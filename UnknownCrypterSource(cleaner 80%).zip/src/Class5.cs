using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Configuration;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Threading;
using Microsoft.VisualBasic.CompilerServices;

[CompilerGenerated]
[EditorBrowsable(EditorBrowsableState.Advanced)]
[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "10.0.0.0")]
internal sealed class Class5 : ApplicationSettingsBase
{
	private static Class5 class5_0 = (Class5)SettingsBase.Synchronized(new Class5());

	private static bool bool_0;

	private static object object_0 = RuntimeHelpers.GetObjectValue(new object());

	public static Class5 Class5_0
	{
		get
		{
			if (!bool_0)
			{
				object obj = object_0;
				ObjectFlowControl.CheckForSyncLockOnValueType(obj);
				bool lockTaken = false;
				try
				{
					Monitor.Enter(obj, ref lockTaken);
					if (!bool_0)
					{
						Class1.Form0_0.Shutdown += delegate
						{
							if (Class1.Form0_0.SaveMySettingsOnExit)
							{
								Class6.Class5_0.Save();
							}
						};
						bool_0 = true;
					}
				}
				finally
				{
					if (lockTaken)
					{
						Monitor.Exit(obj);
					}
				}
			}
			return class5_0;
		}
	}

	[DebuggerNonUserCode]
	public Class5()
	{
	}

	[EditorBrowsable(EditorBrowsableState.Advanced)]
	[DebuggerNonUserCode]
	private static void smethod_0(object sender, EventArgs e)
	{
		if (Class1.Form0_0.SaveMySettingsOnExit)
		{
			Class6.Class5_0.Save();
		}
	}
}
