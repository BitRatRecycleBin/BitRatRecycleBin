using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Net;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

[DesignerGenerated]
public class Dialog1 : Form
{
	private static List<WeakReference> list_0 = new List<WeakReference>();

	private IContainer icontainer_0;

	[AccessedThroughProperty("BlackShadesNetForm1")]
	private GControl0 _BlackShadesNetForm1;

	[AccessedThroughProperty("EightBallLabel1")]
	private Class8 _EightBallLabel1;

	[AccessedThroughProperty("EightBallLabel3")]
	private Class8 _EightBallLabel3;

	[AccessedThroughProperty("EightBallLabel2")]
	private Class8 _EightBallLabel2;

	[AccessedThroughProperty("txtPword")]
	private GControl4 _txtPword;

	[AccessedThroughProperty("txtUname")]
	private GControl4 _txtUname;

	[AccessedThroughProperty("txtEmail")]
	private GControl4 _txtEmail;

	[AccessedThroughProperty("btnRegister")]
	private Control14 _btnRegister;

	[AccessedThroughProperty("btnCancel")]
	private Control15 _btnCancel;

	internal virtual GControl0 BlackShadesNetForm1
	{
		[DebuggerNonUserCode]
		get
		{
			return _BlackShadesNetForm1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_BlackShadesNetForm1 = value;
		}
	}

	internal virtual Class8 EightBallLabel1
	{
		[DebuggerNonUserCode]
		get
		{
			return _EightBallLabel1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_EightBallLabel1 = value;
		}
	}

	internal virtual Class8 EightBallLabel3
	{
		[DebuggerNonUserCode]
		get
		{
			return _EightBallLabel3;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_EightBallLabel3 = value;
		}
	}

	internal virtual Class8 EightBallLabel2
	{
		[DebuggerNonUserCode]
		get
		{
			return _EightBallLabel2;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_EightBallLabel2 = value;
		}
	}

	internal virtual GControl4 txtPword
	{
		[DebuggerNonUserCode]
		get
		{
			return _txtPword;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_txtPword = value;
		}
	}

	internal virtual GControl4 txtUname
	{
		[DebuggerNonUserCode]
		get
		{
			return _txtUname;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_txtUname = value;
		}
	}

	internal virtual GControl4 txtEmail
	{
		[DebuggerNonUserCode]
		get
		{
			return _txtEmail;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_txtEmail = value;
		}
	}

	internal virtual Control14 btnRegister
	{
		[DebuggerNonUserCode]
		get
		{
			return _btnRegister;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			EventHandler value2 = btnRegister_Click;
			if (_btnRegister != null)
			{
				_btnRegister.Click -= value2;
			}
			_btnRegister = value;
			if (_btnRegister != null)
			{
				_btnRegister.Click += value2;
			}
		}
	}

	internal virtual Control15 btnCancel
	{
		[DebuggerNonUserCode]
		get
		{
			return _btnCancel;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			EventHandler value2 = btnCancel_Click;
			if (_btnCancel != null)
			{
				_btnCancel.Click -= value2;
			}
			_btnCancel = value;
			if (_btnCancel != null)
			{
				_btnCancel.Click += value2;
			}
		}
	}

	[DebuggerNonUserCode]
	public Dialog1()
	{
		smethod_0(this);
		InitializeComponent();
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	[DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && icontainer_0 != null)
			{
				icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	[System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		BlackShadesNetForm1 = new GControl0();
		btnRegister = new Control14();
		btnCancel = new Control15();
		txtPword = new GControl4();
		txtUname = new GControl4();
		txtEmail = new GControl4();
		EightBallLabel3 = new Class8();
		EightBallLabel2 = new Class8();
		EightBallLabel1 = new Class8();
		BlackShadesNetForm1.SuspendLayout();
		SuspendLayout();
		BlackShadesNetForm1.Boolean_0 = false;
		BlackShadesNetForm1.Controls.Add(btnRegister);
		BlackShadesNetForm1.Controls.Add(btnCancel);
		BlackShadesNetForm1.Controls.Add(txtPword);
		BlackShadesNetForm1.Controls.Add(txtUname);
		BlackShadesNetForm1.Controls.Add(txtEmail);
		BlackShadesNetForm1.Controls.Add(EightBallLabel3);
		BlackShadesNetForm1.Controls.Add(EightBallLabel2);
		BlackShadesNetForm1.Controls.Add(EightBallLabel1);
		BlackShadesNetForm1.Dock = System.Windows.Forms.DockStyle.Fill;
		BlackShadesNetForm1.Font = new System.Drawing.Font("Trebuchet MS", 8.25f, System.Drawing.FontStyle.Bold);
		BlackShadesNetForm1.ForeColor = System.Drawing.Color.FromArgb(142, 152, 156);
		System.Drawing.Point point2 = (BlackShadesNetForm1.Location = new System.Drawing.Point(0, 0));
		BlackShadesNetForm1.Boolean_1 = true;
		BlackShadesNetForm1.Name = "BlackShadesNetForm1";
		System.Drawing.Size size2 = (BlackShadesNetForm1.Size = new System.Drawing.Size(254, 268));
		BlackShadesNetForm1.TabIndex = 0;
		BlackShadesNetForm1.Text = "Register For UnknownCrypter";
		btnRegister.BackColor = System.Drawing.Color.Transparent;
		btnRegister.Struct0_0 = new Struct0[0];
		btnRegister.String_0 = "";
		btnRegister.Font = new System.Drawing.Font("Verdana", 8f);
		btnRegister.Image_0 = null;
		point2 = (btnRegister.Location = new System.Drawing.Point(15, 229));
		btnRegister.Name = "btnRegister";
		btnRegister.Boolean_0 = false;
		size2 = (btnRegister.Size = new System.Drawing.Size(126, 23));
		btnRegister.TabIndex = 9;
		btnRegister.Text = "Register";
		btnRegister.Boolean_1 = true;
		btnCancel.BackColor = System.Drawing.Color.Transparent;
		btnCancel.Struct0_0 = new Struct0[0];
		btnCancel.String_0 = "";
		btnCancel.Font = new System.Drawing.Font("Verdana", 8f);
		btnCancel.Image_0 = null;
		point2 = (btnCancel.Location = new System.Drawing.Point(164, 229));
		btnCancel.Name = "btnCancel";
		btnCancel.Boolean_0 = false;
		size2 = (btnCancel.Size = new System.Drawing.Size(75, 23));
		btnCancel.TabIndex = 8;
		btnCancel.Text = "Cancel";
		btnCancel.Boolean_1 = true;
		txtPword.BackColor = System.Drawing.Color.FromArgb(36, 40, 42);
		txtPword.ForeColor = System.Drawing.Color.FromArgb(142, 152, 156);
		point2 = (txtPword.Location = new System.Drawing.Point(12, 170));
		txtPword.Int32_0 = 32767;
		txtPword.Name = "txtPword";
		size2 = (txtPword.Size = new System.Drawing.Size(227, 24));
		txtPword.TabIndex = 7;
		txtPword.HorizontalAlignment_0 = System.Windows.Forms.HorizontalAlignment.Left;
		txtPword.Boolean_0 = true;
		txtUname.BackColor = System.Drawing.Color.FromArgb(36, 40, 42);
		txtUname.ForeColor = System.Drawing.Color.FromArgb(142, 152, 156);
		point2 = (txtUname.Location = new System.Drawing.Point(15, 111));
		txtUname.Int32_0 = 32767;
		txtUname.Name = "txtUname";
		size2 = (txtUname.Size = new System.Drawing.Size(227, 24));
		txtUname.TabIndex = 6;
		txtUname.HorizontalAlignment_0 = System.Windows.Forms.HorizontalAlignment.Left;
		txtUname.Boolean_0 = false;
		txtEmail.BackColor = System.Drawing.Color.FromArgb(36, 40, 42);
		txtEmail.ForeColor = System.Drawing.Color.FromArgb(142, 152, 156);
		point2 = (txtEmail.Location = new System.Drawing.Point(15, 55));
		txtEmail.Int32_0 = 32767;
		txtEmail.Name = "txtEmail";
		size2 = (txtEmail.Size = new System.Drawing.Size(227, 24));
		txtEmail.TabIndex = 5;
		txtEmail.HorizontalAlignment_0 = System.Windows.Forms.HorizontalAlignment.Left;
		txtEmail.Boolean_0 = false;
		EightBallLabel3.AutoSize = true;
		EightBallLabel3.BackColor = System.Drawing.Color.Transparent;
		EightBallLabel3.Font = new System.Drawing.Font("Segoe UI", 9f);
		EightBallLabel3.ForeColor = System.Drawing.Color.WhiteSmoke;
		point2 = (EightBallLabel3.Location = new System.Drawing.Point(12, 152));
		EightBallLabel3.Name = "EightBallLabel3";
		size2 = (EightBallLabel3.Size = new System.Drawing.Size(60, 15));
		EightBallLabel3.TabIndex = 4;
		EightBallLabel3.Text = "Password:";
		EightBallLabel2.AutoSize = true;
		EightBallLabel2.BackColor = System.Drawing.Color.Transparent;
		EightBallLabel2.Font = new System.Drawing.Font("Segoe UI", 9f);
		EightBallLabel2.ForeColor = System.Drawing.Color.WhiteSmoke;
		point2 = (EightBallLabel2.Location = new System.Drawing.Point(12, 93));
		EightBallLabel2.Name = "EightBallLabel2";
		size2 = (EightBallLabel2.Size = new System.Drawing.Size(63, 15));
		EightBallLabel2.TabIndex = 3;
		EightBallLabel2.Text = "Username:";
		EightBallLabel1.AutoSize = true;
		EightBallLabel1.BackColor = System.Drawing.Color.Transparent;
		EightBallLabel1.Font = new System.Drawing.Font("Segoe UI", 9f);
		EightBallLabel1.ForeColor = System.Drawing.Color.WhiteSmoke;
		point2 = (EightBallLabel1.Location = new System.Drawing.Point(12, 37));
		EightBallLabel1.Name = "EightBallLabel1";
		size2 = (EightBallLabel1.Size = new System.Drawing.Size(84, 15));
		EightBallLabel1.TabIndex = 2;
		EightBallLabel1.Text = "Email Address:";
		System.Drawing.SizeF sizeF2 = (AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f));
		AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		size2 = (ClientSize = new System.Drawing.Size(254, 268));
		Controls.Add(BlackShadesNetForm1);
		FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
		MaximizeBox = false;
		MinimizeBox = false;
		Name = "Dialog1";
		ShowInTaskbar = false;
		StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
		Text = "Register For UnknownCrypter";
		TransparencyKey = System.Drawing.Color.Fuchsia;
		BlackShadesNetForm1.ResumeLayout(false);
		BlackShadesNetForm1.PerformLayout();
		ResumeLayout(false);
	}

	private void btnCancel_Click(object sender, EventArgs e)
	{
		DialogResult = DialogResult.Cancel;
		Close();
	}

	private void btnRegister_Click(object sender, EventArgs e)
	{
		string text = txtEmail.Text;
		string text2 = txtUname.Text;
		string text3 = txtPword.Text;
		if ((Operators.CompareString(text, "", TextCompare: false) == 0) | (Operators.CompareString(text2, "", TextCompare: false) == 0) | (Operators.CompareString(text3, "", TextCompare: false) == 0))
		{
			MessageBox.Show("All fields are required", "Information Required", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			return;
		}
		try
		{
			WebClient webClient = new WebClient();
			string text4 = webClient.DownloadString("http://kingmummylive.com/server/test_file.php?u=" + text2 + "&p=" + text3 + "&e=" + text);
			if (text4.StartsWith("200 OK"))
			{
				MessageBox.Show(text4.Substring(checked(text4.IndexOf("<>") + 2)), "Registeration Successful");
				Close();
			}
			else
			{
				MessageBox.Show(text4, "Error");
			}
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			MessageBox.Show("Network problem. Try again!", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			ProjectData.ClearProjectError();
		}
	}
}
