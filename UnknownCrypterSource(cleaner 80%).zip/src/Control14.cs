using System.Drawing;
using System.Windows.Forms;

internal class Control14 : Control12
{
	public Control14()
	{
		Boolean_1 = true;
		BackColor = Color.Transparent;
	}

	protected override void ColorHook()
	{
	}

	protected override void PaintHook()
	{
		method_53(Color.FromArgb(0, 0, 0), Color.FromArgb(95, 0, 0), 0, 2, Width / 2, Height / 2, 45f);
		method_53(Color.FromArgb(95, 0, 0), Color.FromArgb(0, 0, 0), Width / 2, 2, checked(Width - 15), Height / 2, -45f);
		method_53(Color.FromArgb(0, 0, 0), Color.FromArgb(95, 0, 0), 0, Height / 2, Width / 2, Height, 45f);
		method_53(Color.FromArgb(95, 0, 0), Color.FromArgb(0, 0, 0), Width / 2, Height / 2, Width, Height / 2, 315f);
		method_32(Pens.Black, 0);
		method_32(Pens.Black, 1);
		method_32(new Pen(Color.FromArgb(95, 0, 0)), 3);
		checked
		{
			graphics_0.DrawLine(new Pen(Color.FromArgb(93, 93, 93)), 3, 3, Width - 5, 3);
			graphics_0.DrawLine(new Pen(Color.FromArgb(73, 73, 73)), 0, Height - 1, Width, Height - 1);
			method_52(Color.FromArgb(0, 0, 0), Color.FromArgb(73, 73, 73), 0, 0, 1, Height);
			method_52(Color.FromArgb(0, 0, 0), Color.FromArgb(73, 73, 73), Width - 1, 0, 1, Height);
			if (enum1_0 == Enum1.Over)
			{
				unchecked
				{
					method_53(Color.FromArgb(0, 0, 0), Color.FromArgb(95, 0, 0), 0, 2, Width / 2, Height / 2, 45f);
					method_53(Color.FromArgb(95, 0, 0), Color.FromArgb(0, 0, 0), Width / 2, 2, checked(Width - 15), Height / 2, -45f);
					method_53(Color.FromArgb(0, 0, 0), Color.FromArgb(95, 0, 0), 0, Height / 2, Width / 2, Height, 45f);
					method_53(Color.FromArgb(95, 0, 0), Color.FromArgb(0, 0, 0), Width / 2, Height / 2, Width, Height / 2, 315f);
				}
				graphics_0.FillRectangle(new SolidBrush(Color.FromArgb(13, Color.White)), 0, 0, Width, unchecked(Height / 2) - 7);
				method_32(Pens.Black, 0);
				method_32(Pens.Black, 1);
				method_32(new Pen(Color.FromArgb(95, 0, 0)), 3);
				graphics_0.DrawLine(new Pen(Color.FromArgb(93, 93, 93)), 3, 3, Width - 5, 3);
				graphics_0.DrawLine(new Pen(Color.FromArgb(73, 73, 73)), 0, Height - 1, Width, Height - 1);
				method_52(Color.FromArgb(0, 0, 0), Color.FromArgb(73, 73, 73), 0, 0, 1, Height);
				method_52(Color.FromArgb(0, 0, 0), Color.FromArgb(73, 73, 73), Width - 1, 0, 1, Height);
			}
			else if (enum1_0 == Enum1.Down)
			{
				unchecked
				{
					method_53(Color.FromArgb(0, 0, 0), Color.FromArgb(95, 0, 0), 0, 2, Width / 2, Height / 2, 45f);
					method_53(Color.FromArgb(95, 0, 0), Color.FromArgb(0, 0, 0), Width / 2, 2, checked(Width - 15), Height / 2, -45f);
					method_53(Color.FromArgb(0, 0, 0), Color.FromArgb(95, 0, 0), 0, Height / 2, Width / 2, Height, 45f);
					method_53(Color.FromArgb(95, 0, 0), Color.FromArgb(0, 0, 0), Width / 2, Height / 2, Width, Height / 2, 315f);
				}
				graphics_0.FillRectangle(new SolidBrush(Color.FromArgb(20, Color.Black)), 0, 0, Width, unchecked(Height / 2) - 7);
				method_32(Pens.Black, 0);
				method_32(Pens.Black, 1);
				method_32(new Pen(Color.FromArgb(95, 0, 0)), 3);
				graphics_0.DrawLine(new Pen(Color.FromArgb(93, 93, 93)), 3, 3, Width - 5, 3);
				graphics_0.DrawLine(new Pen(Color.FromArgb(73, 73, 73)), 0, Height - 1, Width, Height - 1);
				method_52(Color.FromArgb(0, 0, 0), Color.FromArgb(73, 73, 73), 0, 0, 1, Height);
				method_52(Color.FromArgb(0, 0, 0), Color.FromArgb(73, 73, 73), Width - 1, 0, 1, Height);
			}
			method_29(BackColor);
			method_38(Brushes.White, HorizontalAlignment.Center, 0, 0);
		}
	}
}
