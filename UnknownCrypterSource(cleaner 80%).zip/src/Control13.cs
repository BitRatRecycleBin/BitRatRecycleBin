using System.Drawing;

internal class Control13 : Control12
{
	public Control13()
	{
		Boolean_1 = true;
		BackColor = Color.Transparent;
	}

	protected override void ColorHook()
	{
	}

	protected override void PaintHook()
	{
		method_53(Color.FromArgb(141, 141, 141), Color.FromArgb(23, 23, 23), 0, 0, Width, Height, 45f);
		method_32(new Pen(Color.FromArgb(41, 41, 41)), 0);
		method_32(new Pen(Color.FromArgb(41, 41, 41)), 1);
		method_32(Pens.Black, 2);
		checked
		{
			graphics_0.DrawLine(new Pen(Color.FromArgb(100, 100, 100)), 0, Height - 1, Width, Height - 1);
			method_52(Color.FromArgb(41, 41, 41), Color.FromArgb(100, 100, 100), 0, 0, 1, Height);
			method_52(Color.FromArgb(41, 41, 41), Color.FromArgb(100, 100, 100), Width - 1, 0, Width, Height);
			method_29(BackColor);
			method_26(Color.FromArgb(41, 41, 41), 2);
			if (enum1_0 == Enum1.Over)
			{
				method_53(Color.FromArgb(255, 255, 255), Color.FromArgb(23, 23, 23), 0, 0, Width, Height, 45f);
				method_32(new Pen(Color.FromArgb(41, 41, 41)), 0);
				method_32(new Pen(Color.FromArgb(41, 41, 41)), 1);
				method_32(Pens.Black, 2);
				graphics_0.DrawLine(new Pen(Color.FromArgb(100, 100, 100)), 0, Height - 1, Width, Height - 1);
				method_52(Color.FromArgb(41, 41, 41), Color.FromArgb(100, 100, 100), 0, 0, 1, Height);
				method_52(Color.FromArgb(41, 41, 41), Color.FromArgb(100, 100, 100), Width - 1, 0, Width, Height);
				method_29(BackColor);
				method_26(Color.FromArgb(41, 41, 41), 2);
			}
			else if (enum1_0 == Enum1.Down)
			{
				method_53(Color.FromArgb(100, 100, 100), Color.FromArgb(23, 23, 23), 0, 0, Width, Height, 45f);
				method_32(new Pen(Color.FromArgb(41, 41, 41)), 0);
				method_32(new Pen(Color.FromArgb(41, 41, 41)), 1);
				method_32(Pens.Black, 2);
				graphics_0.DrawLine(new Pen(Color.FromArgb(100, 100, 100)), 0, Height - 1, Width, Height - 1);
				method_52(Color.FromArgb(41, 41, 41), Color.FromArgb(100, 100, 100), 0, 0, 1, Height);
				method_52(Color.FromArgb(41, 41, 41), Color.FromArgb(100, 100, 100), Width - 1, 0, Width, Height);
				method_29(BackColor);
				method_26(Color.FromArgb(41, 41, 41), 2);
			}
		}
	}
}
