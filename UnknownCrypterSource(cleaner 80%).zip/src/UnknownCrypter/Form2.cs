using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using UnknownCrypter.My.Resources;

namespace UnknownCrypter
{
	[DesignerGenerated]
	public class Form2 : Form
	{
		private delegate void Delegate3(string msg);

		private static List<WeakReference> list_0 = new List<WeakReference>();

		private IContainer icontainer_0;

		[AccessedThroughProperty("BlackShadesNetForm1")]
		private GControl0 _BlackShadesNetForm1;

		[AccessedThroughProperty("BoosterControlpanel1")]
		private Control10 _BoosterControlpanel1;

		[AccessedThroughProperty("btnInstall")]
		private Control14 _btnInstall;

		[AccessedThroughProperty("btnStart")]
		private Control15 _btnStart;

		[AccessedThroughProperty("EightBallLabel3")]
		private Class8 _EightBallLabel3;

		[AccessedThroughProperty("EightBallLabel2")]
		private Class8 _EightBallLabel2;

		[AccessedThroughProperty("EightBallLabel1")]
		private Class8 _EightBallLabel1;

		[AccessedThroughProperty("progressBar")]
		private Control19 _progressBar;

		[AccessedThroughProperty("lblSize")]
		private Class8 _lblSize;

		[AccessedThroughProperty("lblCVersion")]
		private Class8 _lblCVersion;

		[AccessedThroughProperty("lblNVersion")]
		private Class8 _lblNVersion;

		[AccessedThroughProperty("lblPercent")]
		private Class8 _lblPercent;

		[AccessedThroughProperty("picLoading")]
		private PictureBox _picLoading;

		[AccessedThroughProperty("lblLoading")]
		private Class8 _lblLoading;

		[AccessedThroughProperty("lblInfo")]
		private Class8 _lblInfo;

		private bool bool_0;

		private Delegate3 delegate3_0;

		private Delegate3 delegate3_1;

		private Delegate3 delegate3_2;

		internal virtual GControl0 BlackShadesNetForm1
		{
			[DebuggerNonUserCode]
			get
			{
				return _BlackShadesNetForm1;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_BlackShadesNetForm1 = value;
			}
		}

		internal virtual Control10 BoosterControlpanel1
		{
			[DebuggerNonUserCode]
			get
			{
				return _BoosterControlpanel1;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_BoosterControlpanel1 = value;
			}
		}

		internal virtual Control14 btnInstall
		{
			[DebuggerNonUserCode]
			get
			{
				return _btnInstall;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				EventHandler value2 = btnInstall_Click;
				if (_btnInstall != null)
				{
					_btnInstall.Click -= value2;
				}
				_btnInstall = value;
				if (_btnInstall != null)
				{
					_btnInstall.Click += value2;
				}
			}
		}

		internal virtual Control15 btnStart
		{
			[DebuggerNonUserCode]
			get
			{
				return _btnStart;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				EventHandler value2 = btnStart_Click;
				if (_btnStart != null)
				{
					_btnStart.Click -= value2;
				}
				_btnStart = value;
				if (_btnStart != null)
				{
					_btnStart.Click += value2;
				}
			}
		}

		internal virtual Class8 EightBallLabel3
		{
			[DebuggerNonUserCode]
			get
			{
				return _EightBallLabel3;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_EightBallLabel3 = value;
			}
		}

		internal virtual Class8 EightBallLabel2
		{
			[DebuggerNonUserCode]
			get
			{
				return _EightBallLabel2;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_EightBallLabel2 = value;
			}
		}

		internal virtual Class8 EightBallLabel1
		{
			[DebuggerNonUserCode]
			get
			{
				return _EightBallLabel1;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_EightBallLabel1 = value;
			}
		}

		internal virtual Control19 progressBar
		{
			[DebuggerNonUserCode]
			get
			{
				return _progressBar;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_progressBar = value;
			}
		}

		internal virtual Class8 lblSize
		{
			[DebuggerNonUserCode]
			get
			{
				return _lblSize;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_lblSize = value;
			}
		}

		internal virtual Class8 lblCVersion
		{
			[DebuggerNonUserCode]
			get
			{
				return _lblCVersion;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_lblCVersion = value;
			}
		}

		internal virtual Class8 lblNVersion
		{
			[DebuggerNonUserCode]
			get
			{
				return _lblNVersion;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_lblNVersion = value;
			}
		}

		internal virtual Class8 lblPercent
		{
			[DebuggerNonUserCode]
			get
			{
				return _lblPercent;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_lblPercent = value;
			}
		}

		internal virtual PictureBox picLoading
		{
			[DebuggerNonUserCode]
			get
			{
				return _picLoading;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_picLoading = value;
			}
		}

		internal virtual Class8 lblLoading
		{
			[DebuggerNonUserCode]
			get
			{
				return _lblLoading;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_lblLoading = value;
			}
		}

		internal virtual Class8 lblInfo
		{
			[DebuggerNonUserCode]
			get
			{
				return _lblInfo;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_lblInfo = value;
			}
		}

		public Form2()
		{
			base.FormClosing += Form2_FormClosing;
			base.Load += Form2_Load;
			smethod_0(this);
			bool_0 = false;
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		private static void smethod_0(object object_0)
		{
			checked
			{
				lock (list_0)
				{
					if (list_0.Count == list_0.Capacity)
					{
						int num = 0;
						int num2 = list_0.Count - 1;
						int num3 = 0;
						while (true)
						{
							int num4 = num3;
							int num5 = num2;
							if (num4 > num5)
							{
								break;
							}
							WeakReference weakReference = list_0[num3];
							if (weakReference.IsAlive)
							{
								if (num3 != num)
								{
									list_0[num] = list_0[num3];
								}
								num++;
							}
							num3++;
						}
						list_0.RemoveRange(num, list_0.Count - num);
						list_0.Capacity = list_0.Count;
					}
					list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
				}
			}
		}

		[DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				if (disposing && icontainer_0 != null)
				{
					icontainer_0.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		[System.Diagnostics.DebuggerStepThrough]
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UnknownCrypter.Form2));
			BlackShadesNetForm1 = new GControl0();
			lblInfo = new Class8();
			picLoading = new System.Windows.Forms.PictureBox();
			lblLoading = new Class8();
			btnInstall = new Control14();
			btnStart = new Control15();
			BoosterControlpanel1 = new Control10();
			lblPercent = new Class8();
			lblSize = new Class8();
			lblCVersion = new Class8();
			lblNVersion = new Class8();
			EightBallLabel3 = new Class8();
			EightBallLabel2 = new Class8();
			EightBallLabel1 = new Class8();
			progressBar = new Control19();
			BlackShadesNetForm1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)picLoading).BeginInit();
			BoosterControlpanel1.SuspendLayout();
			SuspendLayout();
			BlackShadesNetForm1.Boolean_0 = false;
			BlackShadesNetForm1.Controls.Add(lblInfo);
			BlackShadesNetForm1.Controls.Add(picLoading);
			BlackShadesNetForm1.Controls.Add(lblLoading);
			BlackShadesNetForm1.Controls.Add(btnInstall);
			BlackShadesNetForm1.Controls.Add(btnStart);
			BlackShadesNetForm1.Controls.Add(BoosterControlpanel1);
			BlackShadesNetForm1.Dock = System.Windows.Forms.DockStyle.Fill;
			BlackShadesNetForm1.Font = new System.Drawing.Font("Trebuchet MS", 8.25f, System.Drawing.FontStyle.Bold);
			BlackShadesNetForm1.ForeColor = System.Drawing.Color.FromArgb(142, 152, 156);
			System.Drawing.Point point2 = (BlackShadesNetForm1.Location = new System.Drawing.Point(0, 0));
			BlackShadesNetForm1.Boolean_1 = true;
			BlackShadesNetForm1.Name = "BlackShadesNetForm1";
			System.Drawing.Size size2 = (BlackShadesNetForm1.Size = new System.Drawing.Size(262, 261));
			BlackShadesNetForm1.TabIndex = 0;
			BlackShadesNetForm1.Text = "Software Updater";
			lblInfo.AutoSize = true;
			lblInfo.BackColor = System.Drawing.Color.Transparent;
			lblInfo.Font = new System.Drawing.Font("Segoe UI", 9f);
			lblInfo.ForeColor = System.Drawing.Color.WhiteSmoke;
			point2 = (lblInfo.Location = new System.Drawing.Point(12, 176));
			lblInfo.Name = "lblInfo";
			size2 = (lblInfo.Size = new System.Drawing.Size(224, 30));
			lblInfo.TabIndex = 9;
			lblInfo.Text = "Download completed successfully! \r\nClick \"Install Update\" button to continue.";
			lblInfo.Visible = false;
			picLoading.BackColor = System.Drawing.Color.Transparent;
			picLoading.Image = UnknownCrypter.My.Resources.Resources.Bitmap_0;
			point2 = (picLoading.Location = new System.Drawing.Point(91, 184));
			picLoading.Name = "picLoading";
			size2 = (picLoading.Size = new System.Drawing.Size(16, 16));
			picLoading.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			picLoading.TabIndex = 7;
			picLoading.TabStop = false;
			lblLoading.AutoSize = true;
			lblLoading.BackColor = System.Drawing.Color.Transparent;
			lblLoading.Font = new System.Drawing.Font("Segoe UI", 9f);
			lblLoading.ForeColor = System.Drawing.Color.WhiteSmoke;
			point2 = (lblLoading.Location = new System.Drawing.Point(113, 185));
			lblLoading.Name = "lblLoading";
			size2 = (lblLoading.Size = new System.Drawing.Size(59, 15));
			lblLoading.TabIndex = 6;
			lblLoading.Text = "Loading...";
			btnInstall.BackColor = System.Drawing.Color.Transparent;
			btnInstall.Struct0_0 = new Struct0[0];
			btnInstall.String_0 = "";
			btnInstall.Font = new System.Drawing.Font("Verdana", 8f);
			btnInstall.Image_0 = null;
			point2 = (btnInstall.Location = new System.Drawing.Point(126, 226));
			btnInstall.Name = "btnInstall";
			btnInstall.Boolean_0 = false;
			size2 = (btnInstall.Size = new System.Drawing.Size(124, 23));
			btnInstall.TabIndex = 4;
			btnInstall.Text = "Install Update";
			btnInstall.Boolean_1 = true;
			btnInstall.Visible = false;
			btnStart.BackColor = System.Drawing.Color.Transparent;
			btnStart.Struct0_0 = new Struct0[0];
			btnStart.String_0 = "";
			btnStart.Font = new System.Drawing.Font("Verdana", 8f);
			btnStart.Image_0 = null;
			point2 = (btnStart.Location = new System.Drawing.Point(12, 226));
			btnStart.Name = "btnStart";
			btnStart.Boolean_0 = false;
			size2 = (btnStart.Size = new System.Drawing.Size(108, 23));
			btnStart.TabIndex = 3;
			btnStart.Text = "Start Update";
			btnStart.Boolean_1 = true;
			btnStart.Visible = false;
			BoosterControlpanel1.BackColor = System.Drawing.Color.Transparent;
			BoosterControlpanel1.FormBorderStyle_0 = System.Windows.Forms.FormBorderStyle.None;
			BoosterControlpanel1.Struct0_0 = new Struct0[0];
			BoosterControlpanel1.Controls.Add(lblPercent);
			BoosterControlpanel1.Controls.Add(lblSize);
			BoosterControlpanel1.Controls.Add(lblCVersion);
			BoosterControlpanel1.Controls.Add(lblNVersion);
			BoosterControlpanel1.Controls.Add(EightBallLabel3);
			BoosterControlpanel1.Controls.Add(EightBallLabel2);
			BoosterControlpanel1.Controls.Add(EightBallLabel1);
			BoosterControlpanel1.Controls.Add(progressBar);
			BoosterControlpanel1.String_0 = "";
			BoosterControlpanel1.Font = new System.Drawing.Font("Verdana", 8f);
			BoosterControlpanel1.Image_0 = null;
			point2 = (BoosterControlpanel1.Location = new System.Drawing.Point(12, 38));
			BoosterControlpanel1.Boolean_1 = true;
			BoosterControlpanel1.Name = "BoosterControlpanel1";
			BoosterControlpanel1.Boolean_3 = false;
			BoosterControlpanel1.Boolean_2 = true;
			size2 = (BoosterControlpanel1.Size = new System.Drawing.Size(238, 123));
			BoosterControlpanel1.Boolean_0 = true;
			BoosterControlpanel1.FormStartPosition_0 = System.Windows.Forms.FormStartPosition.Manual;
			BoosterControlpanel1.TabIndex = 2;
			BoosterControlpanel1.Text = "Update Information";
			BoosterControlpanel1.Color_0 = System.Drawing.Color.Empty;
			BoosterControlpanel1.Boolean_4 = true;
			lblPercent.AutoSize = true;
			lblPercent.BackColor = System.Drawing.Color.Transparent;
			lblPercent.Font = new System.Drawing.Font("Segoe UI", 9f);
			lblPercent.ForeColor = System.Drawing.Color.WhiteSmoke;
			point2 = (lblPercent.Location = new System.Drawing.Point(107, 33));
			lblPercent.Name = "lblPercent";
			size2 = (lblPercent.Size = new System.Drawing.Size(23, 15));
			lblPercent.TabIndex = 7;
			lblPercent.Text = "0%";
			lblPercent.Visible = false;
			lblSize.AutoSize = true;
			lblSize.BackColor = System.Drawing.Color.Transparent;
			lblSize.Font = new System.Drawing.Font("Segoe UI", 9f);
			lblSize.ForeColor = System.Drawing.Color.WhiteSmoke;
			point2 = (lblSize.Location = new System.Drawing.Point(102, 98));
			lblSize.Name = "lblSize";
			size2 = (lblSize.Size = new System.Drawing.Size(13, 15));
			lblSize.TabIndex = 6;
			lblSize.Text = "0";
			lblCVersion.AutoSize = true;
			lblCVersion.BackColor = System.Drawing.Color.Transparent;
			lblCVersion.Font = new System.Drawing.Font("Segoe UI", 9f);
			lblCVersion.ForeColor = System.Drawing.Color.WhiteSmoke;
			point2 = (lblCVersion.Location = new System.Drawing.Point(102, 78));
			lblCVersion.Name = "lblCVersion";
			size2 = (lblCVersion.Size = new System.Drawing.Size(13, 15));
			lblCVersion.TabIndex = 5;
			lblCVersion.Text = "0";
			lblNVersion.AutoSize = true;
			lblNVersion.BackColor = System.Drawing.Color.Transparent;
			lblNVersion.Font = new System.Drawing.Font("Segoe UI", 9f);
			lblNVersion.ForeColor = System.Drawing.Color.WhiteSmoke;
			point2 = (lblNVersion.Location = new System.Drawing.Point(102, 58));
			lblNVersion.Name = "lblNVersion";
			size2 = (lblNVersion.Size = new System.Drawing.Size(13, 15));
			lblNVersion.TabIndex = 4;
			lblNVersion.Text = "0";
			EightBallLabel3.AutoSize = true;
			EightBallLabel3.BackColor = System.Drawing.Color.Transparent;
			EightBallLabel3.Font = new System.Drawing.Font("Segoe UI", 9f);
			EightBallLabel3.ForeColor = System.Drawing.Color.WhiteSmoke;
			point2 = (EightBallLabel3.Location = new System.Drawing.Point(3, 98));
			EightBallLabel3.Name = "EightBallLabel3";
			size2 = (EightBallLabel3.Size = new System.Drawing.Size(87, 15));
			EightBallLabel3.TabIndex = 3;
			EightBallLabel3.Text = "Download Size:";
			EightBallLabel2.AutoSize = true;
			EightBallLabel2.BackColor = System.Drawing.Color.Transparent;
			EightBallLabel2.Font = new System.Drawing.Font("Segoe UI", 9f);
			EightBallLabel2.ForeColor = System.Drawing.Color.WhiteSmoke;
			point2 = (EightBallLabel2.Location = new System.Drawing.Point(3, 78));
			EightBallLabel2.Name = "EightBallLabel2";
			size2 = (EightBallLabel2.Size = new System.Drawing.Size(92, 15));
			EightBallLabel2.TabIndex = 2;
			EightBallLabel2.Text = "Current Version:";
			EightBallLabel1.AutoSize = true;
			EightBallLabel1.BackColor = System.Drawing.Color.Transparent;
			EightBallLabel1.Font = new System.Drawing.Font("Segoe UI", 9f);
			EightBallLabel1.ForeColor = System.Drawing.Color.WhiteSmoke;
			point2 = (EightBallLabel1.Location = new System.Drawing.Point(3, 58));
			EightBallLabel1.Name = "EightBallLabel1";
			size2 = (EightBallLabel1.Size = new System.Drawing.Size(76, 15));
			EightBallLabel1.TabIndex = 1;
			EightBallLabel1.Text = "New Version:";
			progressBar.BackColor = System.Drawing.Color.Transparent;
			progressBar.Struct0_0 = new Struct0[0];
			progressBar.String_0 = "";
			progressBar.Font = new System.Drawing.Font("Verdana", 8f);
			progressBar.Image_0 = null;
			point2 = (progressBar.Location = new System.Drawing.Point(3, 29));
			progressBar.Int32_3 = 100;
			progressBar.Name = "progressBar";
			progressBar.Boolean_0 = false;
			size2 = (progressBar.Size = new System.Drawing.Size(232, 23));
			progressBar.TabIndex = 0;
			progressBar.Text = "BoosterRedProgressbar1";
			progressBar.Boolean_1 = true;
			progressBar.Int32_2 = 0;
			progressBar.Visible = false;
			System.Drawing.SizeF sizeF2 = (AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f));
			AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			size2 = (ClientSize = new System.Drawing.Size(262, 261));
			Controls.Add(BlackShadesNetForm1);
			FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
			Name = "Form2";
			StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			Text = "Software Updater";
			TopMost = true;
			TransparencyKey = System.Drawing.Color.Fuchsia;
			BlackShadesNetForm1.ResumeLayout(false);
			BlackShadesNetForm1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)picLoading).EndInit();
			BoosterControlpanel1.ResumeLayout(false);
			BoosterControlpanel1.PerformLayout();
			ResumeLayout(false);
		}

		private void Form2_FormClosing(object sender, FormClosingEventArgs e)
		{
			Class1.MyForms_0.Form1_0.WindowState = FormWindowState.Normal;
			Class1.MyForms_0.Form1_0.ShowInTaskbar = true;
		}

		private void Form2_Load(object sender, EventArgs e)
		{
			lblPercent.BackColor = Color.FromArgb(66, 0, 0);
			lblCVersion.Text = Class1.MyForms_0.Form1_0.string_3;
			lblNVersion.Text = Class1.MyForms_0.Form1_0.string_4;
			delegate3_0 = method_1;
			Thread thread = new Thread(method_3);
			thread.Start();
		}

		private void method_0(string string_0)
		{
			if (InvokeRequired)
			{
				Invoke(new Delegate3(method_0), string_0);
				return;
			}
			progressBar.Int32_2 = Conversions.ToInteger(string_0);
			lblPercent.Text = string_0 + "%";
			if ((Conversions.ToInteger(string_0) >= 50) & !bool_0)
			{
				lblPercent.BackColor = Color.FromArgb(204, 0, 0);
				bool_0 = true;
			}
		}

		private void method_1(string string_0)
		{
			if (InvokeRequired)
			{
				Invoke(new Delegate3(method_1), string_0);
			}
			else if (string_0.Substring(0, string_0.IndexOf("\r\n")).Contains("200"))
			{
				string text = string_0.ToLower().Substring(checked(string_0.ToLower().IndexOf("content-length: ") + 16));
				text = Conversions.ToString(Math.Round(Conversions.ToDouble(text.Substring(0, text.IndexOf("\r\n"))) / 1024.0, 2)) + " KiB";
				lblSize.Text = text;
				lblLoading.Visible = false;
				picLoading.Visible = false;
				btnStart.Visible = true;
				delegate3_1 = method_0;
				delegate3_2 = method_2;
			}
			else
			{
				MessageBox.Show(string_0, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		private void method_2(string string_0)
		{
			if (InvokeRequired)
			{
				Invoke(new Delegate3(method_2), string_0);
			}
			else
			{
				btnInstall.Visible = true;
				lblInfo.Visible = true;
			}
		}

		private void method_3()
		{
			try
			{
				TcpClient tcpClient = new TcpClient("kingmummylive.com", 80);
				NetworkStream stream = tcpClient.GetStream();
				string s = "GET /unknown/update.exe HTTP/1.1\r\nHost: kingmummylive.com\r\nConnection: close\r\n\r\n";
				byte[] bytes = Encoding.ASCII.GetBytes(s);
				stream.Write(bytes, 0, bytes.Length);
				stream.Flush();
				byte[] array = new byte[1];
				StringBuilder stringBuilder = new StringBuilder();
				do
				{
					int num = stream.Read(array, 0, array.Length);
					if (num != 0)
					{
						stringBuilder.Append(Encoding.ASCII.GetString(array, 0, num));
						continue;
					}
					stream.Close();
					tcpClient.Close();
					delegate3_0("An error has occured\r\n");
					return;
				}
				while (!stringBuilder.ToString().EndsWith("\r\n\r\n"));
				tcpClient.Close();
				stream.Close();
				delegate3_0(stringBuilder.ToString());
			}
			catch (Exception projectError)
			{
				ProjectData.SetProjectError(projectError);
				delegate3_0("An Error has occured\r\n");
				ProjectData.ClearProjectError();
			}
		}

		private void btnStart_Click(object sender, EventArgs e)
		{
			progressBar.Visible = true;
			lblPercent.Visible = true;
			btnStart.Enabled = false;
			Thread thread = new Thread(method_4);
			thread.Start();
		}

		private void method_4()
		{
			checked
			{
				try
				{
					TcpClient tcpClient = new TcpClient("kingmummylive.com", 80);
					NetworkStream stream = tcpClient.GetStream();
					string s = "GET /unknown/update.exe HTTP/1.1\r\nHost: kingmummylive.com\r\nConnection: close\r\n\r\n";
					byte[] bytes = Encoding.ASCII.GetBytes(s);
					stream.Write(bytes, 0, bytes.Length);
					stream.Flush();
					byte[] array = new byte[1];
					StringBuilder stringBuilder = new StringBuilder();
					do
					{
						int num = stream.Read(array, 0, array.Length);
						if (num != 0)
						{
							stringBuilder.Append(Encoding.ASCII.GetString(array, 0, num));
							continue;
						}
						stream.Close();
						tcpClient.Close();
						delegate3_0("Update downloading failed. Pls try again!\r\n");
						return;
					}
					while (!stringBuilder.ToString().EndsWith("\r\n\r\n"));
					string text = stringBuilder.ToString();
					if (text.Substring(0, text.IndexOf("\r\n")).Contains("200"))
					{
						string text2 = text.ToLower().Substring(text.ToLower().IndexOf("content-length: ") + 16);
						text2 = text2.Substring(0, text2.IndexOf("\r\n"));
						string text3 = Application.ExecutablePath + ".download";
						array = new byte[4097];
						int num2 = 0;
						int num3 = Conversions.ToInteger(text2);
						FileStream fileStream = new FileStream(text3, FileMode.Create);
						while (true)
						{
							int num = stream.Read(array, 0, array.Length);
							if (num == 0)
							{
								break;
							}
							fileStream.Write(array, 0, num);
							fileStream.Flush();
							num2 += num;
							delegate3_1(Conversions.ToString(Math.Ceiling((double)num2 / (double)num3 * 100.0)));
							Thread.Sleep(50);
						}
						stream.Close();
						tcpClient.Close();
						fileStream.Close();
						if (num3 == num2)
						{
							delegate3_2(text3);
						}
						else
						{
							delegate3_0("Update downloading failed. Pls try again!\r\n");
						}
					}
					else
					{
						delegate3_0("Update downloading failed. Pls try again!\r\n");
					}
				}
				catch (Exception projectError)
				{
					ProjectData.SetProjectError(projectError);
					delegate3_0("Update downloading failed. Pls try again!\r\n");
					ProjectData.ClearProjectError();
				}
			}
		}

		private void btnInstall_Click(object sender, EventArgs e)
		{
			string text = "\"" + Application.ExecutablePath + "\"";
			string text2 = "\"" + Application.ExecutablePath + ".download\"";
			string contents = "taskkill /F /IM " + Path.GetFileName(Application.ExecutablePath) + " && timeout /t 5 /nobreak && del " + text + " && ren " + text2 + " " + Path.GetFileName(Application.ExecutablePath) + " && " + text + " && exit";
			File.WriteAllText("update.bat", contents);
			Process.Start("update.bat");
		}
	}
}
