using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using UnknownCrypter.My.Resources;

namespace UnknownCrypter
{
	[DesignerGenerated]
	public class Form1 : Form
	{
		private delegate void Delegate2(string msg);

		private static List<WeakReference> list_0 = new List<WeakReference>();

		private IContainer icontainer_0;

		[AccessedThroughProperty("BlackShadesNetForm1")]
		private GControl0 _BlackShadesNetForm1;

		[AccessedThroughProperty("EightBallLabel1")]
		private Class8 _EightBallLabel1;

		[AccessedThroughProperty("BoosterControlpanel1")]
		private Control10 _BoosterControlpanel1;

		[AccessedThroughProperty("EightBallLabel4")]
		private Class8 _EightBallLabel4;

		[AccessedThroughProperty("EightBallLabel3")]
		private Class8 _EightBallLabel3;

		[AccessedThroughProperty("txtPassword")]
		private GControl4 _txtPassword;

		[AccessedThroughProperty("txtUsername")]
		private GControl4 _txtUsername;

		[AccessedThroughProperty("EightBallLabel2")]
		private Class8 _EightBallLabel2;

		[AccessedThroughProperty("chkRemember")]
		private Control20 _chkRemember;

		[AccessedThroughProperty("btnLogin")]
		private Control14 _btnLogin;

		[AccessedThroughProperty("btnForgot")]
		private Class8 _btnForgot;

		[AccessedThroughProperty("mnuAbout")]
		private Class8 _mnuAbout;

		[AccessedThroughProperty("Timer1")]
		private System.Windows.Forms.Timer timer_0;

		[AccessedThroughProperty("PictureBox1")]
		private PictureBox _PictureBox1;

		[AccessedThroughProperty("btnSignUp")]
		private Control15 _btnSignUp;

		[AccessedThroughProperty("txtUpdate")]
		private GControl4 _txtUpdate;

		public static string string_0;

		public static string string_1;

		public static string string_2;

		private Delegate2 delegate2_0;

		private Delegate2 delegate2_1;

		public string string_3;

		public string string_4;

		public string string_5;

		public bool bool_0;

		internal virtual GControl0 BlackShadesNetForm1
		{
			[DebuggerNonUserCode]
			get
			{
				return _BlackShadesNetForm1;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_BlackShadesNetForm1 = value;
			}
		}

		internal virtual Class8 EightBallLabel1
		{
			[DebuggerNonUserCode]
			get
			{
				return _EightBallLabel1;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_EightBallLabel1 = value;
			}
		}

		internal virtual Control10 BoosterControlpanel1
		{
			[DebuggerNonUserCode]
			get
			{
				return _BoosterControlpanel1;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_BoosterControlpanel1 = value;
			}
		}

		internal virtual Class8 EightBallLabel4
		{
			[DebuggerNonUserCode]
			get
			{
				return _EightBallLabel4;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_EightBallLabel4 = value;
			}
		}

		internal virtual Class8 EightBallLabel3
		{
			[DebuggerNonUserCode]
			get
			{
				return _EightBallLabel3;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_EightBallLabel3 = value;
			}
		}

		internal virtual GControl4 txtPassword
		{
			[DebuggerNonUserCode]
			get
			{
				return _txtPassword;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_txtPassword = value;
			}
		}

		internal virtual GControl4 txtUsername
		{
			[DebuggerNonUserCode]
			get
			{
				return _txtUsername;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_txtUsername = value;
			}
		}

		internal virtual Class8 EightBallLabel2
		{
			[DebuggerNonUserCode]
			get
			{
				return _EightBallLabel2;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_EightBallLabel2 = value;
			}
		}

		internal virtual Control20 chkRemember
		{
			[DebuggerNonUserCode]
			get
			{
				return _chkRemember;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				Control20.Delegate0 value2 = method_2;
				if (_chkRemember != null)
				{
					_chkRemember.Event_0 -= value2;
				}
				_chkRemember = value;
				if (_chkRemember != null)
				{
					_chkRemember.Event_0 += value2;
				}
			}
		}

		internal virtual Control14 btnLogin
		{
			[DebuggerNonUserCode]
			get
			{
				return _btnLogin;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				EventHandler value2 = btnLogin_Click;
				if (_btnLogin != null)
				{
					_btnLogin.Click -= value2;
				}
				_btnLogin = value;
				if (_btnLogin != null)
				{
					_btnLogin.Click += value2;
				}
			}
		}

		internal virtual Class8 btnForgot
		{
			[DebuggerNonUserCode]
			get
			{
				return _btnForgot;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				EventHandler value2 = btnForgot_Click;
				if (_btnForgot != null)
				{
					_btnForgot.Click -= value2;
				}
				_btnForgot = value;
				if (_btnForgot != null)
				{
					_btnForgot.Click += value2;
				}
			}
		}

		internal virtual Class8 mnuAbout
		{
			[DebuggerNonUserCode]
			get
			{
				return _mnuAbout;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				EventHandler value2 = mnuAbout_Click;
				if (_mnuAbout != null)
				{
					_mnuAbout.Click -= value2;
				}
				_mnuAbout = value;
				if (_mnuAbout != null)
				{
					_mnuAbout.Click += value2;
				}
			}
		}

		internal virtual System.Windows.Forms.Timer Timer_0
		{
			[DebuggerNonUserCode]
			get
			{
				return timer_0;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				EventHandler value2 = Timer_0_Tick;
				if (timer_0 != null)
				{
					timer_0.Tick -= value2;
				}
				timer_0 = value;
				if (timer_0 != null)
				{
					timer_0.Tick += value2;
				}
			}
		}

		internal virtual PictureBox PictureBox1
		{
			[DebuggerNonUserCode]
			get
			{
				return _PictureBox1;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_PictureBox1 = value;
			}
		}

		internal virtual Control15 btnSignUp
		{
			[DebuggerNonUserCode]
			get
			{
				return _btnSignUp;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				EventHandler value2 = btnSignUp_Click;
				if (_btnSignUp != null)
				{
					_btnSignUp.Click -= value2;
				}
				_btnSignUp = value;
				if (_btnSignUp != null)
				{
					_btnSignUp.Click += value2;
				}
			}
		}

		internal virtual GControl4 txtUpdate
		{
			[DebuggerNonUserCode]
			get
			{
				return _txtUpdate;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			[DebuggerNonUserCode]
			set
			{
				_txtUpdate = value;
			}
		}

		public Form1()
		{
			base.Load += Form1_Load;
			smethod_0(this);
			string_3 = "2.0";
			string_4 = "0";
			string_5 = "";
			bool_0 = false;
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		private static void smethod_0(object object_0)
		{
			checked
			{
				lock (list_0)
				{
					if (list_0.Count == list_0.Capacity)
					{
						int num = 0;
						int num2 = list_0.Count - 1;
						int num3 = 0;
						while (true)
						{
							int num4 = num3;
							int num5 = num2;
							if (num4 > num5)
							{
								break;
							}
							WeakReference weakReference = list_0[num3];
							if (weakReference.IsAlive)
							{
								if (num3 != num)
								{
									list_0[num] = list_0[num3];
								}
								num++;
							}
							num3++;
						}
						list_0.RemoveRange(num, list_0.Count - num);
						list_0.Capacity = list_0.Count;
					}
					list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
				}
			}
		}

		[DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				if (disposing && icontainer_0 != null)
				{
					icontainer_0.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		[System.Diagnostics.DebuggerStepThrough]
		private void InitializeComponent()
		{
			icontainer_0 = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UnknownCrypter.Form1));
			Timer_0 = new System.Windows.Forms.Timer(icontainer_0);
			BlackShadesNetForm1 = new GControl0();
			txtUpdate = new GControl4();
			btnSignUp = new Control15();
			PictureBox1 = new System.Windows.Forms.PictureBox();
			btnForgot = new Class8();
			mnuAbout = new Class8();
			BoosterControlpanel1 = new Control10();
			chkRemember = new Control20();
			btnLogin = new Control14();
			EightBallLabel4 = new Class8();
			EightBallLabel3 = new Class8();
			txtPassword = new GControl4();
			txtUsername = new GControl4();
			EightBallLabel2 = new Class8();
			EightBallLabel1 = new Class8();
			BlackShadesNetForm1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)PictureBox1).BeginInit();
			BoosterControlpanel1.SuspendLayout();
			SuspendLayout();
			Timer_0.Enabled = true;
			Timer_0.Interval = 2000;
			BlackShadesNetForm1.Boolean_0 = false;
			BlackShadesNetForm1.Controls.Add(txtUpdate);
			BlackShadesNetForm1.Controls.Add(btnSignUp);
			BlackShadesNetForm1.Controls.Add(PictureBox1);
			BlackShadesNetForm1.Controls.Add(btnForgot);
			BlackShadesNetForm1.Controls.Add(mnuAbout);
			BlackShadesNetForm1.Controls.Add(BoosterControlpanel1);
			BlackShadesNetForm1.Controls.Add(EightBallLabel2);
			BlackShadesNetForm1.Controls.Add(EightBallLabel1);
			BlackShadesNetForm1.Dock = System.Windows.Forms.DockStyle.Fill;
			BlackShadesNetForm1.Font = new System.Drawing.Font("Trebuchet MS", 8.25f, System.Drawing.FontStyle.Bold);
			BlackShadesNetForm1.ForeColor = System.Drawing.Color.FromArgb(142, 152, 156);
			System.Drawing.Point point2 = (BlackShadesNetForm1.Location = new System.Drawing.Point(0, 0));
			System.Windows.Forms.Padding padding2 = (BlackShadesNetForm1.Margin = new System.Windows.Forms.Padding(4));
			BlackShadesNetForm1.Boolean_1 = true;
			BlackShadesNetForm1.Name = "BlackShadesNetForm1";
			System.Drawing.Size size2 = (BlackShadesNetForm1.Size = new System.Drawing.Size(473, 481));
			BlackShadesNetForm1.TabIndex = 0;
			BlackShadesNetForm1.Text = "UnKnown Crypter v2.0";
			txtUpdate.BackColor = System.Drawing.Color.FromArgb(36, 40, 42);
			txtUpdate.ForeColor = System.Drawing.Color.FromArgb(142, 152, 156);
			point2 = (txtUpdate.Location = new System.Drawing.Point(16, 438));
			padding2 = (txtUpdate.Margin = new System.Windows.Forms.Padding(0));
			txtUpdate.Int32_0 = 32767;
			txtUpdate.Name = "txtUpdate";
			size2 = (txtUpdate.Size = new System.Drawing.Size(437, 27));
			txtUpdate.TabIndex = 6;
			txtUpdate.Text = "https://join.skype.com/x4wQnXDb0UiU";
			txtUpdate.HorizontalAlignment_0 = System.Windows.Forms.HorizontalAlignment.Left;
			txtUpdate.Boolean_0 = false;
			btnSignUp.BackColor = System.Drawing.Color.Transparent;
			btnSignUp.Struct0_0 = new Struct0[0];
			btnSignUp.String_0 = "";
			btnSignUp.Font = new System.Drawing.Font("Verdana", 8f);
			btnSignUp.Image_0 = null;
			point2 = (btnSignUp.Location = new System.Drawing.Point(92, 402));
			padding2 = (btnSignUp.Margin = new System.Windows.Forms.Padding(4));
			btnSignUp.Name = "btnSignUp";
			btnSignUp.Boolean_0 = false;
			size2 = (btnSignUp.Size = new System.Drawing.Size(203, 28));
			btnSignUp.TabIndex = 34;
			btnSignUp.Text = "REGISTER";
			btnSignUp.Boolean_1 = true;
			PictureBox1.BackColor = System.Drawing.Color.Transparent;
			PictureBox1.Image = UnknownCrypter.My.Resources.Resources.Bitmap_2;
			point2 = (PictureBox1.Location = new System.Drawing.Point(161, 110));
			padding2 = (PictureBox1.Margin = new System.Windows.Forms.Padding(4));
			PictureBox1.Name = "PictureBox1";
			size2 = (PictureBox1.Size = new System.Drawing.Size(133, 123));
			PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			PictureBox1.TabIndex = 30;
			PictureBox1.TabStop = false;
			btnForgot.AutoSize = true;
			btnForgot.BackColor = System.Drawing.Color.Transparent;
			btnForgot.Cursor = System.Windows.Forms.Cursors.Hand;
			btnForgot.Font = new System.Drawing.Font("Segoe UI", 9f, System.Drawing.FontStyle.Underline);
			btnForgot.ForeColor = System.Drawing.Color.WhiteSmoke;
			point2 = (btnForgot.Location = new System.Drawing.Point(324, 406));
			padding2 = (btnForgot.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0));
			btnForgot.Name = "btnForgot";
			size2 = (btnForgot.Size = new System.Drawing.Size(125, 20));
			btnForgot.TabIndex = 28;
			btnForgot.Text = "Forgot Password?";
			mnuAbout.AutoSize = true;
			mnuAbout.BackColor = System.Drawing.Color.Transparent;
			mnuAbout.Cursor = System.Windows.Forms.Cursors.Hand;
			mnuAbout.Font = new System.Drawing.Font("Segoe UI", 9f, System.Drawing.FontStyle.Underline);
			mnuAbout.ForeColor = System.Drawing.Color.WhiteSmoke;
			point2 = (mnuAbout.Location = new System.Drawing.Point(16, 406));
			padding2 = (mnuAbout.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0));
			mnuAbout.Name = "mnuAbout";
			size2 = (mnuAbout.Size = new System.Drawing.Size(50, 20));
			mnuAbout.TabIndex = 27;
			mnuAbout.Text = "About";
			BoosterControlpanel1.BackColor = System.Drawing.Color.Transparent;
			BoosterControlpanel1.FormBorderStyle_0 = System.Windows.Forms.FormBorderStyle.None;
			BoosterControlpanel1.Struct0_0 = new Struct0[0];
			BoosterControlpanel1.Controls.Add(chkRemember);
			BoosterControlpanel1.Controls.Add(btnLogin);
			BoosterControlpanel1.Controls.Add(EightBallLabel4);
			BoosterControlpanel1.Controls.Add(EightBallLabel3);
			BoosterControlpanel1.Controls.Add(txtPassword);
			BoosterControlpanel1.Controls.Add(txtUsername);
			BoosterControlpanel1.String_0 = "";
			BoosterControlpanel1.Font = new System.Drawing.Font("Verdana", 8f);
			BoosterControlpanel1.Image_0 = null;
			point2 = (BoosterControlpanel1.Location = new System.Drawing.Point(16, 235));
			padding2 = (BoosterControlpanel1.Margin = new System.Windows.Forms.Padding(4));
			BoosterControlpanel1.Boolean_1 = true;
			BoosterControlpanel1.Name = "BoosterControlpanel1";
			BoosterControlpanel1.Boolean_3 = false;
			BoosterControlpanel1.Boolean_2 = true;
			size2 = (BoosterControlpanel1.Size = new System.Drawing.Size(441, 162));
			BoosterControlpanel1.Boolean_0 = true;
			BoosterControlpanel1.FormStartPosition_0 = System.Windows.Forms.FormStartPosition.Manual;
			BoosterControlpanel1.TabIndex = 25;
			BoosterControlpanel1.Text = "User Login";
			BoosterControlpanel1.Color_0 = System.Drawing.Color.Empty;
			BoosterControlpanel1.Boolean_4 = true;
			chkRemember.BackColor = System.Drawing.Color.Transparent;
			chkRemember.Boolean_4 = false;
			chkRemember.Struct0_0 = new Struct0[0];
			chkRemember.String_0 = "";
			chkRemember.Font = new System.Drawing.Font("Verdana", 8f);
			chkRemember.Image_0 = null;
			point2 = (chkRemember.Location = new System.Drawing.Point(27, 129));
			padding2 = (chkRemember.Margin = new System.Windows.Forms.Padding(4));
			chkRemember.Name = "chkRemember";
			chkRemember.Boolean_0 = false;
			size2 = (chkRemember.Size = new System.Drawing.Size(168, 15));
			chkRemember.TabIndex = 5;
			chkRemember.Text = "Remember Login";
			chkRemember.Boolean_1 = true;
			btnLogin.BackColor = System.Drawing.Color.Transparent;
			btnLogin.Struct0_0 = new Struct0[0];
			btnLogin.String_0 = "";
			btnLogin.Font = new System.Drawing.Font("Verdana", 8f);
			btnLogin.Image_0 = null;
			point2 = (btnLogin.Location = new System.Drawing.Point(247, 122));
			padding2 = (btnLogin.Margin = new System.Windows.Forms.Padding(4));
			btnLogin.Name = "btnLogin";
			btnLogin.Boolean_0 = false;
			size2 = (btnLogin.Size = new System.Drawing.Size(171, 28));
			btnLogin.TabIndex = 4;
			btnLogin.Text = "Login";
			btnLogin.Boolean_1 = true;
			EightBallLabel4.AutoSize = true;
			EightBallLabel4.BackColor = System.Drawing.Color.Transparent;
			EightBallLabel4.Font = new System.Drawing.Font("Segoe UI", 9f);
			EightBallLabel4.ForeColor = System.Drawing.Color.WhiteSmoke;
			point2 = (EightBallLabel4.Location = new System.Drawing.Point(23, 87));
			padding2 = (EightBallLabel4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0));
			EightBallLabel4.Name = "EightBallLabel4";
			size2 = (EightBallLabel4.Size = new System.Drawing.Size(102, 20));
			EightBallLabel4.TabIndex = 3;
			EightBallLabel4.Text = "PIN/Password:";
			EightBallLabel3.AutoSize = true;
			EightBallLabel3.BackColor = System.Drawing.Color.Transparent;
			EightBallLabel3.Font = new System.Drawing.Font("Segoe UI", 9f);
			EightBallLabel3.ForeColor = System.Drawing.Color.WhiteSmoke;
			point2 = (EightBallLabel3.Location = new System.Drawing.Point(23, 53));
			padding2 = (EightBallLabel3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0));
			EightBallLabel3.Name = "EightBallLabel3";
			size2 = (EightBallLabel3.Size = new System.Drawing.Size(79, 20));
			EightBallLabel3.TabIndex = 2;
			EightBallLabel3.Text = "License ID:";
			txtPassword.BackColor = System.Drawing.Color.FromArgb(36, 40, 42);
			txtPassword.ForeColor = System.Drawing.Color.FromArgb(142, 152, 156);
			point2 = (txtPassword.Location = new System.Drawing.Point(143, 82));
			padding2 = (txtPassword.Margin = new System.Windows.Forms.Padding(4));
			txtPassword.Int32_0 = 32767;
			txtPassword.Name = "txtPassword";
			size2 = (txtPassword.Size = new System.Drawing.Size(275, 28));
			txtPassword.TabIndex = 1;
			txtPassword.HorizontalAlignment_0 = System.Windows.Forms.HorizontalAlignment.Left;
			txtPassword.Boolean_0 = true;
			txtUsername.BackColor = System.Drawing.Color.FromArgb(36, 40, 42);
			txtUsername.ForeColor = System.Drawing.Color.FromArgb(142, 152, 156);
			point2 = (txtUsername.Location = new System.Drawing.Point(143, 46));
			padding2 = (txtUsername.Margin = new System.Windows.Forms.Padding(4));
			txtUsername.Int32_0 = 32767;
			txtUsername.Name = "txtUsername";
			size2 = (txtUsername.Size = new System.Drawing.Size(275, 28));
			txtUsername.TabIndex = 0;
			txtUsername.HorizontalAlignment_0 = System.Windows.Forms.HorizontalAlignment.Left;
			txtUsername.Boolean_0 = false;
			EightBallLabel2.AutoSize = true;
			EightBallLabel2.BackColor = System.Drawing.Color.Transparent;
			EightBallLabel2.Font = new System.Drawing.Font("Sitka Banner", 9f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			EightBallLabel2.ForeColor = System.Drawing.Color.WhiteSmoke;
			point2 = (EightBallLabel2.Location = new System.Drawing.Point(155, 85));
			padding2 = (EightBallLabel2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0));
			EightBallLabel2.Name = "EightBallLabel2";
			size2 = (EightBallLabel2.Size = new System.Drawing.Size(157, 21));
			EightBallLabel2.TabIndex = 24;
			EightBallLabel2.Text = "Best Java and JS Crypter";
			EightBallLabel1.AutoSize = true;
			EightBallLabel1.BackColor = System.Drawing.Color.Transparent;
			EightBallLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			EightBallLabel1.ForeColor = System.Drawing.Color.WhiteSmoke;
			point2 = (EightBallLabel1.Location = new System.Drawing.Point(40, 37));
			padding2 = (EightBallLabel1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0));
			EightBallLabel1.Name = "EightBallLabel1";
			size2 = (EightBallLabel1.Size = new System.Drawing.Size(326, 42));
			EightBallLabel1.TabIndex = 22;
			EightBallLabel1.Text = "UnKnown Krypter";
			System.Drawing.SizeF sizeF2 = (AutoScaleDimensions = new System.Drawing.SizeF(8f, 16f));
			AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.Black;
			size2 = (ClientSize = new System.Drawing.Size(473, 481));
			Controls.Add(BlackShadesNetForm1);
			FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
			padding2 = (Margin = new System.Windows.Forms.Padding(4));
			Name = "Form1";
			StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			Text = "UnKnown Crypter v2.0";
			TransparencyKey = System.Drawing.Color.Fuchsia;
			BlackShadesNetForm1.ResumeLayout(false);
			BlackShadesNetForm1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)PictureBox1).EndInit();
			BoosterControlpanel1.ResumeLayout(false);
			BoosterControlpanel1.PerformLayout();
			ResumeLayout(false);
		}

		private void mnuAbout_Click(object sender, EventArgs e)
		{
			MessageBox.Show("UnKnown Crypter v2.0\r\nBest Java and JS Crypter\r\nSupport: support@unknowncrypter.co", "About", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}

		private void method_0()
		{
			try
			{
				WebClient webClient = new WebClient();
				string text = webClient.DownloadString("http://kingmummylive.com/version.txt");
				string_5 = webClient.DownloadString("http://kingmummylive.com/channel.txt");
				if (text != null)
				{
					if (Operators.CompareString(text, string_3, TextCompare: false) != 0)
					{
						delegate2_0(text);
					}
					else
					{
						delegate2_0(null);
					}
				}
				else
				{
					delegate2_0(null);
				}
			}
			catch (Exception projectError)
			{
				ProjectData.SetProjectError(projectError);
				ProjectData.ClearProjectError();
			}
		}

		private void method_1(string string_6)
		{
			if (InvokeRequired)
			{
				Invoke(new Delegate2(method_1), string_6);
				return;
			}
			if (string_6 != null)
			{
				DialogResult dialogResult = MessageBox.Show("UnknownCrypter v" + string_6 + " is available for download.\r\nDo you want to download and install update now?", "Update Available", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
				if (dialogResult == DialogResult.Yes)
				{
					string_4 = string_6;
					WindowState = FormWindowState.Minimized;
					ShowInTaskbar = false;
					Class1.MyForms_0.Form2_0.Show();
				}
			}
			txtUpdate.Text = string_5;
		}

		private void method_2(object object_0)
		{
			method_4();
		}

		private string method_3()
		{
			ProcessStartInfo processStartInfo = new ProcessStartInfo("cmd", "/c wmic csproduct get UUID");
			processStartInfo.RedirectStandardOutput = true;
			processStartInfo.UseShellExecute = false;
			processStartInfo.CreateNoWindow = true;
			Process process = new Process();
			process.StartInfo = processStartInfo;
			process.Start();
			return process.StandardOutput.ReadToEnd().Replace("UUID", string.Empty).Trim()
				.ToUpper();
		}

		private void method_4()
		{
			try
			{
				Class1.Class0_0.Registry.CurrentUser.CreateSubKey("SOFTWARE\\unknownCrypter");
				if (chkRemember.Boolean_4)
				{
					string value = txtUsername.Text.Trim();
					string value2 = txtPassword.Text.Trim();
					Class1.Class0_0.Registry.CurrentUser.OpenSubKey("SOFTWARE\\unknownCrypter", writable: true).SetValue("user", value);
					Class1.Class0_0.Registry.CurrentUser.OpenSubKey("SOFTWARE\\unknownCrypter", writable: true).SetValue("pass", value2);
				}
				else
				{
					Class1.Class0_0.Registry.CurrentUser.DeleteSubKey("SOFTWARE\\unknownCrypter");
				}
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				MessageBox.Show(ex2.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				ProjectData.ClearProjectError();
			}
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			if (File.Exists("update.bat"))
			{
				File.Delete("update.bat");
			}
			Class1.Class0_0.Registry.CurrentUser.CreateSubKey("SOFTWARE\\unknownCrypter");
			string text = Conversions.ToString(Class1.Class0_0.Registry.CurrentUser.OpenSubKey("SOFTWARE\\unknownCrypter").GetValue("user"));
			string text2 = Conversions.ToString(Class1.Class0_0.Registry.CurrentUser.OpenSubKey("SOFTWARE\\unknownCrypter").GetValue("pass"));
			if (text != null && text2 != null)
			{
				txtUsername.Text = text;
				txtPassword.Text = text2;
				chkRemember.Boolean_4 = true;
			}
			try
			{
				ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
			}
			catch (Exception projectError)
			{
				ProjectData.SetProjectError(projectError);
				ProjectData.ClearProjectError();
			}
			delegate2_0 = method_1;
			delegate2_1 = method_5;
			Thread thread = new Thread(method_0);
			thread.Start();
		}

		private void Timer_0_Tick(object sender, EventArgs e)
		{
			try
			{
				Process[] processes = Process.GetProcesses();
				Process[] array = processes;
				int num = 0;
				while (true)
				{
					if (num < array.Length)
					{
						Process process = array[num];
						if (process.MainWindowTitle.ToLower().Contains("wireshark") | process.MainWindowTitle.ToLower().Contains("pcap"))
						{
							break;
						}
						num = checked(num + 1);
						continue;
					}
					return;
				}
				Application.Exit();
			}
			catch (Exception projectError)
			{
				ProjectData.SetProjectError(projectError);
				ProjectData.ClearProjectError();
			}
		}

		private void method_5(string string_6)
		{
			if (InvokeRequired)
			{
				Invoke(new Delegate2(method_5), string_6);
				return;
			}
			Class1.MyForms_0.Loading_0.Close();
			checked
			{
				if (string_6.StartsWith("200 ") & string_6.Contains("<>"))
				{
					string text = string_6.Substring(0, string_6.IndexOf("<>"));
					string[] array = text.Split(' ');
					if (Conversions.ToDouble(array[1]) == 0.0)
					{
						Form3.bool_0 = false;
					}
					else if (Conversions.ToDouble(array[1]) == 1.0)
					{
						Form3.bool_0 = true;
					}
					string_2 = string_6.Substring(string_6.IndexOf("<>") + 2);
					string text2 = "";
					if (string_2.Contains("<>"))
					{
						text2 = string_2.Substring(string_2.IndexOf("<>") + 2);
						string_2 = string_2.Substring(0, string_2.IndexOf("<>"));
						if (text2.Contains("You are a Private Stub User"))
						{
							bool_0 = true;
						}
					}
					WindowState = FormWindowState.Minimized;
					ShowInTaskbar = false;
					Class1.MyForms_0.Form3_0.Show();
					Class1.MyForms_0.Form3_0.TopMost = true;
					MessageBox.Show(text2, "Login successful", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					Class1.MyForms_0.Form3_0.TopMost = false;
				}
				else
				{
					MessageBox.Show(string_6);
				}
			}
		}

		private void method_6()
		{
			try
			{
				WebClient webClient = new WebClient();
				string msg = webClient.DownloadString("http://kingmummylive.com/server/?u=" + string_0 + "&p=" + string_1 + "&hwid=" + method_3());
				delegate2_1(msg);
			}
			catch (Exception projectError)
			{
				ProjectData.SetProjectError(projectError);
				delegate2_1("Could not connect to server. Please check internet connection");
				ProjectData.ClearProjectError();
			}
		}

		private void btnLogin_Click(object sender, EventArgs e)
		{
			if (chkRemember.Boolean_4)
			{
				method_4();
			}
			Class1.MyForms_0.Loading_0.Show();
			string_0 = txtUsername.Text.Trim();
			string_1 = txtPassword.Text.Trim();
			Thread thread = new Thread(method_6);
			thread.Start();
		}

		private void btnForgot_Click(object sender, EventArgs e)
		{
		}

		private void btnSignUp_Click(object sender, EventArgs e)
		{
			Class1.MyForms_0.Dialog1_0.ShowDialog();
		}
	}
}
