public enum GEnum0 : byte
{
	None,
	Over,
	Down
}
