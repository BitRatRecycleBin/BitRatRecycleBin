using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

internal class Control23 : Control12
{
	private Label label_0;

	protected override void ColorHook()
	{
	}

	public Control23()
	{
		label_0 = new Label();
		SetStyle(ControlStyles.SupportsTransparentBackColor, value: true);
		Size size2 = (Size = new Size(20, 20));
	}

	protected override void PaintHook()
	{
		graphics_0.SmoothingMode = SmoothingMode.HighQuality;
		graphics_0.Clear(Color.White);
		Graphics graphics = graphics_0;
		SolidBrush brush = new SolidBrush(Color.FromArgb(239, 239, 239));
		checked
		{
			Rectangle rect = new Rectangle(-1, -1, Width + 1, Height + 1);
			graphics.FillRectangle(brush, rect);
			switch (enum1_0)
			{
			case Enum1.None:
			{
				graphics_0.SmoothingMode = SmoothingMode.HighQuality;
				GraphicsPath graphicsPath3 = new GraphicsPath();
				rect = new Rectangle(Width - 20, Height - 19, 15, 15);
				graphicsPath3.AddEllipse(rect);
				PathGradientBrush pathGradientBrush3 = new PathGradientBrush(graphicsPath3);
				Point point = new Point((int)Math.Round((double)Height - 18.5), Height - 20);
				pathGradientBrush3.CenterPoint = point;
				pathGradientBrush3.CenterColor = Color.FromArgb(193, 26, 26);
				pathGradientBrush3.SurroundColors = new Color[1] { Color.FromArgb(229, 110, 110) };
				PointF pointF2 = (pathGradientBrush3.FocusScales = new PointF(0.6f, 0.6f));
				graphics_0.FillPath(pathGradientBrush3, graphicsPath3);
				graphics_0.DrawPath(new Pen(Color.FromArgb(159, 41, 41)), graphicsPath3);
				graphics_0.SetClip(graphicsPath3);
				Graphics graphics4 = graphics_0;
				SolidBrush brush4 = new SolidBrush(Color.FromArgb(40, Color.WhiteSmoke));
				rect = new Rectangle(Width - 20, Height - 18, 6, 6);
				graphics4.FillEllipse(brush4, rect);
				graphics_0.ResetClip();
				break;
			}
			case Enum1.Over:
			{
				graphics_0.SmoothingMode = SmoothingMode.HighQuality;
				GraphicsPath graphicsPath2 = new GraphicsPath();
				rect = new Rectangle(Width - 20, Height - 19, 15, 15);
				graphicsPath2.AddEllipse(rect);
				PathGradientBrush pathGradientBrush2 = new PathGradientBrush(graphicsPath2);
				Point point = new Point((int)Math.Round((double)Height - 18.5), Height - 20);
				pathGradientBrush2.CenterPoint = point;
				pathGradientBrush2.CenterColor = Color.FromArgb(221, 32, 32);
				pathGradientBrush2.SurroundColors = new Color[1] { Color.FromArgb(229, 110, 110) };
				PointF pointF2 = (pathGradientBrush2.FocusScales = new PointF(0.6f, 0.6f));
				graphics_0.FillPath(pathGradientBrush2, graphicsPath2);
				graphics_0.DrawPath(new Pen(Color.FromArgb(159, 41, 41)), graphicsPath2);
				graphics_0.SetClip(graphicsPath2);
				Graphics graphics3 = graphics_0;
				SolidBrush brush3 = new SolidBrush(Color.FromArgb(40, Color.WhiteSmoke));
				rect = new Rectangle(Width - 20, Height - 18, 6, 6);
				graphics3.FillEllipse(brush3, rect);
				graphics_0.ResetClip();
				break;
			}
			case Enum1.Down:
			{
				graphics_0.SmoothingMode = SmoothingMode.HighQuality;
				GraphicsPath graphicsPath = new GraphicsPath();
				rect = new Rectangle(Width - 20, Height - 19, 15, 15);
				graphicsPath.AddEllipse(rect);
				PathGradientBrush pathGradientBrush = new PathGradientBrush(graphicsPath);
				Point point = new Point((int)Math.Round((double)Height - 18.5), Height - 20);
				pathGradientBrush.CenterPoint = point;
				pathGradientBrush.CenterColor = Color.FromArgb(221, 32, 32);
				pathGradientBrush.SurroundColors = new Color[1] { Color.FromArgb(229, 110, 110) };
				PointF pointF2 = (pathGradientBrush.FocusScales = new PointF(0.6f, 0.6f));
				graphics_0.FillPath(pathGradientBrush, graphicsPath);
				graphics_0.DrawPath(new Pen(Color.White), graphicsPath);
				graphics_0.SetClip(graphicsPath);
				Graphics graphics2 = graphics_0;
				SolidBrush brush2 = new SolidBrush(Color.FromArgb(40, Color.WhiteSmoke));
				rect = new Rectangle(Width - 20, Height - 18, 6, 6);
				graphics2.FillEllipse(brush2, rect);
				graphics_0.ResetClip();
				break;
			}
			}
		}
	}
}
