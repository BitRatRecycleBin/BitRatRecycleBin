using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

public class GControl10 : Control
{
	public enum GEnum2 : byte
	{
		Left,
		Center,
		Right
	}

	private static List<WeakReference> list_0 = new List<WeakReference>();

	private GEnum0 genum0_0;

	private GEnum2 genum2_0;

	public GEnum2 GEnum2_0
	{
		get
		{
			return genum2_0;
		}
		set
		{
			genum2_0 = value;
			Invalidate();
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	public GControl10()
	{
		smethod_0(this);
		genum0_0 = GEnum0.None;
		genum2_0 = GEnum2.Center;
		SetStyle(ControlStyles.AllPaintingInWmPaint, value: true);
		SetStyle(ControlStyles.OptimizedDoubleBuffer, value: true);
		SetStyle(ControlStyles.SupportsTransparentBackColor, value: true);
		DoubleBuffered = true;
		BackColor = Color.Transparent;
		Font = new Font("Arial", 8.25f, FontStyle.Bold);
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		int num = 13;
		Bitmap bitmap = new Bitmap(Width, Height);
		Graphics graphics = Graphics.FromImage(bitmap);
		graphics.SmoothingMode = SmoothingMode.HighQuality;
		graphics.TextRenderingHint = TextRenderingHint.AntiAlias;
		base.OnPaint(e);
		checked
		{
			if (Enabled)
			{
				graphics.Clear(BackColor);
				Rectangle rect;
				switch (genum0_0)
				{
				case GEnum0.None:
				{
					rect = new Rectangle(0, 0, Width - 1, Height - 1);
					LinearGradientBrush brush5 = new LinearGradientBrush(rect, Color.FromArgb(131, 198, 240), Color.FromArgb(24, 121, 218), 90f);
					rect = new Rectangle(0, 0, Width - 1, Height - 1);
					graphics.FillPath(brush5, Class19.smethod_0(rect, num));
					rect = new Rectangle(0, 0, Width - 1, Height - 1);
					LinearGradientBrush brush6 = new LinearGradientBrush(rect, Color.FromArgb(145, 212, 254), Color.Transparent, 90f);
					Pen pen3 = new Pen(brush6);
					rect = new Rectangle(0, 1, Width - 1, Height - 2);
					graphics.DrawPath(pen3, Class19.smethod_0(rect, num + 1));
					break;
				}
				case GEnum0.Over:
				{
					rect = new Rectangle(0, 0, Width - 1, Height - 1);
					LinearGradientBrush brush3 = new LinearGradientBrush(rect, Color.FromArgb(150, 203, 235), Color.FromArgb(35, 135, 220), 90f);
					rect = new Rectangle(0, 0, Width - 1, Height - 1);
					graphics.FillPath(brush3, Class19.smethod_0(rect, num));
					rect = new Rectangle(1, 1, Width - 3, Height - 3);
					LinearGradientBrush brush4 = new LinearGradientBrush(rect, Color.FromArgb(173, 226, 255), Color.FromArgb(54, 155, 235), 90f);
					Pen pen2 = new Pen(brush4);
					rect = new Rectangle(1, 1, Width - 3, Height - 3);
					graphics.DrawPath(pen2, Class19.smethod_0(rect, num));
					break;
				}
				case GEnum0.Down:
				{
					rect = new Rectangle(0, 0, Width - 1, Height - 1);
					LinearGradientBrush brush = new LinearGradientBrush(rect, Color.FromArgb(30, 121, 210), Color.FromArgb(84, 172, 236), 90f);
					rect = new Rectangle(0, 0, Width - 1, Height - 1);
					graphics.FillPath(brush, Class19.smethod_0(rect, num));
					rect = new Rectangle(0, 0, Width - 1, Height - 1);
					LinearGradientBrush brush2 = new LinearGradientBrush(rect, Color.FromArgb(54, 145, 234), Color.Transparent, 90f);
					Pen pen = new Pen(brush2);
					rect = new Rectangle(0, 1, Width - 1, Height - 1);
					graphics.DrawPath(pen, Class19.smethod_0(rect, num + 1));
					break;
				}
				}
				Pen pen4 = new Pen(Color.FromArgb(21, 38, 56));
				rect = new Rectangle(0, 0, Width - 1, Height - 1);
				graphics.DrawPath(pen4, Class19.smethod_0(rect, num));
				SolidBrush brush7 = new SolidBrush(Parent.BackColor);
				rect = new Rectangle(-1, -1, 2, 10);
				graphics.FillRectangle(brush7, rect);
				SolidBrush brush8 = new SolidBrush(Parent.BackColor);
				rect = new Rectangle(-2, -1, 4, 9);
				graphics.FillRectangle(brush8, rect);
			}
			StringFormat stringFormat = new StringFormat();
			switch (GEnum2_0)
			{
			case GEnum2.Left:
			{
				stringFormat.Alignment = StringAlignment.Near;
				stringFormat.LineAlignment = StringAlignment.Center;
				string s5 = Text;
				Font font5 = Font;
				SolidBrush brush11 = new SolidBrush(Color.FromArgb(16, 20, 21));
				Rectangle rect = new Rectangle(6, 2, Width - 1, Height - 1);
				graphics.DrawString(s5, font5, brush11, rect, stringFormat);
				string s6 = Text;
				Font font6 = Font;
				Brush white3 = Brushes.White;
				rect = new Rectangle(5, 1, Width - 1, Height - 1);
				graphics.DrawString(s6, font6, white3, rect, stringFormat);
				break;
			}
			case GEnum2.Center:
			{
				stringFormat.Alignment = StringAlignment.Center;
				stringFormat.LineAlignment = StringAlignment.Center;
				string s3 = Text;
				Font font3 = Font;
				SolidBrush brush10 = new SolidBrush(Color.FromArgb(16, 20, 21));
				Rectangle rect = new Rectangle(1, 2, Width - 1, Height - 1);
				graphics.DrawString(s3, font3, brush10, rect, stringFormat);
				string s4 = Text;
				Font font4 = Font;
				Brush white2 = Brushes.White;
				rect = new Rectangle(0, 1, Width - 1, Height - 1);
				graphics.DrawString(s4, font4, white2, rect, stringFormat);
				break;
			}
			case GEnum2.Right:
			{
				stringFormat.Alignment = StringAlignment.Far;
				stringFormat.LineAlignment = StringAlignment.Center;
				string s = Text;
				Font font = Font;
				SolidBrush brush9 = new SolidBrush(Color.FromArgb(16, 20, 21));
				Rectangle rect = new Rectangle(-3, 2, Width - 1, Height - 1);
				graphics.DrawString(s, font, brush9, rect, stringFormat);
				string s2 = Text;
				Font font2 = Font;
				Brush white = Brushes.White;
				rect = new Rectangle(-4, 1, Width - 1, Height - 1);
				graphics.DrawString(s2, font2, white, rect, stringFormat);
				break;
			}
			}
			Graphics graphics2 = e.Graphics;
			Point point = new Point(0, 0);
			graphics2.DrawImage(bitmap, point);
			graphics.Dispose();
			bitmap.Dispose();
		}
	}

	protected override void OnMouseEnter(EventArgs e)
	{
		if (Enabled)
		{
			base.OnMouseEnter(e);
			genum0_0 = GEnum0.Over;
			Invalidate();
			Cursor = Cursors.Hand;
		}
	}

	protected override void OnMouseDown(MouseEventArgs e)
	{
		if (Enabled)
		{
			base.OnMouseDown(e);
			genum0_0 = GEnum0.Down;
			Invalidate();
			Cursor = Cursors.Hand;
		}
	}

	protected override void OnMouseUp(MouseEventArgs e)
	{
		if (Enabled)
		{
			base.OnMouseUp(e);
			genum0_0 = GEnum0.Over;
			Invalidate();
			Cursor = Cursors.Hand;
		}
	}

	protected override void OnMouseLeave(EventArgs e)
	{
		if (Enabled)
		{
			base.OnMouseLeave(e);
			genum0_0 = GEnum0.None;
			Invalidate();
			Cursor = Cursors.Default;
		}
	}

	protected override void OnTextChanged(EventArgs e)
	{
		base.OnTextChanged(e);
		Invalidate();
	}
}
