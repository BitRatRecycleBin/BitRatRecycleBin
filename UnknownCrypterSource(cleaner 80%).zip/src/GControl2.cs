using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

public class GControl2 : Control
{
	private static List<WeakReference> list_0 = new List<WeakReference>();

	private Enum2 enum2_0;

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	protected override void OnMouseEnter(EventArgs e)
	{
		base.OnMouseEnter(e);
		enum2_0 = Enum2.Over;
		Invalidate();
	}

	protected override void OnMouseDown(MouseEventArgs e)
	{
		base.OnMouseDown(e);
		enum2_0 = Enum2.Down;
		Invalidate();
	}

	protected override void OnMouseLeave(EventArgs e)
	{
		base.OnMouseLeave(e);
		enum2_0 = Enum2.None;
		Invalidate();
	}

	protected override void OnMouseUp(MouseEventArgs e)
	{
		base.OnMouseUp(e);
		enum2_0 = Enum2.Over;
		Invalidate();
	}

	protected override void OnPaintBackground(PaintEventArgs pevent)
	{
	}

	protected override void OnTextChanged(EventArgs e)
	{
		base.OnTextChanged(e);
		Invalidate();
	}

	public GControl2()
	{
		smethod_0(this);
		enum2_0 = Enum2.None;
		BackColor = Color.FromArgb(38, 38, 38);
		Font = new Font("Verdana", 8.25f);
		Size size2 = (Size = new Size(15, 11));
		DoubleBuffered = true;
		Focus();
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Bitmap bitmap = new Bitmap(Width, Height);
		Graphics graphics = Graphics.FromImage(bitmap);
		Class18 @class = new Class18();
		checked
		{
			Rectangle rectangle = new Rectangle(0, 0, Width - 1, Height - 1);
			Size size2 = (Size = new Size(15, 11));
			graphics.Clear(Color.FromArgb(49, 53, 55));
			switch (enum2_0)
			{
			case Enum2.None:
			{
				LinearGradientBrush brush5 = new LinearGradientBrush(rectangle, Color.FromArgb(200, 44, 47, 51), Color.FromArgb(80, 64, 69, 71), 90f);
				graphics.FillPath(brush5, @class.method_0(rectangle, 1));
				Rectangle rect = new Rectangle(2, 2, Width - 6, Height - 6);
				LinearGradientBrush brush6 = new LinearGradientBrush(rect, Color.FromArgb(90, 97, 101), Color.FromArgb(63, 69, 73), 90f);
				rect = new Rectangle(2, 2, Width - 6, Height - 6);
				graphics.FillPath(brush6, @class.method_0(rect, 1));
				Pen pen4 = new Pen(Color.FromArgb(30, 32, 35));
				rect = new Rectangle(2, 2, Width - 6, Height - 6);
				graphics.DrawPath(pen4, @class.method_0(rect, 1));
				break;
			}
			case Enum2.Over:
			{
				LinearGradientBrush brush3 = new LinearGradientBrush(rectangle, Color.FromArgb(200, 44, 47, 51), Color.FromArgb(80, 64, 69, 71), 90f);
				graphics.FillPath(brush3, @class.method_0(rectangle, 1));
				Rectangle rect = new Rectangle(2, 2, Width - 6, Height - 6);
				LinearGradientBrush brush4 = new LinearGradientBrush(rect, Color.FromArgb(90, 97, 101), Color.FromArgb(63, 69, 73), 90f);
				rect = new Rectangle(2, 2, Width - 6, Height - 6);
				graphics.FillPath(brush4, @class.method_0(rect, 1));
				Pen pen2 = new Pen(Color.FromArgb(30, 32, 35));
				rect = new Rectangle(2, 2, Width - 6, Height - 6);
				graphics.DrawPath(pen2, @class.method_0(rect, 1));
				Pen pen3 = new Pen(Color.FromArgb(200, 0, 186, 255));
				rect = new Rectangle(2, 2, Width - 6, Height - 6);
				graphics.DrawPath(pen3, @class.method_0(rect, 1));
				break;
			}
			case Enum2.Down:
			{
				LinearGradientBrush brush = new LinearGradientBrush(rectangle, Color.FromArgb(200, 44, 47, 51), Color.FromArgb(80, 64, 69, 71), 90f);
				graphics.FillPath(brush, @class.method_0(rectangle, 1));
				Rectangle rect = new Rectangle(2, 2, Width - 6, Height - 6);
				LinearGradientBrush brush2 = new LinearGradientBrush(rect, Color.FromArgb(90, 97, 101), Color.FromArgb(63, 69, 73), 135f);
				rect = new Rectangle(2, 2, Width - 6, Height - 6);
				graphics.FillPath(brush2, @class.method_0(rect, 1));
				Pen pen = new Pen(Color.FromArgb(30, 32, 35));
				rect = new Rectangle(2, 2, Width - 6, Height - 6);
				graphics.DrawPath(pen, @class.method_0(rect, 1));
				break;
			}
			}
			NewLateBinding.LateCall(e.Graphics, null, "DrawImage", new object[3]
			{
				RuntimeHelpers.GetObjectValue(bitmap.Clone()),
				0,
				0
			}, null, null, null, IgnoreReturn: true);
			graphics.Dispose();
			bitmap.Dispose();
		}
	}
}
