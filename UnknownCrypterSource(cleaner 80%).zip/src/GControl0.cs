using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

public class GControl0 : ContainerControl
{
	private static List<WeakReference> list_0 = new List<WeakReference>();

	private Point point_0;

	private bool bool_0;

	private int int_0;

	private int int_1;

	private bool bool_1;

	private bool bool_2;

	[AccessedThroughProperty("minimBtn")]
	private GControl2 gcontrol2_0;

	[AccessedThroughProperty("closeBtn")]
	private GControl2 gcontrol2_1;

	public bool Boolean_0
	{
		get
		{
			return bool_1;
		}
		set
		{
			bool_1 = value;
			Invalidate();
		}
	}

	public bool Boolean_1
	{
		get
		{
			return bool_2;
		}
		set
		{
			bool_2 = value;
			Invalidate();
		}
	}

	private virtual GControl2 GControl2_0
	{
		[DebuggerNonUserCode]
		get
		{
			return gcontrol2_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			EventHandler value2 = delegate
			{
				method_0();
			};
			if (gcontrol2_0 != null)
			{
				gcontrol2_0.Click -= value2;
			}
			gcontrol2_0 = value;
			if (gcontrol2_0 != null)
			{
				gcontrol2_0.Click += value2;
			}
		}
	}

	private virtual GControl2 GControl2_1
	{
		[DebuggerNonUserCode]
		get
		{
			return gcontrol2_1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			EventHandler value2 = delegate
			{
				method_1();
			};
			if (gcontrol2_1 != null)
			{
				gcontrol2_1.Click -= value2;
			}
			gcontrol2_1 = value;
			if (gcontrol2_1 != null)
			{
				gcontrol2_1.Click += value2;
			}
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	private void method_0()
	{
		ParentForm.FindForm().WindowState = FormWindowState.Minimized;
	}

	private void method_1()
	{
		if (Boolean_0)
		{
			Environment.Exit(0);
		}
		else
		{
			ParentForm.FindForm().Close();
		}
	}

	protected override void OnMouseDown(MouseEventArgs e)
	{
		base.OnMouseDown(e);
		bool num = e.Button == MouseButtons.Left;
		Rectangle rectangle = new Rectangle(0, 0, Width, int_0);
		Rectangle rectangle2 = rectangle;
		if (num & rectangle2.Contains(e.Location))
		{
			bool_0 = true;
			point_0 = e.Location;
		}
	}

	protected override void OnMouseUp(MouseEventArgs e)
	{
		base.OnMouseUp(e);
		bool_0 = false;
	}

	protected override void OnMouseMove(MouseEventArgs e)
	{
		base.OnMouseMove(e);
		if (bool_0)
		{
			Parent.Location = Control.MousePosition - (Size)point_0;
		}
	}

	protected override void OnInvalidated(InvalidateEventArgs e)
	{
		base.OnInvalidated(e);
		ParentForm.FindForm().Text = Text;
	}

	protected override void OnPaintBackground(PaintEventArgs e)
	{
	}

	protected override void OnTextChanged(EventArgs e)
	{
		base.OnTextChanged(e);
		Invalidate();
	}

	protected override void OnCreateControl()
	{
		base.OnCreateControl();
		ParentForm.FormBorderStyle = FormBorderStyle.None;
		ParentForm.TransparencyKey = Color.Fuchsia;
	}

	protected override void CreateHandle()
	{
		base.CreateHandle();
	}

	public GControl0()
	{
		smethod_0(this);
		ref Point reference = ref point_0;
		reference = new Point(0, 0);
		bool_0 = false;
		int_1 = 0;
		bool_1 = false;
		bool_2 = true;
		GControl2 gControl = new GControl2();
		checked
		{
			Point point2 = (gControl.Location = new Point(Width - 44, 7));
			GControl2_0 = gControl;
			gControl = new GControl2();
			point2 = (gControl.Location = new Point(Width - 27, 7));
			GControl2_1 = gControl;
			Dock = DockStyle.Fill;
			int_0 = 25;
			Font = new Font("Trebuchet MS", 8.25f, FontStyle.Bold);
			ForeColor = Color.FromArgb(142, 152, 156);
			DoubleBuffered = true;
			Controls.Add(GControl2_1);
			GControl2_1.Refresh();
			GControl2_0.Refresh();
		}
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Bitmap bitmap = new Bitmap(Width, Height);
		Graphics graphics = Graphics.FromImage(bitmap);
		if (bool_2)
		{
			Controls.Add(GControl2_0);
		}
		else
		{
			Controls.Remove(GControl2_0);
		}
		checked
		{
			Point point2 = (GControl2_0.Location = new Point(Width - 44, 7));
			point2 = (GControl2_1.Location = new Point(Width - 27, 7));
			graphics.SmoothingMode = SmoothingMode.Default;
			Rectangle rectangle_ = new Rectangle(0, 0, Width - 1, Height - 1);
			Color transparencyKey = ParentForm.TransparencyKey;
			Class18 @class = new Class18();
			base.OnPaint(e);
			graphics.Clear(transparencyKey);
			graphics.FillPath(new SolidBrush(Color.FromArgb(42, 47, 49)), @class.method_0(rectangle_, 7));
			Rectangle rect = new Rectangle(1, 1, (int)Math.Round((double)Width / 2.0 - 1.0), Height - 3);
			LinearGradientBrush brush = new LinearGradientBrush(rect, Color.FromArgb(102, 108, 112), Color.FromArgb(204, 216, 224), 0f);
			rect = new Rectangle(1, 1, (int)Math.Round((double)Width / 2.0 - 1.0), Height - 3);
			LinearGradientBrush brush2 = new LinearGradientBrush(rect, Color.FromArgb(204, 216, 224), Color.FromArgb(102, 108, 112), 0f);
			Pen pen = new Pen(brush);
			rect = new Rectangle(1, 1, (int)Math.Round((double)Width / 2.0 + 3.0), Height - 3);
			graphics.DrawPath(pen, @class.method_0(rect, 7));
			Pen pen2 = new Pen(brush2);
			rect = new Rectangle((int)Math.Round((double)Width / 2.0 - 5.0), 1, (int)Math.Round((double)Width / 2.0 + 3.0), Height - 3);
			graphics.DrawPath(pen2, @class.method_0(rect, 7));
			SolidBrush brush3 = new SolidBrush(Color.FromArgb(42, 47, 49));
			rect = new Rectangle(2, 2, Width - 5, Height - 5);
			graphics.FillPath(brush3, @class.method_0(rect, 7));
			rect = new Rectangle(0, 0, Width - 1, 25);
			LinearGradientBrush brush4 = new LinearGradientBrush(rect, Color.FromArgb(42, 46, 48), Color.FromArgb(93, 98, 101), 0f);
			rect = new Rectangle(0, 0, Width - 1, 25);
			LinearGradientBrush brush5 = new LinearGradientBrush(rect, Color.FromArgb(93, 98, 101), Color.FromArgb(42, 46, 48), 0f);
			rect = new Rectangle(2, 2, (int)Math.Round((double)Width / 2.0 + 2.0), 25);
			graphics.FillPath(brush4, @class.method_0(rect, 7));
			rect = new Rectangle((int)Math.Round((double)Width / 2.0 - 3.0), 2, (int)Math.Round((double)Width / 2.0 - 1.0), 25);
			graphics.FillPath(brush5, @class.method_0(rect, 7));
			SolidBrush brush6 = new SolidBrush(Color.FromArgb(42, 47, 49));
			rect = new Rectangle(2, 23, Width - 5, 10);
			graphics.FillRectangle(brush6, rect);
			Pen pen3 = new Pen(Color.FromArgb(42, 46, 48));
			rect = new Rectangle(2, 2, Width - 5, Height - 5);
			graphics.DrawPath(pen3, @class.method_0(rect, 7));
			graphics.DrawPath(new Pen(Color.FromArgb(9, 11, 12)), @class.method_0(rectangle_, 7));
			string s = Text;
			Font font = Font;
			Brush white = Brushes.White;
			rect = new Rectangle(7, 5, Width - 1, 22);
			graphics.DrawString(s, font, white, rect, new StringFormat
			{
				Alignment = StringAlignment.Near,
				LineAlignment = StringAlignment.Near
			});
			NewLateBinding.LateCall(e.Graphics, null, "DrawImage", new object[3]
			{
				RuntimeHelpers.GetObjectValue(bitmap.Clone()),
				0,
				0
			}, null, null, null, IgnoreReturn: true);
			graphics.Dispose();
			bitmap.Dispose();
		}
	}

	[SpecialName]
	[CompilerGenerated]
	[DebuggerStepThrough]
	private void GControl2_0_Click(object sender, EventArgs e)
	{
		method_0();
	}

	[SpecialName]
	[CompilerGenerated]
	[DebuggerStepThrough]
	private void GControl2_1_Click(object sender, EventArgs e)
	{
		method_1();
	}
}
