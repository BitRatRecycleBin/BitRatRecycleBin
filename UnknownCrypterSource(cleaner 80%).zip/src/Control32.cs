using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

internal class Control32 : ContainerControl
{
	private static List<WeakReference> list_0 = new List<WeakReference>();

	private bool bool_0;

	private string string_0;

	private string string_1;

	private Font font_0;

	private Font font_1;

	private GraphicsPath graphicsPath_0;

	private GraphicsPath graphicsPath_1;

	private PointF pointF_0;

	private SizeF sizeF_0;

	private SizeF sizeF_1;

	public bool Boolean_0
	{
		get
		{
			return bool_0;
		}
		set
		{
			bool_0 = value;
			Invalidate();
		}
	}

	public string String_0
	{
		get
		{
			return string_0;
		}
		set
		{
			string_0 = value;
			Invalidate();
		}
	}

	public string String_1
	{
		get
		{
			return string_1;
		}
		set
		{
			string_1 = value;
			Invalidate();
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	public Control32()
	{
		smethod_0(this);
		string_0 = "GroupBox";
		string_1 = "Details";
		SetStyle(ControlStyles.UserPaint | ControlStyles.Opaque | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		SetStyle(ControlStyles.Selectable, value: false);
		font_0 = new Font("Verdana", 10f);
		font_1 = new Font("Verdana", 6.5f);
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Graphics graphics = e.Graphics;
		graphics = e.Graphics;
		graphics.Clear(Color.White);
		graphics.SmoothingMode = SmoothingMode.AntiAlias;
		checked
		{
			Rectangle rectangle_ = new Rectangle(0, 0, Width - 1, Height - 1);
			graphicsPath_0 = method_0(rectangle_, 7);
			rectangle_ = new Rectangle(1, 1, Width - 3, Height - 3);
			graphicsPath_1 = method_0(rectangle_, 7);
			graphics.FillPath(new SolidBrush(Color.FromArgb(250, 250, 250)), graphicsPath_1);
			graphics.SetClip(graphicsPath_1);
			PathGradientBrush pathGradientBrush = new PathGradientBrush(graphicsPath_1);
			pathGradientBrush.CenterColor = Color.FromArgb(255, 255, 255);
			pathGradientBrush.SurroundColors = new Color[1] { Color.FromArgb(250, 250, 250) };
			PointF pointF2 = (pathGradientBrush.FocusScales = new PointF(0.95f, 0.95f));
			graphics.FillPath(pathGradientBrush, graphicsPath_1);
			graphics.ResetClip();
			graphics.DrawPath(new Pen(new SolidBrush(Color.FromArgb(70, Color.LightGray))), graphicsPath_0);
			graphics.DrawPath(Pens.Gray, graphicsPath_1);
			sizeF_0 = graphics.MeasureString(string_0, font_0, Width, StringFormat.GenericTypographic);
			sizeF_1 = graphics.MeasureString(string_1, font_1, Width, StringFormat.GenericTypographic);
			graphics.DrawString(string_0, font_0, new SolidBrush(Color.FromArgb(1, 75, 124)), 5f, 5f);
			ref PointF reference = ref pointF_0;
			reference = new PointF(6f, sizeF_0.Height + 4f);
			graphics.DrawString(string_1, font_1, new SolidBrush(Color.Black), pointF_0.X, pointF_0.Y);
		}
	}

	public GraphicsPath method_0(Rectangle rectangle_0, int int_0)
	{
		GraphicsPath graphicsPath = new GraphicsPath();
		checked
		{
			int num = int_0 * 2;
			Rectangle rect = new Rectangle(rectangle_0.X, rectangle_0.Y, num, num);
			graphicsPath.AddArc(rect, -180f, 90f);
			rect = new Rectangle(rectangle_0.Width - num + rectangle_0.X, rectangle_0.Y, num, num);
			graphicsPath.AddArc(rect, -90f, 90f);
			rect = new Rectangle(rectangle_0.Width - num + rectangle_0.X, rectangle_0.Height - num + rectangle_0.Y, num, num);
			graphicsPath.AddArc(rect, 0f, 90f);
			rect = new Rectangle(rectangle_0.X, rectangle_0.Height - num + rectangle_0.Y, num, num);
			graphicsPath.AddArc(rect, 90f, 90f);
			Point pt = new Point(rectangle_0.X, rectangle_0.Height - num + rectangle_0.Y);
			Point pt2 = new Point(rectangle_0.X, int_0 + rectangle_0.Y);
			graphicsPath.AddLine(pt, pt2);
			return graphicsPath;
		}
	}
}
