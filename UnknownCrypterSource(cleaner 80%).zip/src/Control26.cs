using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

[DefaultEvent("CheckedChanged")]
internal class Control26 : Control
{
	public delegate void Delegate8(object sender);

	private static List<WeakReference> list_0 = new List<WeakReference>();

	private Delegate8 delegate8_0;

	private bool bool_0;

	private GraphicsPath graphicsPath_0;

	private SizeF sizeF_0;

	private PointF pointF_0;

	private Pen pen_0;

	private Pen pen_1;

	private PathGradientBrush pathGradientBrush_0;

	public bool Boolean_0
	{
		get
		{
			return bool_0;
		}
		set
		{
			bool_0 = value;
			if (bool_0)
			{
				method_0();
			}
			delegate8_0?.Invoke(this);
			Invalidate();
		}
	}

	public event Delegate8 Event_0
	{
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		add
		{
			delegate8_0 = (Delegate8)Delegate.Combine(delegate8_0, value);
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		remove
		{
			delegate8_0 = (Delegate8)Delegate.Remove(delegate8_0, value);
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	public Control26()
	{
		smethod_0(this);
		SetStyle(ControlStyles.UserPaint | ControlStyles.Opaque | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		SetStyle(ControlStyles.Selectable, value: false);
		SetStyle(ControlStyles.SupportsTransparentBackColor, value: true);
		BackColor = Color.White;
		pen_0 = new Pen(Color.FromArgb(55, 55, 55));
		pen_1 = new Pen(Brushes.Red);
	}

	private void method_0()
	{
		if (Parent == null)
		{
			return;
		}
		IEnumerator enumerator = default(IEnumerator);
		try
		{
			enumerator = Parent.Controls.GetEnumerator();
			while (enumerator.MoveNext())
			{
				Control control = (Control)enumerator.Current;
				if (control != this && control is Control26)
				{
					((Control26)control).Boolean_0 = false;
				}
			}
		}
		finally
		{
			if (enumerator is IDisposable)
			{
				(enumerator as IDisposable).Dispose();
			}
		}
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Graphics graphics = e.Graphics;
		graphics.Clear(BackColor);
		graphics.SmoothingMode = SmoothingMode.AntiAlias;
		graphicsPath_0 = new GraphicsPath();
		checked
		{
			graphicsPath_0.AddEllipse(0, 2, Height - 5, Height - 5);
			pathGradientBrush_0 = new PathGradientBrush(graphicsPath_0);
			pathGradientBrush_0.CenterColor = Color.FromArgb(50, 50, 50);
			pathGradientBrush_0.SurroundColors = new Color[1] { Color.FromArgb(45, 45, 45) };
			PointF pointF2 = (pathGradientBrush_0.FocusScales = new PointF(0.3f, 0.3f));
			graphics.DrawEllipse(pen_0, 4, 4, Height - 11, Height - 11);
			if (bool_0)
			{
				GraphicsPath graphicsPath = new GraphicsPath();
				Rectangle rect = new Rectangle((int)Math.Round((double)Height - 18.5), Height - 19, 12, 12);
				graphicsPath.AddEllipse(rect);
				PathGradientBrush pathGradientBrush = new PathGradientBrush(graphicsPath);
				Point point = new Point((int)Math.Round((double)Height - 18.5), Height - 20);
				pathGradientBrush.CenterPoint = point;
				pathGradientBrush.CenterColor = Color.FromArgb(56, 142, 196);
				pathGradientBrush.SurroundColors = new Color[1] { Color.FromArgb(64, 106, 140) };
				pointF2 = (pathGradientBrush.FocusScales = new PointF(0.9f, 0.9f));
				graphics.FillPath(pathGradientBrush, graphicsPath);
				graphics.DrawPath(new Pen(Color.FromArgb(49, 63, 86)), graphicsPath);
				graphics.SetClip(graphicsPath);
				SolidBrush brush = new SolidBrush(Color.FromArgb(40, Color.WhiteSmoke));
				rect = new Rectangle(Height - 16, Height - 18, 6, 6);
				graphics.FillEllipse(brush, rect);
				graphics.ResetClip();
			}
			sizeF_0 = graphics.MeasureString(Text, Font);
			ref PointF reference = ref pointF_0;
			reference = new PointF(Height - 3, (float)unchecked(Height / 2) - sizeF_0.Height / 2f);
			graphics.DrawString(Text, Font, new SolidBrush(Color.FromArgb(1, 75, 124)), pointF_0);
		}
	}

	protected override void OnMouseDown(MouseEventArgs e)
	{
		Boolean_0 = true;
		base.OnMouseDown(e);
	}
}
