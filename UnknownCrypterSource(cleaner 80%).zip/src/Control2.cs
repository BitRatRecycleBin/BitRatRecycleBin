using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

internal class Control2 : Control
{
	private static List<WeakReference> list_0 = new List<WeakReference>();

	private Color color_0;

	private int int_0;

	private int int_1;

	public Color Color_0
	{
		get
		{
			return color_0;
		}
		set
		{
			color_0 = value;
			Invalidate();
		}
	}

	public int Int32_0
	{
		get
		{
			return int_0;
		}
		set
		{
			if (value < 1)
			{
				value = 1;
			}
			if (value < int_1)
			{
				int_1 = value;
			}
			int_0 = value;
			Invalidate();
		}
	}

	public int Int32_1
	{
		get
		{
			return int_1;
		}
		set
		{
			if (value > int_0)
			{
				value = int_0;
			}
			int_1 = value;
			Invalidate();
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	public Control2()
	{
		smethod_0(this);
		int_0 = 100;
		SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		Size size2 = (Size = new Size(200, 26));
		BackColor = Color.FromArgb(80, 80, 80);
		Color_0 = Color.Gray;
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		base.OnPaint(e);
		Graphics graphics = e.Graphics;
		graphics.Clear(Parent.BackColor);
		graphics.SmoothingMode = SmoothingMode.HighQuality;
		int num = 6;
		checked
		{
			Rectangle rectangle = new Rectangle(0, 0, Width - 1, Height - 1);
			GraphicsPath path = Class7.smethod_0(rectangle, 6);
			LinearGradientBrush brush = new LinearGradientBrush(rectangle, BackColor, Color.FromArgb(25, 25, 25), 90f);
			graphics.FillPath(brush, path);
			float num2 = (float)((double)int_1 / (double)int_0 * 100.0);
			if ((double)num2 > 2.75)
			{
				Rectangle rectangle2 = new Rectangle(0, 0, (int)Math.Round((double)Width / (double)int_0 * (double)int_1) - 1, Height - 1);
				GraphicsPath path2 = Class7.smethod_0(rectangle2, num);
				LinearGradientBrush brush2 = new LinearGradientBrush(rectangle2, Color_0, Color.FromArgb(45, 45, 45), 90f);
				graphics.FillPath(brush2, path2);
			}
			graphics.DrawPath(new Pen(Color.FromArgb(30, 30, 30)), path);
		}
	}
}
