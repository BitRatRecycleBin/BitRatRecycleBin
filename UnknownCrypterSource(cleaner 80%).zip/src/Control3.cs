using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

[DefaultEvent("TextChanged")]
internal class Control3 : Control
{
	private static List<WeakReference> list_0 = new List<WeakReference>();

	private int int_0;

	private bool bool_0;

	private bool bool_1;

	private Image image_0;

	private TextBox textBox_0;

	private HorizontalAlignment horizontalAlignment_0;

	public int Int32_0
	{
		get
		{
			return int_0;
		}
		set
		{
			int_0 = value;
			if (textBox_0 != null)
			{
				textBox_0.MaxLength = value;
			}
		}
	}

	public bool Boolean_0
	{
		get
		{
			return bool_0;
		}
		set
		{
			bool_0 = value;
			if (textBox_0 != null)
			{
				textBox_0.ReadOnly = value;
			}
		}
	}

	public bool Boolean_1
	{
		get
		{
			return bool_1;
		}
		set
		{
			bool_1 = value;
			if (textBox_0 != null)
			{
				textBox_0.UseSystemPasswordChar = value;
			}
		}
	}

	public override string Text
	{
		get
		{
			return base.Text;
		}
		set
		{
			base.Text = value;
			if (textBox_0 != null)
			{
				textBox_0.Text = value;
			}
		}
	}

	public override Font Font
	{
		get
		{
			return base.Font;
		}
		set
		{
			base.Font = value;
			if (textBox_0 != null)
			{
				textBox_0.Font = value;
				Point point2 = (textBox_0.Location = new Point(3, 5));
				textBox_0.Width = checked(Width - 6);
			}
		}
	}

	public Image Image_0
	{
		get
		{
			return image_0;
		}
		set
		{
			image_0 = value;
			checked
			{
				if (image_0 != null)
				{
					Point point2 = (textBox_0.Location = new Point(33, 5));
					textBox_0.Width = Width - 38;
				}
				else
				{
					Point point2 = (textBox_0.Location = new Point(5, 5));
					textBox_0.Width = Width - 10;
				}
				Invalidate();
			}
		}
	}

	[Category("Options")]
	public HorizontalAlignment HorizontalAlignment_0
	{
		get
		{
			return horizontalAlignment_0;
		}
		set
		{
			horizontalAlignment_0 = value;
			if (textBox_0 != null)
			{
				textBox_0.TextAlign = value;
			}
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	protected override void OnCreateControl()
	{
		base.OnCreateControl();
		if (!Controls.Contains(textBox_0))
		{
			Controls.Add(textBox_0);
		}
	}

	public Control3()
	{
		smethod_0(this);
		int_0 = 32767;
		horizontalAlignment_0 = HorizontalAlignment.Left;
		Font = new Font("Arial", 9f);
		ForeColor = Color.DimGray;
		Cursor = Cursors.IBeam;
		textBox_0 = new TextBox();
		textBox_0.Font = Font;
		textBox_0.Text = Text;
		textBox_0.ForeColor = ForeColor;
		textBox_0.MaxLength = int_0;
		textBox_0.ReadOnly = bool_0;
		textBox_0.BackColor = Color.Gainsboro;
		textBox_0.UseSystemPasswordChar = bool_1;
		textBox_0.BorderStyle = BorderStyle.None;
		Point point2 = (textBox_0.Location = new Point(5, 5));
		textBox_0.Width = checked(Width - 10);
		textBox_0.TextChanged += textBox_0_TextChanged;
		textBox_0.KeyDown += textBox_0_KeyDown;
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		base.OnPaint(e);
		checked
		{
			Size size2 = (Size = new Size(Size.Width, textBox_0.Height + 12));
			Graphics graphics = e.Graphics;
			graphics.SmoothingMode = SmoothingMode.HighQuality;
			graphics.Clear(Parent.BackColor);
			int num = 3;
			Rectangle rectangle_ = new Rectangle(0, 0, Width - 1, Height - 1);
			GraphicsPath path = Class7.smethod_0(rectangle_, 3);
			graphics.FillPath(Brushes.Gainsboro, path);
			graphics.DrawPath(new Pen(Color.FromArgb(55, 55, 55)), path);
			if (image_0 != null)
			{
				GraphicsPath graphicsPath = new GraphicsPath();
				graphicsPath.AddArc(0, 0, num * 2, num * 2, -90f, -90f);
				Point point = new Point(0, num);
				Point pt = point;
				Point pt2 = new Point(0, Height - num - 1);
				graphicsPath.AddLine(pt, pt2);
				graphicsPath.AddArc(0, Height - num * 2 - 1, num * 2, num * 2, -180f, -90f);
				pt2 = new Point(num * 2, Height - 1);
				Point pt3 = pt2;
				point = new Point(28, Height - 1);
				graphicsPath.AddLine(pt3, point);
				pt2 = new Point(28, Height - 1);
				Point pt4 = pt2;
				point = new Point(28, 0);
				graphicsPath.AddLine(pt4, point);
				pt2 = new Point(28, 0);
				Point pt5 = pt2;
				point = new Point(num * 2, 0);
				graphicsPath.AddLine(pt5, point);
				graphicsPath.CloseAllFigures();
				graphics.FillPath(Brushes.Gainsboro, graphicsPath);
				graphics.DrawPath(new Pen(Color.FromArgb(55, 55, 55)), graphicsPath);
				graphics.DrawImage(image_0, 7, 5, 16, 16);
			}
		}
	}

	private void textBox_0_TextChanged(object sender, EventArgs e)
	{
		Text = textBox_0.Text;
	}

	private void textBox_0_KeyDown(object sender, KeyEventArgs e)
	{
		if (e.Control && e.KeyCode == Keys.A)
		{
			textBox_0.SelectAll();
			e.SuppressKeyPress = true;
		}
	}

	protected override void OnResize(EventArgs e)
	{
		base.OnResize(e);
		checked
		{
			if (image_0 != null)
			{
				Point point2 = (textBox_0.Location = new Point(33, 6));
				textBox_0.Width = Width - 38;
			}
			else
			{
				Point point2 = (textBox_0.Location = new Point(6, 6));
				textBox_0.Width = Width - 12;
			}
		}
	}

	protected override void OnMouseDown(MouseEventArgs e)
	{
		base.OnMouseDown(e);
		textBox_0.SelectionStart = textBox_0.TextLength;
		textBox_0.Focus();
	}
}
