using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using UnknownCrypter.My.Resources;

[DesignerGenerated]
public class Loading : Form
{
	private static List<WeakReference> list_0 = new List<WeakReference>();

	private IContainer icontainer_0;

	[AccessedThroughProperty("PictureBox1")]
	private PictureBox _PictureBox1;

	[AccessedThroughProperty("EightBallLabel1")]
	private Class8 _EightBallLabel1;

	internal virtual PictureBox PictureBox1
	{
		[DebuggerNonUserCode]
		get
		{
			return _PictureBox1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_PictureBox1 = value;
		}
	}

	internal virtual Class8 EightBallLabel1
	{
		[DebuggerNonUserCode]
		get
		{
			return _EightBallLabel1;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			_EightBallLabel1 = value;
		}
	}

	[DebuggerNonUserCode]
	public Loading()
	{
		smethod_0(this);
		InitializeComponent();
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	[DebuggerNonUserCode]
	protected override void Dispose(bool disposing)
	{
		try
		{
			if (disposing && icontainer_0 != null)
			{
				icontainer_0.Dispose();
			}
		}
		finally
		{
			base.Dispose(disposing);
		}
	}

	[System.Diagnostics.DebuggerStepThrough]
	private void InitializeComponent()
	{
		PictureBox1 = new System.Windows.Forms.PictureBox();
		EightBallLabel1 = new Class8();
		((System.ComponentModel.ISupportInitialize)PictureBox1).BeginInit();
		SuspendLayout();
		PictureBox1.Image = UnknownCrypter.My.Resources.Resources.Bitmap_0;
		System.Drawing.Point point2 = (PictureBox1.Location = new System.Drawing.Point(4, 9));
		PictureBox1.Name = "PictureBox1";
		System.Drawing.Size size2 = (PictureBox1.Size = new System.Drawing.Size(50, 50));
		PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		PictureBox1.TabIndex = 0;
		PictureBox1.TabStop = false;
		EightBallLabel1.AutoSize = true;
		EightBallLabel1.BackColor = System.Drawing.Color.Transparent;
		EightBallLabel1.Font = new System.Drawing.Font("Showcard Gothic", 26.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		EightBallLabel1.ForeColor = System.Drawing.Color.WhiteSmoke;
		point2 = (EightBallLabel1.Location = new System.Drawing.Point(49, 10));
		EightBallLabel1.Name = "EightBallLabel1";
		size2 = (EightBallLabel1.Size = new System.Drawing.Size(203, 44));
		EightBallLabel1.TabIndex = 1;
		EightBallLabel1.Text = "Loading...";
		System.Drawing.SizeF sizeF2 = (AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f));
		AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		BackColor = System.Drawing.Color.Gray;
		size2 = (ClientSize = new System.Drawing.Size(250, 69));
		Controls.Add(EightBallLabel1);
		Controls.Add(PictureBox1);
		ForeColor = System.Drawing.Color.FromArgb(142, 152, 156);
		FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
		Name = "Loading";
		ShowIcon = false;
		ShowInTaskbar = false;
		StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
		Text = "Loading";
		TopMost = true;
		((System.ComponentModel.ISupportInitialize)PictureBox1).EndInit();
		ResumeLayout(false);
		PerformLayout();
	}
}
