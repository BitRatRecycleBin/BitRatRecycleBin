using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

[DefaultEvent("CheckedChanged")]
internal class Control28 : Control
{
	public delegate void Delegate9(object sender);

	private static List<WeakReference> list_0 = new List<WeakReference>();

	private Delegate9 delegate9_0;

	private bool bool_0;

	private GraphicsPath graphicsPath_0;

	private GraphicsPath graphicsPath_1;

	private SizeF sizeF_0;

	private PointF pointF_0;

	private Pen pen_0;

	private Pen pen_1;

	private Pen pen_2;

	private Pen pen_3;

	private PathGradientBrush pathGradientBrush_0;

	public bool Boolean_0
	{
		get
		{
			return bool_0;
		}
		set
		{
			bool_0 = value;
			delegate9_0?.Invoke(this);
			Invalidate();
		}
	}

	public event Delegate9 Event_0
	{
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		add
		{
			delegate9_0 = (Delegate9)Delegate.Combine(delegate9_0, value);
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		remove
		{
			delegate9_0 = (Delegate9)Delegate.Remove(delegate9_0, value);
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	public Control28()
	{
		smethod_0(this);
		SetStyle(ControlStyles.UserPaint | ControlStyles.Opaque | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		SetStyle(ControlStyles.Selectable, value: false);
		pen_0 = new Pen(Color.LightGray);
		pen_1 = new Pen(Color.FromArgb(35, 35, 35));
		pen_2 = new Pen(Color.Black, 2f);
		pen_3 = new Pen(Color.White, 2f);
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Graphics graphics = e.Graphics;
		graphics.Clear(Color.White);
		graphics.SmoothingMode = SmoothingMode.AntiAlias;
		checked
		{
			Rectangle rectangle_ = new Rectangle(0, 2, Height - 5, Height - 5);
			graphicsPath_0 = method_0(rectangle_, 1);
			rectangle_ = new Rectangle(1, 3, Height - 7, Height - 7);
			graphicsPath_1 = method_0(rectangle_, 1);
			GraphicsPath graphicsPath = new GraphicsPath();
			rectangle_ = new Rectangle((int)Math.Round((double)Height - 18.5), Height - 20, 14, 14);
			graphicsPath.AddPath(method_0(rectangle_, 2), connect: true);
			PathGradientBrush pathGradientBrush = new PathGradientBrush(graphicsPath);
			pathGradientBrush.CenterColor = Color.FromArgb(240, 240, 240);
			pathGradientBrush.SurroundColors = new Color[1] { Color.FromArgb(90, 90, 90) };
			PointF pointF2 = (pathGradientBrush.FocusScales = new PointF(0.4f, 0.4f));
			HatchBrush brush = new HatchBrush(HatchStyle.Trellis, Color.FromArgb(70, Color.FromArgb(15, 54, 80)), Color.Transparent);
			graphics.FillPath(pathGradientBrush, graphicsPath);
			graphics.FillPath(brush, graphicsPath);
			graphics.DrawPath(new Pen(Color.FromArgb(49, 63, 86)), graphicsPath);
			graphics.SetClip(graphicsPath);
			SolidBrush brush2 = new SolidBrush(Color.FromArgb(70, Color.DarkGray));
			rectangle_ = new Rectangle(Height - 16, Height - 18, 6, 6);
			graphics.FillEllipse(brush2, rectangle_);
			Pen white = Pens.White;
			rectangle_ = new Rectangle(5, 4, Height - 11, Height - 11);
			graphics.DrawPath(white, method_0(rectangle_, 2));
			graphics.ResetClip();
			if (bool_0)
			{
				Pen pen = new Pen(new SolidBrush(Color.FromArgb(1, 75, 124)), 2f);
				Point pt = new Point(8, Height - 9);
				Point pt2 = new Point(Height - 8, 6);
				graphics.DrawLine(pen, pt, pt2);
				graphics.DrawLine(new Pen(new SolidBrush(Color.FromArgb(1, 75, 124)), 2f), 7, Height - 13, 8, Height - 10);
			}
			sizeF_0 = graphics.MeasureString(Text, Font);
			ref PointF reference = ref pointF_0;
			reference = new PointF(Height - 3, (float)unchecked(Height / 2) - sizeF_0.Height / 2f);
			graphics.DrawString(Text, Font, new SolidBrush(Color.FromArgb(1, 75, 124)), pointF_0);
		}
	}

	protected override void OnMouseDown(MouseEventArgs e)
	{
		Boolean_0 = !Boolean_0;
	}

	public GraphicsPath method_0(Rectangle rectangle_0, int int_0)
	{
		GraphicsPath graphicsPath = new GraphicsPath();
		checked
		{
			int num = int_0 * 2;
			Rectangle rect = new Rectangle(rectangle_0.X, rectangle_0.Y, num, num);
			graphicsPath.AddArc(rect, -180f, 90f);
			rect = new Rectangle(rectangle_0.Width - num + rectangle_0.X, rectangle_0.Y, num, num);
			graphicsPath.AddArc(rect, -90f, 90f);
			rect = new Rectangle(rectangle_0.Width - num + rectangle_0.X, rectangle_0.Height - num + rectangle_0.Y, num, num);
			graphicsPath.AddArc(rect, 0f, 90f);
			rect = new Rectangle(rectangle_0.X, rectangle_0.Height - num + rectangle_0.Y, num, num);
			graphicsPath.AddArc(rect, 90f, 90f);
			Point pt = new Point(rectangle_0.X, rectangle_0.Height - num + rectangle_0.Y);
			Point pt2 = new Point(rectangle_0.X, int_0 + rectangle_0.Y);
			graphicsPath.AddLine(pt, pt2);
			return graphicsPath;
		}
	}
}
