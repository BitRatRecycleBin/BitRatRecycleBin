using System.Drawing;
using System.Windows.Forms;

internal class Class17 : ProfessionalColorTable
{
	private Color color_0;

	public override Color ButtonSelectedBorder => color_0;

	public override Color CheckBackground => color_0;

	public override Color CheckPressedBackground => color_0;

	public override Color CheckSelectedBackground => color_0;

	public override Color ImageMarginGradientBegin => color_0;

	public override Color ImageMarginGradientEnd => color_0;

	public override Color ImageMarginGradientMiddle => color_0;

	public override Color MenuBorder => Color.FromArgb(1, 75, 124);

	public override Color MenuItemBorder => color_0;

	public override Color MenuItemSelected => Color.FromArgb(50, Color.LightGray);

	public override Color SeparatorDark => Color.FromArgb(35, 35, 35);

	public override Color ToolStripDropDownBackground => color_0;

	public Class17()
	{
		color_0 = Color.White;
	}
}
