using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

public class GControl13 : Control
{
	private static List<WeakReference> list_0 = new List<WeakReference>();

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	public GControl13()
	{
		smethod_0(this);
		SetStyle(ControlStyles.SupportsTransparentBackColor, value: true);
		SetStyle(ControlStyles.UserPaint, value: true);
		SetStyle(ControlStyles.AllPaintingInWmPaint, value: true);
		SetStyle(ControlStyles.OptimizedDoubleBuffer, value: true);
		DoubleBuffered = true;
		ForeColor = Color.White;
		BackColor = Color.FromArgb(51, 56, 60);
		Font = new Font("Arial", 8.25f, FontStyle.Bold);
	}

	protected override void OnTextChanged(EventArgs e)
	{
		base.OnTextChanged(e);
		Invalidate();
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Bitmap bitmap = new Bitmap(Width, Height);
		Graphics graphics = Graphics.FromImage(bitmap);
		base.OnPaint(e);
		graphics.TextRenderingHint = TextRenderingHint.AntiAlias;
		graphics.Clear(BackColor);
		string s = Text;
		Font font = Font;
		SolidBrush brush = new SolidBrush(Color.FromArgb(16, 20, 21));
		checked
		{
			Rectangle rectangle = new Rectangle(1, 1, Width - 1, Height - 1);
			graphics.DrawString(s, font, brush, rectangle, new StringFormat
			{
				LineAlignment = StringAlignment.Center,
				Alignment = StringAlignment.Near
			});
			string s2 = Text;
			Font font2 = Font;
			SolidBrush brush2 = new SolidBrush(ForeColor);
			rectangle = new Rectangle(0, 0, Width - 1, Height - 1);
			graphics.DrawString(s2, font2, brush2, rectangle, new StringFormat
			{
				LineAlignment = StringAlignment.Center,
				Alignment = StringAlignment.Near
			});
			Graphics graphics2 = e.Graphics;
			Point point = new Point(0, 0);
			graphics2.DrawImage(bitmap, point);
			graphics.Dispose();
			bitmap.Dispose();
		}
	}
}
