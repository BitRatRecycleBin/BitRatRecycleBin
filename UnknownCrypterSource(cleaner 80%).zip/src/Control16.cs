using System.Drawing;
using System.Windows.Forms;

internal class Control16 : Control12
{
	public Control16()
	{
		Boolean_1 = true;
		BackColor = Color.Transparent;
	}

	protected override void ColorHook()
	{
	}

	protected override void PaintHook()
	{
		method_52(Color.FromArgb(59, 59, 59), Color.FromArgb(24, 24, 24), 0, 0, Width, Height);
		checked
		{
			method_52(Color.FromArgb(204, 37, 37), Color.FromArgb(104, 2, 2), 0, 0, unchecked(Width / 5) + 8, Height);
			graphics_0.FillRectangle(new SolidBrush(Color.FromArgb(20, Color.White)), 0, 0, Width, unchecked(Height / 2));
			method_32(new Pen(Color.FromArgb(216, 70, 70)), 1);
			graphics_0.DrawLine(new Pen(Color.FromArgb(151, 36, 36)), unchecked(Width / 5) + 7, 1, unchecked(Width / 5) + 7, Height - 1);
			graphics_0.DrawLine(new Pen(Color.FromArgb(64, 64, 64)), unchecked(Width / 5) + 8, 1, unchecked(Width / 5) + 8, Height - 1);
			graphics_0.DrawLine(new Pen(Color.FromArgb(87, 87, 87)), unchecked(Width / 5) + 8, 1, Width, 1);
			graphics_0.DrawLine(new Pen(Color.FromArgb(87, 87, 87)), Width - 2, 1, Width - 2, Height - 1);
			graphics_0.DrawLine(new Pen(Color.FromArgb(87, 87, 87)), unchecked(Width / 5) + 8, Height - 2, Width, Height - 2);
			method_35(Pens.Black);
			method_29(BackColor);
			if (enum1_0 == Enum1.Over)
			{
				graphics_0.FillRectangle(new SolidBrush(Color.FromArgb(30, Color.White)), unchecked(Width / 5) + 8, 0, Width, Height);
				method_32(new Pen(Color.FromArgb(216, 70, 70)), 1);
				graphics_0.DrawLine(new Pen(Color.FromArgb(151, 36, 36)), unchecked(Width / 5) + 7, 1, unchecked(Width / 5) + 7, Height - 1);
				graphics_0.DrawLine(new Pen(Color.FromArgb(64, 64, 64)), unchecked(Width / 5) + 8, 1, unchecked(Width / 5) + 8, Height - 1);
				graphics_0.DrawLine(new Pen(Color.FromArgb(87, 87, 87)), unchecked(Width / 5) + 8, 1, Width, 1);
				graphics_0.DrawLine(new Pen(Color.FromArgb(87, 87, 87)), Width - 2, 1, Width - 2, Height - 1);
				graphics_0.DrawLine(new Pen(Color.FromArgb(87, 87, 87)), unchecked(Width / 5) + 8, Height - 2, Width, Height - 2);
				method_35(Pens.Black);
			}
			else if (enum1_0 == Enum1.Down)
			{
				method_52(Color.FromArgb(45, 45, 45), Color.FromArgb(0, 0, 0), unchecked(Width / 5) + 8, 0, Width, Height);
				graphics_0.FillRectangle(new SolidBrush(Color.FromArgb(15, Color.White)), unchecked(Width / 5) + 8, 0, Width, unchecked(Height / 2));
				method_32(new Pen(Color.FromArgb(216, 70, 70)), 1);
				graphics_0.DrawLine(new Pen(Color.FromArgb(151, 36, 36)), unchecked(Width / 5) + 7, 1, unchecked(Width / 5) + 7, Height - 1);
				graphics_0.DrawLine(new Pen(Color.FromArgb(64, 64, 64)), unchecked(Width / 5) + 8, 1, unchecked(Width / 5) + 8, Height - 1);
				graphics_0.DrawLine(new Pen(Color.FromArgb(87, 87, 87)), unchecked(Width / 5) + 8, 1, Width, 1);
				graphics_0.DrawLine(new Pen(Color.FromArgb(87, 87, 87)), Width - 2, 1, Width - 2, Height - 1);
				graphics_0.DrawLine(new Pen(Color.FromArgb(87, 87, 87)), unchecked(Width / 5) + 8, Height - 2, Width, Height - 2);
				method_35(Pens.Black);
			}
			method_38(Brushes.White, HorizontalAlignment.Center, 8, 0);
		}
	}
}
