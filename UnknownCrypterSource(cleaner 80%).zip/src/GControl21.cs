using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

public class GControl21 : Control
{
	public enum GEnum6
	{
		Left,
		Middle,
		Right
	}

	private static List<WeakReference> list_0 = new List<WeakReference>();

	private Enum3 enum3_0;

	private Color color_0;

	private Color color_1;

	private Color color_2;

	private Color color_3;

	private Color color_4;

	private Color color_5;

	private bool bool_0;

	private bool bool_1;

	private bool bool_2;

	private Image image_0;

	private StringAlignment stringAlignment_0;

	private GEnum6 genum6_0;

	[Category("Control")]
	public GEnum6 GEnum6_0
	{
		get
		{
			return genum6_0;
		}
		set
		{
			if (bool_2 && value == GEnum6.Middle)
			{
				genum6_0 = GEnum6.Left;
			}
			else
			{
				genum6_0 = value;
			}
			Invalidate();
		}
	}

	[Category("Control")]
	public Image Image_0
	{
		get
		{
			return image_0;
		}
		set
		{
			image_0 = value;
			Invalidate();
		}
	}

	[Category("Control")]
	public StringAlignment StringAlignment_0
	{
		get
		{
			return stringAlignment_0;
		}
		set
		{
			stringAlignment_0 = value;
			Invalidate();
		}
	}

	[Category("Control")]
	public bool Boolean_0
	{
		get
		{
			return bool_1;
		}
		set
		{
			bool_1 = value;
			Invalidate();
		}
	}

	[Category("Control")]
	public bool Boolean_1
	{
		get
		{
			return bool_2;
		}
		set
		{
			if (genum6_0 == GEnum6.Middle && Boolean_0 && value)
			{
				genum6_0 = GEnum6.Left;
			}
			bool_2 = value;
			Invalidate();
		}
	}

	[Category("Control")]
	public bool Boolean_2
	{
		get
		{
			return bool_0;
		}
		set
		{
			bool_0 = value;
			Invalidate();
		}
	}

	[Category("Colours")]
	public Color Color_0
	{
		get
		{
			return color_3;
		}
		set
		{
			color_3 = value;
		}
	}

	[Category("Colours")]
	public Color Color_1
	{
		get
		{
			return color_4;
		}
		set
		{
			color_4 = value;
		}
	}

	[Category("Colours")]
	public Color Color_2
	{
		get
		{
			return color_1;
		}
		set
		{
			color_1 = value;
		}
	}

	[Category("Colours")]
	public Color Color_3
	{
		get
		{
			return color_0;
		}
		set
		{
			color_0 = value;
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	protected override void OnMouseUp(MouseEventArgs e)
	{
		base.OnMouseUp(e);
		enum3_0 = Enum3.Over;
		Invalidate();
	}

	protected override void OnMouseEnter(EventArgs e)
	{
		base.OnMouseEnter(e);
		enum3_0 = Enum3.Over;
		Invalidate();
	}

	protected override void OnMouseLeave(EventArgs e)
	{
		base.OnMouseLeave(e);
		enum3_0 = Enum3.None;
		Invalidate();
	}

	protected override void OnMouseDown(MouseEventArgs e)
	{
		base.OnMouseDown(e);
		enum3_0 = Enum3.Down;
		Invalidate();
	}

	public GControl21()
	{
		smethod_0(this);
		enum3_0 = Enum3.None;
		color_0 = Color.FromArgb(153, 153, 153);
		color_1 = Color.FromArgb(45, 45, 48);
		color_2 = Color.FromArgb(255, 255, 255);
		color_3 = Color.FromArgb(15, 15, 18);
		color_4 = Color.FromArgb(60, 60, 62);
		color_5 = Color.FromArgb(37, 37, 39);
		bool_0 = true;
		bool_1 = false;
		image_0 = null;
		stringAlignment_0 = StringAlignment.Center;
		genum6_0 = GEnum6.Left;
		SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		DoubleBuffered = true;
		BackColor = color_1;
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Graphics graphics = e.Graphics;
		Graphics graphics2 = graphics;
		graphics2.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
		graphics2.SmoothingMode = SmoothingMode.AntiAlias;
		graphics2.PixelOffsetMode = PixelOffsetMode.HighQuality;
		switch (enum3_0)
		{
		case Enum3.None:
		{
			Graphics graphics5 = graphics2;
			SolidBrush brush3 = new SolidBrush(color_1);
			Rectangle rect = new Rectangle(0, 0, Width, Height);
			graphics5.FillRectangle(brush3, rect);
			break;
		}
		case Enum3.Over:
		{
			Graphics graphics4 = graphics2;
			SolidBrush brush2 = new SolidBrush(color_4);
			Rectangle rect = new Rectangle(0, 0, Width, Height);
			graphics4.FillRectangle(brush2, rect);
			break;
		}
		case Enum3.Down:
		{
			Graphics graphics3 = graphics2;
			SolidBrush brush = new SolidBrush(color_5);
			Rectangle rect = new Rectangle(0, 0, Width, Height);
			graphics3.FillRectangle(brush, rect);
			break;
		}
		}
		if (bool_0)
		{
			Graphics graphics6 = graphics2;
			Pen pen = new Pen(color_3, 1f);
			Rectangle rect = new Rectangle(0, 0, Width, Height);
			graphics6.DrawRectangle(pen, rect);
		}
		checked
		{
			if (bool_1)
			{
				if (bool_2)
				{
					if (Width > 50 && Height > 30)
					{
						if (genum6_0 == GEnum6.Left)
						{
							Graphics graphics7 = graphics2;
							Image image = image_0;
							Rectangle rect = new Rectangle(10, 10, Height - 20, Height - 20);
							graphics7.DrawImage(image, rect);
							Graphics graphics8 = graphics2;
							string s = Text;
							Font font = Font;
							SolidBrush brush4 = new SolidBrush(color_0);
							rect = new Rectangle(0 + (Height - 5), 0, Width - 20 - (Height - 10), Height);
							graphics8.DrawString(s, font, brush4, rect, new StringFormat
							{
								Alignment = stringAlignment_0,
								LineAlignment = StringAlignment.Center
							});
						}
						else if (genum6_0 == GEnum6.Right)
						{
							Graphics graphics9 = graphics2;
							Image image2 = image_0;
							Rectangle rect = new Rectangle(Width - 20 - (Height - 20), 10, Height - 20, Height - 20);
							graphics9.DrawImage(image2, rect);
							Graphics graphics10 = graphics2;
							string s2 = Text;
							Font font2 = Font;
							SolidBrush brush5 = new SolidBrush(color_0);
							rect = new Rectangle(10, 0, Width - 20 - (Height - 20), Height);
							graphics10.DrawString(s2, font2, brush5, rect, new StringFormat
							{
								Alignment = stringAlignment_0,
								LineAlignment = StringAlignment.Center
							});
						}
					}
					else
					{
						Graphics graphics11 = graphics2;
						string s3 = Text;
						Font font3 = Font;
						SolidBrush brush6 = new SolidBrush(color_0);
						Rectangle rect = new Rectangle(10, 0, Width - 20, Height);
						graphics11.DrawString(s3, font3, brush6, rect, new StringFormat
						{
							Alignment = stringAlignment_0,
							LineAlignment = StringAlignment.Center
						});
					}
				}
				else if (genum6_0 == GEnum6.Left)
				{
					Graphics graphics12 = graphics2;
					Image image3 = image_0;
					Rectangle rect = new Rectangle(10, 10, Height - 20, Height - 20);
					graphics12.DrawImage(image3, rect);
				}
				else if (genum6_0 == GEnum6.Middle)
				{
					Graphics graphics13 = graphics2;
					Image image4 = image_0;
					Rectangle rect = new Rectangle((int)Math.Round((double)Width / 2.0 - (double)(Height - 20) / 2.0), 10, Height - 20, Height - 20);
					graphics13.DrawImage(image4, rect);
				}
				else
				{
					Graphics graphics14 = graphics2;
					Image image5 = image_0;
					Rectangle rect = new Rectangle(Width - 10 - (Height - 20), 10, Height - 20, Height - 20);
					graphics14.DrawImage(image5, rect);
				}
			}
			else if (bool_2)
			{
				Graphics graphics15 = graphics2;
				string s4 = Text;
				Font font4 = Font;
				SolidBrush brush7 = new SolidBrush(color_0);
				Rectangle rect = new Rectangle(10, 0, Width - 20, Height);
				graphics15.DrawString(s4, font4, brush7, rect, new StringFormat
				{
					Alignment = stringAlignment_0,
					LineAlignment = StringAlignment.Center
				});
			}
			graphics2.InterpolationMode = InterpolationMode.HighQualityBicubic;
			graphics2 = null;
		}
	}
}
