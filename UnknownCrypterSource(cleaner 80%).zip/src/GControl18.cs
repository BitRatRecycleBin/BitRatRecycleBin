using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

[DefaultEvent("CheckedChanged")]
public class GControl18 : Control
{
	public delegate void GDelegate7(object sender);

	private static List<WeakReference> list_0 = new List<WeakReference>();

	private GEnum0 genum0_0;

	private bool bool_0;

	private GDelegate7 gdelegate7_0;

	public bool Boolean_0
	{
		get
		{
			return bool_0;
		}
		set
		{
			bool_0 = value;
			Invalidate();
		}
	}

	public event GDelegate7 Event_0
	{
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		add
		{
			gdelegate7_0 = (GDelegate7)Delegate.Combine(gdelegate7_0, value);
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		remove
		{
			gdelegate7_0 = (GDelegate7)Delegate.Remove(gdelegate7_0, value);
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	protected override void OnMouseEnter(EventArgs e)
	{
		base.OnMouseEnter(e);
		genum0_0 = GEnum0.Over;
		Invalidate();
	}

	protected override void OnMouseDown(MouseEventArgs e)
	{
		base.OnMouseDown(e);
		genum0_0 = GEnum0.Down;
		Invalidate();
	}

	protected override void OnMouseLeave(EventArgs e)
	{
		base.OnMouseLeave(e);
		genum0_0 = GEnum0.None;
		Invalidate();
	}

	protected override void OnMouseUp(MouseEventArgs e)
	{
		base.OnMouseUp(e);
		genum0_0 = GEnum0.Over;
		Invalidate();
	}

	protected override void OnTextChanged(EventArgs e)
	{
		base.OnTextChanged(e);
		Invalidate();
	}

	protected override void OnResize(EventArgs e)
	{
		base.OnResize(e);
		Size size2 = (Size = new Size(60, 26));
	}

	protected override void OnClick(EventArgs e)
	{
		bool_0 = !bool_0;
		gdelegate7_0?.Invoke(this);
		base.OnClick(e);
	}

	public GControl18()
	{
		smethod_0(this);
		genum0_0 = GEnum0.None;
		SetStyle(ControlStyles.UserPaint, value: true);
		SetStyle(ControlStyles.AllPaintingInWmPaint, value: true);
		SetStyle(ControlStyles.OptimizedDoubleBuffer, value: true);
		SetStyle(ControlStyles.SupportsTransparentBackColor, value: true);
		Size size2 = (Size = new Size(60, 26));
		BackColor = Color.Transparent;
		ForeColor = Color.White;
		DoubleBuffered = true;
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Bitmap bitmap = new Bitmap(Width, Height);
		Graphics graphics = Graphics.FromImage(bitmap);
		graphics.SmoothingMode = SmoothingMode.HighQuality;
		graphics.TextRenderingHint = TextRenderingHint.AntiAlias;
		int int_ = 4;
		graphics.Clear(BackColor);
		graphics.Clear(Color.Transparent);
		SolidBrush brush = new SolidBrush(Color.FromArgb(49, 50, 54));
		checked
		{
			Rectangle rectangle_ = new Rectangle(0, 0, Width - 1, Height - 1);
			graphics.FillPath(brush, Class19.smethod_0(rectangle_, 4));
			Color[] array = new Color[6]
			{
				Color.FromArgb(43, 44, 48),
				Color.FromArgb(44, 45, 49),
				Color.FromArgb(45, 46, 50),
				Color.FromArgb(46, 47, 51),
				Color.FromArgb(47, 48, 52),
				Color.FromArgb(48, 49, 53)
			};
			int num = 0;
			do
			{
				Pen pen = new Pen(array[num]);
				rectangle_ = new Rectangle(num + 1, num + 1, Width - (2 * num + 3), Height - (2 * num + 3));
				graphics.DrawPath(pen, Class19.smethod_0(rectangle_, int_));
				num++;
			}
			while (num <= 5);
			rectangle_ = new Rectangle(0, 0, Width - 1, Height - 1);
			LinearGradientBrush brush2 = new LinearGradientBrush(rectangle_, Color.Transparent, Color.FromArgb(87, 88, 92), 90f);
			Pen pen2 = new Pen(brush2);
			rectangle_ = new Rectangle(0, 0, Width - 1, Height - 2);
			graphics.DrawPath(pen2, Class19.smethod_0(rectangle_, int_));
			Pen pen3 = new Pen(Color.FromArgb(32, 33, 37));
			rectangle_ = new Rectangle(0, 0, Width - 1, Height - 3);
			graphics.DrawPath(pen3, Class19.smethod_0(rectangle_, int_));
			switch (Boolean_0)
			{
			case false:
			{
				rectangle_ = new Rectangle(0, 0, 30, Height - 3);
				LinearGradientBrush brush6 = new LinearGradientBrush(rectangle_, Color.FromArgb(72, 79, 87), Color.FromArgb(48, 52, 55), 90f);
				rectangle_ = new Rectangle(0, 0, 30, Height - 3);
				graphics.FillPath(brush6, Class19.smethod_0(rectangle_, int_));
				rectangle_ = new Rectangle(0, 0, 30, Height - 3);
				LinearGradientBrush brush7 = new LinearGradientBrush(rectangle_, Color.FromArgb(29, 34, 40), Color.FromArgb(33, 34, 38), 90f);
				Pen pen8 = new Pen(brush7);
				rectangle_ = new Rectangle(0, 0, 30, Height - 3);
				graphics.DrawPath(pen8, Class19.smethod_0(rectangle_, int_));
				rectangle_ = new Rectangle(1, 1, 28, Height - 5);
				LinearGradientBrush brush8 = new LinearGradientBrush(rectangle_, Color.FromArgb(118, 123, 129), Color.FromArgb(66, 67, 71), 90f);
				Pen pen9 = new Pen(brush8);
				rectangle_ = new Rectangle(1, 1, 28, Height - 5);
				graphics.DrawPath(pen9, Class19.smethod_0(rectangle_, int_));
				int num3 = 0;
				do
				{
					Pen pen10 = new Pen(Color.FromArgb(82, 86, 95));
					Point pt2 = new Point(7, 7 + num3 * 4);
					Point pt4 = pt2;
					Point point = new Point(22, 7 + num3 * 4);
					graphics.DrawLine(pen10, pt4, point);
					Pen pen11 = new Pen(Color.FromArgb(47, 50, 57));
					point = new Point(7, 7 + num3 * 4 + 1);
					Point pt5 = point;
					pt2 = new Point(22, 7 + num3 * 4 + 1);
					graphics.DrawLine(pen11, pt5, pt2);
					num3++;
				}
				while (num3 <= 2);
				break;
			}
			case true:
			{
				rectangle_ = new Rectangle(29, 0, 30, Height - 3);
				LinearGradientBrush brush3 = new LinearGradientBrush(rectangle_, Color.FromArgb(145, 204, 238), Color.FromArgb(35, 137, 222), 90f);
				rectangle_ = new Rectangle(29, 0, 30, Height - 3);
				graphics.FillPath(brush3, Class19.smethod_0(rectangle_, int_));
				rectangle_ = new Rectangle(29, 0, 30, Height - 3);
				LinearGradientBrush brush4 = new LinearGradientBrush(rectangle_, Color.FromArgb(21, 37, 52), Color.FromArgb(18, 37, 54), 90f);
				Pen pen4 = new Pen(brush4);
				rectangle_ = new Rectangle(29, 0, 30, Height - 3);
				graphics.DrawPath(pen4, Class19.smethod_0(rectangle_, int_));
				rectangle_ = new Rectangle(30, 1, 28, Height - 5);
				LinearGradientBrush brush5 = new LinearGradientBrush(rectangle_, Color.FromArgb(169, 228, 255), Color.FromArgb(53, 155, 240), 90f);
				Pen pen5 = new Pen(brush5);
				rectangle_ = new Rectangle(30, 1, 28, Height - 5);
				graphics.DrawPath(pen5, Class19.smethod_0(rectangle_, int_));
				int num2 = 0;
				do
				{
					Pen pen6 = new Pen(Color.FromArgb(109, 188, 244));
					Point point = new Point(36, 7 + num2 * 4);
					Point pt = point;
					Point pt2 = new Point(51, 7 + num2 * 4);
					graphics.DrawLine(pen6, pt, pt2);
					Pen pen7 = new Pen(Color.FromArgb(40, 123, 199));
					point = new Point(36, 7 + num2 * 4 + 1);
					Point pt3 = point;
					pt2 = new Point(51, 7 + num2 * 4 + 1);
					graphics.DrawLine(pen7, pt3, pt2);
					num2++;
				}
				while (num2 <= 2);
				break;
			}
			}
			NewLateBinding.LateCall(e.Graphics, null, "DrawImage", new object[3]
			{
				RuntimeHelpers.GetObjectValue(bitmap.Clone()),
				0,
				0
			}, null, null, null, IgnoreReturn: true);
			graphics.Dispose();
			bitmap.Dispose();
		}
	}
}
