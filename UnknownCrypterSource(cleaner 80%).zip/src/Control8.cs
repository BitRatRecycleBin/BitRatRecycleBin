using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

internal abstract class Control8 : ContainerControl
{
	protected Graphics graphics_0;

	protected Bitmap bitmap_0;

	private bool bool_0;

	private bool bool_1;

	private Rectangle rectangle_0;

	protected Enum1 enum1_0;

	private bool bool_2;

	private Point point_0;

	private bool bool_3;

	private bool bool_4;

	private bool bool_5;

	private bool bool_6;

	private int int_0;

	private int int_1;

	private Message[] message_0;

	private bool bool_7;

	private bool bool_8;

	private bool bool_9;

	private bool bool_10;

	private Color color_0;

	private FormBorderStyle formBorderStyle_0;

	private FormStartPosition formStartPosition_0;

	private bool bool_11;

	private Image image_0;

	private Dictionary<string, Color> dictionary_0;

	private string string_0;

	private bool bool_12;

	private Size size_0;

	private bool bool_13;

	private int int_2;

	private int int_3;

	private int int_4;

	private bool bool_14;

	private bool bool_15;

	private Rectangle rectangle_1;

	private Size size_1;

	private Point point_1;

	private Point point_2;

	private Bitmap bitmap_1;

	private Graphics graphics_1;

	private SolidBrush solidBrush_0;

	private SolidBrush solidBrush_1;

	private Point point_3;

	private Size size_2;

	private Point point_4;

	private LinearGradientBrush linearGradientBrush_0;

	private Rectangle rectangle_2;

	private GraphicsPath graphicsPath_0;

	private PathGradientBrush pathGradientBrush_0;

	private LinearGradientBrush linearGradientBrush_1;

	private Rectangle rectangle_3;

	private GraphicsPath graphicsPath_1;

	private Rectangle rectangle_4;

	public override DockStyle Dock
	{
		get
		{
			return base.Dock;
		}
		set
		{
			if (bool_14)
			{
				base.Dock = value;
			}
		}
	}

	[Category("Misc")]
	public override Color BackColor
	{
		get
		{
			return base.BackColor;
		}
		set
		{
			if (value == base.BackColor)
			{
				return;
			}
			if (!IsHandleCreated && bool_14 && value == Color.Transparent)
			{
				bool_7 = true;
				return;
			}
			base.BackColor = value;
			if (Parent != null)
			{
				if (!bool_14)
				{
					Parent.BackColor = value;
				}
				ColorHook();
			}
		}
	}

	public override Size MinimumSize
	{
		get
		{
			return base.MinimumSize;
		}
		set
		{
			base.MinimumSize = value;
			if (Parent != null)
			{
				Parent.MinimumSize = value;
			}
		}
	}

	public override Size MaximumSize
	{
		get
		{
			return base.MaximumSize;
		}
		set
		{
			base.MaximumSize = value;
			if (Parent != null)
			{
				Parent.MaximumSize = value;
			}
		}
	}

	public override string Text
	{
		get
		{
			return base.Text;
		}
		set
		{
			base.Text = value;
			Invalidate();
		}
	}

	public override Font Font
	{
		get
		{
			return base.Font;
		}
		set
		{
			base.Font = value;
			Invalidate();
		}
	}

	[Browsable(false)]
	[EditorBrowsable(EditorBrowsableState.Never)]
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	public override Color ForeColor
	{
		get
		{
			return Color.Empty;
		}
		set
		{
		}
	}

	[Browsable(false)]
	[EditorBrowsable(EditorBrowsableState.Never)]
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	public override Image BackgroundImage
	{
		get
		{
			return null;
		}
		set
		{
		}
	}

	[EditorBrowsable(EditorBrowsableState.Never)]
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	[Browsable(false)]
	public override ImageLayout BackgroundImageLayout
	{
		get
		{
			return ImageLayout.None;
		}
		set
		{
		}
	}

	public bool Boolean_0
	{
		get
		{
			return bool_8;
		}
		set
		{
			bool_8 = value;
		}
	}

	public bool Boolean_1
	{
		get
		{
			return bool_9;
		}
		set
		{
			bool_9 = value;
		}
	}

	public bool Boolean_2
	{
		get
		{
			return bool_10;
		}
		set
		{
			bool_10 = value;
		}
	}

	public Color Color_0
	{
		get
		{
			if (bool_13 && !bool_14)
			{
				return ParentForm.TransparencyKey;
			}
			return color_0;
		}
		set
		{
			if (!(value == color_0))
			{
				color_0 = value;
				if (bool_13 && !bool_14)
				{
					ParentForm.TransparencyKey = value;
					ColorHook();
				}
			}
		}
	}

	public FormBorderStyle FormBorderStyle_0
	{
		get
		{
			if (bool_13 && !bool_14)
			{
				return ParentForm.FormBorderStyle;
			}
			return formBorderStyle_0;
		}
		set
		{
			formBorderStyle_0 = value;
			if (bool_13 && !bool_14)
			{
				ParentForm.FormBorderStyle = value;
				if (value != 0)
				{
					Boolean_1 = false;
					Boolean_2 = false;
				}
			}
		}
	}

	public FormStartPosition FormStartPosition_0
	{
		get
		{
			if (bool_13 && !bool_14)
			{
				return ParentForm.StartPosition;
			}
			return formStartPosition_0;
		}
		set
		{
			formStartPosition_0 = value;
			if (bool_13 && !bool_14)
			{
				ParentForm.StartPosition = value;
			}
		}
	}

	public bool Boolean_3
	{
		get
		{
			return bool_11;
		}
		set
		{
			bool_11 = value;
			Invalidate();
		}
	}

	public Image Image_0
	{
		get
		{
			return image_0;
		}
		set
		{
			if (value == null)
			{
				size_0 = Size.Empty;
			}
			else
			{
				size_0 = value.Size;
			}
			image_0 = value;
			Invalidate();
		}
	}

	public Struct0[] Struct0_0
	{
		get
		{
			List<Struct0> list = new List<Struct0>();
			Dictionary<string, Color>.Enumerator enumerator = dictionary_0.GetEnumerator();
			while (enumerator.MoveNext())
			{
				Struct0 item = new Struct0(enumerator.Current.Key, enumerator.Current.Value);
				list.Add(item);
			}
			return list.ToArray();
		}
		set
		{
			for (int i = 0; i < value.Length; i = checked(i + 1))
			{
				Struct0 @struct = value[i];
				if (dictionary_0.ContainsKey(@struct.String_0))
				{
					dictionary_0[@struct.String_0] = @struct.Color_0;
				}
			}
			method_16();
			ColorHook();
			Invalidate();
		}
	}

	public string String_0
	{
		get
		{
			return string_0;
		}
		set
		{
			if (Operators.CompareString(value, string_0, TextCompare: false) == 0)
			{
				return;
			}
			Struct0[] struct0_ = Struct0_0;
			checked
			{
				try
				{
					byte[] value2 = Convert.FromBase64String(value);
					int num = struct0_.Length - 1;
					int num2 = 0;
					while (true)
					{
						int num3 = num2;
						int num4 = num;
						if (num3 <= num4)
						{
							struct0_[num2].Color_0 = Color.FromArgb(BitConverter.ToInt32(value2, num2 * 4));
							num2++;
							continue;
						}
						break;
					}
				}
				catch (Exception projectError)
				{
					ProjectData.SetProjectError(projectError);
					ProjectData.ClearProjectError();
					return;
				}
				string_0 = value;
				Struct0_0 = struct0_;
				ColorHook();
				Invalidate();
			}
		}
	}

	public bool Boolean_4
	{
		get
		{
			return bool_12;
		}
		set
		{
			bool_12 = value;
			if (IsHandleCreated || bool_14)
			{
				if (!value && BackColor.A != byte.MaxValue)
				{
					throw new Exception("Unable to change value to false while a transparent BackColor is in use.");
				}
				SetStyle(ControlStyles.Opaque, !value);
				SetStyle(ControlStyles.SupportsTransparentBackColor, value);
				method_15();
				Invalidate();
			}
		}
	}

	protected Size Size_0 => size_0;

	protected bool Boolean_5 => bool_13;

	protected bool Boolean_6
	{
		get
		{
			if (Parent == null)
			{
				return false;
			}
			return Parent.Parent != null;
		}
	}

	protected int Int32_0
	{
		get
		{
			return int_2;
		}
		set
		{
			int_2 = value;
			if (Int32_0 != 0 && IsHandleCreated)
			{
				Width = Int32_0;
			}
		}
	}

	protected int Int32_1
	{
		get
		{
			return int_3;
		}
		set
		{
			int_3 = value;
			if (Int32_1 != 0 && IsHandleCreated)
			{
				Height = Int32_1;
			}
		}
	}

	protected int Int32_2
	{
		get
		{
			return int_4;
		}
		set
		{
			int_4 = value;
			if (!bool_14)
			{
				ref Rectangle reference = ref rectangle_0;
				reference = checked(new Rectangle(7, 7, Width - 14, value - 7));
				Invalidate();
			}
		}
	}

	protected bool Boolean_7
	{
		get
		{
			return bool_14;
		}
		set
		{
			bool_14 = value;
			Boolean_4 = bool_12;
			if (bool_12 && bool_7)
			{
				BackColor = Color.Transparent;
			}
			method_15();
			Invalidate();
		}
	}

	protected bool Boolean_8
	{
		get
		{
			return bool_15;
		}
		set
		{
			bool_15 = value;
			method_17();
		}
	}

	public Control8()
	{
		message_0 = new Message[9];
		bool_8 = true;
		bool_9 = true;
		bool_10 = true;
		dictionary_0 = new Dictionary<string, Color>();
		int_4 = 24;
		SetStyle(ControlStyles.UserPaint | ControlStyles.Opaque | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		size_0 = Size.Empty;
		Font = new Font("Verdana", 8f);
		bitmap_1 = new Bitmap(1, 1);
		graphics_1 = Graphics.FromImage(bitmap_1);
		graphicsPath_0 = new GraphicsPath();
		method_16();
	}

	protected sealed override void OnHandleCreated(EventArgs e)
	{
		if (bool_0)
		{
			method_5();
		}
		method_16();
		ColorHook();
		if (int_2 != 0)
		{
			Width = int_2;
		}
		if (int_3 != 0)
		{
			Height = int_3;
		}
		if (!bool_14)
		{
			base.Dock = DockStyle.Fill;
		}
		Boolean_4 = bool_12;
		if (bool_12 && bool_7)
		{
			BackColor = Color.Transparent;
		}
		base.OnHandleCreated(e);
	}

	protected sealed override void OnParentChanged(EventArgs e)
	{
		base.OnParentChanged(e);
		if (Parent == null)
		{
			return;
		}
		bool_13 = Parent is Form;
		if (!bool_14)
		{
			method_5();
			if (bool_13)
			{
				ParentForm.FormBorderStyle = formBorderStyle_0;
				ParentForm.TransparencyKey = color_0;
				if (!DesignMode)
				{
					ParentForm.Shown += method_1;
				}
			}
			Parent.BackColor = BackColor;
		}
		vmethod_0();
		bool_0 = true;
		method_17();
	}

	private void method_0(bool bool_16)
	{
		vmethod_1();
		if (bool_16)
		{
			Invalidate();
		}
	}

	protected sealed override void OnPaint(PaintEventArgs e)
	{
		if (Width != 0 && Height != 0)
		{
			if (bool_12 && bool_14)
			{
				PaintHook();
				e.Graphics.DrawImage(bitmap_0, 0, 0);
			}
			else
			{
				graphics_0 = e.Graphics;
				PaintHook();
			}
		}
	}

	protected override void OnHandleDestroyed(EventArgs e)
	{
		Class10.smethod_3(method_0);
		base.OnHandleDestroyed(e);
	}

	private void method_1(object sender, EventArgs e)
	{
		checked
		{
			if (!bool_14 && !bool_1)
			{
				if (formStartPosition_0 == FormStartPosition.CenterParent || formStartPosition_0 == FormStartPosition.CenterScreen)
				{
					Rectangle bounds = Screen.PrimaryScreen.Bounds;
					Rectangle bounds2 = ParentForm.Bounds;
					Point point2 = (ParentForm.Location = new Point(unchecked(bounds.Width / 2) - unchecked(bounds2.Width / 2), unchecked(bounds.Height / 2) - unchecked(bounds2.Width / 2)));
				}
				bool_1 = true;
			}
		}
	}

	protected sealed override void OnSizeChanged(EventArgs e)
	{
		if (bool_9 && !bool_14)
		{
			ref Rectangle reference = ref rectangle_0;
			reference = checked(new Rectangle(7, 7, Width - 14, int_4 - 7));
		}
		method_15();
		Invalidate();
		base.OnSizeChanged(e);
	}

	protected override void SetBoundsCore(int x, int y, int width, int height, BoundsSpecified specified)
	{
		if (int_2 != 0)
		{
			width = int_2;
		}
		if (int_3 != 0)
		{
			height = int_3;
		}
		base.SetBoundsCore(x, y, width, height, specified);
	}

	private void method_2(Enum1 enum1_1)
	{
		enum1_0 = enum1_1;
		Invalidate();
	}

	protected override void OnMouseMove(MouseEventArgs e)
	{
		if ((!bool_13 || ParentForm.WindowState != FormWindowState.Maximized) && bool_10 && !bool_14)
		{
			method_4();
		}
		base.OnMouseMove(e);
	}

	protected override void OnEnabledChanged(EventArgs e)
	{
		if (Enabled)
		{
			method_2(Enum1.None);
		}
		else
		{
			method_2(Enum1.Block);
		}
		base.OnEnabledChanged(e);
	}

	protected override void OnMouseEnter(EventArgs e)
	{
		method_2(Enum1.Over);
		base.OnMouseEnter(e);
	}

	protected override void OnMouseUp(MouseEventArgs e)
	{
		method_2(Enum1.Over);
		base.OnMouseUp(e);
	}

	protected override void OnMouseLeave(EventArgs e)
	{
		method_2(Enum1.None);
		if (GetChildAtPoint(PointToClient(Control.MousePosition)) != null && bool_10 && !bool_14)
		{
			Cursor = Cursors.Default;
			int_1 = 0;
		}
		base.OnMouseLeave(e);
	}

	protected override void OnMouseDown(MouseEventArgs e)
	{
		if (e.Button == MouseButtons.Left)
		{
			method_2(Enum1.Down);
		}
		if ((!bool_13 || ParentForm.WindowState != FormWindowState.Maximized) && !bool_14)
		{
			if (bool_9 && rectangle_0.Contains(e.Location))
			{
				Capture = false;
				bool_2 = true;
				DefWndProc(ref message_0[0]);
			}
			else if (bool_10 && int_1 != 0)
			{
				Capture = false;
				bool_2 = true;
				DefWndProc(ref message_0[int_1]);
			}
		}
		base.OnMouseDown(e);
	}

	protected override void WndProc(ref Message m)
	{
		base.WndProc(ref m);
		if (!bool_2 || m.Msg != 513)
		{
			return;
		}
		bool_2 = false;
		method_2(Enum1.Over);
		if (bool_8)
		{
			if (Boolean_6)
			{
				Rectangle rectangle_ = new Rectangle(Point.Empty, Parent.Parent.Size);
				method_6(rectangle_);
			}
			else
			{
				method_6(Screen.FromControl(Parent).WorkingArea);
			}
		}
	}

	private int method_3()
	{
		point_0 = PointToClient(Control.MousePosition);
		bool_3 = point_0.X < 7;
		checked
		{
			bool_4 = point_0.X > Width - 7;
			bool_5 = point_0.Y < 7;
			bool_6 = point_0.Y > Height - 7;
			if (bool_3 && bool_5)
			{
				return 4;
			}
			if (bool_3 && bool_6)
			{
				return 7;
			}
			if (bool_4 && bool_5)
			{
				return 5;
			}
			if (bool_4 && bool_6)
			{
				return 8;
			}
			if (bool_3)
			{
				return 1;
			}
			if (bool_4)
			{
				return 2;
			}
			if (bool_5)
			{
				return 3;
			}
			if (bool_6)
			{
				return 6;
			}
			return 0;
		}
	}

	private void method_4()
	{
		int_0 = method_3();
		if (int_0 != int_1)
		{
			int_1 = int_0;
			switch (int_1)
			{
			case 0:
				Cursor = Cursors.Default;
				break;
			case 1:
			case 2:
				Cursor = Cursors.SizeWE;
				break;
			case 3:
			case 6:
				Cursor = Cursors.SizeNS;
				break;
			case 5:
			case 7:
				Cursor = Cursors.SizeNESW;
				break;
			case 4:
			case 8:
				Cursor = Cursors.SizeNWSE;
				break;
			}
		}
	}

	private void method_5()
	{
		ref Message reference = ref message_0[0];
		IntPtr handle = Parent.Handle;
		IntPtr wparam = new IntPtr(2);
		reference = Message.Create(handle, 161, wparam, IntPtr.Zero);
		int num = 1;
		checked
		{
			do
			{
				ref Message reference2 = ref message_0[num];
				IntPtr handle2 = Parent.Handle;
				wparam = new IntPtr(num + 9);
				reference2 = Message.Create(handle2, 161, wparam, IntPtr.Zero);
				num++;
			}
			while (num <= 8);
		}
	}

	private void method_6(Rectangle rectangle_5)
	{
		if (Parent.Width > rectangle_5.Width)
		{
			Parent.Width = rectangle_5.Width;
		}
		if (Parent.Height > rectangle_5.Height)
		{
			Parent.Height = rectangle_5.Height;
		}
		int num = Parent.Location.X;
		int num2 = Parent.Location.Y;
		if (num < rectangle_5.X)
		{
			num = rectangle_5.X;
		}
		if (num2 < rectangle_5.Y)
		{
			num2 = rectangle_5.Y;
		}
		checked
		{
			int num3 = rectangle_5.X + rectangle_5.Width;
			int num4 = rectangle_5.Y + rectangle_5.Height;
			if (num + Parent.Width > num3)
			{
				num = num3 - Parent.Width;
			}
			if (num2 + Parent.Height > num4)
			{
				num2 = num4 - Parent.Height;
			}
			Point point2 = (Parent.Location = new Point(num, num2));
		}
	}

	protected Pen method_7(string string_1)
	{
		return new Pen(dictionary_0[string_1]);
	}

	protected Pen method_8(string string_1, float float_0)
	{
		return new Pen(dictionary_0[string_1], float_0);
	}

	protected SolidBrush method_9(string string_1)
	{
		return new SolidBrush(dictionary_0[string_1]);
	}

	protected Color method_10(string string_1)
	{
		return dictionary_0[string_1];
	}

	protected void method_11(string string_1, Color color_1)
	{
		if (dictionary_0.ContainsKey(string_1))
		{
			dictionary_0[string_1] = color_1;
		}
		else
		{
			dictionary_0.Add(string_1, color_1);
		}
	}

	protected void method_12(string string_1, byte byte_0, byte byte_1, byte byte_2)
	{
		method_11(string_1, Color.FromArgb(byte_0, byte_1, byte_2));
	}

	protected void method_13(string string_1, byte byte_0, byte byte_1, byte byte_2, byte byte_3)
	{
		method_11(string_1, Color.FromArgb(byte_0, byte_1, byte_2, byte_3));
	}

	protected void method_14(string string_1, byte byte_0, Color color_1)
	{
		method_11(string_1, Color.FromArgb(byte_0, color_1));
	}

	private void method_15()
	{
		if (bool_12 && bool_14)
		{
			if (Width != 0 && Height != 0)
			{
				bitmap_0 = new Bitmap(Width, Height, PixelFormat.Format32bppPArgb);
				graphics_0 = Graphics.FromImage(bitmap_0);
			}
		}
		else
		{
			graphics_0 = null;
			bitmap_0 = null;
		}
	}

	private void method_16()
	{
		MemoryStream memoryStream = new MemoryStream(checked(dictionary_0.Count * 4));
		Struct0[] struct0_ = Struct0_0;
		foreach (Struct0 @struct in struct0_)
		{
			memoryStream.Write(BitConverter.GetBytes(@struct.Color_0.ToArgb()), 0, 4);
		}
		memoryStream.Close();
		string_0 = Convert.ToBase64String(memoryStream.ToArray());
	}

	private void method_17()
	{
		if (!DesignMode && bool_0)
		{
			if (bool_15)
			{
				Class10.smethod_2(method_0);
			}
			else
			{
				Class10.smethod_3(method_0);
			}
		}
	}

	protected abstract void ColorHook();

	protected abstract void PaintHook();

	protected virtual void vmethod_0()
	{
	}

	protected virtual void vmethod_1()
	{
	}

	protected Rectangle method_18(Rectangle rectangle_5, int int_5)
	{
		ref Rectangle reference = ref rectangle_1;
		reference = checked(new Rectangle(rectangle_5.X + int_5, rectangle_5.Y + int_5, rectangle_5.Width - int_5 * 2, rectangle_5.Height - int_5 * 2));
		return rectangle_1;
	}

	protected Size method_19(Size size_3, int int_5)
	{
		ref Size reference = ref size_1;
		reference = checked(new Size(size_3.Width + int_5, size_3.Height + int_5));
		return size_1;
	}

	protected Point method_20(Point point_5, int int_5)
	{
		ref Point reference = ref point_1;
		reference = checked(new Point(point_5.X + int_5, point_5.Y + int_5));
		return point_1;
	}

	protected Point method_21(Rectangle rectangle_5, Rectangle rectangle_6)
	{
		ref Point reference = ref point_2;
		checked
		{
			reference = new Point(unchecked(rectangle_5.Width / 2) - unchecked(rectangle_6.Width / 2) + rectangle_5.X + rectangle_6.X, unchecked(rectangle_5.Height / 2) - unchecked(rectangle_6.Height / 2) + rectangle_5.Y + rectangle_6.Y);
			return point_2;
		}
	}

	protected Point method_22(Rectangle rectangle_5, Size size_3)
	{
		ref Point reference = ref point_2;
		checked
		{
			reference = new Point(unchecked(rectangle_5.Width / 2) - unchecked(size_3.Width / 2) + rectangle_5.X, unchecked(rectangle_5.Height / 2) - unchecked(size_3.Height / 2) + rectangle_5.Y);
			return point_2;
		}
	}

	protected Point method_23(Rectangle rectangle_5)
	{
		return method_27(Width, Height, rectangle_5.Width, rectangle_5.Height);
	}

	protected Point method_24(Size size_3)
	{
		return method_27(Width, Height, size_3.Width, size_3.Height);
	}

	protected Point method_25(int int_5, int int_6)
	{
		return method_27(Width, Height, int_5, int_6);
	}

	protected Point method_26(Size size_3, Size size_4)
	{
		return method_27(size_3.Width, size_3.Height, size_4.Width, size_4.Height);
	}

	protected Point method_27(int int_5, int int_6, int int_7, int int_8)
	{
		ref Point reference = ref point_2;
		checked
		{
			reference = new Point(unchecked(int_5 / 2) - unchecked(int_7 / 2), unchecked(int_6 / 2) - unchecked(int_8 / 2));
			return point_2;
		}
	}

	protected Size method_28()
	{
		lock (graphics_1)
		{
			return graphics_1.MeasureString(Text, Font, Width).ToSize();
		}
	}

	protected Size method_29(string string_1)
	{
		lock (graphics_1)
		{
			return graphics_1.MeasureString(string_1, Font, Width).ToSize();
		}
	}

	protected void method_30(Color color_1, int int_5, int int_6)
	{
		if (bool_12)
		{
			bitmap_0.SetPixel(int_5, int_6, color_1);
			return;
		}
		solidBrush_0 = new SolidBrush(color_1);
		graphics_0.FillRectangle(solidBrush_0, int_5, int_6, 1, 1);
	}

	protected void method_31(Color color_1, int int_5)
	{
		method_33(color_1, 0, 0, Width, Height, int_5);
	}

	protected void method_32(Color color_1, Rectangle rectangle_5, int int_5)
	{
		method_33(color_1, rectangle_5.X, rectangle_5.Y, rectangle_5.Width, rectangle_5.Height, int_5);
	}

	protected void method_33(Color color_1, int int_5, int int_6, int int_7, int int_8, int int_9)
	{
		checked
		{
			method_36(color_1, int_5 + int_9, int_6 + int_9, int_7 - int_9 * 2, int_8 - int_9 * 2);
		}
	}

	protected void method_34(Color color_1)
	{
		method_36(color_1, 0, 0, Width, Height);
	}

	protected void method_35(Color color_1, Rectangle rectangle_5)
	{
		method_36(color_1, rectangle_5.X, rectangle_5.Y, rectangle_5.Width, rectangle_5.Height);
	}

	protected void method_36(Color color_1, int int_5, int int_6, int int_7, int int_8)
	{
		checked
		{
			if (!bool_11)
			{
				if (bool_12)
				{
					bitmap_0.SetPixel(int_5, int_6, color_1);
					bitmap_0.SetPixel(int_5 + (int_7 - 1), int_6, color_1);
					bitmap_0.SetPixel(int_5, int_6 + (int_8 - 1), color_1);
					bitmap_0.SetPixel(int_5 + (int_7 - 1), int_6 + (int_8 - 1), color_1);
				}
				else
				{
					solidBrush_1 = new SolidBrush(color_1);
					graphics_0.FillRectangle(solidBrush_1, int_5, int_6, 1, 1);
					graphics_0.FillRectangle(solidBrush_1, int_5 + (int_7 - 1), int_6, 1, 1);
					graphics_0.FillRectangle(solidBrush_1, int_5, int_6 + (int_8 - 1), 1, 1);
					graphics_0.FillRectangle(solidBrush_1, int_5 + (int_7 - 1), int_6 + (int_8 - 1), 1, 1);
				}
			}
		}
	}

	protected void method_37(Pen pen_0, int int_5)
	{
		method_39(pen_0, 0, 0, Width, Height, int_5);
	}

	protected void method_38(Pen pen_0, Rectangle rectangle_5, int int_5)
	{
		method_39(pen_0, rectangle_5.X, rectangle_5.Y, rectangle_5.Width, rectangle_5.Height, int_5);
	}

	protected void method_39(Pen pen_0, int int_5, int int_6, int int_7, int int_8, int int_9)
	{
		checked
		{
			method_42(pen_0, int_5 + int_9, int_6 + int_9, int_7 - int_9 * 2, int_8 - int_9 * 2);
		}
	}

	protected void method_40(Pen pen_0)
	{
		method_42(pen_0, 0, 0, Width, Height);
	}

	protected void method_41(Pen pen_0, Rectangle rectangle_5)
	{
		method_42(pen_0, rectangle_5.X, rectangle_5.Y, rectangle_5.Width, rectangle_5.Height);
	}

	protected void method_42(Pen pen_0, int int_5, int int_6, int int_7, int int_8)
	{
		checked
		{
			graphics_0.DrawRectangle(pen_0, int_5, int_6, int_7 - 1, int_8 - 1);
		}
	}

	protected void method_43(Brush brush_0, HorizontalAlignment horizontalAlignment_0, int int_5, int int_6)
	{
		method_44(brush_0, Text, horizontalAlignment_0, int_5, int_6);
	}

	protected void method_44(Brush brush_0, string string_1, HorizontalAlignment horizontalAlignment_0, int int_5, int int_6)
	{
		checked
		{
			if (string_1.Length != 0)
			{
				size_2 = method_29(string_1);
				ref Point reference = ref point_3;
				reference = new Point(unchecked(Width / 2) - unchecked(size_2.Width / 2), unchecked(Int32_2 / 2) - unchecked(size_2.Height / 2));
				switch (horizontalAlignment_0)
				{
				case HorizontalAlignment.Left:
					graphics_0.DrawString(string_1, Font, brush_0, int_5, point_3.Y + int_6);
					break;
				case HorizontalAlignment.Right:
					graphics_0.DrawString(string_1, Font, brush_0, Width - size_2.Width - int_5, point_3.Y + int_6);
					break;
				case HorizontalAlignment.Center:
					graphics_0.DrawString(string_1, Font, brush_0, point_3.X + int_5, point_3.Y + int_6);
					break;
				}
			}
		}
	}

	protected void method_45(Brush brush_0, Point point_5)
	{
		if (Text.Length != 0)
		{
			graphics_0.DrawString(Text, Font, brush_0, point_5);
		}
	}

	protected void method_46(Brush brush_0, int int_5, int int_6)
	{
		if (Text.Length != 0)
		{
			graphics_0.DrawString(Text, Font, brush_0, int_5, int_6);
		}
	}

	protected void method_47(HorizontalAlignment horizontalAlignment_0, int int_5, int int_6)
	{
		method_48(image_0, horizontalAlignment_0, int_5, int_6);
	}

	protected void method_48(Image image_1, HorizontalAlignment horizontalAlignment_0, int int_5, int int_6)
	{
		checked
		{
			if (image_1 != null)
			{
				ref Point reference = ref point_4;
				reference = new Point(unchecked(Width / 2) - unchecked(image_1.Width / 2), unchecked(Int32_2 / 2) - unchecked(image_1.Height / 2));
				switch (horizontalAlignment_0)
				{
				case HorizontalAlignment.Left:
					graphics_0.DrawImage(image_1, int_5, point_4.Y + int_6, image_1.Width, image_1.Height);
					break;
				case HorizontalAlignment.Right:
					graphics_0.DrawImage(image_1, Width - image_1.Width - int_5, point_4.Y + int_6, image_1.Width, image_1.Height);
					break;
				case HorizontalAlignment.Center:
					graphics_0.DrawImage(image_1, point_4.X + int_5, point_4.Y + int_6, image_1.Width, image_1.Height);
					break;
				}
			}
		}
	}

	protected void method_49(Point point_5)
	{
		method_52(image_0, point_5.X, point_5.Y);
	}

	protected void method_50(int int_5, int int_6)
	{
		method_52(image_0, int_5, int_6);
	}

	protected void method_51(Image image_1, Point point_5)
	{
		method_52(image_1, point_5.X, point_5.Y);
	}

	protected void method_52(Image image_1, int int_5, int int_6)
	{
		if (image_1 != null)
		{
			graphics_0.DrawImage(image_1, int_5, int_6, image_1.Width, image_1.Height);
		}
	}

	protected void method_53(ColorBlend colorBlend_0, int int_5, int int_6, int int_7, int int_8)
	{
		ref Rectangle reference = ref rectangle_2;
		reference = new Rectangle(int_5, int_6, int_7, int_8);
		method_55(colorBlend_0, rectangle_2);
	}

	protected void method_54(ColorBlend colorBlend_0, int int_5, int int_6, int int_7, int int_8, float float_0)
	{
		ref Rectangle reference = ref rectangle_2;
		reference = new Rectangle(int_5, int_6, int_7, int_8);
		method_56(colorBlend_0, rectangle_2, float_0);
	}

	protected void method_55(ColorBlend colorBlend_0, Rectangle rectangle_5)
	{
		linearGradientBrush_0 = new LinearGradientBrush(rectangle_5, Color.Empty, Color.Empty, 90f);
		linearGradientBrush_0.InterpolationColors = colorBlend_0;
		graphics_0.FillRectangle(linearGradientBrush_0, rectangle_5);
	}

	protected void method_56(ColorBlend colorBlend_0, Rectangle rectangle_5, float float_0)
	{
		linearGradientBrush_0 = new LinearGradientBrush(rectangle_5, Color.Empty, Color.Empty, float_0);
		linearGradientBrush_0.InterpolationColors = colorBlend_0;
		graphics_0.FillRectangle(linearGradientBrush_0, rectangle_5);
	}

	protected void method_57(Color color_1, Color color_2, int int_5, int int_6, int int_7, int int_8)
	{
		ref Rectangle reference = ref rectangle_2;
		reference = new Rectangle(int_5, int_6, int_7, int_8);
		method_59(color_1, color_2, rectangle_2);
	}

	protected void method_58(Color color_1, Color color_2, int int_5, int int_6, int int_7, int int_8, float float_0)
	{
		ref Rectangle reference = ref rectangle_2;
		reference = new Rectangle(int_5, int_6, int_7, int_8);
		method_60(color_1, color_2, rectangle_2, float_0);
	}

	protected void method_59(Color color_1, Color color_2, Rectangle rectangle_5)
	{
		linearGradientBrush_0 = new LinearGradientBrush(rectangle_5, color_1, color_2, 90f);
		graphics_0.FillRectangle(linearGradientBrush_0, rectangle_5);
	}

	protected void method_60(Color color_1, Color color_2, Rectangle rectangle_5, float float_0)
	{
		linearGradientBrush_0 = new LinearGradientBrush(rectangle_5, color_1, color_2, float_0);
		graphics_0.FillRectangle(linearGradientBrush_0, rectangle_5);
	}

	public void method_61(ColorBlend colorBlend_0, int int_5, int int_6, int int_7, int int_8)
	{
		ref Rectangle reference = ref rectangle_3;
		reference = new Rectangle(int_5, int_6, int_7, int_8);
		method_66(colorBlend_0, rectangle_3, int_7 / 2, int_8 / 2);
	}

	public void method_62(ColorBlend colorBlend_0, int int_5, int int_6, int int_7, int int_8, Point point_5)
	{
		ref Rectangle reference = ref rectangle_3;
		reference = new Rectangle(int_5, int_6, int_7, int_8);
		method_66(colorBlend_0, rectangle_3, point_5.X, point_5.Y);
	}

	public void method_63(ColorBlend colorBlend_0, int int_5, int int_6, int int_7, int int_8, int int_9, int int_10)
	{
		ref Rectangle reference = ref rectangle_3;
		reference = new Rectangle(int_5, int_6, int_7, int_8);
		method_66(colorBlend_0, rectangle_3, int_9, int_10);
	}

	public void method_64(ColorBlend colorBlend_0, Rectangle rectangle_5)
	{
		method_66(colorBlend_0, rectangle_5, rectangle_5.Width / 2, rectangle_5.Height / 2);
	}

	public void method_65(ColorBlend colorBlend_0, Rectangle rectangle_5, Point point_5)
	{
		method_66(colorBlend_0, rectangle_5, point_5.X, point_5.Y);
	}

	public void method_66(ColorBlend colorBlend_0, Rectangle rectangle_5, int int_5, int int_6)
	{
		graphicsPath_0.Reset();
		checked
		{
			graphicsPath_0.AddEllipse(rectangle_5.X, rectangle_5.Y, rectangle_5.Width - 1, rectangle_5.Height - 1);
			pathGradientBrush_0 = new PathGradientBrush(graphicsPath_0);
			PathGradientBrush pathGradientBrush = pathGradientBrush_0;
			Point point = new Point(rectangle_5.X + int_5, rectangle_5.Y + int_6);
			pathGradientBrush.CenterPoint = point;
			pathGradientBrush_0.InterpolationColors = colorBlend_0;
			if (graphics_0.SmoothingMode == SmoothingMode.AntiAlias)
			{
				graphics_0.FillEllipse(pathGradientBrush_0, rectangle_5.X + 1, rectangle_5.Y + 1, rectangle_5.Width - 3, rectangle_5.Height - 3);
			}
			else
			{
				graphics_0.FillEllipse(pathGradientBrush_0, rectangle_5);
			}
		}
	}

	protected void method_67(Color color_1, Color color_2, int int_5, int int_6, int int_7, int int_8)
	{
		ref Rectangle reference = ref rectangle_3;
		reference = new Rectangle(int_5, int_6, int_7, int_8);
		method_69(color_1, color_2, rectangle_2);
	}

	protected void method_68(Color color_1, Color color_2, int int_5, int int_6, int int_7, int int_8, float float_0)
	{
		ref Rectangle reference = ref rectangle_3;
		reference = new Rectangle(int_5, int_6, int_7, int_8);
		method_70(color_1, color_2, rectangle_2, float_0);
	}

	protected void method_69(Color color_1, Color color_2, Rectangle rectangle_5)
	{
		linearGradientBrush_1 = new LinearGradientBrush(rectangle_5, color_1, color_2, 90f);
		graphics_0.FillRectangle(linearGradientBrush_0, rectangle_5);
	}

	protected void method_70(Color color_1, Color color_2, Rectangle rectangle_5, float float_0)
	{
		linearGradientBrush_1 = new LinearGradientBrush(rectangle_5, color_1, color_2, float_0);
		graphics_0.FillEllipse(linearGradientBrush_0, rectangle_5);
	}

	public GraphicsPath method_71(int int_5, int int_6, int int_7, int int_8, int int_9)
	{
		ref Rectangle reference = ref rectangle_4;
		reference = new Rectangle(int_5, int_6, int_7, int_8);
		return method_72(rectangle_4, int_9);
	}

	public GraphicsPath method_72(Rectangle rectangle_5, int int_5)
	{
		graphicsPath_1 = new GraphicsPath(FillMode.Winding);
		graphicsPath_1.AddArc(rectangle_5.X, rectangle_5.Y, int_5, int_5, 180f, 90f);
		checked
		{
			graphicsPath_1.AddArc(rectangle_5.Right - int_5, rectangle_5.Y, int_5, int_5, 270f, 90f);
			graphicsPath_1.AddArc(rectangle_5.Right - int_5, rectangle_5.Bottom - int_5, int_5, int_5, 0f, 90f);
			graphicsPath_1.AddArc(rectangle_5.X, rectangle_5.Bottom - int_5, int_5, int_5, 90f, 90f);
			graphicsPath_1.CloseFigure();
			return graphicsPath_1;
		}
	}
}
