using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

internal class Control22 : Control12
{
	[DebuggerNonUserCode]
	public Control22()
	{
	}

	protected override void ColorHook()
	{
	}

	protected override void PaintHook()
	{
		graphics_0.SmoothingMode = SmoothingMode.HighQuality;
		graphics_0.Clear(Color.White);
		checked
		{
			switch (enum1_0)
			{
			case Enum1.None:
			{
				Rectangle rect = new Rectangle(0, 0, Width, (int)Math.Round((double)Height / 2.0));
				LinearGradientBrush brush3 = new LinearGradientBrush(rect, Color.FromArgb(100, Color.FromArgb(207, 207, 207)), Color.FromArgb(250, 250, 250), 90f);
				GraphicsPath graphicsPath3 = new GraphicsPath();
				graphicsPath3 = method_66(0, 0, Width - 1, Height - 1, 7);
				graphics_0.FillPath(brush3, graphicsPath3);
				graphics_0.DrawPath(new Pen(Color.FromArgb(105, 112, 115)), graphicsPath3);
				graphics_0.SetClip(graphicsPath3);
				GraphicsPath path3 = method_66(1, 1, Width - 3, Height - 3, 7);
				graphics_0.DrawPath(new Pen(Color.White, 1f), path3);
				graphics_0.ResetClip();
				method_38(new SolidBrush(Color.FromArgb(1, 75, 124)), HorizontalAlignment.Left, 5, 1);
				break;
			}
			case Enum1.Over:
			{
				Rectangle rect = new Rectangle(0, 0, Width, (int)Math.Round((double)Height / 2.0));
				LinearGradientBrush brush2 = new LinearGradientBrush(rect, Color.FromArgb(100, Color.FromArgb(207, 207, 207)), Color.FromArgb(250, 250, 250), 90f);
				GraphicsPath graphicsPath2 = new GraphicsPath();
				graphicsPath2 = method_66(0, 0, Width - 1, Height - 1, 7);
				graphics_0.FillPath(brush2, graphicsPath2);
				graphics_0.DrawPath(new Pen(Color.FromArgb(105, 112, 115)), graphicsPath2);
				graphics_0.SetClip(graphicsPath2);
				GraphicsPath path2 = method_66(1, 1, Width - 3, Height - 3, 7);
				graphics_0.DrawPath(new Pen(Color.FromArgb(50, Color.Gray), 1f), path2);
				graphics_0.ResetClip();
				method_38(new SolidBrush(Color.FromArgb(1, 75, 124)), HorizontalAlignment.Left, 5, 1);
				break;
			}
			case Enum1.Down:
			{
				Rectangle rect = new Rectangle(0, 0, Width, (int)Math.Round((double)Height / 2.0));
				LinearGradientBrush brush = new LinearGradientBrush(rect, Color.FromArgb(100, Color.FromArgb(207, 207, 207)), Color.FromArgb(250, 250, 250), 90f);
				GraphicsPath graphicsPath = new GraphicsPath();
				graphicsPath = method_66(0, 0, Width - 1, Height - 1, 7);
				graphics_0.FillPath(brush, graphicsPath);
				graphics_0.DrawPath(new Pen(Color.FromArgb(105, 112, 115)), graphicsPath);
				graphics_0.SetClip(graphicsPath);
				GraphicsPath path = method_66(1, 1, Width - 3, Height - 3, 7);
				graphics_0.DrawPath(new Pen(Color.White, 1f), path);
				graphics_0.ResetClip();
				method_38(new SolidBrush(Color.FromArgb(86, 161, 196)), HorizontalAlignment.Left, 5, 1);
				break;
			}
			}
		}
	}
}
