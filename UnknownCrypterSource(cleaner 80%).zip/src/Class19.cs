using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using Microsoft.VisualBasic.CompilerServices;

[StandardModule]
internal sealed class Class19
{
	public static GraphicsPath smethod_0(Rectangle rectangle_0, int int_0)
	{
		GraphicsPath graphicsPath = new GraphicsPath();
		checked
		{
			int num = int_0 * 2;
			Rectangle rect = new Rectangle(rectangle_0.X, rectangle_0.Y, num, num);
			graphicsPath.AddArc(rect, -180f, 90f);
			rect = new Rectangle(rectangle_0.Width - num + rectangle_0.X, rectangle_0.Y, num, num);
			graphicsPath.AddArc(rect, -90f, 90f);
			rect = new Rectangle(rectangle_0.Width - num + rectangle_0.X, rectangle_0.Height - num + rectangle_0.Y, num, num);
			graphicsPath.AddArc(rect, 0f, 90f);
			rect = new Rectangle(rectangle_0.X, rectangle_0.Height - num + rectangle_0.Y, num, num);
			graphicsPath.AddArc(rect, 90f, 90f);
			Point pt = new Point(rectangle_0.X, rectangle_0.Height - num + rectangle_0.Y);
			Point pt2 = new Point(rectangle_0.X, int_0 + rectangle_0.Y);
			graphicsPath.AddLine(pt, pt2);
			return graphicsPath;
		}
	}

	public static GraphicsPath smethod_1(int int_0, int int_1, int int_2, int int_3, int int_4)
	{
		Rectangle rectangle = new Rectangle(int_0, int_1, int_2, int_3);
		GraphicsPath graphicsPath = new GraphicsPath();
		checked
		{
			int num = int_4 * 2;
			Rectangle rect = new Rectangle(rectangle.X, rectangle.Y, num, num);
			graphicsPath.AddArc(rect, -180f, 90f);
			rect = new Rectangle(rectangle.Width - num + rectangle.X, rectangle.Y, num, num);
			graphicsPath.AddArc(rect, -90f, 90f);
			rect = new Rectangle(rectangle.Width - num + rectangle.X, rectangle.Height - num + rectangle.Y, num, num);
			graphicsPath.AddArc(rect, 0f, 90f);
			rect = new Rectangle(rectangle.X, rectangle.Height - num + rectangle.Y, num, num);
			graphicsPath.AddArc(rect, 90f, 90f);
			Point pt = new Point(rectangle.X, rectangle.Height - num + rectangle.Y);
			Point pt2 = new Point(rectangle.X, int_4 + rectangle.Y);
			graphicsPath.AddLine(pt, pt2);
			return graphicsPath;
		}
	}

	private static Image smethod_2(ref string string_0)
	{
		byte[] array = Convert.FromBase64String(string_0);
		MemoryStream memoryStream = new MemoryStream(array, 0, array.Length);
		memoryStream.Write(array, 0, array.Length);
		return Image.FromStream(memoryStream, useEmbeddedColorManagement: true);
	}

	public static TextureBrush smethod_3(string string_0)
	{
		return new TextureBrush(smethod_2(ref string_0), WrapMode.Tile);
	}
}
