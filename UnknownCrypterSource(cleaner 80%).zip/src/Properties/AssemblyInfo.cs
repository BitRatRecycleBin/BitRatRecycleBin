using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyCompany("Unknown Inc")]
[assembly: Guid("8a0479e7-545f-4a3f-8b16-d6140cf6c573")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCopyright("Copyright ©  2019")]
[assembly: AssemblyProduct("UnknownCrypter")]
[assembly: ComVisible(false)]
[assembly: AssemblyFileVersion("2.0.0.0")]
[assembly: AssemblyDescription("Best Java and JS Crypter")]
[assembly: AssemblyTitle("UnknownCrypter")]
[assembly: AssemblyVersion("2.0.0.0")]
