using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

public class GClass3 : ComboBox
{
	private static List<WeakReference> list_0 = new List<WeakReference>();

	private int int_0;

	private int Int32_0
	{
		get
		{
			return int_0;
		}
		set
		{
			int_0 = value;
			try
			{
				base.SelectedIndex = value;
			}
			catch (Exception projectError)
			{
				ProjectData.SetProjectError(projectError);
				ProjectData.ClearProjectError();
			}
			Invalidate();
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	public void GClass3_DrawItem(object sender, DrawItemEventArgs e)
	{
		e.DrawBackground();
		try
		{
			if ((e.State & DrawItemState.Selected) == DrawItemState.Selected)
			{
				e.Graphics.FillRectangle(new SolidBrush(Color.FromArgb(59, 60, 64)), e.Bounds);
			}
			else
			{
				e.Graphics.FillRectangle(new SolidBrush(Color.FromArgb(49, 50, 54)), e.Bounds);
			}
			using SolidBrush brush = new SolidBrush(e.ForeColor);
			Graphics graphics = e.Graphics;
			string itemText = GetItemText(RuntimeHelpers.GetObjectValue(base.Items[e.Index]));
			Font font = e.Font;
			Rectangle rectangle = new Rectangle(e.Bounds.X, checked(e.Bounds.Y + 1), e.Bounds.Width, e.Bounds.Height);
			graphics.DrawString(itemText, font, brush, rectangle);
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			ProjectData.ClearProjectError();
		}
	}

	protected void method_0(Color color_0, Point point_0, Point point_1, Point point_2, Graphics graphics_0)
	{
		List<Point> list = new List<Point>();
		list.Add(point_0);
		list.Add(point_1);
		list.Add(point_2);
		graphics_0.FillPolygon(new SolidBrush(color_0), list.ToArray());
	}

	public GClass3()
	{
		base.DrawItem += GClass3_DrawItem;
		smethod_0(this);
		int_0 = 0;
		SetStyle(ControlStyles.AllPaintingInWmPaint, value: true);
		SetStyle(ControlStyles.ResizeRedraw, value: true);
		SetStyle(ControlStyles.UserPaint, value: true);
		SetStyle(ControlStyles.DoubleBuffer, value: true);
		SetStyle(ControlStyles.SupportsTransparentBackColor, value: true);
		DrawMode = DrawMode.OwnerDrawFixed;
		BackColor = Color.Transparent;
		ForeColor = Color.FromArgb(182, 179, 171);
		DropDownStyle = ComboBoxStyle.DropDownList;
		Int32_0 = 0;
		ItemHeight = 18;
		DoubleBuffered = true;
		Font = new Font("Arial", 8.25f, FontStyle.Bold);
	}

	protected override void OnResize(EventArgs e)
	{
		base.OnResize(e);
		Height = 26;
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Bitmap bitmap = new Bitmap(Width, Height);
		Graphics graphics = Graphics.FromImage(bitmap);
		graphics.Clear(BackColor);
		graphics.SmoothingMode = SmoothingMode.HighQuality;
		graphics.TextRenderingHint = TextRenderingHint.AntiAlias;
		SolidBrush brush = new SolidBrush(Color.FromArgb(49, 50, 54));
		checked
		{
			Rectangle rectangle_ = new Rectangle(0, 0, Width - 1, Height - 1);
			graphics.FillPath(brush, Class19.smethod_0(rectangle_, 4));
			rectangle_ = new Rectangle(0, 0, Width - 1, Height - 1);
			LinearGradientBrush brush2 = new LinearGradientBrush(rectangle_, Color.FromArgb(57, 62, 68), Color.FromArgb(42, 43, 47), 90f);
			rectangle_ = new Rectangle(0, 0, Width - 1, Height - 1);
			graphics.FillPath(brush2, Class19.smethod_0(rectangle_, 4));
			rectangle_ = new Rectangle(0, 0, Width - 1, Height - 2);
			graphics.SetClip(Class19.smethod_0(rectangle_, 4));
			rectangle_ = new Rectangle(Width - 17, 0, 17, Height - 2);
			LinearGradientBrush linearGradientBrush = new LinearGradientBrush(rectangle_, Color.FromArgb(75, 78, 87), Color.FromArgb(50, 51, 55), 90f);
			graphics.FillRectangle(linearGradientBrush, linearGradientBrush.Rectangle);
			graphics.ResetClip();
			rectangle_ = new Rectangle(0, 1, Width - 1, Height - 2);
			LinearGradientBrush brush3 = new LinearGradientBrush(rectangle_, Color.FromArgb(92, 97, 103), Color.Transparent, 90f);
			Pen pen = new Pen(brush3);
			rectangle_ = new Rectangle(0, 1, Width - 1, Height - 2);
			graphics.DrawPath(pen, Class19.smethod_0(rectangle_, 4));
			Pen pen2 = new Pen(Color.FromArgb(32, 33, 37));
			rectangle_ = new Rectangle(0, 0, Width - 1, Height - 1);
			graphics.DrawPath(pen2, Class19.smethod_0(rectangle_, 4));
			Color color_ = Color.FromArgb(22, 23, 28);
			Point point = new Point(Width - 12, 8);
			Point point_ = point;
			Point point2 = new Point(Width - 6, 8);
			Point point_2 = point2;
			Point point_3 = new Point(Width - 9, 5);
			method_0(color_, point_, point_2, point_3, graphics);
			Color color_2 = Color.FromArgb(22, 23, 28);
			point_3 = new Point(Width - 12, 14);
			Point point_4 = point_3;
			point2 = new Point(Width - 6, 14);
			Point point_5 = point2;
			point = new Point(Width - 9, 17);
			method_0(color_2, point_4, point_5, point, graphics);
			rectangle_ = new Rectangle(Width - 17, 0, 17, Height);
			graphics.SetClip(Class19.smethod_0(rectangle_, 4));
			rectangle_ = new Rectangle(1, 1, Width - 3, Height - 3);
			LinearGradientBrush brush4 = new LinearGradientBrush(rectangle_, Color.FromArgb(82, 85, 92), Color.FromArgb(66, 67, 72), 90f);
			Pen pen3 = new Pen(brush4);
			rectangle_ = new Rectangle(1, 1, Width - 3, Height - 3);
			graphics.DrawPath(pen3, Class19.smethod_0(rectangle_, 4));
			graphics.ResetClip();
			Pen pen4 = new Pen(Color.FromArgb(29, 37, 40));
			point_3 = new Point(Width - 17, 0);
			Point pt = point_3;
			point2 = new Point(Width - 17, Height - 2);
			graphics.DrawLine(pen4, pt, point2);
			Pen pen5 = new Pen(Color.FromArgb(85, 92, 98));
			point_3 = new Point(Width - 16, 1);
			Point pt2 = point_3;
			point2 = new Point(Width - 16, Height - 3);
			graphics.DrawLine(pen5, pt2, point2);
			try
			{
				string s = Text;
				Font font = Font;
				SolidBrush brush5 = new SolidBrush(Color.FromArgb(16, 20, 21));
				rectangle_ = new Rectangle(7, 0, Width - 1, Height - 1);
				graphics.DrawString(s, font, brush5, rectangle_, new StringFormat
				{
					LineAlignment = StringAlignment.Center,
					Alignment = StringAlignment.Near
				});
				string s2 = Text;
				Font font2 = Font;
				SolidBrush brush6 = new SolidBrush(Color.White);
				rectangle_ = new Rectangle(7, 1, Width - 1, Height - 1);
				graphics.DrawString(s2, font2, brush6, rectangle_, new StringFormat
				{
					LineAlignment = StringAlignment.Center,
					Alignment = StringAlignment.Near
				});
			}
			catch (Exception projectError)
			{
				ProjectData.SetProjectError(projectError);
				ProjectData.ClearProjectError();
			}
			NewLateBinding.LateCall(e.Graphics, null, "DrawImage", new object[3]
			{
				RuntimeHelpers.GetObjectValue(bitmap.Clone()),
				0,
				0
			}, null, null, null, IgnoreReturn: true);
			graphics.Dispose();
			bitmap.Dispose();
		}
	}
}
