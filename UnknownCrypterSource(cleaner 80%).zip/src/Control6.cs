using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

[DefaultEvent("CheckedChanged")]
internal class Control6 : Control
{
	public delegate void Delegate4(object sender);

	private static List<WeakReference> list_0 = new List<WeakReference>();

	private Delegate4 delegate4_0;

	private bool bool_0;

	public bool Boolean_0
	{
		get
		{
			return bool_0;
		}
		set
		{
			bool_0 = value;
			Invalidate();
		}
	}

	public event Delegate4 Event_0
	{
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		add
		{
			delegate4_0 = (Delegate4)Delegate.Combine(delegate4_0, value);
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		remove
		{
			delegate4_0 = (Delegate4)Delegate.Remove(delegate4_0, value);
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	public Control6()
	{
		smethod_0(this);
		SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		Size size2 = (Size = new Size(150, 20));
		ForeColor = Color.WhiteSmoke;
		Font = new Font("Segoe UI", 9f);
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		base.OnPaint(e);
		Size size2 = (Size = new Size(Size.Width, 20));
		Graphics graphics = e.Graphics;
		graphics.SmoothingMode = SmoothingMode.HighQuality;
		graphics.Clear(Parent.BackColor);
		checked
		{
			Rectangle rectangle = new Rectangle(0, 0, Height - 1, Height - 1);
			GraphicsPath path = Class7.smethod_0(rectangle, 4);
			LinearGradientBrush brush = new LinearGradientBrush(rectangle, Color.FromArgb(120, 120, 120), Color.FromArgb(100, 100, 100), 90f);
			graphics.FillPath(brush, path);
			graphics.DrawPath(new Pen(Color.FromArgb(50, 50, 50)), path);
			int num = (int)Math.Round((double)(Height - 1) / 2.0 - (double)(graphics.MeasureString(Text, Font).Height / 2f) + 1.0);
			string s = Text;
			Font font = Font;
			SolidBrush brush2 = new SolidBrush(ForeColor);
			Point point = new Point(Height - 1 + 4, num);
			graphics.DrawString(s, font, brush2, point);
			if (bool_0)
			{
				Font font2 = new Font("Marlett", 13f);
				SolidBrush brush3 = new SolidBrush(ForeColor);
				point = new Point(0, 2);
				graphics.DrawString("b", font2, brush3, point);
			}
		}
	}

	protected override void OnMouseDown(MouseEventArgs e)
	{
		base.OnMouseDown(e);
		Focus();
		if (bool_0)
		{
			bool_0 = false;
		}
		else
		{
			bool_0 = true;
		}
		delegate4_0?.Invoke(this);
		Invalidate();
	}
}
