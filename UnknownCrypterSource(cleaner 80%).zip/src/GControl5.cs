using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

public class GControl5 : Control
{
	private static List<WeakReference> list_0 = new List<WeakReference>();

	[AccessedThroughProperty("txtbox")]
	private RichTextBox richTextBox_0;

	private virtual RichTextBox RichTextBox_0
	{
		[DebuggerNonUserCode]
		get
		{
			return richTextBox_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			EventHandler value2 = delegate
			{
				method_0();
			};
			if (richTextBox_0 != null)
			{
				richTextBox_0.TextChanged -= value2;
			}
			richTextBox_0 = value;
			if (richTextBox_0 != null)
			{
				richTextBox_0.TextChanged += value2;
			}
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	protected override void OnPaintBackground(PaintEventArgs pevent)
	{
	}

	protected override void OnTextChanged(EventArgs e)
	{
		base.OnTextChanged(e);
		Invalidate();
	}

	protected override void OnBackColorChanged(EventArgs e)
	{
		base.OnBackColorChanged(e);
		RichTextBox_0.BackColor = BackColor;
		Invalidate();
	}

	protected override void OnForeColorChanged(EventArgs e)
	{
		base.OnForeColorChanged(e);
		RichTextBox_0.ForeColor = ForeColor;
		Invalidate();
	}

	protected override void OnSizeChanged(EventArgs e)
	{
		base.OnSizeChanged(e);
		Size size2 = (RichTextBox_0.Size = checked(new Size(Width - 10, Height - 11)));
	}

	protected override void OnFontChanged(EventArgs e)
	{
		base.OnFontChanged(e);
		RichTextBox_0.Font = Font;
	}

	protected override void OnGotFocus(EventArgs e)
	{
		base.OnGotFocus(e);
		RichTextBox_0.Focus();
	}

	public void method_0()
	{
		Text = RichTextBox_0.Text;
	}

	public void method_1()
	{
		RichTextBox_0.Text = Text;
	}

	public void method_2()
	{
		RichTextBox richTextBox = RichTextBox_0;
		richTextBox.Multiline = true;
		richTextBox.BackColor = BackColor;
		richTextBox.ForeColor = ForeColor;
		richTextBox.Text = string.Empty;
		richTextBox.BorderStyle = BorderStyle.None;
		Point point2 = (richTextBox.Location = new Point(3, 4));
		richTextBox.Font = new Font("Trebuchet MS", 8.25f, FontStyle.Bold);
		Size size2 = (richTextBox.Size = checked(new Size(Width - 10, Height - 10)));
		richTextBox = null;
		RichTextBox_0.Font = new Font("Trebuchet MS", 8.25f, FontStyle.Bold);
	}

	public GControl5()
	{
		base.TextChanged += delegate
		{
			method_1();
		};
		smethod_0(this);
		RichTextBox_0 = new RichTextBox();
		method_2();
		Controls.Add(RichTextBox_0);
		Text = "";
		BackColor = Color.FromArgb(36, 40, 42);
		ForeColor = Color.FromArgb(142, 152, 156);
		Size size2 = (Size = new Size(135, 35));
		DoubleBuffered = true;
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Bitmap bitmap = new Bitmap(Width, Height);
		Graphics graphics = Graphics.FromImage(bitmap);
		graphics.SmoothingMode = SmoothingMode.HighQuality;
		new Class18();
		checked
		{
			Rectangle rect = new Rectangle(0, 0, Width - 1, Height - 1);
			graphics.Clear(Color.FromArgb(36, 40, 42));
			graphics.DrawRectangle(new Pen(Color.FromArgb(30, 33, 35), 2f), rect);
			graphics.DrawLine(new Pen(Color.FromArgb(83, 90, 94)), Width - 1, 0, Width - 1, Height);
			graphics.DrawLine(new Pen(Color.FromArgb(83, 90, 94)), 0, Height - 1, Width - 1, Height - 1);
			NewLateBinding.LateCall(e.Graphics, null, "DrawImage", new object[3]
			{
				RuntimeHelpers.GetObjectValue(bitmap.Clone()),
				0,
				0
			}, null, null, null, IgnoreReturn: true);
			graphics.Dispose();
			bitmap.Dispose();
		}
	}

	[SpecialName]
	[CompilerGenerated]
	[DebuggerStepThrough]
	private void RichTextBox_0_TextChanged(object sender, EventArgs e)
	{
		method_0();
	}

	[SpecialName]
	[CompilerGenerated]
	[DebuggerStepThrough]
	private void GControl5_TextChanged(object sender, EventArgs e)
	{
		method_1();
	}
}
