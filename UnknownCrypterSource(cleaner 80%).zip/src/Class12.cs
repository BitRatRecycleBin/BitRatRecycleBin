using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

internal class Class12 : ComboBox
{
	private static List<WeakReference> list_0 = new List<WeakReference>();

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	public Class12()
	{
		smethod_0(this);
		SetStyle(ControlStyles.UserPaint | ControlStyles.Opaque | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		SetStyle(ControlStyles.Selectable, value: false);
		DrawMode = DrawMode.OwnerDrawFixed;
		DropDownStyle = ComboBoxStyle.DropDownList;
		DrawMode = DrawMode.OwnerDrawFixed;
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Graphics graphics = e.Graphics;
		graphics.Clear(Color.White);
		checked
		{
			Rectangle rectangle_ = new Rectangle(0, 0, Width - 1, Height - 1);
			GraphicsPath path = method_0(rectangle_, 5);
			rectangle_ = new Rectangle(1, 1, Width - 3, Height - 3);
			GraphicsPath path2 = method_0(rectangle_, 5);
			rectangle_ = new Rectangle(2, 2, Width - 5, Height - 5);
			GraphicsPath path3 = method_0(rectangle_, 5);
			graphics.SmoothingMode = SmoothingMode.HighQuality;
			graphics.FillPath(new SolidBrush(Color.FromArgb(250, 250, 250)), path3);
			graphics.DrawPath(new Pen(Color.FromArgb(60, Color.LightGray), 4f), path2);
			graphics.DrawPath(new Pen(Color.FromArgb(100, Color.FromArgb(15, 15, 15))), path);
			graphics.SmoothingMode = SmoothingMode.None;
			Rectangle rect = new Rectangle(Width - 26, 0, 1, Height);
			Rectangle rectangle = new Rectangle(Width - 27, 0, 2, Height);
			graphics.FillRectangle(new SolidBrush(Color.FromArgb(30, Color.FromArgb(1, 75, 124))), rect);
			graphics.DrawRectangle(new Pen(Color.FromArgb(60, Color.FromArgb(61, 113, 153))), rect);
			graphics.SmoothingMode = SmoothingMode.HighQuality;
			Pen pen = new Pen(Color.FromArgb(97, 152, 195));
			rectangle_ = new Rectangle(Width - 18, Height - 19, 8, 8);
			graphics.DrawArc(pen, rectangle_, 20f, 140f);
			Pen pen2 = new Pen(Color.LightGray);
			rectangle_ = new Rectangle(Width - 18, Height - 18, 8, 8);
			graphics.DrawArc(pen2, rectangle_, 10f, 160f);
			Pen pen3 = new Pen(Color.FromArgb(78, 121, 154), 1.5f);
			rectangle_ = new Rectangle(Width - 18, Height - 20, 8, 8);
			graphics.DrawArc(pen3, rectangle_, 20f, 140f);
			Pen pen4 = new Pen(Color.FromArgb(97, 152, 195));
			rectangle_ = new Rectangle(Width - 19, Height - 16, 10, 10);
			graphics.DrawArc(pen4, rectangle_, 20f, 140f);
			Pen pen5 = new Pen(Color.LightGray);
			rectangle_ = new Rectangle(Width - 19, Height - 15, 10, 10);
			graphics.DrawArc(pen5, rectangle_, 10f, 160f);
			Pen pen6 = new Pen(Color.FromArgb(78, 121, 154), 1.5f);
			rectangle_ = new Rectangle(Width - 19, Height - 17, 10, 10);
			graphics.DrawArc(pen6, rectangle_, 20f, 140f);
			graphics.SmoothingMode = SmoothingMode.None;
			graphics.DrawString(point: new PointF(3f, Height - 18), s: Text, font: Font, brush: new SolidBrush(Color.FromArgb(1, 75, 124)));
		}
	}

	protected override void OnDrawItem(DrawItemEventArgs e)
	{
		if ((e.State & DrawItemState.Selected) == DrawItemState.Selected)
		{
			e.Graphics.FillRectangle(Brushes.LightGray, e.Bounds);
		}
		else
		{
			e.Graphics.FillRectangle(new SolidBrush(Color.FromArgb(250, 250, 250)), e.Bounds);
		}
		if (e.Index != -1)
		{
			e.Graphics.DrawString(GetItemText(RuntimeHelpers.GetObjectValue(Items[e.Index])), e.Font, new SolidBrush(Color.FromArgb(1, 75, 124)), e.Bounds);
		}
	}

	public GraphicsPath method_0(Rectangle rectangle_0, int int_0)
	{
		GraphicsPath graphicsPath = new GraphicsPath();
		checked
		{
			int num = int_0 * 2;
			Rectangle rect = new Rectangle(rectangle_0.X, rectangle_0.Y, num, num);
			graphicsPath.AddArc(rect, -180f, 90f);
			rect = new Rectangle(rectangle_0.Width - num + rectangle_0.X, rectangle_0.Y, num, num);
			graphicsPath.AddArc(rect, -90f, 90f);
			rect = new Rectangle(rectangle_0.Width - num + rectangle_0.X, rectangle_0.Height - num + rectangle_0.Y, num, num);
			graphicsPath.AddArc(rect, 0f, 90f);
			rect = new Rectangle(rectangle_0.X, rectangle_0.Height - num + rectangle_0.Y, num, num);
			graphicsPath.AddArc(rect, 90f, 90f);
			Point pt = new Point(rectangle_0.X, rectangle_0.Height - num + rectangle_0.Y);
			Point pt2 = new Point(rectangle_0.X, int_0 + rectangle_0.Y);
			graphicsPath.AddLine(pt, pt2);
			return graphicsPath;
		}
	}
}
