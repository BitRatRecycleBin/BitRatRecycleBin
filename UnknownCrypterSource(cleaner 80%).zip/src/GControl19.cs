using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

[DefaultEvent("CheckedChanged")]
public class GControl19 : Control
{
	public delegate void GDelegate8(object sender);

	private static List<WeakReference> list_0 = new List<WeakReference>();

	private GEnum0 genum0_0;

	private bool bool_0;

	private GDelegate8 gdelegate8_0;

	public bool Boolean_0
	{
		get
		{
			return bool_0;
		}
		set
		{
			bool_0 = value;
			Invalidate();
		}
	}

	public event GDelegate8 Event_0
	{
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		add
		{
			gdelegate8_0 = (GDelegate8)Delegate.Combine(gdelegate8_0, value);
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		remove
		{
			gdelegate8_0 = (GDelegate8)Delegate.Remove(gdelegate8_0, value);
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	protected override void OnMouseEnter(EventArgs e)
	{
		base.OnMouseEnter(e);
		genum0_0 = GEnum0.Over;
		Invalidate();
	}

	protected override void OnMouseDown(MouseEventArgs e)
	{
		base.OnMouseDown(e);
		genum0_0 = GEnum0.Down;
		Invalidate();
	}

	protected override void OnMouseLeave(EventArgs e)
	{
		base.OnMouseLeave(e);
		genum0_0 = GEnum0.None;
		Invalidate();
	}

	protected override void OnMouseUp(MouseEventArgs e)
	{
		base.OnMouseUp(e);
		genum0_0 = GEnum0.Over;
		Invalidate();
	}

	protected override void OnTextChanged(EventArgs e)
	{
		base.OnTextChanged(e);
		Invalidate();
	}

	protected override void OnResize(EventArgs e)
	{
		base.OnResize(e);
		Size size2 = (Size = new Size(34, 21));
	}

	protected override void OnClick(EventArgs e)
	{
		bool_0 = !bool_0;
		gdelegate8_0?.Invoke(this);
		base.OnClick(e);
	}

	public GControl19()
	{
		smethod_0(this);
		genum0_0 = GEnum0.None;
		SetStyle(ControlStyles.UserPaint, value: true);
		SetStyle(ControlStyles.AllPaintingInWmPaint, value: true);
		SetStyle(ControlStyles.OptimizedDoubleBuffer, value: true);
		SetStyle(ControlStyles.SupportsTransparentBackColor, value: true);
		Size size2 = (Size = new Size(34, 21));
		BackColor = Color.Transparent;
		ForeColor = Color.White;
		DoubleBuffered = true;
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Bitmap bitmap = new Bitmap(Width, Height);
		Graphics graphics = Graphics.FromImage(bitmap);
		graphics.SmoothingMode = SmoothingMode.HighQuality;
		graphics.TextRenderingHint = TextRenderingHint.AntiAlias;
		checked
		{
			Rectangle rectangle = new Rectangle(0, 0, Height - 1, Height - 1);
			int int_ = 9;
			graphics.Clear(BackColor);
			graphics.Clear(Color.Transparent);
			SolidBrush brush = new SolidBrush(Color.FromArgb(49, 50, 54));
			Rectangle rectangle_ = new Rectangle(0, 0, Width - 1, Height - 1);
			graphics.FillPath(brush, Class19.smethod_0(rectangle_, 9));
			Color[] array = new Color[6]
			{
				Color.FromArgb(43, 44, 48),
				Color.FromArgb(44, 45, 49),
				Color.FromArgb(45, 46, 50),
				Color.FromArgb(46, 47, 51),
				Color.FromArgb(47, 48, 52),
				Color.FromArgb(48, 49, 53)
			};
			int num = 0;
			do
			{
				Pen pen = new Pen(array[num]);
				rectangle_ = new Rectangle(num + 1, num + 1, Width - (2 * num + 3), Height - (2 * num + 3));
				graphics.DrawPath(pen, Class19.smethod_0(rectangle_, int_));
				num++;
			}
			while (num <= 5);
			rectangle_ = new Rectangle(0, 0, Width - 1, Height - 1);
			LinearGradientBrush brush2 = new LinearGradientBrush(rectangle_, Color.Transparent, Color.FromArgb(87, 88, 92), 90f);
			Pen pen2 = new Pen(brush2);
			rectangle_ = new Rectangle(0, 0, Width - 1, Height - 2);
			graphics.DrawPath(pen2, Class19.smethod_0(rectangle_, int_));
			Pen pen3 = new Pen(Color.FromArgb(32, 33, 37));
			rectangle_ = new Rectangle(0, 0, Width - 1, Height - 3);
			graphics.DrawPath(pen3, Class19.smethod_0(rectangle_, int_));
			SolidBrush brush3 = new SolidBrush(Parent.BackColor);
			rectangle_ = new Rectangle(-1, 0, 2, 7);
			graphics.FillRectangle(brush3, rectangle_);
			switch (Boolean_0)
			{
			case false:
			{
				rectangle_ = new Rectangle(0, 0, Height - 3, Height - 3);
				LinearGradientBrush brush7 = new LinearGradientBrush(rectangle_, Color.FromArgb(72, 79, 87), Color.FromArgb(48, 52, 55), 90f);
				rectangle_ = new Rectangle(0, 0, Height - 3, Height - 3);
				graphics.FillEllipse(brush7, rectangle_);
				rectangle_ = new Rectangle(0, 0, Height - 3, Height - 3);
				LinearGradientBrush brush8 = new LinearGradientBrush(rectangle_, Color.FromArgb(29, 34, 40), Color.FromArgb(33, 34, 38), 90f);
				Pen pen6 = new Pen(brush8);
				rectangle_ = new Rectangle(0, 0, Height - 3, Height - 3);
				graphics.DrawEllipse(pen6, rectangle_);
				rectangle_ = new Rectangle(1, 1, Height - 5, Height - 4);
				LinearGradientBrush brush9 = new LinearGradientBrush(rectangle_, Color.FromArgb(118, 123, 129), Color.FromArgb(66, 67, 71), 90f);
				Pen pen7 = new Pen(brush9);
				rectangle_ = new Rectangle(1, 1, Height - 5, Height - 5);
				graphics.DrawEllipse(pen7, rectangle_);
				break;
			}
			case true:
			{
				rectangle_ = new Rectangle(15, 0, Height - 3, Height - 3);
				LinearGradientBrush brush4 = new LinearGradientBrush(rectangle_, Color.FromArgb(138, 211, 254), Color.FromArgb(56, 157, 229), 90f);
				rectangle_ = new Rectangle(15, 0, Height - 3, Height - 3);
				graphics.FillEllipse(brush4, rectangle_);
				rectangle_ = new Rectangle(15, 0, Height - 3, Height - 3);
				LinearGradientBrush brush5 = new LinearGradientBrush(rectangle_, Color.FromArgb(7, 39, 64), Color.FromArgb(26, 35, 42), 90f);
				Pen pen4 = new Pen(brush5);
				rectangle_ = new Rectangle(15, 0, Height - 3, Height - 3);
				graphics.DrawEllipse(pen4, rectangle_);
				rectangle_ = new Rectangle(16, 1, Height - 5, Height - 4);
				LinearGradientBrush brush6 = new LinearGradientBrush(rectangle_, Color.FromArgb(176, 206, 230), Color.FromArgb(30, 107, 175), 90f);
				Pen pen5 = new Pen(brush6);
				rectangle_ = new Rectangle(16, 1, Height - 5, Height - 5);
				graphics.DrawEllipse(pen5, rectangle_);
				break;
			}
			}
			NewLateBinding.LateCall(e.Graphics, null, "DrawImage", new object[3]
			{
				RuntimeHelpers.GetObjectValue(bitmap.Clone()),
				0,
				0
			}, null, null, null, IgnoreReturn: true);
			graphics.Dispose();
			bitmap.Dispose();
		}
	}
}
