using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

internal class Control27 : Control
{
	private static List<WeakReference> list_0 = new List<WeakReference>();

	private int int_0;

	private int int_1;

	private int int_2;

	private GraphicsPath graphicsPath_0;

	private GraphicsPath graphicsPath_1;

	private GraphicsPath graphicsPath_2;

	private Rectangle rectangle_0;

	private Rectangle rectangle_1;

	private Pen pen_0;

	private SolidBrush solidBrush_0;

	private LinearGradientBrush linearGradientBrush_0;

	private LinearGradientBrush linearGradientBrush_1;

	private int int_3;

	public int Int32_0
	{
		get
		{
			return int_0;
		}
		set
		{
			if (value < 0)
			{
				throw new Exception("Property value is not valid.");
			}
			int_0 = value;
			if (value > int_2)
			{
				int_2 = value;
			}
			if (value > int_1)
			{
				int_1 = value;
			}
			Invalidate();
		}
	}

	public int Int32_1
	{
		get
		{
			return int_1;
		}
		set
		{
			if (value < 0)
			{
				throw new Exception("Property value is not valid.");
			}
			int_1 = value;
			if (value < int_2)
			{
				int_2 = value;
			}
			if (value < int_0)
			{
				int_0 = value;
			}
			Invalidate();
		}
	}

	public int Int32_2
	{
		get
		{
			return int_2;
		}
		set
		{
			if (value > int_1 || value < int_0)
			{
				throw new Exception("Property value is not valid.");
			}
			int_2 = value;
			Invalidate();
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	private void method_0(int int_4)
	{
		checked
		{
			Int32_2 += int_4;
		}
	}

	public Control27()
	{
		smethod_0(this);
		int_1 = 100;
		SetStyle(ControlStyles.UserPaint | ControlStyles.Opaque | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		SetStyle(ControlStyles.Selectable, value: false);
		pen_0 = new Pen(Color.FromArgb(55, 55, 55));
		solidBrush_0 = new SolidBrush(Color.FromArgb(0, 214, 37));
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Graphics graphics = e.Graphics;
		Rectangle rectangle = default(Rectangle);
		graphics.Clear(Color.White);
		graphics.SmoothingMode = SmoothingMode.HighQuality;
		checked
		{
			Rectangle rectangle_ = new Rectangle(0, 0, Width - 1, Height - 1);
			graphicsPath_0 = method_1(rectangle_, 4);
			rectangle_ = new Rectangle(1, 1, Width - 3, Height - 3);
			graphicsPath_1 = method_1(rectangle_, 4);
			ref Rectangle reference = ref rectangle_0;
			reference = new Rectangle(0, 2, Width - 1, Height - 1);
			linearGradientBrush_0 = new LinearGradientBrush(rectangle_0, Color.FromArgb(255, 255, 255), Color.FromArgb(230, 230, 230), 90f);
			graphics.SetClip(graphicsPath_0);
			PathGradientBrush pathGradientBrush = new PathGradientBrush(graphicsPath_0);
			pathGradientBrush.CenterColor = Color.FromArgb(230, 230, 230);
			pathGradientBrush.SurroundColors = new Color[1] { Color.FromArgb(255, 255, 255) };
			Point point = new Point(0, Height);
			pathGradientBrush.CenterPoint = point;
			PointF pointF2 = (pathGradientBrush.FocusScales = new PointF(1f, 0f));
			graphics.FillRectangle(pathGradientBrush, rectangle_0);
			SolidBrush brush = new SolidBrush(Color.FromArgb(250, 250, 250));
			rectangle_ = new Rectangle(1, 1, Width - 3, (int)Math.Round((double)Height / 2.0 - 2.0));
			graphics.FillPath(brush, method_1(rectangle_, 4));
			int_3 = (int)Math.Round((double)(int_2 - int_0) / (double)(int_1 - int_0) * (double)(Width - 3));
			if (int_3 > 1)
			{
				rectangle_ = new Rectangle(1, 1, int_3, Height - 3);
				graphicsPath_2 = method_1(rectangle_, 4);
				HatchBrush brush2 = new HatchBrush(HatchStyle.Trellis, Color.FromArgb(50, Color.Black), Color.Transparent);
				ref Rectangle reference2 = ref rectangle_1;
				reference2 = new Rectangle(1, 1, int_3, Height - 3);
				linearGradientBrush_1 = new LinearGradientBrush(rectangle_1, Color.FromArgb(20, 34, 45), Color.FromArgb(27, 84, 121), 90f);
				graphics.FillPath(linearGradientBrush_1, graphicsPath_2);
				graphics.DrawPath(new Pen(Color.FromArgb(120, 134, 145)), graphicsPath_2);
				graphics.SetClip(graphicsPath_2);
				graphics.SmoothingMode = SmoothingMode.None;
				graphics.FillRectangle(new SolidBrush(Color.FromArgb(32, 100, 144)), rectangle_1.X, rectangle_1.Y + 1, rectangle_1.Width, unchecked(rectangle_1.Height / 2));
				rectangle = new Rectangle(1, 1, int_3, Height - 1);
				graphics.FillRectangle(brush2, rectangle);
				graphics.SmoothingMode = SmoothingMode.AntiAlias;
				graphics.ResetClip();
			}
			graphics.DrawPath(new Pen(Color.FromArgb(125, 125, 125)), graphicsPath_1);
			graphics.DrawPath(new Pen(Color.FromArgb(80, Color.LightGray)), graphicsPath_0);
		}
	}

	public GraphicsPath method_1(Rectangle rectangle_2, int int_4)
	{
		GraphicsPath graphicsPath = new GraphicsPath();
		checked
		{
			int num = int_4 * 2;
			Rectangle rect = new Rectangle(rectangle_2.X, rectangle_2.Y, num, num);
			graphicsPath.AddArc(rect, -180f, 90f);
			rect = new Rectangle(rectangle_2.Width - num + rectangle_2.X, rectangle_2.Y, num, num);
			graphicsPath.AddArc(rect, -90f, 90f);
			rect = new Rectangle(rectangle_2.Width - num + rectangle_2.X, rectangle_2.Height - num + rectangle_2.Y, num, num);
			graphicsPath.AddArc(rect, 0f, 90f);
			rect = new Rectangle(rectangle_2.X, rectangle_2.Height - num + rectangle_2.Y, num, num);
			graphicsPath.AddArc(rect, 90f, 90f);
			Point pt = new Point(rectangle_2.X, rectangle_2.Height - num + rectangle_2.Y);
			Point pt2 = new Point(rectangle_2.X, int_4 + rectangle_2.Y);
			graphicsPath.AddLine(pt, pt2);
			return graphicsPath;
		}
	}
}
