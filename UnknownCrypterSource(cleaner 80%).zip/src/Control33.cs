using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

internal class Control33 : Control
{
	private static List<WeakReference> list_0 = new List<WeakReference>();

	private Label label_0;

	private string string_0;

	private PointF pointF_0;

	private SizeF sizeF_0;

	public override string Text
	{
		get
		{
			return string_0;
		}
		set
		{
			string_0 = value;
			Invalidate();
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	public Control33()
	{
		smethod_0(this);
		label_0 = new Label();
		string_0 = "SLCLabel";
		SetStyle(ControlStyles.UserPaint | ControlStyles.Opaque | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		SetStyle(ControlStyles.Selectable, value: false);
		Font = new Font("Verdana", 8f, FontStyle.Regular);
		Size size2 = (Size = new Size(39, 13));
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Graphics graphics = e.Graphics;
		graphics = e.Graphics;
		graphics.Clear(Color.White);
		ref PointF reference = ref pointF_0;
		reference = new PointF(0f, 0f);
		graphics.DrawString(Text, Font, new SolidBrush(Color.FromArgb(1, 75, 124)), pointF_0);
	}
}
