using System.Drawing;
using System.Windows.Forms;

internal class Control15 : Control12
{
	public Control15()
	{
		Boolean_1 = true;
		BackColor = Color.Transparent;
	}

	protected override void ColorHook()
	{
	}

	protected override void PaintHook()
	{
		method_52(Color.FromArgb(175, 26, 26), Color.FromArgb(124, 0, 0), 0, 0, Width, Height);
		method_38(Brushes.White, HorizontalAlignment.Center, 0, 0);
		graphics_0.FillRectangle(new SolidBrush(Color.FromArgb(30, Color.White)), 0, 0, Width, Height / 2);
		method_32(new Pen(Color.FromArgb(105, 0, 0)), 0);
		method_32(new Pen(Color.FromArgb(199, 26, 26)), 1);
		if (enum1_0 == Enum1.Over)
		{
			graphics_0.FillRectangle(new SolidBrush(Color.FromArgb(30, Color.White)), 0, 0, Width, Height);
		}
		else if (enum1_0 == Enum1.Down)
		{
			method_52(Color.FromArgb(45, 45, 45), Color.FromArgb(0, 0, 0), 0, 0, Width, Height);
			method_38(Brushes.White, HorizontalAlignment.Center, 0, 0);
			graphics_0.FillRectangle(new SolidBrush(Color.FromArgb(15, Color.White)), 0, 0, Width, Height / 2);
			method_35(Pens.Black);
			method_32(new Pen(Color.FromArgb(73, 73, 73)), 1);
		}
		method_29(BackColor);
	}
}
