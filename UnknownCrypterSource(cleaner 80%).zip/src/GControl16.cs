using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

[DefaultEvent("CheckedChanged")]
public class GControl16 : Control
{
	public delegate void GDelegate5(object sender);

	private static List<WeakReference> list_0 = new List<WeakReference>();

	private GEnum0 genum0_0;

	private bool bool_0;

	private GDelegate5 gdelegate5_0;

	public bool Boolean_0
	{
		get
		{
			return bool_0;
		}
		set
		{
			bool_0 = value;
			Invalidate();
		}
	}

	public event GDelegate5 Event_0
	{
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		add
		{
			gdelegate5_0 = (GDelegate5)Delegate.Combine(gdelegate5_0, value);
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		remove
		{
			gdelegate5_0 = (GDelegate5)Delegate.Remove(gdelegate5_0, value);
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	protected override void OnMouseEnter(EventArgs e)
	{
		base.OnMouseEnter(e);
		genum0_0 = GEnum0.Over;
		Invalidate();
	}

	protected override void OnMouseDown(MouseEventArgs e)
	{
		base.OnMouseDown(e);
		genum0_0 = GEnum0.Down;
		Invalidate();
	}

	protected override void OnMouseLeave(EventArgs e)
	{
		base.OnMouseLeave(e);
		genum0_0 = GEnum0.None;
		Invalidate();
	}

	protected override void OnMouseUp(MouseEventArgs e)
	{
		base.OnMouseUp(e);
		genum0_0 = GEnum0.Over;
		Invalidate();
	}

	protected override void OnTextChanged(EventArgs e)
	{
		base.OnTextChanged(e);
		Width = checked((int)Math.Round(CreateGraphics().MeasureString(Text, Font).Width + 6f + (float)Height));
		Invalidate();
	}

	protected override void OnResize(EventArgs e)
	{
		base.OnResize(e);
		Height = 19;
	}

	protected override void OnClick(EventArgs e)
	{
		bool_0 = !bool_0;
		gdelegate5_0?.Invoke(this);
		base.OnClick(e);
	}

	public GControl16()
	{
		smethod_0(this);
		genum0_0 = GEnum0.None;
		SetStyle(ControlStyles.UserPaint, value: true);
		SetStyle(ControlStyles.AllPaintingInWmPaint, value: true);
		SetStyle(ControlStyles.OptimizedDoubleBuffer, value: true);
		SetStyle(ControlStyles.SupportsTransparentBackColor, value: true);
		BackColor = Color.Transparent;
		ForeColor = Color.White;
		Size size2 = (Size = new Size(147, 17));
		DoubleBuffered = true;
		Font = new Font("Arial", 8.25f, FontStyle.Bold);
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Bitmap bitmap = new Bitmap(Width, Height);
		Graphics graphics = Graphics.FromImage(bitmap);
		graphics.SmoothingMode = SmoothingMode.HighQuality;
		graphics.TextRenderingHint = TextRenderingHint.AntiAlias;
		checked
		{
			Rectangle rectangle = new Rectangle(0, 0, Height - 1, Height - 1);
			int int_ = 1;
			graphics.Clear(BackColor);
			graphics.Clear(Color.Transparent);
			SolidBrush brush = new SolidBrush(Color.FromArgb(49, 50, 54));
			Rectangle rectangle_ = new Rectangle(0, 0, Height - 1, Height - 1);
			graphics.FillPath(brush, Class19.smethod_0(rectangle_, 1));
			Color[] array = new Color[6]
			{
				Color.FromArgb(43, 44, 48),
				Color.FromArgb(44, 45, 49),
				Color.FromArgb(45, 46, 50),
				Color.FromArgb(46, 47, 51),
				Color.FromArgb(47, 48, 52),
				Color.FromArgb(48, 49, 53)
			};
			int num = 0;
			int num2;
			do
			{
				Pen pen = new Pen(array[num]);
				rectangle_ = new Rectangle(num + 1, num + 1, Height - (2 * num + 3), Height - (2 * num + 3));
				graphics.DrawPath(pen, Class19.smethod_0(rectangle_, int_));
				num++;
				num2 = num;
				int num3 = 5;
			}
			while (num2 <= 5);
			rectangle_ = new Rectangle(0, 0, Height - 1, Height - 1);
			LinearGradientBrush brush2 = new LinearGradientBrush(rectangle_, Color.Transparent, Color.FromArgb(87, 88, 92), 90f);
			Pen pen2 = new Pen(brush2);
			rectangle_ = new Rectangle(0, 0, Height - 2, Height - 1);
			graphics.DrawPath(pen2, Class19.smethod_0(rectangle_, int_));
			Pen pen3 = new Pen(Color.FromArgb(32, 33, 37));
			rectangle_ = new Rectangle(0, 0, Height - 2, Height - 2);
			graphics.DrawPath(pen3, Class19.smethod_0(rectangle_, int_));
			Point point3;
			if (Boolean_0)
			{
				Rectangle rectangle2 = new Rectangle((int)Math.Round((double)rectangle.X + (double)rectangle.Width / 4.0), (int)Math.Round((double)rectangle.Y + (double)rectangle.Height / 4.0), unchecked(rectangle.Width / 2), unchecked(rectangle.Height / 2));
				Point[] array2 = new Point[3];
				ref Point reference = ref array2[0];
				Point point = (reference = new Point(rectangle2.X + 1, rectangle2.Y + unchecked(rectangle2.Height / 2)));
				ref Point reference2 = ref array2[1];
				Point point2 = (reference2 = new Point(rectangle2.X + unchecked(rectangle2.Width / 2), rectangle2.Y + rectangle2.Height - 1));
				ref Point reference3 = ref array2[2];
				point3 = (reference3 = new Point(rectangle2.X + rectangle2.Width, rectangle2.Y));
				Point[] array3 = array2;
				int num4 = array3.Length - 2;
				int num5 = 0;
				while (true)
				{
					int num6 = num5;
					int num3 = num4;
					if (num6 > num3)
					{
						break;
					}
					graphics.DrawLine(new Pen(Color.White, 2f), array3[num5], array3[num5 + 1]);
					num5++;
				}
			}
			string s = Text;
			Font font = Font;
			SolidBrush brush3 = new SolidBrush(ForeColor);
			point3 = new Point(21, 3);
			graphics.DrawString(s, font, brush3, point3, new StringFormat
			{
				Alignment = StringAlignment.Near,
				LineAlignment = StringAlignment.Near
			});
			NewLateBinding.LateCall(e.Graphics, null, "DrawImage", new object[3]
			{
				RuntimeHelpers.GetObjectValue(bitmap.Clone()),
				0,
				0
			}, null, null, null, IgnoreReturn: true);
			graphics.Dispose();
			bitmap.Dispose();
		}
	}
}
