using System;
using System.Drawing;

internal class Control19 : Control12
{
	private int int_2;

	private int int_3;

	public int Int32_2
	{
		get
		{
			return int_2;
		}
		set
		{
			if (value > int_3)
			{
				value = int_3;
			}
			if (value < 0)
			{
				value = 0;
			}
			int_2 = value;
			Invalidate();
		}
	}

	public int Int32_3
	{
		get
		{
			return int_3;
		}
		set
		{
			if (value < 1)
			{
				value = 1;
			}
			if (int_2 > value)
			{
				int_2 = value;
			}
			int_3 = value;
			Invalidate();
		}
	}

	public Control19()
	{
		int_3 = 100;
		Boolean_1 = true;
		BackColor = Color.Transparent;
	}

	protected override void ColorHook()
	{
	}

	protected override void PaintHook()
	{
		graphics_0.Clear(Color.FromArgb(66, 0, 0));
		checked
		{
			graphics_0.FillRectangle(new SolidBrush(Color.FromArgb(204, 0, 0)), 0, 0, (int)Math.Round((double)int_2 / (double)int_3 * (double)Width - 1.0), Height);
			method_66(0, 0, Width, Height, 5);
			graphics_0.DrawLine(new Pen(Color.FromArgb(32, 32, 32)), 0, 1, Width, 1);
			method_32(new Pen(Color.FromArgb(70, 70, 70)), 0);
			graphics_0.DrawLine(new Pen(Color.FromArgb(138, 139, 138)), 0, Height - 1, Width, Height - 1);
			method_52(Color.FromArgb(70, 70, 70), Color.FromArgb(138, 139, 138), 0, 0, 1, Height);
			method_52(Color.FromArgb(70, 70, 70), Color.FromArgb(138, 139, 138), Width - 1, 0, Width, Height);
		}
	}
}
