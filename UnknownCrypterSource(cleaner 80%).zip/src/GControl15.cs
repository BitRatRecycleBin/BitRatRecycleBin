using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

public class GControl15 : Control
{
	private static List<WeakReference> list_0 = new List<WeakReference>();

	private GEnum0 genum0_0;

	private int int_0;

	private int int_1;

	private long long_0;

	private long long_1;

	private long long_2;

	private bool bool_0;

	public long Int64_0
	{
		get
		{
			return long_0;
		}
		set
		{
			if ((value <= long_1) & (value >= long_2))
			{
				long_0 = value;
			}
			Invalidate();
		}
	}

	public long Int64_1
	{
		get
		{
			return long_1;
		}
		set
		{
			if (value > long_2)
			{
				long_1 = value;
			}
			if (long_0 > long_1)
			{
				long_0 = long_1;
			}
			Invalidate();
		}
	}

	public long Int64_2
	{
		get
		{
			return long_2;
		}
		set
		{
			if (value < long_1)
			{
				long_2 = value;
			}
			if (long_0 < long_2)
			{
				long_0 = long_2;
			}
			Invalidate();
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	protected override void OnMouseMove(MouseEventArgs e)
	{
		base.OnMouseMove(e);
		int_0 = e.Location.X;
		int_1 = e.Location.Y;
		Invalidate();
		if (e.X < checked(Width - 23))
		{
			Cursor = Cursors.IBeam;
		}
		else
		{
			Cursor = Cursors.Default;
		}
	}

	protected override void OnResize(EventArgs e)
	{
		base.OnResize(e);
		Height = 26;
	}

	protected override void OnMouseDown(MouseEventArgs e)
	{
		base.OnMouseClick(e);
		checked
		{
			if (int_0 > Width - 17 && int_0 < Width - 3)
			{
				if (int_1 < 13)
				{
					if (Int64_0 + 1L <= long_1)
					{
						long_0++;
					}
				}
				else if (Int64_0 - 1L >= long_2)
				{
					long_0--;
				}
			}
			else
			{
				bool_0 = !bool_0;
				Focus();
			}
			Invalidate();
		}
	}

	protected override void OnKeyPress(KeyPressEventArgs e)
	{
		base.OnKeyPress(e);
		try
		{
			if (bool_0)
			{
				long_0 = Conversions.ToLong(Conversions.ToString(long_0) + e.KeyChar);
			}
			if (long_0 > long_1)
			{
				long_0 = long_1;
			}
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			ProjectData.ClearProjectError();
		}
	}

	protected override void OnKeyUp(KeyEventArgs e)
	{
		base.OnKeyUp(e);
		checked
		{
			if (e.KeyCode == Keys.Up)
			{
				if (Int64_0 + 1L <= long_1)
				{
					long_0++;
				}
				Invalidate();
			}
			else if (e.KeyCode == Keys.Down)
			{
				if (Int64_0 - 1L >= long_2)
				{
					long_0--;
				}
			}
			else if (e.KeyCode == Keys.Back)
			{
				string text = long_0.ToString();
				text = text.Remove(Convert.ToInt32(text.Length - 1));
				if (text.Length == 0)
				{
					text = "0";
				}
				long_0 = Convert.ToInt32(text);
			}
			Invalidate();
		}
	}

	protected void method_0(Color color_0, Point point_0, Point point_1, Point point_2, Graphics graphics_0)
	{
		List<Point> list = new List<Point>();
		list.Add(point_0);
		list.Add(point_1);
		list.Add(point_2);
		graphics_0.FillPolygon(new SolidBrush(color_0), list.ToArray());
	}

	public GControl15()
	{
		smethod_0(this);
		genum0_0 = default(GEnum0);
		long_1 = 9999999L;
		long_2 = 0L;
		Cursor = Cursors.IBeam;
		SetStyle(ControlStyles.UserPaint | ControlStyles.SupportsTransparentBackColor, value: true);
		BackColor = Color.Transparent;
		ForeColor = Color.White;
		DoubleBuffered = true;
		Font = new Font("Arial", 8.25f, FontStyle.Bold);
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Bitmap bitmap = new Bitmap(Width, Height);
		Graphics graphics = Graphics.FromImage(bitmap);
		int num = 4;
		graphics.Clear(BackColor);
		graphics.SmoothingMode = SmoothingMode.HighQuality;
		graphics.TextRenderingHint = TextRenderingHint.AntiAlias;
		SolidBrush brush = new SolidBrush(Color.FromArgb(49, 50, 54));
		checked
		{
			Rectangle rectangle_ = new Rectangle(0, 0, Width - 1, Height - 1);
			graphics.FillPath(brush, Class19.smethod_0(rectangle_, 4));
			Color[] array = new Color[6]
			{
				Color.FromArgb(43, 44, 48),
				Color.FromArgb(44, 45, 49),
				Color.FromArgb(45, 46, 50),
				Color.FromArgb(46, 47, 51),
				Color.FromArgb(47, 48, 52),
				Color.FromArgb(48, 49, 53)
			};
			int num2 = 0;
			do
			{
				Pen pen = new Pen(array[num2]);
				rectangle_ = new Rectangle(num2 + 1, num2 + 1, Width - (2 * num2 + 3), Height - (2 * num2 + 3));
				graphics.DrawPath(pen, Class19.smethod_0(rectangle_, num));
				num2++;
			}
			while (num2 <= 5);
			rectangle_ = new Rectangle(0, 0, Width - 1, Height - 2);
			graphics.SetClip(Class19.smethod_0(rectangle_, num));
			rectangle_ = new Rectangle(Width - 17, 0, 17, Height - 2);
			LinearGradientBrush linearGradientBrush = new LinearGradientBrush(rectangle_, Color.FromArgb(75, 78, 87), Color.FromArgb(50, 51, 55), 90f);
			graphics.FillRectangle(linearGradientBrush, linearGradientBrush.Rectangle);
			graphics.ResetClip();
			rectangle_ = new Rectangle(0, 0, Width - 1, Height - 1);
			LinearGradientBrush brush2 = new LinearGradientBrush(rectangle_, Color.Transparent, Color.FromArgb(87, 88, 92), 90f);
			Pen pen2 = new Pen(brush2);
			rectangle_ = new Rectangle(0, 0, Width - 1, Height - 1);
			graphics.DrawPath(pen2, Class19.smethod_0(rectangle_, num));
			Pen pen3 = new Pen(Color.FromArgb(32, 33, 37));
			rectangle_ = new Rectangle(0, 0, Width - 1, Height - 2);
			graphics.DrawPath(pen3, Class19.smethod_0(rectangle_, num));
			Color color_ = Color.FromArgb(22, 23, 28);
			Point point = new Point(Width - 12, 8);
			Point point_ = point;
			Point point2 = new Point(Width - 6, 8);
			Point point_2 = point2;
			Point point_3 = new Point(Width - 9, 5);
			method_0(color_, point_, point_2, point_3, graphics);
			Color color_2 = Color.FromArgb(22, 23, 28);
			point_3 = new Point(Width - 12, 17);
			Point point_4 = point_3;
			point2 = new Point(Width - 6, 17);
			Point point_5 = point2;
			point = new Point(Width - 9, 20);
			method_0(color_2, point_4, point_5, point, graphics);
			rectangle_ = new Rectangle(Width - 17, 0, 17, Height - 2);
			graphics.SetClip(Class19.smethod_0(rectangle_, num));
			Pen pen4 = new Pen(Color.FromArgb(82, 85, 92));
			rectangle_ = new Rectangle(1, 1, Width - 3, Height - 4);
			graphics.DrawPath(pen4, Class19.smethod_0(rectangle_, num));
			graphics.ResetClip();
			Pen pen5 = new Pen(Color.FromArgb(29, 37, 40));
			point_3 = new Point(Width - 17, 0);
			Point pt = point_3;
			point2 = new Point(Width - 17, Height - 2);
			graphics.DrawLine(pen5, pt, point2);
			Pen pen6 = new Pen(Color.FromArgb(85, 92, 98));
			point_3 = new Point(Width - 16, 1);
			Point pt2 = point_3;
			point2 = new Point(Width - 16, Height - 3);
			graphics.DrawLine(pen6, pt2, point2);
			Pen pen7 = new Pen(Color.FromArgb(29, 37, 40));
			point_3 = new Point(Width - 17, (int)Math.Round((double)Height / 2.0 - 1.0));
			Point pt3 = point_3;
			point2 = new Point(Width - 1, (int)Math.Round((double)Height / 2.0 - 1.0));
			graphics.DrawLine(pen7, pt3, point2);
			Pen pen8 = new Pen(Color.FromArgb(85, 92, 98));
			point_3 = new Point(Width - 16, (int)Math.Round((double)Height / 2.0));
			Point pt4 = point_3;
			point2 = new Point(Width - 2, (int)Math.Round((double)Height / 2.0));
			graphics.DrawLine(pen8, pt4, point2);
			string s = Conversions.ToString(Int64_0);
			Font font = Font;
			SolidBrush brush3 = new SolidBrush(Color.FromArgb(16, 20, 21));
			point_3 = new Point(8, 8);
			graphics.DrawString(s, font, brush3, point_3);
			string s2 = Conversions.ToString(Int64_0);
			Font font2 = Font;
			Brush white = Brushes.White;
			point_3 = new Point(7, 7);
			graphics.DrawString(s2, font2, white, point_3);
			NewLateBinding.LateCall(e.Graphics, null, "DrawImage", new object[3]
			{
				RuntimeHelpers.GetObjectValue(bitmap.Clone()),
				0,
				0
			}, null, null, null, IgnoreReturn: true);
			graphics.Dispose();
			bitmap.Dispose();
		}
	}
}
