using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

public class GControl8 : ContainerControl
{
	private static List<WeakReference> list_0 = new List<WeakReference>();

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	protected override void OnPaintBackground(PaintEventArgs pevent)
	{
	}

	protected override void OnTextChanged(EventArgs e)
	{
		base.OnTextChanged(e);
		Invalidate();
	}

	public GControl8()
	{
		smethod_0(this);
		BackColor = Color.FromArgb(33, 33, 33);
		Size size2 = (Size = new Size(200, 100));
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Bitmap bitmap = new Bitmap(Width, Height);
		Graphics graphics = Graphics.FromImage(bitmap);
		graphics.SmoothingMode = SmoothingMode.HighSpeed;
		checked
		{
			Rectangle rect = new Rectangle(0, 0, Width - 1, Height - 1);
			_ = ParentForm.TransparencyKey;
			Class18 @class = new Class18();
			base.OnPaint(e);
			graphics.Clear(Color.FromArgb(42, 47, 49));
			Pen pen = new Pen(Color.FromArgb(67, 75, 78));
			Rectangle rectangle_ = new Rectangle(2, 7, Width - 5, Height - 9);
			graphics.DrawPath(pen, @class.method_0(rectangle_, 3));
			LinearGradientBrush brush = new LinearGradientBrush(rect, Color.FromArgb(30, 32, 32), Color.Transparent, 90f);
			Pen pen2 = new Pen(brush);
			rectangle_ = new Rectangle(1, 6, Width - 3, Height - 9);
			graphics.DrawPath(pen2, @class.method_0(rectangle_, 3));
			rectangle_ = new Rectangle(3, 7, Width - 7, Height - 10);
			LinearGradientBrush brush2 = new LinearGradientBrush(rectangle_, Color.Transparent, Color.FromArgb(30, 32, 32), 90f);
			Pen pen3 = new Pen(brush2);
			rectangle_ = new Rectangle(3, 7, Width - 7, Height - 10);
			graphics.DrawPath(pen3, @class.method_0(rectangle_, 3));
			SolidBrush brush3 = new SolidBrush(Color.FromArgb(42, 47, 49));
			rectangle_ = new Rectangle(8, 0, Text.Length * 6, 11);
			graphics.FillRectangle(brush3, rectangle_);
			string s = Text;
			Font font = Font;
			SolidBrush brush4 = new SolidBrush(ForeColor);
			rectangle_ = new Rectangle(8, 0, Width - 1, 11);
			graphics.DrawString(s, font, brush4, rectangle_, new StringFormat
			{
				LineAlignment = StringAlignment.Center,
				Alignment = StringAlignment.Near
			});
			NewLateBinding.LateCall(e.Graphics, null, "DrawImage", new object[3]
			{
				RuntimeHelpers.GetObjectValue(bitmap.Clone()),
				0,
				0
			}, null, null, null, IgnoreReturn: true);
			graphics.Dispose();
			bitmap.Dispose();
		}
	}
}
