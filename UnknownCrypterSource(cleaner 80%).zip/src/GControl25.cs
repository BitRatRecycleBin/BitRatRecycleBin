using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

public class GControl25 : Control
{
	public enum GEnum12
	{
		None,
		One,
		Two,
		Three
	}

	public delegate void GDelegate10(object sender);

	private static List<WeakReference> list_0 = new List<WeakReference>();

	private Color color_0;

	private Color color_1;

	private Color color_2;

	private Color color_3;

	private Color color_4;

	private Color color_5;

	private Color color_6;

	private Color color_7;

	private Color color_8;

	private int int_0;

	private int int_1;

	private int int_2;

	private int int_3;

	private int int_4;

	private int int_5;

	private bool bool_0;

	private bool bool_1;

	private GEnum12 genum12_0;

	private Point point_0;

	private Enum3 enum3_0;

	private Enum3 enum3_1;

	private int int_6;

	private int int_7;

	private int int_8;

	private Rectangle rectangle_0;

	private Rectangle rectangle_1;

	private Rectangle rectangle_2;

	private Rectangle rectangle_3;

	private bool bool_2;

	private bool bool_3;

	private int int_9;

	private GDelegate10 gdelegate10_0;

	[Category("Colours")]
	public Color Color_0
	{
		get
		{
			return color_0;
		}
		set
		{
			color_0 = value;
		}
	}

	[Category("Colours")]
	public Color Color_1
	{
		get
		{
			return color_1;
		}
		set
		{
			color_1 = value;
		}
	}

	[Category("Colours")]
	public Color Color_2
	{
		get
		{
			return color_2;
		}
		set
		{
			color_2 = value;
		}
	}

	[Category("Colours")]
	public Color Color_3
	{
		get
		{
			return color_3;
		}
		set
		{
			color_3 = value;
		}
	}

	[Category("Colours")]
	public Color Color_4
	{
		get
		{
			return color_4;
		}
		set
		{
			color_4 = value;
		}
	}

	[Category("Colours")]
	public Color Color_5
	{
		get
		{
			return color_5;
		}
		set
		{
			color_5 = value;
		}
	}

	[Category("Colours")]
	public Color Color_6
	{
		get
		{
			return color_6;
		}
		set
		{
			color_6 = value;
		}
	}

	[Category("Colours")]
	public Color Color_7
	{
		get
		{
			return color_7;
		}
		set
		{
			color_7 = value;
		}
	}

	[Category("Colours")]
	public Color Color_8
	{
		get
		{
			return color_8;
		}
		set
		{
			color_8 = value;
		}
	}

	[Category("Control")]
	public int Int32_0
	{
		get
		{
			return int_0;
		}
		set
		{
			int_0 = value;
			if (value > int_2)
			{
				int_2 = value;
			}
			if (value > int_1)
			{
				int_1 = value;
			}
			method_0();
		}
	}

	[Category("Control")]
	public int Int32_1
	{
		get
		{
			return int_1;
		}
		set
		{
			if (value < int_2)
			{
				int_2 = value;
			}
			if (value < int_0)
			{
				int_0 = value;
			}
			method_0();
		}
	}

	[Category("Control")]
	public int Int32_2
	{
		get
		{
			return int_2;
		}
		set
		{
			if (value != int_2)
			{
				if (value < int_0)
				{
					int_2 = int_0;
				}
				else if (value > int_1)
				{
					int_2 = int_1;
				}
				else
				{
					int_2 = value;
				}
				method_1();
				gdelegate10_0?.Invoke(this);
			}
		}
	}

	[Category("Control")]
	public int Int32_3
	{
		get
		{
			return int_3;
		}
		set
		{
			if (value >= 1 && value > 0 - ((int_3 == value) ? 1 : 0))
			{
			}
		}
	}

	[Category("Control")]
	public int Int32_4
	{
		get
		{
			return int_5;
		}
		set
		{
			if (value >= 1)
			{
				int_5 = value;
			}
		}
	}

	[Category("Control")]
	public int Int32_5
	{
		get
		{
			return int_4;
		}
		set
		{
			if (value < 16)
			{
				int_4 = 16;
			}
			else
			{
				int_4 = value;
			}
		}
	}

	[Category("Control")]
	public bool Boolean_0
	{
		get
		{
			return bool_0;
		}
		set
		{
			bool_0 = value;
			Invalidate();
		}
	}

	[Category("Control")]
	public bool Boolean_1
	{
		get
		{
			return bool_1;
		}
		set
		{
			bool_1 = value;
			Invalidate();
		}
	}

	[Category("Control")]
	public GEnum12 GEnum12_0
	{
		get
		{
			return genum12_0;
		}
		set
		{
			genum12_0 = value;
		}
	}

	public event GDelegate10 Event_0
	{
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		add
		{
			gdelegate10_0 = (GDelegate10)Delegate.Combine(gdelegate10_0, value);
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		remove
		{
			gdelegate10_0 = (GDelegate10)Delegate.Remove(gdelegate10_0, value);
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	protected override void OnSizeChanged(EventArgs e)
	{
		method_0();
	}

	private void method_0()
	{
		ref Rectangle reference = ref rectangle_0;
		reference = new Rectangle(0, 0, 16, Height);
		ref Rectangle reference2 = ref rectangle_1;
		checked
		{
			reference2 = new Rectangle(Width - Int32_5, 0, Int32_5, Height);
			ref Rectangle reference3 = ref rectangle_2;
			reference3 = new Rectangle(rectangle_0.Right + 1, 0, (int)Math.Round((double)Width - (double)Width / 8.0 - 8.0), Height);
			bool_2 = int_1 - int_0 != 0;
			if (bool_2)
			{
				ref Rectangle reference4 = ref rectangle_3;
				reference4 = new Rectangle(0, 4, (int)Math.Round((double)Width / 8.0), Height - 8);
			}
			gdelegate10_0?.Invoke(this);
			method_1();
		}
	}

	private void method_1()
	{
		rectangle_3.X = checked((int)Math.Round((double)(int_2 - int_0) / (double)(int_1 - int_0) * (double)(rectangle_2.Width - int_9) + 16.0));
		Invalidate();
	}

	protected override void OnMouseDown(MouseEventArgs e)
	{
		if (e.Button != MouseButtons.Left || !bool_2)
		{
			return;
		}
		checked
		{
			if (rectangle_0.Contains(e.Location))
			{
				enum3_1 = Enum3.Down;
				int_8 = int_2 - int_3;
			}
			else if (rectangle_1.Contains(e.Location))
			{
				int_8 = int_2 + int_3;
				enum3_1 = Enum3.Down;
			}
			else
			{
				if (rectangle_3.Contains(e.Location))
				{
					enum3_0 = Enum3.Down;
					Invalidate();
					return;
				}
				if (e.X < rectangle_3.X)
				{
					int_8 = int_2 - int_5;
				}
				else
				{
					int_8 = int_2 + int_5;
				}
			}
			Int32_2 = Math.Min(Math.Max(int_8, int_0), int_1);
			Invalidate();
			method_1();
		}
	}

	protected override void OnMouseMove(MouseEventArgs e)
	{
		int_6 = e.Location.X;
		int_7 = e.Location.Y;
		if (rectangle_0.Contains(e.Location))
		{
			enum3_1 = Enum3.Over;
		}
		else if (rectangle_1.Contains(e.Location))
		{
			enum3_1 = Enum3.Over;
		}
		else if (enum3_1 != Enum3.Down)
		{
			enum3_1 = Enum3.None;
		}
		if (rectangle_3.Contains(e.Location) & (enum3_0 != Enum3.Down))
		{
			enum3_0 = Enum3.Over;
		}
		else if (enum3_0 != Enum3.Down)
		{
			enum3_0 = Enum3.None;
		}
		Invalidate();
		checked
		{
			if ((enum3_0 == Enum3.Down) | ((enum3_1 == Enum3.Down && bool_2) ? true : false))
			{
				int num = e.X + 2 - rectangle_0.Width - unchecked(int_9 / 2);
				int num2 = rectangle_2.Width - int_9;
				int_8 = (int)Math.Round((double)num / (double)num2 * (double)(int_1 - int_0)) - int_0;
				Int32_2 = Math.Min(Math.Max(int_8, int_0), int_1);
				method_1();
			}
		}
	}

	protected override void OnMouseUp(MouseEventArgs e)
	{
		if (rectangle_3.Contains(e.Location))
		{
			enum3_0 = Enum3.Over;
		}
		else if (!rectangle_3.Contains(e.Location))
		{
			enum3_0 = Enum3.None;
		}
		checked
		{
			if ((e.Location.X < 16) | (e.Location.X > Width - 16))
			{
				enum3_0 = Enum3.Over;
			}
			else if ((e.Location.X >= 16) | (e.Location.X > Width - 16))
			{
				enum3_0 = Enum3.None;
			}
			Invalidate();
		}
	}

	protected override void OnMouseLeave(EventArgs e)
	{
		enum3_0 = Enum3.None;
		enum3_1 = Enum3.None;
		Invalidate();
	}

	protected override void OnMouseEnter(EventArgs e)
	{
		base.OnMouseEnter(e);
		Invalidate();
	}

	public GControl25()
	{
		smethod_0(this);
		color_0 = Color.FromArgb(62, 62, 66);
		color_1 = Color.FromArgb(104, 104, 104);
		color_2 = Color.FromArgb(158, 158, 158);
		color_3 = Color.FromArgb(239, 235, 239);
		color_4 = Color.FromArgb(153, 153, 153);
		color_5 = Color.FromArgb(39, 123, 181);
		color_6 = Color.FromArgb(0, 113, 171);
		int_0 = 0;
		int_1 = 100;
		int_2 = 0;
		int_3 = 1;
		int_4 = 16;
		int_5 = 10;
		bool_0 = false;
		bool_1 = false;
		genum12_0 = GEnum12.None;
		ref Point reference = ref point_0;
		reference = new Point(int_6, int_7);
		enum3_0 = Enum3.None;
		enum3_1 = Enum3.None;
		int_9 = 24;
		SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.Selectable | ControlStyles.SupportsTransparentBackColor | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		DoubleBuffered = true;
		Size size2 = (Size = new Size(50, 19));
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Graphics graphics = e.Graphics;
		Graphics graphics2 = graphics;
		graphics2.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
		graphics2.SmoothingMode = SmoothingMode.HighQuality;
		graphics2.PixelOffsetMode = PixelOffsetMode.HighQuality;
		graphics2.Clear(color_0);
		Point[] array = new Point[3];
		ref Point reference = ref array[0];
		checked
		{
			Point point = (reference = new Point(5, (int)Math.Round((double)Height / 2.0)));
			ref Point reference2 = ref array[1];
			Point point2 = (reference2 = new Point(11, (int)Math.Round((double)Height / 4.0)));
			ref Point reference3 = ref array[2];
			Point point3 = (reference3 = new Point(11, (int)Math.Round((double)Height / 2.0 + (double)Height / 4.0)));
			Point[] points = array;
			array = new Point[3];
			ref Point reference4 = ref array[0];
			point3 = (reference4 = new Point(Width - 5, (int)Math.Round((double)Height / 2.0)));
			ref Point reference5 = ref array[1];
			point2 = (reference5 = new Point(Width - 11, (int)Math.Round((double)Height / 4.0)));
			ref Point reference6 = ref array[2];
			point = (reference6 = new Point(Width - 11, (int)Math.Round((double)Height / 2.0 + (double)Height / 4.0)));
			Point[] points2 = array;
			switch (enum3_0)
			{
			case Enum3.None:
			{
				using (SolidBrush brush3 = new SolidBrush(color_1))
				{
					graphics2.FillRectangle(brush3, rectangle_3);
				}
				break;
			}
			case Enum3.Over:
			{
				using (SolidBrush brush2 = new SolidBrush(color_2))
				{
					graphics2.FillRectangle(brush2, rectangle_3);
				}
				break;
			}
			case Enum3.Down:
			{
				using (SolidBrush brush = new SolidBrush(color_3))
				{
					graphics2.FillRectangle(brush, rectangle_3);
				}
				break;
			}
			}
			switch (enum3_1)
			{
			case Enum3.None:
				graphics2.FillPolygon(new SolidBrush(color_4), points);
				graphics2.FillPolygon(new SolidBrush(color_4), points2);
				break;
			case Enum3.Over:
				if (int_6 < 16)
				{
					graphics2.FillPolygon(new SolidBrush(color_5), points);
					graphics2.FillPolygon(new SolidBrush(color_4), points2);
				}
				else if (int_6 > Width - 16)
				{
					graphics2.FillPolygon(new SolidBrush(color_5), points2);
					graphics2.FillPolygon(new SolidBrush(color_4), points);
				}
				else
				{
					graphics2.FillPolygon(new SolidBrush(color_4), points);
					graphics2.FillPolygon(new SolidBrush(color_4), points2);
				}
				break;
			case Enum3.Down:
				if (!rectangle_3.Contains(point_0))
				{
					using SolidBrush brush4 = new SolidBrush(color_1);
					graphics2.FillRectangle(brush4, rectangle_3);
				}
				if (int_6 < 16)
				{
					graphics2.FillPolygon(new SolidBrush(color_6), points);
					graphics2.FillPolygon(new SolidBrush(color_4), points2);
				}
				else if (int_6 > Width - 16)
				{
					graphics2.FillPolygon(new SolidBrush(color_6), points2);
					graphics2.FillPolygon(new SolidBrush(color_4), points);
				}
				else
				{
					graphics2.FillPolygon(new SolidBrush(color_4), points);
					graphics2.FillPolygon(new SolidBrush(color_4), points2);
				}
				break;
			}
			graphics2.InterpolationMode = InterpolationMode.HighQualityBicubic;
			graphics2 = null;
		}
	}
}
