using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

internal abstract class Control12 : Control
{
	protected Graphics graphics_0;

	protected Bitmap bitmap_0;

	private bool bool_0;

	private bool bool_1;

	protected Enum1 enum1_0;

	private bool bool_2;

	private bool bool_3;

	private Image image_0;

	private bool bool_4;

	private Dictionary<string, Color> dictionary_0;

	private string string_0;

	private Size size_0;

	private int int_0;

	private int int_1;

	private bool bool_5;

	private Rectangle rectangle_0;

	private Size size_1;

	private Point point_0;

	private Point point_1;

	private Bitmap bitmap_1;

	private Graphics graphics_1;

	private SolidBrush solidBrush_0;

	private SolidBrush solidBrush_1;

	private Point point_2;

	private Size size_2;

	private Point point_3;

	private LinearGradientBrush linearGradientBrush_0;

	private Rectangle rectangle_1;

	private GraphicsPath graphicsPath_0;

	private PathGradientBrush pathGradientBrush_0;

	private LinearGradientBrush linearGradientBrush_1;

	private Rectangle rectangle_2;

	private GraphicsPath graphicsPath_1;

	private Rectangle rectangle_3;

	[Browsable(false)]
	[EditorBrowsable(EditorBrowsableState.Never)]
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	public override Color ForeColor
	{
		get
		{
			return Color.Empty;
		}
		set
		{
		}
	}

	[Browsable(false)]
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	[EditorBrowsable(EditorBrowsableState.Never)]
	public override Image BackgroundImage
	{
		get
		{
			return null;
		}
		set
		{
		}
	}

	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	[EditorBrowsable(EditorBrowsableState.Never)]
	[Browsable(false)]
	public override ImageLayout BackgroundImageLayout
	{
		get
		{
			return ImageLayout.None;
		}
		set
		{
		}
	}

	public override string Text
	{
		get
		{
			return base.Text;
		}
		set
		{
			base.Text = value;
			Invalidate();
		}
	}

	public override Font Font
	{
		get
		{
			return base.Font;
		}
		set
		{
			base.Font = value;
			Invalidate();
		}
	}

	[Category("Misc")]
	public override Color BackColor
	{
		get
		{
			return base.BackColor;
		}
		set
		{
			if (!IsHandleCreated && value == Color.Transparent)
			{
				bool_2 = true;
				return;
			}
			base.BackColor = value;
			if (Parent != null)
			{
				ColorHook();
			}
		}
	}

	public bool Boolean_0
	{
		get
		{
			return bool_3;
		}
		set
		{
			bool_3 = value;
			Invalidate();
		}
	}

	public Image Image_0
	{
		get
		{
			return image_0;
		}
		set
		{
			if (value == null)
			{
				size_0 = Size.Empty;
			}
			else
			{
				size_0 = value.Size;
			}
			image_0 = value;
			Invalidate();
		}
	}

	public bool Boolean_1
	{
		get
		{
			return bool_4;
		}
		set
		{
			bool_4 = value;
			if (IsHandleCreated)
			{
				if (!value && BackColor.A != byte.MaxValue)
				{
					throw new Exception("Unable to change value to false while a transparent BackColor is in use.");
				}
				SetStyle(ControlStyles.Opaque, !value);
				SetStyle(ControlStyles.SupportsTransparentBackColor, value);
				if (value)
				{
					method_10();
				}
				else
				{
					bitmap_0 = null;
				}
				Invalidate();
			}
		}
	}

	public Struct0[] Struct0_0
	{
		get
		{
			List<Struct0> list = new List<Struct0>();
			Dictionary<string, Color>.Enumerator enumerator = dictionary_0.GetEnumerator();
			while (enumerator.MoveNext())
			{
				Struct0 item = new Struct0(enumerator.Current.Key, enumerator.Current.Value);
				list.Add(item);
			}
			return list.ToArray();
		}
		set
		{
			for (int i = 0; i < value.Length; i = checked(i + 1))
			{
				Struct0 @struct = value[i];
				if (dictionary_0.ContainsKey(@struct.String_0))
				{
					dictionary_0[@struct.String_0] = @struct.Color_0;
				}
			}
			method_11();
			ColorHook();
			Invalidate();
		}
	}

	public string String_0
	{
		get
		{
			return string_0;
		}
		set
		{
			if (Operators.CompareString(value, string_0, TextCompare: false) == 0)
			{
				return;
			}
			Struct0[] struct0_ = Struct0_0;
			checked
			{
				try
				{
					byte[] value2 = Convert.FromBase64String(value);
					int num = struct0_.Length - 1;
					int num2 = 0;
					while (true)
					{
						int num3 = num2;
						int num4 = num;
						if (num3 <= num4)
						{
							struct0_[num2].Color_0 = Color.FromArgb(BitConverter.ToInt32(value2, num2 * 4));
							num2++;
							continue;
						}
						break;
					}
				}
				catch (Exception projectError)
				{
					ProjectData.SetProjectError(projectError);
					ProjectData.ClearProjectError();
					return;
				}
				string_0 = value;
				Struct0_0 = struct0_;
				ColorHook();
				Invalidate();
			}
		}
	}

	protected Size Size_0 => size_0;

	protected int Int32_0
	{
		get
		{
			return int_0;
		}
		set
		{
			int_0 = value;
			if (Int32_0 != 0 && IsHandleCreated)
			{
				Width = Int32_0;
			}
		}
	}

	protected int Int32_1
	{
		get
		{
			return int_1;
		}
		set
		{
			int_1 = value;
			if (Int32_1 != 0 && IsHandleCreated)
			{
				Height = Int32_1;
			}
		}
	}

	protected bool Boolean_2
	{
		get
		{
			return bool_5;
		}
		set
		{
			bool_5 = value;
			method_12();
		}
	}

	public Control12()
	{
		dictionary_0 = new Dictionary<string, Color>();
		SetStyle(ControlStyles.UserPaint | ControlStyles.Opaque | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		size_0 = Size.Empty;
		Font = new Font("Verdana", 8f);
		bitmap_1 = new Bitmap(1, 1);
		graphics_1 = Graphics.FromImage(bitmap_1);
		graphicsPath_0 = new GraphicsPath();
		method_11();
	}

	protected sealed override void OnHandleCreated(EventArgs e)
	{
		method_11();
		ColorHook();
		if (int_0 != 0)
		{
			Width = int_0;
		}
		if (int_1 != 0)
		{
			Height = int_1;
		}
		Boolean_1 = bool_4;
		if (bool_4 && bool_2)
		{
			BackColor = Color.Transparent;
		}
		base.OnHandleCreated(e);
	}

	protected sealed override void OnParentChanged(EventArgs e)
	{
		if (Parent != null)
		{
			vmethod_0();
			bool_0 = true;
			method_12();
		}
		base.OnParentChanged(e);
	}

	private void method_0(bool bool_6)
	{
		vmethod_1();
		if (bool_6)
		{
			Invalidate();
		}
	}

	protected sealed override void OnPaint(PaintEventArgs e)
	{
		if (Width != 0 && Height != 0)
		{
			if (bool_4)
			{
				PaintHook();
				e.Graphics.DrawImage(bitmap_0, 0, 0);
			}
			else
			{
				graphics_0 = e.Graphics;
				PaintHook();
			}
		}
	}

	protected override void OnHandleDestroyed(EventArgs e)
	{
		Class10.smethod_3(method_0);
		base.OnHandleDestroyed(e);
	}

	protected sealed override void OnSizeChanged(EventArgs e)
	{
		if (bool_4)
		{
			method_10();
		}
		Invalidate();
		base.OnSizeChanged(e);
	}

	protected override void SetBoundsCore(int x, int y, int width, int height, BoundsSpecified specified)
	{
		if (int_0 != 0)
		{
			width = int_0;
		}
		if (int_1 != 0)
		{
			height = int_1;
		}
		base.SetBoundsCore(x, y, width, height, specified);
	}

	protected override void OnMouseEnter(EventArgs e)
	{
		bool_1 = true;
		method_1(Enum1.Over);
		base.OnMouseEnter(e);
	}

	protected override void OnMouseUp(MouseEventArgs e)
	{
		if (bool_1)
		{
			method_1(Enum1.Over);
		}
		base.OnMouseUp(e);
	}

	protected override void OnMouseDown(MouseEventArgs e)
	{
		if (e.Button == MouseButtons.Left)
		{
			method_1(Enum1.Down);
		}
		base.OnMouseDown(e);
	}

	protected override void OnMouseLeave(EventArgs e)
	{
		bool_1 = false;
		method_1(Enum1.None);
		base.OnMouseLeave(e);
	}

	protected override void OnEnabledChanged(EventArgs e)
	{
		if (Enabled)
		{
			method_1(Enum1.None);
		}
		else
		{
			method_1(Enum1.Block);
		}
		base.OnEnabledChanged(e);
	}

	private void method_1(Enum1 enum1_1)
	{
		enum1_0 = enum1_1;
		Invalidate();
	}

	protected Pen method_2(string string_1)
	{
		return new Pen(dictionary_0[string_1]);
	}

	protected Pen method_3(string string_1, float float_0)
	{
		return new Pen(dictionary_0[string_1], float_0);
	}

	protected SolidBrush method_4(string string_1)
	{
		return new SolidBrush(dictionary_0[string_1]);
	}

	protected Color method_5(string string_1)
	{
		return dictionary_0[string_1];
	}

	protected void method_6(string string_1, Color color_0)
	{
		if (dictionary_0.ContainsKey(string_1))
		{
			dictionary_0[string_1] = color_0;
		}
		else
		{
			dictionary_0.Add(string_1, color_0);
		}
	}

	protected void method_7(string string_1, byte byte_0, byte byte_1, byte byte_2)
	{
		method_6(string_1, Color.FromArgb(byte_0, byte_1, byte_2));
	}

	protected void method_8(string string_1, byte byte_0, byte byte_1, byte byte_2, byte byte_3)
	{
		method_6(string_1, Color.FromArgb(byte_0, byte_1, byte_2, byte_3));
	}

	protected void method_9(string string_1, byte byte_0, Color color_0)
	{
		method_6(string_1, Color.FromArgb(byte_0, color_0));
	}

	private void method_10()
	{
		if (Width != 0 && Height != 0)
		{
			bitmap_0 = new Bitmap(Width, Height, PixelFormat.Format32bppPArgb);
			graphics_0 = Graphics.FromImage(bitmap_0);
		}
	}

	private void method_11()
	{
		MemoryStream memoryStream = new MemoryStream(checked(dictionary_0.Count * 4));
		Struct0[] struct0_ = Struct0_0;
		foreach (Struct0 @struct in struct0_)
		{
			memoryStream.Write(BitConverter.GetBytes(@struct.Color_0.ToArgb()), 0, 4);
		}
		memoryStream.Close();
		string_0 = Convert.ToBase64String(memoryStream.ToArray());
	}

	private void method_12()
	{
		if (!DesignMode && bool_0)
		{
			if (bool_5)
			{
				Class10.smethod_2(method_0);
			}
			else
			{
				Class10.smethod_3(method_0);
			}
		}
	}

	protected abstract void ColorHook();

	protected abstract void PaintHook();

	protected virtual void vmethod_0()
	{
	}

	protected virtual void vmethod_1()
	{
	}

	protected Rectangle method_13(Rectangle rectangle_4, int int_2)
	{
		ref Rectangle reference = ref rectangle_0;
		reference = checked(new Rectangle(rectangle_4.X + int_2, rectangle_4.Y + int_2, rectangle_4.Width - int_2 * 2, rectangle_4.Height - int_2 * 2));
		return rectangle_0;
	}

	protected Size method_14(Size size_3, int int_2)
	{
		ref Size reference = ref size_1;
		reference = checked(new Size(size_3.Width + int_2, size_3.Height + int_2));
		return size_1;
	}

	protected Point method_15(Point point_4, int int_2)
	{
		ref Point reference = ref point_0;
		reference = checked(new Point(point_4.X + int_2, point_4.Y + int_2));
		return point_0;
	}

	protected Point method_16(Rectangle rectangle_4, Rectangle rectangle_5)
	{
		ref Point reference = ref point_1;
		checked
		{
			reference = new Point(unchecked(rectangle_4.Width / 2) - unchecked(rectangle_5.Width / 2) + rectangle_4.X + rectangle_5.X, unchecked(rectangle_4.Height / 2) - unchecked(rectangle_5.Height / 2) + rectangle_4.Y + rectangle_5.Y);
			return point_1;
		}
	}

	protected Point method_17(Rectangle rectangle_4, Size size_3)
	{
		ref Point reference = ref point_1;
		checked
		{
			reference = new Point(unchecked(rectangle_4.Width / 2) - unchecked(size_3.Width / 2) + rectangle_4.X, unchecked(rectangle_4.Height / 2) - unchecked(size_3.Height / 2) + rectangle_4.Y);
			return point_1;
		}
	}

	protected Point method_18(Rectangle rectangle_4)
	{
		return method_22(Width, Height, rectangle_4.Width, rectangle_4.Height);
	}

	protected Point method_19(Size size_3)
	{
		return method_22(Width, Height, size_3.Width, size_3.Height);
	}

	protected Point method_20(int int_2, int int_3)
	{
		return method_22(Width, Height, int_2, int_3);
	}

	protected Point method_21(Size size_3, Size size_4)
	{
		return method_22(size_3.Width, size_3.Height, size_4.Width, size_4.Height);
	}

	protected Point method_22(int int_2, int int_3, int int_4, int int_5)
	{
		ref Point reference = ref point_1;
		checked
		{
			reference = new Point(unchecked(int_2 / 2) - unchecked(int_4 / 2), unchecked(int_3 / 2) - unchecked(int_5 / 2));
			return point_1;
		}
	}

	protected Size method_23()
	{
		return graphics_1.MeasureString(Text, Font, Width).ToSize();
	}

	protected Size method_24(string string_1)
	{
		return graphics_1.MeasureString(string_1, Font, Width).ToSize();
	}

	protected void method_25(Color color_0, int int_2, int int_3)
	{
		if (bool_4)
		{
			bitmap_0.SetPixel(int_2, int_3, color_0);
			return;
		}
		solidBrush_0 = new SolidBrush(color_0);
		graphics_0.FillRectangle(solidBrush_0, int_2, int_3, 1, 1);
	}

	protected void method_26(Color color_0, int int_2)
	{
		method_28(color_0, 0, 0, Width, Height, int_2);
	}

	protected void method_27(Color color_0, Rectangle rectangle_4, int int_2)
	{
		method_28(color_0, rectangle_4.X, rectangle_4.Y, rectangle_4.Width, rectangle_4.Height, int_2);
	}

	protected void method_28(Color color_0, int int_2, int int_3, int int_4, int int_5, int int_6)
	{
		checked
		{
			method_31(color_0, int_2 + int_6, int_3 + int_6, int_4 - int_6 * 2, int_5 - int_6 * 2);
		}
	}

	protected void method_29(Color color_0)
	{
		method_31(color_0, 0, 0, Width, Height);
	}

	protected void method_30(Color color_0, Rectangle rectangle_4)
	{
		method_31(color_0, rectangle_4.X, rectangle_4.Y, rectangle_4.Width, rectangle_4.Height);
	}

	protected void method_31(Color color_0, int int_2, int int_3, int int_4, int int_5)
	{
		checked
		{
			if (!bool_3)
			{
				if (bool_4)
				{
					bitmap_0.SetPixel(int_2, int_3, color_0);
					bitmap_0.SetPixel(int_2 + (int_4 - 1), int_3, color_0);
					bitmap_0.SetPixel(int_2, int_3 + (int_5 - 1), color_0);
					bitmap_0.SetPixel(int_2 + (int_4 - 1), int_3 + (int_5 - 1), color_0);
				}
				else
				{
					solidBrush_1 = new SolidBrush(color_0);
					graphics_0.FillRectangle(solidBrush_1, int_2, int_3, 1, 1);
					graphics_0.FillRectangle(solidBrush_1, int_2 + (int_4 - 1), int_3, 1, 1);
					graphics_0.FillRectangle(solidBrush_1, int_2, int_3 + (int_5 - 1), 1, 1);
					graphics_0.FillRectangle(solidBrush_1, int_2 + (int_4 - 1), int_3 + (int_5 - 1), 1, 1);
				}
			}
		}
	}

	protected void method_32(Pen pen_0, int int_2)
	{
		method_34(pen_0, 0, 0, Width, Height, int_2);
	}

	protected void method_33(Pen pen_0, Rectangle rectangle_4, int int_2)
	{
		method_34(pen_0, rectangle_4.X, rectangle_4.Y, rectangle_4.Width, rectangle_4.Height, int_2);
	}

	protected void method_34(Pen pen_0, int int_2, int int_3, int int_4, int int_5, int int_6)
	{
		checked
		{
			method_37(pen_0, int_2 + int_6, int_3 + int_6, int_4 - int_6 * 2, int_5 - int_6 * 2);
		}
	}

	protected void method_35(Pen pen_0)
	{
		method_37(pen_0, 0, 0, Width, Height);
	}

	protected void method_36(Pen pen_0, Rectangle rectangle_4)
	{
		method_37(pen_0, rectangle_4.X, rectangle_4.Y, rectangle_4.Width, rectangle_4.Height);
	}

	protected void method_37(Pen pen_0, int int_2, int int_3, int int_4, int int_5)
	{
		checked
		{
			graphics_0.DrawRectangle(pen_0, int_2, int_3, int_4 - 1, int_5 - 1);
		}
	}

	protected void method_38(Brush brush_0, HorizontalAlignment horizontalAlignment_0, int int_2, int int_3)
	{
		method_39(brush_0, Text, horizontalAlignment_0, int_2, int_3);
	}

	protected void method_39(Brush brush_0, string string_1, HorizontalAlignment horizontalAlignment_0, int int_2, int int_3)
	{
		checked
		{
			if (string_1.Length != 0)
			{
				size_2 = method_24(string_1);
				point_2 = method_19(size_2);
				switch (horizontalAlignment_0)
				{
				case HorizontalAlignment.Left:
					graphics_0.DrawString(string_1, Font, brush_0, int_2, point_2.Y + int_3);
					break;
				case HorizontalAlignment.Right:
					graphics_0.DrawString(string_1, Font, brush_0, Width - size_2.Width - int_2, point_2.Y + int_3);
					break;
				case HorizontalAlignment.Center:
					graphics_0.DrawString(string_1, Font, brush_0, point_2.X + int_2, point_2.Y + int_3);
					break;
				}
			}
		}
	}

	protected void method_40(Brush brush_0, Point point_4)
	{
		if (Text.Length != 0)
		{
			graphics_0.DrawString(Text, Font, brush_0, point_4);
		}
	}

	protected void method_41(Brush brush_0, int int_2, int int_3)
	{
		if (Text.Length != 0)
		{
			graphics_0.DrawString(Text, Font, brush_0, int_2, int_3);
		}
	}

	protected void method_42(HorizontalAlignment horizontalAlignment_0, int int_2, int int_3)
	{
		method_43(image_0, horizontalAlignment_0, int_2, int_3);
	}

	protected void method_43(Image image_1, HorizontalAlignment horizontalAlignment_0, int int_2, int int_3)
	{
		checked
		{
			if (image_1 != null)
			{
				point_3 = method_19(image_1.Size);
				switch (horizontalAlignment_0)
				{
				case HorizontalAlignment.Left:
					graphics_0.DrawImage(image_1, int_2, point_3.Y + int_3, image_1.Width, image_1.Height);
					break;
				case HorizontalAlignment.Right:
					graphics_0.DrawImage(image_1, Width - image_1.Width - int_2, point_3.Y + int_3, image_1.Width, image_1.Height);
					break;
				case HorizontalAlignment.Center:
					graphics_0.DrawImage(image_1, point_3.X + int_2, point_3.Y + int_3, image_1.Width, image_1.Height);
					break;
				}
			}
		}
	}

	protected void method_44(Point point_4)
	{
		method_47(image_0, point_4.X, point_4.Y);
	}

	protected void method_45(int int_2, int int_3)
	{
		method_47(image_0, int_2, int_3);
	}

	protected void method_46(Image image_1, Point point_4)
	{
		method_47(image_1, point_4.X, point_4.Y);
	}

	protected void method_47(Image image_1, int int_2, int int_3)
	{
		if (image_1 != null)
		{
			graphics_0.DrawImage(image_1, int_2, int_3, image_1.Width, image_1.Height);
		}
	}

	protected void method_48(ColorBlend colorBlend_0, int int_2, int int_3, int int_4, int int_5)
	{
		ref Rectangle reference = ref rectangle_1;
		reference = new Rectangle(int_2, int_3, int_4, int_5);
		method_50(colorBlend_0, rectangle_1);
	}

	protected void method_49(ColorBlend colorBlend_0, int int_2, int int_3, int int_4, int int_5, float float_0)
	{
		ref Rectangle reference = ref rectangle_1;
		reference = new Rectangle(int_2, int_3, int_4, int_5);
		method_51(colorBlend_0, rectangle_1, float_0);
	}

	protected void method_50(ColorBlend colorBlend_0, Rectangle rectangle_4)
	{
		linearGradientBrush_0 = new LinearGradientBrush(rectangle_4, Color.Empty, Color.Empty, 90f);
		linearGradientBrush_0.InterpolationColors = colorBlend_0;
		graphics_0.FillRectangle(linearGradientBrush_0, rectangle_4);
	}

	protected void method_51(ColorBlend colorBlend_0, Rectangle rectangle_4, float float_0)
	{
		linearGradientBrush_0 = new LinearGradientBrush(rectangle_4, Color.Empty, Color.Empty, float_0);
		linearGradientBrush_0.InterpolationColors = colorBlend_0;
		graphics_0.FillRectangle(linearGradientBrush_0, rectangle_4);
	}

	protected void method_52(Color color_0, Color color_1, int int_2, int int_3, int int_4, int int_5)
	{
		ref Rectangle reference = ref rectangle_1;
		reference = new Rectangle(int_2, int_3, int_4, int_5);
		method_54(color_0, color_1, rectangle_1);
	}

	protected void method_53(Color color_0, Color color_1, int int_2, int int_3, int int_4, int int_5, float float_0)
	{
		ref Rectangle reference = ref rectangle_1;
		reference = new Rectangle(int_2, int_3, int_4, int_5);
		method_55(color_0, color_1, rectangle_1, float_0);
	}

	protected void method_54(Color color_0, Color color_1, Rectangle rectangle_4)
	{
		linearGradientBrush_0 = new LinearGradientBrush(rectangle_4, color_0, color_1, 90f);
		graphics_0.FillRectangle(linearGradientBrush_0, rectangle_4);
	}

	protected void method_55(Color color_0, Color color_1, Rectangle rectangle_4, float float_0)
	{
		linearGradientBrush_0 = new LinearGradientBrush(rectangle_4, color_0, color_1, float_0);
		graphics_0.FillRectangle(linearGradientBrush_0, rectangle_4);
	}

	public void method_56(ColorBlend colorBlend_0, int int_2, int int_3, int int_4, int int_5)
	{
		ref Rectangle reference = ref rectangle_2;
		reference = new Rectangle(int_2, int_3, int_4, int_5);
		method_61(colorBlend_0, rectangle_2, int_4 / 2, int_5 / 2);
	}

	public void method_57(ColorBlend colorBlend_0, int int_2, int int_3, int int_4, int int_5, Point point_4)
	{
		ref Rectangle reference = ref rectangle_2;
		reference = new Rectangle(int_2, int_3, int_4, int_5);
		method_61(colorBlend_0, rectangle_2, point_4.X, point_4.Y);
	}

	public void method_58(ColorBlend colorBlend_0, int int_2, int int_3, int int_4, int int_5, int int_6, int int_7)
	{
		ref Rectangle reference = ref rectangle_2;
		reference = new Rectangle(int_2, int_3, int_4, int_5);
		method_61(colorBlend_0, rectangle_2, int_6, int_7);
	}

	public void method_59(ColorBlend colorBlend_0, Rectangle rectangle_4)
	{
		method_61(colorBlend_0, rectangle_4, rectangle_4.Width / 2, rectangle_4.Height / 2);
	}

	public void method_60(ColorBlend colorBlend_0, Rectangle rectangle_4, Point point_4)
	{
		method_61(colorBlend_0, rectangle_4, point_4.X, point_4.Y);
	}

	public void method_61(ColorBlend colorBlend_0, Rectangle rectangle_4, int int_2, int int_3)
	{
		graphicsPath_0.Reset();
		checked
		{
			graphicsPath_0.AddEllipse(rectangle_4.X, rectangle_4.Y, rectangle_4.Width - 1, rectangle_4.Height - 1);
			pathGradientBrush_0 = new PathGradientBrush(graphicsPath_0);
			PathGradientBrush pathGradientBrush = pathGradientBrush_0;
			Point point = new Point(rectangle_4.X + int_2, rectangle_4.Y + int_3);
			pathGradientBrush.CenterPoint = point;
			pathGradientBrush_0.InterpolationColors = colorBlend_0;
			if (graphics_0.SmoothingMode == SmoothingMode.AntiAlias)
			{
				graphics_0.FillEllipse(pathGradientBrush_0, rectangle_4.X + 1, rectangle_4.Y + 1, rectangle_4.Width - 3, rectangle_4.Height - 3);
			}
			else
			{
				graphics_0.FillEllipse(pathGradientBrush_0, rectangle_4);
			}
		}
	}

	protected void method_62(Color color_0, Color color_1, int int_2, int int_3, int int_4, int int_5)
	{
		ref Rectangle reference = ref rectangle_2;
		reference = new Rectangle(int_2, int_3, int_4, int_5);
		method_64(color_0, color_1, rectangle_2);
	}

	protected void method_63(Color color_0, Color color_1, int int_2, int int_3, int int_4, int int_5, float float_0)
	{
		ref Rectangle reference = ref rectangle_2;
		reference = new Rectangle(int_2, int_3, int_4, int_5);
		method_65(color_0, color_1, rectangle_2, float_0);
	}

	protected void method_64(Color color_0, Color color_1, Rectangle rectangle_4)
	{
		linearGradientBrush_1 = new LinearGradientBrush(rectangle_4, color_0, color_1, 90f);
		graphics_0.FillEllipse(linearGradientBrush_1, rectangle_4);
	}

	protected void method_65(Color color_0, Color color_1, Rectangle rectangle_4, float float_0)
	{
		linearGradientBrush_1 = new LinearGradientBrush(rectangle_4, color_0, color_1, float_0);
		graphics_0.FillEllipse(linearGradientBrush_1, rectangle_4);
	}

	public GraphicsPath method_66(int int_2, int int_3, int int_4, int int_5, int int_6)
	{
		ref Rectangle reference = ref rectangle_3;
		reference = new Rectangle(int_2, int_3, int_4, int_5);
		return method_67(rectangle_3, int_6);
	}

	public GraphicsPath method_67(Rectangle rectangle_4, int int_2)
	{
		graphicsPath_1 = new GraphicsPath(FillMode.Winding);
		graphicsPath_1.AddArc(rectangle_4.X, rectangle_4.Y, int_2, int_2, 180f, 90f);
		checked
		{
			graphicsPath_1.AddArc(rectangle_4.Right - int_2, rectangle_4.Y, int_2, int_2, 270f, 90f);
			graphicsPath_1.AddArc(rectangle_4.Right - int_2, rectangle_4.Bottom - int_2, int_2, int_2, 0f, 90f);
			graphicsPath_1.AddArc(rectangle_4.X, rectangle_4.Bottom - int_2, int_2, int_2, 90f, 90f);
			graphicsPath_1.CloseFigure();
			return graphicsPath_1;
		}
	}
}
