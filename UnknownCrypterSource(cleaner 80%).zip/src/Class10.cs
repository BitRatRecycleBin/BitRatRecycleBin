using System;
using System.Collections.Generic;
using Microsoft.VisualBasic.CompilerServices;

[StandardModule]
internal sealed class Class10
{
	public delegate void Delegate6(bool invalidate);

	private static int int_0;

	private static bool bool_0;

	public static Class11 class11_0 = new Class11();

	private const int int_1 = 50;

	private const int int_2 = 10;

	private static List<Delegate6> list_0 = new List<Delegate6>();

	private static void smethod_0(IntPtr intptr_0, bool bool_1)
	{
		bool_0 = int_0 >= 50;
		if (bool_0)
		{
			int_0 = 0;
		}
		checked
		{
			lock (list_0)
			{
				int num = list_0.Count - 1;
				int num2 = 0;
				while (true)
				{
					int num3 = num2;
					int num4 = num;
					if (num3 <= num4)
					{
						list_0[num2](bool_0);
						num2++;
						continue;
					}
					break;
				}
			}
			int_0 += 10;
		}
	}

	private static void smethod_1()
	{
		if (list_0.Count == 0)
		{
			class11_0.method_1();
		}
		else
		{
			class11_0.method_0(0u, 10u, smethod_0);
		}
	}

	public static void smethod_2(Delegate6 delegate6_0)
	{
		lock (list_0)
		{
			if (!list_0.Contains(delegate6_0))
			{
				list_0.Add(delegate6_0);
				smethod_1();
			}
		}
	}

	public static void smethod_3(Delegate6 delegate6_0)
	{
		lock (list_0)
		{
			if (list_0.Contains(delegate6_0))
			{
				list_0.Remove(delegate6_0);
				smethod_1();
			}
		}
	}
}
