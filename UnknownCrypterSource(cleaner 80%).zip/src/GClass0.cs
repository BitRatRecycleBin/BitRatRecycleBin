using System.Diagnostics;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

public class GClass0
{
	[DebuggerNonUserCode]
	public GClass0()
	{
	}

	public static bool smethod_0(string string_0)
	{
		ProcessStartInfo processStartInfo = new ProcessStartInfo(Application.StartupPath + "\\compiler\\bin\\javac.exe", "\"" + string_0 + "\"");
		processStartInfo.CreateNoWindow = true;
		processStartInfo.RedirectStandardOutput = true;
		processStartInfo.RedirectStandardError = true;
		processStartInfo.UseShellExecute = false;
		Process process = new Process();
		process.StartInfo = processStartInfo;
		process.Start();
		string text = process.StandardOutput.ReadToEnd();
		process.WaitForExit();
		if ((Operators.CompareString(text.Trim(), "", TextCompare: false) == 0) | (Operators.CompareString(text.Trim(), "\r\n", TextCompare: false) == 0))
		{
			return true;
		}
		return false;
	}

	public static bool smethod_1(string string_0)
	{
		ProcessStartInfo processStartInfo = new ProcessStartInfo(Application.StartupPath + "\\compiler\\bin\\jar.exe", string_0);
		processStartInfo.CreateNoWindow = true;
		processStartInfo.RedirectStandardOutput = true;
		processStartInfo.RedirectStandardError = true;
		processStartInfo.UseShellExecute = false;
		processStartInfo.WorkingDirectory = Application.StartupPath + "\\compiler\\bin";
		Process process = new Process();
		process.StartInfo = processStartInfo;
		process.Start();
		string text = process.StandardOutput.ReadToEnd();
		process.WaitForExit();
		if ((Operators.CompareString(text.Trim(), "", TextCompare: false) == 0) | (Operators.CompareString(text.Trim(), "\r\n", TextCompare: false) == 0))
		{
			return true;
		}
		return false;
	}
}
