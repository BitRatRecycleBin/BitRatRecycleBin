using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

[DefaultEvent("CheckedChanged")]
public class GControl7 : Control
{
	public delegate void GDelegate4(object sender);

	private static List<WeakReference> list_0 = new List<WeakReference>();

	private Rectangle rectangle_0;

	private LinearGradientBrush linearGradientBrush_0;

	private Enum2 enum2_0;

	private bool bool_0;

	private GDelegate4 gdelegate4_0;

	public bool Boolean_0
	{
		get
		{
			return bool_0;
		}
		set
		{
			bool_0 = value;
			method_0();
			gdelegate4_0?.Invoke(this);
			Invalidate();
		}
	}

	public event GDelegate4 Event_0
	{
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		add
		{
			gdelegate4_0 = (GDelegate4)Delegate.Combine(gdelegate4_0, value);
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		remove
		{
			gdelegate4_0 = (GDelegate4)Delegate.Remove(gdelegate4_0, value);
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	protected override void OnMouseEnter(EventArgs e)
	{
		base.OnMouseEnter(e);
		enum2_0 = Enum2.Over;
		Invalidate();
	}

	protected override void OnMouseDown(MouseEventArgs e)
	{
		base.OnMouseDown(e);
		enum2_0 = Enum2.Down;
		Invalidate();
	}

	protected override void OnMouseLeave(EventArgs e)
	{
		base.OnMouseLeave(e);
		enum2_0 = Enum2.None;
		Invalidate();
	}

	protected override void OnMouseUp(MouseEventArgs e)
	{
		base.OnMouseUp(e);
		enum2_0 = Enum2.Over;
		Invalidate();
	}

	protected override void OnResize(EventArgs e)
	{
		base.OnResize(e);
		Height = 16;
	}

	protected override void OnPaintBackground(PaintEventArgs pevent)
	{
	}

	protected override void OnTextChanged(EventArgs e)
	{
		base.OnTextChanged(e);
		Invalidate();
	}

	protected override void OnClick(EventArgs e)
	{
		if (!bool_0)
		{
			Boolean_0 = true;
		}
		base.OnClick(e);
	}

	protected override void OnCreateControl()
	{
		base.OnCreateControl();
		method_0();
	}

	private void method_0()
	{
		if (!IsHandleCreated || !bool_0)
		{
			return;
		}
		IEnumerator enumerator = default(IEnumerator);
		try
		{
			enumerator = Parent.Controls.GetEnumerator();
			while (enumerator.MoveNext())
			{
				Control control = (Control)enumerator.Current;
				if (control != this && control is GControl7)
				{
					((GControl7)control).Boolean_0 = false;
				}
			}
		}
		finally
		{
			if (enumerator is IDisposable)
			{
				(enumerator as IDisposable).Dispose();
			}
		}
	}

	public GControl7()
	{
		smethod_0(this);
		enum2_0 = Enum2.None;
		BackColor = Color.FromArgb(42, 47, 49);
		ForeColor = Color.White;
		Size size2 = (Size = new Size(150, 16));
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Bitmap bitmap = new Bitmap(Width, Height);
		Graphics graphics = Graphics.FromImage(bitmap);
		new Class18();
		checked
		{
			Rectangle rect = new Rectangle(0, 0, Height - 1, Height - 1);
			graphics.SmoothingMode = SmoothingMode.HighQuality;
			graphics.Clear(BackColor);
			LinearGradientBrush brush = new LinearGradientBrush(rect, Color.FromArgb(36, 40, 42), Color.FromArgb(66, 70, 72), 90f);
			graphics.FillEllipse(brush, rect);
			Pen pen = new Pen(Color.FromArgb(44, 48, 50));
			Rectangle rect2 = new Rectangle(1, 1, Height - 3, Height - 3);
			graphics.DrawEllipse(pen, rect2);
			graphics.DrawEllipse(new Pen(Color.FromArgb(102, 108, 112)), rect);
			if (Boolean_0)
			{
				rect2 = new Rectangle(4, 4, Height - 9, Height - 8);
				LinearGradientBrush brush2 = new LinearGradientBrush(rect2, Color.White, Color.Black, 90f);
				rect2 = new Rectangle(4, 4, Height - 9, Height - 9);
				graphics.FillEllipse(brush2, rect2);
			}
			string s = Text;
			Font font = Font;
			Brush white = Brushes.White;
			Point point = new Point(18, 0);
			graphics.DrawString(s, font, white, point, new StringFormat
			{
				Alignment = StringAlignment.Near,
				LineAlignment = StringAlignment.Near
			});
			NewLateBinding.LateCall(e.Graphics, null, "DrawImage", new object[3]
			{
				RuntimeHelpers.GetObjectValue(bitmap.Clone()),
				0,
				0
			}, null, null, null, IgnoreReturn: true);
			graphics.Dispose();
			bitmap.Dispose();
		}
	}
}
