using System.Drawing;
using System.Drawing.Drawing2D;
using Microsoft.VisualBasic.CompilerServices;

[StandardModule]
internal sealed class Class7
{
	public static GraphicsPath smethod_0(Rectangle rectangle_0, int int_0)
	{
		GraphicsPath graphicsPath = new GraphicsPath();
		checked
		{
			int num = int_0 * 2;
			Rectangle rect = new Rectangle(rectangle_0.X, rectangle_0.Y, num, num);
			graphicsPath.AddArc(rect, -180f, 90f);
			rect = new Rectangle(rectangle_0.Width - num + rectangle_0.X, rectangle_0.Y, num, num);
			graphicsPath.AddArc(rect, -90f, 90f);
			rect = new Rectangle(rectangle_0.Width - num + rectangle_0.X, rectangle_0.Height - num + rectangle_0.Y, num, num);
			graphicsPath.AddArc(rect, 0f, 90f);
			rect = new Rectangle(rectangle_0.X, rectangle_0.Height - num + rectangle_0.Y, num, num);
			graphicsPath.AddArc(rect, 90f, 90f);
			graphicsPath.CloseAllFigures();
			return graphicsPath;
		}
	}

	public static GraphicsPath smethod_1(Rectangle rectangle_0, int int_0)
	{
		GraphicsPath graphicsPath = new GraphicsPath();
		checked
		{
			int num = int_0 * 2;
			Rectangle rect = new Rectangle(rectangle_0.X, rectangle_0.Y, num, num);
			graphicsPath.AddArc(rect, -180f, 90f);
			rect = new Rectangle(rectangle_0.Width - num + rectangle_0.X, rectangle_0.Y, num, num);
			graphicsPath.AddArc(rect, -90f, 90f);
			Point point = new Point(rectangle_0.X + rectangle_0.Width, rectangle_0.Y + num);
			Point pt = point;
			Point pt2 = new Point(rectangle_0.X + rectangle_0.Width, rectangle_0.Y + rectangle_0.Height);
			graphicsPath.AddLine(pt, pt2);
			pt2 = new Point(rectangle_0.X + rectangle_0.Width, rectangle_0.Y + rectangle_0.Height);
			Point pt3 = pt2;
			point = new Point(rectangle_0.X, rectangle_0.Y + rectangle_0.Height);
			graphicsPath.AddLine(pt3, point);
			pt2 = new Point(rectangle_0.X, rectangle_0.Y + rectangle_0.Height);
			Point pt4 = pt2;
			point = new Point(rectangle_0.X, rectangle_0.Y + num);
			graphicsPath.AddLine(pt4, point);
			graphicsPath.CloseAllFigures();
			return graphicsPath;
		}
	}

	public static GraphicsPath smethod_2(Rectangle rectangle_0, int int_0)
	{
		GraphicsPath graphicsPath = new GraphicsPath();
		checked
		{
			int num = int_0 * 2;
			Rectangle rect = new Rectangle(rectangle_0.X, rectangle_0.Y, num, num);
			graphicsPath.AddArc(rect, -180f, 90f);
			Point point = new Point(rectangle_0.X + num, rectangle_0.Y);
			Point pt = point;
			Point pt2 = new Point(rectangle_0.Width, rectangle_0.Y);
			graphicsPath.AddLine(pt, pt2);
			pt2 = new Point(rectangle_0.X + rectangle_0.Width, rectangle_0.Y);
			Point pt3 = pt2;
			point = new Point(rectangle_0.X + rectangle_0.Width, rectangle_0.Y + rectangle_0.Height);
			graphicsPath.AddLine(pt3, point);
			pt2 = new Point(rectangle_0.X + rectangle_0.Width, rectangle_0.Y + rectangle_0.Height);
			Point pt4 = pt2;
			point = new Point(rectangle_0.X + num, rectangle_0.Y + rectangle_0.Height);
			graphicsPath.AddLine(pt4, point);
			rect = new Rectangle(rectangle_0.X, rectangle_0.Height - num + rectangle_0.Y, num, num);
			graphicsPath.AddArc(rect, 90f, 90f);
			graphicsPath.CloseAllFigures();
			return graphicsPath;
		}
	}

	public static GraphicsPath smethod_3(Rectangle rectangle_0, int int_0)
	{
		GraphicsPath graphicsPath = new GraphicsPath();
		checked
		{
			int num = int_0 * 2;
			Point pt = new Point(rectangle_0.X, rectangle_0.Y);
			Point pt2 = new Point(rectangle_0.X, rectangle_0.Y);
			graphicsPath.AddLine(pt, pt2);
			Rectangle rect = new Rectangle(rectangle_0.Width - num + rectangle_0.X, rectangle_0.Y, num, num);
			graphicsPath.AddArc(rect, -90f, 90f);
			rect = new Rectangle(rectangle_0.Width - num + rectangle_0.X, rectangle_0.Height - num + rectangle_0.Y, num, num);
			graphicsPath.AddArc(rect, 0f, 90f);
			rect = new Rectangle(rectangle_0.X, rectangle_0.Height - num + rectangle_0.Y, num, num);
			graphicsPath.AddArc(rect, 90f, 90f);
			graphicsPath.CloseAllFigures();
			return graphicsPath;
		}
	}

	public static void smethod_4(Graphics graphics_0, string string_0, Font font_0, Brush brush_0, Point point_0)
	{
		Brush black = Brushes.Black;
		Point point = checked(new Point(point_0.X + 1, point_0.Y + 1));
		graphics_0.DrawString(string_0, font_0, black, point);
		graphics_0.DrawString(string_0, font_0, brush_0, point_0);
	}

	public static Rectangle smethod_5(Rectangle rectangle_0, int int_0)
	{
		return checked(new Rectangle(rectangle_0.X + int_0, rectangle_0.Y + int_0, rectangle_0.Width - int_0 * 2, rectangle_0.Height - int_0 * 2));
	}

	public static Color smethod_6(Color color_0, int int_0 = -20)
	{
		Color color = color_0;
		checked
		{
			int red = ((unchecked((int)color.R) + int_0 >= 0) ? ((unchecked((int)color.R) + int_0 <= 255) ? (unchecked((int)color.R) + int_0) : 255) : 0);
			int green = ((unchecked((int)color.G) + int_0 >= 0) ? ((unchecked((int)color.G) + int_0 <= 255) ? (unchecked((int)color.G) + int_0) : 255) : 0);
			int blue = ((unchecked((int)color.B) + int_0 >= 0) ? ((unchecked((int)color.B) + int_0 <= 255) ? (unchecked((int)color.B) + int_0) : 255) : 0);
			return Color.FromArgb(red, green, blue);
		}
	}
}
