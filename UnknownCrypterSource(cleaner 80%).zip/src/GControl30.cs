using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

public class GControl30 : ContainerControl
{
	private static List<WeakReference> list_0 = new List<WeakReference>();

	private Color color_0;

	private Color color_1;

	private Color color_2;

	private Color color_3;

	[Category("Colours")]
	public Color Color_0
	{
		get
		{
			return color_3;
		}
		set
		{
			color_3 = value;
		}
	}

	[Category("Colours")]
	public Color Color_1
	{
		get
		{
			return color_2;
		}
		set
		{
			color_2 = value;
		}
	}

	[Category("Colours")]
	public Color Color_2
	{
		get
		{
			return color_1;
		}
		set
		{
			color_1 = value;
		}
	}

	[Category("Colours")]
	public Color Color_3
	{
		get
		{
			return color_0;
		}
		set
		{
			color_0 = value;
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	public GControl30()
	{
		smethod_0(this);
		color_0 = Color.FromArgb(37, 37, 38);
		color_1 = Color.FromArgb(45, 45, 48);
		color_2 = Color.FromArgb(129, 129, 131);
		color_3 = Color.FromArgb(2, 118, 196);
		SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		DoubleBuffered = true;
		Size size2 = (Size = new Size(160, 110));
		Font = new Font("Segoe UI", 10f, FontStyle.Regular);
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Graphics graphics = e.Graphics;
		Graphics graphics2 = graphics;
		graphics2.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
		graphics2.SmoothingMode = SmoothingMode.HighQuality;
		graphics2.PixelOffsetMode = PixelOffsetMode.HighQuality;
		Graphics graphics3 = graphics2;
		SolidBrush brush = new SolidBrush(color_0);
		Rectangle rect = new Rectangle(0, 28, Width, Height);
		graphics3.FillRectangle(brush, rect);
		Graphics graphics4 = graphics2;
		SolidBrush brush2 = new SolidBrush(color_1);
		rect = new Rectangle(0, 0, Width, 28);
		graphics4.FillRectangle(brush2, rect);
		Graphics graphics5 = graphics2;
		SolidBrush brush3 = new SolidBrush(Color.FromArgb(33, 33, 33));
		rect = new Rectangle(0, 28, Width, 1);
		graphics5.FillRectangle(brush3, rect);
		Graphics graphics6 = graphics2;
		string s = Text;
		Font font = Font;
		SolidBrush brush4 = new SolidBrush(color_2);
		Point point = new Point(5, 5);
		graphics6.DrawString(s, font, brush4, point);
		Graphics graphics7 = graphics2;
		Pen pen = new Pen(color_3, 2f);
		rect = new Rectangle(0, 0, Width, Height);
		graphics7.DrawRectangle(pen, rect);
		graphics2.InterpolationMode = InterpolationMode.HighQualityBicubic;
		graphics2 = null;
	}
}
