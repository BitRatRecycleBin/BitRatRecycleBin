using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

public class GControl23 : Control
{
	public enum GEnum8
	{
		None,
		One,
		Two
	}

	public enum GEnum9
	{
		One,
		Two,
		Three
	}

	public enum GEnum10
	{
		Left,
		Center,
		Right
	}

	private static List<WeakReference> list_0 = new List<WeakReference>();

	private Color color_0;

	private Color color_1;

	private Color color_2;

	private Color color_3;

	private Color color_4;

	private bool bool_0;

	private GEnum8 genum8_0;

	private GEnum9 genum9_0;

	private bool bool_1;

	private StringFormat stringFormat_0;

	private string string_0;

	private GEnum10 genum10_0;

	private StringFormat stringFormat_1;

	private string string_1;

	private GEnum10 genum10_1;

	private StringFormat stringFormat_2;

	private string string_2;

	private GEnum10 genum10_2;

	[Category("First Label Options")]
	public string String_0
	{
		get
		{
			return string_0;
		}
		set
		{
			string_0 = value;
		}
	}

	[Category("First Label Options")]
	public GEnum10 GEnum10_0
	{
		get
		{
			return genum10_0;
		}
		set
		{
			switch (value)
			{
			case GEnum10.Left:
				stringFormat_0 = new StringFormat
				{
					Alignment = StringAlignment.Near,
					LineAlignment = StringAlignment.Center
				};
				genum10_0 = value;
				break;
			case GEnum10.Center:
				stringFormat_0 = new StringFormat
				{
					Alignment = StringAlignment.Center,
					LineAlignment = StringAlignment.Center
				};
				genum10_0 = value;
				break;
			case GEnum10.Right:
				stringFormat_0 = new StringFormat
				{
					Alignment = StringAlignment.Far,
					LineAlignment = StringAlignment.Center
				};
				genum10_0 = value;
				break;
			}
		}
	}

	[Category("Second Label Options")]
	public string String_1
	{
		get
		{
			return string_1;
		}
		set
		{
			string_1 = value;
		}
	}

	[Category("Second Label Options")]
	public GEnum10 GEnum10_1
	{
		get
		{
			return genum10_1;
		}
		set
		{
			switch (value)
			{
			case GEnum10.Left:
				stringFormat_1 = new StringFormat
				{
					Alignment = StringAlignment.Near,
					LineAlignment = StringAlignment.Center
				};
				genum10_1 = value;
				break;
			case GEnum10.Center:
				stringFormat_1 = new StringFormat
				{
					Alignment = StringAlignment.Center,
					LineAlignment = StringAlignment.Center
				};
				genum10_1 = value;
				break;
			case GEnum10.Right:
				stringFormat_1 = new StringFormat
				{
					Alignment = StringAlignment.Far,
					LineAlignment = StringAlignment.Center
				};
				genum10_1 = value;
				break;
			}
		}
	}

	[Category("Third Label Options")]
	public string String_2
	{
		get
		{
			return string_2;
		}
		set
		{
			string_2 = value;
		}
	}

	[Category("Third Label Options")]
	public GEnum10 GEnum10_2
	{
		get
		{
			return genum10_2;
		}
		set
		{
			switch (value)
			{
			case GEnum10.Left:
				stringFormat_2 = new StringFormat
				{
					Alignment = StringAlignment.Near,
					LineAlignment = StringAlignment.Center
				};
				genum10_2 = value;
				break;
			case GEnum10.Center:
				stringFormat_2 = new StringFormat
				{
					Alignment = StringAlignment.Center,
					LineAlignment = StringAlignment.Center
				};
				genum10_2 = value;
				break;
			case GEnum10.Right:
				stringFormat_2 = new StringFormat
				{
					Alignment = StringAlignment.Far,
					LineAlignment = StringAlignment.Center
				};
				genum10_2 = value;
				break;
			}
		}
	}

	[Category("Colours")]
	public Color Color_0
	{
		get
		{
			return color_1;
		}
		set
		{
			color_1 = value;
		}
	}

	[Category("Colours")]
	public Color Color_1
	{
		get
		{
			return color_3;
		}
		set
		{
			color_3 = value;
		}
	}

	[Category("Colours")]
	public Color Color_2
	{
		get
		{
			return color_0;
		}
		set
		{
			color_0 = value;
		}
	}

	[Category("Control")]
	public GEnum9 GEnum9_0
	{
		get
		{
			return genum9_0;
		}
		set
		{
			genum9_0 = value;
		}
	}

	[Category("Control")]
	public GEnum8 GEnum8_0
	{
		get
		{
			return genum8_0;
		}
		set
		{
			genum8_0 = value;
		}
	}

	public bool Boolean_0
	{
		get
		{
			return bool_1;
		}
		set
		{
			bool_1 = value;
		}
	}

	[Category("Colours")]
	public Color Color_3
	{
		get
		{
			return color_2;
		}
		set
		{
			color_2 = value;
		}
	}

	public bool Boolean_1
	{
		get
		{
			return bool_0;
		}
		set
		{
			bool_0 = value;
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	protected override void CreateHandle()
	{
		base.CreateHandle();
		Dock = DockStyle.Bottom;
	}

	public GControl23()
	{
		smethod_0(this);
		color_0 = Color.FromArgb(153, 153, 153);
		color_1 = Color.FromArgb(45, 45, 48);
		color_2 = Color.FromArgb(0, 122, 204);
		color_3 = Color.FromArgb(27, 27, 29);
		color_4 = Color.FromArgb(45, 45, 48);
		bool_0 = true;
		genum8_0 = GEnum8.One;
		genum9_0 = GEnum9.One;
		bool_1 = true;
		string_0 = "Label1";
		genum10_0 = GEnum10.Left;
		string_1 = "Label2";
		genum10_1 = GEnum10.Center;
		string_2 = "Label3";
		genum10_2 = GEnum10.Center;
		SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		DoubleBuffered = true;
		Font = new Font("Segoe UI", 9f);
		Size size2 = (Size = new Size(Width, 20));
		Cursor = Cursors.Arrow;
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Graphics graphics = e.Graphics;
		Rectangle rect = new Rectangle(0, 0, Width, Height);
		Graphics graphics2 = graphics;
		graphics2.SmoothingMode = SmoothingMode.HighQuality;
		graphics2.PixelOffsetMode = PixelOffsetMode.HighQuality;
		graphics2.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
		graphics2.FillRectangle(new SolidBrush(Color_0), rect);
		checked
		{
			switch (genum8_0)
			{
			case GEnum8.None:
				if (genum9_0 == GEnum9.One)
				{
					Graphics graphics14 = graphics2;
					string s7 = string_0;
					Font font7 = Font;
					SolidBrush brush9 = new SolidBrush(color_0);
					Rectangle rectangle = new Rectangle(5, 1, Width - 5, Height);
					graphics14.DrawString(s7, font7, brush9, rectangle, stringFormat_0);
				}
				else if (genum9_0 == GEnum9.Two)
				{
					Graphics graphics15 = graphics2;
					string s8 = string_0;
					Font font8 = Font;
					SolidBrush brush10 = new SolidBrush(color_0);
					Rectangle rectangle = new Rectangle(5, 1, (int)Math.Round((double)Width / 2.0 - 6.0), Height);
					graphics15.DrawString(s8, font8, brush10, rectangle, stringFormat_0);
					Graphics graphics16 = graphics2;
					string s9 = string_1;
					Font font9 = Font;
					SolidBrush brush11 = new SolidBrush(color_0);
					rectangle = new Rectangle((int)Math.Round((double)Width - ((double)Width / 2.0 + 5.0)), 1, (int)Math.Round((double)Width / 2.0 - 4.0), Height);
					graphics16.DrawString(s9, font9, brush11, rectangle, stringFormat_1);
					Graphics graphics17 = graphics2;
					Pen pen4 = new Pen(color_4, 1f);
					Point pt2 = new Point((int)Math.Round((double)Width / 2.0), 6);
					Point pt5 = pt2;
					Point point = new Point((int)Math.Round((double)Width / 2.0), Height - 6);
					graphics17.DrawLine(pen4, pt5, point);
				}
				else
				{
					Graphics graphics18 = graphics2;
					string s10 = string_0;
					Font font10 = Font;
					SolidBrush brush12 = new SolidBrush(color_0);
					Rectangle rectangle = new Rectangle(5, 1, (int)Math.Round((double)Width - (double)Width / 3.0 * 2.0 - 6.0), Height);
					graphics18.DrawString(s10, font10, brush12, rectangle, stringFormat_0);
					Graphics graphics19 = graphics2;
					string s11 = string_1;
					Font font11 = Font;
					SolidBrush brush13 = new SolidBrush(color_0);
					rectangle = new Rectangle((int)Math.Round((double)Width - (double)Width / 3.0 * 2.0 + 5.0), 1, (int)Math.Round((double)Width - (double)Width / 3.0 * 2.0 - 6.0), Height);
					graphics19.DrawString(s11, font11, brush13, rectangle, stringFormat_1);
					Graphics graphics20 = graphics2;
					string s12 = string_2;
					Font font12 = Font;
					SolidBrush brush14 = new SolidBrush(color_0);
					rectangle = new Rectangle((int)Math.Round((double)Width - (double)Width / 3.0 + 5.0), 1, (int)Math.Round((double)Width / 3.0 - 6.0), Height);
					graphics20.DrawString(s12, font12, brush14, rectangle, stringFormat_2);
					Graphics graphics21 = graphics2;
					Pen pen5 = new Pen(color_4, 1f);
					Point point = new Point((int)Math.Round((double)Width - (double)Width / 3.0 * 2.0), 6);
					Point pt6 = point;
					Point pt2 = new Point((int)Math.Round((double)Width - (double)Width / 3.0 * 2.0), Height - 6);
					graphics21.DrawLine(pen5, pt6, pt2);
					Graphics graphics22 = graphics2;
					Pen pen6 = new Pen(color_4, 1f);
					point = new Point((int)Math.Round((double)Width - (double)Width / 3.0), 6);
					Point pt7 = point;
					pt2 = new Point((int)Math.Round((double)Width - (double)Width / 3.0), Height - 6);
					graphics22.DrawLine(pen6, pt7, pt2);
				}
				break;
			case GEnum8.One:
			{
				Rectangle rectangle;
				if (genum9_0 == GEnum9.One)
				{
					Graphics graphics23 = graphics2;
					string s13 = string_0;
					Font font13 = Font;
					SolidBrush brush15 = new SolidBrush(color_0);
					rectangle = new Rectangle(22, 1, Width, Height);
					graphics23.DrawString(s13, font13, brush15, rectangle, stringFormat_0);
				}
				else if (genum9_0 == GEnum9.Two)
				{
					Graphics graphics24 = graphics2;
					string s14 = string_0;
					Font font14 = Font;
					SolidBrush brush16 = new SolidBrush(color_0);
					rectangle = new Rectangle(22, 1, (int)Math.Round((double)Width / 2.0 - 24.0), Height);
					graphics24.DrawString(s14, font14, brush16, rectangle, stringFormat_0);
					Graphics graphics25 = graphics2;
					string s15 = string_1;
					Font font15 = Font;
					SolidBrush brush17 = new SolidBrush(color_0);
					rectangle = new Rectangle((int)Math.Round((double)Width / 2.0 + 5.0), 1, (int)Math.Round((double)Width / 2.0 - 10.0), Height);
					graphics25.DrawString(s15, font15, brush17, rectangle, stringFormat_1);
					Graphics graphics26 = graphics2;
					Pen pen7 = new Pen(color_4, 1f);
					Point point = new Point((int)Math.Round((double)Width / 2.0), 6);
					Point pt8 = point;
					Point pt2 = new Point((int)Math.Round((double)Width / 2.0), Height - 6);
					graphics26.DrawLine(pen7, pt8, pt2);
				}
				else
				{
					Graphics graphics27 = graphics2;
					string s16 = string_0;
					Font font16 = Font;
					SolidBrush brush18 = new SolidBrush(color_0);
					rectangle = new Rectangle(22, 1, (int)Math.Round((double)(Width - 78) / 3.0), Height);
					graphics27.DrawString(s16, font16, brush18, rectangle, stringFormat_0);
					Graphics graphics28 = graphics2;
					string s17 = string_1;
					Font font17 = Font;
					SolidBrush brush19 = new SolidBrush(color_0);
					rectangle = new Rectangle((int)Math.Round((double)Width - (double)Width / 3.0 * 2.0 + 5.0), 1, (int)Math.Round((double)Width - (double)Width / 3.0 * 2.0 - 12.0), Height);
					graphics28.DrawString(s17, font17, brush19, rectangle, stringFormat_1);
					Graphics graphics29 = graphics2;
					string s18 = string_2;
					Font font18 = Font;
					SolidBrush brush20 = new SolidBrush(color_0);
					rectangle = new Rectangle((int)Math.Round((double)Width - (double)Width / 3.0 + 6.0), 1, (int)Math.Round((double)Width / 3.0 - 22.0), Height);
					graphics29.DrawString(s18, font18, brush20, rectangle, stringFormat_2);
					Graphics graphics30 = graphics2;
					Pen pen8 = new Pen(color_4, 1f);
					Point point = new Point((int)Math.Round((double)Width - (double)Width / 3.0 * 2.0), 6);
					Point pt9 = point;
					Point pt2 = new Point((int)Math.Round((double)Width - (double)Width / 3.0 * 2.0), Height - 6);
					graphics30.DrawLine(pen8, pt9, pt2);
					Graphics graphics31 = graphics2;
					Pen pen9 = new Pen(color_4, 1f);
					point = new Point((int)Math.Round((double)Width - (double)Width / 3.0), 6);
					Point pt10 = point;
					pt2 = new Point((int)Math.Round((double)Width - (double)Width / 3.0), Height - 6);
					graphics31.DrawLine(pen9, pt10, pt2);
				}
				Graphics graphics32 = graphics2;
				SolidBrush brush21 = new SolidBrush(color_2);
				rectangle = new Rectangle(5, 10, 14, 3);
				graphics32.FillRectangle(brush21, rectangle);
				break;
			}
			case GEnum8.Two:
			{
				Rectangle rectangle;
				if (genum9_0 == GEnum9.One)
				{
					Graphics graphics3 = graphics2;
					string s = string_0;
					Font font = Font;
					SolidBrush brush = new SolidBrush(color_0);
					rectangle = new Rectangle(22, 1, Width - 44, Height);
					graphics3.DrawString(s, font, brush, rectangle, stringFormat_0);
				}
				else if (genum9_0 == GEnum9.Two)
				{
					Graphics graphics4 = graphics2;
					string s2 = string_0;
					Font font2 = Font;
					SolidBrush brush2 = new SolidBrush(color_0);
					rectangle = new Rectangle(22, 1, (int)Math.Round((double)(Width - 46) / 2.0), Height);
					graphics4.DrawString(s2, font2, brush2, rectangle, stringFormat_0);
					Graphics graphics5 = graphics2;
					string s3 = string_1;
					Font font3 = Font;
					SolidBrush brush3 = new SolidBrush(color_0);
					rectangle = new Rectangle((int)Math.Round((double)Width / 2.0 + 5.0), 1, (int)Math.Round((double)Width / 2.0 - 28.0), Height);
					graphics5.DrawString(s3, font3, brush3, rectangle, stringFormat_1);
					Graphics graphics6 = graphics2;
					Pen pen = new Pen(color_4, 1f);
					Point point = new Point((int)Math.Round((double)Width / 2.0), 6);
					Point pt = point;
					Point pt2 = new Point((int)Math.Round((double)Width / 2.0), Height - 6);
					graphics6.DrawLine(pen, pt, pt2);
				}
				else
				{
					Graphics graphics7 = graphics2;
					string s4 = string_0;
					Font font4 = Font;
					SolidBrush brush4 = new SolidBrush(color_0);
					rectangle = new Rectangle(22, 1, (int)Math.Round((double)(Width - 78) / 3.0), Height);
					graphics7.DrawString(s4, font4, brush4, rectangle, stringFormat_0);
					Graphics graphics8 = graphics2;
					string s5 = string_1;
					Font font5 = Font;
					SolidBrush brush5 = new SolidBrush(color_0);
					rectangle = new Rectangle((int)Math.Round((double)Width - (double)Width / 3.0 * 2.0 + 5.0), 1, (int)Math.Round((double)Width - (double)Width / 3.0 * 2.0 - 12.0), Height);
					graphics8.DrawString(s5, font5, brush5, rectangle, stringFormat_1);
					Graphics graphics9 = graphics2;
					string s6 = string_2;
					Font font6 = Font;
					SolidBrush brush6 = new SolidBrush(color_0);
					rectangle = new Rectangle((int)Math.Round((double)Width - (double)Width / 3.0 + 6.0), 1, (int)Math.Round((double)Width / 3.0 - 22.0), Height);
					graphics9.DrawString(s6, font6, brush6, rectangle, stringFormat_2);
					Graphics graphics10 = graphics2;
					Pen pen2 = new Pen(color_4, 1f);
					Point point = new Point((int)Math.Round((double)Width - (double)Width / 3.0 * 2.0), 6);
					Point pt3 = point;
					Point pt2 = new Point((int)Math.Round((double)Width - (double)Width / 3.0 * 2.0), Height - 6);
					graphics10.DrawLine(pen2, pt3, pt2);
					Graphics graphics11 = graphics2;
					Pen pen3 = new Pen(color_4, 1f);
					point = new Point((int)Math.Round((double)Width - (double)Width / 3.0), 6);
					Point pt4 = point;
					pt2 = new Point((int)Math.Round((double)Width - (double)Width / 3.0), Height - 6);
					graphics11.DrawLine(pen3, pt4, pt2);
				}
				Graphics graphics12 = graphics2;
				SolidBrush brush7 = new SolidBrush(color_4);
				rectangle = new Rectangle(5, 10, 14, 3);
				graphics12.FillRectangle(brush7, rectangle);
				Graphics graphics13 = graphics2;
				SolidBrush brush8 = new SolidBrush(color_4);
				rectangle = new Rectangle(Width - 20, 10, 14, 3);
				graphics13.FillRectangle(brush8, rectangle);
				break;
			}
			}
			if (bool_1)
			{
				Graphics graphics33 = graphics2;
				Pen pen10 = new Pen(color_3, 2f);
				Rectangle rectangle = new Rectangle(0, 0, Width, Height);
				graphics33.DrawRectangle(pen10, rectangle);
			}
			graphics2.InterpolationMode = InterpolationMode.HighQualityBicubic;
			graphics2 = null;
		}
	}
}
