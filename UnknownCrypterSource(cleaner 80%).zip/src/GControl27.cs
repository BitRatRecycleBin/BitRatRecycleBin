using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

public class GControl27 : Control
{
	private static List<WeakReference> list_0 = new List<WeakReference>();

	private Color color_0;

	private Color color_1;

	private Color color_2;

	private Color color_3;

	private int int_0;

	private int int_1;

	private int int_2;

	private int int_3;

	private Font font_0;

	[Category("Control")]
	public int Int32_0
	{
		get
		{
			return int_1;
		}
		set
		{
			if (value < int_0)
			{
				int_0 = value;
			}
			int_1 = value;
			Invalidate();
		}
	}

	[Category("Control")]
	public int Int32_1
	{
		get
		{
			if (int_0 == 0)
			{
				return 0;
			}
			return int_0;
		}
		set
		{
			int num = value;
			if (num > int_1)
			{
				value = int_1;
				Invalidate();
			}
			int_0 = value;
			Invalidate();
		}
	}

	[Category("Colours")]
	public Color Color_0
	{
		get
		{
			return color_0;
		}
		set
		{
			color_0 = value;
			Invalidate();
		}
	}

	[Category("Colours")]
	public Color Color_1
	{
		get
		{
			return color_3;
		}
		set
		{
			color_3 = value;
			Invalidate();
		}
	}

	[Category("Colours")]
	public Color Color_2
	{
		get
		{
			return color_2;
		}
		set
		{
			color_2 = value;
			Invalidate();
		}
	}

	[Category("Colours")]
	public Color Color_3
	{
		get
		{
			return color_1;
		}
		set
		{
			color_1 = value;
			Invalidate();
		}
	}

	[Category("Control")]
	public int Int32_2
	{
		get
		{
			return int_2;
		}
		set
		{
			int_2 = value;
		}
	}

	[Category("Control")]
	public int Int32_3
	{
		get
		{
			return int_3;
		}
		set
		{
			int_3 = value;
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	public void method_0(int int_4)
	{
		checked
		{
			Int32_1 += int_4;
		}
	}

	public GControl27()
	{
		smethod_0(this);
		color_0 = Color.FromArgb(28, 28, 28);
		color_1 = Color.FromArgb(45, 45, 48);
		color_2 = Color.FromArgb(62, 62, 66);
		color_3 = Color.FromArgb(153, 153, 153);
		int_0 = 0;
		int_1 = 100;
		int_2 = 110;
		int_3 = 255;
		font_0 = new Font("Segoe UI", 20f);
		SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		DoubleBuffered = true;
		Size size2 = (Size = new Size(78, 78));
		BackColor = Color.Transparent;
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Bitmap bitmap = new Bitmap(Width, Height);
		Graphics graphics = Graphics.FromImage(bitmap);
		Graphics graphics2 = graphics;
		graphics2.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
		graphics2.SmoothingMode = SmoothingMode.HighQuality;
		graphics2.PixelOffsetMode = PixelOffsetMode.HighQuality;
		graphics2.Clear(BackColor);
		int num = int_0;
		checked
		{
			if (num == 0)
			{
				graphics2.DrawArc(new Pen(new SolidBrush(color_0), 7f), 3, 3, Width - 3 - 4, Height - 3 - 3, int_2 - 3, int_3 + 5);
				graphics2.DrawArc(new Pen(new SolidBrush(color_1), 4f), 3, 3, Width - 3 - 4, Height - 3 - 3, int_2, int_3);
				Graphics graphics3 = graphics2;
				string s = Conversions.ToString(int_0);
				Font font = font_0;
				SolidBrush brush = new SolidBrush(color_3);
				Point point = new Point((int)Math.Round((double)Width / 2.0), (int)Math.Round((double)Height / 2.0 - 1.0));
				graphics3.DrawString(s, font, brush, point, new StringFormat
				{
					Alignment = StringAlignment.Center,
					LineAlignment = StringAlignment.Center
				});
			}
			else if (num == int_1)
			{
				graphics2.DrawArc(new Pen(new SolidBrush(color_0), 7f), 3, 3, Width - 3 - 4, Height - 3 - 3, int_2 - 3, int_3 + 5);
				graphics2.DrawArc(new Pen(new SolidBrush(color_1), 4f), 3, 3, Width - 3 - 4, Height - 3 - 3, int_2, int_3);
				graphics2.DrawArc(new Pen(new SolidBrush(color_2), 4f), 3, 3, Width - 3 - 4, Height - 3 - 3, int_2, int_3);
				Graphics graphics4 = graphics2;
				string s2 = Conversions.ToString(int_0);
				Font font2 = font_0;
				SolidBrush brush2 = new SolidBrush(color_3);
				Point point = new Point((int)Math.Round((double)Width / 2.0), (int)Math.Round((double)Height / 2.0 - 1.0));
				graphics4.DrawString(s2, font2, brush2, point, new StringFormat
				{
					Alignment = StringAlignment.Center,
					LineAlignment = StringAlignment.Center
				});
			}
			else
			{
				graphics2.DrawArc(new Pen(new SolidBrush(color_0), 7f), 3, 3, Width - 3 - 4, Height - 3 - 3, int_2 - 3, int_3 + 5);
				graphics2.DrawArc(new Pen(new SolidBrush(color_1), 4f), 3, 3, Width - 3 - 4, Height - 3 - 3, int_2, int_3);
				graphics2.DrawArc(new Pen(new SolidBrush(color_2), 4f), 3, 3, Width - 3 - 4, Height - 3 - 3, int_2, (int)Math.Round((double)int_3 / (double)int_1 * (double)int_0));
				Graphics graphics5 = graphics2;
				string s3 = Conversions.ToString(int_0);
				Font font3 = font_0;
				SolidBrush brush3 = new SolidBrush(color_3);
				Point point = new Point((int)Math.Round((double)Width / 2.0), (int)Math.Round((double)Height / 2.0 - 1.0));
				graphics5.DrawString(s3, font3, brush3, point, new StringFormat
				{
					Alignment = StringAlignment.Center,
					LineAlignment = StringAlignment.Center
				});
			}
			graphics2 = null;
			base.OnPaint(e);
			e.Graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
			e.Graphics.DrawImageUnscaled(bitmap, 0, 0);
			bitmap.Dispose();
		}
	}
}
