using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

public class GControl28 : TabControl
{
	private static List<WeakReference> list_0 = new List<WeakReference>();

	private Color color_0;

	private Color color_1;

	private Color color_2;

	private Color color_3;

	private Color color_4;

	private Color color_5;

	private StringFormat stringFormat_0;

	private TabPage tabPage_0;

	[Category("Colours")]
	public Color Color_0
	{
		get
		{
			return color_4;
		}
		set
		{
			color_4 = value;
		}
	}

	[Category("Colours")]
	public Color Color_1
	{
		get
		{
			return color_5;
		}
		set
		{
			color_5 = value;
		}
	}

	[Category("Colours")]
	public Color Color_2
	{
		get
		{
			return color_0;
		}
		set
		{
			color_0 = value;
		}
	}

	[Category("Colours")]
	public Color Color_3
	{
		get
		{
			return color_1;
		}
		set
		{
			color_1 = value;
		}
	}

	[Category("Colours")]
	public Color Color_4
	{
		get
		{
			return color_2;
		}
		set
		{
			color_2 = value;
		}
	}

	[Category("Colours")]
	public Color Color_5
	{
		get
		{
			return color_3;
		}
		set
		{
			color_3 = value;
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	protected override void CreateHandle()
	{
		base.CreateHandle();
		Alignment = TabAlignment.Top;
	}

	protected override void OnMouseDown(MouseEventArgs e)
	{
		tabPage_0 = method_0();
		base.OnMouseDown(e);
	}

	protected override void OnMouseUp(MouseEventArgs e)
	{
		tabPage_0 = null;
		base.OnMouseUp(e);
	}

	protected override void OnMouseMove(MouseEventArgs e)
	{
		if (e.Button == MouseButtons.Left && tabPage_0 != null)
		{
			DoDragDrop(tabPage_0, DragDropEffects.Move);
		}
		base.OnMouseMove(e);
	}

	protected override void OnDragOver(DragEventArgs drgevent)
	{
		TabPage tabPage = (TabPage)drgevent.Data.GetData(typeof(TabPage));
		TabPage tabPage2 = method_0();
		if (tabPage == tabPage_0 && tabPage2 != null)
		{
			drgevent.Effect = DragDropEffects.Move;
			if (tabPage2 != tabPage)
			{
				method_1(tabPage, tabPage2);
			}
		}
		base.OnDragOver(drgevent);
	}

	private TabPage method_0()
	{
		checked
		{
			int num = TabPages.Count - 1;
			int num2 = 0;
			while (true)
			{
				int num3 = num2;
				int num4 = num;
				if (num3 <= num4)
				{
					if (GetTabRect(num2).Contains(PointToClient(Cursor.Position)))
					{
						break;
					}
					num2++;
					continue;
				}
				return null;
			}
			return TabPages[num2];
		}
	}

	private void method_1(TabPage tabPage_1, TabPage tabPage_2)
	{
		int num = TabPages.IndexOf(tabPage_1);
		int num2 = TabPages.IndexOf(tabPage_2);
		TabPages[num2] = tabPage_1;
		TabPages[num] = tabPage_2;
		if (SelectedIndex == num)
		{
			SelectedIndex = num2;
		}
		else if (SelectedIndex == num2)
		{
			SelectedIndex = num;
		}
		Refresh();
	}

	public GControl28()
	{
		smethod_0(this);
		color_0 = Color.FromArgb(255, 255, 255);
		color_1 = Color.FromArgb(28, 28, 28);
		color_2 = Color.FromArgb(45, 45, 48);
		color_3 = Color.FromArgb(0, 122, 204);
		color_4 = Color.FromArgb(30, 30, 30);
		color_5 = Color.FromArgb(0, 122, 204);
		stringFormat_0 = new StringFormat
		{
			Alignment = StringAlignment.Near,
			LineAlignment = StringAlignment.Center
		};
		SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		DoubleBuffered = true;
		SizeMode = TabSizeMode.Normal;
		Size size2 = (ItemSize = new Size(240, 16));
		AllowDrop = true;
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Graphics graphics = e.Graphics;
		Graphics graphics2 = graphics;
		graphics2.SmoothingMode = SmoothingMode.HighQuality;
		graphics2.PixelOffsetMode = PixelOffsetMode.HighQuality;
		graphics2.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
		graphics2.Clear(color_2);
		try
		{
			SelectedTab.BackColor = color_1;
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			ProjectData.ClearProjectError();
		}
		try
		{
			SelectedTab.BorderStyle = BorderStyle.None;
		}
		catch (Exception projectError2)
		{
			ProjectData.SetProjectError(projectError2);
			ProjectData.ClearProjectError();
		}
		checked
		{
			int num = TabCount - 1;
			int num2 = 0;
			Point point;
			Rectangle rect;
			while (true)
			{
				int num3 = num2;
				int num4 = num;
				if (num3 > num4)
				{
					break;
				}
				point = new Point(GetTabRect(num2).Location.X + 2, GetTabRect(num2).Location.Y);
				Point location = point;
				Size size = new Size(GetTabRect(num2).Width, GetTabRect(num2).Height);
				Rectangle rectangle = new Rectangle(location, size);
				Point location2 = rectangle.Location;
				size = new Size(rectangle.Width, rectangle.Height);
				Rectangle rectangle2 = new Rectangle(location2, size);
				if (num2 == SelectedIndex)
				{
					graphics2.FillRectangle(new SolidBrush(color_2), rectangle2);
					Graphics graphics3 = graphics2;
					SolidBrush brush = new SolidBrush(color_3);
					rect = new Rectangle(rectangle.X - 5, rectangle.Y - 3, rectangle.Width, rectangle.Height + 5);
					graphics3.FillRectangle(brush, rect);
					graphics2.DrawString(TabPages[num2].Text, Font, new SolidBrush(color_0), rectangle2, stringFormat_0);
				}
				else
				{
					graphics2.DrawString(TabPages[num2].Text, Font, new SolidBrush(color_0), rectangle2, stringFormat_0);
				}
				num2++;
			}
			Graphics graphics4 = graphics2;
			Pen pen = new Pen(color_5, 2f);
			point = new Point(0, 19);
			Point pt = point;
			Point pt2 = new Point(Width, 19);
			graphics4.DrawLine(pen, pt, pt2);
			Graphics graphics5 = graphics2;
			SolidBrush brush2 = new SolidBrush(color_1);
			rect = new Rectangle(0, 20, Width, Height - 20);
			graphics5.FillRectangle(brush2, rect);
			Graphics graphics6 = graphics2;
			Pen pen2 = new Pen(color_4, 2f);
			rect = new Rectangle(0, 0, Width, Height);
			graphics6.DrawRectangle(pen2, rect);
			graphics2.InterpolationMode = InterpolationMode.HighQualityBicubic;
			graphics2 = null;
		}
	}
}
