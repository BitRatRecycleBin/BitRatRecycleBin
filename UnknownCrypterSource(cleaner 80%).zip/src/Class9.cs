using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

internal class Class9 : ComboBox
{
	private static List<WeakReference> list_0 = new List<WeakReference>();

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	public Class9()
	{
		base.DrawItem += Class9_DrawItem;
		smethod_0(this);
		SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		Font = new Font("Arial", 9f);
	}

	protected override void CreateHandle()
	{
		base.CreateHandle();
		DrawMode = DrawMode.OwnerDrawFixed;
		DropDownStyle = ComboBoxStyle.DropDownList;
		DoubleBuffered = true;
		ItemHeight = 20;
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		base.OnPaint(e);
		Graphics graphics = e.Graphics;
		graphics.SmoothingMode = SmoothingMode.HighQuality;
		graphics.Clear(Parent.BackColor);
		checked
		{
			Rectangle rectangle = new Rectangle(0, 0, Width - 1, Height - 1);
			GraphicsPath path = Class7.smethod_0(rectangle, 4);
			LinearGradientBrush brush = new LinearGradientBrush(rectangle, Color.FromArgb(85, 85, 85), Color.FromArgb(60, 60, 60), 90f);
			graphics.FillPath(brush, path);
			graphics.DrawPath(new Pen(Color.FromArgb(55, 55, 55)), path);
			Point[] array = new Point[3];
			ref Point reference = ref array[0];
			Point point = (reference = new Point(Width - 14, 16));
			ref Point reference2 = ref array[1];
			Point point2 = (reference2 = new Point(Width - 17, 10));
			ref Point reference3 = ref array[2];
			Point point3 = (reference3 = new Point(Width - 11, 10));
			Point[] points = array;
			graphics.FillPolygon(Brushes.DarkGray, points);
			Pen pen = new Pen(Color.FromArgb(55, 55, 55));
			point3 = new Point(Width - 25, 1);
			Point pt = point3;
			point2 = new Point(Width - 25, Height - 2);
			graphics.DrawLine(pen, pt, point2);
			try
			{
				if (Items.Count > 0)
				{
					if (SelectedIndex != -1)
					{
						int num = (int)Math.Round((double)(Height - 1) / 2.0 - (double)(graphics.MeasureString(Conversions.ToString(Items[SelectedIndex]), Font).Height / 2f));
						string s = Conversions.ToString(Items[SelectedIndex]);
						Font font = Font;
						Brush whiteSmoke = Brushes.WhiteSmoke;
						point3 = new Point(6, num);
						graphics.DrawString(s, font, whiteSmoke, point3);
					}
					else
					{
						int num2 = (int)Math.Round((double)(Height - 1) / 2.0 - (double)(graphics.MeasureString(Conversions.ToString(Items[0]), Font).Height / 2f));
						string s2 = Conversions.ToString(Items[0]);
						Font font2 = Font;
						Brush whiteSmoke2 = Brushes.WhiteSmoke;
						point3 = new Point(6, num2);
						graphics.DrawString(s2, font2, whiteSmoke2, point3);
					}
				}
			}
			catch (Exception projectError)
			{
				ProjectData.SetProjectError(projectError);
				ProjectData.ClearProjectError();
			}
		}
	}

	public void Class9_DrawItem(object sender, DrawItemEventArgs e)
	{
		e.DrawBackground();
		Graphics graphics = e.Graphics;
		graphics.SmoothingMode = SmoothingMode.HighQuality;
		Rectangle rectangle = e.Bounds;
		checked
		{
			Rectangle rect = new Rectangle(rectangle.X - 1, e.Bounds.Y - 1, e.Bounds.Width + 1, e.Bounds.Height + 1);
			try
			{
				graphics.FillRectangle(new SolidBrush(Parent.BackColor), e.Bounds);
				Rectangle rectangle2;
				if ((e.State & DrawItemState.Selected) == DrawItemState.Selected)
				{
					LinearGradientBrush brush = new LinearGradientBrush(rect, Color.FromArgb(170, 170, 170), Color.FromArgb(140, 140, 140), 90f);
					graphics.FillRectangle(brush, rect);
					string itemText = GetItemText(RuntimeHelpers.GetObjectValue(base.Items[e.Index]));
					Font font = Font;
					Brush white = Brushes.White;
					int num = e.Bounds.X + 6;
					int num2 = e.Bounds.Y + 3;
					int num3 = e.Bounds.Width;
					rectangle = e.Bounds;
					rectangle2 = new Rectangle(num, num2, num3, rectangle.Height);
					graphics.DrawString(itemText, font, white, rectangle2);
					graphics.DrawRectangle(Pens.Silver, rect);
				}
				else
				{
					LinearGradientBrush brush2 = new LinearGradientBrush(rect, Color.FromArgb(135, 135, 135), Color.FromArgb(110, 110, 110), 90f);
					graphics.FillRectangle(brush2, rect);
					string itemText2 = GetItemText(RuntimeHelpers.GetObjectValue(base.Items[e.Index]));
					Font font2 = Font;
					Brush darkGray = Brushes.DarkGray;
					rectangle2 = e.Bounds;
					rectangle = new Rectangle(rectangle2.X + 6, e.Bounds.Y + 3, e.Bounds.Width, e.Bounds.Height);
					graphics.DrawString(itemText2, font2, darkGray, rectangle);
					graphics.DrawRectangle(Pens.Silver, rect);
				}
			}
			catch (Exception projectError)
			{
				ProjectData.SetProjectError(projectError);
				ProjectData.ClearProjectError();
			}
		}
	}

	protected override void OnSelectedItemChanged(EventArgs e)
	{
		base.OnSelectedItemChanged(e);
		Invalidate();
	}
}
