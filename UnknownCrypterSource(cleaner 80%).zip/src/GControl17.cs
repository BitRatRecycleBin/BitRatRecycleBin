using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

[DefaultEvent("CheckedChanged")]
public class GControl17 : Control
{
	public delegate void GDelegate6(object sender);

	private static List<WeakReference> list_0 = new List<WeakReference>();

	private Rectangle rectangle_0;

	private LinearGradientBrush linearGradientBrush_0;

	private GEnum0 genum0_0;

	private bool bool_0;

	private GDelegate6 gdelegate6_0;

	public bool Boolean_0
	{
		get
		{
			return bool_0;
		}
		set
		{
			bool_0 = value;
			method_0();
			gdelegate6_0?.Invoke(this);
			Invalidate();
		}
	}

	public event GDelegate6 Event_0
	{
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		add
		{
			gdelegate6_0 = (GDelegate6)Delegate.Combine(gdelegate6_0, value);
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		remove
		{
			gdelegate6_0 = (GDelegate6)Delegate.Remove(gdelegate6_0, value);
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	protected override void OnMouseEnter(EventArgs e)
	{
		base.OnMouseEnter(e);
		genum0_0 = GEnum0.Over;
		Invalidate();
	}

	protected override void OnMouseDown(MouseEventArgs e)
	{
		base.OnMouseDown(e);
		genum0_0 = GEnum0.Down;
		Invalidate();
	}

	protected override void OnMouseLeave(EventArgs e)
	{
		base.OnMouseLeave(e);
		genum0_0 = GEnum0.None;
		Invalidate();
	}

	protected override void OnMouseUp(MouseEventArgs e)
	{
		base.OnMouseUp(e);
		genum0_0 = GEnum0.Over;
		Invalidate();
	}

	protected override void OnResize(EventArgs e)
	{
		base.OnResize(e);
		Height = 19;
	}

	protected override void OnTextChanged(EventArgs e)
	{
		base.OnTextChanged(e);
		Width = checked((int)Math.Round(CreateGraphics().MeasureString(Text, Font).Width + 6f + (float)Height));
		Invalidate();
	}

	protected override void OnClick(EventArgs e)
	{
		if (!bool_0)
		{
			Boolean_0 = true;
		}
		base.OnClick(e);
	}

	protected override void OnCreateControl()
	{
		base.OnCreateControl();
		method_0();
	}

	private void method_0()
	{
		try
		{
			if (!IsHandleCreated || !Boolean_0)
			{
				return;
			}
			IEnumerator enumerator = default(IEnumerator);
			try
			{
				enumerator = Parent.Controls.GetEnumerator();
				while (enumerator.MoveNext())
				{
					Control control = (Control)enumerator.Current;
					if (control != this && control is GControl17)
					{
						((GControl17)control).Boolean_0 = false;
					}
				}
			}
			finally
			{
				if (enumerator is IDisposable)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			ProjectData.ClearProjectError();
		}
	}

	public GControl17()
	{
		smethod_0(this);
		genum0_0 = GEnum0.None;
		SetStyle(ControlStyles.UserPaint | ControlStyles.SupportsTransparentBackColor, value: true);
		BackColor = Color.Transparent;
		ForeColor = Color.White;
		DoubleBuffered = true;
		Size size2 = (Size = new Size(177, 17));
		Font = new Font("Arial", 8.25f, FontStyle.Bold);
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Bitmap bitmap = new Bitmap(Width, Height);
		Graphics graphics = Graphics.FromImage(bitmap);
		checked
		{
			Rectangle rectangle = new Rectangle(0, 0, Height - 1, Height - 1);
			graphics.SmoothingMode = SmoothingMode.HighQuality;
			graphics.TextRenderingHint = TextRenderingHint.AntiAlias;
			graphics.Clear(BackColor);
			graphics.Clear(Color.Transparent);
			SolidBrush brush = new SolidBrush(Color.FromArgb(49, 50, 54));
			Rectangle rect = new Rectangle(0, 0, Height - 1, Height - 1);
			graphics.FillEllipse(brush, rect);
			Color[] array = new Color[6]
			{
				Color.FromArgb(43, 44, 48),
				Color.FromArgb(44, 45, 49),
				Color.FromArgb(45, 46, 50),
				Color.FromArgb(46, 47, 51),
				Color.FromArgb(47, 48, 52),
				Color.FromArgb(48, 49, 53)
			};
			int num = 0;
			do
			{
				Pen pen = new Pen(array[num]);
				rect = new Rectangle(num + 1, num + 1, Height - (2 * num + 3), Height - (2 * num + 3));
				graphics.DrawEllipse(pen, rect);
				num++;
			}
			while (num <= 5);
			rect = new Rectangle(0, 0, Height - 1, Height - 1);
			LinearGradientBrush brush2 = new LinearGradientBrush(rect, Color.Transparent, Color.FromArgb(87, 88, 92), 90f);
			Pen pen2 = new Pen(brush2);
			rect = new Rectangle(0, 0, Height - 2, Height - 1);
			graphics.DrawEllipse(pen2, rect);
			Pen pen3 = new Pen(Color.FromArgb(32, 33, 37));
			rect = new Rectangle(0, 0, Height - 2, Height - 2);
			graphics.DrawEllipse(pen3, rect);
			if (Boolean_0)
			{
				SolidBrush brush3 = new SolidBrush(Color.White);
				rect = new Rectangle(5, 5, Height - 12, Height - 12);
				graphics.FillEllipse(brush3, rect);
			}
			string s = Text;
			Font font = Font;
			SolidBrush brush4 = new SolidBrush(ForeColor);
			Point point = new Point(21, 3);
			graphics.DrawString(s, font, brush4, point, new StringFormat
			{
				Alignment = StringAlignment.Near,
				LineAlignment = StringAlignment.Near
			});
			NewLateBinding.LateCall(e.Graphics, null, "DrawImage", new object[3]
			{
				RuntimeHelpers.GetObjectValue(bitmap.Clone()),
				0,
				0
			}, null, null, null, IgnoreReturn: true);
			graphics.Dispose();
			bitmap.Dispose();
		}
	}
}
