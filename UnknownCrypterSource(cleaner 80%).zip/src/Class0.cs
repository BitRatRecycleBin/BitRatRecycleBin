using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using Microsoft.VisualBasic.Devices;

[EditorBrowsable(EditorBrowsableState.Never)]
[GeneratedCode("MyTemplate", "10.0.0.0")]
internal class Class0 : Computer
{
	[EditorBrowsable(EditorBrowsableState.Never)]
	[DebuggerHidden]
	public Class0()
	{
	}
}
