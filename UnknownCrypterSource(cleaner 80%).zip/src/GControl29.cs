using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

public class GControl29 : Control
{
	public enum GEnum13
	{
		Rounded,
		NotRounded
	}

	private static List<WeakReference> list_0 = new List<WeakReference>();

	private Enum3 enum3_0;

	[AccessedThroughProperty("TB")]
	private TextBox textBox_0;

	private Color color_0;

	private Color color_1;

	private Color color_2;

	private GEnum13 genum13_0;

	private HorizontalAlignment horizontalAlignment_0;

	private int int_0;

	private bool bool_0;

	private bool bool_1;

	private bool bool_2;

	private virtual TextBox TextBox_0
	{
		[DebuggerNonUserCode]
		get
		{
			return textBox_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			textBox_0 = value;
		}
	}

	[Category("Options")]
	public HorizontalAlignment HorizontalAlignment_0
	{
		get
		{
			return horizontalAlignment_0;
		}
		set
		{
			horizontalAlignment_0 = value;
			if (TextBox_0 != null)
			{
				TextBox_0.TextAlign = value;
			}
		}
	}

	[Category("Options")]
	public int Int32_0
	{
		get
		{
			return int_0;
		}
		set
		{
			int_0 = value;
			if (TextBox_0 != null)
			{
				TextBox_0.MaxLength = value;
			}
		}
	}

	[Category("Options")]
	public bool Boolean_0
	{
		get
		{
			return bool_0;
		}
		set
		{
			bool_0 = value;
			if (TextBox_0 != null)
			{
				TextBox_0.ReadOnly = value;
			}
		}
	}

	[Category("Options")]
	public bool Boolean_1
	{
		get
		{
			return bool_1;
		}
		set
		{
			bool_1 = value;
			if (TextBox_0 != null)
			{
				TextBox_0.UseSystemPasswordChar = value;
			}
		}
	}

	[Category("Options")]
	public bool Boolean_2
	{
		get
		{
			return bool_2;
		}
		set
		{
			bool_2 = value;
			checked
			{
				if (TextBox_0 != null)
				{
					TextBox_0.Multiline = value;
					if (value)
					{
						TextBox_0.Height = Height - 7;
					}
					else
					{
						Height = TextBox_0.Height + 7;
					}
				}
			}
		}
	}

	[Category("Options")]
	public override string Text
	{
		get
		{
			return base.Text;
		}
		set
		{
			base.Text = value;
			if (TextBox_0 != null)
			{
				TextBox_0.Text = value;
			}
		}
	}

	[Category("Options")]
	public override Font Font
	{
		get
		{
			return base.Font;
		}
		set
		{
			base.Font = value;
			checked
			{
				if (TextBox_0 != null)
				{
					TextBox_0.Font = value;
					Point point2 = (TextBox_0.Location = new Point(3, 5));
					TextBox_0.Width = Width - 6;
					if (!bool_2)
					{
						Height = TextBox_0.Height + 7;
					}
				}
			}
		}
	}

	public GEnum13 GEnum13_0
	{
		get
		{
			return genum13_0;
		}
		set
		{
			genum13_0 = value;
			Invalidate();
		}
	}

	[Category("Colours")]
	public Color Color_0
	{
		get
		{
			return color_0;
		}
		set
		{
			color_0 = value;
		}
	}

	[Category("Colours")]
	public Color Color_1
	{
		get
		{
			return color_1;
		}
		set
		{
			color_1 = value;
		}
	}

	[Category("Colours")]
	public Color Color_2
	{
		get
		{
			return color_2;
		}
		set
		{
			color_2 = value;
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	protected override void OnCreateControl()
	{
		base.OnCreateControl();
		if (!Controls.Contains(TextBox_0))
		{
			Controls.Add(TextBox_0);
		}
	}

	private void method_0(object sender, EventArgs e)
	{
		Text = TextBox_0.Text;
	}

	private void method_1(object sender, KeyEventArgs e)
	{
		if (e.Control && e.KeyCode == Keys.A)
		{
			TextBox_0.SelectAll();
			e.SuppressKeyPress = true;
		}
		if (e.Control && e.KeyCode == Keys.C)
		{
			TextBox_0.Copy();
			e.SuppressKeyPress = true;
		}
	}

	protected override void OnResize(EventArgs e)
	{
		Point point2 = (TextBox_0.Location = new Point(5, 5));
		checked
		{
			TextBox_0.Width = Width - 10;
			if (bool_2)
			{
				TextBox_0.Height = Height - 7;
			}
			else
			{
				Height = TextBox_0.Height + 7;
			}
			base.OnResize(e);
		}
	}

	public void method_2()
	{
		TextBox_0.Focus();
		TextBox_0.SelectAll();
	}

	protected override void OnMouseDown(MouseEventArgs e)
	{
		base.OnMouseDown(e);
		enum3_0 = Enum3.Down;
		Invalidate();
	}

	protected override void OnMouseUp(MouseEventArgs e)
	{
		base.OnMouseUp(e);
		enum3_0 = Enum3.Over;
		TextBox_0.Focus();
		Invalidate();
	}

	protected override void OnMouseLeave(EventArgs e)
	{
		base.OnMouseLeave(e);
		enum3_0 = Enum3.None;
		Invalidate();
	}

	public GControl29()
	{
		smethod_0(this);
		enum3_0 = Enum3.None;
		color_0 = Color.FromArgb(51, 51, 55);
		color_1 = Color.FromArgb(153, 153, 153);
		color_2 = Color.FromArgb(35, 35, 35);
		genum13_0 = GEnum13.NotRounded;
		horizontalAlignment_0 = HorizontalAlignment.Left;
		int_0 = 32767;
		SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		DoubleBuffered = true;
		BackColor = Color.Transparent;
		TextBox_0 = new TextBox();
		TextBox_0.Height = 20;
		TextBox_0.Font = new Font("Segoe UI", 10f);
		TextBox_0.Text = Text;
		TextBox_0.BackColor = color_0;
		TextBox_0.ForeColor = color_1;
		TextBox_0.MaxLength = int_0;
		TextBox_0.Multiline = false;
		TextBox_0.ReadOnly = bool_0;
		TextBox_0.UseSystemPasswordChar = bool_1;
		TextBox_0.BorderStyle = BorderStyle.None;
		Point point2 = (TextBox_0.Location = new Point(5, 5));
		TextBox_0.Width = checked(Width - 35);
		TextBox_0.TextChanged += method_0;
		TextBox_0.KeyDown += method_1;
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Graphics graphics = e.Graphics;
		Rectangle rectangle_ = new Rectangle(0, 0, Width, Height);
		Graphics graphics2 = graphics;
		graphics2.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
		graphics2.SmoothingMode = SmoothingMode.HighQuality;
		graphics2.PixelOffsetMode = PixelOffsetMode.HighQuality;
		graphics2.Clear(BackColor);
		TextBox_0.BackColor = color_0;
		TextBox_0.ForeColor = color_1;
		switch (genum13_0)
		{
		case GEnum13.Rounded:
		{
			GraphicsPath graphicsPath = Class20.smethod_0(rectangle_, 6);
			graphics2.FillPath(new SolidBrush(Color.FromArgb(42, 42, 42)), graphicsPath);
			graphics2.DrawPath(new Pen(new SolidBrush(Color.FromArgb(35, 35, 35)), 2f), graphicsPath);
			graphicsPath.Dispose();
			break;
		}
		case GEnum13.NotRounded:
		{
			Graphics graphics3 = graphics2;
			SolidBrush brush = new SolidBrush(color_0);
			Rectangle rect = checked(new Rectangle(0, 0, Width - 1, Height - 1));
			graphics3.FillRectangle(brush, rect);
			Graphics graphics4 = graphics2;
			Pen pen = new Pen(Color.FromArgb(63, 63, 70), 2f);
			rect = new Rectangle(0, 0, Width, Height);
			graphics4.DrawRectangle(pen, rect);
			break;
		}
		}
		graphics2.InterpolationMode = InterpolationMode.HighQualityBicubic;
		graphics2 = null;
	}
}
