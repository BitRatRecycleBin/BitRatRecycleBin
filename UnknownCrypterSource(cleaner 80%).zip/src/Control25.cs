using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

[DefaultEvent("TextChanged")]
internal class Control25 : Control
{
	private static List<WeakReference> list_0 = new List<WeakReference>();

	private TextBox textBox_0;

	private Enum1 enum1_0;

	private HorizontalAlignment horizontalAlignment_0;

	private int int_0;

	private bool bool_0;

	private bool bool_1;

	private bool bool_2;

	public HorizontalAlignment HorizontalAlignment_0
	{
		get
		{
			return horizontalAlignment_0;
		}
		set
		{
			horizontalAlignment_0 = value;
			if (textBox_0 != null)
			{
				textBox_0.TextAlign = value;
			}
		}
	}

	public int Int32_0
	{
		get
		{
			return int_0;
		}
		set
		{
			int_0 = value;
			if (textBox_0 != null)
			{
				textBox_0.MaxLength = value;
			}
		}
	}

	public bool Boolean_0
	{
		get
		{
			return bool_0;
		}
		set
		{
			bool_0 = value;
			if (textBox_0 != null)
			{
				textBox_0.ReadOnly = value;
			}
		}
	}

	public bool Boolean_1
	{
		get
		{
			return bool_1;
		}
		set
		{
			bool_1 = value;
			if (textBox_0 != null)
			{
				textBox_0.UseSystemPasswordChar = value;
			}
		}
	}

	public bool Boolean_2
	{
		get
		{
			return bool_2;
		}
		set
		{
			bool_2 = value;
			checked
			{
				if (textBox_0 != null)
				{
					textBox_0.Multiline = value;
					if (value)
					{
						textBox_0.Height = Height - 11;
					}
					else
					{
						Height = textBox_0.Height + 11;
					}
				}
			}
		}
	}

	public override string Text
	{
		get
		{
			return base.Text;
		}
		set
		{
			base.Text = value;
			if (textBox_0 != null)
			{
				textBox_0.Text = value;
			}
		}
	}

	public override Font Font
	{
		get
		{
			return base.Font;
		}
		set
		{
			base.Font = value;
			checked
			{
				if (textBox_0 != null)
				{
					textBox_0.Font = value;
					Point point2 = (textBox_0.Location = new Point(3, 5));
					textBox_0.Width = Width - 6;
					if (!bool_2)
					{
						Height = textBox_0.Height + 11;
					}
				}
			}
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	protected override void OnMouseEnter(EventArgs e)
	{
		base.OnMouseEnter(e);
		enum1_0 = Enum1.Over;
		Invalidate();
	}

	protected override void OnMouseDown(MouseEventArgs e)
	{
		base.OnMouseDown(e);
		enum1_0 = Enum1.Down;
		Invalidate();
	}

	protected override void OnMouseLeave(EventArgs e)
	{
		base.OnMouseLeave(e);
		enum1_0 = Enum1.None;
		Invalidate();
	}

	protected override void OnMouseUp(MouseEventArgs e)
	{
		base.OnMouseUp(e);
		enum1_0 = Enum1.Over;
		textBox_0.Focus();
		Invalidate();
	}

	protected override void OnEnter(EventArgs e)
	{
		base.OnEnter(e);
		textBox_0.Focus();
		Invalidate();
	}

	protected override void OnLeave(EventArgs e)
	{
		base.OnLeave(e);
		Invalidate();
	}

	protected override void OnMouseMove(MouseEventArgs e)
	{
		base.OnMouseMove(e);
		Invalidate();
	}

	protected override void OnCreateControl()
	{
		base.OnCreateControl();
		if (!Controls.Contains(textBox_0))
		{
			Controls.Add(textBox_0);
		}
	}

	private void textBox_0_TextChanged(object sender, EventArgs e)
	{
		Text = textBox_0.Text;
	}

	private void textBox_0_KeyDown(object sender, KeyEventArgs e)
	{
		if (e.Control && e.KeyCode == Keys.A)
		{
			textBox_0.SelectAll();
			e.SuppressKeyPress = true;
		}
		if (e.Control && e.KeyCode == Keys.C)
		{
			textBox_0.Copy();
			e.SuppressKeyPress = true;
		}
	}

	protected override void OnResize(EventArgs e)
	{
		Point point2 = (textBox_0.Location = new Point(5, 5));
		checked
		{
			textBox_0.Width = Width - 10;
			if (bool_2)
			{
				textBox_0.Height = Height - 11;
			}
			else
			{
				Height = textBox_0.Height + 11;
			}
			base.OnResize(e);
		}
	}

	public Control25()
	{
		smethod_0(this);
		enum1_0 = Enum1.None;
		horizontalAlignment_0 = HorizontalAlignment.Left;
		int_0 = 32767;
		SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.Selectable | ControlStyles.SupportsTransparentBackColor | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		DoubleBuffered = true;
		textBox_0 = new TextBox();
		textBox_0.Font = new Font("Tahoma", 8f);
		textBox_0.BackColor = Color.White;
		textBox_0.ForeColor = Color.FromArgb(1, 75, 124);
		textBox_0.MaxLength = int_0;
		textBox_0.Multiline = bool_2;
		textBox_0.ReadOnly = bool_0;
		textBox_0.UseSystemPasswordChar = bool_1;
		textBox_0.BorderStyle = BorderStyle.None;
		Point point2 = (textBox_0.Location = new Point(5, 5));
		checked
		{
			textBox_0.Width = Width - 10;
			textBox_0.Cursor = Cursors.IBeam;
			if (bool_2)
			{
				textBox_0.Height = Height - 11;
			}
			else
			{
				Height = textBox_0.Height + 11;
			}
			textBox_0.TextChanged += textBox_0_TextChanged;
			textBox_0.KeyDown += textBox_0_KeyDown;
		}
	}

	public Rectangle method_0()
	{
		Rectangle rectangle = default(Rectangle);
		return checked(new Rectangle(2, 2, Width - 5, Height - 5));
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Bitmap bitmap = new Bitmap(Width, Height);
		Graphics graphics = Graphics.FromImage(bitmap);
		GraphicsPath path = method_1(method_0(), 2);
		Graphics graphics2 = graphics;
		graphics2.SmoothingMode = SmoothingMode.HighQuality;
		graphics2.TextRenderingHint = TextRenderingHint.SingleBitPerPixelGridFit;
		graphics2.Clear(Color.White);
		PathGradientBrush pathGradientBrush = new PathGradientBrush(path);
		pathGradientBrush.CenterColor = Color.White;
		pathGradientBrush.SurroundColors = new Color[1] { Color.FromArgb(234, 234, 234) };
		PointF pointF2 = (pathGradientBrush.FocusScales = new PointF(0.9f, 0.5f));
		graphics2.FillPath(pathGradientBrush, path);
		graphics2.DrawPath(new Pen(Color.FromArgb(125, 125, 125)), path);
		base.OnPaint(e);
		graphics.Dispose();
		e.Graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
		e.Graphics.DrawImageUnscaled(bitmap, 0, 0);
		bitmap.Dispose();
		graphics2 = null;
	}

	public GraphicsPath method_1(Rectangle rectangle_0, int int_1)
	{
		GraphicsPath graphicsPath = new GraphicsPath();
		checked
		{
			int num = int_1 * 2;
			Rectangle rect = new Rectangle(rectangle_0.X, rectangle_0.Y, num, num);
			graphicsPath.AddArc(rect, -180f, 90f);
			rect = new Rectangle(rectangle_0.Width - num + rectangle_0.X, rectangle_0.Y, num, num);
			graphicsPath.AddArc(rect, -90f, 90f);
			rect = new Rectangle(rectangle_0.Width - num + rectangle_0.X, rectangle_0.Height - num + rectangle_0.Y, num, num);
			graphicsPath.AddArc(rect, 0f, 90f);
			rect = new Rectangle(rectangle_0.X, rectangle_0.Height - num + rectangle_0.Y, num, num);
			graphicsPath.AddArc(rect, 90f, 90f);
			Point pt = new Point(rectangle_0.X, rectangle_0.Height - num + rectangle_0.Y);
			Point pt2 = new Point(rectangle_0.X, int_1 + rectangle_0.Y);
			graphicsPath.AddLine(pt, pt2);
			return graphicsPath;
		}
	}
}
