using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

public class GControl1 : Control
{
	private static List<WeakReference> list_0 = new List<WeakReference>();

	private Enum2 enum2_0;

	private StringAlignment stringAlignment_0;

	public StringAlignment StringAlignment_0
	{
		get
		{
			return stringAlignment_0;
		}
		set
		{
			stringAlignment_0 = value;
			Invalidate();
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	protected override void OnMouseEnter(EventArgs e)
	{
		base.OnMouseEnter(e);
		enum2_0 = Enum2.Over;
		Invalidate();
	}

	protected override void OnMouseDown(MouseEventArgs e)
	{
		base.OnMouseDown(e);
		enum2_0 = Enum2.Down;
		Invalidate();
	}

	protected override void OnMouseLeave(EventArgs e)
	{
		base.OnMouseLeave(e);
		enum2_0 = Enum2.None;
		Invalidate();
	}

	protected override void OnMouseUp(MouseEventArgs e)
	{
		base.OnMouseUp(e);
		enum2_0 = Enum2.Over;
		Invalidate();
	}

	protected override void OnPaintBackground(PaintEventArgs pevent)
	{
	}

	protected override void OnTextChanged(EventArgs e)
	{
		base.OnTextChanged(e);
		Invalidate();
	}

	public GControl1()
	{
		smethod_0(this);
		enum2_0 = Enum2.None;
		stringAlignment_0 = StringAlignment.Center;
		BackColor = Color.FromArgb(38, 38, 38);
		Font = new Font("Trebuchet MS", 8.25f, FontStyle.Bold);
		ForeColor = Color.White;
		DoubleBuffered = true;
		Size size2 = (Size = new Size(75, 23));
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Bitmap bitmap = new Bitmap(Width, Height);
		Graphics graphics = Graphics.FromImage(bitmap);
		checked
		{
			Rectangle rect = new Rectangle(0, 0, Width - 1, Height - 1);
			Class18 @class = new Class18();
			graphics.SmoothingMode = SmoothingMode.HighQuality;
			graphics.Clear(Color.FromArgb(42, 47, 49));
			Rectangle rectangle_;
			switch (enum2_0)
			{
			case Enum2.None:
			{
				SolidBrush brush8 = new SolidBrush(Color.FromArgb(32, 36, 38));
				rectangle_ = new Rectangle(0, 0, Width - 1, Height - 2);
				graphics.FillPath(brush8, @class.method_0(rectangle_, 3));
				rectangle_ = new Rectangle(1, 1, Width - 5, (int)Math.Round((double)Height / 2.0 - 3.0));
				LinearGradientBrush brush9 = new LinearGradientBrush(rectangle_, Color.FromArgb(70, Color.White), Color.Transparent, 90f);
				rectangle_ = new Rectangle(0, 0, Width - 1, (int)Math.Round((double)Height / 2.0 - 3.0));
				graphics.FillPath(brush9, @class.method_0(rectangle_, 3));
				LinearGradientBrush brush10 = new LinearGradientBrush(rect, Color.FromArgb(36, 31, 43), Color.FromArgb(61, 65, 68), 90f);
				Pen pen8 = new Pen(Color.FromArgb(99, 103, 105));
				rectangle_ = new Rectangle(0, 1, Width - 1, Height - 3);
				graphics.DrawPath(pen8, @class.method_0(rectangle_, 3));
				Pen pen9 = new Pen(brush10);
				rectangle_ = new Rectangle(0, 0, Width - 1, Height - 2);
				graphics.DrawPath(pen9, @class.method_0(rectangle_, 3));
				Pen pen10 = new Pen(Color.FromArgb(27, 31, 33));
				rectangle_ = new Rectangle(1, 0, Width - 3, Height - 3);
				graphics.DrawPath(pen10, @class.method_0(rectangle_, 3));
				break;
			}
			case Enum2.Over:
			{
				SolidBrush brush5 = new SolidBrush(Color.FromArgb(32, 36, 38));
				rectangle_ = new Rectangle(0, 0, Width - 1, Height - 2);
				graphics.FillPath(brush5, @class.method_0(rectangle_, 3));
				rectangle_ = new Rectangle(1, 1, Width - 5, (int)Math.Round((double)Height / 2.0 - 3.0));
				LinearGradientBrush brush6 = new LinearGradientBrush(rectangle_, Color.FromArgb(70, Color.White), Color.Transparent, 90f);
				rectangle_ = new Rectangle(0, 0, Width - 1, (int)Math.Round((double)Height / 2.0 - 3.0));
				graphics.FillPath(brush6, @class.method_0(rectangle_, 3));
				LinearGradientBrush brush7 = new LinearGradientBrush(rect, Color.FromArgb(36, 31, 43), Color.FromArgb(61, 65, 68), 90f);
				Pen pen3 = new Pen(Color.FromArgb(99, 103, 105));
				rectangle_ = new Rectangle(0, 1, Width - 1, Height - 3);
				graphics.DrawPath(pen3, @class.method_0(rectangle_, 3));
				Pen pen4 = new Pen(Color.FromArgb(100, 99, 103, 105));
				rectangle_ = new Rectangle(2, 2, Width - 5, Height - 6);
				graphics.DrawPath(pen4, @class.method_0(rectangle_, 3));
				Pen pen5 = new Pen(brush7);
				rectangle_ = new Rectangle(0, 0, Width - 1, Height - 2);
				graphics.DrawPath(pen5, @class.method_0(rectangle_, 3));
				Pen pen6 = new Pen(Color.FromArgb(27, 31, 33));
				rectangle_ = new Rectangle(1, 0, Width - 3, Height - 3);
				graphics.DrawPath(pen6, @class.method_0(rectangle_, 3));
				Pen pen7 = new Pen(Color.FromArgb(0, 186, 255));
				rectangle_ = new Rectangle(1, 1, Width - 3, Height - 4);
				graphics.DrawPath(pen7, @class.method_0(rectangle_, 3));
				break;
			}
			case Enum2.Down:
			{
				SolidBrush brush = new SolidBrush(Color.FromArgb(32, 36, 38));
				rectangle_ = new Rectangle(0, 0, Width - 1, Height - 2);
				graphics.FillPath(brush, @class.method_0(rectangle_, 3));
				rectangle_ = new Rectangle(0, 0, Width - 1, (int)Math.Round((double)Height / 2.0 - 1.0));
				LinearGradientBrush brush2 = new LinearGradientBrush(rectangle_, Color.FromArgb(32, 36, 38), Color.FromArgb(57, 57, 57), 90f);
				rectangle_ = new Rectangle(0, 0, Width - 1, (int)Math.Round((double)Height / 2.0 + 1.0));
				graphics.FillPath(brush2, @class.method_0(rectangle_, 3));
				rectangle_ = new Rectangle(0, 0, Width - 1, (int)Math.Round((double)Height / 2.0 - 1.0));
				LinearGradientBrush brush3 = new LinearGradientBrush(rectangle_, Color.FromArgb(57, 57, 57), Color.FromArgb(32, 36, 38), 90f);
				rectangle_ = new Rectangle(0, (int)Math.Round((double)Height / 2.0 - 1.0), Width - 1, (int)Math.Round((double)Height / 2.0 + 2.0));
				graphics.FillPath(brush3, @class.method_0(rectangle_, 3));
				graphics.DrawLine(new Pen(Color.FromArgb(57, 57, 57)), 0, Convert.ToInt32((double)Height / 2.0 - 1.0), Width - 1, Convert.ToInt32((double)Height / 2.0 - 1.0));
				LinearGradientBrush brush4 = new LinearGradientBrush(rect, Color.FromArgb(36, 31, 43), Color.FromArgb(61, 65, 68), 90f);
				Pen pen = new Pen(brush4);
				rectangle_ = new Rectangle(0, 0, Width - 1, Height - 2);
				graphics.DrawPath(pen, @class.method_0(rectangle_, 3));
				Pen pen2 = new Pen(Color.FromArgb(27, 31, 33));
				rectangle_ = new Rectangle(1, 0, Width - 3, Height - 3);
				graphics.DrawPath(pen2, @class.method_0(rectangle_, 3));
				break;
			}
			}
			string s = Text;
			Font font = Font;
			SolidBrush brush11 = new SolidBrush(ForeColor);
			rectangle_ = new Rectangle(-1, -1, Width - 1, Height - 1);
			graphics.DrawString(s, font, brush11, rectangle_, new StringFormat
			{
				LineAlignment = StringAlignment.Center,
				Alignment = StringAlignment.Center
			});
			NewLateBinding.LateCall(e.Graphics, null, "DrawImage", new object[3]
			{
				RuntimeHelpers.GetObjectValue(bitmap.Clone()),
				0,
				0
			}, null, null, null, IgnoreReturn: true);
			graphics.Dispose();
			bitmap.Dispose();
		}
	}
}
