using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

internal class Control0 : ContainerControl
{
	private static List<WeakReference> list_0 = new List<WeakReference>();

	private int int_0;

	private bool bool_0;

	private int int_1;

	private int int_2;

	private bool bool_1;

	private bool bool_2;

	private Icon icon_0;

	private bool bool_3;

	public override string Text
	{
		get
		{
			return base.Text;
		}
		set
		{
			base.Text = value;
			Invalidate();
		}
	}

	public Icon Icon_0
	{
		get
		{
			return icon_0;
		}
		set
		{
			icon_0 = value;
			Invalidate();
		}
	}

	public bool Boolean_0
	{
		get
		{
			return bool_3;
		}
		set
		{
			bool_3 = value;
			Invalidate();
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	public Control0()
	{
		smethod_0(this);
		int_0 = 39;
		bool_0 = false;
		SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		Dock = DockStyle.Fill;
		Font = new Font("Segoe UI", 9f);
		BackColor = Color.FromArgb(90, 90, 90);
		Boolean_0 = true;
	}

	protected override void CreateHandle()
	{
		base.CreateHandle();
		Color color = default(Color);
		if (FindForm().TransparencyKey == color)
		{
			FindForm().TransparencyKey = Color.Fuchsia;
		}
		FindForm().FormBorderStyle = FormBorderStyle.None;
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		base.OnPaint(e);
		Graphics graphics = e.Graphics;
		graphics.SmoothingMode = SmoothingMode.HighQuality;
		graphics.Clear(FindForm().TransparencyKey);
		checked
		{
			Rectangle rectangle_ = new Rectangle(0, 0, Width - 1, Height - 1);
			int num = 8;
			GraphicsPath path = Class7.smethod_1(rectangle_, 8);
			graphics.FillPath(new SolidBrush(Color.FromArgb(60, 60, 60)), path);
			Rectangle rectangle_2 = new Rectangle(0, 0, Width - 1, (int)Math.Round((double)int_0 / 1.75));
			GraphicsPath path2 = Class7.smethod_1(rectangle_2, 8);
			Rectangle rect = new Rectangle(rectangle_2.X, rectangle_2.Y, rectangle_2.Width, rectangle_2.Height + 2);
			LinearGradientBrush brush = new LinearGradientBrush(rect, Color.FromArgb(100, 100, 100), Color.FromArgb(60, 60, 60), 90f);
			graphics.FillPath(brush, path2);
			Rectangle rect2 = new Rectangle(6, int_0, Width - 13, Height - int_0 - 8);
			graphics.FillRectangle(new SolidBrush(BackColor), rect2);
			graphics.DrawRectangle(Pens.Black, rect2);
			int num2 = (int)Math.Round((double)int_0 / 2.0 - (double)(graphics.MeasureString(Text, Font).Height / 2f) + 1.0);
			Point point_;
			if (bool_3 & (icon_0 != null))
			{
				Icon icon = icon_0;
				rect = new Rectangle(8, 6, int_0 - 11, int_0 - 11);
				graphics.DrawIcon(icon, rect);
				string string_ = Text;
				Font font = Font;
				Brush white = Brushes.White;
				point_ = new Point(8 + int_0 - 11 + 4, num2);
				Class7.smethod_4(graphics, string_, font, white, point_);
			}
			else
			{
				string string_2 = Text;
				Font font2 = Font;
				Brush white2 = Brushes.White;
				point_ = new Point(8, num2);
				Class7.smethod_4(graphics, string_2, font2, white2, point_);
			}
			Rectangle rectangle = new Rectangle(Width - 29, 8, 22, 22);
			GraphicsPath path3 = Class7.smethod_0(rectangle, 3);
			LinearGradientBrush brush2 = new LinearGradientBrush(rectangle, Color.FromArgb(105, 105, 105), Color.FromArgb(75, 75, 75), 90f);
			graphics.FillPath(brush2, path3);
			if (bool_1)
			{
				graphics.FillPath(new SolidBrush(Color.FromArgb(15, Color.White)), path3);
			}
			graphics.DrawPath(new Pen(Color.FromArgb(40, 40, 40)), path3);
			Font font3 = new Font("Marlett", 10f);
			Brush lightGray = Brushes.LightGray;
			point_ = new Point(Width - 26, 13);
			graphics.DrawString("r", font3, lightGray, point_);
			Rectangle rectangle2 = new Rectangle(Width - 55, 8, 22, 22);
			GraphicsPath path4 = Class7.smethod_0(rectangle2, 3);
			LinearGradientBrush brush3 = new LinearGradientBrush(rectangle2, Color.FromArgb(105, 105, 105), Color.FromArgb(75, 75, 75), 90f);
			graphics.FillPath(brush3, path4);
			if (bool_2)
			{
				graphics.FillPath(new SolidBrush(Color.FromArgb(15, Color.White)), path4);
			}
			graphics.DrawPath(new Pen(Color.FromArgb(40, 40, 40)), path4);
			Font font4 = new Font("Marlett", 13f);
			Brush lightGray2 = Brushes.LightGray;
			point_ = new Point(Width - 53, 10);
			graphics.DrawString("0", font4, lightGray2, point_);
			Pen dimGray = Pens.DimGray;
			rect = new Rectangle(rectangle_.X + 1, rectangle_.Y, rectangle_.Width - 2, rectangle_.Height);
			graphics.DrawPath(dimGray, Class7.smethod_1(rect, num));
			Pen dimGray2 = Pens.DimGray;
			rect = new Rectangle(rectangle_.X, rectangle_.Y + 1, rectangle_.Width, rectangle_.Height - 2);
			graphics.DrawPath(dimGray2, Class7.smethod_1(rect, num));
			graphics.SmoothingMode = SmoothingMode.None;
			graphics.DrawPath(new Pen(Color.FromArgb(40, 40, 40)), path);
		}
	}

	protected override void OnMouseMove(MouseEventArgs e)
	{
		base.OnMouseMove(e);
		if (bool_0)
		{
			Form form = FindForm();
			Point mousePosition = Control.MousePosition;
			Point point = new Point(int_1, int_2);
			form.Location = mousePosition - (Size)point;
		}
		checked
		{
			if (e.Y > 8 && e.Y < 30)
			{
				if (e.X > Width - 29 && e.X < Width - 7)
				{
					bool_1 = true;
				}
				else
				{
					bool_1 = false;
				}
				if (e.X > Width - 55 && e.X < Width - 33)
				{
					bool_2 = true;
				}
				else
				{
					bool_2 = false;
				}
			}
			else
			{
				bool_1 = false;
				bool_2 = false;
			}
			Invalidate();
		}
	}

	protected override void OnMouseDown(MouseEventArgs e)
	{
		base.OnMouseDown(e);
		int_1 = e.X;
		int_2 = e.Y;
		if (e.Y <= int_0 && !bool_1 && !bool_2)
		{
			bool_0 = true;
		}
		if (bool_1)
		{
			FindForm().Close();
		}
		else if (bool_2)
		{
			FindForm().WindowState = FormWindowState.Minimized;
		}
		else
		{
			Focus();
		}
	}

	protected override void OnMouseUp(MouseEventArgs e)
	{
		base.OnMouseUp(e);
		bool_0 = false;
	}
}
