using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

public class GControl12 : Control
{
	private static List<WeakReference> list_0 = new List<WeakReference>();

	private int int_0;

	private int int_1;

	public int Int32_0
	{
		get
		{
			return int_0;
		}
		set
		{
			if (value > int_1)
			{
				int_0 = int_1;
			}
			else if (value < 0)
			{
				int_0 = 0;
			}
			else
			{
				int_0 = value;
			}
			Invalidate();
		}
	}

	public int Int32_1
	{
		get
		{
			return int_1;
		}
		set
		{
			if (value < 1)
			{
				int_1 = 1;
			}
			else
			{
				int_1 = value;
			}
			if (value < int_0)
			{
				int_0 = int_1;
			}
			Invalidate();
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	protected override void OnResize(EventArgs e)
	{
		base.OnResize(e);
	}

	public GControl12()
	{
		smethod_0(this);
		int_1 = 100;
		SetStyle(ControlStyles.OptimizedDoubleBuffer, value: true);
		SetStyle(ControlStyles.AllPaintingInWmPaint, value: true);
		SetStyle(ControlStyles.SupportsTransparentBackColor, value: true);
		BackColor = Color.Transparent;
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		int num = 6;
		Bitmap bitmap = new Bitmap(Width, Height);
		Graphics graphics = Graphics.FromImage(bitmap);
		graphics.SmoothingMode = SmoothingMode.HighQuality;
		graphics.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
		checked
		{
			int num2 = (int)Math.Round((double)(Width - 1) * ((double)int_0 / (double)int_1));
			graphics.Clear(Color.Transparent);
			SolidBrush brush = new SolidBrush(Color.FromArgb(49, 50, 54));
			Rectangle rectangle_ = new Rectangle(0, 0, Width - 1, Height - 1);
			graphics.FillPath(brush, Class19.smethod_0(rectangle_, 6));
			Color[] array = new Color[6]
			{
				Color.FromArgb(43, 44, 48),
				Color.FromArgb(44, 45, 49),
				Color.FromArgb(45, 46, 50),
				Color.FromArgb(46, 47, 51),
				Color.FromArgb(47, 48, 52),
				Color.FromArgb(48, 49, 53)
			};
			int num3 = 0;
			do
			{
				Pen pen = new Pen(array[num3]);
				rectangle_ = new Rectangle(num3 + 1, num3 + 1, Width - (2 * num3 + 3), Height - (2 * num3 + 3));
				graphics.DrawPath(pen, Class19.smethod_0(rectangle_, num));
				num3++;
			}
			while (num3 <= 5);
			if (num2 > 4)
			{
				SolidBrush brush2 = new SolidBrush(Color.FromArgb(80, 164, 234));
				rectangle_ = new Rectangle(0, 0, num2, Height - 2);
				graphics.FillPath(brush2, Class19.smethod_0(rectangle_, num));
				HatchBrush brush3 = new HatchBrush(HatchStyle.DarkUpwardDiagonal, Color.FromArgb(100, 26, 127, 217), Color.Transparent);
				rectangle_ = new Rectangle(0, 0, num2, Height - 2);
				LinearGradientBrush brush4 = new LinearGradientBrush(rectangle_, Color.FromArgb(75, Color.White), Color.FromArgb(65, Color.Black), 90f);
				rectangle_ = new Rectangle(0, 0, num2, Height - 2);
				graphics.FillPath(brush4, Class19.smethod_0(rectangle_, num));
				rectangle_ = new Rectangle(0, 0, num2, Height - 2);
				graphics.FillPath(brush3, Class19.smethod_0(rectangle_, num));
				rectangle_ = new Rectangle(0, 0, num2, Height - 2);
				LinearGradientBrush brush5 = new LinearGradientBrush(rectangle_, Color.FromArgb(183, 223, 249), Color.FromArgb(41, 141, 226), 90f);
				Pen pen2 = new Pen(brush5);
				rectangle_ = new Rectangle(1, 1, num2 - 2, Height - 4);
				graphics.DrawPath(pen2, Class19.smethod_0(rectangle_, num));
				Pen pen3 = new Pen(Color.FromArgb(1, 44, 76));
				rectangle_ = new Rectangle(0, 0, num2, Height - 2);
				graphics.DrawPath(pen3, Class19.smethod_0(rectangle_, num));
			}
			rectangle_ = new Rectangle(0, 0, Width - 1, Height - 1);
			LinearGradientBrush brush6 = new LinearGradientBrush(rectangle_, Color.Transparent, Color.FromArgb(87, 88, 92), 90f);
			Pen pen4 = new Pen(brush6);
			rectangle_ = new Rectangle(0, 0, Width - 1, Height - 1);
			graphics.DrawPath(pen4, Class19.smethod_0(rectangle_, num));
			Pen pen5 = new Pen(Color.FromArgb(32, 33, 37));
			rectangle_ = new Rectangle(0, 0, Width - 1, Height - 2);
			graphics.DrawPath(pen5, Class19.smethod_0(rectangle_, num));
			NewLateBinding.LateCall(e.Graphics, null, "DrawImage", new object[3]
			{
				RuntimeHelpers.GetObjectValue(bitmap.Clone()),
				0,
				0
			}, null, null, null, IgnoreReturn: true);
			graphics.Dispose();
			bitmap.Dispose();
		}
	}
}
