using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

public class GControl20 : ContainerControl
{
	public enum GEnum4
	{
		VSIcon,
		FormIcon
	}

	public enum GEnum5
	{
		WholeApplication,
		Form
	}

	private delegate void Delegate12(MouseEventArgs e);

	private static List<WeakReference> list_0 = new List<WeakReference>();

	private bool bool_0;

	private bool bool_1;

	private bool bool_2;

	private int int_0;

	private bool bool_3;

	private Enum3 enum3_0;

	private int int_1;

	private int int_2;

	private bool bool_4;

	private const int int_3 = 35;

	private Point point_0;

	private Color color_0;

	private Color color_1;

	private Color color_2;

	private Color color_3;

	private Color color_4;

	private Color color_5;

	private Color color_6;

	private Font font_0;

	private GEnum4 genum4_0;

	private GEnum5 genum5_0;

	private Form form_0;

	private Point[] point_1;

	private Point[] point_2;

	private Point[] point_3;

	private Point[] point_4;

	[Category("Control")]
	public GEnum5 GEnum5_0
	{
		get
		{
			return genum5_0;
		}
		set
		{
			genum5_0 = value;
			Invalidate();
		}
	}

	[Category("Control")]
	public Form Form_0
	{
		get
		{
			return form_0;
		}
		set
		{
			if (value != null)
			{
				form_0 = value;
				Invalidate();
			}
		}
	}

	[Category("Control")]
	public GEnum4 GEnum4_0
	{
		get
		{
			return genum4_0;
		}
		set
		{
			genum4_0 = value;
			Invalidate();
		}
	}

	[Category("Control")]
	public int Int32_0
	{
		get
		{
			return int_0;
		}
		set
		{
			int_0 = value;
		}
	}

	[Category("Control")]
	public bool Boolean_0
	{
		get
		{
			return bool_1;
		}
		set
		{
			bool_1 = value;
		}
	}

	[Category("Control")]
	public bool Boolean_1
	{
		get
		{
			return bool_2;
		}
		set
		{
			bool_2 = value;
		}
	}

	[Category("Control")]
	public bool Boolean_2
	{
		get
		{
			return bool_3;
		}
		set
		{
			bool_3 = value;
			Invalidate();
		}
	}

	[Category("Control")]
	public bool Boolean_3
	{
		get
		{
			return bool_0;
		}
		set
		{
			bool_0 = value;
		}
	}

	[Category("Colours")]
	public Color Color_0
	{
		get
		{
			return color_4;
		}
		set
		{
			color_4 = value;
		}
	}

	[Category("Colours")]
	public Color Color_1
	{
		get
		{
			return color_5;
		}
		set
		{
			color_5 = value;
		}
	}

	[Category("Colours")]
	public Color Color_2
	{
		get
		{
			return color_1;
		}
		set
		{
			color_1 = value;
		}
	}

	[Category("Colours")]
	public Color Color_3
	{
		get
		{
			return color_0;
		}
		set
		{
			color_0 = value;
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	protected override void OnMouseUp(MouseEventArgs e)
	{
		base.OnMouseUp(e);
		bool_4 = false;
		enum3_0 = Enum3.Over;
		Invalidate();
	}

	protected override void OnMouseEnter(EventArgs e)
	{
		base.OnMouseEnter(e);
		enum3_0 = Enum3.Over;
		Invalidate();
	}

	protected override void OnMouseLeave(EventArgs e)
	{
		base.OnMouseLeave(e);
		enum3_0 = Enum3.None;
		Invalidate();
	}

	protected override void OnMouseMove(MouseEventArgs e)
	{
		base.OnMouseMove(e);
		int_1 = e.Location.X;
		int_2 = e.Location.Y;
		Invalidate();
		if (bool_4)
		{
			Parent.Location = Control.MousePosition - (Size)point_0;
		}
		if (e.Y > 26)
		{
			Cursor = Cursors.Arrow;
		}
		else
		{
			Cursor = Cursors.Hand;
		}
	}

	protected override void OnMouseDown(MouseEventArgs e)
	{
		base.OnMouseDown(e);
		checked
		{
			if (int_1 > Width - 30 && int_1 < Width && int_2 < 26)
			{
				if (bool_0)
				{
					if (genum5_0 == GEnum5.Form)
					{
						if (form_0 == "(none)")
						{
							Environment.Exit(0);
						}
						else if (form_0.InvokeRequired)
						{
							form_0.Invoke(new Delegate12(OnMouseDown), e);
						}
						else
						{
							form_0.Close();
						}
					}
					else
					{
						Environment.Exit(0);
					}
				}
			}
			else if (int_1 > Width - 60 && int_1 < Width - 30 && int_2 < 26)
			{
				if (bool_2)
				{
					switch (FindForm().WindowState)
					{
					case FormWindowState.Normal:
						FindForm().WindowState = FormWindowState.Maximized;
						break;
					case FormWindowState.Maximized:
						FindForm().WindowState = FormWindowState.Normal;
						break;
					}
				}
			}
			else if (int_1 > Width - 90 && int_1 < Width - 60 && int_2 < 26)
			{
				if (bool_1)
				{
					switch (FindForm().WindowState)
					{
					case FormWindowState.Normal:
						FindForm().WindowState = FormWindowState.Minimized;
						break;
					case FormWindowState.Maximized:
						FindForm().WindowState = FormWindowState.Minimized;
						break;
					}
				}
			}
			else
			{
				bool num = e.Button == MouseButtons.Left;
				Rectangle rectangle = new Rectangle(0, 0, Width - 90, 35);
				Rectangle rectangle2 = rectangle;
				if (num & rectangle2.Contains(e.Location))
				{
					bool_4 = true;
					point_0 = e.Location;
				}
				else
				{
					bool num2 = e.Button == MouseButtons.Left;
					rectangle2 = new Rectangle(Width - 90, 22, 75, 13);
					rectangle = rectangle2;
					if (num2 & rectangle.Contains(e.Location))
					{
						bool_4 = true;
						point_0 = e.Location;
					}
					else
					{
						bool num3 = e.Button == MouseButtons.Left;
						rectangle2 = new Rectangle(Width - 15, 0, 15, 35);
						rectangle = rectangle2;
						if (num3 & rectangle.Contains(e.Location))
						{
							bool_4 = true;
							point_0 = e.Location;
						}
						else
						{
							Focus();
						}
					}
				}
			}
			enum3_0 = Enum3.Down;
			Invalidate();
		}
	}

	public GControl20()
	{
		smethod_0(this);
		bool_0 = true;
		bool_1 = true;
		bool_2 = true;
		int_0 = 12;
		bool_3 = true;
		enum3_0 = Enum3.None;
		bool_4 = false;
		ref Point reference = ref point_0;
		reference = new Point(0, 0);
		color_0 = Color.FromArgb(153, 153, 153);
		color_1 = Color.FromArgb(45, 45, 48);
		color_2 = Color.FromArgb(255, 255, 255);
		color_3 = Color.FromArgb(248, 248, 248);
		color_4 = Color.FromArgb(15, 15, 18);
		color_5 = Color.FromArgb(63, 63, 65);
		color_6 = Color.FromArgb(0, 122, 204);
		font_0 = new Font("Microsoft Sans Serif", 9f);
		genum4_0 = GEnum4.FormIcon;
		genum5_0 = GEnum5.WholeApplication;
		form_0 = Form.ActiveForm;
		Point[] array = new Point[2];
		ref Point reference2 = ref array[0];
		Point point = (reference2 = new Point(9, 11));
		ref Point reference3 = ref array[1];
		Point point2 = (reference3 = new Point(16, 17));
		point_1 = array;
		array = new Point[2];
		ref Point reference4 = ref array[0];
		point2 = (reference4 = new Point(9, 22));
		ref Point reference5 = ref array[1];
		point = (reference5 = new Point(16, 17));
		point_2 = array;
		array = new Point[2];
		ref Point reference6 = ref array[0];
		point2 = (reference6 = new Point(16, 17));
		ref Point reference7 = ref array[1];
		point = (reference7 = new Point(26, 7));
		point_3 = array;
		array = new Point[2];
		ref Point reference8 = ref array[0];
		point2 = (reference8 = new Point(16, 17));
		ref Point reference9 = ref array[1];
		point = (reference9 = new Point(25, 26));
		point_4 = array;
		SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		DoubleBuffered = true;
		BackColor = color_1;
		Dock = DockStyle.Fill;
	}

	protected override void OnCreateControl()
	{
		base.OnCreateControl();
		ParentForm.FormBorderStyle = FormBorderStyle.None;
		ParentForm.AllowTransparency = false;
		ParentForm.TransparencyKey = Color.Fuchsia;
		ParentForm.FindForm().StartPosition = FormStartPosition.CenterParent;
		Dock = DockStyle.Fill;
		Invalidate();
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Graphics graphics = e.Graphics;
		Graphics graphics2 = graphics;
		graphics2.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
		graphics2.SmoothingMode = SmoothingMode.AntiAlias;
		graphics2.PixelOffsetMode = PixelOffsetMode.HighQuality;
		Graphics graphics3 = graphics2;
		SolidBrush brush = new SolidBrush(color_1);
		Rectangle rect = new Rectangle(0, 0, Width, Height);
		graphics3.FillRectangle(brush, rect);
		Graphics graphics4 = graphics2;
		Pen pen = new Pen(color_4);
		rect = new Rectangle(0, 0, Width, Height);
		graphics4.DrawRectangle(pen, rect);
		Enum3 @enum = enum3_0;
		checked
		{
			if (@enum == Enum3.Over)
			{
				if (int_1 > Width - 30 && int_1 < Width && int_2 < 26)
				{
					Graphics graphics5 = graphics2;
					SolidBrush brush2 = new SolidBrush(color_5);
					rect = new Rectangle(Width - 30, 1, 29, 25);
					graphics5.FillRectangle(brush2, rect);
				}
				else if (int_1 > Width - 60 && int_1 < Width - 30 && int_2 < 26)
				{
					Graphics graphics6 = graphics2;
					SolidBrush brush3 = new SolidBrush(color_5);
					rect = new Rectangle(Width - 60, 1, 30, 25);
					graphics6.FillRectangle(brush3, rect);
				}
				else if (int_1 > Width - 90 && int_1 < Width - 60 && int_2 < 26)
				{
					Graphics graphics7 = graphics2;
					SolidBrush brush4 = new SolidBrush(color_5);
					rect = new Rectangle(Width - 90, 1, 30, 25);
					graphics7.FillRectangle(brush4, rect);
				}
			}
			graphics2.DrawLine(new Pen(color_3, 2f), Width - 20, 10, Width - 12, 18);
			graphics2.DrawLine(new Pen(color_3, 2f), Width - 20, 18, Width - 12, 10);
			graphics2.FillRectangle(new SolidBrush(color_3), Width - 79, 17, 8, 2);
			if (FindForm().WindowState == FormWindowState.Normal)
			{
				graphics2.DrawLine(new Pen(color_3), Width - 49, 18, Width - 40, 18);
				graphics2.DrawLine(new Pen(color_3), Width - 49, 18, Width - 49, 10);
				graphics2.DrawLine(new Pen(color_3), Width - 40, 18, Width - 40, 10);
				graphics2.DrawLine(new Pen(color_3), Width - 49, 10, Width - 40, 10);
				graphics2.DrawLine(new Pen(color_3), Width - 49, 11, Width - 40, 11);
			}
			else if (FindForm().WindowState == FormWindowState.Maximized)
			{
				graphics2.DrawLine(new Pen(color_3), Width - 48, 16, Width - 39, 16);
				graphics2.DrawLine(new Pen(color_3), Width - 48, 16, Width - 48, 8);
				graphics2.DrawLine(new Pen(color_3), Width - 39, 16, Width - 39, 8);
				graphics2.DrawLine(new Pen(color_3), Width - 48, 8, Width - 39, 8);
				graphics2.DrawLine(new Pen(color_3), Width - 48, 9, Width - 39, 9);
				Graphics graphics8 = graphics2;
				SolidBrush brush5 = new SolidBrush(color_1);
				rect = new Rectangle(Width - 51, 12, 9, 8);
				graphics8.FillRectangle(brush5, rect);
				graphics2.DrawLine(new Pen(color_3), Width - 51, 20, Width - 42, 20);
				graphics2.DrawLine(new Pen(color_3), Width - 51, 20, Width - 51, 12);
				graphics2.DrawLine(new Pen(color_3), Width - 42, 20, Width - 42, 12);
				graphics2.DrawLine(new Pen(color_3), Width - 51, 12, Width - 42, 12);
				graphics2.DrawLine(new Pen(color_3), Width - 51, 13, Width - 42, 13);
			}
			if (bool_3)
			{
				GEnum4 gEnum = genum4_0;
				if (gEnum == GEnum4.FormIcon)
				{
					Graphics graphics9 = graphics2;
					Icon icon = FindForm().Icon;
					rect = new Rectangle(6, 6, 22, 22);
					graphics9.DrawIcon(icon, rect);
					Graphics graphics10 = graphics2;
					string s = Text;
					Font font = font_0;
					SolidBrush brush6 = new SolidBrush(color_0);
					RectangleF layoutRectangle = new RectangleF(37f, 0f, Width - 110, 32f);
					graphics10.DrawString(s, font, brush6, layoutRectangle, new StringFormat
					{
						LineAlignment = StringAlignment.Center,
						Alignment = StringAlignment.Near
					});
				}
				else
				{
					graphics2.DrawLines(new Pen(color_2, 3f), point_1);
					graphics2.DrawLines(new Pen(color_2, 3f), point_2);
					graphics2.DrawLines(new Pen(color_2, 4f), point_3);
					graphics2.DrawLines(new Pen(color_2, 4f), point_4);
					Graphics graphics11 = graphics2;
					Pen pen2 = new Pen(color_2, 3f);
					Point pt = new Point(9, 11);
					Point pt2 = new Point(9, 22);
					graphics11.DrawLine(pen2, pt, pt2);
					graphics2.DrawLine(new Pen(color_2, 4f), 26, 6, 26, 28);
					Graphics graphics12 = graphics2;
					string s2 = Text;
					Font font2 = font_0;
					SolidBrush brush7 = new SolidBrush(color_0);
					RectangleF layoutRectangle = new RectangleF(37f, 0f, Width - 110, 32f);
					graphics12.DrawString(s2, font2, brush7, layoutRectangle, new StringFormat
					{
						LineAlignment = StringAlignment.Center,
						Alignment = StringAlignment.Near
					});
				}
			}
			else
			{
				Graphics graphics13 = graphics2;
				string s3 = Text;
				Font font3 = font_0;
				SolidBrush brush8 = new SolidBrush(color_0);
				RectangleF layoutRectangle = new RectangleF(5f, 0f, Width - 110, 30f);
				graphics13.DrawString(s3, font3, brush8, layoutRectangle, new StringFormat
				{
					LineAlignment = StringAlignment.Center,
					Alignment = StringAlignment.Near
				});
			}
			graphics2.InterpolationMode = InterpolationMode.HighQualityBicubic;
			graphics2 = null;
		}
	}
}
