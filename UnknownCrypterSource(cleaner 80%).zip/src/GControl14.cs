using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

public class GControl14 : TabControl
{
	public enum GEnum3
	{
		Left,
		Center,
		Right
	}

	private static List<WeakReference> list_0 = new List<WeakReference>();

	private GEnum3 genum3_0;

	public GEnum3 GEnum3_0
	{
		get
		{
			return genum3_0;
		}
		set
		{
			genum3_0 = value;
			Invalidate();
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	public GControl14()
	{
		smethod_0(this);
		genum3_0 = GEnum3.Left;
		SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor | ControlStyles.AllPaintingInWmPaint | ControlStyles.DoubleBuffer, value: true);
		DoubleBuffered = true;
		SizeMode = TabSizeMode.Fixed;
		BackColor = Color.Transparent;
		Size size2 = (ItemSize = new Size(35, 100));
		Font = new Font("Arial", 8.25f, FontStyle.Bold);
	}

	protected override void CreateHandle()
	{
		base.CreateHandle();
		Alignment = TabAlignment.Left;
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Bitmap bitmap = new Bitmap(Width, Height);
		Graphics graphics = Graphics.FromImage(bitmap);
		int int_ = 6;
		graphics.TextRenderingHint = TextRenderingHint.AntiAlias;
		graphics.SmoothingMode = SmoothingMode.HighQuality;
		try
		{
			SelectedTab.BackColor = Color.FromArgb(47, 48, 52);
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			ProjectData.ClearProjectError();
		}
		graphics.Clear(Color.FromArgb(51, 56, 60));
		SolidBrush brush = new SolidBrush(Color.FromArgb(49, 50, 54));
		checked
		{
			int num = ItemSize.Height - 1;
			int num2 = Width;
			Size size = ItemSize;
			Rectangle rectangle = new Rectangle(num, 0, num2 - size.Height - 1 - 1, Height - 1);
			graphics.FillPath(brush, Class19.smethod_0(rectangle, int_));
			Color[] array = new Color[6]
			{
				Color.FromArgb(43, 44, 48),
				Color.FromArgb(44, 45, 49),
				Color.FromArgb(45, 46, 50),
				Color.FromArgb(46, 47, 51),
				Color.FromArgb(47, 48, 52),
				Color.FromArgb(48, 49, 53)
			};
			int num3 = 0;
			int num4;
			do
			{
				Pen pen = new Pen(array[num3]);
				size = ItemSize;
				rectangle = new Rectangle(size.Height - 1 + num3 + 1, num3 + 1, Width - ItemSize.Height - 1 - (2 * num3 + 3), Height - (2 * num3 + 3));
				graphics.DrawPath(pen, Class19.smethod_0(rectangle, int_));
				num3++;
				num4 = num3;
				int num5 = 5;
			}
			while (num4 <= 5);
			rectangle = new Rectangle(0, 0, Width - 1, Height - 1);
			LinearGradientBrush brush2 = new LinearGradientBrush(rectangle, Color.Transparent, Color.FromArgb(87, 88, 92), 90f);
			Pen pen2 = new Pen(brush2);
			size = ItemSize;
			rectangle = new Rectangle(size.Height - 1, 0, Width - ItemSize.Height - 1 - 1, Height - 1);
			graphics.DrawPath(pen2, Class19.smethod_0(rectangle, int_));
			Pen pen3 = new Pen(Color.FromArgb(32, 33, 37));
			size = ItemSize;
			rectangle = new Rectangle(size.Height - 1, 0, Width - ItemSize.Height - 1 - 1, Height - 2);
			graphics.DrawPath(pen3, Class19.smethod_0(rectangle, int_));
			int num6 = TabCount - 1;
			int num7 = 0;
			while (true)
			{
				int num8 = num7;
				int num5 = num6;
				if (num8 > num5)
				{
					break;
				}
				Point point;
				Point point2;
				if (num7 == SelectedIndex)
				{
					rectangle = GetTabRect(num7);
					point = rectangle.Location;
					point2 = new Point(point.X - 1, GetTabRect(num7).Location.Y + 3);
					Point location = point2;
					size = new Size(GetTabRect(num7).Width - 7, GetTabRect(num7).Height - 7);
					Rectangle rectangle2 = new Rectangle(location, size);
					point2 = GetTabRect(num7).Location;
					point = new Point(point2.X - 1, GetTabRect(num7).Location.Y + 4);
					Point location2 = point;
					size = new Size(GetTabRect(num7).Width - 7, GetTabRect(num7).Height - 8);
					Rectangle rectangle_ = new Rectangle(location2, size);
					LinearGradientBrush brush3 = new LinearGradientBrush(rectangle2, Color.FromArgb(72, 79, 87), Color.FromArgb(48, 51, 56), 90f);
					graphics.FillPath(brush3, Class19.smethod_0(rectangle2, int_));
					LinearGradientBrush brush4 = new LinearGradientBrush(rectangle2, Color.FromArgb(119, 124, 130), Color.FromArgb(64, 67, 72), 90f);
					graphics.DrawPath(new Pen(brush4), Class19.smethod_0(rectangle_, int_));
					graphics.DrawPath(new Pen(Color.FromArgb(31, 36, 42)), Class19.smethod_0(rectangle2, int_));
				}
				switch (GEnum3_0)
				{
				case GEnum3.Left:
				{
					point2 = GetTabRect(num7).Location;
					point = new Point(point2.X + 3, GetTabRect(num7).Location.Y + 4);
					Point location7 = point;
					size = new Size(GetTabRect(num7).Width - 1, GetTabRect(num7).Height - 7);
					Rectangle rectangle7 = new Rectangle(location7, size);
					point2 = GetTabRect(num7).Location;
					point = new Point(point2.X + 4, GetTabRect(num7).Location.Y + 5);
					Point location8 = point;
					size = new Size(GetTabRect(num7).Width - 1, GetTabRect(num7).Height - 7);
					Rectangle rectangle8 = new Rectangle(location8, size);
					graphics.DrawString(TabPages[num7].Text, Font, new SolidBrush(Color.FromArgb(150, Color.Black)), rectangle8, new StringFormat
					{
						LineAlignment = StringAlignment.Center,
						Alignment = StringAlignment.Near
					});
					graphics.DrawString(TabPages[num7].Text, Font, Brushes.White, rectangle7, new StringFormat
					{
						LineAlignment = StringAlignment.Center,
						Alignment = StringAlignment.Near
					});
					break;
				}
				case GEnum3.Center:
				{
					point2 = GetTabRect(num7).Location;
					point = new Point(point2.X - 4, GetTabRect(num7).Location.Y + 4);
					Point location5 = point;
					size = new Size(GetTabRect(num7).Width - 1, GetTabRect(num7).Height - 7);
					Rectangle rectangle5 = new Rectangle(location5, size);
					point2 = GetTabRect(num7).Location;
					point = new Point(point2.X - 3, GetTabRect(num7).Location.Y + 5);
					Point location6 = point;
					size = new Size(GetTabRect(num7).Width - 1, GetTabRect(num7).Height - 7);
					Rectangle rectangle6 = new Rectangle(location6, size);
					graphics.DrawString(TabPages[num7].Text, Font, new SolidBrush(Color.FromArgb(150, Color.Black)), rectangle6, new StringFormat
					{
						LineAlignment = StringAlignment.Center,
						Alignment = StringAlignment.Center
					});
					graphics.DrawString(TabPages[num7].Text, Font, Brushes.White, rectangle5, new StringFormat
					{
						LineAlignment = StringAlignment.Center,
						Alignment = StringAlignment.Center
					});
					break;
				}
				case GEnum3.Right:
				{
					point2 = GetTabRect(num7).Location;
					point = new Point(point2.X - 9, GetTabRect(num7).Location.Y + 4);
					Point location3 = point;
					size = new Size(GetTabRect(num7).Width - 1, GetTabRect(num7).Height - 7);
					Rectangle rectangle3 = new Rectangle(location3, size);
					point2 = GetTabRect(num7).Location;
					point = new Point(point2.X - 8, GetTabRect(num7).Location.Y + 5);
					Point location4 = point;
					size = new Size(GetTabRect(num7).Width - 1, GetTabRect(num7).Height - 7);
					Rectangle rectangle4 = new Rectangle(location4, size);
					graphics.DrawString(TabPages[num7].Text, Font, new SolidBrush(Color.FromArgb(150, Color.Black)), rectangle4, new StringFormat
					{
						LineAlignment = StringAlignment.Center,
						Alignment = StringAlignment.Far
					});
					graphics.DrawString(TabPages[num7].Text, Font, Brushes.White, rectangle3, new StringFormat
					{
						LineAlignment = StringAlignment.Center,
						Alignment = StringAlignment.Far
					});
					break;
				}
				}
				num7++;
			}
			NewLateBinding.LateCall(e.Graphics, null, "DrawImage", new object[3]
			{
				RuntimeHelpers.GetObjectValue(bitmap.Clone()),
				0,
				0
			}, null, null, null, IgnoreReturn: true);
			graphics.Dispose();
			bitmap.Dispose();
		}
	}
}
