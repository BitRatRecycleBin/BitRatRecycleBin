using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

internal class Control5 : TabControl
{
	private static List<WeakReference> list_0 = new List<WeakReference>();

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	public Control5()
	{
		smethod_0(this);
		SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.DoubleBuffer, value: true);
		Size size2 = (Size = new Size(400, 200));
		SizeMode = TabSizeMode.Fixed;
		size2 = (ItemSize = new Size(35, 145));
		Font = new Font("Verdana", 8f);
	}

	protected override void CreateHandle()
	{
		base.CreateHandle();
		Alignment = TabAlignment.Left;
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Graphics graphics = e.Graphics;
		graphics.SmoothingMode = SmoothingMode.HighQuality;
		graphics.Clear(Parent.BackColor);
		Color color = default(Color);
		Pen pen = new Pen(Color.FromArgb(55, 55, 55));
		checked
		{
			Rectangle rectangle_ = new Rectangle(ItemSize.Height + 2, 2, Width - 1 - ItemSize.Height - 2, Height - 3);
			GraphicsPath path = Class7.smethod_3(rectangle_, 4);
			graphics.FillPath(new SolidBrush(Color.FromArgb(100, 100, 100)), path);
			graphics.DrawPath(pen, path);
			int num = TabCount - 1;
			int num2 = 0;
			while (true)
			{
				int num3 = num2;
				int num4 = num;
				if (num3 <= num4)
				{
					if (num2 == SelectedIndex)
					{
						Rectangle tabRect = GetTabRect(num2);
						GraphicsPath path2 = Class7.smethod_2(tabRect, 6);
						graphics.FillPath(new SolidBrush(Color.FromArgb(100, 100, 100)), path2);
						graphics.DrawPath(pen, path2);
						Rectangle rect = new Rectangle(tabRect.X + 12, (int)Math.Round((double)tabRect.Y + (double)tabRect.Height / 2.0 - 8.0), 16, 16);
						graphics.FillEllipse(Brushes.SteelBlue, rect);
						graphics.FillEllipse(new LinearGradientBrush(rect, Color.FromArgb(30, Color.White), Color.FromArgb(10, Color.Black), 115f), rect);
						graphics.DrawEllipse(new Pen(Color.FromArgb(40, 105, 145)), rect);
						graphics.SmoothingMode = SmoothingMode.None;
						Pen pen2 = new Pen(Color.FromArgb(100, 100, 100));
						Point pt = new Point(tabRect.X + tabRect.Width, tabRect.Y + 1);
						Point pt2 = new Point(tabRect.X + tabRect.Width, tabRect.Y + tabRect.Height - 1);
						graphics.DrawLine(pen2, pt, pt2);
						graphics.SmoothingMode = SmoothingMode.HighQuality;
						color = Color.White;
						int num5 = tabRect.Location.X + 28 + 8;
						int num6 = (int)Math.Round((double)tabRect.Location.Y + (double)tabRect.Height / 2.0 - (double)(graphics.MeasureString(TabPages[num2].Text, Font).Height / 2f));
						string s = TabPages[num2].Text;
						Font font = Font;
						SolidBrush brush = new SolidBrush(color);
						pt2 = new Point(num5, num6);
						graphics.DrawString(s, font, brush, pt2);
					}
					else
					{
						Rectangle tabRect2 = GetTabRect(num2);
						Rectangle rectangle_2 = new Rectangle(tabRect2.X + 6, tabRect2.Y, tabRect2.Width - 6, tabRect2.Height);
						GraphicsPath path3 = Class7.smethod_2(rectangle_2, 6);
						graphics.FillPath(new SolidBrush(Color.FromArgb(75, 75, 75)), path3);
						graphics.DrawPath(pen, path3);
						Rectangle rect2 = new Rectangle(rectangle_2.X + 12, (int)Math.Round((double)rectangle_2.Y + (double)rectangle_2.Height / 2.0 - 8.0), 16, 16);
						graphics.FillEllipse(Brushes.Gray, rect2);
						graphics.DrawEllipse(Pens.DimGray, rect2);
						color = Color.Silver;
						int num7 = rectangle_2.Location.X + 28 + 8;
						int num8 = (int)Math.Round((double)rectangle_2.Location.Y + (double)rectangle_2.Height / 2.0 - (double)(graphics.MeasureString(TabPages[num2].Text, Font).Height / 2f));
						string s2 = TabPages[num2].Text;
						Font font2 = Font;
						SolidBrush brush2 = new SolidBrush(color);
						Point pt2 = new Point(num7, num8);
						graphics.DrawString(s2, font2, brush2, pt2);
					}
					try
					{
						TabPages[num2].BackColor = Color.FromArgb(100, 100, 100);
					}
					catch (Exception projectError)
					{
						ProjectData.SetProjectError(projectError);
						ProjectData.ClearProjectError();
					}
					num2++;
					continue;
				}
				break;
			}
		}
	}
}
