using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

internal class Control1 : Control
{
	public enum Enum0
	{
		None,
		Over,
		Down
	}

	private static List<WeakReference> list_0 = new List<WeakReference>();

	private Enum0 enum0_0;

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	public Control1()
	{
		smethod_0(this);
		SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		Font = new Font("Segoe UI", 9f);
		BackColor = Color.Gray;
		ForeColor = Color.WhiteSmoke;
		Size size2 = (Size = new Size(120, 40));
		Cursor = Cursors.Hand;
		enum0_0 = Enum0.None;
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		base.OnPaint(e);
		Graphics graphics = e.Graphics;
		graphics.Clear(Parent.BackColor);
		graphics.SmoothingMode = SmoothingMode.HighQuality;
		checked
		{
			Rectangle rectangle = new Rectangle(0, 0, Width - 1, Height - 1);
			GraphicsPath path = Class7.smethod_0(rectangle, 6);
			LinearGradientBrush brush = new LinearGradientBrush(rectangle, BackColor, Color.FromArgb(40, 40, 40), 90f);
			graphics.FillPath(brush, path);
			if (enum0_0 == Enum0.Over)
			{
				graphics.FillPath(new SolidBrush(Color.FromArgb(15, Color.White)), path);
			}
			else if (enum0_0 == Enum0.Down)
			{
				graphics.FillPath(new SolidBrush(Color.FromArgb(25, Color.White)), path);
			}
			int num = (int)Math.Round((double)(Width - 1) / 2.0 - (double)(graphics.MeasureString(Text, Font).Width / 2f));
			int num2 = (int)Math.Round((double)(Height - 1) / 2.0 - (double)(graphics.MeasureString(Text, Font).Height / 2f));
			string string_ = Text;
			Font font = Font;
			SolidBrush brush_ = new SolidBrush(ForeColor);
			Point point_ = new Point(num, num2);
			Class7.smethod_4(graphics, string_, font, brush_, point_);
			graphics.DrawPath(new Pen(Color.FromArgb(30, 30, 30)), path);
		}
	}

	protected override void OnMouseEnter(EventArgs e)
	{
		base.OnMouseEnter(e);
		enum0_0 = Enum0.Over;
		Invalidate();
	}

	protected override void OnMouseLeave(EventArgs e)
	{
		base.OnMouseLeave(e);
		enum0_0 = Enum0.None;
		Invalidate();
	}

	protected override void OnMouseDown(MouseEventArgs e)
	{
		base.OnMouseDown(e);
		enum0_0 = Enum0.Down;
		Invalidate();
	}

	protected override void OnMouseUp(MouseEventArgs e)
	{
		base.OnMouseUp(e);
		enum0_0 = Enum0.Over;
		Invalidate();
	}
}
