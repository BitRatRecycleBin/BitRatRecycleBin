using System.ComponentModel.Design;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

[DebuggerNonUserCode]
[CompilerGenerated]
[StandardModule]
[HideModuleName]
internal sealed class Class6
{
	[HelpKeyword("My.Settings")]
	internal static Class5 Class5_0 => Class5.Class5_0;
}
