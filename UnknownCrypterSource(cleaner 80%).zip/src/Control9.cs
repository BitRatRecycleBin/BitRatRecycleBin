using System.Drawing;
using System.Windows.Forms;

internal class Control9 : Control8
{
	public Control9()
	{
		Color_0 = Color.Fuchsia;
		BackColor = Color.FromArgb(51, 51, 51);
		Int32_2 = 25;
	}

	protected override void ColorHook()
	{
	}

	protected override void PaintHook()
	{
		graphics_0.Clear(Color.FromArgb(51, 51, 51));
		checked
		{
			method_57(Color.FromArgb(29, 29, 29), Color.FromArgb(65, 65, 65), 0, 28, Width, unchecked(Height / 2) - 10);
			method_57(Color.FromArgb(87, 87, 87), Color.FromArgb(49, 49, 49), 0, 0, Width, 25);
			graphics_0.DrawLine(Pens.Black, 0, 25, Width, 25);
			graphics_0.DrawLine(new Pen(Color.FromArgb(192, 74, 74)), 0, 26, Width, 26);
			graphics_0.FillRectangle(new SolidBrush(Color.FromArgb(169, 0, 0)), 0, 27, Width, 27);
			graphics_0.FillRectangle(new SolidBrush(Color.FromArgb(45, Color.White)), 0, 27, Width, 13);
			graphics_0.DrawLine(new Pen(Color.FromArgb(38, 38, 38)), 0, Height - 25, Width, Height - 25);
			graphics_0.DrawLine(new Pen(Color.FromArgb(64, 64, 64)), 0, Height - 24, Width, Height - 24);
			method_40(Pens.Black);
			method_37(new Pen(Color.FromArgb(92, 92, 92)), 1);
			method_34(Color.Fuchsia);
			method_43(Brushes.Black, HorizontalAlignment.Center, 0, 0);
			method_43(Brushes.White, HorizontalAlignment.Center, 0, 1);
		}
	}
}
