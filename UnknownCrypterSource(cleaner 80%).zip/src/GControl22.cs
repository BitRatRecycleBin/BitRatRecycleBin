using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

public class GControl22 : Control
{
	public enum GEnum7
	{
		Left,
		Middle,
		Right
	}

	private static List<WeakReference> list_0 = new List<WeakReference>();

	private Color color_0;

	private Color color_1;

	private Font font_0;

	private bool bool_0;

	private StringAlignment stringAlignment_0;

	private GEnum7 genum7_0;

	private bool bool_1;

	private bool bool_2;

	private bool bool_3;

	private bool bool_4;

	[Category("Control")]
	public GEnum7 GEnum7_0
	{
		get
		{
			return genum7_0;
		}
		set
		{
			genum7_0 = value;
			Invalidate();
		}
	}

	[Category("Control")]
	public StringAlignment StringAlignment_0
	{
		get
		{
			return stringAlignment_0;
		}
		set
		{
			stringAlignment_0 = value;
			Invalidate();
		}
	}

	[Category("Control")]
	public bool Boolean_0
	{
		get
		{
			return bool_3;
		}
		set
		{
			bool_3 = value;
			Invalidate();
		}
	}

	[Category("Control")]
	public bool Boolean_1
	{
		get
		{
			return bool_4;
		}
		set
		{
			bool_4 = value;
			Invalidate();
		}
	}

	[Category("Control")]
	public bool Boolean_2
	{
		get
		{
			return bool_2;
		}
		set
		{
			bool_2 = value;
			Invalidate();
		}
	}

	[Category("Control")]
	public bool Boolean_3
	{
		get
		{
			return bool_1;
		}
		set
		{
			bool_1 = value;
			Invalidate();
		}
	}

	[Category("Control")]
	public bool Boolean_4
	{
		get
		{
			return bool_0;
		}
		set
		{
			bool_0 = value;
			Invalidate();
		}
	}

	[Category("Colours")]
	public Color Color_0
	{
		get
		{
			return color_1;
		}
		set
		{
			color_1 = value;
		}
	}

	[Category("Colours")]
	public Color Color_1
	{
		get
		{
			return color_0;
		}
		set
		{
			color_0 = value;
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	protected override void OnSizeChanged(EventArgs e)
	{
		base.OnSizeChanged(e);
		if (bool_0 && !((float)Height >= Font.Size * 2f + 3f))
		{
			Size size2 = (Size = new Size(Width, checked((int)Math.Round(Font.Size * 2f + 3f))));
		}
		Invalidate();
	}

	public GControl22()
	{
		smethod_0(this);
		color_0 = Color.FromArgb(153, 153, 153);
		color_1 = Color.FromArgb(0, 122, 204);
		font_0 = new Font("Microsoft Sans Serif", 8f);
		stringAlignment_0 = StringAlignment.Center;
		genum7_0 = GEnum7.Left;
		bool_1 = false;
		bool_2 = false;
		bool_3 = false;
		bool_4 = false;
		SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		DoubleBuffered = true;
		BackColor = Color.Transparent;
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Graphics graphics = e.Graphics;
		Graphics graphics2 = graphics;
		graphics2.TextRenderingHint = TextRenderingHint.AntiAlias;
		graphics2.SmoothingMode = SmoothingMode.AntiAlias;
		graphics2.PixelOffsetMode = PixelOffsetMode.HighQuality;
		checked
		{
			Rectangle rectangle;
			Point point2;
			Point point;
			if (bool_0 && !bool_3)
			{
				switch (genum7_0)
				{
				case GEnum7.Left:
				{
					Graphics graphics11 = graphics2;
					string s3 = Text;
					Font font3 = Font;
					SolidBrush brush3 = new SolidBrush(color_0);
					rectangle = new Rectangle(0, 0, (int)Math.Round(graphics2.MeasureString(Text, Font).Width + 10f), Height);
					graphics11.DrawString(s3, font3, brush3, rectangle, new StringFormat
					{
						Alignment = stringAlignment_0,
						LineAlignment = StringAlignment.Center
					});
					Graphics graphics12 = graphics2;
					Pen pen7 = new Pen(color_1);
					point2 = new Point((int)Math.Round(graphics2.MeasureString(Text, Font).Width + 20f), (int)Math.Round((double)Height / 2.0));
					Point pt7 = point2;
					point = new Point(Width, (int)Math.Round((double)Height / 2.0));
					graphics12.DrawLine(pen7, pt7, point);
					if (bool_1)
					{
						Graphics graphics13 = graphics2;
						Pen pen8 = new Pen(color_1);
						point = new Point(Width - 1, (int)Math.Round((double)Height / 2.0 - (double)(graphics2.MeasureString(Text, Font).Height / 2f)));
						Point pt8 = point;
						point2 = new Point(Width - 1, (int)Math.Round((double)Height / 2.0 + (double)(graphics2.MeasureString(Text, Font).Height / 2f)));
						graphics13.DrawLine(pen8, pt8, point2);
					}
					if (bool_2)
					{
						graphics2.DrawLine(new Pen(color_1), 0, (int)Math.Round((double)Height / 2.0 + (double)(graphics2.MeasureString(Text, Font).Height / 2f)) + 3, (int)Math.Round(graphics2.MeasureString(Text, Font).Width + 20f), (int)Math.Round((double)Height / 2.0 + (double)(graphics2.MeasureString(Text, Font).Height / 2f)) + 3);
						graphics2.DrawLine(new Pen(color_1), (int)Math.Round(graphics2.MeasureString(Text, Font).Width + 20f), (int)Math.Round((double)Height / 2.0 + (double)(graphics2.MeasureString(Text, Font).Height / 2f)) + 3, (int)Math.Round(graphics2.MeasureString(Text, Font).Width + 20f), (int)Math.Round((double)Height / 2.0));
					}
					break;
				}
				case GEnum7.Middle:
				{
					Graphics graphics6 = graphics2;
					string s2 = Text;
					Font font2 = Font;
					SolidBrush brush2 = new SolidBrush(color_0);
					rectangle = new Rectangle((int)Math.Round((double)Width / 2.0 - (double)(graphics2.MeasureString(Text, Font).Width / 2f) - 10.0), 0, (int)Math.Round(graphics2.MeasureString(Text, Font).Width) + 10, Height);
					graphics6.DrawString(s2, font2, brush2, rectangle, new StringFormat
					{
						Alignment = stringAlignment_0,
						LineAlignment = StringAlignment.Center
					});
					Graphics graphics7 = graphics2;
					Pen pen3 = new Pen(color_1);
					point = new Point(0, (int)Math.Round((double)Height / 2.0));
					Point pt3 = point;
					point2 = new Point((int)Math.Round((double)Width / 2.0 - (double)(graphics2.MeasureString(Text, Font).Width / 2f) - 20.0), (int)Math.Round((double)Height / 2.0));
					graphics7.DrawLine(pen3, pt3, point2);
					Graphics graphics8 = graphics2;
					Pen pen4 = new Pen(color_1);
					point = new Point((int)Math.Round((double)Width / 2.0 + (double)(graphics2.MeasureString(Text, Font).Width / 2f) + 10.0), (int)Math.Round((double)Height / 2.0));
					Point pt4 = point;
					point2 = new Point(Width, (int)Math.Round((double)Height / 2.0));
					graphics8.DrawLine(pen4, pt4, point2);
					if (bool_1)
					{
						Graphics graphics9 = graphics2;
						Pen pen5 = new Pen(color_1);
						point = new Point(Width - 1, (int)Math.Round((double)Height / 2.0 - (double)(graphics2.MeasureString(Text, Font).Height / 2f)));
						Point pt5 = point;
						point2 = new Point(Width - 1, (int)Math.Round((double)Height / 2.0 + (double)(graphics2.MeasureString(Text, Font).Height / 2f)));
						graphics9.DrawLine(pen5, pt5, point2);
						Graphics graphics10 = graphics2;
						Pen pen6 = new Pen(color_1);
						point = new Point(1, (int)Math.Round((double)Height / 2.0 - (double)(graphics2.MeasureString(Text, Font).Height / 2f)));
						Point pt6 = point;
						point2 = new Point(1, (int)Math.Round((double)Height / 2.0 + (double)(graphics2.MeasureString(Text, Font).Height / 2f)));
						graphics10.DrawLine(pen6, pt6, point2);
					}
					if (bool_2)
					{
						graphics2.DrawLine(new Pen(color_1), (int)Math.Round((double)Width / 2.0 - (double)(graphics2.MeasureString(Text, Font).Width / 2f) - 20.0), (int)Math.Round((double)Height / 2.0), (int)Math.Round((double)Width / 2.0 - (double)(graphics2.MeasureString(Text, Font).Width / 2f) - 20.0), (int)Math.Round((double)Height / 2.0 + (double)(graphics2.MeasureString(Text, Font).Height / 2f)) + 3);
						graphics2.DrawLine(new Pen(color_1), (int)Math.Round((double)Width / 2.0 + (double)(graphics2.MeasureString(Text, Font).Width / 2f) + 10.0), (int)Math.Round((double)Height / 2.0), (int)Math.Round((double)Width / 2.0 + (double)(graphics2.MeasureString(Text, Font).Width / 2f) + 10.0), (int)Math.Round((double)Height / 2.0 + (double)(graphics2.MeasureString(Text, Font).Height / 2f)) + 3);
						graphics2.DrawLine(new Pen(color_1), (int)Math.Round((double)Width / 2.0 - (double)(graphics2.MeasureString(Text, Font).Width / 2f) - 20.0), (int)Math.Round((double)Height / 2.0 + (double)(graphics2.MeasureString(Text, Font).Height / 2f)) + 3, (int)Math.Round((double)Width / 2.0 + (double)(graphics2.MeasureString(Text, Font).Width / 2f) + 10.0), (int)Math.Round((double)Height / 2.0 + (double)(graphics2.MeasureString(Text, Font).Height / 2f)) + 3);
					}
					break;
				}
				case GEnum7.Right:
				{
					Graphics graphics3 = graphics2;
					string s = Text;
					Font font = Font;
					SolidBrush brush = new SolidBrush(color_0);
					rectangle = new Rectangle((int)Math.Round((float)Width - graphics2.MeasureString(Text, Font).Width - 10f), 0, (int)Math.Round(graphics2.MeasureString(Text, Font).Width + 10f), Height);
					graphics3.DrawString(s, font, brush, rectangle, new StringFormat
					{
						Alignment = stringAlignment_0,
						LineAlignment = StringAlignment.Center
					});
					Graphics graphics4 = graphics2;
					Pen pen = new Pen(color_1);
					point = new Point(0, (int)Math.Round((double)Height / 2.0));
					Point pt = point;
					point2 = new Point((int)Math.Round((float)Width - graphics2.MeasureString(Text, Font).Width - 20f), (int)Math.Round((double)Height / 2.0));
					graphics4.DrawLine(pen, pt, point2);
					if (bool_1)
					{
						Graphics graphics5 = graphics2;
						Pen pen2 = new Pen(color_1);
						point = new Point(1, (int)Math.Round((double)Height / 2.0 - (double)(graphics2.MeasureString(Text, Font).Height / 2f)));
						Point pt2 = point;
						point2 = new Point(1, (int)Math.Round((double)Height / 2.0 + (double)(graphics2.MeasureString(Text, Font).Height / 2f)));
						graphics5.DrawLine(pen2, pt2, point2);
					}
					if (bool_2)
					{
						graphics2.DrawLine(new Pen(color_1), (int)Math.Round((float)Width - graphics2.MeasureString(Text, Font).Width - 20f), (int)Math.Round((double)Height / 2.0 + (double)(graphics2.MeasureString(Text, Font).Height / 2f)) + 3, Width, (int)Math.Round((double)Height / 2.0 + (double)(graphics2.MeasureString(Text, Font).Height / 2f)) + 3);
						graphics2.DrawLine(new Pen(color_1), (int)Math.Round((float)Width - graphics2.MeasureString(Text, Font).Width - 20f), (int)Math.Round((double)Height / 2.0 + (double)(graphics2.MeasureString(Text, Font).Height / 2f)) + 3, (int)Math.Round((float)Width - graphics2.MeasureString(Text, Font).Width - 20f), (int)Math.Round((double)Height / 2.0));
					}
					break;
				}
				}
			}
			else if (bool_0 && bool_3)
			{
				if (bool_4)
				{
					Graphics graphics14 = graphics2;
					Pen pen9 = new Pen(color_1);
					point = new Point(5, (int)Math.Round((double)Height / 2.0) + 6);
					Point pt9 = point;
					point2 = new Point((int)Math.Round(graphics2.MeasureString(Text, Font).Width + 8f), (int)Math.Round((double)Height / 2.0) + 6);
					graphics14.DrawLine(pen9, pt9, point2);
					Graphics graphics15 = graphics2;
					string s4 = Text;
					Font font4 = Font;
					SolidBrush brush4 = new SolidBrush(color_0);
					rectangle = new Rectangle(5, 0, Width - 10, (int)Math.Round((double)Height / 2.0 + 3.0));
					graphics15.DrawString(s4, font4, brush4, rectangle, new StringFormat
					{
						Alignment = StringAlignment.Near,
						LineAlignment = StringAlignment.Far
					});
				}
				else
				{
					Graphics graphics16 = graphics2;
					Pen pen10 = new Pen(color_1);
					point = new Point(0, (int)Math.Round((double)Height / 2.0) + 6);
					Point pt10 = point;
					point2 = new Point(Width, (int)Math.Round((double)Height / 2.0) + 6);
					graphics16.DrawLine(pen10, pt10, point2);
					if (bool_1)
					{
						Graphics graphics17 = graphics2;
						Pen pen11 = new Pen(color_1);
						point = new Point(Width - 1, (int)Math.Round((double)Height / 2.0) - 5);
						Point pt11 = point;
						point2 = new Point(Width - 1, (int)Math.Round((double)Height / 2.0 + 5.0));
						graphics17.DrawLine(pen11, pt11, point2);
						Graphics graphics18 = graphics2;
						Pen pen12 = new Pen(color_1);
						point = new Point(1, (int)Math.Round((double)Height / 2.0) - 5);
						Point pt12 = point;
						point2 = new Point(1, (int)Math.Round((double)Height / 2.0 + 5.0));
						graphics18.DrawLine(pen12, pt12, point2);
					}
					Graphics graphics19 = graphics2;
					string s5 = Text;
					Font font5 = Font;
					SolidBrush brush5 = new SolidBrush(color_0);
					rectangle = new Rectangle(5, 0, Width - 10, (int)Math.Round((double)Height / 2.0 + 3.0));
					graphics19.DrawString(s5, font5, brush5, rectangle, new StringFormat
					{
						Alignment = stringAlignment_0,
						LineAlignment = StringAlignment.Far
					});
				}
			}
			else if (bool_4)
			{
				Graphics graphics20 = graphics2;
				Pen pen13 = new Pen(color_1);
				point = new Point(5, (int)Math.Round((double)Height / 2.0) + 6);
				Point pt13 = point;
				point2 = new Point((int)Math.Round(graphics2.MeasureString(Text, Font).Width + 8f), (int)Math.Round((double)Height / 2.0) + 6);
				graphics20.DrawLine(pen13, pt13, point2);
				Graphics graphics21 = graphics2;
				string s6 = Text;
				Font font6 = Font;
				SolidBrush brush6 = new SolidBrush(color_0);
				rectangle = new Rectangle(5, 0, Width - 10, (int)Math.Round((double)Height / 2.0 + 3.0));
				graphics21.DrawString(s6, font6, brush6, rectangle, new StringFormat
				{
					Alignment = StringAlignment.Near,
					LineAlignment = StringAlignment.Far
				});
			}
			else
			{
				Graphics graphics22 = graphics2;
				Pen pen14 = new Pen(color_1);
				point = new Point(0, (int)Math.Round((double)Height / 2.0));
				Point pt14 = point;
				point2 = new Point(Width, (int)Math.Round((double)Height / 2.0));
				graphics22.DrawLine(pen14, pt14, point2);
				if (bool_1)
				{
					Graphics graphics23 = graphics2;
					Pen pen15 = new Pen(color_1);
					point = new Point(Width - 1, (int)Math.Round((double)Height / 2.0 - (double)(graphics2.MeasureString(Text, Font).Height / 2f)));
					Point pt15 = point;
					point2 = new Point(Width - 1, (int)Math.Round((double)Height / 2.0 + (double)(graphics2.MeasureString(Text, Font).Height / 2f)));
					graphics23.DrawLine(pen15, pt15, point2);
					Graphics graphics24 = graphics2;
					Pen pen16 = new Pen(color_1);
					point = new Point(1, (int)Math.Round((double)Height / 2.0 - (double)(graphics2.MeasureString(Text, Font).Height / 2f)));
					Point pt16 = point;
					point2 = new Point(1, (int)Math.Round((double)Height / 2.0 + (double)(graphics2.MeasureString(Text, Font).Height / 2f)));
					graphics24.DrawLine(pen16, pt16, point2);
				}
			}
			graphics2.InterpolationMode = InterpolationMode.HighQualityBicubic;
			graphics2 = null;
		}
	}
}
