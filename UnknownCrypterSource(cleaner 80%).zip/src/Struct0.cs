using System;
using System.Drawing;
using Microsoft.VisualBasic.CompilerServices;

internal struct Struct0
{
	public string string_0;

	private Color color_0;

	public string String_0 => string_0;

	public Color Color_0
	{
		get
		{
			return color_0;
		}
		set
		{
			color_0 = value;
		}
	}

	public string String_1
	{
		get
		{
			return "#" + color_0.R.ToString("X2", null) + color_0.G.ToString("X2", null) + color_0.B.ToString("X2", null);
		}
		set
		{
			try
			{
				color_0 = ColorTranslator.FromHtml(value);
			}
			catch (Exception projectError)
			{
				ProjectData.SetProjectError(projectError);
				ProjectData.ClearProjectError();
			}
		}
	}

	public Struct0(string name, Color value)
	{
		this = default(Struct0);
		string_0 = name;
		color_0 = value;
	}
}
