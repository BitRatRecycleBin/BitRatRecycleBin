using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

[DefaultEvent("Scroll")]
internal class Control30 : Control
{
	public delegate void Delegate10(object sender);

	private static List<WeakReference> list_0 = new List<WeakReference>();

	private Delegate10 delegate10_0;

	private int int_0;

	private int int_1;

	private int int_2;

	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private double double_0;

	private int int_3;

	private int int_4;

	private int int_5;

	private int int_6;

	private Rectangle rectangle_0;

	private Rectangle rectangle_1;

	private Rectangle rectangle_2;

	private Rectangle rectangle_3;

	private bool bool_0;

	private bool bool_1;

	private GraphicsPath graphicsPath_0;

	private GraphicsPath graphicsPath_1;

	private GraphicsPath graphicsPath_2;

	private GraphicsPath graphicsPath_3;

	private int int_7;

	public int Int32_0
	{
		get
		{
			return int_0;
		}
		set
		{
			if (value < 0)
			{
				throw new Exception("Property value is not valid.");
			}
			int_0 = value;
			if (value > int_2)
			{
				int_2 = value;
			}
			if (value > int_1)
			{
				int_1 = value;
			}
			method_1();
		}
	}

	public int Int32_1
	{
		get
		{
			return int_1;
		}
		set
		{
			if (value < 1)
			{
				value = 1;
			}
			int_1 = value;
			if (value < int_2)
			{
				int_2 = value;
			}
			if (value < int_0)
			{
				int_0 = value;
			}
			method_1();
		}
	}

	public int Int32_2
	{
		get
		{
			if (!bool_0)
			{
				return int_0;
			}
			return int_2;
		}
		set
		{
			if (value != int_2)
			{
				if (value > int_1 || value < int_0)
				{
					throw new Exception("Property value is not valid.");
				}
				int_2 = value;
				method_2();
				delegate10_0?.Invoke(this);
			}
		}
	}

	public double Double_0
	{
		[DebuggerNonUserCode]
		get
		{
			return double_0;
		}
		[DebuggerNonUserCode]
		set
		{
			double_0 = value;
		}
	}

	public double Double_1
	{
		get
		{
			if (!bool_0)
			{
				return 0.0;
			}
			return method_3();
		}
	}

	public int Int32_3
	{
		get
		{
			return int_3;
		}
		set
		{
			if (value < 1)
			{
				throw new Exception("Property value is not valid.");
			}
			int_3 = value;
		}
	}

	public int Int32_4
	{
		get
		{
			return int_4;
		}
		set
		{
			if (value < 1)
			{
				throw new Exception("Property value is not valid.");
			}
			int_4 = value;
		}
	}

	public event Delegate10 Event_0
	{
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		add
		{
			delegate10_0 = (Delegate10)Delegate.Combine(delegate10_0, value);
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		remove
		{
			delegate10_0 = (Delegate10)Delegate.Remove(delegate10_0, value);
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	public Control30()
	{
		smethod_0(this);
		int_1 = 100;
		int_3 = 1;
		int_4 = 10;
		int_5 = 16;
		int_6 = 24;
		SetStyle(ControlStyles.UserPaint | ControlStyles.Opaque | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		SetStyle(ControlStyles.Selectable, value: false);
		Width = 18;
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Graphics graphics = e.Graphics;
		graphics = e.Graphics;
		graphics.Clear(Color.FromArgb(255, 255, 255));
		graphicsPath_0 = method_0(4, 6, bool_2: false);
		graphicsPath_1 = method_0(5, 7, bool_2: false);
		graphics.FillPath(new SolidBrush(Color.LightGray), graphicsPath_1);
		graphics.FillPath(new SolidBrush(Color.FromArgb(83, 123, 168)), graphicsPath_0);
		checked
		{
			graphicsPath_2 = method_0(4, Height - 11, bool_2: true);
			graphicsPath_3 = method_0(5, Height - 10, bool_2: true);
			graphics.FillPath(new SolidBrush(Color.LightGray), graphicsPath_3);
			graphics.FillPath(new SolidBrush(Color.FromArgb(83, 123, 168)), graphicsPath_2);
			if (bool_0)
			{
				graphics.FillRectangle(new SolidBrush(Color.FromArgb(250, 250, 250)), rectangle_3);
				graphics.DrawRectangle(Pens.LightGray, rectangle_3);
				graphics.DrawRectangle(Pens.White, rectangle_3.X + 1, rectangle_3.Y + 1, rectangle_3.Width - 2, rectangle_3.Height - 2);
				int num = rectangle_3.Y + unchecked(rectangle_3.Height / 2) - 3;
				int num2 = 0;
				do
				{
					int num3 = num + num2 * 3;
					graphics.DrawLine(new Pen(new SolidBrush(Color.FromArgb(68, 95, 127))), rectangle_3.X + 5, num3, rectangle_3.Right - 5, num3);
					graphics.DrawLine(new Pen(new SolidBrush(Color.FromArgb(50, Color.FromArgb(68, 95, 127)))), rectangle_3.X + 5, num3 + 1, rectangle_3.Right - 5, num3 + 1);
					num2++;
				}
				while (num2 <= 2);
			}
			graphics.SmoothingMode = SmoothingMode.HighQuality;
			Graphics graphics2 = graphics;
			Pen pen = new Pen(new SolidBrush(Color.FromArgb(59, 122, 165)));
			Rectangle rectangle_ = new Rectangle(1, 1, Width - 3, Height - 3);
			graphics2.DrawPath(pen, method_4(rectangle_, 4));
			graphics.SmoothingMode = SmoothingMode.None;
		}
	}

	private GraphicsPath method_0(int int_8, int int_9, bool bool_2)
	{
		GraphicsPath graphicsPath = new GraphicsPath();
		int num = 9;
		int num2 = 5;
		checked
		{
			if (bool_2)
			{
				graphicsPath.AddLine(int_8 + 1, int_9, int_8 + num + 1, int_9);
				graphicsPath.AddLine(int_8 + num, int_9, int_8 + num2, int_9 + num2 - 1);
			}
			else
			{
				graphicsPath.AddLine(int_8, int_9 + num2, int_8 + num, int_9 + num2);
				graphicsPath.AddLine(int_8 + num, int_9 + num2, int_8 + num2, int_9);
			}
			graphicsPath.CloseFigure();
			return graphicsPath;
		}
	}

	protected override void OnSizeChanged(EventArgs e)
	{
		method_1();
	}

	private void method_1()
	{
		ref Rectangle reference = ref rectangle_0;
		reference = new Rectangle(0, 0, Width, int_5);
		ref Rectangle reference2 = ref rectangle_1;
		checked
		{
			reference2 = new Rectangle(0, Height - int_5, Width, int_5);
			ref Rectangle reference3 = ref rectangle_2;
			reference3 = new Rectangle(0, rectangle_0.Bottom + 1, Width, Height - int_5 * 2 - 1);
			bool_0 = int_1 - int_0 > rectangle_2.Height;
			if (bool_0)
			{
				ref Rectangle reference4 = ref rectangle_3;
				reference4 = new Rectangle(1, 0, Width - 3, int_6);
			}
			delegate10_0?.Invoke(this);
			method_2();
		}
	}

	private void method_2()
	{
		rectangle_3.Y = checked((int)Math.Round(method_3() * (double)(rectangle_2.Height - int_6)) + rectangle_0.Height);
		Invalidate();
	}

	protected override void OnMouseDown(MouseEventArgs e)
	{
		checked
		{
			if (e.Button == MouseButtons.Left && bool_0)
			{
				if (rectangle_0.Contains(e.Location))
				{
					int_7 = int_2 - int_3;
				}
				else if (rectangle_1.Contains(e.Location))
				{
					int_7 = int_2 + int_3;
				}
				else
				{
					if (rectangle_3.Contains(e.Location))
					{
						bool_1 = true;
						base.OnMouseDown(e);
						return;
					}
					if (e.Y < rectangle_3.Y)
					{
						int_7 = int_2 - int_4;
					}
					else
					{
						int_7 = int_2 + int_4;
					}
				}
				Int32_2 = Math.Min(Math.Max(int_7, int_0), int_1);
				method_2();
			}
			base.OnMouseDown(e);
		}
	}

	protected override void OnMouseMove(MouseEventArgs e)
	{
		checked
		{
			if (bool_1 && bool_0)
			{
				int num = e.Y - rectangle_0.Height - unchecked(int_6 / 2);
				int num2 = rectangle_2.Height - int_6;
				int_7 = (int)Math.Round((double)num / (double)num2 * (double)(int_1 - int_0)) + int_0;
				Int32_2 = Math.Min(Math.Max(int_7, int_0), int_1);
				method_2();
			}
			base.OnMouseMove(e);
		}
	}

	protected override void OnMouseUp(MouseEventArgs e)
	{
		bool_1 = false;
		base.OnMouseUp(e);
	}

	private double method_3()
	{
		return checked((double)(int_2 - int_0) / (double)(int_1 - int_0));
	}

	public GraphicsPath method_4(Rectangle rectangle_4, int int_8)
	{
		GraphicsPath graphicsPath = new GraphicsPath();
		checked
		{
			int num = int_8 * 2;
			Rectangle rect = new Rectangle(rectangle_4.X, rectangle_4.Y, num, num);
			graphicsPath.AddArc(rect, -180f, 90f);
			rect = new Rectangle(rectangle_4.Width - num + rectangle_4.X, rectangle_4.Y, num, num);
			graphicsPath.AddArc(rect, -90f, 90f);
			rect = new Rectangle(rectangle_4.Width - num + rectangle_4.X, rectangle_4.Height - num + rectangle_4.Y, num, num);
			graphicsPath.AddArc(rect, 0f, 90f);
			rect = new Rectangle(rectangle_4.X, rectangle_4.Height - num + rectangle_4.Y, num, num);
			graphicsPath.AddArc(rect, 90f, 90f);
			Point pt = new Point(rectangle_4.X, rectangle_4.Height - num + rectangle_4.Y);
			Point pt2 = new Point(rectangle_4.X, int_8 + rectangle_4.Y);
			graphicsPath.AddLine(pt, pt2);
			return graphicsPath;
		}
	}
}
