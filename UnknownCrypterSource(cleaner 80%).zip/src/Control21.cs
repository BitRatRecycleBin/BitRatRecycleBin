using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

[DefaultEvent("CheckedChanged")]
internal class Control21 : Control12
{
	public delegate void Delegate1(object sender);

	private static List<WeakReference> list_0 = new List<WeakReference>();

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private bool bool_6;

	private Delegate1 delegate1_0;

	private bool Boolean_3
	{
		[DebuggerNonUserCode]
		get
		{
			return bool_6;
		}
		[DebuggerNonUserCode]
		set
		{
			bool_6 = value;
		}
	}

	public bool Boolean_4
	{
		get
		{
			return Boolean_3;
		}
		set
		{
			Boolean_3 = value;
		}
	}

	public event Delegate1 Event_0
	{
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		add
		{
			delegate1_0 = (Delegate1)Delegate.Combine(delegate1_0, value);
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		remove
		{
			delegate1_0 = (Delegate1)Delegate.Remove(delegate1_0, value);
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	public Control21()
	{
		smethod_0(this);
		Boolean_3 = false;
		Boolean_1 = true;
		BackColor = Color.Transparent;
		Int32_1 = 15;
	}

	protected override void ColorHook()
	{
	}

	protected override void PaintHook()
	{
		graphics_0.Clear(BackColor);
		checked
		{
			switch (Boolean_3)
			{
			case false:
				graphics_0.FillEllipse(new SolidBrush(Color.FromArgb(51, 28, 28)), 2, 2, Height - 3, Height - 3);
				break;
			case true:
				graphics_0.FillEllipse(new SolidBrush(Color.FromArgb(129, 10, 10)), 2, 2, Height - 3, Height - 3);
				graphics_0.FillEllipse(new SolidBrush(Color.FromArgb(30, Color.White)), 2, 2, Height - 3, unchecked(Height / 2));
				break;
			}
			graphics_0.DrawEllipse(new Pen(Color.FromArgb(92, 92, 92)), 2, 2, Height - 3, Height - 3);
			graphics_0.DrawEllipse(Pens.Black, 1, 1, Height - 1, Height - 1);
			method_38(Brushes.White, HorizontalAlignment.Left, 18, 1);
		}
	}

	protected override void OnClick(EventArgs e)
	{
		Boolean_3 = !Boolean_3;
		delegate1_0?.Invoke(this);
		base.OnClick(e);
	}
}
