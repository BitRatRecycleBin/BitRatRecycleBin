using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

[DefaultEvent("CheckedChanged")]
internal class Control7 : Control
{
	public delegate void Delegate5(object sender);

	private static List<WeakReference> list_0 = new List<WeakReference>();

	private Delegate5 delegate5_0;

	private bool bool_0;

	public bool Boolean_0
	{
		get
		{
			return bool_0;
		}
		set
		{
			bool_0 = value;
			Invalidate();
		}
	}

	public event Delegate5 Event_0
	{
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		add
		{
			delegate5_0 = (Delegate5)Delegate.Combine(delegate5_0, value);
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		remove
		{
			delegate5_0 = (Delegate5)Delegate.Remove(delegate5_0, value);
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	public Control7()
	{
		smethod_0(this);
		SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		Size size2 = (Size = new Size(140, 20));
		ForeColor = Color.WhiteSmoke;
		Font = new Font("Segoe UI", 9f);
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Graphics graphics = e.Graphics;
		graphics.SmoothingMode = SmoothingMode.HighQuality;
		graphics.Clear(Parent.BackColor);
		checked
		{
			Rectangle rect = new Rectangle(0, 0, Height - 1, Height - 1);
			LinearGradientBrush brush = new LinearGradientBrush(rect, Color.FromArgb(120, 120, 120), Color.FromArgb(100, 100, 100), 90f);
			graphics.FillEllipse(brush, rect);
			graphics.DrawEllipse(new Pen(Color.FromArgb(50, 50, 50)), rect);
			int num = (int)Math.Round((double)(Height - 1) / 2.0 - (double)(graphics.MeasureString(Text, Font).Height / 2f) + 1.0);
			string s = Text;
			Font font = Font;
			SolidBrush brush2 = new SolidBrush(ForeColor);
			Point point = new Point(Height - 1 + 4, num);
			graphics.DrawString(s, font, brush2, point);
			if (bool_0)
			{
				Rectangle rect2 = new Rectangle(5, 5, Height - 11, Height - 11);
				LinearGradientBrush brush3 = new LinearGradientBrush(rect2, Color.LightGray, Color.Gray, 90f);
				graphics.FillEllipse(brush3, rect2);
				graphics.DrawEllipse(new Pen(Color.FromArgb(70, 70, 70)), rect2);
			}
		}
	}

	protected override void OnMouseDown(MouseEventArgs e)
	{
		base.OnMouseDown(e);
		IEnumerator enumerator = default(IEnumerator);
		try
		{
			enumerator = Parent.Controls.GetEnumerator();
			while (enumerator.MoveNext())
			{
				Control control = (Control)enumerator.Current;
				if (control != this && control is Control7)
				{
					((Control7)control).Boolean_0 = false;
				}
			}
		}
		finally
		{
			if (enumerator is IDisposable)
			{
				(enumerator as IDisposable).Dispose();
			}
		}
		if (bool_0)
		{
			bool_0 = false;
		}
		else
		{
			bool_0 = true;
		}
		delegate5_0?.Invoke(this);
		Invalidate();
	}
}
