using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

internal class Control11 : Control8
{
	private Pen pen_0;

	private Pen pen_1;

	private Color color_1;

	private Color color_2;

	private Color color_3;

	private Color color_4;

	private SolidBrush solidBrush_2;

	public Control11()
	{
		Color_0 = Color.Fuchsia;
		Int32_2 = 30;
		method_11("top", Color.FromArgb(21, 18, 37));
		method_11("bottom", Color.FromArgb(32, 35, 54));
		method_11("top2", Color.FromArgb(32, 35, 54));
		method_11("bottom2", Color.FromArgb(21, 18, 37));
		BackColor = Color.FromArgb(0, 57, 72);
		pen_0 = new Pen(Color.FromArgb(35, 35, 35));
		pen_1 = new Pen(Color.FromArgb(60, 60, 60));
		solidBrush_2 = new SolidBrush(Color.FromArgb(50, 50, 50));
	}

	protected override void ColorHook()
	{
		color_1 = method_10("top");
		color_2 = method_10("bottom");
		color_3 = method_10("top2");
		color_4 = method_10("bottom2");
	}

	private GraphicsPath method_73()
	{
		GraphicsPath graphicsPath = new GraphicsPath();
		List<Point> list = new List<Point>();
		Point item = new Point(0, 2);
		list.Add(item);
		item = new Point(2, 0);
		list.Add(item);
		item = new Point(100, 0);
		list.Add(item);
		item = new Point(115, 15);
		list.Add(item);
		checked
		{
			item = new Point(Width - 1 - 115, 15);
			list.Add(item);
			item = new Point(Width - 1 - 100, 0);
			list.Add(item);
			item = new Point(Width - 2, 0);
			list.Add(item);
			item = new Point(Width - 1, 3);
			list.Add(item);
			item = new Point(Width - 1, Height - 3);
			list.Add(item);
			item = new Point(Width - 3, Height - 1);
			list.Add(item);
			item = new Point(Width - 100, Height - 1);
			list.Add(item);
			item = new Point(Width - 115, Height - 15 - 1);
			list.Add(item);
			item = new Point(116, Height - 15 - 1);
			list.Add(item);
			item = new Point(101, Height - 1);
			list.Add(item);
			item = new Point(2, Height - 1);
			list.Add(item);
			item = new Point(0, Height - 2);
			list.Add(item);
			graphicsPath.AddPolygon(list.ToArray());
			return graphicsPath;
		}
	}

	protected override void PaintHook()
	{
		Color_0 = Color.Fuchsia;
		graphics_0.Clear(Color.Fuchsia);
		HatchBrush brush = new HatchBrush(HatchStyle.Trellis, Color.FromArgb(50, Color.FromArgb(38, 138, 201)), Color.FromArgb(80, Color.FromArgb(12, 40, 57)));
		Rectangle rect = new Rectangle(0, 0, Width, Height);
		LinearGradientBrush brush2 = new LinearGradientBrush(rect, Color.FromArgb(108, 137, 184), Color.FromArgb(13, 20, 25), 20f);
		Graphics graphics = graphics_0;
		checked
		{
			rect = new Rectangle(3, 3, Width - 5, Height - 3);
			graphics.FillRectangle(brush2, rect);
			Graphics graphics2 = graphics_0;
			rect = new Rectangle(3, 3, Width - 5, Height - 3);
			graphics2.FillRectangle(brush, rect);
			graphics_0.DrawLine(Pens.Fuchsia, 1, 0, Width - 1, 0);
			graphics_0.DrawLine(Pens.Fuchsia, 1, 1, Width - 1, 1);
			graphics_0.DrawLine(new Pen(Color.FromArgb(26, 47, 59)), 1, 2, Width - 1, 2);
			graphics_0.DrawLine(Pens.Fuchsia, 1, Height - 1, Width - 1, Height - 1);
			graphics_0.DrawLine(Pens.Fuchsia, 1, Height - 2, Width - 1, Height - 2);
			graphics_0.DrawLine(new Pen(Color.FromArgb(26, 47, 59)), 1, Height - 2, Width - 4, Height - 2);
			GraphicsPath graphicsPath = method_73();
			PathGradientBrush pathGradientBrush = new PathGradientBrush(graphicsPath);
			pathGradientBrush.CenterColor = Color.FromArgb(250, 250, 250);
			pathGradientBrush.SurroundColors = new Color[1] { Color.FromArgb(237, 237, 237) };
			PointF pointF2 = (pathGradientBrush.FocusScales = new PointF(0.9f, 0.5f));
			graphics_0.SetClip(graphicsPath);
			graphics_0.FillPath(pathGradientBrush, graphicsPath);
			graphics_0.DrawPath(new Pen(Color.White, 3f), graphicsPath);
			graphics_0.ResetClip();
			GraphicsPath path = method_73();
			graphics_0.DrawPath(Pens.Gray, path);
			rect = new Rectangle(0, 0, Width - 1, Height - 1);
			new LinearGradientBrush(rect, Color.FromArgb(13, 59, 85), Color.FromArgb(22, 35, 43), 180f);
			GraphicsPath graphicsPath2 = new GraphicsPath();
			PathGradientBrush pathGradientBrush2 = new PathGradientBrush(graphicsPath);
			pathGradientBrush2.CenterColor = Color.FromArgb(39, 60, 73);
			pathGradientBrush2.SurroundColors = new Color[1] { Color.FromArgb(31, 105, 152) };
			pointF2 = (pathGradientBrush2.FocusScales = new PointF(0.5f, 0.5f));
			Point point = new Point((int)Math.Round((double)Width / 2.0), 10);
			pathGradientBrush2.CenterPoint = point;
			rect = new Rectangle(0, 39, Width - 1, 20);
			graphicsPath2.AddRectangle(rect);
			graphics_0.FillPath(pathGradientBrush2, graphicsPath2);
			graphics_0.FillPath(new HatchBrush(HatchStyle.NarrowHorizontal, Color.FromArgb(20, 34, 45), Color.Transparent), graphicsPath2);
			Graphics graphics3 = graphics_0;
			Pen fuchsia = Pens.Fuchsia;
			rect = new Rectangle(Width - 4, 40, 3, 17);
			graphics3.DrawRectangle(fuchsia, rect);
			Graphics graphics4 = graphics_0;
			Brush fuchsia2 = Brushes.Fuchsia;
			rect = new Rectangle(Width - 4, 40, 3, 17);
			graphics4.FillRectangle(fuchsia2, rect);
			Graphics graphics5 = graphics_0;
			Pen fuchsia3 = Pens.Fuchsia;
			rect = new Rectangle(0, 40, 3, 17);
			graphics5.DrawRectangle(fuchsia3, rect);
			Graphics graphics6 = graphics_0;
			Brush fuchsia4 = Brushes.Fuchsia;
			rect = new Rectangle(0, 40, 3, 17);
			graphics6.FillRectangle(fuchsia4, rect);
			method_43(new SolidBrush(Color.FromArgb(30, Color.Black)), HorizontalAlignment.Left, 12, 6);
			method_43(new SolidBrush(Color.FromArgb(20, Color.Black)), HorizontalAlignment.Left, 11, 5);
			method_43(Brushes.Black, HorizontalAlignment.Left, 10, 4);
		}
	}
}
