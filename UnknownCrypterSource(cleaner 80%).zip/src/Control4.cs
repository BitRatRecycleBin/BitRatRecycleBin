using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

internal class Control4 : ContainerControl
{
	private static List<WeakReference> list_0 = new List<WeakReference>();

	private HorizontalAlignment horizontalAlignment_0;

	public HorizontalAlignment HorizontalAlignment_0
	{
		get
		{
			return horizontalAlignment_0;
		}
		set
		{
			horizontalAlignment_0 = value;
			Invalidate();
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	public Control4()
	{
		smethod_0(this);
		SetStyle(ControlStyles.ContainerControl | ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		Size size2 = (Size = new Size(300, 140));
		BackColor = Color.FromArgb(70, 70, 70);
		ForeColor = Color.WhiteSmoke;
		Font = new Font("Segoe UI", 9f);
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		base.OnPaint(e);
		Graphics graphics = e.Graphics;
		graphics.SmoothingMode = SmoothingMode.HighQuality;
		graphics.Clear(Parent.BackColor);
		checked
		{
			Rectangle rectangle_ = new Rectangle(0, 0, Width - 1, Height - 1);
			GraphicsPath path = Class7.smethod_0(rectangle_, 6);
			graphics.FillPath(new SolidBrush(BackColor), path);
			Rectangle rectangle = new Rectangle(0, 0, Width - 1, 26);
			GraphicsPath path2 = Class7.smethod_1(rectangle, 6);
			LinearGradientBrush brush = new LinearGradientBrush(rectangle, Color.FromArgb(100, 100, 100), BackColor, 90f);
			graphics.FillPath(brush, path2);
			int num = ((horizontalAlignment_0 == HorizontalAlignment.Left) ? 5 : ((horizontalAlignment_0 != HorizontalAlignment.Center) ? ((int)Math.Round((float)(Width - 5) - graphics.MeasureString(Text, Font).Width - 1f)) : ((int)Math.Round((double)(Width - 1) / 2.0 - (double)(graphics.MeasureString(Text, Font).Width / 2f)))));
			string s = Text;
			Font font = Font;
			SolidBrush brush2 = new SolidBrush(ForeColor);
			Point point = new Point(num, 5);
			graphics.DrawString(s, font, brush2, point);
			graphics.DrawPath(Pens.Black, path);
			Pen black = Pens.Black;
			point = new Point(0, 26);
			Point pt = point;
			Point pt2 = new Point(Width - 1, 26);
			graphics.DrawLine(black, pt, pt2);
		}
	}

	protected override void OnMouseDown(MouseEventArgs e)
	{
		base.OnMouseDown(e);
		Focus();
	}
}
