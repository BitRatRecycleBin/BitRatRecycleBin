using System.Drawing;
using System.Windows.Forms;

internal class Control10 : Control8
{
	public Control10()
	{
		Boolean_7 = true;
		Boolean_4 = true;
		BackColor = Color.Transparent;
		Int32_2 = 20;
	}

	protected override void ColorHook()
	{
	}

	protected override void PaintHook()
	{
		graphics_0.Clear(Color.FromArgb(51, 51, 51));
		method_57(Color.FromArgb(51, 51, 51), Color.FromArgb(0, 0, 0), 0, 0, Width, 20);
		graphics_0.DrawLine(new Pen(Color.FromArgb(92, 92, 92)), 0, 21, Width, 21);
		graphics_0.DrawLine(Pens.Black, 0, 20, Width, 20);
		method_40(Pens.Black);
		method_43(Brushes.White, HorizontalAlignment.Center, 8, 3);
		method_37(new Pen(Color.FromArgb(92, 92, 92)), 1);
	}
}
