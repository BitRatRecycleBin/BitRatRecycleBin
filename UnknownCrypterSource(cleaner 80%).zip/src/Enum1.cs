internal enum Enum1 : byte
{
	None,
	Over,
	Down,
	Block
}
