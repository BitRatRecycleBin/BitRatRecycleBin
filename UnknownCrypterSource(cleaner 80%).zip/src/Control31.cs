using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

[DefaultEvent("CheckedChanged")]
internal class Control31 : Control
{
	public delegate void Delegate11(object sender);

	private static List<WeakReference> list_0 = new List<WeakReference>();

	private Delegate11 delegate11_0;

	protected Enum1 enum1_0;

	private bool bool_0;

	private GraphicsPath graphicsPath_0;

	private GraphicsPath graphicsPath_1;

	private GraphicsPath graphicsPath_2;

	private GraphicsPath graphicsPath_3;

	private Pen pen_0;

	private Pen pen_1;

	private Pen pen_2;

	private SolidBrush solidBrush_0;

	private SolidBrush solidBrush_1;

	private SolidBrush solidBrush_2;

	private SolidBrush solidBrush_3;

	private SolidBrush solidBrush_4;

	private PathGradientBrush pathGradientBrush_0;

	private LinearGradientBrush linearGradientBrush_0;

	private Rectangle rectangle_0;

	private Rectangle rectangle_1;

	private Rectangle rectangle_2;

	private StringFormat stringFormat_0;

	private StringFormat stringFormat_1;

	private int int_0;

	public bool Boolean_0
	{
		get
		{
			return bool_0;
		}
		set
		{
			bool_0 = value;
			delegate11_0?.Invoke(this);
			Invalidate();
		}
	}

	public event Delegate11 Event_0
	{
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		add
		{
			delegate11_0 = (Delegate11)Delegate.Combine(delegate11_0, value);
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		remove
		{
			delegate11_0 = (Delegate11)Delegate.Remove(delegate11_0, value);
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	public Control31()
	{
		smethod_0(this);
		SetStyle(ControlStyles.UserPaint | ControlStyles.Opaque | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		SetStyle(ControlStyles.Selectable, value: false);
		pen_0 = new Pen(Color.FromArgb(55, 55, 55));
		pen_1 = new Pen(Color.FromArgb(35, 35, 35));
		pen_2 = new Pen(Color.FromArgb(65, 65, 65));
		solidBrush_0 = new SolidBrush(Color.FromArgb(35, 35, 35));
		solidBrush_1 = new SolidBrush(Color.FromArgb(85, 85, 85));
		solidBrush_2 = new SolidBrush(Color.FromArgb(65, 65, 65));
		solidBrush_3 = new SolidBrush(Color.FromArgb(205, 150, 0));
		solidBrush_4 = new SolidBrush(Color.FromArgb(40, 40, 40));
		stringFormat_0 = new StringFormat();
		stringFormat_0.LineAlignment = StringAlignment.Center;
		stringFormat_0.Alignment = StringAlignment.Near;
		stringFormat_1 = new StringFormat();
		stringFormat_1.LineAlignment = StringAlignment.Center;
		stringFormat_1.Alignment = StringAlignment.Far;
		Size size2 = (Size = new Size(56, 24));
		MinimumSize = Size;
		MaximumSize = Size;
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Graphics graphics = e.Graphics;
		graphics.Clear(Color.White);
		graphics.SmoothingMode = SmoothingMode.AntiAlias;
		checked
		{
			Rectangle rectangle_ = new Rectangle(0, 0, Width - 1, Height - 1);
			graphicsPath_0 = method_0(rectangle_, 7);
			rectangle_ = new Rectangle(1, 1, Width - 3, Height - 3);
			graphicsPath_1 = method_0(rectangle_, 7);
			pathGradientBrush_0 = new PathGradientBrush(graphicsPath_0);
			pathGradientBrush_0.CenterColor = Color.FromArgb(250, 250, 250);
			pathGradientBrush_0.SurroundColors = new Color[1] { Color.FromArgb(245, 245, 245) };
			PointF pointF2 = (pathGradientBrush_0.FocusScales = new PointF(0.3f, 0.3f));
			graphics.FillPath(pathGradientBrush_0, graphicsPath_0);
			graphics.DrawPath(Pens.LightGray, graphicsPath_0);
			graphics.DrawPath(Pens.White, graphicsPath_1);
			ref Rectangle reference = ref rectangle_0;
			reference = new Rectangle(5, 0, Width - 10, Height + 2);
			ref Rectangle reference2 = ref rectangle_1;
			reference2 = new Rectangle(6, 1, Width - 10, Height + 2);
			ref Rectangle reference3 = ref rectangle_2;
			reference3 = new Rectangle(1, 1, unchecked(Width / 2) - 1, Height - 3);
			if (bool_0)
			{
				graphics.DrawString("On", Font, new SolidBrush(Color.FromArgb(1, 75, 124)), rectangle_0, stringFormat_0);
				rectangle_2.X += unchecked(Width / 2) - 1;
			}
			else
			{
				graphics.DrawString("Off", Font, new SolidBrush(Color.FromArgb(1, 75, 124)), rectangle_0, stringFormat_1);
			}
			graphicsPath_2 = method_0(rectangle_2, 7);
			rectangle_ = new Rectangle(rectangle_2.X + 1, rectangle_2.Y + 1, rectangle_2.Width - 2, rectangle_2.Height - 2);
			graphicsPath_3 = method_0(rectangle_, 7);
			linearGradientBrush_0 = new LinearGradientBrush(ClientRectangle, Color.FromArgb(255, 255, 255), Color.FromArgb(245, 245, 245), 90f);
			graphics.FillPath(linearGradientBrush_0, graphicsPath_2);
			graphics.DrawPath(Pens.LightGray, graphicsPath_2);
			graphics.DrawPath(Pens.White, graphicsPath_3);
			int_0 = rectangle_2.X + unchecked(rectangle_2.Width / 2) - 3;
			int num = 0;
			do
			{
				if (bool_0)
				{
				}
				graphics.SmoothingMode = SmoothingMode.None;
				if (bool_0)
				{
					graphics.SmoothingMode = SmoothingMode.HighQuality;
					GraphicsPath graphicsPath = new GraphicsPath();
					rectangle_ = new Rectangle(Width - 20, Height - 17, 10, 10);
					graphicsPath.AddEllipse(rectangle_);
					PathGradientBrush pathGradientBrush = new PathGradientBrush(graphicsPath);
					Point point = new Point((int)Math.Round((double)Height - 18.5), Height - 20);
					pathGradientBrush.CenterPoint = point;
					pathGradientBrush.CenterColor = Color.FromArgb(53, 152, 74);
					pathGradientBrush.SurroundColors = new Color[1] { Color.FromArgb(86, 216, 114) };
					pointF2 = (pathGradientBrush.FocusScales = new PointF(0.9f, 0.9f));
					graphics.FillPath(pathGradientBrush, graphicsPath);
					graphics.DrawPath(new Pen(Color.FromArgb(85, 200, 109)), graphicsPath);
					graphics.SetClip(graphicsPath);
					SolidBrush brush = new SolidBrush(Color.FromArgb(40, Color.WhiteSmoke));
					rectangle_ = new Rectangle(Width - 20, Height - 18, 6, 6);
					graphics.FillEllipse(brush, rectangle_);
					graphics.ResetClip();
				}
				else
				{
					graphics.SmoothingMode = SmoothingMode.HighQuality;
					GraphicsPath graphicsPath2 = new GraphicsPath();
					rectangle_ = new Rectangle(Height - 15, Height - 17, 10, 10);
					graphicsPath2.AddEllipse(rectangle_);
					PathGradientBrush pathGradientBrush2 = new PathGradientBrush(graphicsPath2);
					Point point = new Point((int)Math.Round((double)Height - 18.5), Height - 20);
					pathGradientBrush2.CenterPoint = point;
					pathGradientBrush2.CenterColor = Color.FromArgb(185, 65, 65);
					pathGradientBrush2.SurroundColors = new Color[1] { Color.Red };
					pointF2 = (pathGradientBrush2.FocusScales = new PointF(0.9f, 0.9f));
					graphics.FillPath(pathGradientBrush2, graphicsPath2);
					graphics.DrawPath(new Pen(Color.FromArgb(152, 53, 53)), graphicsPath2);
					graphics.SetClip(graphicsPath2);
					SolidBrush brush2 = new SolidBrush(Color.FromArgb(40, Color.WhiteSmoke));
					rectangle_ = new Rectangle(Height - 16, Height - 18, 6, 6);
					graphics.FillEllipse(brush2, rectangle_);
					graphics.ResetClip();
				}
				graphics.SmoothingMode = SmoothingMode.AntiAlias;
				num++;
			}
			while (num <= 1);
		}
	}

	public GraphicsPath method_0(Rectangle rectangle_3, int int_1)
	{
		GraphicsPath graphicsPath = new GraphicsPath();
		checked
		{
			int num = int_1 * 2;
			Rectangle rect = new Rectangle(rectangle_3.X, rectangle_3.Y, num, num);
			graphicsPath.AddArc(rect, -180f, 90f);
			rect = new Rectangle(rectangle_3.Width - num + rectangle_3.X, rectangle_3.Y, num, num);
			graphicsPath.AddArc(rect, -90f, 90f);
			rect = new Rectangle(rectangle_3.Width - num + rectangle_3.X, rectangle_3.Height - num + rectangle_3.Y, num, num);
			graphicsPath.AddArc(rect, 0f, 90f);
			rect = new Rectangle(rectangle_3.X, rectangle_3.Height - num + rectangle_3.Y, num, num);
			graphicsPath.AddArc(rect, 90f, 90f);
			Point pt = new Point(rectangle_3.X, rectangle_3.Height - num + rectangle_3.Y);
			Point pt2 = new Point(rectangle_3.X, int_1 + rectangle_3.Y);
			graphicsPath.AddLine(pt, pt2);
			return graphicsPath;
		}
	}

	protected override void OnMouseDown(MouseEventArgs e)
	{
		Boolean_0 = !Boolean_0;
		base.OnMouseDown(e);
	}
}
