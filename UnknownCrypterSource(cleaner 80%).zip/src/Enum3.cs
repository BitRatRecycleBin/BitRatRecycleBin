internal enum Enum3 : byte
{
	None,
	Over,
	Down,
	Block
}
