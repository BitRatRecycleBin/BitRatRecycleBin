using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

public class GControl26 : Control
{
	public class GClass4
	{
		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private string string_0;

		public string String_0
		{
			[DebuggerNonUserCode]
			get
			{
				return string_0;
			}
			[DebuggerNonUserCode]
			set
			{
				string_0 = value;
			}
		}

		[DebuggerNonUserCode]
		public GClass4()
		{
		}

		public override string ToString()
		{
			return String_0;
		}
	}

	private static List<WeakReference> list_0 = new List<WeakReference>();

	private List<GClass4> list_1;

	private readonly List<GClass4> list_2;

	private bool bool_0;

	private int int_0;

	private GControl24 gcontrol24_0;

	private Color color_0;

	private Color color_1;

	private Color color_2;

	private Color color_3;

	private Color color_4;

	private int int_1;

	private int int_2;

	private bool bool_1;

	private bool bool_2;

	[Category("Colours")]
	public Color Color_0
	{
		get
		{
			return color_4;
		}
		set
		{
			color_4 = value;
		}
	}

	[Category("Colours")]
	public Color Color_1
	{
		get
		{
			return color_0;
		}
		set
		{
			color_0 = value;
		}
	}

	[Category("Colours")]
	public Color Color_2
	{
		get
		{
			return color_2;
		}
		set
		{
			color_2 = value;
		}
	}

	[Category("Colours")]
	public Color Color_3
	{
		get
		{
			return color_1;
		}
		set
		{
			color_1 = value;
		}
	}

	[Category("Colours")]
	public Color Color_4
	{
		get
		{
			return color_3;
		}
		set
		{
			color_3 = value;
		}
	}

	[Category("Control")]
	public int Int32_0 => int_2;

	[Category("Control")]
	public int Int32_1 => int_1;

	[Category("Control")]
	public bool Boolean_0
	{
		get
		{
			return bool_1;
		}
		set
		{
			bool_1 = value;
			Invalidate();
		}
	}

	[Category("Control")]
	public bool Boolean_1
	{
		get
		{
			return bool_2;
		}
		set
		{
			bool_2 = value;
			Invalidate();
		}
	}

	[Category("Control")]
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
	public GClass4[] GClass4_0
	{
		get
		{
			return list_1.ToArray();
		}
		set
		{
			list_1 = new List<GClass4>(value);
			Invalidate();
			method_1();
		}
	}

	[Category("Control")]
	public GClass4[] GClass4_1 => list_2.ToArray();

	[Category("Control")]
	public bool Boolean_2
	{
		get
		{
			return bool_0;
		}
		set
		{
			bool_0 = value;
			if (list_2.Count > 1)
			{
				list_2.RemoveRange(1, checked(list_2.Count - 1));
			}
			Invalidate();
		}
	}

	public override Font Font
	{
		get
		{
			return base.Font;
		}
		set
		{
			int_0 = checked((int)Math.Round(Graphics.FromHwnd(Handle).MeasureString("@", Font).Height));
			if (gcontrol24_0 != null)
			{
				gcontrol24_0.int_3 = 1;
				gcontrol24_0.int_5 = 1;
			}
			base.Font = value;
			method_2();
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	private void method_0(object object_0)
	{
		Invalidate();
	}

	private void method_1()
	{
		checked
		{
			if ((double)(int)Math.Round(Math.Round((double)(list_1.Count * int_0) / (double)int_2)) < (double)(list_1.Count * int_0) / (double)int_2)
			{
				gcontrol24_0.int_1 = (int)Math.Round(Math.Ceiling((double)(list_1.Count * int_0) / (double)int_2));
			}
			else if ((int)Math.Round(Math.Round((double)(list_1.Count * int_0) / (double)int_2)) == 0)
			{
				gcontrol24_0.int_1 = 1;
			}
			else
			{
				gcontrol24_0.int_1 = (int)Math.Round(Math.Round((double)(list_1.Count * int_0) / (double)int_2));
			}
			Invalidate();
		}
	}

	private void method_2()
	{
		checked
		{
			Point point2 = (gcontrol24_0.Location = new Point(Width - gcontrol24_0.Width - 2, 2));
			Size size2 = (gcontrol24_0.Size = new Size(18, Height - 4));
			Invalidate();
		}
	}

	public void method_3(string string_0)
	{
		GClass4 gClass = new GClass4();
		gClass.String_0 = string_0;
		list_1.Add(gClass);
		Invalidate();
		method_1();
	}

	public void method_4(string[] string_0)
	{
		foreach (string string_ in string_0)
		{
			GClass4 gClass = new GClass4();
			gClass.String_0 = string_;
			list_1.Add(gClass);
		}
		Invalidate();
		method_1();
	}

	public void method_5(int int_3)
	{
		list_1.RemoveAt(int_3);
		Invalidate();
		method_1();
	}

	public void method_6(GClass4 gclass4_0)
	{
		list_1.Remove(gclass4_0);
		Invalidate();
		method_1();
	}

	public void method_7(GClass4[] gclass4_0)
	{
		foreach (GClass4 item in gclass4_0)
		{
			list_1.Remove(item);
		}
		Invalidate();
		method_1();
	}

	protected override void OnSizeChanged(EventArgs e)
	{
		int_1 = Width;
		int_2 = Height;
		method_1();
		method_2();
		base.OnSizeChanged(e);
	}

	private void gcontrol24_0_MouseDown(object sender, MouseEventArgs e)
	{
		Focus();
	}

	protected override void OnMouseDown(MouseEventArgs e)
	{
		Focus();
		if (e.Button == MouseButtons.Left)
		{
			int num = checked(gcontrol24_0.Int32_2 * (gcontrol24_0.Int32_1 + (Height - int_0)));
			int num2 = checked(e.Y + num) / int_0;
			if (num2 > checked(list_1.Count - 1))
			{
				num2 = -1;
			}
			if (num2 != -1)
			{
				if (Control.ModifierKeys == Keys.Control && bool_0)
				{
					if (list_2.Contains(list_1[num2]))
					{
						list_2.Remove(list_1[num2]);
					}
					else
					{
						list_2.Add(list_1[num2]);
					}
				}
				else
				{
					list_2.Clear();
					list_2.Add(list_1[num2]);
				}
			}
			Invalidate();
		}
		base.OnMouseDown(e);
	}

	protected override void OnMouseWheel(MouseEventArgs e)
	{
		checked
		{
			int num = -(unchecked(checked(e.Delta * SystemInformation.MouseWheelScrollLines) / 120) * 1);
			int int32_ = Math.Max(Math.Min(gcontrol24_0.Int32_2 + num, gcontrol24_0.Int32_1), gcontrol24_0.Int32_0);
			gcontrol24_0.Int32_2 = int32_;
			base.OnMouseWheel(e);
		}
	}

	public GControl26()
	{
		smethod_0(this);
		list_1 = new List<GClass4>();
		list_2 = new List<GClass4>();
		bool_0 = true;
		int_0 = 24;
		color_0 = Color.FromArgb(37, 37, 38);
		color_1 = Color.FromArgb(62, 62, 64);
		color_2 = Color.FromArgb(47, 47, 47);
		color_3 = Color.FromArgb(35, 35, 35);
		color_4 = Color.FromArgb(199, 199, 199);
		int_1 = 1;
		int_2 = 1;
		bool_1 = false;
		bool_2 = true;
		SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.Selectable | ControlStyles.SupportsTransparentBackColor | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		DoubleBuffered = true;
		gcontrol24_0 = new GControl24();
		gcontrol24_0.int_3 = 1;
		gcontrol24_0.int_5 = 1;
		gcontrol24_0.Event_0 += method_0;
		gcontrol24_0.MouseDown += gcontrol24_0_MouseDown;
		Controls.Add(gcontrol24_0);
		method_2();
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Graphics graphics = e.Graphics;
		Graphics graphics2 = graphics;
		graphics2.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
		graphics2.SmoothingMode = SmoothingMode.HighQuality;
		graphics2.PixelOffsetMode = PixelOffsetMode.HighQuality;
		graphics2.Clear(color_0);
		int num = checked(gcontrol24_0.Int32_2 * (gcontrol24_0.Int32_1 + (Height - int_0)));
		int num2 = ((num != 0) ? (num / int_0 / gcontrol24_0.Int32_1) : 0);
		checked
		{
			Math.Min(num2 + unchecked(Height / int_0), list_1.Count - 1);
			if (!bool_1 && !bool_2)
			{
				graphics2.DrawLine(new Pen(color_3, 2f), gcontrol24_0.Location.X - 1, 0, gcontrol24_0.Location.X - 1, Height);
			}
			int num3 = list_1.Count - 1;
			int num4 = num2;
			while (true)
			{
				int num5 = num4;
				int num6 = num3;
				if (num5 > num6)
				{
					break;
				}
				GClass4 gClass = GClass4_0[num4];
				int num7 = num4 * int_0 + 1 - num + (int)Math.Round((double)int_0 / 2.0 - 8.0);
				if (list_2.Contains(gClass))
				{
					Graphics graphics3 = graphics2;
					SolidBrush brush = new SolidBrush(color_2);
					Rectangle rect = new Rectangle(0, num4 * int_0 + 1 - num, Width - 19, int_0 - 1);
					graphics3.FillRectangle(brush, rect);
				}
				else
				{
					Graphics graphics4 = graphics2;
					SolidBrush brush2 = new SolidBrush(color_1);
					Rectangle rect = new Rectangle(0, num4 * int_0 + 1 - num, Width - 19, int_0 - 1);
					graphics4.FillRectangle(brush2, rect);
				}
				graphics2.DrawLine(new Pen(color_3), 0, num4 * int_0 + 1 - num + int_0 - 1, Width - 18, num4 * int_0 + 1 - num + int_0 - 1);
				if (graphics2.MeasureString(gClass.String_0, new Font("Segoe UI", 8f)).Width > (float)(int_1 - 30))
				{
					Graphics graphics5 = graphics2;
					string string_ = gClass.String_0;
					Font font = new Font("Segoe UI", 8f);
					SolidBrush brush3 = new SolidBrush(color_4);
					Rectangle rect = new Rectangle(7, num7, Width - 35, 15);
					graphics5.DrawString(string_, font, brush3, rect);
					Graphics graphics6 = graphics2;
					Font font2 = new Font("Segoe UI", 8f);
					SolidBrush brush4 = new SolidBrush(color_4);
					rect = new Rectangle(Width - 32, num7, 15, 15);
					graphics6.DrawString("...", font2, brush4, rect);
				}
				else
				{
					Graphics graphics7 = graphics2;
					string string_2 = gClass.String_0;
					Font font3 = new Font("Segoe UI", 8f);
					SolidBrush brush5 = new SolidBrush(color_4);
					Rectangle rect = new Rectangle(7, num7, Width - 34, num7 + 10);
					graphics7.DrawString(string_2, font3, brush5, rect);
				}
				graphics2.ResetClip();
				num4++;
			}
			graphics2.DrawRectangle(new Pen(Color.FromArgb(35, 35, 35), 2f), 1, 1, Width - 2, Height - 2);
			graphics2.InterpolationMode = InterpolationMode.HighQualityBicubic;
			if (bool_2)
			{
				graphics2.DrawLine(new Pen(color_3, 2f), gcontrol24_0.Location.X - 1, 0, gcontrol24_0.Location.X - 1, Height);
			}
			graphics2 = null;
		}
	}
}
