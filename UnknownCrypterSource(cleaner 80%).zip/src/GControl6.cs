using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

[DefaultEvent("CheckedChanged")]
public class GControl6 : Control
{
	public delegate void GDelegate3(object sender);

	private static List<WeakReference> list_0 = new List<WeakReference>();

	private Enum2 enum2_0;

	private bool bool_0;

	private GDelegate3 gdelegate3_0;

	public bool Boolean_0
	{
		get
		{
			return bool_0;
		}
		set
		{
			bool_0 = value;
			Invalidate();
		}
	}

	public event GDelegate3 Event_0
	{
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		add
		{
			gdelegate3_0 = (GDelegate3)Delegate.Combine(gdelegate3_0, value);
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		remove
		{
			gdelegate3_0 = (GDelegate3)Delegate.Remove(gdelegate3_0, value);
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	protected override void OnMouseEnter(EventArgs e)
	{
		base.OnMouseEnter(e);
		enum2_0 = Enum2.Over;
		Invalidate();
	}

	protected override void OnMouseDown(MouseEventArgs e)
	{
		base.OnMouseDown(e);
		enum2_0 = Enum2.Down;
		Invalidate();
	}

	protected override void OnMouseLeave(EventArgs e)
	{
		base.OnMouseLeave(e);
		enum2_0 = Enum2.None;
		Invalidate();
	}

	protected override void OnMouseUp(MouseEventArgs e)
	{
		base.OnMouseUp(e);
		enum2_0 = Enum2.Over;
		Invalidate();
	}

	protected override void OnPaintBackground(PaintEventArgs pevent)
	{
	}

	protected override void OnTextChanged(EventArgs e)
	{
		base.OnTextChanged(e);
		Invalidate();
	}

	protected override void OnResize(EventArgs e)
	{
		base.OnResize(e);
		Height = 14;
	}

	protected override void OnClick(EventArgs e)
	{
		bool_0 = !bool_0;
		gdelegate3_0?.Invoke(this);
		base.OnClick(e);
	}

	public GControl6()
	{
		smethod_0(this);
		enum2_0 = Enum2.None;
		BackColor = Color.FromArgb(20, 20, 20);
		ForeColor = Color.White;
		Size size2 = (Size = new Size(145, 16));
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Bitmap bitmap = new Bitmap(Width, Height);
		Graphics graphics = Graphics.FromImage(bitmap);
		new Class18();
		checked
		{
			Rectangle rect = new Rectangle(0, 0, Height - 1, Height - 1);
			graphics.Clear(Color.FromArgb(42, 47, 49));
			LinearGradientBrush linearGradientBrush = new LinearGradientBrush(rect, Color.FromArgb(36, 40, 42), Color.FromArgb(64, 71, 74), 90f);
			graphics.FillRectangle(linearGradientBrush, linearGradientBrush.Rectangle);
			Pen pen = new Pen(Color.FromArgb(42, 47, 49));
			Rectangle rect2 = new Rectangle(1, 1, Height - 3, Height - 3);
			graphics.DrawRectangle(pen, rect2);
			graphics.DrawRectangle(new Pen(Color.FromArgb(102, 108, 112)), rect);
			Point point3;
			if (Boolean_0)
			{
				Rectangle rect3 = new Rectangle((int)Math.Round((double)rect.X + (double)rect.Width / 4.0), (int)Math.Round((double)rect.Y + (double)rect.Height / 4.0), unchecked(rect.Width / 2), unchecked(rect.Height / 2));
				Point[] array = new Point[3];
				ref Point reference = ref array[0];
				Point point = (reference = new Point(rect3.X, rect3.Y + unchecked(rect3.Height / 2)));
				ref Point reference2 = ref array[1];
				Point point2 = (reference2 = new Point(rect3.X + unchecked(rect3.Width / 2), rect3.Y + rect3.Height));
				ref Point reference3 = ref array[2];
				point3 = (reference3 = new Point(rect3.X + rect3.Width, rect3.Y));
				Point[] array2 = array;
				graphics.SmoothingMode = SmoothingMode.HighQuality;
				Pen pen2 = new Pen(Color.FromArgb(250, 255, 255, 255), 2f);
				new LinearGradientBrush(rect3, Color.FromArgb(200, 200, 200), Color.FromArgb(255, 255, 255), 0f);
				int num = array2.Length - 2;
				int num2 = 0;
				while (true)
				{
					int num3 = num2;
					int num4 = num;
					if (num3 > num4)
					{
						break;
					}
					graphics.DrawLine(pen2, array2[num2], array2[num2 + 1]);
					num2++;
				}
			}
			string s = Text;
			Font font = Font;
			SolidBrush brush = new SolidBrush(ForeColor);
			point3 = new Point(18, -1);
			graphics.DrawString(s, font, brush, point3, new StringFormat
			{
				Alignment = StringAlignment.Near,
				LineAlignment = StringAlignment.Near
			});
			NewLateBinding.LateCall(e.Graphics, null, "DrawImage", new object[3]
			{
				RuntimeHelpers.GetObjectValue(bitmap.Clone()),
				0,
				0
			}, null, null, null, IgnoreReturn: true);
			graphics.Dispose();
			bitmap.Dispose();
		}
	}
}
