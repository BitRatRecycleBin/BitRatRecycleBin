using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

internal class Control24 : TabControl
{
	private static List<WeakReference> list_0 = new List<WeakReference>();

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	public Control24()
	{
		smethod_0(this);
		SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		DoubleBuffered = true;
		SizeMode = TabSizeMode.Fixed;
		Size size2 = (ItemSize = new Size(30, 120));
	}

	protected override void CreateHandle()
	{
		base.CreateHandle();
		Alignment = TabAlignment.Left;
	}

	public GraphicsPath method_0()
	{
		GraphicsPath graphicsPath = new GraphicsPath();
		List<Point> list = new List<Point>();
		Point item = new Point(0, 0);
		list.Add(item);
		checked
		{
			item = new Point(Width - 1, 0);
			list.Add(item);
			item = new Point(Width - 1, Height - 1);
			list.Add(item);
			item = new Point(0, Height - 1);
			list.Add(item);
			graphicsPath.AddPolygon(list.ToArray());
			return graphicsPath;
		}
	}

	public GraphicsPath method_1()
	{
		GraphicsPath graphicsPath = new GraphicsPath();
		List<Point> list = new List<Point>();
		Point item = new Point(1, 1);
		list.Add(item);
		item = new Point(122, 1);
		list.Add(item);
		checked
		{
			item = new Point(122, Height - 2);
			list.Add(item);
			item = new Point(1, Height - 2);
			list.Add(item);
			graphicsPath.AddPolygon(list.ToArray());
			return graphicsPath;
		}
	}

	public GraphicsPath method_2()
	{
		GraphicsPath graphicsPath = new GraphicsPath();
		List<Point> list = new List<Point>();
		Point item = new Point(50, 1);
		list.Add(item);
		item = new Point(349, 50);
		list.Add(item);
		item = new Point(349, 50);
		list.Add(item);
		item = new Point(50, 349);
		list.Add(item);
		graphicsPath.AddPolygon(list.ToArray());
		return graphicsPath;
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Bitmap bitmap = new Bitmap(Width, Height);
		Graphics graphics = Graphics.FromImage(bitmap);
		graphics.Clear(Color.White);
		GraphicsPath path = method_0();
		graphics.DrawPath(Pens.LightGray, path);
		GraphicsPath path2 = method_1();
		PathGradientBrush pathGradientBrush = new PathGradientBrush(path2);
		pathGradientBrush.CenterColor = Color.FromArgb(250, 250, 250);
		pathGradientBrush.SurroundColors = new Color[1] { Color.FromArgb(237, 237, 237) };
		PointF pointF2 = (pathGradientBrush.FocusScales = new PointF(0.9f, 0.9f));
		graphics.FillPath(pathGradientBrush, path2);
		graphics.DrawPath(Pens.Gray, path2);
		checked
		{
			int num = TabCount - 1;
			int num2 = 0;
			while (true)
			{
				int num3 = num2;
				int num4 = num;
				if (num3 > num4)
				{
					break;
				}
				Rectangle tabRect = GetTabRect(num2);
				Rectangle rect = tabRect;
				rect.Width -= 3;
				rect.Height -= 3;
				rect.Y++;
				rect.X++;
				if (num2 == SelectedIndex)
				{
					Rectangle rect2 = new Rectangle(rect.X + 108, rect.Y + 1, 10, rect.Height - 1);
					LinearGradientBrush brush = new LinearGradientBrush(rect2, Color.FromArgb(227, 227, 227), Color.Transparent, 180f);
					rect2 = new Rectangle(rect.X, rect.Y + 1, 10, rect.Height - 1);
					LinearGradientBrush brush2 = new LinearGradientBrush(rect2, Color.FromArgb(227, 227, 227), Color.Transparent, 180f);
					graphics.FillRectangle(new SolidBrush(Color.FromArgb(242, 242, 242)), rect);
					graphics.DrawRectangle(Pens.White, rect);
					graphics.DrawRectangle(new Pen(Color.FromArgb(70, Color.FromArgb(39, 93, 127)), 2f), tabRect);
					rect2 = new Rectangle(rect.X + 113, rect.Y + 1, 6, rect.Height - 1);
					graphics.FillRectangle(brush, rect2);
					rect2 = new Rectangle(rect.X, rect.Y + 1, 6, rect.Height - 1);
					graphics.FillRectangle(brush2, rect2);
					graphics.SmoothingMode = SmoothingMode.HighQuality;
					GraphicsPath graphicsPath = new GraphicsPath();
					rect2 = new Rectangle(rect.X + 8, rect.Y + 8, 12, 12);
					graphicsPath.AddEllipse(rect2);
					PathGradientBrush pathGradientBrush2 = new PathGradientBrush(graphicsPath);
					Point point = new Point(rect.X - 10, rect.Y - 10);
					pathGradientBrush2.CenterPoint = point;
					pathGradientBrush2.CenterColor = Color.FromArgb(56, 142, 196);
					pathGradientBrush2.SurroundColors = new Color[1] { Color.FromArgb(64, 106, 140) };
					pointF2 = (pathGradientBrush2.FocusScales = new PointF(0.9f, 0.9f));
					graphics.FillPath(pathGradientBrush2, graphicsPath);
					graphics.DrawPath(new Pen(Color.FromArgb(49, 63, 86)), graphicsPath);
					graphics.SetClip(graphicsPath);
					SolidBrush brush3 = new SolidBrush(Color.FromArgb(40, Color.WhiteSmoke));
					rect2 = new Rectangle((int)Math.Round((double)rect.X + 10.5), rect.Y + 11, 6, 6);
					graphics.FillEllipse(brush3, rect2);
					graphics.ResetClip();
					graphics.SmoothingMode = SmoothingMode.None;
				}
				else
				{
					graphics.SmoothingMode = SmoothingMode.HighQuality;
					Rectangle rect2 = new Rectangle(rect.X + 108, rect.Y + 1, 10, rect.Height - 1);
					LinearGradientBrush brush4 = new LinearGradientBrush(rect2, Color.FromArgb(227, 227, 227), Color.Transparent, 180f);
					rect2 = new Rectangle(rect.X, rect.Y + 1, 10, rect.Height - 1);
					LinearGradientBrush brush5 = new LinearGradientBrush(rect2, Color.FromArgb(227, 227, 227), Color.Transparent, 180f);
					graphics.FillRectangle(new SolidBrush(Color.FromArgb(242, 242, 242)), rect);
					graphics.DrawRectangle(Pens.White, rect);
					graphics.DrawRectangle(new Pen(Color.FromArgb(70, Color.FromArgb(39, 93, 127)), 2f), tabRect);
					rect2 = new Rectangle(rect.X + 113, rect.Y + 1, 6, rect.Height - 1);
					graphics.FillRectangle(brush4, rect2);
					rect2 = new Rectangle(rect.X, rect.Y + 1, 6, rect.Height - 1);
					graphics.FillRectangle(brush5, rect2);
					Brush lightGray = Brushes.LightGray;
					rect2 = new Rectangle(rect.X + 8, rect.Y + 8, 12, 12);
					graphics.FillEllipse(lightGray, rect2);
					Pen pen = new Pen(Color.FromArgb(100, 100, 100), 1f);
					rect2 = new Rectangle(rect.X + 8, rect.Y + 8, 12, 12);
					graphics.DrawEllipse(pen, rect2);
					graphics.SmoothingMode = SmoothingMode.None;
				}
				graphics.DrawString(TabPages[num2].Text, Font, new SolidBrush(Color.FromArgb(56, 106, 137)), tabRect, new StringFormat
				{
					Alignment = StringAlignment.Center,
					LineAlignment = StringAlignment.Center
				});
				num2++;
			}
			NewLateBinding.LateCall(e.Graphics, null, "DrawImage", new object[3]
			{
				RuntimeHelpers.GetObjectValue(bitmap.Clone()),
				0,
				0
			}, null, null, null, IgnoreReturn: true);
			graphics.Dispose();
			bitmap.Dispose();
			base.OnPaint(e);
		}
	}
}
