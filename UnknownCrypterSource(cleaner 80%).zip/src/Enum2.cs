internal enum Enum2 : byte
{
	None,
	Over,
	Down,
	Block
}
