using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Xml.Linq;

[DebuggerNonUserCode]
[CompilerGenerated]
[EditorBrowsable(EditorBrowsableState.Never)]
internal sealed class Class3
{
	[EditorBrowsable(EditorBrowsableState.Never)]
	[CompilerGenerated]
	[DebuggerNonUserCode]
	private sealed class Class4
	{
		private readonly string[] string_0;

		private readonly XNamespace[] xnamespace_0;

		private readonly List<XAttribute> list_0;

		[EditorBrowsable(EditorBrowsableState.Never)]
		internal Class4(string[] inScopePrefixes, XNamespace[] inScopeNs, List<XAttribute> attributes)
		{
			string_0 = inScopePrefixes;
			xnamespace_0 = inScopeNs;
			list_0 = attributes;
		}

		[EditorBrowsable(EditorBrowsableState.Never)]
		internal XElement method_0(XElement xelement_0)
		{
			return smethod_4(string_0, xnamespace_0, list_0, xelement_0);
		}

		[EditorBrowsable(EditorBrowsableState.Never)]
		internal object method_1(object object_0)
		{
			XElement xElement = object_0 as XElement;
			if (xElement != null)
			{
				return smethod_4(string_0, xnamespace_0, list_0, xElement);
			}
			return object_0;
		}
	}

	public static string this[IEnumerable<XElement> ienumerable_0]
	{
		get
		{
			using (IEnumerator<XElement> enumerator = ienumerable_0.GetEnumerator())
			{
				if (enumerator.MoveNext())
				{
					XElement current = enumerator.Current;
					return current.Value;
				}
			}
			return null;
		}
		set
		{
			using IEnumerator<XElement> enumerator = ienumerable_0.GetEnumerator();
			if (enumerator.MoveNext())
			{
				XElement current = enumerator.Current;
				current.Value = value;
			}
		}
	}

	public static string this[IEnumerable<XElement> ienumerable_0, XName xname_0]
	{
		get
		{
			using (IEnumerator<XElement> enumerator = ienumerable_0.GetEnumerator())
			{
				if (enumerator.MoveNext())
				{
					XElement current = enumerator.Current;
					return (string)current.Attribute(xname_0);
				}
			}
			return null;
		}
		set
		{
			using IEnumerator<XElement> enumerator = ienumerable_0.GetEnumerator();
			if (enumerator.MoveNext())
			{
				XElement current = enumerator.Current;
				current.SetAttributeValue(xname_0, value);
			}
		}
	}

	public static string AttributeValue
	{
		get
		{
			return (string)xelement_0.Attribute(xname_0);
		}
		set
		{
			xelement_0.SetAttributeValue(xname_0, value);
		}
	}

	[EditorBrowsable(EditorBrowsableState.Never)]
	private Class3()
	{
	}

	[EditorBrowsable(EditorBrowsableState.Never)]
	public static XAttribute smethod_0(XName xname_0, object object_0)
	{
		if (object_0 == null)
		{
			return null;
		}
		return new XAttribute(xname_0, RuntimeHelpers.GetObjectValue(object_0));
	}

	[EditorBrowsable(EditorBrowsableState.Never)]
	public static XAttribute smethod_1(XName xname_0, XNamespace xnamespace_0)
	{
		XAttribute xAttribute = new XAttribute(xname_0, xnamespace_0.NamespaceName);
		xAttribute.AddAnnotation(xnamespace_0);
		return xAttribute;
	}

	[EditorBrowsable(EditorBrowsableState.Never)]
	public static object smethod_2(string[] string_0, XNamespace[] xnamespace_0, List<XAttribute> list_0, object object_0)
	{
		if (object_0 != null)
		{
			XElement xElement = object_0 as XElement;
			if (xElement != null)
			{
				return smethod_4(string_0, xnamespace_0, list_0, xElement);
			}
			IEnumerable enumerable = object_0 as IEnumerable;
			if (enumerable != null)
			{
				return smethod_3(string_0, xnamespace_0, list_0, enumerable);
			}
		}
		return object_0;
	}

	[EditorBrowsable(EditorBrowsableState.Never)]
	public static IEnumerable smethod_3(string[] string_0, XNamespace[] xnamespace_0, List<XAttribute> list_0, IEnumerable ienumerable_0)
	{
		if (ienumerable_0 != null)
		{
			IEnumerable<XElement> enumerable = ienumerable_0 as IEnumerable<XElement>;
			if (enumerable != null)
			{
				return enumerable.Select(new Class4(string_0, xnamespace_0, list_0).method_0);
			}
			return ienumerable_0.Cast<object>().Select(new Class4(string_0, xnamespace_0, list_0).method_1);
		}
		return ienumerable_0;
	}

	[EditorBrowsable(EditorBrowsableState.Never)]
	public static XElement smethod_4(string[] string_0, XNamespace[] xnamespace_0, List<XAttribute> list_0, XElement xelement_0)
	{
		checked
		{
			if (xelement_0 != null)
			{
				XAttribute xAttribute = xelement_0.FirstAttribute;
				while (xAttribute != null)
				{
					XAttribute nextAttribute = xAttribute.NextAttribute;
					if (xAttribute.IsNamespaceDeclaration)
					{
						XNamespace xNamespace = xAttribute.Annotation<XNamespace>();
						string localName = xAttribute.Name.LocalName;
						if ((object)xNamespace != null)
						{
							if (string_0 != null && xnamespace_0 != null)
							{
								int num = string_0.Length - 1;
								int num2 = num;
								int num3 = 0;
								while (true)
								{
									int num4 = num3;
									int num5 = num2;
									if (num4 > num5)
									{
										break;
									}
									string value = string_0[num3];
									XNamespace xNamespace2 = xnamespace_0[num3];
									if (!localName.Equals(value))
									{
										num3++;
										continue;
									}
									if (xNamespace == xNamespace2)
									{
										xAttribute.Remove();
									}
									xAttribute = null;
									break;
								}
							}
							if (xAttribute != null)
							{
								if (list_0 != null)
								{
									int num6 = list_0.Count - 1;
									int num7 = num6;
									int num8 = 0;
									while (true)
									{
										int num9 = num8;
										int num5 = num7;
										if (num9 > num5)
										{
											break;
										}
										XAttribute xAttribute2 = list_0[num8];
										string localName2 = xAttribute2.Name.LocalName;
										XNamespace xNamespace3 = xAttribute2.Annotation<XNamespace>();
										if ((object)xNamespace3 == null || !localName.Equals(localName2))
										{
											num8++;
											continue;
										}
										if (xNamespace == xNamespace3)
										{
											xAttribute.Remove();
										}
										xAttribute = null;
										break;
									}
								}
								if (xAttribute != null)
								{
									xAttribute.Remove();
									list_0.Add(xAttribute);
								}
							}
						}
					}
					xAttribute = nextAttribute;
				}
			}
			return xelement_0;
		}
	}
}
