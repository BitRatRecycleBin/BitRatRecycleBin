using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

public class GControl11 : Control
{
	private static List<WeakReference> list_0 = new List<WeakReference>();

	[AccessedThroughProperty("txtbox")]
	private TextBox textBox_0;

	private bool bool_0;

	private int int_0;

	private HorizontalAlignment horizontalAlignment_0;

	private bool bool_1;

	private virtual TextBox TextBox_0
	{
		[DebuggerNonUserCode]
		get
		{
			return textBox_0;
		}
		[MethodImpl(MethodImplOptions.Synchronized)]
		[DebuggerNonUserCode]
		set
		{
			EventHandler value2 = delegate
			{
				method_0();
			};
			if (textBox_0 != null)
			{
				textBox_0.TextChanged -= value2;
			}
			textBox_0 = value;
			if (textBox_0 != null)
			{
				textBox_0.TextChanged += value2;
			}
		}
	}

	public bool Boolean_0
	{
		get
		{
			return bool_0;
		}
		set
		{
			TextBox_0.UseSystemPasswordChar = Boolean_0;
			bool_0 = value;
			Invalidate();
		}
	}

	public int Int32_0
	{
		get
		{
			return int_0;
		}
		set
		{
			int_0 = value;
			TextBox_0.MaxLength = Int32_0;
			Invalidate();
		}
	}

	public HorizontalAlignment HorizontalAlignment_0
	{
		get
		{
			return horizontalAlignment_0;
		}
		set
		{
			horizontalAlignment_0 = value;
			Invalidate();
		}
	}

	public bool Boolean_1
	{
		get
		{
			return bool_1;
		}
		set
		{
			bool_1 = value;
			TextBox_0.Multiline = value;
			OnResize(EventArgs.Empty);
			Invalidate();
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	protected override void OnTextChanged(EventArgs e)
	{
		base.OnTextChanged(e);
		Invalidate();
	}

	protected override void OnBackColorChanged(EventArgs e)
	{
		base.OnBackColorChanged(e);
		Invalidate();
	}

	protected override void OnForeColorChanged(EventArgs e)
	{
		base.OnForeColorChanged(e);
		TextBox_0.ForeColor = ForeColor;
		Invalidate();
	}

	protected override void OnFontChanged(EventArgs e)
	{
		base.OnFontChanged(e);
		TextBox_0.Font = Font;
	}

	protected override void OnGotFocus(EventArgs e)
	{
		base.OnGotFocus(e);
		TextBox_0.Focus();
	}

	private void method_0()
	{
		Text = TextBox_0.Text;
	}

	private void method_1()
	{
		TextBox_0.Text = Text;
	}

	public void method_2()
	{
		TextBox textBox = TextBox_0;
		textBox.Multiline = false;
		textBox.BackColor = Color.FromArgb(49, 50, 54);
		textBox.ForeColor = ForeColor;
		textBox.Text = string.Empty;
		textBox.TextAlign = HorizontalAlignment.Center;
		textBox.BorderStyle = BorderStyle.None;
		Point point2 = (textBox.Location = new Point(5, 4));
		textBox.Font = new Font("Arial", 8.25f, FontStyle.Bold);
		Size size2 = (textBox.Size = checked(new Size(Width - 10, Height - 11)));
		textBox.UseSystemPasswordChar = Boolean_0;
		textBox = null;
	}

	public GControl11()
	{
		base.TextChanged += delegate
		{
			method_1();
		};
		smethod_0(this);
		TextBox_0 = new TextBox();
		bool_0 = false;
		int_0 = 32767;
		bool_1 = false;
		method_2();
		Controls.Add(TextBox_0);
		SetStyle(ControlStyles.UserPaint, value: true);
		SetStyle(ControlStyles.SupportsTransparentBackColor, value: true);
		Text = "";
		BackColor = Color.Transparent;
		ForeColor = Color.White;
		Font = new Font("Arial", 8.25f, FontStyle.Bold);
		Size size2 = (Size = new Size(135, 24));
		DoubleBuffered = true;
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Bitmap bitmap = new Bitmap(Width, Height);
		Graphics graphics = Graphics.FromImage(bitmap);
		int num = 4;
		graphics.SmoothingMode = SmoothingMode.HighQuality;
		TextBox textBox = TextBox_0;
		textBox.TextAlign = HorizontalAlignment_0;
		textBox.UseSystemPasswordChar = Boolean_0;
		textBox = null;
		graphics.Clear(Color.Transparent);
		SolidBrush brush = new SolidBrush(Color.FromArgb(49, 50, 54));
		checked
		{
			Rectangle rectangle_ = new Rectangle(0, 0, Width - 1, Height - 1);
			graphics.FillPath(brush, Class19.smethod_0(rectangle_, 4));
			Color[] array = new Color[6]
			{
				Color.FromArgb(43, 44, 48),
				Color.FromArgb(44, 45, 49),
				Color.FromArgb(45, 46, 50),
				Color.FromArgb(46, 47, 51),
				Color.FromArgb(47, 48, 52),
				Color.FromArgb(48, 49, 53)
			};
			int num2 = 0;
			do
			{
				Pen pen = new Pen(array[num2]);
				rectangle_ = new Rectangle(num2 + 1, num2 + 1, Width - (2 * num2 + 3), Height - (2 * num2 + 3));
				graphics.DrawPath(pen, Class19.smethod_0(rectangle_, num));
				num2++;
			}
			while (num2 <= 5);
			rectangle_ = new Rectangle(0, 0, Width - 1, Height - 1);
			LinearGradientBrush brush2 = new LinearGradientBrush(rectangle_, Color.Transparent, Color.FromArgb(87, 88, 92), 90f);
			Pen pen2 = new Pen(brush2);
			rectangle_ = new Rectangle(0, 0, Width - 1, Height - 1);
			graphics.DrawPath(pen2, Class19.smethod_0(rectangle_, num));
			Pen pen3 = new Pen(Color.FromArgb(32, 33, 37));
			rectangle_ = new Rectangle(0, 0, Width - 1, Height - 2);
			graphics.DrawPath(pen3, Class19.smethod_0(rectangle_, num));
			NewLateBinding.LateCall(e.Graphics, null, "DrawImage", new object[3]
			{
				RuntimeHelpers.GetObjectValue(bitmap.Clone()),
				0,
				0
			}, null, null, null, IgnoreReturn: true);
			graphics.Dispose();
			bitmap.Dispose();
		}
	}

	protected override void OnResize(EventArgs e)
	{
		base.OnResize(e);
		checked
		{
			if (!Boolean_1)
			{
				int num = TextBox_0.Height;
				Point point2 = (TextBox_0.Location = new Point(10, (int)Math.Round((double)Height / 2.0 - (double)num / 2.0 - 1.0)));
				Size size2 = (TextBox_0.Size = new Size(Width - 20, num));
			}
			else
			{
				_ = TextBox_0.Height;
				Point point2 = (TextBox_0.Location = new Point(10, 10));
				Size size2 = (TextBox_0.Size = new Size(Width - 20, Height - 20));
			}
		}
	}

	[SpecialName]
	[CompilerGenerated]
	[DebuggerStepThrough]
	private void TextBox_0_TextChanged(object sender, EventArgs e)
	{
		method_0();
	}

	[SpecialName]
	[DebuggerStepThrough]
	[CompilerGenerated]
	private void GControl11_TextChanged(object sender, EventArgs e)
	{
		method_1();
	}
}
