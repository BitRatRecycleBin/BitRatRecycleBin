using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

internal class Control29 : Control
{
	public class Class13
	{
		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private string string_0;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private List<Class14> list_0;

		protected Guid guid_0;

		public string String_0
		{
			[DebuggerNonUserCode]
			get
			{
				return string_0;
			}
			[DebuggerNonUserCode]
			set
			{
				string_0 = value;
			}
		}

		[DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
		public List<Class14> List_0
		{
			[DebuggerNonUserCode]
			get
			{
				return list_0;
			}
			[DebuggerNonUserCode]
			set
			{
				list_0 = value;
			}
		}

		public Class13()
		{
			List<Class14> list2 = (List_0 = new List<Class14>());
			guid_0 = Guid.NewGuid();
		}

		public override string ToString()
		{
			return String_0;
		}

		public override bool Equals(object obj)
		{
			if (obj is Class13)
			{
				return ((Class13)obj).guid_0 == guid_0;
			}
			return false;
		}
	}

	public class Class14
	{
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private string string_0;

		public string String_0
		{
			[DebuggerNonUserCode]
			get
			{
				return string_0;
			}
			[DebuggerNonUserCode]
			set
			{
				string_0 = value;
			}
		}

		[DebuggerNonUserCode]
		public Class14()
		{
		}

		public override string ToString()
		{
			return String_0;
		}
	}

	public class Class15
	{
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private string string_0;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private int int_0;

		public string String_0
		{
			[DebuggerNonUserCode]
			get
			{
				return string_0;
			}
			[DebuggerNonUserCode]
			set
			{
				string_0 = value;
			}
		}

		public int Int32_0
		{
			[DebuggerNonUserCode]
			get
			{
				return int_0;
			}
			[DebuggerNonUserCode]
			set
			{
				int_0 = value;
			}
		}

		public Class15()
		{
			Int32_0 = 60;
		}

		public override string ToString()
		{
			return String_0;
		}
	}

	private static List<WeakReference> list_0 = new List<WeakReference>();

	private List<Class13> list_1;

	private List<Class13> list_2;

	private List<Class15> list_3;

	private bool bool_0;

	private int int_0;

	private Control30 control30_0;

	private int[] int_1;

	private Pen pen_0;

	private Pen pen_1;

	private Pen pen_2;

	private SolidBrush solidBrush_0;

	private SolidBrush solidBrush_1;

	private SolidBrush solidBrush_2;

	private SolidBrush solidBrush_3;

	private LinearGradientBrush linearGradientBrush_0;

	[DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
	public Class13[] Class13_0
	{
		get
		{
			return list_1.ToArray();
		}
		set
		{
			list_1 = new List<Class13>(value);
			method_5();
		}
	}

	public Class13[] Class13_1 => list_2.ToArray();

	[DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
	public Class15[] Class15_0
	{
		get
		{
			return list_3.ToArray();
		}
		set
		{
			list_3 = new List<Class15>(value);
			method_7();
		}
	}

	public bool Boolean_0
	{
		get
		{
			return bool_0;
		}
		set
		{
			bool_0 = value;
			if (list_2.Count > 1)
			{
				list_2.RemoveRange(1, checked(list_2.Count - 1));
			}
			Invalidate();
		}
	}

	public override Font Font
	{
		get
		{
			return base.Font;
		}
		set
		{
			int_0 = checked((int)Math.Round(Graphics.FromHwnd(Handle).MeasureString("@", Font).Height) + 6);
			if (control30_0 != null)
			{
				control30_0.Int32_3 = int_0;
				control30_0.Int32_4 = int_0;
			}
			base.Font = value;
			method_6();
		}
	}

	[DebuggerNonUserCode]
	private static void smethod_0(object object_0)
	{
		checked
		{
			lock (list_0)
			{
				if (list_0.Count == list_0.Capacity)
				{
					int num = 0;
					int num2 = list_0.Count - 1;
					int num3 = 0;
					while (true)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						WeakReference weakReference = list_0[num3];
						if (weakReference.IsAlive)
						{
							if (num3 != num)
							{
								list_0[num] = list_0[num3];
							}
							num++;
						}
						num3++;
					}
					list_0.RemoveRange(num, list_0.Count - num);
					list_0.Capacity = list_0.Count;
				}
				list_0.Add(new WeakReference(RuntimeHelpers.GetObjectValue(object_0)));
			}
		}
	}

	public void method_0(string string_0, params string[] string_1)
	{
		List<Class14> list = new List<Class14>();
		foreach (string string_2 in string_1)
		{
			Class14 @class = new Class14();
			@class.String_0 = string_2;
			list.Add(@class);
		}
		Class13 class2 = new Class13();
		class2.String_0 = string_0;
		class2.List_0 = list;
		list_1.Add(class2);
		method_5();
	}

	public void method_1(int int_2)
	{
		list_1.RemoveAt(int_2);
		method_5();
	}

	public void method_2(Class13 class13_0)
	{
		list_1.Remove(class13_0);
		method_5();
	}

	public void method_3(Class13[] class13_0)
	{
		foreach (Class13 item in class13_0)
		{
			list_1.Remove(item);
		}
		method_5();
	}

	public Control29()
	{
		smethod_0(this);
		list_1 = new List<Class13>();
		list_2 = new List<Class13>();
		list_3 = new List<Class15>();
		bool_0 = true;
		int_0 = 24;
		SetStyle(ControlStyles.UserPaint | ControlStyles.Opaque | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		SetStyle(ControlStyles.Selectable, value: true);
		pen_0 = new Pen(Color.FromArgb(55, 55, 55));
		pen_1 = new Pen(Color.FromArgb(35, 35, 35));
		pen_2 = new Pen(Color.FromArgb(65, 65, 65));
		solidBrush_0 = new SolidBrush(Color.FromArgb(62, 62, 62));
		solidBrush_1 = new SolidBrush(Color.FromArgb(65, 65, 65));
		solidBrush_2 = new SolidBrush(Color.FromArgb(47, 47, 47));
		solidBrush_3 = new SolidBrush(Color.FromArgb(50, 50, 50));
		control30_0 = new Control30();
		control30_0.Int32_3 = int_0;
		control30_0.Int32_4 = int_0;
		control30_0.Event_0 += method_4;
		control30_0.MouseDown += control30_0_MouseDown;
		Controls.Add(control30_0);
		method_6();
	}

	protected override void OnSizeChanged(EventArgs e)
	{
		method_6();
		base.OnSizeChanged(e);
	}

	private void method_4(object object_0)
	{
		Invalidate();
	}

	private void method_5()
	{
		control30_0.Int32_1 = checked(list_1.Count * int_0);
		Invalidate();
	}

	private void method_6()
	{
		checked
		{
			Point point2 = (control30_0.Location = new Point(Width - control30_0.Width - 1, 1));
			Size size2 = (control30_0.Size = new Size(18, Height - 2));
			Invalidate();
		}
	}

	private void method_7()
	{
		int num = 3;
		checked
		{
			int_1 = new int[list_3.Count - 1 + 1];
			int num2 = list_3.Count - 1;
			int num3 = 0;
			while (true)
			{
				int num4 = num3;
				int num5 = num2;
				if (num4 > num5)
				{
					break;
				}
				int_1[num3] = num;
				num += Class15_0[num3].Int32_0;
				num3++;
			}
			Invalidate();
		}
	}

	private void control30_0_MouseDown(object sender, MouseEventArgs e)
	{
		Focus();
	}

	protected override void OnMouseDown(MouseEventArgs e)
	{
		Focus();
		if (e.Button == MouseButtons.Left)
		{
			int num = checked((int)Math.Round(control30_0.Double_1 * (double)(control30_0.Int32_1 - (Height - int_0 * 2))));
			int num2 = checked(e.Y + num - int_0) / int_0;
			if (num2 > checked(list_1.Count - 1))
			{
				num2 = -1;
			}
			if (num2 != -1)
			{
				if (Control.ModifierKeys == Keys.Control && bool_0)
				{
					if (list_2.Contains(list_1[num2]))
					{
						list_2.Remove(list_1[num2]);
					}
					else
					{
						list_2.Add(list_1[num2]);
					}
				}
				else
				{
					list_2.Clear();
					list_2.Add(list_1[num2]);
				}
			}
			Invalidate();
		}
		base.OnMouseDown(e);
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Graphics graphics = e.Graphics;
		graphics = e.Graphics;
		graphics.Clear(Color.White);
		checked
		{
			graphics.DrawRectangle(new Pen(new SolidBrush(Color.FromArgb(50, Color.LightGray))), 1, 1, Width - 3, Height - 3);
			int num = (int)Math.Round(control30_0.Double_1 * (double)(control30_0.Int32_1 - (Height - int_0 * 2)));
			int num2 = ((num != 0) ? unchecked(num / int_0) : 0);
			int num3 = Math.Min(num2 + unchecked(Height / int_0), list_1.Count - 1);
			int num4 = num3;
			int num5 = num2;
			Rectangle rectangle;
			while (true)
			{
				int num6 = num5;
				int num7 = num4;
				if (num6 > num7)
				{
					break;
				}
				Class13 @class = Class13_0[num5];
				rectangle = new Rectangle(0, int_0 + num5 * int_0 + 1 - num, Width, int_0 - 1);
				float num8 = graphics.MeasureString(@class.String_0, Font).Height;
				int num9 = rectangle.Y + (int)Math.Round((double)int_0 / 2.0 - (double)(num8 / 2f));
				unchecked
				{
					if (list_2.Contains(@class))
					{
						if (num5 % 2 == 0)
						{
							graphics.FillRectangle(new SolidBrush(Color.FromArgb(40, Color.LightGray)), rectangle);
						}
						else
						{
							graphics.FillRectangle(new SolidBrush(Color.FromArgb(40, Color.LightGray)), rectangle);
						}
					}
					else if (num5 % 2 == 0)
					{
						graphics.FillRectangle(Brushes.White, rectangle);
					}
					else
					{
						graphics.FillRectangle(Brushes.White, rectangle);
					}
					graphics.DrawLine(Pens.LightGray, 0, rectangle.Bottom, Width, rectangle.Bottom);
					if (Class15_0.Length > 0)
					{
						rectangle.Width = Class15_0[0].Int32_0;
						graphics.SetClip(rectangle);
					}
				}
				graphics.DrawString(@class.String_0, Font, new SolidBrush(Color.FromArgb(1, 75, 124)), 10f, num9 + 1);
				if (@class.List_0 != null)
				{
					int num10 = Math.Min(@class.List_0.Count, list_3.Count) - 1;
					int num11 = 0;
					while (true)
					{
						int num12 = num11;
						num7 = num10;
						if (num12 > num7)
						{
							break;
						}
						int num14 = (rectangle.X = int_1[num11 + 1] + 4);
						rectangle.Width = Class15_0[num11].Int32_0;
						graphics.SetClip(rectangle);
						graphics.DrawString(@class.List_0[num11].String_0, Font, new SolidBrush(Color.FromArgb(1, 75, 124)), num14 + 1, num9 + 1);
						num11++;
					}
				}
				graphics.ResetClip();
				num5++;
			}
			rectangle = new Rectangle(0, 0, Width, int_0);
			linearGradientBrush_0 = new LinearGradientBrush(rectangle, Color.FromArgb(255, 255, 255), Color.FromArgb(245, 245, 245), 90f);
			graphics.FillRectangle(linearGradientBrush_0, rectangle);
			graphics.SetClip(rectangle);
			Graphics graphics2 = graphics;
			Brush white = Brushes.White;
			Rectangle rect = new Rectangle(0, 0, rectangle.Width - 1, (int)Math.Round((double)rectangle.Height / 2.0 - 1.0));
			graphics2.FillRectangle(white, rect);
			graphics.ResetClip();
			graphics.DrawRectangle(Pens.White, 1, 1, Width - 22, int_0 - 2);
			int y = Math.Min(control30_0.Int32_1 + int_0 - num, Height);
			int num15 = list_3.Count - 1;
			int num16 = 0;
			while (true)
			{
				int num17 = num16;
				int num7 = num15;
				if (num17 > num7)
				{
					break;
				}
				Class15 class2 = Class15_0[num16];
				float num8 = graphics.MeasureString(class2.String_0, Font).Height;
				int num9 = (int)Math.Round((double)int_0 / 2.0 - (double)(num8 / 2f));
				int num14 = int_1[num16];
				graphics.DrawString(class2.String_0, Font, new SolidBrush(Color.FromArgb(1, 75, 124)), num14 + 1, num9 + 1);
				graphics.DrawLine(Pens.LightGray, num14 - 3, 0, num14 - 3, y);
				graphics.DrawLine(Pens.White, num14 - 2, 0, num14 - 2, int_0);
				num16++;
			}
			graphics.DrawRectangle(Pens.LightGray, 0, 0, Width - 1, Height - 1);
			graphics.DrawLine(new Pen(new SolidBrush(Color.LightGray)), 0, int_0, Width, int_0);
			graphics.DrawLine(new Pen(Brushes.LightGray), control30_0.Location.X - 1, 0, control30_0.Location.X - 1, Height);
			graphics.FillRectangle(Brushes.White, Width - 19, 0, Width, Height);
		}
	}

	protected override void OnMouseWheel(MouseEventArgs e)
	{
		checked
		{
			int num = -(unchecked(checked(e.Delta * SystemInformation.MouseWheelScrollLines) / 120) * unchecked(int_0 / 2));
			int int32_ = Math.Max(Math.Min(control30_0.Int32_2 + num, control30_0.Int32_1), control30_0.Int32_0);
			control30_0.Int32_2 = int32_;
			base.OnMouseWheel(e);
		}
	}
}
