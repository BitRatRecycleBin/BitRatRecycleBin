﻿using System;

internal sealed class Class93 : Class91
{
    private readonly Interface1 interface1_0;

    public Class93(Interface1 interface1_1)
    {
        this.interface1_0 = interface1_1;
    }

    public override void Dispose()
    {
        this.interface1_0.imethod_15();
    }

    public override bool vmethod_0()
    {
        return true;
    }

    public override int vmethod_1()
    {
        return this.interface1_0.imethod_2();
    }

    public override int vmethod_2(byte[] byte_0, int int_0, int int_1, byte[] byte_1, int int_2)
    {
        return this.interface1_0.imethod_8(byte_0, int_0, int_1, byte_1, int_2);
    }

    public override byte[] vmethod_3(byte[] byte_0, int int_0, int int_1)
    {
        return this.interface1_0.imethod_11(byte_0, int_0, int_1);
    }
}

