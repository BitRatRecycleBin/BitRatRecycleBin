﻿using System;

internal sealed class Class25
{
    private int int_0;
    private int int_1;
    private uint uint_0;
    private uint uint_1;
    private uint uint_2;
    private uint uint_3;

    public int method_0()
    {
        return this.int_0;
    }

    public void method_1(int int_2)
    {
        this.int_0 = int_2;
    }

    public uint method_10()
    {
        return this.uint_3;
    }

    public void method_11(uint uint_4)
    {
        this.uint_3 = uint_4;
    }

    public int method_2()
    {
        return this.int_1;
    }

    public void method_3(int int_2)
    {
        this.int_1 = int_2;
    }

    public uint method_4()
    {
        return this.uint_0;
    }

    public void method_5(uint uint_4)
    {
        this.uint_0 = uint_4;
    }

    public uint method_6()
    {
        return this.uint_1;
    }

    public void method_7(uint uint_4)
    {
        this.uint_1 = uint_4;
    }

    public uint method_8()
    {
        return this.uint_2;
    }

    public void method_9(uint uint_4)
    {
        this.uint_2 = uint_4;
    }
}

