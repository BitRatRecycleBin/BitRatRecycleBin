﻿using System;
using System.IO;

internal static class Class59
{
    private static readonly uint[] uint_0 = new uint[] { 0x31c84b1, 0x95eed, 0x1c39, 0x55, 1 };

    public static byte[] smethod_0(string string_0)
    {
        if (string_0 == null)
        {
            throw new Exception();
        }
        MemoryStream stream = new MemoryStream((string_0.Length * 4) / 5);
        int index = 0;
        uint num2 = 0;
        foreach (char ch in string_0)
        {
            if ((ch == 'z') && (index == 0))
            {
                smethod_1(stream, num2, 0);
            }
            else
            {
                if ((ch < '!') || (ch > 'u'))
                {
                    throw new Exception();
                }
                num2 += (uint) (uint_0[index] * (ch - '!'));
                if ((index + 1) == 5)
                {
                    smethod_1(stream, num2, 0);
                    index = 0;
                    num2 = 0;
                }
            }
        }
        if (index == 1)
        {
            throw new Exception();
        }
        if (index > 1)
        {
            int num4 = index;
            while (true)
            {
                if (num4 >= 5)
                {
                    smethod_1(stream, num2, 5 - index);
                    break;
                }
                num2 += (uint) (0x54 * uint_0[num4]);
                num4++;
            }
        }
        return stream.ToArray();
    }

    private static void smethod_1(Stream stream_0, uint uint_1, int int_0)
    {
        stream_0.WriteByte((byte) (uint_1 >> 0x18));
        if (int_0 != 3)
        {
            stream_0.WriteByte((byte) ((uint_1 >> 0x10) & 0xff));
            if (int_0 != 2)
            {
                stream_0.WriteByte((byte) ((uint_1 >> 8) & 0xff));
                if (int_0 != 1)
                {
                    stream_0.WriteByte((byte) (uint_1 & 0xff));
                }
            }
        }
    }
}

