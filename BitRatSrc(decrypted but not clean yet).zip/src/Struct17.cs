﻿using System;
using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Sequential)]
internal struct Struct17
{
    public int int_0;
    public int int_1;
}

