﻿using System;

internal sealed class Class110 : Class109
{
    private Array array_0;
    private long long_0;

    public Array method_4()
    {
        return this.array_0;
    }

    public void method_5(Array array_1)
    {
        this.array_0 = array_1;
    }

    public long method_6()
    {
        return this.long_0;
    }

    public void method_7(long long_1)
    {
        this.long_0 = long_1;
    }

    public override int vmethod_2()
    {
        return 3;
    }

    public override Class94 vmethod_3(Class94 class94_0)
    {
        base.method_1(class94_0.method_0());
        if (class94_0.vmethod_2() != 3)
        {
            throw new ArgumentOutOfRangeException();
        }
        Class110 class2 = (Class110) class94_0;
        this.method_5(class2.method_4());
        this.method_7(class2.method_6());
        base.method_3(class2.method_2());
        return this;
    }

    public override Class94 vmethod_4()
    {
        Class110 class1 = new Class110();
        class1.method_5(this.array_0);
        class1.method_7(this.long_0);
        class1.method_3(base.method_2());
        class1.method_1(base.method_0());
        return class1;
    }

    public override object vmethod_5()
    {
        return this.array_0.GetValue(this.long_0);
    }

    public override void vmethod_6(object object_0)
    {
        this.array_0.SetValue(object_0, this.long_0);
    }

    public override bool vmethod_7(Class109 class109_0)
    {
        Class110 class2 = (Class110) class109_0;
        return ((this.method_6() == class2.method_6()) && ReferenceEquals(this.method_4(), class2.method_4()));
    }
}

