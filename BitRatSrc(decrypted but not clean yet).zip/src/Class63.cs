﻿using System;
using System.Runtime.InteropServices;
using System.Text;

internal static class Class63
{
    public static Class0 smethod_0(string string_0)
    {
        byte[] buffer = Class65.smethod_5(string_0);
        if (buffer == null)
        {
            return null;
        }
        Class46 class1 = new Class46();
        class1.byte_0 = buffer;
        class1.bool_0 = true;
        class1.bool_1 = true;
        Class0 class2 = new Class0();
        class2.class46_0 = class1;
        return class2;
    }

    public static byte[] smethod_1(string string_0)
    {
        if (string_0 == null)
        {
            return null;
        }
        if (string_0.Length == 0)
        {
            return new byte[0];
        }
        byte[] bytes = Encoding.UTF8.GetBytes(string_0);
        Array.Clear(bytes, 0, bytes.Length);
        return Class27.smethod_0(bytes, Class122.smethod_7(), new Func<byte[]>(Class63.smethod_4));
    }

    public static string smethod_2(byte[] byte_0, bool bool_0)
    {
        if (byte_0 == null)
        {
            return null;
        }
        if (byte_0.Length == 0)
        {
            return string.Empty;
        }
        byte[] array = Class27.smethod_1<byte>(byte_0, 0, Class122.smethod_7(), new Func<byte[]>(Class63.smethod_4), bool_0);
        Array.Clear(array, 0, array.Length);
        return Encoding.UTF8.GetString(array);
    }

    public static void smethod_3(string string_0)
    {
        if (string.IsInterned(string_0) == null)
        {
            GCHandle handle = new GCHandle();
            handle = GCHandle.Alloc(string_0, GCHandleType.Pinned);
            IntPtr ptr = handle.AddrOfPinnedObject();
            bool flag = IntPtr.Size == 4;
            int num3 = string_0.Length * 2;
            int ofs = 0;
            int num4 = num3 / IntPtr.Size;
            for (int i = 0; i < num4; i++)
            {
                if (flag)
                {
                    Marshal.WriteInt32(ptr, ofs, 0);
                }
                else
                {
                    Marshal.WriteInt64(ptr, ofs, 0L);
                }
                ofs += IntPtr.Size;
            }
            while (ofs < num3)
            {
                Marshal.WriteInt16(ptr, ofs, (short) 0);
                ofs += 2;
            }
            handle.Free();
        }
    }

    private static byte[] smethod_4()
    {
        return (byte[]) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O9K*?9nW", null);
    }
}

