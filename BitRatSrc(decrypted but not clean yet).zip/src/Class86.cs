﻿using System;

internal sealed class Class86
{
    private Class12[] class12_0;
    private int int_0;
    private Class68[] class68_0;
    private string string_0;
    private int int_1;
    private byte byte_0;

    public Class12[] method_0()
    {
        return this.class12_0;
    }

    public void method_1(Class12[] class12_1)
    {
        this.class12_0 = class12_1;
    }

    public byte method_10()
    {
        return this.byte_0;
    }

    public void method_11(byte byte_1)
    {
        this.byte_0 = byte_1;
    }

    public bool method_12()
    {
        return ((this.method_10() & 8) != 0);
    }

    public bool method_13()
    {
        return ((this.method_10() & 4) != 0);
    }

    public bool method_14()
    {
        return ((this.method_10() & 2) != 0);
    }

    public Class68[] method_2()
    {
        return this.class68_0;
    }

    public void method_3(Class68[] class68_1)
    {
        this.class68_0 = class68_1;
    }

    public string method_4()
    {
        return this.string_0;
    }

    public void method_5(string string_1)
    {
        this.string_0 = string_1;
    }

    public int method_6()
    {
        return this.int_0;
    }

    public void method_7(int int_2)
    {
        this.int_0 = int_2;
    }

    public int method_8()
    {
        return this.int_1;
    }

    public void method_9(int int_2)
    {
        this.int_1 = int_2;
    }
}

