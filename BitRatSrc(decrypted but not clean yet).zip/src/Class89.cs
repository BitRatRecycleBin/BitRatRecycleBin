﻿using System;

internal sealed class Class89 : Interface6
{
    public void imethod_0()
    {
    }

    public string imethod_1()
    {
        return "PKCS7";
    }

    public int imethod_2(byte[] byte_0, int int_0)
    {
        byte num = (byte) (byte_0.Length - int_0);
        while (int_0 < byte_0.Length)
        {
            byte_0[int_0] = num;
            int_0++;
        }
        return num;
    }

    public int imethod_3(byte[] byte_0)
    {
        int num = byte_0[byte_0.Length - 1];
        if ((num < 1) || (num > byte_0.Length))
        {
            throw new Exception2("pad block corrupted");
        }
        for (int i = 1; i <= num; i++)
        {
            if (byte_0[byte_0.Length - i] != num)
            {
                throw new Exception2("pad block corrupted");
            }
        }
        return num;
    }
}

