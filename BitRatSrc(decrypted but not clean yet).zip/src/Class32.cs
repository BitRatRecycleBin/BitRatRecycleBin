﻿using System;

internal abstract class Class32
{
    protected Class32()
    {
    }

    public abstract byte vmethod_0();
}

