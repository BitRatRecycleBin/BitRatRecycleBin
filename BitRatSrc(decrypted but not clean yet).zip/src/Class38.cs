﻿using System;

internal sealed class Class38 : Interface2
{
    private readonly Interface2 interface2_0;
    private readonly byte[] byte_0;

    public Class38(Interface2 interface2_1, byte[] byte_1) : this(interface2_1, byte_1, 0, byte_1.Length)
    {
    }

    public Class38(Interface2 interface2_1, byte[] byte_1, int int_0, int int_1)
    {
        if (interface2_1 == null)
        {
            throw new ArgumentNullException("parameters");
        }
        if (byte_1 == null)
        {
            throw new ArgumentNullException("iv");
        }
        this.interface2_0 = interface2_1;
        this.byte_0 = new byte[int_1];
        Array.Copy(byte_1, int_0, this.byte_0, 0, int_1);
    }

    public byte[] method_0()
    {
        return (byte[]) this.byte_0.Clone();
    }

    public Interface2 method_1()
    {
        return this.interface2_0;
    }
}

