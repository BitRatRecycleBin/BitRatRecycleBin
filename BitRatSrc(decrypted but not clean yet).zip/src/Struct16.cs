﻿using System;
using System.Runtime.InteropServices;
using System.Threading;

[StructLayout(LayoutKind.Sequential)]
internal struct Struct16
{
    private int? nullable_0;
    public Struct16(string string_0)
    {
        this.nullable_0 = new int?(Class55.smethod_0(string_0));
    }

    public int method_0()
    {
        return Class55.smethod_2(this.nullable_0);
    }

    public void method_1(int int_0)
    {
        this.nullable_0 = new int?(Class55.smethod_1(int_0));
    }

    public void method_2()
    {
        this.nullable_0 = new int?(Class55.smethod_1(0));
    }

    public int method_3()
    {
        return Class55.smethod_2(this.nullable_0).GetHashCode();
    }

    public bool method_4(int int_0)
    {
        return Class55.smethod_2(this.nullable_0).Equals(int_0);
    }

    public bool method_5(object object_0)
    {
        return Class55.smethod_2(this.nullable_0).Equals(object_0);
    }

    public int method_6(int int_0)
    {
        return Class55.smethod_2(this.nullable_0).CompareTo(int_0);
    }

    public int method_7(object object_0)
    {
        return Class55.smethod_2(this.nullable_0).CompareTo(object_0);
    }

    public TypeCode method_8()
    {
        return TypeCode.Int32;
    }

    public string method_9()
    {
        return Class55.smethod_2(this.nullable_0).ToString();
    }

    public string method_10(string string_0)
    {
        return Class55.smethod_2(this.nullable_0).ToString(string_0);
    }

    public string method_11(IFormatProvider iformatProvider_0)
    {
        return Class55.smethod_2(this.nullable_0).ToString(iformatProvider_0);
    }

    public string method_12(string string_0, IFormatProvider iformatProvider_0)
    {
        return Class55.smethod_2(this.nullable_0).ToString(string_0, iformatProvider_0);
    }

    public int method_13()
    {
        Thread.MemoryBarrier();
        return Class55.smethod_2(this.nullable_0);
    }

    public void method_14(int int_0)
    {
        Thread.MemoryBarrier();
        this.nullable_0 = new int?(Class55.smethod_1(int_0));
    }

    public int method_15()
    {
        bool lockTaken = false;
        Monitor.Enter(Class82.object_0, ref lockTaken);
        int num = Class55.smethod_2(this.nullable_0) + 1;
        this.nullable_0 = new int?(Class55.smethod_1(num));
        return num;
    }

    public int method_16()
    {
        bool lockTaken = false;
        Monitor.Enter(Class82.object_0, ref lockTaken);
        int num = Class55.smethod_2(this.nullable_0) - 1;
        this.nullable_0 = new int?(Class55.smethod_1(num));
        return num;
    }

    public int method_17(int int_0)
    {
        bool lockTaken = false;
        Monitor.Enter(Class82.object_0, ref lockTaken);
        int num = Class55.smethod_2(this.nullable_0) + int_0;
        this.nullable_0 = new int?(Class55.smethod_1(num));
        return num;
    }

    public int method_18(int int_0)
    {
        bool lockTaken = false;
        Monitor.Enter(Class82.object_0, ref lockTaken);
        this.nullable_0 = new int?(Class55.smethod_1(int_0));
        return Class55.smethod_2(this.nullable_0);
    }

    public int method_19(int int_0, int int_1)
    {
        bool lockTaken = false;
        Monitor.Enter(Class82.object_0, ref lockTaken);
        int num1 = Class55.smethod_2(this.nullable_0);
        if (num1 == int_1)
        {
            this.nullable_0 = new int?(Class55.smethod_1(int_0));
        }
        return num1;
    }
}

