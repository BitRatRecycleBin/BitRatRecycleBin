﻿using System;
using System.IO;
using System.Runtime.InteropServices;

internal sealed class Class65
{
    [ThreadStatic]
    private static Stream stream_0;
    [ThreadStatic]
    private static Class87 class87_0;
    [ThreadStatic]
    private static Class91 class91_0;
    private static int? nullable_0;

    private static Stream smethod_0()
    {
        return (Stream) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O<3*?8T2", null);
    }

    private static unsafe int smethod_1()
    {
        return *(((int*) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O=F*?:.^", null)));
    }

    private static void smethod_10(long long_0, byte[] byte_0)
    {
        // Unresolved stack state at '00000000'
    }

    private static unsafe long smethod_11(string string_0)
    {
        object[] objArray = new object[] { string_0 };
        return *(((long*) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O<J*?=&[", objArray)));
    }

    private static byte[] smethod_2()
    {
        return (byte[]) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O=\"*?;a6", null);
    }

    private static byte[] smethod_3()
    {
        return (byte[]) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O=R*?:su", null);
    }

    public static void smethod_4(string string_0, byte[] byte_0, int int_0, int int_1)
    {
        if (stream_0 == null)
        {
            stream_0 = smethod_0();
        }
        smethod_9(smethod_11(string_0), byte_0, int_0, int_1);
    }

    public static byte[] smethod_5(string string_0)
    {
        if (stream_0 == null)
        {
            stream_0 = smethod_0();
        }
        byte[] buffer = new byte[4];
        long num1 = smethod_11(string_0);
        smethod_9(num1, buffer, 0, 4);
        int num = Class64.smethod_4(buffer, 0);
        Array.Clear(buffer, 0, buffer.Length);
        byte[] buffer2 = new byte[num];
        smethod_9(num1 + 4L, buffer2, 0, num);
        return buffer2;
    }

    private static Class91 smethod_6(out bool bool_0)
    {
        bool_0 = true;
        if (class91_0 != null)
        {
            return class91_0;
        }
        if (class87_0 != null)
        {
            bool_0 = false;
            return class87_0.method_8();
        }
        Class87 class2 = smethod_8();
        Class91 class3 = class2.method_8();
        if (class3.vmethod_0())
        {
            class91_0 = class3;
            class2.Dispose();
        }
        else
        {
            class87_0 = class2;
            bool_0 = false;
        }
        return class3;
    }

    private static int smethod_7()
    {
        if (nullable_0 == null)
        {
            bool flag;
            Class91 class2 = smethod_6(out flag);
            nullable_0 = new int?(class2.vmethod_1());
            if (!flag)
            {
                class2.Dispose();
            }
        }
        return nullable_0.Value;
    }

    private static Class87 smethod_8()
    {
        return (Class87) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O<G*?<ZP", null);
    }

    private static void smethod_9(long long_0, byte[] byte_0, int int_0, int int_1)
    {
        // Unresolved stack state at '00000000'
    }
}

