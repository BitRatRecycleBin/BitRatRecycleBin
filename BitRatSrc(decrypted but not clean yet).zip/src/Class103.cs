﻿using System;

internal sealed class Class103 : Class94
{
    private bool bool_0;

    public bool method_2()
    {
        return this.bool_0;
    }

    public void method_3(bool bool_1)
    {
        this.bool_0 = bool_1;
    }

    public override object vmethod_0()
    {
        return this.method_2();
    }

    public override void vmethod_1(object object_0)
    {
        this.method_3(Convert.ToBoolean(object_0));
    }

    public override int vmethod_2()
    {
        return 2;
    }

    public override Class94 vmethod_3(Class94 class94_0)
    {
        base.method_1(class94_0.method_0());
        switch (class94_0.vmethod_2())
        {
            case 0:
                this.method_3(Convert.ToBoolean(((Class119) class94_0).method_2()));
                break;

            case 2:
                this.method_3(((Class103) class94_0).method_2());
                break;

            case 4:
                this.method_3(Convert.ToBoolean(((Class102) class94_0).method_2()));
                break;

            case 7:
                this.method_3(Convert.ToBoolean(((Class118) class94_0).method_2()));
                break;

            case 8:
                this.method_3(Convert.ToBoolean(((Class100) class94_0).method_2()));
                break;

            case 9:
                this.method_3(Convert.ToBoolean(((Class115) class94_0).method_2()));
                break;

            case 11:
                this.method_3(Convert.ToBoolean(((Class99) class94_0).method_2()));
                break;

            case 14:
                this.method_3(Convert.ToBoolean(((Class105) class94_0).method_2()));
                break;

            case 15:
                this.method_3(Convert.ToBoolean(((Class101) class94_0).method_2()));
                break;

            case 0x13:
                this.method_3(Convert.ToBoolean(((Class120) class94_0).method_2()));
                break;

            case 0x15:
                this.method_3(Convert.ToBoolean(((Class104) class94_0).method_2()));
                break;

            case 0x16:
                this.method_3(Convert.ToBoolean(((Class121) class94_0).method_2()));
                break;

            case 0x18:
                this.method_3(Convert.ToBoolean(((Class98) class94_0).method_2()));
                break;

            default:
                throw new ArgumentOutOfRangeException();
        }
        return this;
    }

    public override Class94 vmethod_4()
    {
        Class103 class1 = new Class103();
        class1.method_3(this.bool_0);
        class1.method_1(base.method_0());
        return class1;
    }
}

