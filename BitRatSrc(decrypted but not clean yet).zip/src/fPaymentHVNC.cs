﻿using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using Zeroit.Framework.Progress;

[DesignerGenerated]
public sealed class fPaymentHVNC : Form
{
    private IContainer icontainer_0;
    private PictureBox pictureBox_0;
    private PictureBox pictureBox_1;
    private BackgroundWorker backgroundWorker_0;
    private Label label_0;
    private Label label_1;
    private ToolStripStatusLabel toolStripStatusLabel_0;
    private Label label_2;
    private Label label_3;
    private PictureBox pictureBox_2;
    private Timer timer_0;
    private Label label_4;
    private Label label_5;
    private Label label_6;
    private BackgroundWorker backgroundWorker_1;
    private Label label_7;
    private PictureBox pictureBox_3;
    private Label label_8;
    private Label label_9;
    private Label label_10;
    private Label label_11;
    private StatusStrip statusStrip_0;
    private Label label_12;
    private ZeroitProgressIndicator zeroitProgressIndicator_0;
    private PictureBox pictureBox_4;
    private PictureBox pictureBox_5;
    private PictureBox pictureBox_6;
    private BackgroundWorker backgroundWorker_2;
    private Label label_13;
    private Struct18 struct18_0;
    private Struct18 struct18_1;
    private Struct16 struct16_0;
    private string string_0;
    private string string_1;
    private string string_2;
    private string string_3;
    private string string_4;
    private bool bool_0;
    private TimeSpan timeSpan_0;
    private Stopwatch stopwatch_0;
    private int int_0;

    public fPaymentHVNC()
    {
        base.Load += new EventHandler(this.fPaymentHVNC_Load);
        base.Closing += new CancelEventHandler(this.fPaymentHVNC_Closing);
        this.InitializeComponent();
    }

    [CompilerGenerated]
    private void _Lambda$__R143-1()
    {
        this.method_8();
    }

    [CompilerGenerated]
    private void _Lambda$__R144-2()
    {
        this.method_8();
    }

    [CompilerGenerated]
    private void _Lambda$__R145-3()
    {
        this.method_8();
    }

    [CompilerGenerated]
    private void _Lambda$__R152-4()
    {
        this.method_8();
    }

    [DebuggerNonUserCode]
    protected override void Dispose(bool disposing)
    {
        if (disposing && (this.icontainer_0 != null))
        {
            this.icontainer_0.Dispose();
        }
    }

    private void fPaymentHVNC_Closing(object sender, CancelEventArgs e)
    {
        base.Visible = false;
        e.Cancel = true;
    }

    private void fPaymentHVNC_Load(object sender, EventArgs e)
    {
        object[] objArray = new object[] { this, sender, e };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O70*?5)$", objArray);
    }

    [DebuggerStepThrough]
    private void InitializeComponent()
    {
        this.icontainer_0 = new Container();
        ComponentResourceManager manager = new ComponentResourceManager(typeof(fPaymentHVNC));
        this.vmethod_1(new PictureBox());
        this.vmethod_3(new PictureBox());
        this.vmethod_5(new BackgroundWorker());
        this.vmethod_7(new Label());
        this.vmethod_9(new Label());
        this.vmethod_11(new ToolStripStatusLabel());
        this.vmethod_13(new Label());
        this.vmethod_15(new Label());
        this.vmethod_17(new PictureBox());
        this.vmethod_19(new Timer(this.icontainer_0));
        this.vmethod_21(new Label());
        this.vmethod_23(new Label());
        this.vmethod_25(new Label());
        this.vmethod_27(new BackgroundWorker());
        this.vmethod_29(new Label());
        this.vmethod_31(new PictureBox());
        this.vmethod_33(new Label());
        this.vmethod_35(new Label());
        this.vmethod_37(new Label());
        this.vmethod_39(new Label());
        this.vmethod_41(new StatusStrip());
        this.vmethod_43(new Label());
        this.vmethod_45(new ZeroitProgressIndicator());
        this.vmethod_47(new PictureBox());
        this.vmethod_49(new PictureBox());
        this.vmethod_51(new PictureBox());
        this.vmethod_53(new BackgroundWorker());
        this.vmethod_55(new Label());
        ((ISupportInitialize) this.vmethod_0()).BeginInit();
        ((ISupportInitialize) this.vmethod_2()).BeginInit();
        ((ISupportInitialize) this.vmethod_16()).BeginInit();
        ((ISupportInitialize) this.vmethod_30()).BeginInit();
        this.vmethod_40().SuspendLayout();
        ((ISupportInitialize) this.vmethod_46()).BeginInit();
        ((ISupportInitialize) this.vmethod_48()).BeginInit();
        ((ISupportInitialize) this.vmethod_50()).BeginInit();
        base.SuspendLayout();
        this.vmethod_0().Image = Class131.smethod_33();
        this.vmethod_0().Location = new Point(0xa1, 0xc2);
        this.vmethod_0().Margin = new Padding(2);
        this.vmethod_0().Name = "pbCopyAmount";
        this.vmethod_0().Size = new Size(15, 15);
        this.vmethod_0().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_0().TabIndex = 0xbd;
        this.vmethod_0().TabStop = false;
        this.vmethod_0().Visible = false;
        this.vmethod_2().Image = Class131.smethod_33();
        this.vmethod_2().Location = new Point(0x115, 240);
        this.vmethod_2().Margin = new Padding(2);
        this.vmethod_2().Name = "pbCopyRemainder";
        this.vmethod_2().Size = new Size(15, 15);
        this.vmethod_2().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_2().TabIndex = 0xbb;
        this.vmethod_2().TabStop = false;
        this.vmethod_2().Visible = false;
        this.vmethod_4().WorkerSupportsCancellation = true;
        this.vmethod_6().AutoSize = true;
        this.vmethod_6().BackColor = Color.Transparent;
        this.vmethod_6().Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_6().ForeColor = Color.Black;
        this.vmethod_6().Location = new Point(0x4b, 240);
        this.vmethod_6().Name = "lblRecv";
        this.vmethod_6().Size = new Size(0x1b, 13);
        this.vmethod_6().TabIndex = 0xb8;
        this.vmethod_6().Text = "N/A";
        this.vmethod_6().Visible = false;
        this.vmethod_8().AutoSize = true;
        this.vmethod_8().BackColor = Color.Transparent;
        this.vmethod_8().Location = new Point(0x10, 240);
        this.vmethod_8().Name = "lblRecvCaption";
        this.vmethod_8().Size = new Size(0x38, 13);
        this.vmethod_8().TabIndex = 0xb7;
        this.vmethod_8().Text = "Received:";
        this.vmethod_8().Visible = false;
        this.vmethod_10().AutoSize = false;
        this.vmethod_10().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_10().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_10().Margin = new Padding(0, 3, -6, 0);
        this.vmethod_10().Name = "tsStatus";
        this.vmethod_10().Size = new Size(0x1ce, 0x10);
        this.vmethod_10().Spring = true;
        this.vmethod_10().Text = "Status: N/A";
        this.vmethod_10().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_12().AutoSize = true;
        this.vmethod_12().BackColor = Color.Transparent;
        this.vmethod_12().Location = new Point(0x3a, 0x175);
        this.vmethod_12().Name = "lblWarning";
        this.vmethod_12().Size = new Size(0x141, 0x5b);
        this.vmethod_12().TabIndex = 0xbc;
        this.vmethod_12().Text = manager.GetString("lblWarning.Text");
        this.vmethod_14().AutoSize = true;
        this.vmethod_14().BackColor = Color.Transparent;
        this.vmethod_14().Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic, GraphicsUnit.Point, 0);
        this.vmethod_14().Location = new Point(0x16f, 0x1d7);
        this.vmethod_14().Name = "lblAlreadyPaid";
        this.vmethod_14().Size = new Size(0x47, 13);
        this.vmethod_14().TabIndex = 0xb5;
        this.vmethod_14().Text = "Already paid?";
        this.vmethod_16().Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
        this.vmethod_16().Image = Class131.smethod_17();
        this.vmethod_16().Location = new Point(0x1bb, 0x1d7);
        this.vmethod_16().Margin = new Padding(2);
        this.vmethod_16().Name = "pbHelp";
        this.vmethod_16().Size = new Size(15, 15);
        this.vmethod_16().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_16().TabIndex = 180;
        this.vmethod_16().TabStop = false;
        this.vmethod_18().Interval = 0x3e8;
        this.vmethod_20().AutoSize = true;
        this.vmethod_20().BackColor = Color.Transparent;
        this.vmethod_20().Location = new Point(0x3a, 0x10c);
        this.vmethod_20().Name = "lblInfo";
        this.vmethod_20().Size = new Size(0x133, 0x5b);
        this.vmethod_20().TabIndex = 0xb2;
        this.vmethod_20().Text = manager.GetString("lblInfo.Text");
        this.vmethod_22().AutoSize = true;
        this.vmethod_22().BackColor = Color.Transparent;
        this.vmethod_22().Location = new Point(0x18, 0xda);
        this.vmethod_22().Name = "lblAddrCaption";
        this.vmethod_22().Size = new Size(0x30, 13);
        this.vmethod_22().TabIndex = 0xac;
        this.vmethod_22().Text = "Address:";
        this.vmethod_22().Visible = false;
        this.vmethod_24().AutoSize = true;
        this.vmethod_24().BackColor = Color.Transparent;
        this.vmethod_24().Location = new Point(0x1a, 0xc4);
        this.vmethod_24().Name = "lblAmountCaption";
        this.vmethod_24().Size = new Size(0x2e, 13);
        this.vmethod_24().TabIndex = 0xab;
        this.vmethod_24().Text = "Amount:";
        this.vmethod_24().Visible = false;
        this.vmethod_26().WorkerSupportsCancellation = true;
        this.vmethod_28().BackColor = Color.Transparent;
        this.vmethod_28().Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
        this.vmethod_28().Location = new Point(60, 0xa9);
        this.vmethod_28().Name = "lblTimer";
        this.vmethod_28().Size = new Size(0x161, 14);
        this.vmethod_28().TabIndex = 0xb1;
        this.vmethod_28().Text = "Time left: N/A";
        this.vmethod_28().TextAlign = ContentAlignment.TopCenter;
        this.vmethod_28().Visible = false;
        this.vmethod_30().Image = Class131.smethod_33();
        this.vmethod_30().Location = new Point(110, 0xd8);
        this.vmethod_30().Margin = new Padding(2);
        this.vmethod_30().Name = "pbCopyAddr";
        this.vmethod_30().Size = new Size(15, 15);
        this.vmethod_30().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_30().TabIndex = 0xb0;
        this.vmethod_30().TabStop = false;
        this.vmethod_30().Visible = false;
        this.vmethod_32().AutoSize = true;
        this.vmethod_32().BackColor = Color.Transparent;
        this.vmethod_32().Location = new Point(0x6b, 0xc4);
        this.vmethod_32().Name = "lblAmountUSD";
        this.vmethod_32().Size = new Size(0x31, 13);
        this.vmethod_32().TabIndex = 0xaf;
        this.vmethod_32().Text = "~ 0 USD";
        this.vmethod_32().Visible = false;
        this.vmethod_34().AutoSize = true;
        this.vmethod_34().BackColor = Color.Transparent;
        this.vmethod_34().Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
        this.vmethod_34().ForeColor = Color.RoyalBlue;
        this.vmethod_34().Location = new Point(0x4b, 0xda);
        this.vmethod_34().Name = "lblAddress";
        this.vmethod_34().Size = new Size(30, 13);
        this.vmethod_34().TabIndex = 0xae;
        this.vmethod_34().Text = "N/A";
        this.vmethod_34().Visible = false;
        this.vmethod_36().AutoSize = true;
        this.vmethod_36().BackColor = Color.Transparent;
        this.vmethod_36().Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
        this.vmethod_36().ForeColor = Color.RoyalBlue;
        this.vmethod_36().Location = new Point(0x4b, 0xc4);
        this.vmethod_36().Name = "lblAmount";
        this.vmethod_36().Size = new Size(30, 13);
        this.vmethod_36().TabIndex = 0xad;
        this.vmethod_36().Text = "N/A";
        this.vmethod_36().Visible = false;
        this.vmethod_38().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
        this.vmethod_38().BackColor = Color.Transparent;
        this.vmethod_38().Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
        this.vmethod_38().Location = new Point(8, 6);
        this.vmethod_38().Name = "lblTitle";
        this.vmethod_38().Size = new Size(0x1bf, 0x17);
        this.vmethod_38().TabIndex = 170;
        this.vmethod_38().Text = "Buy Hidden Desktop/hVNC access";
        this.vmethod_38().TextAlign = ContentAlignment.TopCenter;
        this.vmethod_40().AutoSize = false;
        this.vmethod_40().BackColor = Color.FromArgb(0xeb, 0xed, 0xef);
        this.vmethod_40().ImageScalingSize = new Size(0x1c, 0x1c);
        ToolStripItem[] toolStripItems = new ToolStripItem[] { this.vmethod_10() };
        this.vmethod_40().Items.AddRange(toolStripItems);
        this.vmethod_40().Location = new Point(0, 0x1f5);
        this.vmethod_40().Name = "ssMain";
        this.vmethod_40().Padding = new Padding(1, 0, 7, 0);
        this.vmethod_40().Size = new Size(0x1d0, 0x13);
        this.vmethod_40().SizingGrip = false;
        this.vmethod_40().Stretch = false;
        this.vmethod_40().TabIndex = 0xa8;
        this.vmethod_40().Text = "stStatus";
        this.vmethod_42().AutoSize = true;
        this.vmethod_42().BackColor = Color.Transparent;
        this.vmethod_42().ForeColor = Color.Red;
        this.vmethod_42().Location = new Point(0x6b, 240);
        this.vmethod_42().Name = "lblUnderpaid";
        this.vmethod_42().Size = new Size(0x99, 13);
        this.vmethod_42().TabIndex = 0xb9;
        this.vmethod_42().Text = "(Underpaid! Missing: N/A BTC)";
        this.vmethod_42().Visible = false;
        this.vmethod_44().set_BackColor(SystemColors.AppWorkspace);
        this.vmethod_44().set_CircleWidth(20f);
        this.vmethod_44().set_GetAnimationColor(Color.DeepSkyBlue);
        this.vmethod_44().set_GetAnimationSpeed(100);
        this.vmethod_44().set_GetBaseColor(Color.SkyBlue);
        this.vmethod_44().Location = new Point(0xb5, 0x26);
        this.vmethod_44().MinimumSize = new Size(80, 80);
        this.vmethod_44().Name = "pbSplash";
        this.vmethod_44().set_NumberOfCircles(45f);
        this.vmethod_44().set_Radian(180.0);
        this.vmethod_44().Size = new Size(100, 100);
        this.vmethod_44().set_Smoothing(SmoothingMode.HighQuality);
        this.vmethod_44().TabIndex = 0xa9;
        this.vmethod_46().BackColor = Color.Transparent;
        this.vmethod_46().Image = Class131.smethod_3();
        this.vmethod_46().Location = new Point(0xb5, 0x26);
        this.vmethod_46().Margin = new Padding(2);
        this.vmethod_46().Name = "pbComplete";
        this.vmethod_46().Size = new Size(100, 100);
        this.vmethod_46().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_46().TabIndex = 0xb3;
        this.vmethod_46().TabStop = false;
        this.vmethod_46().Visible = false;
        this.vmethod_48().BackColor = Color.Transparent;
        this.vmethod_48().Location = new Point(0xb5, 0x26);
        this.vmethod_48().Margin = new Padding(2);
        this.vmethod_48().Name = "pbQR";
        this.vmethod_48().Size = new Size(100, 100);
        this.vmethod_48().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_48().TabIndex = 0xa7;
        this.vmethod_48().TabStop = false;
        this.vmethod_48().Visible = false;
        this.vmethod_50().BackColor = Color.Transparent;
        this.vmethod_50().Image = Class131.smethod_13();
        this.vmethod_50().Location = new Point(0xb5, 0x26);
        this.vmethod_50().Margin = new Padding(2);
        this.vmethod_50().Name = "pbError";
        this.vmethod_50().Size = new Size(100, 100);
        this.vmethod_50().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_50().TabIndex = 0xb6;
        this.vmethod_50().TabStop = false;
        this.vmethod_50().Visible = false;
        this.vmethod_54().AutoSize = true;
        this.vmethod_54().BackColor = Color.Transparent;
        this.vmethod_54().ForeColor = Color.Green;
        this.vmethod_54().Location = new Point(0x6b, 240);
        this.vmethod_54().Name = "lblPaid";
        this.vmethod_54().Size = new Size(0xa5, 13);
        this.vmethod_54().TabIndex = 0xba;
        this.vmethod_54().Text = "(Paid! Waiting for confirmations...)";
        this.vmethod_54().Visible = false;
        base.AutoScaleDimensions = new SizeF(6f, 13f);
        base.AutoScaleMode = AutoScaleMode.Font;
        this.BackColor = SystemColors.AppWorkspace;
        base.ClientSize = new Size(0x1d0, 520);
        base.Controls.Add(this.vmethod_0());
        base.Controls.Add(this.vmethod_2());
        base.Controls.Add(this.vmethod_6());
        base.Controls.Add(this.vmethod_8());
        base.Controls.Add(this.vmethod_12());
        base.Controls.Add(this.vmethod_14());
        base.Controls.Add(this.vmethod_16());
        base.Controls.Add(this.vmethod_20());
        base.Controls.Add(this.vmethod_22());
        base.Controls.Add(this.vmethod_24());
        base.Controls.Add(this.vmethod_28());
        base.Controls.Add(this.vmethod_30());
        base.Controls.Add(this.vmethod_32());
        base.Controls.Add(this.vmethod_34());
        base.Controls.Add(this.vmethod_36());
        base.Controls.Add(this.vmethod_38());
        base.Controls.Add(this.vmethod_40());
        base.Controls.Add(this.vmethod_42());
        base.Controls.Add(this.vmethod_54());
        base.Controls.Add(this.vmethod_44());
        base.Controls.Add(this.vmethod_46());
        base.Controls.Add(this.vmethod_48());
        base.Controls.Add(this.vmethod_50());
        this.DoubleBuffered = true;
        base.FormBorderStyle = FormBorderStyle.FixedSingle;
        base.Icon = (Icon) manager.GetObject("$this.Icon");
        base.MaximizeBox = false;
        base.MinimizeBox = false;
        base.Name = "fPaymentHVNC";
        base.Opacity = 0.0;
        this.Text = "Buy Hidden Desktop/hVNC";
        ((ISupportInitialize) this.vmethod_0()).EndInit();
        ((ISupportInitialize) this.vmethod_2()).EndInit();
        ((ISupportInitialize) this.vmethod_16()).EndInit();
        ((ISupportInitialize) this.vmethod_30()).EndInit();
        this.vmethod_40().ResumeLayout(false);
        this.vmethod_40().PerformLayout();
        ((ISupportInitialize) this.vmethod_46()).EndInit();
        ((ISupportInitialize) this.vmethod_48()).EndInit();
        ((ISupportInitialize) this.vmethod_50()).EndInit();
        base.ResumeLayout(false);
        base.PerformLayout();
    }

    public void method_0(int int_1)
    {
        // Unresolved stack state at '00000008'
    }

    public void method_1(string string_5)
    {
        object[] objArray = new object[] { this, string_5 };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O6(*?64D", objArray);
    }

    public void method_10()
    {
        object[] objArray = new object[] { this };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O8B*?=Vk", objArray);
    }

    private void method_11(object sender, EventArgs e)
    {
        Clipboard.Clear();
        Clipboard.SetText(this.vmethod_36().Text);
        Interaction.MsgBox("Amount copied to clipboard!", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_12(object sender, EventArgs e)
    {
        Clipboard.Clear();
        Clipboard.SetText(this.vmethod_34().Text);
        Interaction.MsgBox("Address copied to clipboard!", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_13(object sender, EventArgs e)
    {
        Clipboard.Clear();
        Clipboard.SetText(Conversions.ToString(this.vmethod_42().Tag));
        Interaction.MsgBox("Remaining amount copied to clipboard!", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_14(object sender, EventArgs e)
    {
        string[] textArray1 = new string[] { "If you've already paid and still seeing this payment form, please close it and wait some minutes before starting ", Application.ProductName, " again.\r\n\r\nMost likely, your payment is still waiting for a confirmation and your purchased item will automatically become available once confirmed.\r\n\r\nNOTE: ", Application.ProductName, " uses private nodes in the blockchain to check for confimrations, not public services like blockchain.com.\r\nThis means a confirmation may sometimes take a little longer or sometimes even faster. Do not panic, but allow some more minutes." };
        Interaction.MsgBox(string.Concat(textArray1), MsgBoxStyle.Question, Application.ProductName);
    }

    private void method_15(object sender, EventArgs e)
    {
        Clipboard.Clear();
        Clipboard.SetText(this.vmethod_36().Text);
        Interaction.MsgBox("Amount copied to clipboard!", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_16(object sender, EventArgs e)
    {
        Clipboard.Clear();
        Clipboard.SetText(this.vmethod_34().Text);
        Interaction.MsgBox("Address copied to clipboard!", MsgBoxStyle.Information, Application.ProductName);
    }

    public void method_17()
    {
        object[] objArray = new object[] { this };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O:/*?=5`", objArray);
    }

    public void method_18(string string_5, bool bool_1, string string_6, decimal decimal_0)
    {
        // Unresolved stack state at '00000000'
    }

    private void method_2(ref string string_5, ref string string_6, ref string string_7)
    {
        object[] objArray = new object[] { this, string_5, string_6, string_7 };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O5O*?8-%", objArray);
    }

    private void method_3()
    {
        object[] objArray = new object[] { this };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O8k*?<*@", objArray);
    }

    private void method_4(object sender, DoWorkEventArgs e)
    {
        Thread.Sleep(0x3e8);
        this.int_0 = 0;
        while (this.int_0 < 100)
        {
            ref int numRef;
            *(numRef = ref this.int_0) = numRef + 1;
            this.method_0(this.int_0);
            Thread.Sleep(1);
        }
    }

    private void method_5(object sender, DoWorkEventArgs e)
    {
        object[] objArray = new object[] { this, sender, e };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O5.*?7Ni", objArray);
    }

    private void method_6(object sender, DoWorkEventArgs e)
    {
        Thread.Sleep(0x3e8);
        this.int_0 = 0;
        while (this.int_0 < 100)
        {
            ref int numRef;
            *(numRef = ref this.int_0) = numRef + 1;
            this.method_0(this.int_0);
            Thread.Sleep(1);
        }
    }

    private void method_7(string string_5, string string_6)
    {
        object[] objArray = new object[] { this, string_5, string_6 };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O6k*?92C", objArray);
    }

    public unsafe bool method_8()
    {
        object[] objArray = new object[] { this };
        return *(((bool*) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O5.*?:Oi", objArray)));
    }

    public void method_9()
    {
        object[] objArray = new object[] { this };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O9M*?;j9", objArray);
    }

    internal virtual PictureBox vmethod_0()
    {
        return this.pictureBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_1(PictureBox pictureBox_7)
    {
        EventHandler handler = new EventHandler(this.method_11);
        PictureBox box = this.pictureBox_0;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_0 = pictureBox_7;
        box = this.pictureBox_0;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual ToolStripStatusLabel vmethod_10()
    {
        return this.toolStripStatusLabel_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_11(ToolStripStatusLabel toolStripStatusLabel_1)
    {
        this.toolStripStatusLabel_0 = toolStripStatusLabel_1;
    }

    internal virtual Label vmethod_12()
    {
        return this.label_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_13(Label label_14)
    {
        this.label_2 = label_14;
    }

    internal virtual Label vmethod_14()
    {
        return this.label_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_15(Label label_14)
    {
        this.label_3 = label_14;
    }

    internal virtual PictureBox vmethod_16()
    {
        return this.pictureBox_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_17(PictureBox pictureBox_7)
    {
        EventHandler handler = new EventHandler(this.method_14);
        PictureBox box = this.pictureBox_2;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_2 = pictureBox_7;
        box = this.pictureBox_2;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual Timer vmethod_18()
    {
        return this.timer_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_19(Timer timer_1)
    {
        this.timer_0 = timer_1;
    }

    internal virtual PictureBox vmethod_2()
    {
        return this.pictureBox_1;
    }

    internal virtual Label vmethod_20()
    {
        return this.label_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_21(Label label_14)
    {
        this.label_4 = label_14;
    }

    internal virtual Label vmethod_22()
    {
        return this.label_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_23(Label label_14)
    {
        this.label_5 = label_14;
    }

    internal virtual Label vmethod_24()
    {
        return this.label_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_25(Label label_14)
    {
        this.label_6 = label_14;
    }

    internal virtual BackgroundWorker vmethod_26()
    {
        return this.backgroundWorker_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_27(BackgroundWorker backgroundWorker_3)
    {
        DoWorkEventHandler handler = new DoWorkEventHandler(this.method_5);
        BackgroundWorker worker = this.backgroundWorker_1;
        if (worker != null)
        {
            worker.DoWork -= handler;
        }
        this.backgroundWorker_1 = backgroundWorker_3;
        worker = this.backgroundWorker_1;
        if (worker != null)
        {
            worker.DoWork += handler;
        }
    }

    internal virtual Label vmethod_28()
    {
        return this.label_7;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_29(Label label_14)
    {
        this.label_7 = label_14;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_3(PictureBox pictureBox_7)
    {
        EventHandler handler = new EventHandler(this.method_13);
        PictureBox box = this.pictureBox_1;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_1 = pictureBox_7;
        box = this.pictureBox_1;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual PictureBox vmethod_30()
    {
        return this.pictureBox_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_31(PictureBox pictureBox_7)
    {
        EventHandler handler = new EventHandler(this.method_12);
        PictureBox box = this.pictureBox_3;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_3 = pictureBox_7;
        box = this.pictureBox_3;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual Label vmethod_32()
    {
        return this.label_8;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_33(Label label_14)
    {
        this.label_8 = label_14;
    }

    internal virtual Label vmethod_34()
    {
        return this.label_9;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_35(Label label_14)
    {
        EventHandler handler = new EventHandler(this.method_16);
        Label label = this.label_9;
        if (label != null)
        {
            label.Click -= handler;
        }
        this.label_9 = label_14;
        label = this.label_9;
        if (label != null)
        {
            label.Click += handler;
        }
    }

    internal virtual Label vmethod_36()
    {
        return this.label_10;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_37(Label label_14)
    {
        EventHandler handler = new EventHandler(this.method_15);
        Label label = this.label_10;
        if (label != null)
        {
            label.Click -= handler;
        }
        this.label_10 = label_14;
        label = this.label_10;
        if (label != null)
        {
            label.Click += handler;
        }
    }

    internal virtual Label vmethod_38()
    {
        return this.label_11;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_39(Label label_14)
    {
        this.label_11 = label_14;
    }

    internal virtual BackgroundWorker vmethod_4()
    {
        return this.backgroundWorker_0;
    }

    internal virtual StatusStrip vmethod_40()
    {
        return this.statusStrip_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_41(StatusStrip statusStrip_1)
    {
        this.statusStrip_0 = statusStrip_1;
    }

    internal virtual Label vmethod_42()
    {
        return this.label_12;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_43(Label label_14)
    {
        this.label_12 = label_14;
    }

    internal virtual ZeroitProgressIndicator vmethod_44()
    {
        return this.zeroitProgressIndicator_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_45(ZeroitProgressIndicator zeroitProgressIndicator_1)
    {
        this.zeroitProgressIndicator_0 = zeroitProgressIndicator_1;
    }

    internal virtual PictureBox vmethod_46()
    {
        return this.pictureBox_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_47(PictureBox pictureBox_7)
    {
        this.pictureBox_4 = pictureBox_7;
    }

    internal virtual PictureBox vmethod_48()
    {
        return this.pictureBox_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_49(PictureBox pictureBox_7)
    {
        this.pictureBox_5 = pictureBox_7;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_5(BackgroundWorker backgroundWorker_3)
    {
        DoWorkEventHandler handler = new DoWorkEventHandler(this.method_4);
        BackgroundWorker worker = this.backgroundWorker_0;
        if (worker != null)
        {
            worker.DoWork -= handler;
        }
        this.backgroundWorker_0 = backgroundWorker_3;
        worker = this.backgroundWorker_0;
        if (worker != null)
        {
            worker.DoWork += handler;
        }
    }

    internal virtual PictureBox vmethod_50()
    {
        return this.pictureBox_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_51(PictureBox pictureBox_7)
    {
        this.pictureBox_6 = pictureBox_7;
    }

    internal virtual BackgroundWorker vmethod_52()
    {
        return this.backgroundWorker_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_53(BackgroundWorker backgroundWorker_3)
    {
        DoWorkEventHandler handler = new DoWorkEventHandler(this.method_6);
        BackgroundWorker worker = this.backgroundWorker_2;
        if (worker != null)
        {
            worker.DoWork -= handler;
        }
        this.backgroundWorker_2 = backgroundWorker_3;
        worker = this.backgroundWorker_2;
        if (worker != null)
        {
            worker.DoWork += handler;
        }
    }

    internal virtual Label vmethod_54()
    {
        return this.label_13;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_55(Label label_14)
    {
        this.label_13 = label_14;
    }

    internal virtual Label vmethod_6()
    {
        return this.label_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_7(Label label_14)
    {
        this.label_0 = label_14;
    }

    internal virtual Label vmethod_8()
    {
        return this.label_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_9(Label label_14)
    {
        this.label_1 = label_14;
    }

    private delegate void Delegate88(ref string string_0, ref string string_1, ref string string_2);

    private delegate void Delegate89(string string_0);

    private delegate void Delegate90();

    private delegate void Delegate91();

    private delegate void Delegate92(string string_0, bool bool_0, string string_1, decimal decimal_0);

    private delegate void Delegate93(string string_0, string string_1);

    private delegate void Delegate94(int int_0);
}

