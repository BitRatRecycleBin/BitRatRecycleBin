﻿using System;
using System.Windows.Forms;

public sealed class GClass7 : ListView
{
    public GClass7();
}

