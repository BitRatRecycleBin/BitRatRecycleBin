﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Text;
using System.Threading;

internal static class Class70
{
    private static Class72 class72_0 = new Class72();

    internal static long smethod_0()
    {
        if (!ReferenceEquals(Assembly.GetCallingAssembly(), typeof(Class70).Assembly) || !smethod_2())
        {
            return 0L;
        }
        Monitor.Enter(class72_0);
        long num2 = class72_0.method_0();
        if (num2 == 0L)
        {
            List<byte> list = new List<byte>();
            AssemblyName name = Assembly.GetExecutingAssembly().GetName();
            byte[] publicKeyToken = name.GetPublicKeyToken();
            if ((publicKeyToken != null) && (publicKeyToken.Length == 0))
            {
                publicKeyToken = null;
            }
            if (publicKeyToken != null)
            {
                list.AddRange(publicKeyToken);
            }
            list.AddRange(Encoding.Unicode.GetBytes(name.Name));
            int num4 = smethod_4(typeof(Class70));
            int num5 = Class74.smethod_0();
            list.Add((byte) (num4 >> 0x10));
            list.Add((byte) (num5 >> 8));
            list.Add((byte) (num4 >> 8));
            list.Add((byte) (num5 >> 0x18));
            list.Add((byte) num4);
            list.Add((byte) (num5 >> 0x10));
            list.Add((byte) (num4 >> 0x18));
            list.Add((byte) num5);
            int count = list.Count;
            ulong num = 0UL;
            int num3 = 0;
            while (true)
            {
                if (num3 == count)
                {
                    num += num << 6;
                    num ^= num >> 0x16;
                    num2 = ((long) (num + (num << 30))) ^ -5127325363398215413L;
                    class72_0.method_1(num2);
                    break;
                }
                num += (ulong) list[num3];
                num += num << 20;
                num ^= num >> 12;
                list[num3] = 0;
                num3++;
            }
        }
        return num2;
    }

    internal static unsafe void smethod_1(byte[] byte_0)
    {
        if (ReferenceEquals(Assembly.GetCallingAssembly(), typeof(Class70).Assembly) && smethod_2())
        {
            long num = smethod_0();
            byte[] buffer = new byte[] { (byte) num, (byte) (num >> 40), (byte) (num >> 0x38), (byte) (num >> 0x30), (byte) (num >> 0x20), (byte) (num >> 0x18), (byte) (num >> 0x10), (byte) (num >> 8) };
            int length = byte_0.Length;
            for (int i = 0; i != length; i++)
            {
                byte* numPtr1 = &(byte_0[i]);
                numPtr1[0] = (byte) (numPtr1[0] ^ ((byte) (buffer[i & 7] + i)));
            }
        }
    }

    private static bool smethod_2()
    {
        return smethod_3();
    }

    private static bool smethod_3()
    {
        StackFrame frame = new StackTrace().GetFrame(3);
        MethodBase base2 = (frame == null) ? null : frame.GetMethod();
        Type objA = (base2 == null) ? null : base2.DeclaringType;
        return (!ReferenceEquals(objA, typeof(RuntimeMethodHandle)) ? ((objA != null) ? ReferenceEquals(objA.Assembly, typeof(Class70).Assembly) : false) : false);
    }

    private static int smethod_4(Type type_0)
    {
        return type_0.MetadataToken;
    }

    private sealed class Class71
    {
        internal static int smethod_0()
        {
            return Class70.Class73.smethod_2(Class70.Class73.smethod_0(Class70.Class78.smethod_0() ^ 0x1f74f46e, Class70.smethod_4(typeof(Class70.Class75))), Class70.Class73.smethod_1(Class70.smethod_4(typeof(Class70.Class74)) ^ Class70.smethod_4(typeof(Class70.Class76)), -1434132906));
        }
    }

    private sealed class Class72
    {
        private int int_0;
        private int int_1;

        internal Class72()
        {
            this.method_1(0L);
        }

        internal long method_0()
        {
            if (!ReferenceEquals(Assembly.GetCallingAssembly(), typeof(Class70.Class72).Assembly))
            {
                return 0x2c87f0L;
            }
            if (!Class70.smethod_2())
            {
                return 0x2c87f0L;
            }
            int[] numArray = new int[] { -799872360 };
            numArray[3] = 0x51f9b9c1;
            numArray[1] = 0x6c7bf2e0;
            numArray[2] = -1768535364;
            int num = this.int_0;
            int num2 = this.int_1;
            int num7 = -1640531527;
            int num3 = -957401312;
            for (int i = 0; i != 0x20; i++)
            {
                num2 -= (((num << 4) ^ (num >> 5)) + num) ^ (num3 + numArray[(num3 >> 11) & 3]);
                num3 -= num7;
                num -= (((num2 << 4) ^ (num2 >> 5)) + num2) ^ (num3 + numArray[num3 & 3]);
            }
            for (int j = 0; j != 4; j++)
            {
                numArray[j] = 0;
            }
            return ((num2 << 0x20) | ((ulong) num));
        }

        internal void method_1(long long_0)
        {
            if (ReferenceEquals(Assembly.GetCallingAssembly(), typeof(Class70.Class72).Assembly) && Class70.smethod_2())
            {
                int[] numArray = new int[] { -799872360 };
                numArray[1] = 0x6c7bf2e0;
                numArray[2] = -1768535364;
                numArray[3] = 0x51f9b9c1;
                int num6 = -1640531527;
                int num = (int) long_0;
                int num2 = (int) (long_0 >> 0x20);
                int num3 = 0;
                for (int i = 0; i != 0x20; i++)
                {
                    num += (((num2 << 4) ^ (num2 >> 5)) + num2) ^ (num3 + numArray[num3 & 3]);
                    num3 += num6;
                    num2 += (((num << 4) ^ (num >> 5)) + num) ^ (num3 + numArray[(num3 >> 11) & 3]);
                }
                for (int j = 0; j != 4; j++)
                {
                    numArray[j] = 0;
                }
                this.int_0 = num;
                this.int_1 = num2;
            }
        }
    }

    private static class Class73
    {
        internal static int smethod_0(int int_0, int int_1)
        {
            return (int_0 ^ (int_1 - 0x4e8e61e8));
        }

        internal static int smethod_1(int int_0, int int_1)
        {
            return ((int_0 - -695884082) ^ (int_1 + -2101103186));
        }

        internal static int smethod_2(int int_0, int int_1)
        {
            return (int_0 ^ ((int_1 - -378159800) ^ (int_0 - int_1)));
        }
    }

    private sealed class Class74
    {
        internal static int smethod_0()
        {
            return Class70.Class73.smethod_2(Class70.Class73.smethod_1(Class70.smethod_4(typeof(Class70.Class78)), Class70.Class73.smethod_2(Class70.smethod_4(typeof(Class70.Class74)), Class70.smethod_4(typeof(Class70.Class77)))), Class70.Class76.smethod_0());
        }
    }

    private sealed class Class75
    {
        internal static int smethod_0()
        {
            return Class70.Class73.smethod_2(Class70.smethod_4(typeof(Class70.Class75)), Class70.Class73.smethod_0(Class70.smethod_4(typeof(Class70.Class74)), Class70.Class73.smethod_1(Class70.smethod_4(typeof(Class70.Class78)), Class70.Class73.smethod_2(Class70.smethod_4(typeof(Class70.Class71)), Class70.Class73.smethod_0(Class70.smethod_4(typeof(Class70.Class77)), Class70.smethod_4(typeof(Class70.Class76)))))));
        }
    }

    private sealed class Class76
    {
        internal static int smethod_0()
        {
            return Class70.Class73.smethod_0(Class70.smethod_4(typeof(Class70.Class76)), Class70.Class73.smethod_2(Class70.Class73.smethod_1(Class70.smethod_4(typeof(Class70.Class77)), Class70.smethod_4(typeof(Class70.Class74))), Class70.Class73.smethod_2(Class70.smethod_4(typeof(Class70.Class71)) ^ 0xb559008, Class70.Class77.smethod_0())));
        }
    }

    private sealed class Class77
    {
        internal static int smethod_0()
        {
            return Class70.Class73.smethod_1(Class70.Class73.smethod_1(Class70.Class71.smethod_0(), Class70.Class73.smethod_0(Class70.smethod_4(typeof(Class70.Class77)), Class70.Class78.smethod_0())), Class70.smethod_4(typeof(Class70.Class76)));
        }
    }

    private sealed class Class78
    {
        internal static int smethod_0()
        {
            return Class70.Class73.smethod_0(Class70.smethod_4(typeof(Class70.Class71)), Class70.smethod_4(typeof(Class70.Class75)) ^ Class70.Class73.smethod_1(Class70.smethod_4(typeof(Class70.Class78)), Class70.Class73.smethod_2(Class70.smethod_4(typeof(Class70.Class76)), Class70.Class75.smethod_0())));
        }
    }
}

