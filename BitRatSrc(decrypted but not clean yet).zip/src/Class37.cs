﻿using System;

internal sealed class Class37 : Class32
{
    private string string_0;
    private bool bool_0;
    private bool bool_1;
    private Class3[] class3_0;
    private int int_0 = -1;
    private int int_1 = -1;

    public string method_0()
    {
        return this.string_0;
    }

    public void method_1(string string_1)
    {
        this.string_0 = string_1;
    }

    public int method_10()
    {
        return this.int_1;
    }

    public void method_11(int int_2)
    {
        this.int_1 = int_2;
    }

    public bool method_2()
    {
        return this.bool_0;
    }

    public void method_3(bool bool_2)
    {
        this.bool_0 = bool_2;
    }

    public bool method_4()
    {
        return this.bool_1;
    }

    public void method_5(bool bool_2)
    {
        this.bool_1 = bool_2;
    }

    public Class3[] method_6()
    {
        return this.class3_0;
    }

    public void method_7(Class3[] class3_1)
    {
        this.class3_0 = class3_1;
    }

    public int method_8()
    {
        return this.int_0;
    }

    public void method_9(int int_2)
    {
        this.int_0 = int_2;
    }

    public override byte vmethod_0()
    {
        return 1;
    }
}

