﻿using BitRAT.My;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.Diagnostics;

[HideModuleName, DebuggerNonUserCode, StandardModule]
internal sealed class Class135
{
    internal static MySettings smethod_0()
    {
        return MySettings.Default;
    }
}

