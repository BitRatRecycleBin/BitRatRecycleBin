﻿using System;

internal static class Class122
{
    public static unsafe int smethod_0()
    {
        return *(((int*) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O:+*?5D-", null)));
    }

    public static unsafe int smethod_1()
    {
        return *(((int*) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O:V*?6dT", null)));
    }

    public static unsafe int smethod_2()
    {
        return *(((int*) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O7n*?8E-", null)));
    }

    public static unsafe int smethod_3()
    {
        return *(((int*) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O9F*?7ls", null)));
    }

    public static unsafe int smethod_4()
    {
        return *(((int*) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O9^*?9>G", null)));
    }

    public static unsafe long smethod_5()
    {
        return *(((long*) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O9M*?8r<", null)));
    }

    public static unsafe long smethod_6()
    {
        return *(((long*) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O:d*?8Q1", null)));
    }

    public static unsafe Struct15 smethod_7()
    {
        return *(((Struct15*) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O8**?:Ce", null)));
    }
}

