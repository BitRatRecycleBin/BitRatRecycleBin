﻿using System;

internal sealed class Exception1 : Exception0
{
    public Exception1()
    {
    }

    public Exception1(string string_0) : base(string_0)
    {
    }

    public Exception1(string string_0, Exception exception_0) : base(string_0, exception_0)
    {
    }
}

