﻿using System;

internal interface Interface5
{
    bool imethod_0();
    object imethod_1();
    void imethod_2();
}

