﻿using System;

internal interface Interface0
{
    string imethod_0();
    void imethod_1(bool bool_0, Interface2 interface2_0);
    int imethod_2();
    bool imethod_3();
    int imethod_4(byte[] byte_0, int int_0, byte[] byte_1, int int_1);
    void imethod_5();
}

