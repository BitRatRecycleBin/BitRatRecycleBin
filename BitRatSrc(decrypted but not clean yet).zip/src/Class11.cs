﻿using System;
using System.Threading;

internal static class Class11
{
    public static Interface7 smethod_0()
    {
        return (smethod_1() ?? new Class19());
    }

    private static Interface7 smethod_1()
    {
        Interface7 interface2;
        Class81 class2 = new Class81();
        if (smethod_3(class2))
        {
            interface2 = class2;
        }
        else
        {
            class2.Dispose();
            interface2 = null;
        }
        return interface2;
    }

    private static bool smethod_2(Exception exception_0)
    {
        return ((exception_0 is ThreadAbortException) || (exception_0 is ThreadInterruptedException));
    }

    private static bool smethod_3(Interface7 interface7_0)
    {
        byte[] buffer1 = new byte[3];
        buffer1[1] = 130;
        buffer1[2] = 0xff;
        byte[] buffer = buffer1;
        for (int i = 0; i < buffer.Length; i++)
        {
            byte num2 = buffer[i];
            interface7_0.imethod_2(i, ref num2);
        }
        if (interface7_0.imethod_0() != buffer.Length)
        {
            return false;
        }
        for (int j = 0; j < buffer.Length; j++)
        {
            byte num4;
            interface7_0.imethod_1(j, out num4);
            if (num4 != buffer[j])
            {
                return false;
            }
        }
        interface7_0.imethod_3();
        return (interface7_0.imethod_0() == 0);
    }
}

