﻿using System;
using System.Collections;
using System.Runtime.CompilerServices;
using System.Threading;

public sealed class GClass5
{
    public int int_0;
    private readonly SortedList sortedList_0 = new SortedList();
    private GClass8 gclass8_0;
    private GDelegate5 gdelegate5_0;
    private GDelegate7 gdelegate7_0;
    private GDelegate6 gdelegate6_0;

    public GClass5(int int_1, bool bool_0)
    {
        this.int_0 = int_1;
        this.vmethod_1(new GClass8(int_1, bool_0));
    }

    public void method_0(GDelegate5 gdelegate5_1)
    {
        GDelegate5 objA = this.gdelegate5_0;
        while (true)
        {
            GDelegate5 comparand = objA;
            GDelegate5 delegate4 = comparand + gdelegate5_1;
            objA = Interlocked.CompareExchange<GDelegate5>(ref this.gdelegate5_0, delegate4, comparand);
            if (ReferenceEquals(objA, comparand))
            {
                return;
            }
        }
    }

    public void method_1(GDelegate5 gdelegate5_1)
    {
        GDelegate5 objA = this.gdelegate5_0;
        while (true)
        {
            GDelegate5 comparand = objA;
            GDelegate5 delegate4 = comparand - gdelegate5_1;
            objA = Interlocked.CompareExchange<GDelegate5>(ref this.gdelegate5_0, delegate4, comparand);
            if (ReferenceEquals(objA, comparand))
            {
                return;
            }
        }
    }

    public GClass1 method_10(string string_0)
    {
        return (GClass1) this.sortedList_0[string_0];
    }

    public GClass1 method_11(int int_1)
    {
        return (GClass1) this.sortedList_0[this.sortedList_0.GetKey(int_1)];
    }

    public bool method_12(string string_0)
    {
        return (this.method_10(string_0) != null);
    }

    public object method_13()
    {
        return this.sortedList_0.Count;
    }

    private void method_14(GClass1 gclass1_0)
    {
        this.method_9(gclass1_0);
        GDelegate5 delegate2 = this.gdelegate5_0;
        if (delegate2 != null)
        {
            delegate2(gclass1_0.method_13());
        }
    }

    private void method_15(string string_0, string string_1, string string_2, bool bool_0)
    {
        GDelegate7 delegate2 = this.gdelegate7_0;
        if (delegate2 != null)
        {
            delegate2(string_0, string_1, string_2, bool_0);
        }
        this.method_8(string_0);
        this.sortedList_0.Remove(string_0);
    }

    private void method_16(string string_0, byte[] byte_0)
    {
        GDelegate6 delegate2 = this.gdelegate6_0;
        if (delegate2 != null)
        {
            delegate2(string_0, byte_0);
        }
    }

    public void method_2(GDelegate7 gdelegate7_1)
    {
        GDelegate7 objA = this.gdelegate7_0;
        while (true)
        {
            GDelegate7 comparand = objA;
            GDelegate7 delegate4 = comparand + gdelegate7_1;
            objA = Interlocked.CompareExchange<GDelegate7>(ref this.gdelegate7_0, delegate4, comparand);
            if (ReferenceEquals(objA, comparand))
            {
                return;
            }
        }
    }

    public void method_3(GDelegate7 gdelegate7_1)
    {
        GDelegate7 objA = this.gdelegate7_0;
        while (true)
        {
            GDelegate7 comparand = objA;
            GDelegate7 delegate4 = comparand - gdelegate7_1;
            objA = Interlocked.CompareExchange<GDelegate7>(ref this.gdelegate7_0, delegate4, comparand);
            if (ReferenceEquals(objA, comparand))
            {
                return;
            }
        }
    }

    public void method_4(GDelegate6 gdelegate6_1)
    {
        GDelegate6 objA = this.gdelegate6_0;
        while (true)
        {
            GDelegate6 comparand = objA;
            GDelegate6 delegate4 = comparand + gdelegate6_1;
            objA = Interlocked.CompareExchange<GDelegate6>(ref this.gdelegate6_0, delegate4, comparand);
            if (ReferenceEquals(objA, comparand))
            {
                return;
            }
        }
    }

    public void method_5(GDelegate6 gdelegate6_1)
    {
        GDelegate6 objA = this.gdelegate6_0;
        while (true)
        {
            GDelegate6 comparand = objA;
            GDelegate6 delegate4 = comparand - gdelegate6_1;
            objA = Interlocked.CompareExchange<GDelegate6>(ref this.gdelegate6_0, delegate4, comparand);
            if (ReferenceEquals(objA, comparand))
            {
                return;
            }
        }
    }

    public void method_6()
    {
        this.vmethod_0().method_2();
    }

    public void method_7()
    {
        this.vmethod_0().method_3();
    }

    public void method_8(string string_0)
    {
        if (this.sortedList_0.ContainsKey(string_0))
        {
            ((GClass1) this.sortedList_0[string_0]).method_7();
        }
    }

    public void method_9(GClass1 gclass1_0)
    {
        this.sortedList_0.Add(gclass1_0.method_13(), gclass1_0);
        gclass1_0.method_0(new GClass1.GDelegate1(this.method_15));
        gclass1_0.method_2(new GClass1.GDelegate2(this.method_16));
    }

    private GClass8 vmethod_0()
    {
        return this.gclass8_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    private void vmethod_1(GClass8 gclass8_1)
    {
        GClass8.GDelegate8 delegate2 = new GClass8.GDelegate8(this.method_14);
        GClass8 class2 = this.gclass8_0;
        if (class2 != null)
        {
            class2.method_1(delegate2);
        }
        this.gclass8_0 = gclass8_1;
        class2 = this.gclass8_0;
        if (class2 != null)
        {
            class2.method_0(delegate2);
        }
    }

    public delegate void GDelegate5(string string_0);

    public delegate void GDelegate6(string string_0, byte[] byte_0);

    public delegate void GDelegate7(string string_0, string string_1, string string_2, bool bool_0);
}

