﻿using System;

internal sealed class Class102 : Class94
{
    private object object_0;

    public object method_2()
    {
        return this.object_0;
    }

    public void method_3(object object_1)
    {
        this.object_0 = object_1;
    }

    public override object vmethod_0()
    {
        return this.method_2();
    }

    public override void vmethod_1(object object_1)
    {
        this.method_3(object_1);
    }

    public override int vmethod_2()
    {
        return 4;
    }

    public override Class94 vmethod_3(Class94 class94_0)
    {
        base.method_1(class94_0.method_0());
        this.method_3(class94_0.vmethod_0());
        return this;
    }

    public override Class94 vmethod_4()
    {
        Class102 class1 = new Class102();
        class1.method_3(this.object_0);
        class1.method_1(base.method_0());
        return class1;
    }
}

