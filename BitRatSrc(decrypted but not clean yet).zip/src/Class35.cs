﻿using System;

internal sealed class Class35 : Class32
{
    private int int_0;
    private int int_1;

    public int method_0()
    {
        return this.int_0;
    }

    public void method_1(int int_2)
    {
        this.int_0 = int_2;
    }

    public int method_2()
    {
        return this.int_1;
    }

    public void method_3(int int_2)
    {
        this.int_1 = int_2;
    }

    public override byte vmethod_0()
    {
        return 3;
    }
}

