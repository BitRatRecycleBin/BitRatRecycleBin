﻿using System;

internal sealed class Class33 : Class32
{
    private string string_0;

    public string method_0()
    {
        return this.string_0;
    }

    public void method_1(string string_1)
    {
        this.string_0 = string_1;
    }

    public override byte vmethod_0()
    {
        return 2;
    }
}

