﻿using System;

internal sealed class Class111 : Class109
{
    private Array array_0;
    private int[] int_0;

    public Array method_4()
    {
        return this.array_0;
    }

    public void method_5(Array array_1)
    {
        this.array_0 = array_1;
    }

    public int[] method_6()
    {
        return this.int_0;
    }

    public void method_7(int[] int_1)
    {
        this.int_0 = int_1;
    }

    public override int vmethod_2()
    {
        return 0x10;
    }

    public override Class94 vmethod_3(Class94 class94_0)
    {
        base.method_1(class94_0.method_0());
        if (class94_0.vmethod_2() != 0x10)
        {
            throw new ArgumentOutOfRangeException();
        }
        Class111 class2 = (Class111) class94_0;
        this.method_5(class2.method_4());
        this.method_7(class2.method_6());
        base.method_3(class2.method_2());
        return this;
    }

    public override Class94 vmethod_4()
    {
        Class111 class1 = new Class111();
        class1.method_5(this.method_4());
        class1.method_7(this.method_6());
        class1.method_3(base.method_2());
        class1.method_1(base.method_0());
        return class1;
    }

    public override object vmethod_5()
    {
        return this.method_4().GetValue(this.method_6());
    }

    public override void vmethod_6(object object_0)
    {
        this.method_4().SetValue(object_0, this.method_6());
    }

    public override bool vmethod_7(Class109 class109_0)
    {
        Class111 class2 = (Class111) class109_0;
        return (ReferenceEquals(this.method_4(), class2.method_4()) && Class66.smethod_0(this.method_6(), class2.method_6()));
    }
}

