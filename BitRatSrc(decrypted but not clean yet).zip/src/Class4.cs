﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.ExceptionServices;
using System.Runtime.InteropServices;
using System.Security;
using System.Threading;

internal sealed class Class4
{
    private Class86 class86_0;
    private Dictionary<int, Class6> dictionary_0;
    private static Type type_0 = typeof(object[]);
    private byte[] byte_0;
    private static Type type_1 = typeof(void);
    private readonly Dictionary<Struct2, Delegate0> dictionary_1;
    private object[] object_0;
    private Type[] type_2;
    private Class25[] class25_0;
    private readonly Module module_0;
    private static Type type_3 = typeof(MethodBase);
    private Class29 class29_0;
    private Type type_4;
    private Class94[] class94_0;
    private static Type type_5 = typeof(Assembly);
    private long long_0;
    private static object object_1 = new object();
    private Dictionary<MethodBase, object> dictionary_2;
    private readonly Class16 class16_0;
    private static Type type_6 = typeof(RuntimeHelpers);
    private readonly Class20<Class94> class20_0;
    private Type[] type_7;
    private readonly Class20<Struct1> class20_1;
    private bool bool_0;
    private static readonly Dictionary<int, object> dictionary_3 = new Dictionary<int, object>();
    private object object_2;
    private readonly Dictionary<MethodBase, int> dictionary_4;
    private Stream stream_0;
    private bool bool_1;
    private static Type type_8 = typeof(IntPtr);
    private Class29 class29_1;
    private Class94[] class94_1;
    private static readonly Dictionary<MethodBase, DynamicMethod> dictionary_5 = new Dictionary<MethodBase, DynamicMethod>();
    private uint? nullable_0;

    public Class4(Class16 class16_1) : this(class16_1, typeof(Class4).Module)
    {
    }

    public Class4(Class16 class16_1, Module module_1)
    {
        this.dictionary_1 = new Dictionary<Struct2, Delegate0>(0x100);
        this.dictionary_4 = new Dictionary<MethodBase, int>(0x100);
        this.dictionary_2 = new Dictionary<MethodBase, object>();
        this.class20_1 = new Class20<Struct1>();
        this.class20_0 = new Class20<Class94>();
        this.class16_0 = class16_1;
        this.module_0 = module_1;
        this.method_233();
    }

    private FieldInfo method_0(int int_0, Class3 class3_0, ref bool bool_2)
    {
        if (class3_0.method_0() == 1)
        {
            bool_2 = false;
            return this.module_0.ResolveField(class3_0.method_2());
        }
        Class36 class2 = (Class36) class3_0.method_4();
        Type type1 = this.method_189(class2.method_0().method_2(), false);
        if (type1.IsGenericType)
        {
            bool_2 = false;
        }
        BindingFlags bindingAttr = smethod_12(class2.method_4());
        return type1.GetField(class2.method_2(), bindingAttr);
    }

    private Class94 method_1(Class94 class94_2, Class94 class94_3)
    {
        if (class94_2.vmethod_2() == 7)
        {
            if (class94_3.vmethod_2() == 7)
            {
                int num3 = ((Class118) class94_2).method_2();
                Class118 class1 = new Class118();
                class1.method_3(num3 & ((Class118) class94_3).method_2());
                return class1;
            }
            if (class94_3.vmethod_2() == 0x18)
            {
                int num = ((Class118) class94_2).method_2();
                Type underlyingType = Enum.GetUnderlyingType(class94_3.vmethod_0().GetType());
                if (!ReferenceEquals(underlyingType, typeof(long)) && !ReferenceEquals(underlyingType, typeof(ulong)))
                {
                    Class118 class2 = new Class118();
                    class2.method_3(num & Convert.ToInt32(class94_3.vmethod_0()));
                    return class2;
                }
                long num5 = Convert.ToInt64(class94_3.vmethod_0());
                Class99 class3 = new Class99();
                class3.method_3(num & num5);
                return class3;
            }
        }
        if (class94_2.vmethod_2() == 11)
        {
            if (class94_3.vmethod_2() == 11)
            {
                long num7 = ((Class99) class94_2).method_2();
                Class99 class4 = new Class99();
                class4.method_3(num7 & ((Class99) class94_3).method_2());
                return class4;
            }
            if (class94_3.vmethod_2() == 0x18)
            {
                int num9 = ((Class118) class94_2).method_2();
                long num10 = Convert.ToInt64(class94_3.vmethod_0());
                Class99 class5 = new Class99();
                class5.method_3(num9 & num10);
                return class5;
            }
        }
        if (class94_2.vmethod_2() == 0x18)
        {
            if (class94_3.vmethod_2() == 7)
            {
                int num2 = ((Class118) class94_3).method_2();
                Type underlyingType = Enum.GetUnderlyingType(class94_2.vmethod_0().GetType());
                if (!ReferenceEquals(underlyingType, typeof(long)) && !ReferenceEquals(underlyingType, typeof(ulong)))
                {
                    int num12 = Convert.ToInt32(class94_2.vmethod_0());
                    Class118 class6 = new Class118();
                    class6.method_3(num12 & num2);
                    return class6;
                }
                long num11 = Convert.ToInt64(class94_3.vmethod_0());
                Class99 class7 = new Class99();
                class7.method_3(num11 & num2);
                return class7;
            }
            if (class94_3.vmethod_2() == 11)
            {
                long num13 = Convert.ToInt64(class94_2.vmethod_0());
                Class99 class8 = new Class99();
                class8.method_3(num13 & ((Class99) class94_3).method_2());
                return class8;
            }
            if (class94_3.vmethod_2() == 0x18)
            {
                Type underlyingType = Enum.GetUnderlyingType(class94_2.vmethod_0().GetType());
                Type objA = Enum.GetUnderlyingType(class94_3.vmethod_0().GetType());
                if (!ReferenceEquals(underlyingType, typeof(long)) && (!ReferenceEquals(underlyingType, typeof(ulong)) && (!ReferenceEquals(objA, typeof(long)) && !ReferenceEquals(objA, typeof(ulong)))))
                {
                    int num17 = Convert.ToInt32(class94_2.vmethod_0());
                    Class118 class9 = new Class118();
                    class9.method_3(num17 & Convert.ToInt32(class94_3.vmethod_0()));
                    return class9;
                }
                long num15 = Convert.ToInt64(class94_2.vmethod_0());
                Class99 class10 = new Class99();
                class10.method_3(num15 & Convert.ToInt64(class94_3.vmethod_0()));
                return class10;
            }
        }
        throw new InvalidOperationException();
    }

    private bool method_10(MethodBase methodBase_0, object object_3, Class94[] class94_2, object[] object_4, bool bool_2, ref object object_5)
    {
        Type declaringType = methodBase_0.DeclaringType;
        if (declaringType == null)
        {
            return false;
        }
        if ((!ReferenceEquals(declaringType, type_6) || ((methodBase_0.Name != "InitializeArray") || (object_4.Length != 2))) || (methodBase_0.ToString() != "Void InitializeArray(System.Array, System.RuntimeFieldHandle)"))
        {
            return false;
        }
        Class10.smethod_0((Array) object_4[0], (RuntimeFieldHandle) object_4[1]);
        return true;
    }

    private void method_100(Class94 class94_2)
    {
        this.method_109(typeof(uint));
    }

    private void method_101(Class94 class94_2)
    {
        Class94 class3 = this.method_300();
        this.method_195(this.method_21(class3, this.method_300(), false));
    }

    private void method_102(Class94 class94_2)
    {
        this.method_195(this.class94_1[3].vmethod_4());
    }

    private void method_103(Class94 class94_2)
    {
        throw new NotSupportedException("Arglist is not supported.");
    }

    private bool method_104(MethodBase methodBase_0, object object_3, ref object object_4, object[] object_5)
    {
        Type declaringType = methodBase_0.DeclaringType;
        if (declaringType != null)
        {
            int num;
            object[] objArray;
            if (Class58.smethod_0(declaringType))
            {
                if (string.Equals(methodBase_0.Name, "get_HasValue", StringComparison.Ordinal))
                {
                    object_4 = object_3 != null;
                }
                else if (string.Equals(methodBase_0.Name, "get_Value", StringComparison.Ordinal))
                {
                    if (object_3 == null)
                    {
                        bool? nullable = null;
                        return nullable.Value;
                    }
                    object_4 = object_3;
                }
                else if (methodBase_0.Name.Equals("GetValueOrDefault", StringComparison.Ordinal))
                {
                    if (object_3 == null)
                    {
                        object_4 = Activator.CreateInstance(Nullable.GetUnderlyingType(methodBase_0.DeclaringType));
                    }
                    object_4 = object_3;
                }
                else
                {
                    if ((object_3 != null) || methodBase_0.IsStatic)
                    {
                        return false;
                    }
                    object_4 = null;
                }
                return true;
            }
            if (ReferenceEquals(declaringType, type_5))
            {
                if (methodBase_0.Name.Equals("GetExecutingAssembly", StringComparison.Ordinal))
                {
                    object_4 = Class58.assembly_0;
                    return true;
                }
                if ((this.object_0 != null) && (methodBase_0.Name == "GetCallingAssembly"))
                {
                    Assembly assembly = null;
                    objArray = this.object_0;
                    num = 0;
                    while (num < objArray.Length)
                    {
                        assembly = objArray[num] as Assembly;
                        if (assembly != null)
                        {
                            object_4 = assembly;
                            return true;
                        }
                        num++;
                    }
                }
            }
            else
            {
                if (!ReferenceEquals(declaringType, type_3))
                {
                    return (declaringType.IsArray && ((declaringType.GetArrayRank() >= 2) && this.method_165(methodBase_0, object_3, ref object_4, object_5)));
                }
                if (methodBase_0.Name == "GetCurrentMethod")
                {
                    if (this.object_0 != null)
                    {
                        MethodBase base2 = null;
                        objArray = this.object_0;
                        for (num = 0; num < objArray.Length; num++)
                        {
                            base2 = objArray[num] as MethodBase;
                            if (base2 != null)
                            {
                                object_4 = base2;
                                return true;
                            }
                        }
                    }
                    object_4 = MethodBase.GetCurrentMethod();
                    return true;
                }
            }
        }
        return false;
    }

    private void method_105(Class94 class94_2)
    {
        int num = ((Class118) class94_2).method_2();
        Type type = this.method_189(num, true);
        this.method_144(type);
    }

    private void method_106(Class94 class94_2)
    {
        Class94 class2 = this.method_300();
        this.method_195(this.method_42(class2));
    }

    private void method_107(Class94 class94_2)
    {
        this.method_245(false);
    }

    private void method_108(Class94 class94_2)
    {
        int num = ((Class118) class94_2).method_2();
        Type t = this.method_189(num, true);
        Class118 class1 = new Class118();
        class1.method_3(Marshal.SizeOf(t));
        this.method_195(class1);
    }

    private void method_109(Type type_9)
    {
        Class106 class2 = (Class106) this.method_300();
        this.method_195(Class30.smethod_1(this.method_255(class2).vmethod_0(), type_9));
    }

    private long method_11(string string_0)
    {
        MemoryStream stream = new MemoryStream(Class53.smethod_0(string_0));
        stream.Dispose();
        return new Class29(new Class49(stream, this.method_57())).method_21();
    }

    private void method_110(Class94 class94_2)
    {
        this.method_265(typeof(float));
    }

    private void method_111(Class94 class94_2)
    {
        Class94 class3 = this.method_300();
        Class118 class1 = new Class118();
        Class118 class4 = new Class118();
        class4.method_3(smethod_29(class3, this.method_300()) ? 1 : 0);
        this.method_195(class4);
    }

    private void method_112(Class94 class94_2)
    {
        Class94 class2 = this.method_300();
        Class94 class3 = this.method_300();
        if ((class3.vmethod_2() != 0x11) ? !smethod_18(class3, class2) : !smethod_29(class3, class2))
        {
            uint num = ((Class104) class94_2).method_2();
            this.method_244(num);
        }
    }

    private void method_113(Class94 class94_2)
    {
        int num = ((Class118) class94_2).method_2();
        FieldInfo info = this.method_71(num);
        this.method_195(new Class107(info, null));
    }

    private void method_114(Class94 class94_2)
    {
        this.method_291(((Class121) class94_2).method_2());
    }

    private void method_115(Class94 class94_2)
    {
        Class94 class3 = this.method_300();
        this.method_195(this.method_16(class3, this.method_300(), false, false));
    }

    private void method_116(Class94 class94_2)
    {
        this.method_291(2);
    }

    private void method_117(Class94 class94_2)
    {
        this.method_245(true);
    }

    [DebuggerNonUserCode]
    private MethodBase method_118(int int_0, Class3 class3_0)
    {
        MethodBase base2;
        object obj2;
        Monitor.Enter(dictionary_3);
        bool flag = true;
        if (dictionary_3.TryGetValue(int_0, out obj2))
        {
            base2 = (MethodBase) obj2;
        }
        else if (class3_0.method_0() == 1)
        {
            MethodBase base4 = this.module_0.ResolveMethod(class3_0.method_2());
            if (flag)
            {
                dictionary_3.Add(int_0, base4);
            }
            base2 = base4;
        }
        else
        {
            Class34 class2 = (Class34) class3_0.method_4();
            if (class2.method_3())
            {
                base2 = this.method_243(class2);
            }
            else
            {
                Type type = this.method_189(class2.method_4().method_2(), false);
                this.method_189(class2.method_12().method_2(), true);
                Type[] types = new Type[class2.method_8().Length];
                int index = 0;
                while (true)
                {
                    if (index >= types.Length)
                    {
                        if (type.IsGenericType)
                        {
                            flag = false;
                        }
                        if (class2.method_6() == ".ctor")
                        {
                            ConstructorInfo info2 = type.GetConstructor(BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance, null, CallingConventions.Any, types, null);
                            if (info2 == null)
                            {
                                throw new Exception();
                            }
                            if (flag)
                            {
                                dictionary_3.Add(int_0, info2);
                            }
                            base2 = info2;
                        }
                        else
                        {
                            BindingFlags bindingAttr = smethod_12(class2.method_2());
                            MethodBase base3 = null;
                            base3 = type.GetMethod(class2.method_6(), bindingAttr, null, CallingConventions.Any, types, null);
                            if (base3 == null)
                            {
                                throw new Exception(string.Format("Cannot bind method: {0}.{1}", type.Name, class2.method_6()));
                            }
                            if (flag)
                            {
                                dictionary_3.Add(int_0, base3);
                            }
                            base2 = base3;
                        }
                        break;
                    }
                    types[index] = this.method_189(class2.method_8()[index].method_2(), true);
                    index++;
                }
            }
        }
        return base2;
    }

    private void method_119(Class94 class94_2)
    {
        throw new NotSupportedException("Refanyval is not supported.");
    }

    private void method_12(Class94 class94_2)
    {
        MethodBase base2 = this.method_234(((Class118) class94_2).method_2());
        if (this.type_4 != null)
        {
            ParameterInfo[] parameters = base2.GetParameters();
            Type[] types = new Type[parameters.Length];
            int num2 = 0;
            ParameterInfo[] infoArray = parameters;
            int index = 0;
            while (true)
            {
                if (index >= infoArray.Length)
                {
                    MethodInfo info = this.type_4.GetMethod(base2.Name, BindingFlags.SetProperty | BindingFlags.GetProperty | BindingFlags.InvokeMethod | BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance, null, types, null);
                    if (info != null)
                    {
                        base2 = info;
                    }
                    this.type_4 = null;
                    break;
                }
                ParameterInfo info2 = infoArray[index];
                types[num2++] = info2.ParameterType;
                index++;
            }
        }
        this.method_124(base2, true);
    }

    private void method_120(Class94 class94_2)
    {
        Class94 class2 = this.method_300();
        if (smethod_18(this.method_300(), class2))
        {
            uint num = ((Class104) class94_2).method_2();
            this.method_244(num);
        }
    }

    private void method_121(Class94 class94_2)
    {
        object fieldHandle;
        int num = ((Class118) class94_2).method_2();
        Class3 class2 = this.method_130(num);
        if (class2.method_0() == 1)
        {
            fieldHandle = this.method_4(class2.method_2());
        }
        else
        {
            switch (class2.method_4().vmethod_0())
            {
                case 0:
                    fieldHandle = this.method_71(num).FieldHandle;
                    break;

                case 1:
                    fieldHandle = this.method_189(num, true).TypeHandle;
                    break;

                case 4:
                    fieldHandle = this.method_234(num).MethodHandle;
                    break;

                default:
                    throw new InvalidOperationException();
            }
        }
        Class102 class1 = new Class102();
        class1.method_3(fieldHandle);
        this.method_195(class1);
    }

    private void method_122(Class94 class94_2)
    {
        MethodBase base2 = this.method_234(((Class118) class94_2).method_2());
        foreach (Class94 class3 in this.class94_0)
        {
            this.method_195(class3);
        }
        this.method_124(base2, false);
    }

    private void method_123(Class94 class94_2)
    {
        int num2;
        Class94 class2 = this.method_300();
        int num = class2.vmethod_2();
        if (num > 11)
        {
            if (num == 0x11)
            {
                num2 = (int) ((Class117) class2).method_2();
            }
            else if (num == 0x18)
            {
                num2 = (int) Convert.ToUInt64(((Class98) class2).method_2());
            }
            else
            {
                goto TR_0000;
            }
        }
        else if (num == 7)
        {
            num2 = (int) ((uint) ((Class118) class2).method_2());
        }
        else if (num == 11)
        {
            num2 = (int) ((ulong) ((Class99) class2).method_2());
        }
        else
        {
            goto TR_0000;
        }
        Class118 class1 = new Class118();
        class1.method_3(num2);
        this.method_195(class1);
        return;
    TR_0000:
        throw new InvalidOperationException();
    }

    private void method_124(MethodBase methodBase_0, bool bool_2)
    {
        if (!bool_2 && this.method_278(methodBase_0))
        {
            methodBase_0 = this.method_15(methodBase_0, bool_2);
        }
        ParameterInfo[] parameters = methodBase_0.GetParameters();
        int length = parameters.Length;
        Class94[] classArray = new Class94[length];
        object[] args = new object[length];
        Struct0 struct2 = new Struct0();
        this.method_200(ref struct2, methodBase_0, bool_2);
        for (int i = length - 1; i >= 0; i--)
        {
            Class94 class3 = this.method_300();
            classArray[i] = class3;
            Class106 class6 = class3 as Class106;
            if (class6 != null)
            {
                class3 = this.method_255(class6);
            }
            if (class3.method_0() != null)
            {
                class3 = Class30.smethod_1(null, class3.method_0()).vmethod_3(class3);
            }
            args[i] = Class30.smethod_1(null, parameters[i].ParameterType).vmethod_3(class3).vmethod_0();
        }
        Class94 class2 = null;
        if (!methodBase_0.IsStatic)
        {
            class2 = this.method_300();
            if ((class2 != null) && (class2.method_0() != null))
            {
                class2 = Class30.smethod_1(null, class2.method_0()).vmethod_3(class2);
            }
        }
        object obj3 = null;
        if (methodBase_0.IsConstructor)
        {
            obj3 = Activator.CreateInstance(methodBase_0.DeclaringType, BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance, null, args, null);
            Class106 class4 = class2 as Class106;
            if (class4 == null)
            {
                throw new InvalidOperationException();
            }
            this.method_142(class4, Class30.smethod_1(obj3, methodBase_0.DeclaringType));
        }
        else
        {
            object obj2 = null;
            if (class2 != null)
            {
                Class94 class5 = class2;
                Class106 class8 = class2 as Class106;
                if (class8 != null)
                {
                    class5 = this.method_255(class8);
                }
                obj2 = class5.vmethod_0();
            }
            if (!this.method_104(methodBase_0, obj2, ref obj3, args))
            {
                if (bool_2 && (!methodBase_0.IsStatic && (obj2 == null)))
                {
                    throw new NullReferenceException();
                }
                if (!this.method_10(methodBase_0, obj2, classArray, args, bool_2, ref obj3))
                {
                    obj3 = this.method_159(methodBase_0, obj2, args, bool_2);
                }
            }
            Class106 class9 = class2 as Class106;
            if (class9 != null)
            {
                this.method_142(class9, Class30.smethod_1(obj2, methodBase_0.DeclaringType));
            }
        }
        MethodInfo info = methodBase_0 as MethodInfo;
        if (info != null)
        {
            Type returnType = info.ReturnType;
            if (!ReferenceEquals(returnType, type_1))
            {
                this.method_195(Class30.smethod_1(obj3, returnType));
            }
        }
    }

    private void method_125(Class94 class94_2)
    {
        int num2 = ((Class118) class94_2).method_2();
        Type type = this.method_189(num2, true);
        Class106 class2 = (Class106) this.method_300();
        if (!type.IsValueType)
        {
            this.method_142(class2, new Class102());
        }
        else
        {
            object obj2 = this.method_255(class2).vmethod_0();
            if (Class58.smethod_0(type))
            {
                Class102 class1 = new Class102();
                class1.method_1(type);
                this.method_142(class2, class1);
            }
            else
            {
                foreach (FieldInfo info in type.GetFields(BindingFlags.FlattenHierarchy | BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance))
                {
                    info.SetValue(obj2, smethod_19(info.FieldType));
                }
            }
        }
    }

    private void method_126(Class94 class94_2)
    {
        this.method_291(1);
    }

    private Class94 method_127(Class94 class94_2, Class94 class94_3)
    {
        if (class94_2.vmethod_2() == 7)
        {
            if (class94_3.vmethod_2() == 7)
            {
                int num2 = ((Class118) class94_2).method_2() << (((Class118) class94_3).method_2() & 0x1f);
                Class118 class1 = new Class118();
                class1.method_3(num2);
                return class1;
            }
            if (class94_3.vmethod_2() == 0x18)
            {
                Class118 class2 = new Class118();
                class2.method_3(Convert.ToInt32(class94_3.vmethod_0()));
                return this.method_127(class94_2, class2);
            }
        }
        if (class94_2.vmethod_2() == 11)
        {
            if (class94_3.vmethod_2() == 7)
            {
                long num4 = ((Class99) class94_2).method_2() << (((Class118) class94_3).method_2() & 0x3f);
                Class99 class3 = new Class99();
                class3.method_3(num4);
                return class3;
            }
            if (class94_3.vmethod_2() == 0x18)
            {
                Class118 class4 = new Class118();
                class4.method_3(Convert.ToInt32(class94_3.vmethod_0()));
                return this.method_127(class94_2, class4);
            }
        }
        if (class94_2.vmethod_2() != 0x18)
        {
            throw new InvalidOperationException();
        }
        Type underlyingType = Enum.GetUnderlyingType(class94_2.vmethod_0().GetType());
        if (!ReferenceEquals(underlyingType, typeof(long)) && !ReferenceEquals(underlyingType, typeof(ulong)))
        {
            Class118 class5 = new Class118();
            class5.method_3(Convert.ToInt32(class94_2.vmethod_0()));
            return this.method_127(class5, class94_3);
        }
        Class99 class6 = new Class99();
        class6.method_3(Convert.ToInt64(class94_2.vmethod_0()));
        return this.method_127(class6, class94_3);
    }

    private void method_128(Stream stream_1, string string_0)
    {
        this.method_22(stream_1, 0L, string_0);
    }

    private Class12[] method_129(Class29 class29_2)
    {
        Class12[] classArray = new Class12[class29_2.method_23()];
        for (int i = 0; i < classArray.Length; i++)
        {
            classArray[i] = this.method_69(class29_2);
        }
        return classArray;
    }

    private void method_13(Class94 class94_2)
    {
        int num = ((Class118) class94_2).method_2();
        Class94 class2 = this.method_300();
        if (!this.method_281(class2, this.method_189(num, true)))
        {
            throw new InvalidCastException();
        }
        this.method_195(class2);
    }

    private Class3 method_130(int int_0)
    {
        if (this.class29_1 == null)
        {
            throw new InvalidOperationException();
        }
        Monitor.Enter(this.class29_1.method_0());
        this.class29_1.method_0().vmethod_9((long) int_0, 0);
        Class3 class3 = new Class3();
        class3.method_1(this.class29_1.method_6());
        if (class3.method_0() == 1)
        {
            class3.method_3(this.class29_1.method_19());
        }
        else
        {
            class3.method_5(this.method_187(this.class29_1));
        }
        return class3;
    }

    private Class94 method_131(Class94 class94_2, Class94 class94_3, bool bool_2, bool bool_3)
    {
        if (class94_2.vmethod_2() == 7)
        {
            if (class94_3.vmethod_2() == 7)
            {
                if (!bool_3)
                {
                    int num = ((Class118) class94_2).method_2();
                    int num2 = ((Class118) class94_3).method_2();
                    int num3 = !bool_2 ? (num - num2) : (num - num2);
                    Class118 class1 = new Class118();
                    class1.method_3(num3);
                    return class1;
                }
                uint num4 = (uint) ((Class118) class94_2).method_2();
                uint num5 = (uint) ((Class118) class94_3).method_2();
                uint num6 = !bool_2 ? (num4 - num5) : (num4 - num5);
                Class118 class2 = new Class118();
                class2.method_3((int) num6);
                return class2;
            }
            if (class94_3.vmethod_2() == 11)
            {
                Class99 class3 = new Class99();
                class3.method_3((long) ((Class118) class94_2).method_2());
                return smethod_3(class3, class94_3, bool_2, bool_3);
            }
            if (class94_3.vmethod_2() == 0x18)
            {
                Type objA = Enum.GetUnderlyingType(class94_3.vmethod_0().GetType());
                if (!ReferenceEquals(objA, typeof(long)) && !ReferenceEquals(objA, typeof(ulong)))
                {
                    Class118 class4 = new Class118();
                    class4.method_3(Convert.ToInt32(class94_3.vmethod_0()));
                    return this.method_131(class94_2, class4, bool_2, bool_3);
                }
                Class99 class5 = new Class99();
                class5.method_3((long) ((Class118) class94_2).method_2());
                Class99 class6 = new Class99();
                class6.method_3(Convert.ToInt64(class94_3.vmethod_0()));
                return smethod_3(class5, class6, bool_2, bool_3);
            }
        }
        if (class94_2.vmethod_2() == 11)
        {
            if (class94_3.vmethod_2() == 11)
            {
                return smethod_3(class94_2, class94_3, bool_2, bool_3);
            }
            if (class94_3.vmethod_2() == 7)
            {
                Class99 class7 = new Class99();
                class7.method_3((long) ((Class118) class94_3).method_2());
                return smethod_3(class94_2, class7, bool_2, bool_3);
            }
            if (class94_3.vmethod_2() == 0x18)
            {
                Type objA = Enum.GetUnderlyingType(class94_3.vmethod_0().GetType());
                if (!ReferenceEquals(objA, typeof(long)) && !ReferenceEquals(objA, typeof(ulong)))
                {
                    Class118 class8 = new Class118();
                    class8.method_3(Convert.ToInt32(class94_3.vmethod_0()));
                    return smethod_3(class94_2, class8, bool_2, bool_3);
                }
                Class99 class9 = new Class99();
                class9.method_3(Convert.ToInt64(class94_3.vmethod_0()));
                return smethod_3(class94_2, class9, bool_2, bool_3);
            }
        }
        if ((class94_2.vmethod_2() == 0x11) && (class94_3.vmethod_2() == 0x11))
        {
            Class117 class10 = new Class117();
            class10.method_3(((Class117) class94_2).method_2() - ((Class117) class94_3).method_2());
            return class10;
        }
        if (class94_2.vmethod_2() != 0x18)
        {
            throw new InvalidOperationException();
        }
        Type underlyingType = Enum.GetUnderlyingType(class94_2.vmethod_0().GetType());
        if (!ReferenceEquals(underlyingType, typeof(long)) && !ReferenceEquals(underlyingType, typeof(ulong)))
        {
            Class118 class11 = new Class118();
            class11.method_3(Convert.ToInt32(class94_2.vmethod_0()));
            return this.method_131(class11, class94_3, bool_2, bool_3);
        }
        Class99 class12 = new Class99();
        class12.method_3(Convert.ToInt64(class94_2.vmethod_0()));
        return this.method_131(class12, class94_3, bool_2, bool_3);
    }

    private void method_132(Class94 class94_2)
    {
        int num = ((Class118) class94_2).method_2();
        Type type = this.method_189(num, true);
        Class94 class2 = Class30.smethod_1(this.method_300().vmethod_0(), type);
        class2.method_1(type);
        this.method_195(class2);
    }

    private void method_133(Class94 class94_2)
    {
        this.method_195(class94_2);
    }

    private void method_134(Class94 class94_2)
    {
        int num = ((Class118) class94_2).method_2();
        string str = this.method_17(num);
        Class113 class1 = new Class113();
        class1.method_3(str);
        this.method_195(class1);
    }

    private void method_135(MemberInfo memberInfo_0)
    {
        MemberInfo declaringType;
        bool flag;
        Assembly assembly;
        if (!smethod_5() || this.class86_0.method_13())
        {
            return;
        }
        else
        {
            flag = false;
            assembly = typeof(SecurityCriticalAttribute).Assembly;
            declaringType = memberInfo_0;
        }
        goto TR_0015;
    TR_0008:
        if (flag)
        {
            if (memberInfo_0 is MethodBase)
            {
                string str2 = smethod_21((MethodBase) memberInfo_0);
                throw smethod_11(this.method_192(this.class86_0), str2);
            }
            if (memberInfo_0 is FieldInfo)
            {
                Type declaringType = memberInfo_0.DeclaringType;
                string str3 = string.Format("{0}.{1}", declaringType.FullName, memberInfo_0.Name);
                throw smethod_0(this.method_192(this.class86_0), str3);
            }
            if (!(memberInfo_0 is Type))
            {
                throw new SecurityException("A caller does not have the permissions required to access a resource.");
            }
            string fullName = ((Type) memberInfo_0).FullName;
            throw smethod_16(this.method_192(this.class86_0), fullName);
        }
        return;
    TR_0015:
        while (true)
        {
            if (declaringType != null)
            {
                object[] customAttributes = declaringType.GetCustomAttributes(false);
                int index = 0;
                while (true)
                {
                    if (index < customAttributes.Length)
                    {
                        Type type = customAttributes[index].GetType();
                        if (ReferenceEquals(type.Assembly, assembly))
                        {
                            string fullName = type.FullName;
                            if ("System.Security.SecurityCriticalAttribute".Equals(fullName, StringComparison.Ordinal))
                            {
                                flag = true;
                                break;
                            }
                            if ("System.Security.SecuritySafeCriticalAttribute".Equals(fullName, StringComparison.Ordinal))
                            {
                                break;
                            }
                        }
                        index++;
                        continue;
                    }
                    declaringType = declaringType.DeclaringType;
                }
                goto TR_0008;
            }
            else
            {
                goto TR_0008;
            }
        }
        goto TR_0015;
    }

    private void method_136(Class94 class94_2)
    {
        this.method_44(false);
    }

    private void method_137(Class94 class94_2)
    {
        int num = ((Class118) class94_2).method_2();
        FieldInfo info = this.method_71(num);
        this.method_195(Class30.smethod_1(info.GetValue(null), info.FieldType));
    }

    private void method_138(Class94 class94_2)
    {
        Debugger.Break();
    }

    public void method_139(Stream stream_1, string string_0, object[] object_3)
    {
        this.method_256(stream_1, string_0, object_3);
    }

    private void method_14(Class94 class94_2)
    {
        sbyte num2;
        Class94 class2 = this.method_300();
        int num = class2.vmethod_2();
        if (num > 11)
        {
            if (num == 0x11)
            {
                num2 = (sbyte) ((Class117) class2).method_2();
            }
            else if (num == 0x18)
            {
                num2 = (sbyte) Convert.ToUInt64(((Class98) class2).method_2());
            }
            else
            {
                goto TR_0000;
            }
        }
        else if (num == 7)
        {
            num2 = (sbyte) ((uint) ((Class118) class2).method_2());
        }
        else if (num == 11)
        {
            num2 = (sbyte) ((ulong) ((Class99) class2).method_2());
        }
        else
        {
            goto TR_0000;
        }
        Class118 class1 = new Class118();
        class1.method_3(num2);
        this.method_195(class1);
        return;
    TR_0000:
        throw new InvalidOperationException();
    }

    private void method_140(Class94 class94_2)
    {
        throw new NotSupportedException("Mkrefany is not supported.");
    }

    private void method_141(Class94 class94_2)
    {
        Class94 class3 = this.method_300();
        this.method_195(this.method_229(class3, this.method_300()));
    }

    private void method_142(Class106 class106_0, Class94 class94_2)
    {
        int num = class106_0.vmethod_2();
        if (num != 3)
        {
            switch (num)
            {
                case 12:
                    ((Class112) class106_0).method_2().vmethod_3(class94_2);
                    return;

                case 13:
                    this.class94_1[((Class108) class106_0).method_2()].vmethod_3(class94_2);
                    return;

                case 0x10:
                    break;

                case 0x12:
                {
                    Class107 class2 = (Class107) class106_0;
                    FieldInfo info = class2.method_4();
                    info.SetValue(class2.method_2(), Class30.smethod_1(class94_2.vmethod_0(), info.FieldType).vmethod_0());
                    Class106 class3 = class2.method_6();
                    if ((class3 != null) && info.DeclaringType.IsValueType)
                    {
                        this.method_142(class3, Class30.smethod_1(class2.method_2(), null));
                    }
                    return;
                }
                default:
                    throw new ArgumentOutOfRangeException();
            }
        }
        Class109 class4 = (Class109) class106_0;
        class4.vmethod_6(Class30.smethod_1(class94_2.vmethod_0(), class4.method_2()).vmethod_0());
    }

    private void method_143(Class94 class94_2)
    {
        Class121 class2 = (Class121) class94_2;
        this.method_195(this.class94_0[class2.method_2()].vmethod_4());
    }

    private void method_144(Type type_9)
    {
        object obj2 = this.method_300().vmethod_0();
        this.method_147(type_9, obj2, this.method_55(), (Array) this.method_300().vmethod_0());
    }

    private void method_145(Class94 class94_2)
    {
        this.method_275();
    }

    private void method_146(Class94 class94_2)
    {
        this.method_291(3);
    }

    private void method_147(Type type_9, object object_3, long long_1, Array array_0)
    {
        array_0.SetValue(Class30.smethod_1(object_3, type_9).vmethod_0(), long_1);
    }

    private void method_148(Class94 class94_2)
    {
        Class94 class2 = this.method_300();
        if (smethod_14(this.method_300(), class2))
        {
            uint num = ((Class104) class94_2).method_2();
            this.method_244(num);
        }
    }

    private void method_149(Class94 class94_2)
    {
        this.method_258(true);
    }

    private MethodBase method_15(MethodBase methodBase_0, bool bool_2)
    {
        MethodBase base2;
        lock (dictionary_5)
        {
            DynamicMethod method;
            if (dictionary_5.TryGetValue(methodBase_0, out method))
            {
                base2 = method;
            }
            else
            {
                Type[] typeArray;
                string name = string.Empty;
                MethodInfo info = methodBase_0 as MethodInfo;
                Type returnType = (info == null) ? type_1 : info.ReturnType;
                ParameterInfo[] parameters = methodBase_0.GetParameters();
                if (methodBase_0.IsStatic)
                {
                    typeArray = new Type[parameters.Length];
                    for (int i = 0; i < parameters.Length; i++)
                    {
                        typeArray[i] = parameters[i].ParameterType;
                    }
                }
                else
                {
                    typeArray = new Type[parameters.Length + 1];
                    Type declaringType = methodBase_0.DeclaringType;
                    if (declaringType.IsValueType)
                    {
                        declaringType = declaringType.MakeByRefType();
                        bool_2 = false;
                    }
                    typeArray[0] = declaringType;
                    for (int i = 0; i < parameters.Length; i++)
                    {
                        typeArray[i + 1] = parameters[i].ParameterType;
                    }
                }
                if (method == null)
                {
                    method = new DynamicMethod(name, returnType, typeArray, this.method_189(this.class86_0.method_6(), true), true);
                }
                ILGenerator iLGenerator = method.GetILGenerator();
                int arg = 0;
                while (true)
                {
                    if (arg >= typeArray.Length)
                    {
                        ConstructorInfo con = methodBase_0 as ConstructorInfo;
                        if (con != null)
                        {
                            iLGenerator.Emit(bool_2 ? OpCodes.Callvirt : OpCodes.Call, con);
                        }
                        else
                        {
                            iLGenerator.Emit(bool_2 ? OpCodes.Callvirt : OpCodes.Call, (MethodInfo) methodBase_0);
                        }
                        iLGenerator.Emit(OpCodes.Ret);
                        dictionary_5.Add(methodBase_0, method);
                        base2 = method;
                        break;
                    }
                    iLGenerator.Emit(OpCodes.Ldarg, arg);
                    arg++;
                }
            }
        }
        return base2;
    }

    private void method_150(bool bool_2)
    {
        short num2;
        Class94 class2 = this.method_300();
        int num = class2.vmethod_2();
        if (num > 11)
        {
            if (num == 0x11)
            {
                num2 = !bool_2 ? ((short) ((Class117) class2).method_2()) : ((short) ((Class117) class2).method_2());
            }
            else if (num == 0x18)
            {
                num2 = !bool_2 ? ((short) Convert.ToUInt64(((Class98) class2).method_2())) : ((short) Convert.ToUInt64(((Class98) class2).method_2()));
            }
            else
            {
                goto TR_0000;
            }
        }
        else if (num == 7)
        {
            num2 = !bool_2 ? ((short) ((Class118) class2).method_2()) : ((short) ((Class118) class2).method_2());
        }
        else if (num == 11)
        {
            num2 = !bool_2 ? ((short) ((Class99) class2).method_2()) : ((short) ((Class99) class2).method_2());
        }
        else
        {
            goto TR_0000;
        }
        Class118 class1 = new Class118();
        class1.method_3(num2);
        this.method_195(class1);
        return;
    TR_0000:
        throw new InvalidOperationException();
    }

    private void method_151(Class94 class94_2)
    {
        uint num = ((Class104) class94_2).method_2();
        this.method_298(null, num);
    }

    private void method_152()
    {
        Class6 class2;
        long num = this.class29_0.method_0().vmethod_4();
        int key = this.class29_0.method_19();
        if (!this.dictionary_0.TryGetValue(key, out class2))
        {
            throw new InvalidOperationException("Unsupported instruction.");
        }
        this.long_0 = num;
        class2.delegate1_0(this.method_230(this.class29_0, class2.class31_0.method_2()));
    }

    private void method_153(Class94 class94_2)
    {
        uint num2;
        Class94 class2 = this.method_300();
        int num = class2.vmethod_2();
        if (num > 11)
        {
            if (num == 0x11)
            {
                num2 = (uint) ((Class117) class2).method_2();
            }
            else if (num == 0x18)
            {
                num2 = (uint) Convert.ToUInt64(((Class98) class2).method_2());
            }
            else
            {
                goto TR_0000;
            }
        }
        else if (num == 7)
        {
            num2 = (uint) ((Class118) class2).method_2();
        }
        else if (num == 11)
        {
            num2 = (uint) ((ulong) ((Class99) class2).method_2());
        }
        else
        {
            goto TR_0000;
        }
        Class118 class1 = new Class118();
        class1.method_3((int) num2);
        this.method_195(class1);
        return;
    TR_0000:
        throw new InvalidOperationException();
    }

    private void method_154(Class94 class94_2)
    {
    }

    private void method_155(Class94 class94_2)
    {
        IntPtr ptr;
        Class94 class2 = this.method_300();
        int num = class2.vmethod_2();
        if (num > 11)
        {
            if (num == 0x11)
            {
                ptr = new IntPtr((long) ((Class117) class2).method_2());
            }
            else if (num == 0x18)
            {
                ptr = new IntPtr((long) Convert.ToUInt64(((Class98) class2).method_2()));
            }
            else
            {
                goto TR_0000;
            }
        }
        else if (num == 7)
        {
            ptr = new IntPtr((long) ((uint) ((Class118) class2).method_2()));
        }
        else if (num == 11)
        {
            ptr = new IntPtr((long) ((ulong) ((Class99) class2).method_2()));
        }
        else
        {
            goto TR_0000;
        }
        Class105 class1 = new Class105();
        class1.method_3(ptr);
        this.method_195(class1);
        return;
    TR_0000:
        throw new InvalidOperationException();
    }

    private void method_156(Class94 class94_2)
    {
        this.method_195(this.class94_0[1].vmethod_4());
    }

    private void method_157(Class94 class94_2)
    {
        Class94 class3 = this.method_300();
        this.method_195(this.method_1(class3, this.method_300()));
    }

    private void method_158(Class94 class94_2)
    {
        Class94 class2 = this.method_300();
        this.method_195(this.method_160(class2));
    }

    private object method_159(MethodBase methodBase_0, object object_3, object[] object_4, bool bool_2)
    {
        Struct2 struct2 = new Struct2(methodBase_0, bool_2);
        Delegate0 delegate2 = this.method_232(struct2);
        if (delegate2 == null)
        {
            bool flag;
            int num;
            Monitor.Enter(this.dictionary_4);
            this.dictionary_4.TryGetValue(methodBase_0, out num);
            if (!(flag = num >= 50))
            {
                this.dictionary_4[methodBase_0] = num + 1;
            }
            if (!(flag = ((flag || (!bool_2 && ((object_3 == null) && (!methodBase_0.IsStatic && !methodBase_0.IsConstructor)))) || smethod_24(methodBase_0)) || ((methodBase_0.CallingConvention & CallingConventions.Any) == CallingConventions.VarArgs)))
            {
                return this.method_247(methodBase_0, object_3, object_4);
            }
            delegate2 = this.method_27(struct2);
            Monitor.Enter(this.dictionary_4);
            this.dictionary_4.Remove(methodBase_0);
        }
        return delegate2(object_3, object_4);
    }

    private Class94 method_16(Class94 class94_2, Class94 class94_3, bool bool_2, bool bool_3)
    {
        if (class94_2.vmethod_2() == 7)
        {
            if (class94_3.vmethod_2() == 7)
            {
                if (!bool_3)
                {
                    int num = ((Class118) class94_2).method_2();
                    int num2 = ((Class118) class94_3).method_2();
                    int num3 = !bool_2 ? (num * num2) : (num * num2);
                    Class118 class1 = new Class118();
                    class1.method_3(num3);
                    return class1;
                }
                uint num4 = (uint) ((Class118) class94_2).method_2();
                uint num5 = (uint) ((Class118) class94_3).method_2();
                uint num6 = !bool_2 ? (num4 * num5) : (num4 * num5);
                Class118 class2 = new Class118();
                class2.method_3((int) num6);
                return class2;
            }
            if (class94_3.vmethod_2() == 11)
            {
                Class99 class3 = new Class99();
                class3.method_3((long) ((Class118) class94_2).method_2());
                return smethod_27(class3, class94_3, bool_2, bool_3);
            }
            if (class94_3.vmethod_2() == 0x18)
            {
                Type objA = Enum.GetUnderlyingType(class94_3.vmethod_0().GetType());
                if (!ReferenceEquals(objA, typeof(long)) && !ReferenceEquals(objA, typeof(ulong)))
                {
                    Class118 class4 = new Class118();
                    class4.method_3(Convert.ToInt32(class94_3.vmethod_0()));
                    return this.method_16(class94_2, class4, bool_2, bool_3);
                }
                Class99 class5 = new Class99();
                class5.method_3((long) ((Class118) class94_2).method_2());
                Class99 class6 = new Class99();
                class6.method_3(Convert.ToInt64(class94_3.vmethod_0()));
                return smethod_27(class5, class6, bool_2, bool_3);
            }
        }
        if (class94_2.vmethod_2() == 11)
        {
            if (class94_3.vmethod_2() == 11)
            {
                return smethod_27(class94_2, class94_3, bool_2, bool_3);
            }
            if (class94_3.vmethod_2() == 7)
            {
                Class99 class7 = new Class99();
                class7.method_3((long) ((Class118) class94_3).method_2());
                return smethod_27(class94_2, class7, bool_2, bool_3);
            }
            if (class94_3.vmethod_2() == 0x18)
            {
                Type objA = Enum.GetUnderlyingType(class94_3.vmethod_0().GetType());
                if (!ReferenceEquals(objA, typeof(long)) && !ReferenceEquals(objA, typeof(ulong)))
                {
                    Class118 class8 = new Class118();
                    class8.method_3(Convert.ToInt32(class94_3.vmethod_0()));
                    return smethod_27(class94_2, class8, bool_2, bool_3);
                }
                Class99 class9 = new Class99();
                class9.method_3(Convert.ToInt64(class94_3.vmethod_0()));
                return smethod_27(class94_2, class9, bool_2, bool_3);
            }
        }
        if ((class94_2.vmethod_2() == 0x11) && (class94_3.vmethod_2() == 0x11))
        {
            Class117 class10 = new Class117();
            class10.method_3(((Class117) class94_2).method_2() * ((Class117) class94_3).method_2());
            return class10;
        }
        if (class94_2.vmethod_2() != 0x18)
        {
            throw new InvalidOperationException();
        }
        Type underlyingType = Enum.GetUnderlyingType(class94_2.vmethod_0().GetType());
        if (!ReferenceEquals(underlyingType, typeof(long)) && !ReferenceEquals(underlyingType, typeof(ulong)))
        {
            Class118 class11 = new Class118();
            class11.method_3(Convert.ToInt32(class94_2.vmethod_0()));
            return this.method_16(class11, class94_3, bool_2, bool_3);
        }
        Class99 class12 = new Class99();
        class12.method_3(Convert.ToInt64(class94_2.vmethod_0()));
        return this.method_16(class12, class94_3, bool_2, bool_3);
    }

    private Class94 method_160(Class94 class94_2)
    {
        if (class94_2.vmethod_2() == 7)
        {
            int num = ((Class118) class94_2).method_2();
            Class118 class1 = new Class118();
            class1.method_3(-num);
            return class1;
        }
        if (class94_2.vmethod_2() == 11)
        {
            long num2 = ((Class99) class94_2).method_2();
            Class99 class2 = new Class99();
            class2.method_3(-num2);
            return class2;
        }
        if (class94_2.vmethod_2() == 0x11)
        {
            Class117 class3 = new Class117();
            class3.method_3(-((Class117) class94_2).method_2());
            return class3;
        }
        if (class94_2.vmethod_2() != 0x18)
        {
            throw new InvalidOperationException();
        }
        Type underlyingType = Enum.GetUnderlyingType(class94_2.vmethod_0().GetType());
        if (!ReferenceEquals(underlyingType, typeof(long)) && !ReferenceEquals(underlyingType, typeof(ulong)))
        {
            Class118 class4 = new Class118();
            class4.method_3(Convert.ToInt32(class94_2.vmethod_0()));
            return this.method_160(class4);
        }
        Class99 class5 = new Class99();
        class5.method_3(Convert.ToInt64(class94_2.vmethod_0()));
        return this.method_160(class5);
    }

    private void method_161(Class94 class94_2)
    {
        this.method_72();
    }

    private void method_162(Class35 class35_0)
    {
        Class3 class2 = this.method_130(class35_0.method_2());
        Class34 class1 = (Class34) class2.method_4();
        MethodBase base2 = this.method_118(class35_0.method_2(), class2);
        base2.GetParameters();
        int num = class35_0.method_0();
        bool flag = (num & 0x40000000) != 0;
        num &= -1073741825;
        this.type_7 = (base2 is ConstructorInfo) ? Type.EmptyTypes : base2.GetGenericArguments();
        this.type_2 = base2.DeclaringType.GetGenericArguments();
        this.method_205(num, this.type_7, this.type_2, flag);
    }

    private void method_163(Class94 class94_2)
    {
        Class94 class3 = this.method_300();
        this.method_195(this.method_16(class3, this.method_300(), true, false));
    }

    private void method_164(Class94 class94_2)
    {
        Class118 class1 = new Class118();
        class1.method_3(5);
        this.method_195(class1);
    }

    private bool method_165(MethodBase methodBase_0, object object_3, ref object object_4, object[] object_5)
    {
        if (!methodBase_0.IsStatic && (methodBase_0.Name == "Address"))
        {
            MethodInfo info = methodBase_0 as MethodInfo;
            if (info != null)
            {
                Type returnType = info.ReturnType;
                if (returnType.IsByRef)
                {
                    returnType = returnType.GetElementType();
                    int length = object_5.Length;
                    if ((length >= 1) && (object_5[0] is int))
                    {
                        int[] numArray = new int[length];
                        for (int i = 0; i < length; i++)
                        {
                            numArray[i] = (int) object_5[i];
                        }
                        Class111 class1 = new Class111();
                        class1.method_5((Array) object_3);
                        class1.method_7(numArray);
                        class1.method_3(returnType);
                        object_4 = class1;
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private Dictionary<int, Class6> method_166()
    {
        Dictionary<int, Class6> dictionary1 = new Dictionary<int, Class6>(0x100);
        dictionary1.Add(this.class16_0.class31_103.method_0(), new Class6(this.class16_0.class31_103, new Delegate1(this.method_216)));
        dictionary1.Add(this.class16_0.class31_21.method_0(), new Class6(this.class16_0.class31_21, new Delegate1(this.method_29)));
        dictionary1.Add(this.class16_0.class31_155.method_0(), new Class6(this.class16_0.class31_155, new Delegate1(this.method_237)));
        dictionary1.Add(this.class16_0.class31_90.method_0(), new Class6(this.class16_0.class31_90, new Delegate1(this.method_219)));
        dictionary1.Add(this.class16_0.class31_52.method_0(), new Class6(this.class16_0.class31_52, new Delegate1(this.method_66)));
        dictionary1.Add(this.class16_0.class31_76.method_0(), new Class6(this.class16_0.class31_76, new Delegate1(this.method_190)));
        dictionary1.Add(this.class16_0.class31_98.method_0(), new Class6(this.class16_0.class31_98, new Delegate1(this.method_113)));
        dictionary1.Add(this.class16_0.class31_8.method_0(), new Class6(this.class16_0.class31_8, new Delegate1(this.method_50)));
        dictionary1.Add(this.class16_0.class31_45.method_0(), new Class6(this.class16_0.class31_45, new Delegate1(this.method_100)));
        dictionary1.Add(this.class16_0.class31_193.method_0(), new Class6(this.class16_0.class31_193, new Delegate1(this.method_277)));
        dictionary1.Add(this.class16_0.class31_6.method_0(), new Class6(this.class16_0.class31_6, new Delegate1(this.method_74)));
        dictionary1.Add(this.class16_0.class31_148.method_0(), new Class6(this.class16_0.class31_148, new Delegate1(this.method_110)));
        dictionary1.Add(this.class16_0.class31_195.method_0(), new Class6(this.class16_0.class31_195, new Delegate1(this.method_149)));
        dictionary1.Add(this.class16_0.class31_29.method_0(), new Class6(this.class16_0.class31_29, new Delegate1(this.method_156)));
        dictionary1.Add(this.class16_0.class31_113.method_0(), new Class6(this.class16_0.class31_113, new Delegate1(this.method_91)));
        dictionary1.Add(this.class16_0.class31_27.method_0(), new Class6(this.class16_0.class31_27, new Delegate1(this.method_210)));
        dictionary1.Add(this.class16_0.class31_31.method_0(), new Class6(this.class16_0.class31_31, new Delegate1(this.method_108)));
        dictionary1.Add(this.class16_0.class31_139.method_0(), new Class6(this.class16_0.class31_139, new Delegate1(this.method_13)));
        dictionary1.Add(this.class16_0.class31_47.method_0(), new Class6(this.class16_0.class31_47, new Delegate1(this.method_269)));
        dictionary1.Add(this.class16_0.class31_196.method_0(), new Class6(this.class16_0.class31_196, new Delegate1(this.method_240)));
        dictionary1.Add(this.class16_0.class31_100.method_0(), new Class6(this.class16_0.class31_100, new Delegate1(this.method_264)));
        dictionary1.Add(this.class16_0.class31_2.method_0(), new Class6(this.class16_0.class31_2, new Delegate1(this.method_199)));
        dictionary1.Add(this.class16_0.class31_163.method_0(), new Class6(this.class16_0.class31_163, new Delegate1(this.method_107)));
        dictionary1.Add(this.class16_0.class31_93.method_0(), new Class6(this.class16_0.class31_93, new Delegate1(this.method_155)));
        dictionary1.Add(this.class16_0.class31_14.method_0(), new Class6(this.class16_0.class31_14, new Delegate1(this.method_120)));
        dictionary1.Add(this.class16_0.class31_212.method_0(), new Class6(this.class16_0.class31_212, new Delegate1(this.method_56)));
        dictionary1.Add(this.class16_0.class31_116.method_0(), new Class6(this.class16_0.class31_116, new Delegate1(this.method_254)));
        dictionary1.Add(this.class16_0.class31_207.method_0(), new Class6(this.class16_0.class31_207, new Delegate1(this.method_40)));
        dictionary1.Add(this.class16_0.class31_82.method_0(), new Class6(this.class16_0.class31_82, new Delegate1(this.method_85)));
        dictionary1.Add(this.class16_0.class31_156.method_0(), new Class6(this.class16_0.class31_156, new Delegate1(this.method_86)));
        dictionary1.Add(this.class16_0.class31_28.method_0(), new Class6(this.class16_0.class31_28, new Delegate1(this.method_177)));
        dictionary1.Add(this.class16_0.class31_119.method_0(), new Class6(this.class16_0.class31_119, new Delegate1(this.method_38)));
        dictionary1.Add(this.class16_0.class31_15.method_0(), new Class6(this.class16_0.class31_15, new Delegate1(this.method_271)));
        dictionary1.Add(this.class16_0.class31_70.method_0(), new Class6(this.class16_0.class31_70, new Delegate1(this.method_33)));
        dictionary1.Add(this.class16_0.class31_205.method_0(), new Class6(this.class16_0.class31_205, new Delegate1(this.method_191)));
        dictionary1.Add(this.class16_0.class31_78.method_0(), new Class6(this.class16_0.class31_78, new Delegate1(this.method_141)));
        dictionary1.Add(this.class16_0.class31_62.method_0(), new Class6(this.class16_0.class31_62, new Delegate1(this.method_89)));
        dictionary1.Add(this.class16_0.class31_181.method_0(), new Class6(this.class16_0.class31_181, new Delegate1(this.method_257)));
        dictionary1.Add(this.class16_0.class31_11.method_0(), new Class6(this.class16_0.class31_11, new Delegate1(this.method_97)));
        dictionary1.Add(this.class16_0.class31_166.method_0(), new Class6(this.class16_0.class31_166, new Delegate1(this.method_198)));
        dictionary1.Add(this.class16_0.class31_134.method_0(), new Class6(this.class16_0.class31_134, new Delegate1(this.method_236)));
        dictionary1.Add(this.class16_0.class31_69.method_0(), new Class6(this.class16_0.class31_69, new Delegate1(this.method_92)));
        dictionary1.Add(this.class16_0.class31_53.method_0(), new Class6(this.class16_0.class31_53, new Delegate1(this.method_196)));
        dictionary1.Add(this.class16_0.class31_13.method_0(), new Class6(this.class16_0.class31_13, new Delegate1(this.method_203)));
        dictionary1.Add(this.class16_0.class31_59.method_0(), new Class6(this.class16_0.class31_59, new Delegate1(this.method_246)));
        dictionary1.Add(this.class16_0.class31_127.method_0(), new Class6(this.class16_0.class31_127, new Delegate1(this.method_102)));
        dictionary1.Add(this.class16_0.class31_105.method_0(), new Class6(this.class16_0.class31_105, new Delegate1(this.method_176)));
        dictionary1.Add(this.class16_0.class31_140.method_0(), new Class6(this.class16_0.class31_140, new Delegate1(this.method_182)));
        dictionary1.Add(this.class16_0.class31_154.method_0(), new Class6(this.class16_0.class31_154, new Delegate1(this.method_8)));
        dictionary1.Add(this.class16_0.class31_169.method_0(), new Class6(this.class16_0.class31_169, new Delegate1(this.method_95)));
        dictionary1.Add(this.class16_0.class31_137.method_0(), new Class6(this.class16_0.class31_137, new Delegate1(this.method_140)));
        dictionary1.Add(this.class16_0.class31_152.method_0(), new Class6(this.class16_0.class31_152, new Delegate1(this.method_169)));
        dictionary1.Add(this.class16_0.class31_194.method_0(), new Class6(this.class16_0.class31_194, new Delegate1(this.method_101)));
        dictionary1.Add(this.class16_0.class31_142.method_0(), new Class6(this.class16_0.class31_142, new Delegate1(this.method_7)));
        dictionary1.Add(this.class16_0.class31_12.method_0(), new Class6(this.class16_0.class31_12, new Delegate1(this.method_173)));
        dictionary1.Add(this.class16_0.class31_202.method_0(), new Class6(this.class16_0.class31_202, new Delegate1(this.method_218)));
        dictionary1.Add(this.class16_0.class31_206.method_0(), new Class6(this.class16_0.class31_206, new Delegate1(this.method_167)));
        dictionary1.Add(this.class16_0.class31_67.method_0(), new Class6(this.class16_0.class31_67, new Delegate1(this.method_252)));
        dictionary1.Add(this.class16_0.class31_141.method_0(), new Class6(this.class16_0.class31_141, new Delegate1(this.method_83)));
        dictionary1.Add(this.class16_0.class31_133.method_0(), new Class6(this.class16_0.class31_133, new Delegate1(this.method_282)));
        dictionary1.Add(this.class16_0.class31_68.method_0(), new Class6(this.class16_0.class31_68, new Delegate1(this.method_286)));
        dictionary1.Add(this.class16_0.class31_151.method_0(), new Class6(this.class16_0.class31_151, new Delegate1(this.method_297)));
        dictionary1.Add(this.class16_0.class31_91.method_0(), new Class6(this.class16_0.class31_91, new Delegate1(this.method_18)));
        dictionary1.Add(this.class16_0.class31_192.method_0(), new Class6(this.class16_0.class31_192, new Delegate1(this.method_231)));
        dictionary1.Add(this.class16_0.class31_115.method_0(), new Class6(this.class16_0.class31_115, new Delegate1(this.method_145)));
        dictionary1.Add(this.class16_0.class31_30.method_0(), new Class6(this.class16_0.class31_30, new Delegate1(this.method_59)));
        dictionary1.Add(this.class16_0.class31_201.method_0(), new Class6(this.class16_0.class31_201, new Delegate1(this.method_90)));
        dictionary1.Add(this.class16_0.class31_132.method_0(), new Class6(this.class16_0.class31_132, new Delegate1(this.method_225)));
        dictionary1.Add(this.class16_0.class31_125.method_0(), new Class6(this.class16_0.class31_125, new Delegate1(this.method_151)));
        dictionary1.Add(this.class16_0.class31_183.method_0(), new Class6(this.class16_0.class31_183, new Delegate1(this.method_68)));
        dictionary1.Add(this.class16_0.class31_110.method_0(), new Class6(this.class16_0.class31_110, new Delegate1(this.method_132)));
        dictionary1.Add(this.class16_0.class31_182.method_0(), new Class6(this.class16_0.class31_182, new Delegate1(this.method_116)));
        dictionary1.Add(this.class16_0.class31_89.method_0(), new Class6(this.class16_0.class31_89, new Delegate1(this.method_238)));
        dictionary1.Add(this.class16_0.class31_108.method_0(), new Class6(this.class16_0.class31_147, new Delegate1(this.method_61)));
        dictionary1.Add(this.class16_0.class31_54.method_0(), new Class6(this.class16_0.class31_54, new Delegate1(this.method_60)));
        dictionary1.Add(this.class16_0.class31_120.method_0(), new Class6(this.class16_0.class31_120, new Delegate1(this.method_163)));
        dictionary1.Add(this.class16_0.class31_46.method_0(), new Class6(this.class16_0.class31_46, new Delegate1(this.method_126)));
        dictionary1.Add(this.class16_0.class31_189.method_0(), new Class6(this.class16_0.class31_189, new Delegate1(this.method_153)));
        dictionary1.Add(this.class16_0.class31_146.method_0(), new Class6(this.class16_0.class31_146, new Delegate1(this.method_186)));
        dictionary1.Add(this.class16_0.class31_5.method_0(), new Class6(this.class16_0.class31_5, new Delegate1(this.method_12)));
        dictionary1.Add(this.class16_0.class31_138.method_0(), new Class6(this.class16_0.class31_138, new Delegate1(this.method_204)));
        dictionary1.Add(this.class16_0.class31_143.method_0(), new Class6(this.class16_0.class31_143, new Delegate1(this.method_285)));
        dictionary1.Add(this.class16_0.class31_88.method_0(), new Class6(this.class16_0.class31_88, new Delegate1(this.method_202)));
        dictionary1.Add(this.class16_0.class31_3.method_0(), new Class6(this.class16_0.class31_3, new Delegate1(this.method_295)));
        dictionary1.Add(this.class16_0.class31_44.method_0(), new Class6(this.class16_0.class31_44, new Delegate1(this.method_76)));
        dictionary1.Add(this.class16_0.class31_130.method_0(), new Class6(this.class16_0.class31_130, new Delegate1(this.method_115)));
        dictionary1.Add(this.class16_0.class31_180.method_0(), new Class6(this.class16_0.class31_180, new Delegate1(this.method_125)));
        dictionary1.Add(this.class16_0.class31_104.method_0(), new Class6(this.class16_0.class31_104, new Delegate1(this.method_183)));
        dictionary1.Add(this.class16_0.class31_102.method_0(), new Class6(this.class16_0.class31_102, new Delegate1(this.method_157)));
        dictionary1.Add(this.class16_0.class31_66.method_0(), new Class6(this.class16_0.class31_66, new Delegate1(this.method_138)));
        dictionary1.Add(this.class16_0.class31_153.method_0(), new Class6(this.class16_0.class31_153, new Delegate1(this.method_6)));
        dictionary1.Add(this.class16_0.class31_36.method_0(), new Class6(this.class16_0.class31_36, new Delegate1(this.method_193)));
        dictionary1.Add(this.class16_0.class31_81.method_0(), new Class6(this.class16_0.class31_81, new Delegate1(this.method_93)));
        dictionary1.Add(this.class16_0.class31_208.method_0(), new Class6(this.class16_0.class31_208, new Delegate1(this.method_194)));
        dictionary1.Add(this.class16_0.class31_144.method_0(), new Class6(this.class16_0.class31_144, new Delegate1(this.method_188)));
        dictionary1.Add(this.class16_0.class31_57.method_0(), new Class6(this.class16_0.class31_57, new Delegate1(this.method_137)));
        dictionary1.Add(this.class16_0.class31_171.method_0(), new Class6(this.class16_0.class31_171, new Delegate1(this.method_260)));
        dictionary1.Add(this.class16_0.class31_121.method_0(), new Class6(this.class16_0.class31_121, new Delegate1(this.method_87)));
        dictionary1.Add(this.class16_0.class31_199.method_0(), new Class6(this.class16_0.class31_199, new Delegate1(this.method_32)));
        dictionary1.Add(this.class16_0.class31_32.method_0(), new Class6(this.class16_0.class31_32, new Delegate1(this.method_78)));
        dictionary1.Add(this.class16_0.class31_157.method_0(), new Class6(this.class16_0.class31_157, new Delegate1(this.method_226)));
        dictionary1.Add(this.class16_0.class31_86.method_0(), new Class6(this.class16_0.class31_86, new Delegate1(this.method_212)));
        dictionary1.Add(this.class16_0.class31_109.method_0(), new Class6(this.class16_0.class31_109, new Delegate1(this.method_181)));
        dictionary1.Add(this.class16_0.class31_63.method_0(), new Class6(this.class16_0.class31_63, new Delegate1(this.method_81)));
        dictionary1.Add(this.class16_0.class31_97.method_0(), new Class6(this.class16_0.class31_97, new Delegate1(this.method_170)));
        dictionary1.Add(this.class16_0.class31_38.method_0(), new Class6(this.class16_0.class31_38, new Delegate1(this.method_84)));
        dictionary1.Add(this.class16_0.class31_118.method_0(), new Class6(this.class16_0.class31_118, new Delegate1(this.method_211)));
        dictionary1.Add(this.class16_0.class31_7.method_0(), new Class6(this.class16_0.class31_7, new Delegate1(this.method_25)));
        dictionary1.Add(this.class16_0.class31_58.method_0(), new Class6(this.class16_0.class31_58, new Delegate1(this.method_28)));
        dictionary1.Add(this.class16_0.class31_107.method_0(), new Class6(this.class16_0.class31_107, new Delegate1(this.method_9)));
        dictionary1.Add(this.class16_0.class31_84.method_0(), new Class6(this.class16_0.class31_84, new Delegate1(this.method_123)));
        dictionary1.Add(this.class16_0.class31_168.method_0(), new Class6(this.class16_0.class31_168, new Delegate1(this.method_250)));
        dictionary1.Add(this.class16_0.class31_200.method_0(), new Class6(this.class16_0.class31_200, new Delegate1(this.method_262)));
        dictionary1.Add(this.class16_0.class31_197.method_0(), new Class6(this.class16_0.class31_197, new Delegate1(this.method_77)));
        dictionary1.Add(this.class16_0.class31_213.method_0(), new Class6(this.class16_0.class31_213, new Delegate1(this.method_58)));
        dictionary1.Add(this.class16_0.class31_209.method_0(), new Class6(this.class16_0.class31_209, new Delegate1(this.method_65)));
        dictionary1.Add(this.class16_0.class31_37.method_0(), new Class6(this.class16_0.class31_37, new Delegate1(this.method_290)));
        dictionary1.Add(this.class16_0.class31_117.method_0(), new Class6(this.class16_0.class31_117, new Delegate1(this.method_80)));
        dictionary1.Add(this.class16_0.class31_85.method_0(), new Class6(this.class16_0.class31_85, new Delegate1(this.method_122)));
        dictionary1.Add(this.class16_0.class31_64.method_0(), new Class6(this.class16_0.class31_64, new Delegate1(this.method_283)));
        dictionary1.Add(this.class16_0.class31_35.method_0(), new Class6(this.class16_0.class31_35, new Delegate1(this.method_37)));
        dictionary1.Add(this.class16_0.class31_99.method_0(), new Class6(this.class16_0.class31_99, new Delegate1(this.method_294)));
        dictionary1.Add(this.class16_0.class31_55.method_0(), new Class6(this.class16_0.class31_55, new Delegate1(this.method_208)));
        dictionary1.Add(this.class16_0.class31_128.method_0(), new Class6(this.class16_0.class31_128, new Delegate1(this.method_161)));
        dictionary1.Add(this.class16_0.class31_186.method_0(), new Class6(this.class16_0.class31_186, new Delegate1(this.method_217)));
        dictionary1.Add(this.class16_0.class31_210.method_0(), new Class6(this.class16_0.class31_210, new Delegate1(this.method_224)));
        dictionary1.Add(this.class16_0.class31_123.method_0(), new Class6(this.class16_0.class31_123, new Delegate1(this.method_112)));
        dictionary1.Add(this.class16_0.class31_83.method_0(), new Class6(this.class16_0.class31_83, new Delegate1(this.method_88)));
        dictionary1.Add(this.class16_0.class31_73.method_0(), new Class6(this.class16_0.class31_73, new Delegate1(this.method_19)));
        dictionary1.Add(this.class16_0.class31_170.method_0(), new Class6(this.class16_0.class31_170, new Delegate1(this.method_114)));
        dictionary1.Add(this.class16_0.class31_172.method_0(), new Class6(this.class16_0.class31_172, new Delegate1(this.method_79)));
        dictionary1.Add(this.class16_0.class31_71.method_0(), new Class6(this.class16_0.class31_71, new Delegate1(this.method_111)));
        dictionary1.Add(this.class16_0.class31_18.method_0(), new Class6(this.class16_0.class31_18, new Delegate1(this.method_276)));
        dictionary1.Add(this.class16_0.class31_42.method_0(), new Class6(this.class16_0.class31_42, new Delegate1(this.method_96)));
        dictionary1.Add(this.class16_0.class31_16.method_0(), new Class6(this.class16_0.class31_16, new Delegate1(this.method_106)));
        dictionary1.Add(this.class16_0.class31_61.method_0(), new Class6(this.class16_0.class31_61, new Delegate1(this.method_180)));
        dictionary1.Add(this.class16_0.class31_40.method_0(), new Class6(this.class16_0.class31_40, new Delegate1(this.method_228)));
        dictionary1.Add(this.class16_0.class31_145.method_0(), new Class6(this.class16_0.class31_145, new Delegate1(this.method_136)));
        dictionary1.Add(this.class16_0.class31_204.method_0(), new Class6(this.class16_0.class31_204, new Delegate1(this.method_248)));
        dictionary1.Add(this.class16_0.class31_10.method_0(), new Class6(this.class16_0.class31_10, new Delegate1(this.method_99)));
        dictionary1.Add(this.class16_0.class31_101.method_0(), new Class6(this.class16_0.class31_101, new Delegate1(this.method_43)));
        dictionary1.Add(this.class16_0.class31_25.method_0(), new Class6(this.class16_0.class31_25, new Delegate1(this.method_301)));
        dictionary1.Add(this.class16_0.class31_198.method_0(), new Class6(this.class16_0.class31_198, new Delegate1(this.method_31)));
        dictionary1.Add(this.class16_0.class31_177.method_0(), new Class6(this.class16_0.class31_177, new Delegate1(this.method_41)));
        dictionary1.Add(this.class16_0.class31_165.method_0(), new Class6(this.class16_0.class31_165, new Delegate1(this.method_287)));
        dictionary1.Add(this.class16_0.class31_203.method_0(), new Class6(this.class16_0.class31_203, new Delegate1(this.method_207)));
        dictionary1.Add(this.class16_0.class31_1.method_0(), new Class6(this.class16_0.class31_1, new Delegate1(this.method_103)));
        dictionary1.Add(this.class16_0.class31_33.method_0(), new Class6(this.class16_0.class31_33, new Delegate1(this.method_47)));
        dictionary1.Add(this.class16_0.class31_19.method_0(), new Class6(this.class16_0.class31_19, new Delegate1(this.method_158)));
        dictionary1.Add(this.class16_0.class31_162.method_0(), new Class6(this.class16_0.class31_162, new Delegate1(this.method_249)));
        dictionary1.Add(this.class16_0.class31_79.method_0(), new Class6(this.class16_0.class31_79, new Delegate1(this.method_35)));
        dictionary1.Add(this.class16_0.class31_96.method_0(), new Class6(this.class16_0.class31_96, new Delegate1(this.method_220)));
        dictionary1.Add(this.class16_0.class31_159.method_0(), new Class6(this.class16_0.class31_159, new Delegate1(this.method_179)));
        dictionary1.Add(this.class16_0.class31_87.method_0(), new Class6(this.class16_0.class31_87, new Delegate1(this.method_46)));
        dictionary1.Add(this.class16_0.class31_124.method_0(), new Class6(this.class16_0.class31_124, new Delegate1(this.method_45)));
        dictionary1.Add(this.class16_0.class31_188.method_0(), new Class6(this.class16_0.class31_188, new Delegate1(this.method_117)));
        dictionary1.Add(this.class16_0.class31_174.method_0(), new Class6(this.class16_0.class31_174, new Delegate1(this.method_14)));
        dictionary1.Add(this.class16_0.class31_34.method_0(), new Class6(this.class16_0.class31_34, new Delegate1(this.method_23)));
        dictionary1.Add(this.class16_0.class31_56.method_0(), new Class6(this.class16_0.class31_56, new Delegate1(this.method_134)));
        dictionary1.Add(this.class16_0.class31_74.method_0(), new Class6(this.class16_0.class31_74, new Delegate1(this.method_293)));
        dictionary1.Add(this.class16_0.class31_175.method_0(), new Class6(this.class16_0.class31_175, new Delegate1(this.method_146)));
        dictionary1.Add(this.class16_0.class31_191.method_0(), new Class6(this.class16_0.class31_191, new Delegate1(this.method_105)));
        dictionary1.Add(this.class16_0.class31_158.method_0(), new Class6(this.class16_0.class31_158, new Delegate1(this.method_178)));
        dictionary1.Add(this.class16_0.class31_131.method_0(), new Class6(this.class16_0.class31_131, new Delegate1(this.method_299)));
        dictionary1.Add(this.class16_0.class31_179.method_0(), new Class6(this.class16_0.class31_179, new Delegate1(this.method_266)));
        dictionary1.Add(this.class16_0.class31_23.method_0(), new Class6(this.class16_0.class31_23, new Delegate1(this.method_184)));
        dictionary1.Add(this.class16_0.class31_173.method_0(), new Class6(this.class16_0.class31_173, new Delegate1(this.method_253)));
        dictionary1.Add(this.class16_0.class31_72.method_0(), new Class6(this.class16_0.class31_72, new Delegate1(this.method_284)));
        dictionary1.Add(this.class16_0.class31_147.method_0(), new Class6(this.class16_0.class31_147, new Delegate1(this.method_154)));
        dictionary1.Add(this.class16_0.class31_65.method_0(), new Class6(this.class16_0.class31_65, new Delegate1(this.method_30)));
        dictionary1.Add(this.class16_0.class31_126.method_0(), new Class6(this.class16_0.class31_126, new Delegate1(this.method_143)));
        dictionary1.Add(this.class16_0.class31_39.method_0(), new Class6(this.class16_0.class31_39, new Delegate1(this.method_148)));
        dictionary1.Add(this.class16_0.class31_176.method_0(), new Class6(this.class16_0.class31_176, new Delegate1(this.method_53)));
        dictionary1.Add(this.class16_0.class31_167.method_0(), new Class6(this.class16_0.class31_167, new Delegate1(this.method_133)));
        dictionary1.Add(this.class16_0.class31_161.method_0(), new Class6(this.class16_0.class31_161, new Delegate1(this.method_273)));
        dictionary1.Add(this.class16_0.class31_211.method_0(), new Class6(this.class16_0.class31_211, new Delegate1(this.method_288)));
        dictionary1.Add(this.class16_0.class31_112.method_0(), new Class6(this.class16_0.class31_112, new Delegate1(this.method_272)));
        dictionary1.Add(this.class16_0.class31_129.method_0(), new Class6(this.class16_0.class31_129, new Delegate1(this.method_263)));
        dictionary1.Add(this.class16_0.class31_75.method_0(), new Class6(this.class16_0.class31_75, new Delegate1(this.method_171)));
        dictionary1.Add(this.class16_0.class31_136.method_0(), new Class6(this.class16_0.class31_136, new Delegate1(this.method_67)));
        dictionary1.Add(this.class16_0.class31_135.method_0(), new Class6(this.class16_0.class31_135, new Delegate1(this.method_34)));
        dictionary1.Add(this.class16_0.class31_17.method_0(), new Class6(this.class16_0.class31_17, new Delegate1(this.method_274)));
        dictionary1.Add(this.class16_0.class31_0.method_0(), new Class6(this.class16_0.class31_0, new Delegate1(this.method_268)));
        dictionary1.Add(this.class16_0.class31_94.method_0(), new Class6(this.class16_0.class31_94, new Delegate1(this.method_172)));
        dictionary1.Add(this.class16_0.class31_49.method_0(), new Class6(this.class16_0.class31_49, new Delegate1(this.method_63)));
        dictionary1.Add(this.class16_0.class31_24.method_0(), new Class6(this.class16_0.class31_24, new Delegate1(this.method_98)));
        dictionary1.Add(this.class16_0.class31_150.method_0(), new Class6(this.class16_0.class31_150, new Delegate1(this.method_168)));
        dictionary1.Add(this.class16_0.class31_80.method_0(), new Class6(this.class16_0.class31_80, new Delegate1(this.method_64)));
        dictionary1.Add(this.class16_0.class31_184.method_0(), new Class6(this.class16_0.class31_184, new Delegate1(this.method_280)));
        dictionary1.Add(this.class16_0.class31_41.method_0(), new Class6(this.class16_0.class31_41, new Delegate1(this.method_3)));
        dictionary1.Add(this.class16_0.class31_26.method_0(), new Class6(this.class16_0.class31_26, new Delegate1(this.method_197)));
        dictionary1.Add(this.class16_0.class31_149.method_0(), new Class6(this.class16_0.class31_149, new Delegate1(this.method_164)));
        dictionary1.Add(this.class16_0.class31_114.method_0(), new Class6(this.class16_0.class31_114, new Delegate1(this.method_75)));
        dictionary1.Add(this.class16_0.class31_190.method_0(), new Class6(this.class16_0.class31_190, new Delegate1(this.method_62)));
        dictionary1.Add(this.class16_0.class31_9.method_0(), new Class6(this.class16_0.class31_9, new Delegate1(this.method_121)));
        dictionary1.Add(this.class16_0.class31_22.method_0(), new Class6(this.class16_0.class31_22, new Delegate1(this.method_223)));
        dictionary1.Add(this.class16_0.class31_48.method_0(), new Class6(this.class16_0.class31_48, new Delegate1(this.method_2)));
        dictionary1.Add(this.class16_0.class31_178.method_0(), new Class6(this.class16_0.class31_178, new Delegate1(this.method_51)));
        dictionary1.Add(this.class16_0.class31_20.method_0(), new Class6(this.class16_0.class31_20, new Delegate1(this.method_206)));
        dictionary1.Add(this.class16_0.class31_160.method_0(), new Class6(this.class16_0.class31_160, new Delegate1(this.method_119)));
        dictionary1.Add(this.class16_0.class31_60.method_0(), new Class6(this.class16_0.class31_60, new Delegate1(this.method_70)));
        dictionary1.Add(this.class16_0.class31_122.method_0(), new Class6(this.class16_0.class31_122, new Delegate1(this.method_174)));
        dictionary1.Add(this.class16_0.class31_95.method_0(), new Class6(this.class16_0.class31_95, new Delegate1(this.method_54)));
        return dictionary1;
    }

    private void method_167(Class94 class94_2)
    {
        this.method_109(typeof(long));
    }

    private void method_168(Class94 class94_2)
    {
        this.method_195(this.class94_1[1].vmethod_4());
    }

    private void method_169(Class94 class94_2)
    {
        Class94 class3 = this.method_300();
        this.method_195(this.method_21(class3, this.method_300(), true));
    }

    private string method_17(int int_0)
    {
        string str;
        object obj2;
        Monitor.Enter(dictionary_3);
        bool flag = true;
        if (dictionary_3.TryGetValue(int_0, out obj2))
        {
            str = (string) obj2;
        }
        else
        {
            Class3 class2 = this.method_130(int_0);
            if (class2.method_0() == 1)
            {
                str = this.module_0.ResolveString(class2.method_2());
            }
            else
            {
                string str2 = ((Class33) class2.method_4()).method_0();
                if (flag)
                {
                    dictionary_3.Add(int_0, str2);
                }
                str = str2;
            }
        }
        return str;
    }

    private void method_170(Class94 class94_2)
    {
        Class94 class2 = this.method_300();
        Class94 class3 = this.method_300();
        if ((class3.vmethod_2() != 0x11) ? !smethod_29(class3, class2) : !smethod_18(class3, class2))
        {
            uint num = ((Class104) class94_2).method_2();
            this.method_244(num);
        }
    }

    private void method_171(Class94 class94_2)
    {
        throw new NotSupportedException("Refanytype is not supported.");
    }

    private void method_172(Class94 class94_2)
    {
        this.method_109(typeof(ushort));
    }

    private void method_173(Class94 class94_2)
    {
        Class94 class3 = this.method_300();
        this.method_195(this.method_242(class3, this.method_300()));
    }

    private void method_174(Class94 class94_2)
    {
        Class118 class1 = new Class118();
        class1.method_3(0);
        this.method_195(class1);
    }

    private void method_175(bool bool_2)
    {
        ulong num2;
        Class94 class2 = this.method_300();
        int num = class2.vmethod_2();
        if (num > 11)
        {
            if (num == 0x11)
            {
                num2 = !bool_2 ? ((ulong) ((Class117) class2).method_2()) : ((ulong) ((Class117) class2).method_2());
            }
            else if (num == 0x18)
            {
                num2 = !bool_2 ? Convert.ToUInt64(((Class98) class2).method_2()) : Convert.ToUInt64(((Class98) class2).method_2());
            }
            else
            {
                goto TR_0000;
            }
        }
        else if (num == 7)
        {
            num2 = !bool_2 ? ((ulong) ((Class118) class2).method_2()) : ((ulong) ((uint) ((Class118) class2).method_2()));
        }
        else if (num == 11)
        {
            num2 = !bool_2 ? ((ulong) ((Class99) class2).method_2()) : ((ulong) ((Class99) class2).method_2());
        }
        else
        {
            goto TR_0000;
        }
        Class99 class1 = new Class99();
        class1.method_3((long) num2);
        this.method_195(class1);
        return;
    TR_0000:
        throw new InvalidOperationException();
    }

    private void method_176(Class94 class94_2)
    {
        int num = ((Class118) class94_2).method_2();
        FieldInfo info = this.method_71(num);
        Class94 class3 = this.method_300();
        Class106 class2 = class3 as Class106;
        object obj2 = (class2 == null) ? class3.vmethod_0() : this.method_255(class2).vmethod_0();
        this.method_195(new Class107(info, obj2, class2));
    }

    private void method_177(Class94 class94_2)
    {
    }

    private void method_178(Class94 class94_2)
    {
        this.method_275();
    }

    private void method_179(Class94 class94_2)
    {
        Class119 class2 = (Class119) class94_2;
        this.method_195(this.class94_1[class2.method_2()].vmethod_4());
    }

    private void method_18(Class94 class94_2)
    {
        Class94 class3 = this.method_300();
        this.method_195(this.method_131(class3, this.method_300(), true, false));
    }

    private void method_180(Class94 class94_2)
    {
        this.method_265(typeof(sbyte));
    }

    private void method_181(Class94 class94_2)
    {
        this.method_258(false);
    }

    private void method_182(Class94 class94_2)
    {
        Class118 class1 = new Class118();
        class1.method_3(4);
        this.method_195(class1);
    }

    private void method_183(Class94 class94_2)
    {
        this.method_300();
    }

    private void method_184(Class94 class94_2)
    {
        if (((Class118) this.method_300()).method_2() != 0)
        {
            this.class20_1.method_7(new Struct1((uint) this.class29_0.method_0().vmethod_4(), this.object_2));
            this.bool_0 = false;
        }
        this.method_227();
    }

    private object method_185(Stream stream_1, int int_0, object[] object_3, Type[] type_9, Type[] type_10, object[] object_4)
    {
        this.stream_0 = stream_1;
        this.method_22(stream_1, (long) int_0, null);
        return this.method_36(object_3, type_9, type_10, object_4);
    }

    private void method_186(Class94 class94_2)
    {
        this.method_195(this.class94_1[0].vmethod_4());
    }

    private Class32 method_187(Class29 class29_2)
    {
        switch (class29_2.method_6())
        {
            case 0:
            {
                Class3 class1 = new Class3();
                class1.method_1(0);
                class1.method_3(class29_2.method_19());
                Class36 class4 = new Class36();
                class4.method_1(class1);
                class4.method_3(class29_2.method_9());
                class4.method_5(class29_2.method_5());
                return class4;
            }
            case 1:
            {
                Class37 class2 = new Class37();
                class2.method_11(class29_2.method_19());
                class2.method_9(class29_2.method_19());
                class2.method_3(class29_2.method_5());
                class2.method_1(class29_2.method_9());
                class2.method_5(class29_2.method_5());
                int num4 = class29_2.method_23();
                Class3[] classArray = new Class3[num4];
                for (int i = 0; i < num4; i++)
                {
                    Class3 class5 = new Class3();
                    class5.method_1(0);
                    class5.method_3(class29_2.method_19());
                    classArray[i] = class5;
                }
                class2.method_7(classArray);
                return class2;
            }
            case 2:
            {
                Class33 class6 = new Class33();
                class6.method_1(class29_2.method_9());
                return class6;
            }
            case 3:
            {
                Class35 class7 = new Class35();
                class7.method_1(class29_2.method_19());
                class7.method_3(class29_2.method_19());
                return class7;
            }
            case 4:
            {
                Class34 class3 = new Class34();
                Class3 class8 = new Class3();
                class8.method_1(0);
                class8.method_3(class29_2.method_19());
                class3.method_5(class8);
                class3.method_1(class29_2.method_6());
                class3.method_7(class29_2.method_9());
                Class3 class9 = new Class3();
                class9.method_1(0);
                class9.method_3(class29_2.method_19());
                class3.method_13(class9);
                int num5 = class29_2.method_23();
                Class3[] classArray2 = new Class3[num5];
                for (int i = 0; i < num5; i++)
                {
                    Class3 class10 = new Class3();
                    class10.method_1(0);
                    class10.method_3(class29_2.method_19());
                    classArray2[i] = class10;
                }
                class3.method_9(classArray2);
                int num6 = class29_2.method_23();
                Class3[] classArray3 = new Class3[num6];
                for (int j = 0; j < num6; j++)
                {
                    Class3 class11 = new Class3();
                    class11.method_1(0);
                    class11.method_3(class29_2.method_19());
                    classArray3[j] = class11;
                }
                class3.method_11(classArray3);
                return class3;
            }
        }
        throw new ArgumentOutOfRangeException();
    }

    private void method_188(Class94 class94_2)
    {
        int num = ((Class118) class94_2).method_2();
        FieldInfo info = this.method_71(num);
        Class94 class3 = this.method_300();
        Class106 class2 = class3 as Class106;
        object obj2 = (class2 == null) ? class3.vmethod_0() : this.method_255(class2).vmethod_0();
        if (obj2 == null)
        {
            throw new NullReferenceException();
        }
        info.SetValue(obj2, Class30.smethod_1(this.method_300().vmethod_0(), info.FieldType).vmethod_0());
        if ((class2 != null) && ((obj2 != null) && obj2.GetType().IsValueType))
        {
            this.method_142(class2, Class30.smethod_1(obj2, null));
        }
    }

    private Type method_189(int int_0, bool bool_2)
    {
        Type type;
        object obj2;
        Monitor.Enter(dictionary_3);
        bool flag = true;
        if (dictionary_3.TryGetValue(int_0, out obj2))
        {
            type = (Type) obj2;
        }
        else
        {
            Class3 class2 = this.method_130(int_0);
            type = this.method_292(int_0, class2, ref flag, bool_2);
            if (flag)
            {
                dictionary_3.Add(int_0, type);
            }
        }
        if (bool_2)
        {
            this.method_135(type);
        }
        return type;
    }

    private void method_19(Class94 class94_2)
    {
        int num = ((Class118) class94_2).method_2();
        FieldInfo info = this.method_71(num);
        Class94 class2 = this.method_300();
        Class106 class3 = class2 as Class106;
        if (class3 != null)
        {
            class2 = this.method_255(class3);
        }
        object obj2 = class2.vmethod_0();
        if (obj2 == null)
        {
            throw new NullReferenceException();
        }
        this.method_195(Class30.smethod_1(info.GetValue(obj2), info.FieldType));
    }

    private void method_190(Class94 class94_2)
    {
        this.method_265(typeof(double));
    }

    private void method_191(Class94 class94_2)
    {
        this.method_265(typeof(uint));
    }

    private string method_192(Class86 class86_1)
    {
        Type type = this.method_189(class86_1.method_6(), false);
        Class68[] classArray = class86_1.method_2();
        string[] strArray = new string[classArray.Length];
        for (int i = 0; i < classArray.Length; i++)
        {
            string fullName;
            Type type1 = this.method_189(classArray[i].method_0(), false);
            if (type1 != null)
            {
                fullName = type1.FullName;
            }
            else
            {
                Type local1 = type1;
                fullName = null;
            }
            strArray[i] = fullName;
        }
        string str = string.Join(", ", strArray);
        return string.Format("{0}.{1}({2})", type.FullName, class86_1.method_4(), str);
    }

    private void method_193(Class94 class94_2)
    {
        this.method_109(typeof(double));
    }

    private void method_194(Class94 class94_2)
    {
        throw new NotSupportedException("Cpobj is not supported.");
    }

    private void method_195(Class94 class94_2)
    {
        Class94 class2;
        if (class94_2 == null)
        {
            throw new ArgumentNullException("obj");
        }
        if (class94_2.method_0() == null)
        {
            int num = class94_2.vmethod_2();
            switch (num)
            {
                case 0:
                {
                    Class118 class6 = new Class118();
                    class6.method_3(((Class119) class94_2).method_2());
                    class6.method_1(class94_2.method_0());
                    class2 = class6;
                    goto TR_0001;
                }
                case 1:
                case 3:
                case 5:
                case 7:
                case 8:
                    break;

                case 2:
                {
                    Class118 class10 = new Class118();
                    Class118 class11 = new Class118();
                    class11.method_3(((Class103) class94_2).method_2() ? 1 : 0);
                    Class118 local1 = class11;
                    local1.method_1(class94_2.method_0());
                    class2 = local1;
                    goto TR_0001;
                }
                case 4:
                {
                    object obj2 = class94_2.vmethod_0();
                    if (obj2 == null)
                    {
                        class2 = class94_2;
                    }
                    else
                    {
                        Type elementType = obj2.GetType();
                        if (elementType.HasElementType && !elementType.IsArray)
                        {
                            elementType = elementType.GetElementType();
                        }
                        class2 = ((elementType == null) || (elementType.IsValueType || elementType.IsEnum)) ? Class30.smethod_1(obj2, elementType) : class94_2;
                    }
                    goto TR_0001;
                }
                case 6:
                {
                    Class118 class7 = new Class118();
                    class7.method_3(((Class95) class94_2).method_2());
                    class7.method_1(class94_2.method_0());
                    class2 = class7;
                    goto TR_0001;
                }
                case 9:
                {
                    Class118 class8 = new Class118();
                    class8.method_3(((Class115) class94_2).method_2());
                    class8.method_1(class94_2.method_0());
                    class2 = class8;
                    goto TR_0001;
                }
                case 10:
                {
                    Class117 class9 = new Class117();
                    class9.method_3((double) ((Class114) class94_2).method_2());
                    class9.method_1(class94_2.method_0());
                    class2 = class9;
                    goto TR_0001;
                }
                default:
                    if (num == 15)
                    {
                        Class118 class5 = new Class118();
                        class5.method_3(((Class101) class94_2).method_2());
                        class5.method_1(class94_2.method_0());
                        class2 = class5;
                        goto TR_0001;
                    }
                    else
                    {
                        switch (num)
                        {
                            case 0x13:
                            {
                                Class99 class1 = new Class99();
                                class1.method_3((long) ((Class120) class94_2).method_2());
                                class1.method_1(class94_2.method_0());
                                class2 = class1;
                                goto TR_0001;
                            }
                            case 0x15:
                            {
                                Class118 class3 = new Class118();
                                class3.method_3((int) ((Class104) class94_2).method_2());
                                class3.method_1(class94_2.method_0());
                                class2 = class3;
                                goto TR_0001;
                            }
                            case 0x16:
                            {
                                Class118 class4 = new Class118();
                                class4.method_3(((Class121) class94_2).method_2());
                                class4.method_1(class94_2.method_0());
                                class2 = class4;
                                goto TR_0001;
                            }
                            default:
                                break;
                        }
                    }
                    break;
            }
            class2 = class94_2;
        }
        else
        {
            class2 = class94_2;
        }
    TR_0001:
        this.class20_0.method_7(class2);
    }

    private void method_196(Class94 class94_2)
    {
        this.method_265(typeof(long));
    }

    private void method_197(Class94 class94_2)
    {
        int num = ((Class118) class94_2).method_2();
        FieldInfo info = this.method_71(num);
        info.SetValue(null, Class30.smethod_1(this.method_300().vmethod_0(), info.FieldType).vmethod_0());
    }

    private void method_198(Class94 class94_2)
    {
        this.method_5(false);
    }

    private void method_199(Class94 class94_2)
    {
        this.method_221(false);
    }

    private void method_2(Class94 class94_2)
    {
        this.method_109(typeof(float));
    }

    private void method_20()
    {
        this.method_296();
    }

    private void method_200(ref Struct0 struct0_0, MethodBase methodBase_0, bool bool_2)
    {
        bool flag = false;
        if (ReferenceEquals(methodBase_0.DeclaringType, typeof(Interlocked)) && methodBase_0.IsStatic)
        {
            string name = methodBase_0.Name;
            if ((name == "Add") || ((name == "CompareExchange") || ((name == "Decrement") || ((name == "Exchange") || ((name == "Increment") || (name == "Read"))))))
            {
                flag = true;
            }
        }
        if (flag)
        {
        }
    }

    private void method_201(bool bool_2)
    {
        int num2;
        Class94 class2 = this.method_300();
        int num = class2.vmethod_2();
        if (num > 11)
        {
            if (num == 0x11)
            {
                num2 = !bool_2 ? ((int) ((Class117) class2).method_2()) : ((int) ((Class117) class2).method_2());
            }
            else if (num == 0x18)
            {
                num2 = !bool_2 ? ((int) Convert.ToUInt64(((Class98) class2).method_2())) : ((int) Convert.ToUInt64(((Class98) class2).method_2()));
            }
            else
            {
                goto TR_0000;
            }
        }
        else if (num == 7)
        {
            num2 = !bool_2 ? ((Class118) class2).method_2() : ((Class118) class2).method_2();
        }
        else if (num == 11)
        {
            num2 = !bool_2 ? ((int) ((Class99) class2).method_2()) : ((int) ((Class99) class2).method_2());
        }
        else
        {
            goto TR_0000;
        }
        Class118 class1 = new Class118();
        class1.method_3(num2);
        this.method_195(class1);
        return;
    TR_0000:
        throw new InvalidOperationException();
    }

    private void method_202(Class94 class94_2)
    {
        object obj2 = this.method_300().vmethod_0();
        long num = this.method_55();
        Array array = (Array) this.method_300().vmethod_0();
        Type elementType = array.GetType().GetElementType();
        if (ReferenceEquals(elementType, typeof(short)))
        {
            Class94 class2 = Class30.smethod_1(obj2, typeof(short));
            ((short[]) array)[(int) ((IntPtr) num)] = (short) class2.vmethod_0();
        }
        else if (ReferenceEquals(elementType, typeof(ushort)))
        {
            Class94 class3 = Class30.smethod_1(obj2, typeof(ushort));
            ((ushort[]) array)[(int) ((IntPtr) num)] = (ushort) class3.vmethod_0();
        }
        else if (ReferenceEquals(elementType, typeof(char)))
        {
            Class94 class4 = Class30.smethod_1(obj2, typeof(char));
            ((char[]) array)[(int) ((IntPtr) num)] = (char) class4.vmethod_0();
        }
        else if (elementType.IsEnum)
        {
            this.method_147(elementType, obj2, num, array);
        }
        else
        {
            this.method_147(typeof(short), obj2, num, array);
        }
    }

    private void method_203(Class94 class94_2)
    {
        float num2;
        Class94 class2 = this.method_300();
        int num = class2.vmethod_2();
        if (num > 11)
        {
            if (num == 0x11)
            {
                num2 = (float) ((Class117) class2).method_2();
            }
            else if (num == 0x18)
            {
                num2 = Convert.ToUInt64(((Class98) class2).method_2());
            }
            else
            {
                goto TR_0000;
            }
        }
        else if (num == 7)
        {
            num2 = ((Class118) class2).method_2();
        }
        else if (num == 11)
        {
            num2 = ((Class99) class2).method_2();
        }
        else
        {
            goto TR_0000;
        }
        Class117 class1 = new Class117();
        class1.method_3((double) num2);
        this.method_195(class1);
        return;
    TR_0000:
        throw new InvalidOperationException();
    }

    private void method_204(Class94 class94_2)
    {
        this.method_44(true);
    }

    private void method_205(int int_0, Type[] type_9, Type[] type_10, bool bool_2)
    {
        this.class29_1.method_0().vmethod_9((long) int_0, 0);
        this.method_73(this.class29_1);
        Class86 class3 = this.method_222(this.class29_1);
        this.method_49(class3);
        int length = class3.method_2().Length;
        object[] objArray = new object[length];
        Class94[] classArray = new Class94[length];
        if ((this.type_4 != null) & bool_2)
        {
            int num5 = class3.method_12() ? 0 : 1;
            Type[] types = new Type[length - num5];
            int index = length - 1;
            while (true)
            {
                if (index < num5)
                {
                    MethodInfo info = this.type_4.GetMethod(class3.method_4(), BindingFlags.SetProperty | BindingFlags.GetProperty | BindingFlags.InvokeMethod | BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance, null, types, null);
                    this.type_4 = null;
                    if (info == null)
                    {
                        break;
                    }
                    this.method_124(info, true);
                    return;
                }
                types[index] = this.method_189(class3.method_2()[index].method_0(), true);
                index--;
            }
        }
        for (int i = length - 1; i >= 0; i--)
        {
            Class94 class2 = this.method_300();
            classArray[i] = class2;
            Class106 class5 = class2 as Class106;
            if (class5 != null)
            {
                class2 = this.method_255(class5);
            }
            if (class2.method_0() != null)
            {
                class2 = Class30.smethod_1(null, class2.method_0()).vmethod_3(class2);
            }
            objArray[i] = Class30.smethod_1(null, this.method_189(class3.method_2()[i].method_0(), true)).vmethod_3(class2).vmethod_0();
            if (((i == 0) & bool_2) && (!class3.method_12() && (objArray[i] == null)))
            {
                throw new NullReferenceException();
            }
        }
        Class4 class4 = new Class4(this.class16_0);
        object[] objArray2 = new object[] { this.module_0.Assembly };
        object obj2 = class4.method_185(this.stream_0, int_0, objArray, type_9, type_10, objArray2);
        Type objA = class4.method_189(class4.class86_0.method_8(), true);
        if (!ReferenceEquals(objA, type_1))
        {
            this.method_195(Class30.smethod_1(obj2, objA));
        }
    }

    private void method_206(Class94 class94_2)
    {
        this.method_109(typeof(int));
    }

    private void method_207(Class94 class94_2)
    {
        this.method_195(class94_2);
    }

    private void method_208(Class94 class94_2)
    {
        Class118 class1 = new Class118();
        class1.method_3(3);
        this.method_195(class1);
    }

    private void method_209()
    {
        this.method_152();
    }

    private Class94 method_21(Class94 class94_2, Class94 class94_3, bool bool_2)
    {
        if (class94_2.vmethod_2() == 7)
        {
            if (class94_3.vmethod_2() == 7)
            {
                if (!bool_2)
                {
                    int num = ((Class118) class94_2).method_2();
                    Class118 class1 = new Class118();
                    class1.method_3(num / ((Class118) class94_3).method_2());
                    return class1;
                }
                uint num3 = (uint) ((Class118) class94_2).method_2();
                Class118 class2 = new Class118();
                class2.method_3((int) (num3 / ((Class118) class94_3).method_2()));
                return class2;
            }
            if (class94_3.vmethod_2() == 11)
            {
                Class99 class3 = new Class99();
                class3.method_3((long) ((Class118) class94_2).method_2());
                return smethod_30(class3, class94_3, bool_2);
            }
            if (class94_3.vmethod_2() == 0x18)
            {
                Type objA = Enum.GetUnderlyingType(class94_3.vmethod_0().GetType());
                if (!ReferenceEquals(objA, typeof(long)) && !ReferenceEquals(objA, typeof(ulong)))
                {
                    Class118 class4 = new Class118();
                    class4.method_3(Convert.ToInt32(class94_3.vmethod_0()));
                    return this.method_21(class94_2, class4, bool_2);
                }
                Class99 class5 = new Class99();
                class5.method_3((long) ((Class118) class94_2).method_2());
                Class99 class6 = new Class99();
                class6.method_3(Convert.ToInt64(class94_3.vmethod_0()));
                return smethod_30(class5, class6, bool_2);
            }
        }
        if (class94_2.vmethod_2() == 11)
        {
            if (class94_3.vmethod_2() == 11)
            {
                return smethod_30(class94_2, class94_3, bool_2);
            }
            if (class94_3.vmethod_2() == 7)
            {
                Class99 class7 = new Class99();
                class7.method_3((long) ((Class118) class94_3).method_2());
                return smethod_30(class94_2, class7, bool_2);
            }
            if (class94_3.vmethod_2() == 0x18)
            {
                Type objA = Enum.GetUnderlyingType(class94_3.vmethod_0().GetType());
                if (!ReferenceEquals(objA, typeof(long)) && !ReferenceEquals(objA, typeof(ulong)))
                {
                    Class118 class8 = new Class118();
                    class8.method_3(Convert.ToInt32(class94_3.vmethod_0()));
                    return smethod_30(class94_2, class8, bool_2);
                }
                Class99 class9 = new Class99();
                class9.method_3(Convert.ToInt64(class94_3.vmethod_0()));
                return smethod_30(class94_2, class9, bool_2);
            }
        }
        if ((class94_2.vmethod_2() == 0x11) && (class94_3.vmethod_2() == 0x11))
        {
            Class117 class10 = new Class117();
            class10.method_3(((Class117) class94_2).method_2() / ((Class117) class94_3).method_2());
            return class10;
        }
        if (class94_2.vmethod_2() != 0x18)
        {
            throw new InvalidOperationException();
        }
        Type underlyingType = Enum.GetUnderlyingType(class94_2.vmethod_0().GetType());
        if (!ReferenceEquals(underlyingType, typeof(long)) && !ReferenceEquals(underlyingType, typeof(ulong)))
        {
            Class118 class11 = new Class118();
            class11.method_3(Convert.ToInt32(class94_2.vmethod_0()));
            return this.method_21(class11, class94_3, bool_2);
        }
        Class99 class12 = new Class99();
        class12.method_3(Convert.ToInt64(class94_2.vmethod_0()));
        return this.method_21(class12, class94_3, bool_2);
    }

    private void method_210(Class94 class94_2)
    {
        this.method_109(Class58.type_0);
    }

    private void method_211(Class94 class94_2)
    {
        Class94 class3 = this.method_300();
        this.method_195(this.method_16(class3, this.method_300(), true, true));
    }

    private void method_212(Class94 class94_2)
    {
        this.method_201(false);
    }

    private bool method_213(Type type_9, Class3 class3_0)
    {
        Class37 class2 = (Class37) class3_0.method_4();
        if (Class67.smethod_0(type_9).IsGenericParameter)
        {
            return ((class2 == null) || class2.method_2());
        }
        Type type = this.method_189(class3_0.method_2(), false);
        return Class21.smethod_0(type_9, type);
    }

    private Class94 method_214(Class94 class94_2, Class94 class94_3, bool bool_2, bool bool_3)
    {
        if (class94_2.vmethod_2() == 7)
        {
            if (class94_3.vmethod_2() == 7)
            {
                if (!bool_3)
                {
                    int num = ((Class118) class94_2).method_2();
                    int num2 = ((Class118) class94_3).method_2();
                    int num3 = !bool_2 ? (num + num2) : (num + num2);
                    Class118 class1 = new Class118();
                    class1.method_3(num3);
                    return class1;
                }
                uint num4 = (uint) ((Class118) class94_2).method_2();
                uint num5 = (uint) ((Class118) class94_3).method_2();
                uint num6 = !bool_2 ? (num4 + num5) : (num4 + num5);
                Class118 class2 = new Class118();
                class2.method_3((int) num6);
                return class2;
            }
            if (class94_3.vmethod_2() == 11)
            {
                Class99 class3 = new Class99();
                class3.method_3((long) ((Class118) class94_2).method_2());
                return smethod_4(class3, class94_3, bool_2, bool_3);
            }
            if (class94_3.vmethod_2() == 0x18)
            {
                Type objA = Enum.GetUnderlyingType(class94_3.vmethod_0().GetType());
                if (!ReferenceEquals(objA, typeof(long)) && !ReferenceEquals(objA, typeof(ulong)))
                {
                    Class118 class4 = new Class118();
                    class4.method_3(Convert.ToInt32(class94_3.vmethod_0()));
                    return this.method_214(class94_2, class4, bool_2, bool_3);
                }
                Class99 class5 = new Class99();
                class5.method_3((long) ((Class118) class94_2).method_2());
                Class99 class6 = new Class99();
                class6.method_3(Convert.ToInt64(class94_3.vmethod_0()));
                return smethod_4(class5, class6, bool_2, bool_3);
            }
        }
        if (class94_2.vmethod_2() == 11)
        {
            if (class94_3.vmethod_2() == 11)
            {
                return smethod_4(class94_2, class94_3, bool_2, bool_3);
            }
            if (class94_3.vmethod_2() == 7)
            {
                Class99 class7 = new Class99();
                class7.method_3((long) ((Class118) class94_3).method_2());
                return smethod_4(class94_2, class7, bool_2, bool_3);
            }
            if (class94_3.vmethod_2() == 0x18)
            {
                Type objA = Enum.GetUnderlyingType(class94_3.vmethod_0().GetType());
                if (!ReferenceEquals(objA, typeof(long)) && !ReferenceEquals(objA, typeof(ulong)))
                {
                    Class118 class8 = new Class118();
                    class8.method_3(Convert.ToInt32(class94_3.vmethod_0()));
                    return smethod_4(class94_2, class8, bool_2, bool_3);
                }
                Class99 class9 = new Class99();
                class9.method_3(Convert.ToInt64(class94_3.vmethod_0()));
                return smethod_4(class94_2, class9, bool_2, bool_3);
            }
        }
        if ((class94_2.vmethod_2() == 0x11) && (class94_3.vmethod_2() == 0x11))
        {
            Class117 class10 = new Class117();
            class10.method_3(((Class117) class94_2).method_2() + ((Class117) class94_3).method_2());
            return class10;
        }
        if (class94_2.vmethod_2() != 0x18)
        {
            throw new InvalidOperationException();
        }
        Type underlyingType = Enum.GetUnderlyingType(class94_2.vmethod_0().GetType());
        if (!ReferenceEquals(underlyingType, typeof(long)) && !ReferenceEquals(underlyingType, typeof(ulong)))
        {
            Class118 class11 = new Class118();
            class11.method_3(Convert.ToInt32(class94_2.vmethod_0()));
            return this.method_214(class11, class94_3, bool_2, bool_3);
        }
        Class99 class12 = new Class99();
        class12.method_3(Convert.ToInt64(class94_2.vmethod_0()));
        return this.method_214(class12, class94_3, bool_2, bool_3);
    }

    private void method_215(object object_3)
    {
        Exception exception = object_3 as Exception;
        if (exception != null)
        {
            smethod_8(exception);
        }
        smethod_2(object_3);
    }

    private void method_216(Class94 class94_2)
    {
        if (this.object_2 == null)
        {
            throw new InvalidOperationException();
        }
        this.method_215(this.object_2);
    }

    private void method_217(Class94 class94_2)
    {
        object obj2 = this.method_300().vmethod_0();
        long num = this.method_55();
        Array array = (Array) this.method_300().vmethod_0();
        Type elementType = array.GetType().GetElementType();
        if (ReferenceEquals(elementType, typeof(long)))
        {
            Class94 class2 = Class30.smethod_1(obj2, typeof(long));
            ((long[]) array)[(int) ((IntPtr) num)] = (long) class2.vmethod_0();
        }
        else if (ReferenceEquals(elementType, typeof(ulong)))
        {
            Class94 class3 = Class30.smethod_1(obj2, typeof(ulong));
            ((ulong[]) array)[(int) ((IntPtr) num)] = (ulong) class3.vmethod_0();
        }
        else if (elementType.IsEnum)
        {
            this.method_147(elementType, obj2, num, array);
        }
        else
        {
            this.method_147(typeof(long), obj2, num, array);
        }
    }

    private void method_218(Class94 class94_2)
    {
        this.method_201(true);
    }

    private void method_219(Class94 class94_2)
    {
    }

    private void method_22(Stream stream_1, long long_1, string string_0)
    {
        int num = this.method_259();
        Class49 class2 = new Class49(stream_1, num);
        this.class29_1 = new Class29(class2);
        if (string_0 != null)
        {
            long_1 = this.method_11(string_0);
        }
        Class48 class3 = this.class29_1.method_0();
        Monitor.Enter(class3);
        class3.vmethod_9(long_1, 0);
        this.method_73(this.class29_1);
        this.class86_0 = this.method_222(this.class29_1);
        this.class25_0 = smethod_15(this.class29_1);
        this.byte_0 = smethod_7(this.class29_1);
        this.method_24();
    }

    private void method_220(Class94 class94_2)
    {
        this.method_195(new Class102());
    }

    private void method_221(bool bool_2)
    {
        ushort num2;
        Class94 class2 = this.method_300();
        int num = class2.vmethod_2();
        if (num > 11)
        {
            if (num == 0x11)
            {
                num2 = !bool_2 ? ((ushort) ((Class117) class2).method_2()) : ((ushort) ((Class117) class2).method_2());
            }
            else if (num == 0x18)
            {
                num2 = !bool_2 ? ((ushort) Convert.ToUInt64(((Class98) class2).method_2())) : ((ushort) Convert.ToUInt64(((Class98) class2).method_2()));
            }
            else
            {
                goto TR_0000;
            }
        }
        else if (num == 7)
        {
            num2 = !bool_2 ? ((ushort) ((Class118) class2).method_2()) : ((ushort) ((uint) ((Class118) class2).method_2()));
        }
        else if (num == 11)
        {
            num2 = !bool_2 ? ((ushort) ((Class99) class2).method_2()) : ((ushort) ((ulong) ((Class99) class2).method_2()));
        }
        else
        {
            goto TR_0000;
        }
        Class118 class1 = new Class118();
        class1.method_3(num2);
        this.method_195(class1);
        return;
    TR_0000:
        throw new InvalidOperationException();
    }

    private Class86 method_222(Class29 class29_2)
    {
        Class86 class1 = new Class86();
        class1.method_9(class29_2.method_19());
        class1.method_1(this.method_129(class29_2));
        class1.method_7(class29_2.method_19());
        class1.method_3(this.method_279(class29_2));
        class1.method_5(class29_2.method_9());
        class1.method_11(class29_2.method_6());
        return class1;
    }

    private void method_223(Class94 class94_2)
    {
        this.method_144(type_8);
    }

    private void method_224(Class94 class94_2)
    {
        this.method_5(true);
    }

    private void method_225(Class94 class94_2)
    {
        this.method_221(true);
    }

    private void method_226(Class94 class94_2)
    {
        this.method_109(type_8);
    }

    private void method_227()
    {
        if (this.class20_1.Count == 0)
        {
            if (this.bool_0)
            {
                this.method_215(this.object_2);
            }
        }
        else
        {
            Struct1 struct2 = this.class20_1.method_6();
            if (struct2.method_1() == null)
            {
                this.class20_0.method_0();
            }
            else
            {
                Class102 class1 = new Class102();
                class1.vmethod_1(struct2.method_1());
                this.method_195(class1);
            }
            this.method_244(struct2.method_0());
        }
    }

    private void method_228(Class94 class94_2)
    {
        this.method_109(typeof(short));
    }

    private Class94 method_229(Class94 class94_2, Class94 class94_3)
    {
        if (class94_2.vmethod_2() == 7)
        {
            if (class94_3.vmethod_2() == 7)
            {
                int num3 = ((Class118) class94_2).method_2();
                Class118 class1 = new Class118();
                class1.method_3(num3 ^ ((Class118) class94_3).method_2());
                return class1;
            }
            if (class94_3.vmethod_2() == 0x18)
            {
                int num = ((Class118) class94_2).method_2();
                Type underlyingType = Enum.GetUnderlyingType(class94_3.vmethod_0().GetType());
                if (!ReferenceEquals(underlyingType, typeof(long)) && !ReferenceEquals(underlyingType, typeof(ulong)))
                {
                    Class118 class2 = new Class118();
                    class2.method_3(num ^ Convert.ToInt32(class94_3.vmethod_0()));
                    return class2;
                }
                long num5 = Convert.ToInt64(class94_3.vmethod_0());
                Class99 class3 = new Class99();
                class3.method_3(num ^ num5);
                return class3;
            }
        }
        if (class94_2.vmethod_2() == 11)
        {
            if (class94_3.vmethod_2() == 11)
            {
                long num7 = ((Class99) class94_2).method_2();
                Class99 class4 = new Class99();
                class4.method_3(num7 ^ ((Class99) class94_3).method_2());
                return class4;
            }
            if (class94_3.vmethod_2() == 0x18)
            {
                int num9 = ((Class118) class94_2).method_2();
                long num10 = Convert.ToInt64(class94_3.vmethod_0());
                Class99 class5 = new Class99();
                class5.method_3(num9 ^ num10);
                return class5;
            }
        }
        if (class94_2.vmethod_2() == 0x18)
        {
            if (class94_3.vmethod_2() == 7)
            {
                int num2 = ((Class118) class94_3).method_2();
                Type underlyingType = Enum.GetUnderlyingType(class94_2.vmethod_0().GetType());
                if (!ReferenceEquals(underlyingType, typeof(long)) && !ReferenceEquals(underlyingType, typeof(ulong)))
                {
                    int num12 = Convert.ToInt32(class94_2.vmethod_0());
                    Class118 class6 = new Class118();
                    class6.method_3(num12 ^ num2);
                    return class6;
                }
                long num11 = Convert.ToInt64(class94_3.vmethod_0());
                Class99 class7 = new Class99();
                class7.method_3(num11 ^ num2);
                return class7;
            }
            if (class94_3.vmethod_2() == 11)
            {
                long num13 = Convert.ToInt64(class94_2.vmethod_0());
                Class99 class8 = new Class99();
                class8.method_3(num13 ^ ((Class99) class94_3).method_2());
                return class8;
            }
            if (class94_3.vmethod_2() == 0x18)
            {
                Type underlyingType = Enum.GetUnderlyingType(class94_2.vmethod_0().GetType());
                Type objA = Enum.GetUnderlyingType(class94_3.vmethod_0().GetType());
                if (!ReferenceEquals(underlyingType, typeof(long)) && (!ReferenceEquals(underlyingType, typeof(ulong)) && (!ReferenceEquals(objA, typeof(long)) && !ReferenceEquals(objA, typeof(ulong)))))
                {
                    int num17 = Convert.ToInt32(class94_2.vmethod_0());
                    Class118 class9 = new Class118();
                    class9.method_3(num17 ^ Convert.ToInt32(class94_3.vmethod_0()));
                    return class9;
                }
                long num15 = Convert.ToInt64(class94_2.vmethod_0());
                Class99 class10 = new Class99();
                class10.method_3(num15 ^ Convert.ToInt64(class94_3.vmethod_0()));
                return class10;
            }
        }
        throw new InvalidOperationException();
    }

    private void method_23(Class94 class94_2)
    {
        this.method_175(false);
    }

    private Class94 method_230(Class29 class29_2, int int_0)
    {
        switch (int_0)
        {
            case 0:
            case 8:
            {
                Class119 class7 = new Class119();
                class7.method_3(class29_2.method_24());
                return class7;
            }
            case 1:
            {
                int num = class29_2.method_19();
                Class118[] classArray = new Class118[num];
                for (int i = 0; i < num; i++)
                {
                    Class118 class1 = new Class118();
                    class1.method_3(class29_2.method_19());
                    classArray[i] = class1;
                }
                Class116 class2 = new Class116();
                class2.method_3(classArray);
                return class2;
            }
            case 2:
            case 11:
            {
                Class118 class9 = new Class118();
                class9.method_3(class29_2.method_19());
                return class9;
            }
            case 3:
            case 4:
            {
                Class121 class3 = new Class121();
                class3.method_3(class29_2.method_6());
                return class3;
            }
            case 5:
            {
                Class114 class4 = new Class114();
                class4.method_3(class29_2.method_26());
                return class4;
            }
            case 6:
            {
                Class117 class5 = new Class117();
                class5.method_3(class29_2.method_27());
                return class5;
            }
            case 7:
            {
                Class99 class6 = new Class99();
                class6.method_3(class29_2.method_21());
                return class6;
            }
            case 9:
            {
                Class104 class8 = new Class104();
                class8.method_3(class29_2.method_20());
                return class8;
            }
            case 10:
                return null;

            case 12:
            {
                Class115 class10 = new Class115();
                class10.method_3(class29_2.method_7());
                return class10;
            }
        }
        throw new Exception("Unknown operand type.");
    }

    private void method_231(Class94 class94_2)
    {
        this.method_215(this.method_300().vmethod_0());
    }

    private Delegate0 method_232(Struct2 struct2_0)
    {
        Delegate0 delegate2;
        Monitor.Enter(this.dictionary_1);
        this.dictionary_1.TryGetValue(struct2_0, out delegate2);
        return delegate2;
    }

    private void method_233()
    {
        if (!this.class16_0.method_1())
        {
            Monitor.Enter(this.class16_0);
            if (!this.class16_0.method_1())
            {
                this.dictionary_0 = this.method_166();
                this.method_94();
                this.class16_0.method_2(true);
            }
        }
        if (this.dictionary_0 == null)
        {
            this.dictionary_0 = this.method_166();
        }
    }

    [DebuggerNonUserCode]
    private MethodBase method_234(int int_0)
    {
        Class3 class2 = this.method_130(int_0);
        MethodBase base2 = this.method_118(int_0, class2);
        this.method_135(base2);
        return base2;
    }

    private void method_235(ref Struct0 struct0_0)
    {
        if (struct0_0.bool_0)
        {
            Monitor.Exit(object_1);
        }
    }

    private void method_236(Class94 class94_2)
    {
        Class94 class3 = this.method_300();
        this.method_195(this.method_214(class3, this.method_300(), true, true));
    }

    private void method_237(Class94 class94_2)
    {
        Class121 class2 = (Class121) class94_2;
        Class112 class1 = new Class112();
        class1.method_3(this.class94_0[class2.method_2()]);
        this.method_195(class1);
    }

    private void method_238(Class94 class94_2)
    {
        int num = ((Class118) class94_2).method_2();
        Type type = this.method_189(num, true);
        long num2 = this.method_55();
        Array array = (Array) this.method_300().vmethod_0();
        Class110 class1 = new Class110();
        class1.method_5(array);
        class1.method_3(type);
        class1.method_7(num2);
        this.method_195(class1);
    }

    [Conditional("DEBUG")]
    private void method_239(object object_3)
    {
    }

    private void method_24()
    {
        smethod_13<Class25>(this.class25_0, Class5.comparison_0 ?? (Class5.comparison_0 = new Comparison<Class25>(Class5.class5_0.method_0)));
    }

    private void method_240(Class94 class94_2)
    {
        object obj2 = this.method_300().vmethod_0();
        long num = this.method_55();
        Array array = (Array) this.method_300().vmethod_0();
        Type elementType = array.GetType().GetElementType();
        if (ReferenceEquals(elementType, typeof(int)))
        {
            Class94 class2 = Class30.smethod_1(obj2, typeof(int));
            ((int[]) array)[(int) ((IntPtr) num)] = (int) class2.vmethod_0();
        }
        else if (ReferenceEquals(elementType, typeof(uint)))
        {
            Class94 class3 = Class30.smethod_1(obj2, typeof(uint));
            ((uint[]) array)[(int) ((IntPtr) num)] = (uint) class3.vmethod_0();
        }
        else if (elementType.IsEnum)
        {
            this.method_147(elementType, obj2, num, array);
        }
        else
        {
            this.method_147(typeof(int), obj2, num, array);
        }
    }

    private void method_241(bool bool_2)
    {
        byte num2;
        Class94 class2 = this.method_300();
        int num = class2.vmethod_2();
        if (num > 11)
        {
            if (num == 0x11)
            {
                num2 = !bool_2 ? ((byte) ((Class117) class2).method_2()) : ((byte) ((Class117) class2).method_2());
            }
            else if (num == 0x18)
            {
                num2 = !bool_2 ? ((byte) Convert.ToUInt64(((Class98) class2).method_2())) : ((byte) Convert.ToUInt64(((Class98) class2).method_2()));
            }
            else
            {
                goto TR_0000;
            }
        }
        else if (num == 7)
        {
            num2 = !bool_2 ? ((byte) ((Class118) class2).method_2()) : ((byte) ((uint) ((Class118) class2).method_2()));
        }
        else if (num == 11)
        {
            num2 = !bool_2 ? ((byte) ((Class99) class2).method_2()) : ((byte) ((ulong) ((Class99) class2).method_2()));
        }
        else
        {
            goto TR_0000;
        }
        Class118 class1 = new Class118();
        class1.method_3(num2);
        this.method_195(class1);
        return;
    TR_0000:
        throw new InvalidOperationException();
    }

    private Class94 method_242(Class94 class94_2, Class94 class94_3)
    {
        if (class94_2.vmethod_2() == 7)
        {
            if (class94_3.vmethod_2() == 7)
            {
                int num3 = ((Class118) class94_2).method_2();
                Class118 class1 = new Class118();
                class1.method_3(num3 | ((Class118) class94_3).method_2());
                return class1;
            }
            if (class94_3.vmethod_2() == 0x18)
            {
                int num = ((Class118) class94_2).method_2();
                Type underlyingType = Enum.GetUnderlyingType(class94_3.vmethod_0().GetType());
                if (!ReferenceEquals(underlyingType, typeof(long)) && !ReferenceEquals(underlyingType, typeof(ulong)))
                {
                    Class118 class2 = new Class118();
                    class2.method_3(num | Convert.ToInt32(class94_3.vmethod_0()));
                    return class2;
                }
                long num5 = Convert.ToInt64(class94_3.vmethod_0());
                Class99 class3 = new Class99();
                class3.method_3(num | num5);
                return class3;
            }
        }
        if (class94_2.vmethod_2() == 11)
        {
            if (class94_3.vmethod_2() == 11)
            {
                long num7 = ((Class99) class94_2).method_2();
                Class99 class4 = new Class99();
                class4.method_3(num7 | ((Class99) class94_3).method_2());
                return class4;
            }
            if (class94_3.vmethod_2() == 0x18)
            {
                int num9 = ((Class118) class94_2).method_2();
                long num10 = Convert.ToInt64(class94_3.vmethod_0());
                Class99 class5 = new Class99();
                class5.method_3(num9 | num10);
                return class5;
            }
        }
        if (class94_2.vmethod_2() == 0x18)
        {
            if (class94_3.vmethod_2() == 7)
            {
                int num2 = ((Class118) class94_3).method_2();
                Type underlyingType = Enum.GetUnderlyingType(class94_2.vmethod_0().GetType());
                if (!ReferenceEquals(underlyingType, typeof(long)) && !ReferenceEquals(underlyingType, typeof(ulong)))
                {
                    int num12 = Convert.ToInt32(class94_2.vmethod_0());
                    Class118 class6 = new Class118();
                    class6.method_3(num12 | num2);
                    return class6;
                }
                long num11 = Convert.ToInt64(class94_3.vmethod_0());
                Class99 class7 = new Class99();
                class7.method_3(num11 | num2);
                return class7;
            }
            if (class94_3.vmethod_2() == 11)
            {
                long num13 = Convert.ToInt64(class94_2.vmethod_0());
                Class99 class8 = new Class99();
                class8.method_3(num13 | ((Class99) class94_3).method_2());
                return class8;
            }
            if (class94_3.vmethod_2() == 0x18)
            {
                Type underlyingType = Enum.GetUnderlyingType(class94_2.vmethod_0().GetType());
                Type objA = Enum.GetUnderlyingType(class94_3.vmethod_0().GetType());
                if (!ReferenceEquals(underlyingType, typeof(long)) && (!ReferenceEquals(underlyingType, typeof(ulong)) && (!ReferenceEquals(objA, typeof(long)) && !ReferenceEquals(objA, typeof(ulong)))))
                {
                    int num17 = Convert.ToInt32(class94_2.vmethod_0());
                    Class118 class9 = new Class118();
                    class9.method_3(num17 | Convert.ToInt32(class94_3.vmethod_0()));
                    return class9;
                }
                long num15 = Convert.ToInt64(class94_2.vmethod_0());
                Class99 class10 = new Class99();
                class10.method_3(num15 | Convert.ToInt64(class94_3.vmethod_0()));
                return class10;
            }
        }
        throw new InvalidOperationException();
    }

    private MethodBase method_243(Class34 class34_0)
    {
        Type type = this.method_189(class34_0.method_4().method_2(), false);
        BindingFlags bindingAttr = smethod_12(class34_0.method_2());
        MethodInfo info2 = null;
        MemberInfo[] member = type.GetMember(class34_0.method_6(), bindingAttr);
        int index = 0;
        while (true)
        {
            if (index >= member.Length)
            {
                break;
            }
            MethodInfo info = (MethodInfo) member[index];
            if (info.IsGenericMethodDefinition)
            {
                ParameterInfo[] parameters = info.GetParameters();
                if ((parameters.Length == class34_0.method_8().Length) && ((info.GetGenericArguments().Length == class34_0.method_10().Length) && this.method_213(info.ReturnType, class34_0.method_12())))
                {
                    bool flag = true;
                    int num = 0;
                    while (true)
                    {
                        if (num < parameters.Length)
                        {
                            if (this.method_213(parameters[num].ParameterType, class34_0.method_8()[num]))
                            {
                                num++;
                                continue;
                            }
                            flag = false;
                        }
                        if (flag)
                        {
                            info2 = info;
                        }
                        break;
                    }
                }
            }
            index++;
        }
        if (info2 == null)
        {
            throw new Exception(string.Format("Cannot bind method: {0}.{1}", type.Name, class34_0.method_6()));
        }
        Type[] typeArguments = new Type[class34_0.method_10().Length];
        for (int i = 0; i < typeArguments.Length; i++)
        {
            typeArguments[i] = this.method_189(class34_0.method_10()[i].method_2(), true);
        }
        return info2.MakeGenericMethod(typeArguments);
    }

    private void method_244(uint uint_0)
    {
        this.nullable_0 = new uint?(uint_0);
    }

    private void method_245(bool bool_2)
    {
        IntPtr ptr;
        Class94 class2 = this.method_300();
        int num = class2.vmethod_2();
        if (num > 11)
        {
            if (num == 0x11)
            {
                if (bool_2)
                {
                    ptr = new IntPtr((long) ((Class117) class2).method_2());
                }
                else
                {
                    ptr = new IntPtr((long) ((Class117) class2).method_2());
                }
            }
            else if (num == 0x18)
            {
                if (bool_2)
                {
                    ptr = new IntPtr((long) Convert.ToUInt64(((Class98) class2).method_2()));
                }
                else
                {
                    ptr = new IntPtr((long) Convert.ToUInt64(((Class98) class2).method_2()));
                }
            }
            else
            {
                goto TR_0000;
            }
        }
        else if (num == 7)
        {
            if (bool_2)
            {
                ptr = new IntPtr(((Class118) class2).method_2());
            }
            else
            {
                ptr = new IntPtr(((Class118) class2).method_2());
            }
        }
        else if (num == 11)
        {
            if (bool_2)
            {
                ptr = new IntPtr(((Class99) class2).method_2());
            }
            else
            {
                ptr = new IntPtr(((Class99) class2).method_2());
            }
        }
        else
        {
            goto TR_0000;
        }
        Class105 class1 = new Class105();
        class1.method_3(ptr);
        this.method_195(class1);
        return;
    TR_0000:
        throw new InvalidOperationException();
    }

    private void method_246(Class94 class94_2)
    {
        this.method_227();
    }

    private object method_247(MethodBase methodBase_0, object object_3, object[] object_4)
    {
        return (!methodBase_0.IsConstructor ? methodBase_0.Invoke(object_3, object_4) : Activator.CreateInstance(methodBase_0.DeclaringType, BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance, null, object_4, null));
    }

    private void method_248(Class94 class94_2)
    {
        this.method_195(this.class94_0[3].vmethod_4());
    }

    private void method_249(Class94 class94_2)
    {
        throw new NotSupportedException("Localloc not supported.");
    }

    private void method_25(Class94 class94_2)
    {
        this.method_265(Class58.type_0);
    }

    private void method_250(Class94 class94_2)
    {
        MethodBase objB = this.method_234(((Class118) class94_2).method_2());
        Type declaringType = objB.DeclaringType;
        Type type3 = this.method_300().vmethod_0().GetType();
        ParameterInfo[] parameters = objB.GetParameters();
        Type[] types = new Type[parameters.Length];
        for (int i = 0; i < parameters.Length; i++)
        {
            types[i] = parameters[i].ParameterType;
        }
        MethodBase base3 = null;
        Type objA = type3;
        while (true)
        {
            if ((objA != null) && !ReferenceEquals(objA, declaringType))
            {
                MethodInfo info = objA.GetMethod(objB.Name, BindingFlags.ExactBinding | BindingFlags.SetProperty | BindingFlags.GetProperty | BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance | BindingFlags.DeclaredOnly, null, CallingConventions.Any, types, null);
                if ((info == null) || !ReferenceEquals(info.GetBaseDefinition(), objB))
                {
                    objA = objA.BaseType;
                    continue;
                }
                base3 = info;
            }
            if (base3 == null)
            {
                base3 = objB;
            }
            Class97 class1 = new Class97();
            class1.method_3(base3);
            this.method_195(class1);
            return;
        }
    }

    private bool method_251(long long_1, uint uint_0, uint uint_1)
    {
        return ((long_1 >= uint_0) && (long_1 <= (uint_0 + uint_1)));
    }

    private void method_252(Class94 class94_2)
    {
        this.method_175(true);
    }

    private void method_253(Class94 class94_2)
    {
        long num2;
        Class94 class2 = this.method_300();
        int num = class2.vmethod_2();
        if (num > 11)
        {
            if (num == 0x11)
            {
                num2 = (long) ((Class117) class2).method_2();
            }
            else if (num == 0x18)
            {
                num2 = (long) Convert.ToUInt64(((Class98) class2).method_2());
            }
            else
            {
                goto TR_0000;
            }
        }
        else if (num == 7)
        {
            num2 = (uint) ((Class118) class2).method_2();
        }
        else if (num == 11)
        {
            num2 = (long) ((ulong) ((Class99) class2).method_2());
        }
        else
        {
            goto TR_0000;
        }
        Class99 class1 = new Class99();
        class1.method_3(num2);
        this.method_195(class1);
        return;
    TR_0000:
        throw new InvalidOperationException();
    }

    private void method_254(Class94 class94_2)
    {
        Class119 class2 = (Class119) class94_2;
        this.method_195(this.class94_0[class2.method_2()].vmethod_4());
    }

    private Class94 method_255(Class106 class106_0)
    {
        int num = class106_0.vmethod_2();
        if (num != 3)
        {
            switch (num)
            {
                case 12:
                    return ((Class112) class106_0).method_2();

                case 13:
                    return this.class94_1[((Class108) class106_0).method_2()];

                case 0x10:
                    break;

                case 0x12:
                {
                    Class107 class2 = (Class107) class106_0;
                    return Class30.smethod_1(class2.method_4().GetValue(class2.method_2()), null);
                }
                default:
                    throw new ArgumentOutOfRangeException();
            }
        }
        Class109 class3 = (Class109) class106_0;
        return Class30.smethod_1(class3.vmethod_5(), class3.method_2());
    }

    public object method_256(Stream stream_1, string string_0, object[] object_3)
    {
        return this.method_48(stream_1, string_0, object_3, null, null, null);
    }

    private void method_257(Class94 class94_2)
    {
        int num = ((Class118) class94_2).method_2();
        Class94 class2 = this.method_300();
        if (this.method_281(class2, this.method_189(num, true)))
        {
            this.method_195(class2);
        }
        else
        {
            this.method_195(new Class102());
        }
    }

    private void method_258(bool bool_2)
    {
        UIntPtr ptr;
        Class94 class2 = this.method_300();
        int num = class2.vmethod_2();
        if (num > 11)
        {
            if (num == 0x11)
            {
                if (bool_2)
                {
                    ptr = new UIntPtr((ulong) ((Class117) class2).method_2());
                }
                else
                {
                    ptr = new UIntPtr((ulong) ((Class117) class2).method_2());
                }
            }
            else if (num == 0x18)
            {
                if (bool_2)
                {
                    ptr = new UIntPtr(Convert.ToUInt64(((Class98) class2).method_2()));
                }
                else
                {
                    ptr = new UIntPtr(Convert.ToUInt64(((Class98) class2).method_2()));
                }
            }
            else
            {
                goto TR_0000;
            }
        }
        else if (num == 7)
        {
            if (bool_2)
            {
                ptr = new UIntPtr((uint) ((Class118) class2).method_2());
            }
            else
            {
                ptr = new UIntPtr((uint) ((Class118) class2).method_2());
            }
        }
        else if (num == 11)
        {
            if (bool_2)
            {
                ptr = new UIntPtr((ulong) ((Class99) class2).method_2());
            }
            else
            {
                ptr = new UIntPtr((ulong) ((Class99) class2).method_2());
            }
        }
        else
        {
            goto TR_0000;
        }
        Class100 class1 = new Class100();
        class1.method_3(ptr);
        this.method_195(class1);
        return;
    TR_0000:
        throw new InvalidOperationException();
    }

    private int method_259()
    {
        return -2144188571;
    }

    private Class94 method_26(Class94 class94_2, Class94 class94_3, bool bool_2)
    {
        if (class94_2.vmethod_2() == 7)
        {
            if (class94_3.vmethod_2() == 7)
            {
                if (!bool_2)
                {
                    int num = ((Class118) class94_2).method_2();
                    Class118 class1 = new Class118();
                    class1.method_3(num % ((Class118) class94_3).method_2());
                    return class1;
                }
                uint num3 = (uint) ((Class118) class94_2).method_2();
                Class118 class2 = new Class118();
                class2.method_3((int) (num3 % ((Class118) class94_3).method_2()));
                return class2;
            }
            if (class94_3.vmethod_2() == 11)
            {
                Class99 class3 = new Class99();
                class3.method_3((long) ((Class118) class94_2).method_2());
                return smethod_10(class3, class94_3, bool_2);
            }
            if (class94_3.vmethod_2() == 0x18)
            {
                Type objA = Enum.GetUnderlyingType(class94_3.vmethod_0().GetType());
                if (!ReferenceEquals(objA, typeof(long)) && !ReferenceEquals(objA, typeof(ulong)))
                {
                    Class118 class4 = new Class118();
                    class4.method_3(Convert.ToInt32(class94_3.vmethod_0()));
                    return this.method_26(class94_2, class4, bool_2);
                }
                Class99 class5 = new Class99();
                class5.method_3((long) ((Class118) class94_2).method_2());
                Class99 class6 = new Class99();
                class6.method_3(Convert.ToInt64(class94_3.vmethod_0()));
                return smethod_10(class5, class6, bool_2);
            }
        }
        if (class94_2.vmethod_2() == 11)
        {
            if (class94_3.vmethod_2() == 11)
            {
                return smethod_10(class94_2, class94_3, bool_2);
            }
            if (class94_3.vmethod_2() == 7)
            {
                Class99 class7 = new Class99();
                class7.method_3((long) ((Class118) class94_3).method_2());
                return smethod_10(class94_2, class7, bool_2);
            }
            if (class94_3.vmethod_2() == 0x18)
            {
                Type objA = Enum.GetUnderlyingType(class94_3.vmethod_0().GetType());
                if (!ReferenceEquals(objA, typeof(long)) && !ReferenceEquals(objA, typeof(ulong)))
                {
                    Class118 class8 = new Class118();
                    class8.method_3(Convert.ToInt32(class94_3.vmethod_0()));
                    return smethod_10(class94_2, class8, bool_2);
                }
                Class99 class9 = new Class99();
                class9.method_3(Convert.ToInt64(class94_3.vmethod_0()));
                return smethod_10(class94_2, class9, bool_2);
            }
        }
        if ((class94_2.vmethod_2() == 0x11) && (class94_3.vmethod_2() == 0x11))
        {
            Class117 class10 = new Class117();
            class10.method_3(((Class117) class94_2).method_2() % ((Class117) class94_3).method_2());
            return class10;
        }
        if (class94_2.vmethod_2() != 0x18)
        {
            throw new InvalidOperationException();
        }
        Type underlyingType = Enum.GetUnderlyingType(class94_2.vmethod_0().GetType());
        if (!ReferenceEquals(underlyingType, typeof(long)) && !ReferenceEquals(underlyingType, typeof(ulong)))
        {
            Class118 class11 = new Class118();
            class11.method_3(Convert.ToInt32(class94_2.vmethod_0()));
            return this.method_26(class11, class94_3, bool_2);
        }
        Class99 class12 = new Class99();
        class12.method_3(Convert.ToInt64(class94_2.vmethod_0()));
        return this.method_26(class12, class94_3, bool_2);
    }

    private void method_260(Class94 class94_2)
    {
        this.method_261(true);
    }

    private void method_261(bool bool_2)
    {
        sbyte num2;
        Class94 class2 = this.method_300();
        int num = class2.vmethod_2();
        if (num > 11)
        {
            if (num == 0x11)
            {
                num2 = !bool_2 ? ((sbyte) ((Class117) class2).method_2()) : ((sbyte) ((Class117) class2).method_2());
            }
            else if (num == 0x18)
            {
                num2 = !bool_2 ? ((sbyte) Convert.ToUInt64(((Class98) class2).method_2())) : ((sbyte) Convert.ToUInt64(((Class98) class2).method_2()));
            }
            else
            {
                goto TR_0000;
            }
        }
        else if (num == 7)
        {
            num2 = !bool_2 ? ((sbyte) ((Class118) class2).method_2()) : ((sbyte) ((Class118) class2).method_2());
        }
        else if (num == 11)
        {
            num2 = !bool_2 ? ((sbyte) ((Class99) class2).method_2()) : ((sbyte) ((Class99) class2).method_2());
        }
        else
        {
            goto TR_0000;
        }
        Class118 class1 = new Class118();
        class1.method_3(num2);
        this.method_195(class1);
        return;
    TR_0000:
        throw new InvalidOperationException();
    }

    private void method_262(Class94 class94_2)
    {
        ulong num2;
        Class94 class2 = this.method_300();
        int num = class2.vmethod_2();
        if (num > 11)
        {
            if (num == 0x11)
            {
                num2 = (ulong) ((Class117) class2).method_2();
            }
            else if (num == 0x18)
            {
                num2 = Convert.ToUInt64(((Class98) class2).method_2());
            }
            else
            {
                goto TR_0000;
            }
        }
        else if (num == 7)
        {
            num2 = (uint) ((Class118) class2).method_2();
        }
        else if (num == 11)
        {
            num2 = (ulong) ((Class99) class2).method_2();
        }
        else
        {
            goto TR_0000;
        }
        Class99 class1 = new Class99();
        class1.method_3((long) num2);
        this.method_195(class1);
        return;
    TR_0000:
        throw new InvalidOperationException();
    }

    private void method_263(Class94 class94_2)
    {
        this.method_150(false);
    }

    private void method_264(Class94 class94_2)
    {
        this.method_144(Class58.type_0);
    }

    private void method_265(Type type_9)
    {
        Array array = (Array) this.method_300().vmethod_0();
        this.method_195(Class30.smethod_1(array.GetValue(this.method_55()), type_9));
    }

    private void method_266(Class94 class94_2)
    {
        Class94 class2 = this.method_300();
        if (smethod_17(this.method_300(), class2))
        {
            uint num = ((Class104) class94_2).method_2();
            this.method_244(num);
        }
    }

    private Delegate0 method_267(MethodBase methodBase_0, bool bool_2)
    {
        DynamicMethod method = null;
        Type[] parameterTypes = new Type[] { Class58.type_0, type_0 };
        method = new DynamicMethod(string.Empty, Class58.type_0, parameterTypes, typeof(Class4).Module, true);
        ILGenerator iLGenerator = method.GetILGenerator();
        ParameterInfo[] parameters = methodBase_0.GetParameters();
        Type[] typeArray = new Type[parameters.Length];
        bool flag = false;
        for (int i = 0; i < parameters.Length; i++)
        {
            Type parameterType = parameters[i].ParameterType;
            if (parameterType.IsByRef)
            {
                flag = true;
                parameterType = parameterType.GetElementType();
            }
            typeArray[i] = parameterType;
        }
        LocalBuilder[] builderArray = new LocalBuilder[typeArray.Length];
        if (builderArray.Length != 0)
        {
            method.InitLocals = true;
        }
        for (int j = 0; j < typeArray.Length; j++)
        {
            builderArray[j] = iLGenerator.DeclareLocal(typeArray[j]);
        }
        for (int k = 0; k < typeArray.Length; k++)
        {
            iLGenerator.Emit(OpCodes.Ldarg_1);
            smethod_25(iLGenerator, k);
            iLGenerator.Emit(OpCodes.Ldelem_Ref);
            smethod_22(iLGenerator, typeArray[k]);
            iLGenerator.Emit(OpCodes.Stloc, builderArray[k]);
        }
        if (flag)
        {
            iLGenerator.BeginExceptionBlock();
        }
        if (!methodBase_0.IsStatic && !methodBase_0.IsConstructor)
        {
            iLGenerator.Emit(OpCodes.Ldarg_0);
            Type declaringType = methodBase_0.DeclaringType;
            if (!declaringType.IsValueType)
            {
                smethod_9(iLGenerator, declaringType);
            }
            else
            {
                iLGenerator.Emit(OpCodes.Unbox, declaringType);
                bool_2 = false;
            }
        }
        for (int m = 0; m < typeArray.Length; m++)
        {
            if (parameters[m].ParameterType.IsByRef)
            {
                iLGenerator.Emit(OpCodes.Ldloca_S, builderArray[m]);
            }
            else
            {
                iLGenerator.Emit(OpCodes.Ldloc, builderArray[m]);
            }
        }
        if (methodBase_0.IsConstructor)
        {
            iLGenerator.Emit(OpCodes.Newobj, (ConstructorInfo) methodBase_0);
            smethod_6(iLGenerator, methodBase_0.DeclaringType);
        }
        else
        {
            MethodInfo methodInfo = (MethodInfo) methodBase_0;
            if (bool_2 && !methodBase_0.IsStatic)
            {
                iLGenerator.EmitCall(OpCodes.Callvirt, methodInfo, null);
            }
            else
            {
                iLGenerator.EmitCall(OpCodes.Call, methodInfo, null);
            }
            if (ReferenceEquals(methodInfo.ReturnType, type_1))
            {
                iLGenerator.Emit(OpCodes.Ldnull);
            }
            else
            {
                smethod_6(iLGenerator, methodInfo.ReturnType);
            }
        }
        if (flag)
        {
            LocalBuilder local = iLGenerator.DeclareLocal(Class58.type_0);
            iLGenerator.Emit(OpCodes.Stloc, local);
            iLGenerator.BeginFinallyBlock();
            int index = 0;
            while (true)
            {
                if (index >= typeArray.Length)
                {
                    iLGenerator.EndExceptionBlock();
                    iLGenerator.Emit(OpCodes.Ldloc, local);
                    break;
                }
                if (parameters[index].ParameterType.IsByRef)
                {
                    iLGenerator.Emit(OpCodes.Ldarg_1);
                    smethod_25(iLGenerator, index);
                    iLGenerator.Emit(OpCodes.Ldloc, builderArray[index]);
                    if (builderArray[index].LocalType.IsValueType || Class67.smethod_0(builderArray[index].LocalType).IsGenericParameter)
                    {
                        iLGenerator.Emit(OpCodes.Box, builderArray[index].LocalType);
                    }
                    iLGenerator.Emit(OpCodes.Stelem_Ref);
                }
                index++;
            }
        }
        iLGenerator.Emit(OpCodes.Ret);
        return (Delegate0) method.CreateDelegate(typeof(Delegate0));
    }

    private void method_268(Class94 class94_2)
    {
        Class94 class2 = this.method_300();
        if (!smethod_20(this.method_300(), class2))
        {
            uint num = ((Class104) class94_2).method_2();
            this.method_244(num);
        }
    }

    private void method_269(Class94 class94_2)
    {
        Class94 class2 = this.method_300();
        if (smethod_29(this.method_300(), class2))
        {
            uint num = ((Class104) class94_2).method_2();
            this.method_244(num);
        }
    }

    private Delegate0 method_27(Struct2 struct2_0)
    {
        Delegate0 delegate2;
        Monitor.Enter(this.dictionary_1);
        this.dictionary_1.TryGetValue(struct2_0, out delegate2);
        if (delegate2 == null)
        {
            MethodBase key = struct2_0.method_0();
            Monitor.Enter(this.dictionary_2);
            while (this.dictionary_2.ContainsKey(key))
            {
                Monitor.Wait(this.dictionary_2);
            }
            this.dictionary_2[key] = null;
            Monitor.Enter(this.dictionary_1);
            this.dictionary_1.TryGetValue(struct2_0, out delegate2);
            if (delegate2 == null)
            {
                delegate2 = this.method_267(key, struct2_0.method_1());
                Monitor.Enter(this.dictionary_1);
                this.dictionary_1[struct2_0] = delegate2;
            }
        }
        return delegate2;
    }

    private Class94[] method_270(object[] object_3)
    {
        Class68[] classArray2 = this.class86_0.method_2();
        int length = classArray2.Length;
        Class94[] classArray = new Class94[length];
        for (int i = 0; i < length; i++)
        {
            object obj2 = object_3[i];
            Type type = this.method_189(classArray2[i].method_0(), false);
            Type c = null;
            Type objA = Class67.smethod_1(type);
            c = (ReferenceEquals(objA, Class58.type_0) || Class58.smethod_0(objA)) ? type : ((obj2 != null) ? obj2.GetType() : type);
            if ((obj2 != null) && (!type.IsAssignableFrom(c) && (type.IsByRef && !type.GetElementType().IsAssignableFrom(c))))
            {
                throw new ArgumentException(string.Format("Object of type {0} cannot be converted to type {1}.", c, type));
            }
            classArray[i] = Class30.smethod_1(obj2, c);
        }
        if (!this.class86_0.method_12() && this.method_189(this.class86_0.method_6(), false).IsValueType)
        {
            Class112 class1 = new Class112();
            class1.method_3(classArray[0]);
            classArray[0] = class1;
        }
        for (int j = 0; j < length; j++)
        {
            if (classArray2[j].method_2())
            {
                Class112 class2 = new Class112();
                class2.method_3(classArray[j]);
                classArray[j] = class2;
            }
        }
        return classArray;
    }

    private void method_271(Class94 class94_2)
    {
        Class121 class2 = (Class121) class94_2;
        Class108 class1 = new Class108();
        class1.method_3(class2.method_2());
        this.method_195(class1);
    }

    private void method_272(Class94 class94_2)
    {
        double num2;
        Class94 class2 = this.method_300();
        int num = class2.vmethod_2();
        if (num == 7)
        {
            num2 = ((Class118) class2).method_2();
        }
        else if (num == 11)
        {
            num2 = ((Class99) class2).method_2();
        }
        else
        {
            if (num != 0x18)
            {
                throw new InvalidOperationException();
            }
            num2 = Convert.ToUInt64(((Class98) class2).method_2());
        }
        Class117 class1 = new Class117();
        class1.method_3(num2);
        this.method_195(class1);
    }

    private void method_273(Class94 class94_2)
    {
        Class118 class1 = new Class118();
        class1.method_3(7);
        this.method_195(class1);
    }

    private void method_274(Class94 class94_2)
    {
        Class94 class3 = this.method_300();
        Class118 class1 = new Class118();
        Class118 class4 = new Class118();
        class4.method_3(smethod_17(class3, this.method_300()) ? 1 : 0);
        this.method_195(class4);
    }

    private void method_275()
    {
        Class106 class3 = (Class106) this.method_300();
        this.method_142(class3, this.method_300());
    }

    private void method_276(Class94 class94_2)
    {
        this.method_241(false);
    }

    private void method_277(Class94 class94_2)
    {
        Class117 class2 = (Class117) this.method_300();
        if (double.IsNaN(class2.method_2()) || double.IsInfinity(class2.method_2()))
        {
            throw new OverflowException("The value is not finite real number.");
        }
        this.method_195(class2);
    }

    private bool method_278(MethodBase methodBase_0)
    {
        return (methodBase_0.IsVirtual ? this.method_189(this.class86_0.method_6(), true).IsSubclassOf(methodBase_0.DeclaringType) : false);
    }

    private Class68[] method_279(Class29 class29_2)
    {
        Class68[] classArray = new Class68[class29_2.method_23()];
        for (int i = 0; i < classArray.Length; i++)
        {
            classArray[i] = this.method_82(class29_2);
        }
        return classArray;
    }

    private void method_28(Class94 class94_2)
    {
        Class94 class2 = this.method_300();
        bool flag = false;
        int num = class2.vmethod_2();
        if (num > 11)
        {
            if (num == 14)
            {
                flag = ((Class105) class2).method_2() == IntPtr.Zero;
                goto TR_0002;
            }
            else if (num == 0x18)
            {
                flag = !Convert.ToBoolean(((Class98) class2).method_2());
                goto TR_0002;
            }
        }
        else
        {
            switch (num)
            {
                case 4:
                    flag = ((Class102) class2).method_2() == null;
                    goto TR_0002;

                case 5:
                case 6:
                    break;

                case 7:
                    flag = ((Class118) class2).method_2() == 0;
                    goto TR_0002;

                case 8:
                    flag = ((Class100) class2).method_2() == UIntPtr.Zero;
                    goto TR_0002;

                default:
                    if (num != 11)
                    {
                        break;
                    }
                    flag = ((Class99) class2).method_2() == 0L;
                    goto TR_0002;
            }
        }
        flag = class2.vmethod_0() == null;
    TR_0002:
        if (flag)
        {
            uint num2 = ((Class104) class94_2).method_2();
            this.method_244(num2);
        }
    }

    private void method_280(Class94 class94_2)
    {
        this.method_265(type_8);
    }

    private bool method_281(Class94 class94_2, Type type_9)
    {
        if (class94_2.vmethod_0() == null)
        {
            return true;
        }
        Type objA = class94_2.method_0() ?? class94_2.vmethod_0().GetType();
        if (ReferenceEquals(objA, type_9) || type_9.IsAssignableFrom(objA))
        {
            return true;
        }
        if (!objA.IsValueType && (!type_9.IsValueType && Marshal.IsComObject(class94_2.vmethod_0())))
        {
            IntPtr comInterfaceForObject = Marshal.GetComInterfaceForObject(class94_2.vmethod_0(), type_9);
            if (comInterfaceForObject != IntPtr.Zero)
            {
                Marshal.Release(comInterfaceForObject);
                return true;
            }
        }
        return false;
    }

    private void method_282(Class94 class94_2)
    {
        Class94 class3 = this.method_300();
        this.method_195(this.method_52(class3, this.method_300(), true));
    }

    private void method_283(Class94 class94_2)
    {
        this.method_195(class94_2);
    }

    private void method_284(Class94 class94_2)
    {
        this.method_275();
    }

    private void method_285(Class94 class94_2)
    {
        MethodBase base2 = this.method_234(((Class118) class94_2).method_2());
        this.method_124(base2, false);
    }

    private void method_286(Class94 class94_2)
    {
        Class94 class2 = this.method_300();
        bool flag = false;
        int num = class2.vmethod_2();
        if (num > 11)
        {
            if (num == 14)
            {
                flag = ((Class105) class2).method_2() != IntPtr.Zero;
                goto TR_0002;
            }
            else if (num == 0x18)
            {
                flag = Convert.ToBoolean(((Class98) class2).method_2());
                goto TR_0002;
            }
        }
        else
        {
            switch (num)
            {
                case 4:
                    flag = ((Class102) class2).method_2() != null;
                    goto TR_0002;

                case 5:
                case 6:
                    break;

                case 7:
                    flag = ((Class118) class2).method_2() != 0;
                    goto TR_0002;

                case 8:
                    flag = ((Class100) class2).method_2() != UIntPtr.Zero;
                    goto TR_0002;

                default:
                    if (num != 11)
                    {
                        break;
                    }
                    flag = ((Class99) class2).method_2() != 0L;
                    goto TR_0002;
            }
        }
        flag = class2.vmethod_0() != null;
    TR_0002:
        if (flag)
        {
            uint num2 = ((Class104) class94_2).method_2();
            this.method_244(num2);
        }
    }

    private void method_287(Class94 class94_2)
    {
        Class94 class3 = this.method_300();
        Class118 class1 = new Class118();
        Class118 class4 = new Class118();
        class4.method_3(smethod_14(class3, this.method_300()) ? 1 : 0);
        this.method_195(class4);
    }

    private void method_288(Class94 class94_2)
    {
        Class118 class1 = new Class118();
        class1.method_3(8);
        this.method_195(class1);
    }

    private Class31 method_289(int int_0)
    {
        IEnumerator<Class31> enumerator = this.class16_0.method_0().GetEnumerator();
        while (enumerator.MoveNext())
        {
            Class31 current = enumerator.Current;
            if (current.method_0() == int_0)
            {
                return current;
            }
        }
        return null;
    }

    private void method_29(Class94 class94_2)
    {
        double num2;
        Class94 class2 = this.method_300();
        int num = class2.vmethod_2();
        if (num > 11)
        {
            if (num == 0x11)
            {
                num2 = ((Class117) class2).method_2();
            }
            else if (num == 0x18)
            {
                num2 = Convert.ToUInt64(((Class98) class2).method_2());
            }
            else
            {
                goto TR_0000;
            }
        }
        else if (num == 7)
        {
            num2 = ((Class118) class2).method_2();
        }
        else if (num == 11)
        {
            num2 = ((Class99) class2).method_2();
        }
        else
        {
            goto TR_0000;
        }
        Class117 class1 = new Class117();
        class1.method_3(num2);
        this.method_195(class1);
        return;
    TR_0000:
        throw new InvalidOperationException();
    }

    private void method_290(Class94 class94_2)
    {
        Class94 class3 = this.method_300();
        this.method_195(this.method_214(class3, this.method_300(), true, false));
    }

    private void method_291(int int_0)
    {
        Class94 class2 = this.method_300();
        if (class2 is Class106)
        {
            this.class94_1[int_0] = class2;
        }
        else
        {
            this.class94_1[int_0].vmethod_3(class2);
        }
    }

    private Type method_292(int int_0, Class3 class3_0, ref bool bool_2, bool bool_3)
    {
        Type type;
        int num;
        string str;
        string str3;
        Assembly[] assemblies;
        if (class3_0.method_0() == 1)
        {
            return this.module_0.ResolveType(class3_0.method_2());
        }
        Class37 class2 = (Class37) class3_0.method_4();
        if (class2.method_2())
        {
            if (class2.method_10() != -1)
            {
                type = this.type_7[class2.method_10()];
            }
            else
            {
                if (class2.method_8() == -1)
                {
                    throw new Exception();
                }
                type = this.type_2[class2.method_8()];
            }
            type = Class67.smethod_4(type, Class67.smethod_3(class2.method_0()));
            bool_2 = false;
            return type;
        }
        string typeName = class2.method_0();
        type = Type.GetType(typeName);
        if (type != null)
        {
            goto TR_000D;
        }
        else
        {
            int index = typeName.IndexOf(',');
            str = typeName.Substring(0, index);
            str3 = typeName.Substring(index + 1).Trim();
            Assembly assembly2 = Class58.assembly_0;
            if (!str3.Equals(assembly2.FullName, StringComparison.Ordinal))
            {
                assemblies = AppDomain.CurrentDomain.GetAssemblies();
                num = 0;
            }
            else
            {
                type = assembly2.GetType(str);
                goto TR_0016;
            }
        }
        goto TR_0020;
    TR_000D:
        if (class2.method_4())
        {
            Type[] typeArguments = new Type[class2.method_6().Length];
            int index = 0;
            while (true)
            {
                if (index >= class2.method_6().Length)
                {
                    type = Class67.smethod_4(Class67.smethod_0(type).GetGenericTypeDefinition().MakeGenericType(typeArguments), Class67.smethod_2(type));
                    bool_2 = false;
                    break;
                }
                typeArguments[index] = this.method_189(class2.method_6()[index].method_2(), bool_3);
                index++;
            }
        }
        return type;
    TR_0016:
        if ((type == null) && (str.StartsWith("<PrivateImplementationDetails><", StringComparison.Ordinal) && str.Contains(".")))
        {
            try
            {
                Type[] types = Assembly.Load(str3).GetTypes();
                num = 0;
                while (num < types.Length)
                {
                    Type type2 = types[num];
                    if (type2.FullName == str)
                    {
                        type = type2;
                        break;
                    }
                    num++;
                }
            }
            catch
            {
            }
        }
        goto TR_000D;
    TR_0020:
        while (true)
        {
            if (num >= assemblies.Length)
            {
                goto TR_0016;
            }
            else
            {
                Assembly assembly = assemblies[num];
                string location = null;
                try
                {
                    location = assembly.Location;
                }
                catch (NotSupportedException)
                {
                }
                if (!string.IsNullOrEmpty(location) || !assembly.FullName.Equals(str3, StringComparison.Ordinal))
                {
                    break;
                }
                type = assembly.GetType(str);
                if (type == null)
                {
                    break;
                }
                goto TR_0016;
            }
            break;
        }
        num++;
        goto TR_0020;
    }

    private void method_293(Class94 class94_2)
    {
        Class119 class2 = (Class119) class94_2;
        Class108 class1 = new Class108();
        class1.method_3(class2.method_2());
        this.method_195(class1);
    }

    private void method_294(Class94 class94_2)
    {
        this.method_265(typeof(int));
    }

    private void method_295(Class94 class94_2)
    {
        Class121 class2 = (Class121) class94_2;
        this.class94_0[class2.method_2()].vmethod_3(this.method_300());
    }

    private void method_296()
    {
        long num = this.class29_0.method_0().vmethod_3();
        while (true)
        {
            if (!this.bool_1)
            {
                if (this.nullable_0 != null)
                {
                    this.class29_0.method_0().vmethod_5((long) ((ulong) this.nullable_0.Value));
                    this.nullable_0 = null;
                }
                this.method_209();
                if ((this.class29_0.method_0().vmethod_4() < num) || (this.nullable_0 != null))
                {
                    continue;
                }
            }
            return;
        }
    }

    private void method_297(Class94 class94_2)
    {
        int num = ((Class118) class94_2).method_2();
        bool flag1 = (num & -2147483648) != 0;
        bool flag = (num & 0x40000000) != 0;
        num &= 0x3fffffff;
        if (flag1)
        {
            this.method_205(num, null, null, flag);
        }
        else
        {
            Class35 class2 = (Class35) this.method_130(num).method_4();
            this.method_162(class2);
        }
    }

    private void method_298(object object_3, uint uint_0)
    {
        bool flag = object_3 != null;
        this.object_2 = object_3;
        if (flag)
        {
            this.class20_1.method_0();
        }
        this.bool_0 = flag;
        if (!flag)
        {
            this.class20_1.method_7(new Struct1(uint_0));
        }
        foreach (Class25 class2 in this.class25_0)
        {
            if (this.method_251(this.long_0, class2.method_6(), class2.method_10()))
            {
                switch (class2.method_2())
                {
                    case 0:
                        if (flag)
                        {
                            Type objA = object_3.GetType();
                            Type objB = this.method_189(class2.method_0(), true);
                            if (ReferenceEquals(objA, objB) || objA.IsSubclassOf(objB))
                            {
                                this.class20_1.method_7(new Struct1(class2.method_8(), object_3));
                                this.bool_0 = false;
                            }
                        }
                        break;

                    case 1:
                        if (flag)
                        {
                            this.class20_1.method_7(new Struct1(class2.method_8()));
                        }
                        break;

                    case 2:
                        if (flag || !this.method_251((long) uint_0, class2.method_6(), class2.method_10()))
                        {
                            this.class20_1.method_7(new Struct1(class2.method_8()));
                        }
                        break;

                    case 4:
                        if (flag)
                        {
                            this.class20_1.method_7(new Struct1(class2.method_4(), object_3));
                        }
                        break;

                    default:
                        break;
                }
            }
        }
        this.method_227();
    }

    private void method_299(Class94 class94_2)
    {
        short num2;
        Class94 class2 = this.method_300();
        int num = class2.vmethod_2();
        if (num > 11)
        {
            if (num == 0x11)
            {
                num2 = (short) ((Class117) class2).method_2();
            }
            else if (num == 0x18)
            {
                num2 = (short) Convert.ToUInt64(((Class98) class2).method_2());
            }
            else
            {
                goto TR_0000;
            }
        }
        else if (num == 7)
        {
            num2 = (short) ((uint) ((Class118) class2).method_2());
        }
        else if (num == 11)
        {
            num2 = (short) ((ulong) ((Class99) class2).method_2());
        }
        else
        {
            goto TR_0000;
        }
        Class118 class1 = new Class118();
        class1.method_3(num2);
        this.method_195(class1);
        return;
    TR_0000:
        throw new InvalidOperationException();
    }

    private void method_3(Class94 class94_2)
    {
        MethodBase base2 = ((Class97) this.method_300()).method_2();
        this.method_124(base2, false);
    }

    private void method_30(Class94 class94_2)
    {
        Class118 class1 = new Class118();
        class1.method_3(-1);
        this.method_195(class1);
    }

    private Class94 method_300()
    {
        return this.class20_0.method_6();
    }

    private void method_301(Class94 class94_2)
    {
        throw new NotSupportedException("Initblk not supported.");
    }

    private void method_31(Class94 class94_2)
    {
        Class121 class2 = (Class121) class94_2;
        this.method_195(this.class94_1[class2.method_2()].vmethod_4());
    }

    private void method_32(Class94 class94_2)
    {
        byte num2;
        Class94 class2 = this.method_300();
        int num = class2.vmethod_2();
        if (num > 11)
        {
            if (num == 0x11)
            {
                num2 = (byte) ((Class117) class2).method_2();
            }
            else if (num == 0x18)
            {
                num2 = (byte) Convert.ToUInt64(((Class98) class2).method_2());
            }
            else
            {
                goto TR_0000;
            }
        }
        else if (num == 7)
        {
            num2 = (byte) ((uint) ((Class118) class2).method_2());
        }
        else if (num == 11)
        {
            num2 = (byte) ((ulong) ((Class99) class2).method_2());
        }
        else
        {
            goto TR_0000;
        }
        Class118 class1 = new Class118();
        class1.method_3(num2);
        this.method_195(class1);
        return;
    TR_0000:
        throw new InvalidOperationException();
    }

    private void method_33(Class94 class94_2)
    {
        int num = ((Class118) class94_2).method_2();
        Type type = this.method_189(num, true);
        this.method_109(type);
    }

    private void method_34(Class94 class94_2)
    {
        this.method_144(typeof(float));
    }

    private void method_35(Class94 class94_2)
    {
        this.method_150(true);
    }

    private object method_36(object[] object_3, Type[] type_9, Type[] type_10, object[] object_4)
    {
        if (object_3 == null)
        {
            object_3 = Class69<object>.gparam_0;
        }
        if (type_9 == null)
        {
            type_9 = Type.EmptyTypes;
        }
        if (type_10 == null)
        {
            type_10 = Type.EmptyTypes;
        }
        this.object_0 = object_4;
        this.type_7 = type_9;
        this.type_2 = type_10;
        this.class94_0 = this.method_270(object_3);
        this.class94_1 = this.method_39();
        Class50 class2 = new Class50(this.byte_0);
        this.class29_0 = new Class29(class2);
        this.bool_1 = false;
        this.nullable_0 = null;
        this.class20_0.method_0();
        this.method_20();
        Type objA = this.method_189(this.class86_0.method_8(), false);
        return ((ReferenceEquals(objA, type_1) || (this.class20_0.Count <= 0)) ? null : Class30.smethod_1(null, objA).vmethod_3(this.method_300()).vmethod_0());
    }

    private void method_37(Class94 class94_2)
    {
        int num;
        int num2 = ((Class118) class94_2).method_2();
        Class94 class2 = this.method_300();
        Class118 class3 = class2 as Class118;
        if (class3 != null)
        {
            num = class3.method_2();
        }
        else
        {
            Class105 class4 = class2 as Class105;
            if (class4 != null)
            {
                num = class4.method_2().ToInt32();
            }
            else
            {
                Class100 class5 = class2 as Class100;
                if (class5 == null)
                {
                    throw new Exception();
                }
                num = (int) class5.method_2().ToUInt32();
            }
        }
        Array array = Array.CreateInstance(this.method_189(num2, true), num);
        Class116 class1 = new Class116();
        class1.method_3(array);
        this.method_195(class1);
    }

    private void method_38(Class94 class94_2)
    {
        this.method_109(typeof(sbyte));
    }

    private Class94[] method_39()
    {
        Class12[] classArray = this.class86_0.method_0();
        int length = classArray.Length;
        Class94[] classArray2 = new Class94[length];
        for (int i = 0; i < length; i++)
        {
            classArray2[i] = Class30.smethod_1(null, this.method_189(classArray[i].method_0(), false));
        }
        return classArray2;
    }

    private object method_4(int int_0)
    {
        object obj2;
        int num = Class52.smethod_0(int_0);
        if (num > 0x4000000)
        {
            if (num > 0xa000000)
            {
                if (num == 0x1b000000)
                {
                    goto TR_0004;
                }
                else if (num == 0x2b000000)
                {
                    goto TR_0008;
                }
            }
            else
            {
                if (num != 0x6000000)
                {
                    if (num == 0xa000000)
                    {
                        obj2 = this.module_0.ModuleHandle.ResolveFieldHandle(int_0);
                    }
                    else
                    {
                        goto TR_0000;
                    }
                    return obj2;
                }
                goto TR_0008;
            }
        }
        else
        {
            if ((num != 0x1000000) && (num != 0x2000000))
            {
                if (num == 0x4000000)
                {
                    obj2 = this.module_0.ModuleHandle.ResolveFieldHandle(int_0);
                }
                else
                {
                    goto TR_0000;
                }
                return obj2;
            }
            goto TR_0004;
        }
    TR_0000:
        throw new InvalidOperationException();
    TR_0004:
        return this.module_0.ModuleHandle.ResolveTypeHandle(int_0);
    TR_0008:
        return this.module_0.ModuleHandle.ResolveMethodHandle(int_0);
    }

    private void method_40(Class94 class94_2)
    {
        object obj2 = this.method_300().vmethod_0();
        long num = this.method_55();
        Array array = (Array) this.method_300().vmethod_0();
        Type elementType = array.GetType().GetElementType();
        if (ReferenceEquals(elementType, typeof(sbyte)))
        {
            Class94 class2 = Class30.smethod_1(obj2, typeof(sbyte));
            ((sbyte[]) array)[(int) ((IntPtr) num)] = (sbyte) class2.vmethod_0();
        }
        else if (ReferenceEquals(elementType, typeof(byte)))
        {
            Class94 class3 = Class30.smethod_1(obj2, typeof(byte));
            ((byte[]) array)[(int) ((IntPtr) num)] = (byte) class3.vmethod_0();
        }
        else if (ReferenceEquals(elementType, typeof(bool)))
        {
            Class94 class4 = Class30.smethod_1(obj2, typeof(bool));
            ((bool[]) array)[(int) ((IntPtr) num)] = (bool) class4.vmethod_0();
        }
        else if (elementType.IsEnum)
        {
            this.method_147(elementType, obj2, num, array);
        }
        else
        {
            this.method_147(typeof(sbyte), obj2, num, array);
        }
    }

    private void method_41(Class94 class94_2)
    {
        this.method_195(this.class94_1[2].vmethod_4());
    }

    private Class94 method_42(Class94 class94_2)
    {
        if (class94_2.vmethod_2() == 7)
        {
            int num = ((Class118) class94_2).method_2();
            Class118 class1 = new Class118();
            class1.method_3(~num);
            return class1;
        }
        if (class94_2.vmethod_2() == 11)
        {
            long num2 = ((Class99) class94_2).method_2();
            Class99 class2 = new Class99();
            class2.method_3(~num2);
            return class2;
        }
        if (class94_2.vmethod_2() != 0x18)
        {
            throw new InvalidOperationException();
        }
        Type underlyingType = Enum.GetUnderlyingType(class94_2.vmethod_0().GetType());
        if (!ReferenceEquals(underlyingType, typeof(long)) && !ReferenceEquals(underlyingType, typeof(ulong)))
        {
            int num4 = Convert.ToInt32(class94_2.vmethod_0());
            Class118 class3 = new Class118();
            class3.method_3(~num4);
            return class3;
        }
        long num3 = Convert.ToInt64(class94_2.vmethod_0());
        Class99 class4 = new Class99();
        class4.method_3(~num3);
        return class4;
    }

    private void method_43(Class94 class94_2)
    {
        int num = ((Class118) class94_2).method_2();
        Type type = this.method_189(num, true);
        this.method_265(type);
    }

    private void method_44(bool bool_2)
    {
        uint num2;
        Class94 class2 = this.method_300();
        int num = class2.vmethod_2();
        if (num > 11)
        {
            if (num == 0x11)
            {
                num2 = !bool_2 ? ((uint) ((Class117) class2).method_2()) : ((uint) ((Class117) class2).method_2());
            }
            else if (num == 0x18)
            {
                num2 = !bool_2 ? ((uint) Convert.ToUInt64(((Class98) class2).method_2())) : ((uint) Convert.ToUInt64(((Class98) class2).method_2()));
            }
            else
            {
                goto TR_0000;
            }
        }
        else if (num == 7)
        {
            num2 = !bool_2 ? ((ushort) ((Class118) class2).method_2()) : ((uint) ((Class118) class2).method_2());
        }
        else if (num == 11)
        {
            num2 = !bool_2 ? ((uint) ((Class99) class2).method_2()) : ((uint) ((Class99) class2).method_2());
        }
        else
        {
            goto TR_0000;
        }
        Class118 class1 = new Class118();
        class1.method_3((int) num2);
        this.method_195(class1);
        return;
    TR_0000:
        throw new InvalidOperationException();
    }

    private void method_45(Class94 class94_2)
    {
        int num2 = ((Class118) class94_2).method_2();
        MethodBase base2 = this.method_234(num2);
        Type declaringType = base2.DeclaringType;
        ParameterInfo[] parameters = base2.GetParameters();
        object[] objArray = new object[parameters.Length];
        Dictionary<int, Class106> dictionary = new Dictionary<int, Class106>();
        for (int i = parameters.Length - 1; i >= 0; i--)
        {
            Class94 class2 = this.method_300();
            Class106 class3 = class2 as Class106;
            if (class3 != null)
            {
                dictionary.Add(i, class3);
                class2 = this.method_255(class3);
            }
            if (class2.method_0() != null)
            {
                class2 = Class30.smethod_1(null, class2.method_0()).vmethod_3(class2);
            }
            objArray[i] = Class30.smethod_1(null, parameters[i].ParameterType).vmethod_3(class2).vmethod_0();
        }
        object obj2 = this.method_159(base2, null, objArray, false);
        Dictionary<int, Class106>.Enumerator enumerator = dictionary.GetEnumerator();
        while (enumerator.MoveNext())
        {
            KeyValuePair<int, Class106> current = enumerator.Current;
            this.method_142(current.Value, Class30.smethod_1(objArray[current.Key], null));
        }
        this.method_195(Class30.smethod_1(obj2, declaringType));
    }

    private void method_46(Class94 class94_2)
    {
        Class119 class2 = (Class119) class94_2;
        Class94 class3 = this.method_300();
        this.class94_0[class2.method_2()].vmethod_3(class3);
    }

    private void method_47(Class94 class94_2)
    {
        this.method_291(((Class119) class94_2).method_2());
    }

    public object method_48(Stream stream_1, string string_0, object[] object_3, Type[] type_9, Type[] type_10, object[] object_4)
    {
        this.stream_0 = stream_1;
        this.method_128(stream_1, string_0);
        return this.method_36(object_3, type_9, type_10, object_4);
    }

    private void method_49(Class86 class86_1)
    {
        if (smethod_5() && (!this.class86_0.method_13() && (class86_1.method_13() && !class86_1.method_14())))
        {
            string str = this.method_192(class86_1);
            throw smethod_11(this.method_192(this.class86_0), str);
        }
    }

    private void method_5(bool bool_2)
    {
        long num2;
        Class94 class2 = this.method_300();
        int num = class2.vmethod_2();
        if (num > 11)
        {
            if (num == 0x11)
            {
                num2 = !bool_2 ? ((long) ((Class117) class2).method_2()) : ((long) ((Class117) class2).method_2());
            }
            else if (num == 0x18)
            {
                num2 = !bool_2 ? ((long) Convert.ToUInt64(((Class98) class2).method_2())) : ((long) Convert.ToUInt64(((Class98) class2).method_2()));
            }
            else
            {
                goto TR_0000;
            }
        }
        else if (num == 7)
        {
            num2 = !bool_2 ? ((long) ((Class118) class2).method_2()) : ((long) ((Class118) class2).method_2());
        }
        else if (num == 11)
        {
            num2 = !bool_2 ? ((Class99) class2).method_2() : ((Class99) class2).method_2();
        }
        else
        {
            goto TR_0000;
        }
        Class99 class1 = new Class99();
        class1.method_3(num2);
        this.method_195(class1);
        return;
    TR_0000:
        throw new InvalidOperationException();
    }

    private void method_50(Class94 class94_2)
    {
        UIntPtr ptr;
        Class94 class2 = this.method_300();
        int num = class2.vmethod_2();
        if (num > 11)
        {
            if (num == 0x11)
            {
                ptr = new UIntPtr((ulong) ((Class117) class2).method_2());
            }
            else if (num == 0x18)
            {
                ptr = new UIntPtr(Convert.ToUInt64(((Class98) class2).method_2()));
            }
            else
            {
                goto TR_0000;
            }
        }
        else if (num == 7)
        {
            ptr = new UIntPtr((uint) ((Class118) class2).method_2());
        }
        else if (num == 11)
        {
            ptr = new UIntPtr((ulong) ((Class99) class2).method_2());
        }
        else
        {
            goto TR_0000;
        }
        Class100 class1 = new Class100();
        class1.method_3(ptr);
        this.method_195(class1);
        return;
    TR_0000:
        throw new InvalidOperationException();
    }

    private void method_51(Class94 class94_2)
    {
        this.method_261(false);
    }

    private Class94 method_52(Class94 class94_2, Class94 class94_3, bool bool_2)
    {
        if (class94_2.vmethod_2() == 7)
        {
            if (class94_3.vmethod_2() == 7)
            {
                if (!bool_2)
                {
                    int num = ((Class118) class94_2).method_2();
                    Class118 class1 = new Class118();
                    class1.method_3(num >> (((Class118) class94_3).method_2() & 0x1f));
                    return class1;
                }
                uint num3 = (uint) ((Class118) class94_2).method_2();
                Class118 class2 = new Class118();
                class2.method_3((int) (num3 >> (((Class118) class94_3).method_2() & 0x1f)));
                return class2;
            }
            if (class94_3.vmethod_2() == 0x18)
            {
                Class118 class3 = new Class118();
                class3.method_3(Convert.ToInt32(class94_3.vmethod_0()));
                return this.method_52(class94_2, class3, bool_2);
            }
        }
        if (class94_2.vmethod_2() == 11)
        {
            if (class94_3.vmethod_2() == 7)
            {
                if (!bool_2)
                {
                    long num5 = ((Class99) class94_2).method_2();
                    Class99 class4 = new Class99();
                    class4.method_3(num5 >> (((Class118) class94_3).method_2() & 0x3f));
                    return class4;
                }
                ulong num7 = (ulong) ((Class99) class94_2).method_2();
                Class99 class5 = new Class99();
                class5.method_3((long) (num7 >> (((Class118) class94_3).method_2() & 0x3f)));
                return class5;
            }
            if (class94_3.vmethod_2() == 0x18)
            {
                Class118 class6 = new Class118();
                class6.method_3(Convert.ToInt32(class94_3.vmethod_0()));
                return this.method_52(class94_2, class6, bool_2);
            }
        }
        if (class94_2.vmethod_2() != 0x18)
        {
            throw new InvalidOperationException();
        }
        Type underlyingType = Enum.GetUnderlyingType(class94_2.vmethod_0().GetType());
        if (!ReferenceEquals(underlyingType, typeof(long)) && !ReferenceEquals(underlyingType, typeof(ulong)))
        {
            Class118 class7 = new Class118();
            class7.method_3(Convert.ToInt32(class94_2.vmethod_0()));
            return this.method_52(class7, class94_3, bool_2);
        }
        Class99 class8 = new Class99();
        class8.method_3(Convert.ToInt64(class94_2.vmethod_0()));
        return this.method_52(class8, class94_3, bool_2);
    }

    private void method_53(Class94 class94_2)
    {
        Class94 class3 = this.method_300();
        this.method_195(this.method_131(class3, this.method_300(), true, true));
    }

    private void method_54(Class94 class94_2)
    {
        this.method_195(this.class94_0[0].vmethod_4());
    }

    private long method_55()
    {
        long num2;
        Class94 class2 = this.method_300();
        int num = class2.vmethod_2();
        if (num > 8)
        {
            if (num == 14)
            {
                num2 = ((Class105) class2).method_2().ToInt64();
            }
            else if (num == 0x18)
            {
                num2 = Convert.ToInt64(((Class98) class2).method_2());
            }
            else
            {
                goto TR_0000;
            }
        }
        else if (num == 7)
        {
            num2 = ((Class118) class2).method_2();
        }
        else if (num == 8)
        {
            num2 = (long) ((Class100) class2).method_2().ToUInt64();
        }
        else
        {
            goto TR_0000;
        }
        return num2;
    TR_0000:
        throw new Exception("Unexpected value on the stack.");
    }

    private void method_56(Class94 class94_2)
    {
        this.method_265(typeof(byte));
    }

    private int method_57()
    {
        return -56926124;
    }

    private void method_58(Class94 class94_2)
    {
        int num = ((Class118) class94_2).method_2();
        Type type = this.method_189(num, true);
        Class94 class2 = Class30.smethod_1(this.method_300().vmethod_0(), type);
        this.method_195(class2);
    }

    private void method_59(Class94 class94_2)
    {
        this.method_195(this.class94_0[2].vmethod_4());
    }

    private void method_6(Class94 class94_2)
    {
        Class118 class1 = new Class118();
        class1.method_3(1);
        this.method_195(class1);
    }

    private void method_60(Class94 class94_2)
    {
        Class118 class1 = new Class118();
        class1.method_3(6);
        this.method_195(class1);
    }

    private void method_61(Class94 class94_2)
    {
    }

    private void method_62(Class94 class94_2)
    {
        int num = ((Class118) class94_2).method_2();
        this.type_4 = this.method_189(num, true);
    }

    private void method_63(Class94 class94_2)
    {
        Class94 class3 = this.method_300();
        this.method_195(this.method_131(class3, this.method_300(), false, false));
    }

    private void method_64(Class94 class94_2)
    {
        Class94 class3 = this.method_300();
        Class118 class1 = new Class118();
        Class118 class4 = new Class118();
        class4.method_3(smethod_18(class3, this.method_300()) ? 1 : 0);
        this.method_195(class4);
    }

    private void method_65(Class94 class94_2)
    {
        this.method_275();
    }

    private void method_66(Class94 class94_2)
    {
        Class94 class2 = this.method_300();
        if (!smethod_14(this.method_300(), class2))
        {
            uint num = ((Class104) class94_2).method_2();
            this.method_244(num);
        }
    }

    private void method_67(Class94 class94_2)
    {
        MethodBase base2 = this.method_234(((Class118) class94_2).method_2());
        Class97 class1 = new Class97();
        class1.method_3(base2);
        this.method_195(class1);
    }

    private void method_68(Class94 class94_2)
    {
        Class94 class3 = this.method_300();
        this.method_195(this.method_26(class3, this.method_300(), true));
    }

    private Class12 method_69(Class29 class29_2)
    {
        Class12 class1 = new Class12();
        class1.method_1(class29_2.method_19());
        return class1;
    }

    private void method_7(Class94 class94_2)
    {
        Class94 class3 = this.method_300();
        Class118 class1 = new Class118();
        Class118 class4 = new Class118();
        class4.method_3(smethod_20(class3, this.method_300()) ? 1 : 0);
        this.method_195(class4);
    }

    private void method_70(Class94 class94_2)
    {
        this.method_195(class94_2);
    }

    private FieldInfo method_71(int int_0)
    {
        FieldInfo info;
        object obj2;
        Monitor.Enter(dictionary_3);
        bool flag = true;
        if (dictionary_3.TryGetValue(int_0, out obj2))
        {
            info = (FieldInfo) obj2;
        }
        else
        {
            Class3 class2 = this.method_130(int_0);
            info = this.method_0(int_0, class2, ref flag);
            if (flag)
            {
                dictionary_3.Add(int_0, info);
            }
        }
        this.method_135(info);
        return info;
    }

    private void method_72()
    {
        this.bool_1 = true;
    }

    private void method_73(Class29 class29_2)
    {
    }

    private void method_74(Class94 class94_2)
    {
        this.method_109(typeof(byte));
    }

    private void method_75(Class94 class94_2)
    {
        Class119 class2 = (Class119) class94_2;
        Class112 class1 = new Class112();
        class1.method_3(this.class94_0[class2.method_2()]);
        this.method_195(class1);
    }

    private void method_76(Class94 class94_2)
    {
        Class94 class3 = this.method_300();
        this.method_195(this.method_52(class3, this.method_300(), false));
    }

    private void method_77(Class94 class94_2)
    {
        ushort num2;
        Class94 class2 = this.method_300();
        int num = class2.vmethod_2();
        if (num > 11)
        {
            if (num == 0x11)
            {
                num2 = (ushort) ((Class117) class2).method_2();
            }
            else if (num == 0x18)
            {
                num2 = (ushort) Convert.ToUInt64(((Class98) class2).method_2());
            }
            else
            {
                goto TR_0000;
            }
        }
        else if (num == 7)
        {
            num2 = (ushort) ((uint) ((Class118) class2).method_2());
        }
        else if (num == 11)
        {
            num2 = (ushort) ((ulong) ((Class99) class2).method_2());
        }
        else
        {
            goto TR_0000;
        }
        Class118 class1 = new Class118();
        class1.method_3(num2);
        this.method_195(class1);
        return;
    TR_0000:
        throw new InvalidOperationException();
    }

    private void method_78(Class94 class94_2)
    {
        Array array = (Array) this.method_300().vmethod_0();
        Class118 class1 = new Class118();
        class1.method_3(array.Length);
        this.method_195(class1);
    }

    private void method_79(Class94 class94_2)
    {
        this.method_195(class94_2);
    }

    private void method_8(Class94 class94_2)
    {
        this.method_275();
    }

    private void method_80(Class94 class94_2)
    {
        this.method_144(typeof(double));
    }

    private void method_81(Class94 class94_2)
    {
        this.method_291(0);
    }

    private Class68 method_82(Class29 class29_2)
    {
        Class68 class1 = new Class68();
        class1.method_1(class29_2.method_19());
        class1.method_3(class29_2.method_5());
        return class1;
    }

    private void method_83(Class94 class94_2)
    {
        this.method_241(true);
    }

    private void method_84(Class94 class94_2)
    {
        uint num2;
        Class94 class2 = this.method_300();
        int num = class2.vmethod_2();
        if (num == 7)
        {
            num2 = (uint) ((Class118) class2).method_2();
        }
        else if (num == 11)
        {
            num2 = (uint) ((Class99) class2).method_2();
        }
        else
        {
            if (num != 0x18)
            {
                throw new InvalidOperationException();
            }
            num2 = (uint) Convert.ToInt64(class2.vmethod_0());
        }
        Class118[] classArray = (Class118[]) ((Class116) class94_2).method_2();
        if (num2 < classArray.Length)
        {
            uint num3 = (uint) classArray[num2].method_2();
            this.method_244(num3);
        }
    }

    private void method_85(Class94 class94_2)
    {
        Class94 class2 = this.method_300();
        if (!smethod_17(this.method_300(), class2))
        {
            uint num = ((Class104) class94_2).method_2();
            this.method_244(num);
        }
    }

    private void method_86(Class94 class94_2)
    {
        this.method_265(typeof(ushort));
    }

    private void method_87(Class94 class94_2)
    {
        uint num = ((Class104) class94_2).method_2();
        this.method_244(num);
    }

    private void method_88(Class94 class94_2)
    {
        Class94 class2 = this.method_300();
        Class94 class3 = class2.vmethod_4();
        this.method_195(class2);
        this.method_195(class3);
    }

    private void method_89(Class94 class94_2)
    {
        Class94 class3 = this.method_300();
        this.method_195(this.method_26(class3, this.method_300(), false));
    }

    private void method_9(Class94 class94_2)
    {
        this.method_275();
    }

    private void method_90(Class94 class94_2)
    {
        Class94 class2 = this.method_300();
        if (smethod_20(this.method_300(), class2))
        {
            uint num = ((Class104) class94_2).method_2();
            this.method_244(num);
        }
    }

    private void method_91(Class94 class94_2)
    {
        Class118 class1 = new Class118();
        class1.method_3(2);
        this.method_195(class1);
    }

    private void method_92(Class94 class94_2)
    {
        this.method_275();
    }

    private void method_93(Class94 class94_2)
    {
        Class94 class3 = this.method_300();
        this.method_195(this.method_127(class3, this.method_300()));
    }

    private void method_94()
    {
    }

    private void method_95(Class94 class94_2)
    {
        Class94 class3 = this.method_300();
        this.method_195(this.method_214(class3, this.method_300(), false, false));
    }

    private void method_96(Class94 class94_2)
    {
        throw new NotSupportedException("Cpblk not supported.");
    }

    private void method_97(Class94 class94_2)
    {
        this.method_275();
    }

    private void method_98(Class94 class94_2)
    {
        this.method_275();
    }

    private void method_99(Class94 class94_2)
    {
        this.method_265(typeof(short));
    }

    private static Exception smethod_0(string string_0, string string_1)
    {
        return new FieldAccessException(smethod_26(string.Format("security transparent method '{0}'", string_0), string.Format("security critical field '{0}'", string_1)));
    }

    private static bool smethod_1()
    {
        return false;
    }

    private static Class94 smethod_10(Class94 class94_2, Class94 class94_3, bool bool_2)
    {
        if (!bool_2)
        {
            long num = ((Class99) class94_2).method_2();
            Class99 class1 = new Class99();
            class1.method_3(num % ((Class99) class94_3).method_2());
            return class1;
        }
        ulong num3 = (ulong) ((Class99) class94_2).method_2();
        Class99 class2 = new Class99();
        class2.method_3((long) (num3 % ((ulong) ((Class99) class94_3).method_2())));
        return class2;
    }

    private static Exception smethod_11(string string_0, string string_1)
    {
        return new MethodAccessException(smethod_26(string.Format("security transparent method '{0}'", string_0), string.Format("security critical method '{0}'", string_1)));
    }

    private static BindingFlags smethod_12(bool bool_2)
    {
        BindingFlags flags = BindingFlags.NonPublic | BindingFlags.Public;
        return (!bool_2 ? (flags | BindingFlags.Instance) : (flags | BindingFlags.Static));
    }

    public static void smethod_13<T>(T[] gparam_0, Comparison<T> comparison_0)
    {
        KeyValuePair<int, T>[] keys = new KeyValuePair<int, T>[gparam_0.Length];
        for (int i = 0; i < gparam_0.Length; i++)
        {
            keys[i] = new KeyValuePair<int, T>(i, gparam_0[i]);
        }
        Array.Sort<KeyValuePair<int, T>, T>(keys, gparam_0, new Class8<T>(comparison_0));
    }

    private static bool smethod_14(Class94 class94_2, Class94 class94_3)
    {
        bool flag = false;
        int num = class94_2.vmethod_2();
        if (num > 11)
        {
            if (num == 0x11)
            {
                flag = ((Class117) class94_2).method_2() < ((Class117) class94_3).method_2();
            }
            else if (num == 0x18)
            {
                Class99 class4 = new Class99();
                class4.method_3(Convert.ToInt64(((Class98) class94_2).method_2()));
                return smethod_14(class4, class94_3);
            }
        }
        else if (num == 7)
        {
            if (class94_3.vmethod_2() == 0x18)
            {
                Class118 class3 = new Class118();
                class3.method_3(Convert.ToInt32(((Class98) class94_3).method_2()));
                return smethod_14(class94_2, class3);
            }
            flag = ((Class118) class94_2).method_2() < ((Class118) class94_3).method_2();
        }
        else if (num == 11)
        {
            if (class94_3.vmethod_2() == 0x18)
            {
                Class99 class1 = new Class99();
                class1.method_3(Convert.ToInt64(((Class98) class94_3).method_2()));
                return smethod_14(class94_2, class1);
            }
            if (class94_3.vmethod_2() == 7)
            {
                Class99 class2 = new Class99();
                class2.method_3((long) ((Class118) class94_3).method_2());
                return smethod_14(class94_2, class2);
            }
            flag = ((Class99) class94_2).method_2() < ((Class99) class94_3).method_2();
        }
        return flag;
    }

    private static Class25[] smethod_15(Class29 class29_2)
    {
        int num = class29_2.method_23();
        Class25[] classArray = new Class25[num];
        for (int i = 0; i < num; i++)
        {
            classArray[i] = smethod_23(class29_2);
        }
        return classArray;
    }

    private static Exception smethod_16(string string_0, string string_1)
    {
        return new TypeLoadException(smethod_26(string.Format("security transparent method '{0}'", string_0), string.Format("security critical type '{0}'", string_1)));
    }

    private static bool smethod_17(Class94 class94_2, Class94 class94_3)
    {
        bool flag = false;
        int num = class94_2.vmethod_2();
        if (num > 11)
        {
            if (num == 0x11)
            {
                double d = ((Class117) class94_2).method_2();
                double num3 = ((Class117) class94_3).method_2();
                flag = ((d < num3) || double.IsNaN(d)) || double.IsNaN(num3);
            }
            else if (num == 0x18)
            {
                Class99 class4 = new Class99();
                class4.method_3(Convert.ToInt64(((Class98) class94_2).method_2()));
                return smethod_17(class4, class94_3);
            }
        }
        else if (num == 7)
        {
            if (class94_3.vmethod_2() == 0x18)
            {
                Class118 class3 = new Class118();
                class3.method_3(Convert.ToInt32(((Class98) class94_3).method_2()));
                return smethod_17(class94_2, class3);
            }
            flag = ((Class118) class94_2).method_2() < ((Class118) class94_3).method_2();
        }
        else if (num == 11)
        {
            if (class94_3.vmethod_2() == 0x18)
            {
                Class99 class1 = new Class99();
                class1.method_3(Convert.ToInt64(((Class98) class94_3).method_2()));
                return smethod_17(class94_2, class1);
            }
            if (class94_3.vmethod_2() == 7)
            {
                Class99 class2 = new Class99();
                class2.method_3((long) ((Class118) class94_3).method_2());
                return smethod_17(class94_2, class2);
            }
            flag = ((Class99) class94_2).method_2() < ((Class99) class94_3).method_2();
        }
        return flag;
    }

    private static bool smethod_18(Class94 class94_2, Class94 class94_3)
    {
        bool flag = false;
        int num = class94_2.vmethod_2();
        if (num > 11)
        {
            if (num == 0x11)
            {
                double d = ((Class117) class94_2).method_2();
                double num3 = ((Class117) class94_3).method_2();
                flag = (!double.IsNaN(d) && !double.IsNaN(num3)) && (d > num3);
            }
            else if (num == 0x18)
            {
                Class99 class4 = new Class99();
                class4.method_3(Convert.ToInt64(((Class98) class94_2).method_2()));
                return smethod_18(class4, class94_3);
            }
        }
        else if (num == 7)
        {
            if (class94_3.vmethod_2() == 0x18)
            {
                Class118 class3 = new Class118();
                class3.method_3(Convert.ToInt32(((Class98) class94_3).method_2()));
                return smethod_18(class94_2, class3);
            }
            flag = ((Class118) class94_2).method_2() > ((Class118) class94_3).method_2();
        }
        else if (num == 11)
        {
            if (class94_3.vmethod_2() == 0x18)
            {
                Class99 class1 = new Class99();
                class1.method_3(Convert.ToInt64(((Class98) class94_3).method_2()));
                return smethod_18(class94_2, class1);
            }
            if (class94_3.vmethod_2() == 7)
            {
                Class99 class2 = new Class99();
                class2.method_3((long) ((Class118) class94_3).method_2());
                return smethod_18(class94_2, class2);
            }
            flag = ((Class99) class94_2).method_2() > ((Class99) class94_3).method_2();
        }
        return flag;
    }

    public static object smethod_19(Type type_9)
    {
        return (!type_9.IsValueType ? null : Activator.CreateInstance(type_9));
    }

    private static void smethod_2(object object_3)
    {
        throw object_3;
    }

    private static bool smethod_20(Class94 class94_2, Class94 class94_3)
    {
        bool flag = false;
        switch (class94_2.vmethod_2())
        {
            case 3:
            case 0x10:
                flag = ((Class109) class94_2).vmethod_7((Class109) class94_3);
                break;

            case 4:
                flag = class94_2.vmethod_0() == class94_3.vmethod_0();
                break;

            case 7:
                flag = (class94_3.vmethod_2() != 0x18) ? (((class94_3.vmethod_2() != 4) || (class94_3.vmethod_0() != null)) ? (((Class118) class94_2).method_2() == ((Class118) class94_3).method_2()) : (((Class118) class94_2).method_2() == 0)) : (((Class118) class94_2).method_2() == Convert.ToInt64(((Class98) class94_3).method_2()));
                break;

            case 8:
                flag = ((class94_3.vmethod_2() != 4) || (class94_3.vmethod_0() != null)) ? ((class94_3.vmethod_2() != 7) ? ((class94_3.vmethod_2() != 11) ? (((Class100) class94_2).method_2() == ((Class100) class94_3).method_2()) : (((Class100) class94_2).method_2() == new UIntPtr((ulong) ((Class99) class94_3).method_2()))) : (((Class100) class94_2).method_2() == new UIntPtr((uint) ((Class118) class94_3).method_2()))) : (((Class100) class94_2).method_2() == UIntPtr.Zero);
                break;

            case 11:
                flag = (class94_3.vmethod_2() != 0x18) ? (((class94_3.vmethod_2() != 4) || (class94_3.vmethod_0() != null)) ? (((Class99) class94_2).method_2() == ((Class99) class94_3).method_2()) : (((Class99) class94_2).method_2() == 0L)) : (((Class99) class94_2).method_2() == Convert.ToInt64(((Class98) class94_3).method_2()));
                break;

            case 12:
                flag = smethod_20(((Class112) class94_2).method_2(), ((Class112) class94_3).method_2());
                break;

            case 13:
            {
                Class108 class6 = (Class108) class94_3;
                flag = ((Class108) class94_2).method_2() == class6.method_2();
                break;
            }
            case 14:
                flag = ((class94_3.vmethod_2() != 4) || (class94_3.vmethod_0() != null)) ? ((class94_3.vmethod_2() != 7) ? ((class94_3.vmethod_2() != 11) ? (((Class105) class94_2).method_2() == ((Class105) class94_3).method_2()) : (((Class105) class94_2).method_2() == new IntPtr(((Class99) class94_3).method_2()))) : (((Class105) class94_2).method_2() == new IntPtr(((Class118) class94_3).method_2()))) : (((Class105) class94_2).method_2() == IntPtr.Zero);
                break;

            case 0x11:
            {
                double d = ((Class117) class94_2).method_2();
                double num = ((Class117) class94_3).method_2();
                flag = (!double.IsNaN(d) && !double.IsNaN(num)) && d.Equals(num);
                break;
            }
            case 0x12:
            {
                Class107 class3 = (Class107) class94_2;
                Class107 class4 = (Class107) class94_3;
                flag = (class3.method_2() == class4.method_2()) && ReferenceEquals(class3.method_4(), class4.method_4());
                break;
            }
            case 20:
                flag = ((class94_3.vmethod_2() != 4) || (class94_3.vmethod_0() != null)) ? (((Class96) class94_2).method_2() == ((Class96) class94_3).method_2()) : false;
                break;

            case 0x18:
            {
                Class98 class2 = (Class98) class94_2;
                if (class94_3.vmethod_2() == 0x18)
                {
                    flag = Convert.ToInt64(class2.method_2()) == Convert.ToInt64(((Class98) class94_3).method_2());
                }
                else if (class2.method_2() == 0)
                {
                    flag = class94_3.vmethod_0() == null;
                }
                else if (class94_3.vmethod_0() != null)
                {
                    flag = Convert.ToInt64(class2.method_2()) == Convert.ToInt64(class94_3.vmethod_0());
                }
                break;
            }
            default:
                flag = class94_2.vmethod_0() == class94_3.vmethod_0();
                break;
        }
        return flag;
    }

    private static string smethod_21(MethodBase methodBase_0)
    {
        Type declaringType = methodBase_0.DeclaringType;
        ParameterInfo[] parameters = methodBase_0.GetParameters();
        string[] strArray = new string[parameters.Length];
        for (int i = 0; i < parameters.Length; i++)
        {
            ParameterInfo info = parameters[i];
            strArray[i] = string.Format("{0} {1}", info.ParameterType, info.Name);
        }
        string str = string.Join(", ", strArray);
        return string.Format("{0}.{1}({2})", declaringType.FullName, methodBase_0.Name, str);
    }

    private static void smethod_22(ILGenerator ilgenerator_0, Type type_9)
    {
        if (!type_9.IsValueType && !Class67.smethod_0(type_9).IsGenericParameter)
        {
            smethod_9(ilgenerator_0, type_9);
        }
        else
        {
            ilgenerator_0.Emit(OpCodes.Unbox_Any, type_9);
        }
    }

    private static Class25 smethod_23(Class29 class29_2)
    {
        Class25 class1 = new Class25();
        class1.method_3(class29_2.method_6());
        class1.method_1(class29_2.method_19());
        class1.method_7(class29_2.method_20());
        class1.method_5(class29_2.method_20());
        class1.method_11(class29_2.method_20());
        class1.method_9(class29_2.method_20());
        return class1;
    }

    private static bool smethod_24(MethodBase methodBase_0)
    {
        ParameterInfo[] parameters = methodBase_0.GetParameters();
        for (int i = 0; i < parameters.Length; i++)
        {
            if (parameters[i].ParameterType.IsByRef)
            {
                return true;
            }
        }
        return false;
    }

    private static void smethod_25(ILGenerator ilgenerator_0, int int_0)
    {
        switch (int_0)
        {
            case -1:
                ilgenerator_0.Emit(OpCodes.Ldc_I4_M1);
                return;

            case 0:
                ilgenerator_0.Emit(OpCodes.Ldc_I4_0);
                return;

            case 1:
                ilgenerator_0.Emit(OpCodes.Ldc_I4_1);
                return;

            case 2:
                ilgenerator_0.Emit(OpCodes.Ldc_I4_2);
                return;

            case 3:
                ilgenerator_0.Emit(OpCodes.Ldc_I4_3);
                return;

            case 4:
                ilgenerator_0.Emit(OpCodes.Ldc_I4_4);
                return;

            case 5:
                ilgenerator_0.Emit(OpCodes.Ldc_I4_5);
                return;

            case 6:
                ilgenerator_0.Emit(OpCodes.Ldc_I4_6);
                return;

            case 7:
                ilgenerator_0.Emit(OpCodes.Ldc_I4_7);
                return;

            case 8:
                ilgenerator_0.Emit(OpCodes.Ldc_I4_8);
                return;
        }
        if ((int_0 > -129) && (int_0 < 0x80))
        {
            ilgenerator_0.Emit(OpCodes.Ldc_I4_S, (sbyte) int_0);
        }
        else
        {
            ilgenerator_0.Emit(OpCodes.Ldc_I4, int_0);
        }
    }

    private static string smethod_26(string string_0, string string_1)
    {
        string fullName = typeof(Class4).Assembly.FullName;
        string[] textArray1 = new string[] { string.Format("Attempt by {0} to access {1} failed.", string_0, string_1), Environment.NewLine, Environment.NewLine, string.Format("Assembly '{0}' is marked with the AllowPartiallyTrustedCallersAttribute, and uses the level 2 security transparency model. ", fullName), "Level 2 transparency causes all methods in AllowPartiallyTrustedCallers assemblies to become security transparent by default, which may be the cause of this exception." };
        return string.Concat(textArray1);
    }

    private static Class94 smethod_27(Class94 class94_2, Class94 class94_3, bool bool_2, bool bool_3)
    {
        if (!bool_3)
        {
            long num = ((Class99) class94_2).method_2();
            long num2 = ((Class99) class94_3).method_2();
            long num3 = !bool_2 ? (num * num2) : (num * num2);
            Class99 class1 = new Class99();
            class1.method_3(num3);
            return class1;
        }
        ulong num4 = (ulong) ((Class99) class94_2).method_2();
        ulong num5 = (ulong) ((Class99) class94_3).method_2();
        ulong num6 = !bool_2 ? (num4 * num5) : (num4 * num5);
        Class99 class2 = new Class99();
        class2.method_3((long) num6);
        return class2;
    }

    [Conditional("DEBUG")]
    public static void smethod_28(string string_0)
    {
    }

    private static bool smethod_29(Class94 class94_2, Class94 class94_3)
    {
        int num = class94_2.vmethod_2();
        if (num > 14)
        {
            if (num == 0x11)
            {
                double d = ((Class117) class94_2).method_2();
                double num3 = ((Class117) class94_3).method_2();
                return (((d > num3) || double.IsNaN(d)) || double.IsNaN(num3));
            }
            else if (num == 20)
            {
                return (((class94_3.vmethod_2() != 4) || (class94_3.vmethod_0() != null)) ? (((Class96) class94_2).method_2() != ((Class96) class94_3).method_2()) : true);
            }
            else if (num == 0x18)
            {
                long num4 = (class94_3.vmethod_2() != 7) ? Convert.ToInt64(((Class98) class94_3).method_2()) : ((long) ((Class118) class94_3).method_2());
                return (Convert.ToInt64(((Class98) class94_2).method_2()) > num4);
            }
        }
        else
        {
            switch (num)
            {
                case 4:
                    return (((Class102) class94_2).method_2() != ((Class102) class94_3).method_2());

                case 5:
                case 6:
                    break;

                case 7:
                    return (((Class118) class94_2).method_2() > ((Class118) class94_3).method_2());

                case 8:
                    return (((class94_3.vmethod_2() != 4) || (class94_3.vmethod_0() != null)) ? (((Class100) class94_2).method_2() != ((Class100) class94_3).method_2()) : (((Class100) class94_2).method_2() != UIntPtr.Zero));

                default:
                    if (num == 11)
                    {
                        return (((Class99) class94_2).method_2() > ((Class99) class94_3).method_2());
                    }
                    else if (num == 14)
                    {
                        return (((class94_3.vmethod_2() != 4) || (class94_3.vmethod_0() != null)) ? (((Class105) class94_2).method_2() != ((Class105) class94_3).method_2()) : (((Class105) class94_2).method_2() != IntPtr.Zero));
                    }
                    break;
            }
        }
        return (class94_2.vmethod_0() != class94_3.vmethod_0());
    }

    private static Class94 smethod_3(Class94 class94_2, Class94 class94_3, bool bool_2, bool bool_3)
    {
        if (!bool_3)
        {
            long num = ((Class99) class94_2).method_2();
            long num2 = ((Class99) class94_3).method_2();
            long num3 = !bool_2 ? (num - num2) : (num - num2);
            Class99 class1 = new Class99();
            class1.method_3(num3);
            return class1;
        }
        ulong num4 = (ulong) ((Class99) class94_2).method_2();
        ulong num5 = (ulong) ((Class99) class94_3).method_2();
        ulong num6 = !bool_2 ? (num4 - num5) : (num4 - num5);
        Class99 class2 = new Class99();
        class2.method_3((long) num6);
        return class2;
    }

    private static Class94 smethod_30(Class94 class94_2, Class94 class94_3, bool bool_2)
    {
        if (!bool_2)
        {
            long num = ((Class99) class94_2).method_2();
            Class99 class1 = new Class99();
            class1.method_3(num / ((Class99) class94_3).method_2());
            return class1;
        }
        ulong num3 = (ulong) ((Class99) class94_2).method_2();
        Class99 class2 = new Class99();
        class2.method_3((long) (num3 / ((ulong) ((Class99) class94_3).method_2())));
        return class2;
    }

    private static Class94 smethod_4(Class94 class94_2, Class94 class94_3, bool bool_2, bool bool_3)
    {
        if (!bool_3)
        {
            long num = ((Class99) class94_2).method_2();
            long num2 = ((Class99) class94_3).method_2();
            long num3 = !bool_2 ? (num + num2) : (num + num2);
            Class99 class1 = new Class99();
            class1.method_3(num3);
            return class1;
        }
        ulong num4 = (ulong) ((Class99) class94_2).method_2();
        ulong num5 = (ulong) ((Class99) class94_3).method_2();
        ulong num6 = !bool_2 ? (num4 + num5) : (num4 + num5);
        Class99 class2 = new Class99();
        class2.method_3((long) num6);
        return class2;
    }

    private static bool smethod_5()
    {
        return false;
    }

    private static void smethod_6(ILGenerator ilgenerator_0, Type type_9)
    {
        if (type_9.IsValueType || Class67.smethod_0(type_9).IsGenericParameter)
        {
            ilgenerator_0.Emit(OpCodes.Box, type_9);
        }
    }

    private static byte[] smethod_7(Class29 class29_2)
    {
        int num = class29_2.method_19();
        byte[] buffer = new byte[num];
        class29_2.method_14(buffer, 0, num);
        return buffer;
    }

    private static void smethod_8(Exception exception_0)
    {
        ExceptionDispatchInfo.Capture(exception_0).Throw();
    }

    private static void smethod_9(ILGenerator ilgenerator_0, Type type_9)
    {
        if (!ReferenceEquals(type_9, Class58.type_0))
        {
            ilgenerator_0.Emit(OpCodes.Castclass, type_9);
        }
    }

    [Serializable]
    private sealed class Class5
    {
        public static readonly Class4.Class5 class5_0 = new Class4.Class5();
        public static Comparison<Class25> comparison_0;

        internal int method_0(Class25 class25_0, Class25 class25_1)
        {
            return ((class25_0.method_6() != class25_1.method_6()) ? class25_0.method_6().CompareTo(class25_1.method_6()) : class25_1.method_10().CompareTo(class25_0.method_10()));
        }
    }

    private sealed class Class6
    {
        public Class31 class31_0;
        public Class4.Delegate1 delegate1_0;

        public Class6(Class31 class31_1, Class4.Delegate1 delegate1_1)
        {
            this.class31_0 = class31_1;
            this.delegate1_0 = delegate1_1;
        }
    }

    private sealed class Class7
    {
        private string string_0;
        private Type type_0;

        public string method_0()
        {
            return this.string_0;
        }

        public void method_1(string string_1)
        {
            this.string_0 = string_1;
        }

        public Type method_2()
        {
            return this.type_0;
        }

        public void method_3(Type type_1)
        {
            this.type_0 = type_1;
        }
    }

    private sealed class Class8<T> : IComparer<KeyValuePair<int, T>>
    {
        private readonly Comparison<T> comparison_0;

        public Class8(Comparison<T> comparison_1)
        {
            this.comparison_0 = comparison_1;
        }

        public int Compare(KeyValuePair<int, T> keyValuePair_0, KeyValuePair<int, T> keyValuePair_1)
        {
            int num = this.comparison_0(keyValuePair_0.Value, keyValuePair_1.Value);
            return ((num != 0) ? num : keyValuePair_1.Key.CompareTo(keyValuePair_0.Key));
        }
    }

    private delegate object Delegate0(object object_0, object[] object_1);

    private delegate void Delegate1(Class94 class94_0);

    [StructLayout(LayoutKind.Sequential)]
    private struct Struct0
    {
        public bool bool_0;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct Struct1
    {
        private readonly uint uint_0;
        private readonly object object_0;
        public Struct1(uint uint_1)
        {
            this.uint_0 = uint_1;
            this.object_0 = null;
        }

        public Struct1(uint uint_1, object object_1)
        {
            this.uint_0 = uint_1;
            this.object_0 = object_1;
        }

        public uint method_0()
        {
            return this.uint_0;
        }

        public object method_1()
        {
            return this.object_0;
        }
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct Struct2 : IEquatable<Class4.Struct2>
    {
        private readonly MethodBase methodBase_0;
        private readonly bool bool_0;
        public Struct2(MethodBase methodBase_1, bool bool_1)
        {
            this.methodBase_0 = methodBase_1;
            this.bool_0 = bool_1;
        }

        public MethodBase method_0()
        {
            return this.methodBase_0;
        }

        public bool method_1()
        {
            return this.bool_0;
        }

        public override int GetHashCode()
        {
            return (this.method_0().GetHashCode() ^ this.method_1().GetHashCode());
        }

        public override bool Equals(object obj)
        {
            if (!(obj is Class4.Struct2))
            {
                return false;
            }
            Class4.Struct2 other = (Class4.Struct2) obj;
            return this.Equals(other);
        }

        public bool Equals(Class4.Struct2 other)
        {
            return (ReferenceEquals(this.method_0(), other.method_0()) && (this.method_1() == other.method_1()));
        }
    }
}

