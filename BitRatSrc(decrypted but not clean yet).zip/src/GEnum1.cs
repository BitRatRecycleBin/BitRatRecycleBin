﻿using System;

public enum GEnum1
{
}

