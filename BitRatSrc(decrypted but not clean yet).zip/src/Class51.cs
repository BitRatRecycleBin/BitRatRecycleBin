﻿using System;
using System.Runtime.InteropServices;

internal sealed class Class51
{
    internal static readonly Struct13 struct13_0; // data size: 256 bytes
    internal static readonly Struct12 struct12_0; // data size: 20 bytes

    [StructLayout(LayoutKind.Explicit, Size=20, Pack=1)]
    private struct Struct12
    {
    }

    [StructLayout(LayoutKind.Explicit, Size=0x100, Pack=1)]
    private struct Struct13
    {
    }
}

