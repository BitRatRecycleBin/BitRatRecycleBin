﻿internal interface Interface2
{
}

