﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.CompilerServices;

internal static class Class79
{
    private static readonly Assembly assembly_0 = typeof(Class79).Assembly;
    private static volatile Dictionary<string, Class80> dictionary_0;

    internal static void smethod_0()
    {
        AppDomain.CurrentDomain.ResourceResolve += new ResolveEventHandler(Class79.smethod_1);
    }

    private static Assembly smethod_1(object object_0, ResolveEventArgs resolveEventArgs_0)
    {
        if (ReferenceEquals(resolveEventArgs_0.RequestingAssembly, assembly_0))
        {
            smethod_2();
        }
        return null;
    }

    private static void smethod_2()
    {
    }

    private sealed class Class80
    {
        private readonly string string_0;
        private volatile Assembly assembly_0;

        internal Class80(string string_1)
        {
            this.string_0 = string_1;
        }

        internal Assembly method_0()
        {
            return null;
        }

        private static Assembly smethod_0(string string_1)
        {
            return (Class39.smethod_3(string_1) ?? Assembly.Load(string_1));
        }
    }
}

