﻿using System;

internal sealed class Class31
{
    private int int_0;
    private readonly int int_1;

    public Class31(int int_2, int int_3)
    {
        this.method_1(int_2);
        this.int_1 = int_3;
    }

    public override bool Equals(object obj)
    {
        Class31 class2 = obj as Class31;
        return ((class2 != null) ? this.method_3(class2) : false);
    }

    public override int GetHashCode()
    {
        return this.method_0().GetHashCode();
    }

    public int method_0()
    {
        return this.int_0;
    }

    public void method_1(int int_2)
    {
        this.int_0 = int_2;
    }

    public int method_2()
    {
        return this.int_1;
    }

    public bool method_3(Class31 class31_0)
    {
        return (class31_0.method_0() == this.method_0());
    }

    public static bool operator ==(Class31 class31_0, Class31 class31_1)
    {
        return class31_0.method_3(class31_1);
    }

    public static bool operator !=(Class31 class31_0, Class31 class31_1)
    {
        return !(class31_0 == class31_1);
    }

    public override string ToString()
    {
        return this.method_0().ToString();
    }
}

