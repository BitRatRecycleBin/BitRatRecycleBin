﻿using System;
using System.Runtime.InteropServices;

internal interface Interface7 : IDisposable
{
    int imethod_0();
    void imethod_1(int int_0, out byte byte_0);
    void imethod_2(int int_0, ref byte byte_0);
    void imethod_3();
    Interface7 imethod_4();
}

