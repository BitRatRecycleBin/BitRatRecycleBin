﻿using System;
using System.Collections;
using System.Runtime.InteropServices;

internal sealed class Class144
{
    private static Class144.Interface14 interface14_0;

    private static T smethod_0<T>(string string_0);
    private static Class144.Interface11 smethod_1();
    internal static bool smethod_2();
    internal static bool smethod_3(string string_0);
    internal static bool smethod_4(string string_0, string string_1);

    internal enum Enum4
    {
    }

    internal enum Enum5
    {
    }

    internal enum Enum6
    {
    }

    internal enum Enum7
    {
    }

    [TypeLibType((short) 0x1040), Guid("D46D2478-9AC9-4008-9DC7-5563CE5536CC")]
    internal interface Interface10
    {
        [return: MarshalAs(UnmanagedType.Interface)]
        Class144.Interface11 imethod_0();
        [return: MarshalAs(UnmanagedType.Interface)]
        Class144.Interface11 imethod_1([In] Class144.Enum7 enum7_0);
    }

    [Guid("174A0DDA-E9F9-449D-993B-21AB667CA456"), TypeLibType((short) 0x1040)]
    internal interface Interface11
    {
        Class144.Enum7 imethod_0();
        bool imethod_1();
        void imethod_2(bool bool_0);
        bool imethod_3();
        void imethod_4(bool bool_0);
        bool imethod_5();
        void imethod_6(bool bool_0);
        bool imethod_7();
        void imethod_8(bool bool_0);
        object imethod_9();
        object imethod_10();
        object imethod_11();
        object imethod_12();
        [return: MarshalAs(UnmanagedType.Interface)]
        Class144.Interface13 imethod_13();
    }

    [Guid("B5E64FFA-C2C5-444E-A301-FB5E00018050"), TypeLibType((short) 0x1040)]
    internal interface Interface12
    {
        [return: MarshalAs(UnmanagedType.BStr)]
        string imethod_0();
        void imethod_1([MarshalAs(UnmanagedType.BStr)] string string_0);
        [return: MarshalAs(UnmanagedType.BStr)]
        string imethod_2();
        void imethod_3([MarshalAs(UnmanagedType.BStr)] string string_0);
        Class144.Enum5 imethod_4();
        void imethod_5(Class144.Enum5 enum5_0);
        Class144.Enum4 imethod_6();
        void imethod_7(Class144.Enum4 enum4_0);
        [return: MarshalAs(UnmanagedType.BStr)]
        string imethod_8();
        void imethod_9([MarshalAs(UnmanagedType.BStr)] string string_0);
        bool imethod_10();
        void imethod_11(bool bool_0);
    }

    [TypeLibType((short) 0x1040), Guid("644EFD52-CCF9-486C-97A2-39F352570B30")]
    internal interface Interface13 : IEnumerable
    {
        int imethod_0();
        void imethod_1([In, MarshalAs(UnmanagedType.Interface)] Class144.Interface12 interface12_0);
        void imethod_2([In, MarshalAs(UnmanagedType.BStr)] string string_0);
        [return: MarshalAs(UnmanagedType.Interface)]
        Class144.Interface12 imethod_3([In, MarshalAs(UnmanagedType.BStr)] string string_0);
    }

    [TypeLibType((short) 0x1040), Guid("F7898AF5-CAC4-4632-A2EC-DA06E5111AF2")]
    internal interface Interface14
    {
        [return: MarshalAs(UnmanagedType.Interface)]
        Class144.Interface10 imethod_0();
        Class144.Enum7 imethod_1();
        void imethod_2();
        void imethod_3([In, MarshalAs(UnmanagedType.BStr)] string string_0, [In] Class144.Enum5 enum5_0, [In] int int_0, [In, MarshalAs(UnmanagedType.BStr)] string string_1, [In] Class144.Enum6 enum6_0, [MarshalAs(UnmanagedType.Struct)] out object object_0, [MarshalAs(UnmanagedType.Struct)] out object object_1);
        void imethod_4([In] Class144.Enum5 enum5_0, [In, MarshalAs(UnmanagedType.BStr)] string string_0, [In] byte byte_0, [MarshalAs(UnmanagedType.Struct)] out object object_0, [MarshalAs(UnmanagedType.Struct)] out object object_1);
    }
}

