﻿using Org.BouncyCastle.Asn1.X509;
using System;
using System.Security.Cryptography;

internal sealed class Class87 : IDisposable
{
    private Enum2 enum2_0;
    private Enum0 enum0_0;
    private byte[] byte_0;
    private byte[] byte_1;
    private static Type modreq(BasicConstraints) type_0;
    private bool bool_0;
    private bool bool_1;
    private SymmetricAlgorithm symmetricAlgorithm_0;

    public Class87()
    {
        this.method_1((Enum2) 1);
    }

    public void Dispose()
    {
        IDisposable disposable = this.symmetricAlgorithm_0;
        if (disposable != null)
        {
            disposable.Dispose();
        }
    }

    public Enum2 method_0()
    {
        return this.enum2_0;
    }

    public void method_1(Enum2 enum2_1)
    {
        if (this.enum2_0 != enum2_1)
        {
            this.enum2_0 = enum2_1;
            this.bool_1 = true;
        }
    }

    private Class91 method_10(bool bool_2)
    {
        if (!this.bool_0)
        {
            bool flag = this.bool_1 || ReferenceEquals(this.symmetricAlgorithm_0, null);
            if (this.symmetricAlgorithm_0 == null)
            {
                this.symmetricAlgorithm_0 = smethod_0();
                if (this.symmetricAlgorithm_0 == null)
                {
                    this.bool_0 = true;
                }
            }
            if (this.symmetricAlgorithm_0 != null)
            {
                if (flag)
                {
                    this.symmetricAlgorithm_0.Key = this.method_4();
                    this.symmetricAlgorithm_0.IV = this.method_6();
                    this.symmetricAlgorithm_0.Mode = smethod_1(this.method_0());
                    this.symmetricAlgorithm_0.Padding = smethod_2(this.method_2());
                }
                return new Class92(bool_2 ? this.symmetricAlgorithm_0.CreateEncryptor() : this.symmetricAlgorithm_0.CreateDecryptor());
            }
        }
        Class90 class2 = new Class90(new Class9());
        Class14 class3 = (this.method_2() == ((Enum0) 1)) ? new Class14(class2) : new Class15(class2, smethod_3(this.method_2()));
        Class38 class4 = new Class38(new Class26(this.method_4()), this.method_6());
        class3.imethod_1(bool_2, class4);
        return new Class93(class3);
    }

    public Enum0 method_2()
    {
        return this.enum0_0;
    }

    public void method_3(Enum0 enum0_1)
    {
        if (this.enum0_0 != enum0_1)
        {
            this.enum0_0 = enum0_1;
            this.bool_1 = true;
        }
    }

    public byte[] method_4()
    {
        return this.byte_0;
    }

    public void method_5(byte[] byte_2)
    {
        this.byte_0 = byte_2;
        this.bool_1 = true;
    }

    public byte[] method_6()
    {
        return this.byte_1;
    }

    public void method_7(byte[] byte_2)
    {
        this.byte_1 = byte_2;
        this.bool_1 = true;
    }

    public Class91 method_8()
    {
        return this.method_10(true);
    }

    public Class91 method_9()
    {
        return this.method_10(false);
    }

    private static SymmetricAlgorithm smethod_0()
    {
        return null;
    }

    private static CipherMode smethod_1(Enum2 enum2_1)
    {
        if (enum2_1 != ((Enum2) 1))
        {
            throw new InvalidOperationException("Cipher mode is not supported");
        }
        return CipherMode.CBC;
    }

    private static PaddingMode smethod_2(Enum0 enum0_1)
    {
        if (enum0_1 == ((Enum0) 1))
        {
            return PaddingMode.None;
        }
        if (enum0_1 != ((Enum0) 2))
        {
            throw new InvalidOperationException("Padding mode is not supported");
        }
        return PaddingMode.PKCS7;
    }

    private static Interface6 smethod_3(Enum0 enum0_1)
    {
        if (enum0_1 == ((Enum0) 1))
        {
            return null;
        }
        if (enum0_1 != ((Enum0) 2))
        {
            throw new InvalidOperationException("Padding mode is not supported");
        }
        return new Class89();
    }

    private sealed class Class88
    {
    }
}

