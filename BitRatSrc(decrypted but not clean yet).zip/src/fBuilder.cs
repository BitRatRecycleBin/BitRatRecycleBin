﻿using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using VisualPlus.Enumerators;
using VisualPlus.Toolkit.Controls.Interactivity;

[DesignerGenerated]
public sealed class fBuilder : Form
{
    private IContainer icontainer_0;
    private TextBox textBox_0;
    private Label label_0;
    private TextBox textBox_1;
    private Label label_1;
    private Label label_2;
    private TextBox textBox_2;
    private PictureBox pictureBox_0;
    private CheckBox checkBox_0;
    private TextBox textBox_3;
    private Label label_3;
    private TextBox textBox_4;
    private Label label_4;
    private Label label_5;
    private Label label_6;
    private PictureBox pictureBox_1;
    private PictureBox pictureBox_2;
    private VisualButton visualButton_0;
    private StatusStrip statusStrip_0;
    private ToolStripStatusLabel toolStripStatusLabel_0;
    private GClass7 gclass7_0;
    private BackgroundWorker backgroundWorker_0;
    private Label label_7;
    private Timer timer_0;
    private Label label_8;
    private PictureBox pictureBox_3;
    private RadioButton radioButton_0;
    private RadioButton radioButton_1;
    private TextBox textBox_5;
    private Label label_9;
    private Label label_10;
    private PictureBox pictureBox_4;
    private PictureBox pictureBox_5;
    private long long_0;
    private Struct18 struct18_0;
    private Struct18 struct18_1;
    private Struct16 struct16_0;
    private Struct7 struct7_0;

    public fBuilder()
    {
        base.Load += new EventHandler(this.fBuilder_Load);
        base.Closing += new CancelEventHandler(this.fBuilder_Closing);
        this.InitializeComponent();
    }

    [CompilerGenerated]
    private void _Lambda$__R155-1()
    {
        this.method_12();
    }

    [CompilerGenerated]
    private void _Lambda$__R156-2()
    {
        this.method_12();
    }

    [DebuggerNonUserCode]
    protected override void Dispose(bool disposing)
    {
        if (disposing && (this.icontainer_0 != null))
        {
            this.icontainer_0.Dispose();
        }
    }

    private void fBuilder_Closing(object sender, CancelEventArgs e)
    {
        if (Class130.struct18_7.method_0() && (MessageBox.Show("A build is currently in progress. Closing this window will cancel the build. Proceed?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.No))
        {
            e.Cancel = true;
        }
        else
        {
            base.Visible = false;
            e.Cancel = true;
        }
    }

    private void fBuilder_Load(object sender, EventArgs e)
    {
        base.Visible = false;
        this.vmethod_38().Columns.Add("c1", string.Empty);
        this.vmethod_38().Columns[0].Width = this.vmethod_38().Width - 0x19;
        this.vmethod_38().GridLines = Class135.smethod_0().Gridlines;
    }

    [DebuggerStepThrough]
    private void InitializeComponent()
    {
        this.icontainer_0 = new Container();
        this.vmethod_1(new TextBox());
        this.vmethod_3(new Label());
        this.vmethod_5(new TextBox());
        this.vmethod_7(new Label());
        this.vmethod_9(new Label());
        this.vmethod_11(new TextBox());
        this.vmethod_15(new CheckBox());
        this.vmethod_17(new TextBox());
        this.vmethod_19(new Label());
        this.vmethod_21(new TextBox());
        this.vmethod_23(new Label());
        this.vmethod_25(new Label());
        this.vmethod_27(new Label());
        this.vmethod_33(new VisualButton());
        this.vmethod_35(new StatusStrip());
        this.vmethod_37(new ToolStripStatusLabel());
        this.vmethod_41(new BackgroundWorker());
        this.vmethod_43(new Label());
        this.vmethod_45(new Timer(this.icontainer_0));
        this.vmethod_47(new Label());
        this.vmethod_51(new RadioButton());
        this.vmethod_53(new RadioButton());
        this.vmethod_55(new TextBox());
        this.vmethod_57(new Label());
        this.vmethod_59(new Label());
        this.vmethod_39(new GClass7());
        this.vmethod_61(new PictureBox());
        this.vmethod_49(new PictureBox());
        this.vmethod_31(new PictureBox());
        this.vmethod_29(new PictureBox());
        this.vmethod_13(new PictureBox());
        this.vmethod_63(new PictureBox());
        this.vmethod_34().SuspendLayout();
        ((ISupportInitialize) this.vmethod_60()).BeginInit();
        ((ISupportInitialize) this.vmethod_48()).BeginInit();
        ((ISupportInitialize) this.vmethod_30()).BeginInit();
        ((ISupportInitialize) this.vmethod_28()).BeginInit();
        ((ISupportInitialize) this.vmethod_12()).BeginInit();
        ((ISupportInitialize) this.vmethod_62()).BeginInit();
        base.SuspendLayout();
        this.vmethod_0().Location = new Point(0x42, 0x5b);
        this.vmethod_0().Margin = new Padding(1);
        this.vmethod_0().MaxLength = 0x10;
        this.vmethod_0().Name = "txtPassword";
        this.vmethod_0().PasswordChar = '*';
        this.vmethod_0().Size = new Size(0x98, 20);
        this.vmethod_0().TabIndex = 2;
        this.vmethod_2().AutoSize = true;
        this.vmethod_2().BackColor = Color.Transparent;
        this.vmethod_2().FlatStyle = FlatStyle.Flat;
        this.vmethod_2().Location = new Point(6, 0x5e);
        this.vmethod_2().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_2().Name = "lblPassword";
        this.vmethod_2().Size = new Size(0x38, 13);
        this.vmethod_2().TabIndex = 0x25;
        this.vmethod_2().Text = "Password:";
        this.vmethod_4().Location = new Point(0x42, 0x42);
        this.vmethod_4().Margin = new Padding(1);
        this.vmethod_4().MaxLength = 5;
        this.vmethod_4().Name = "txtPort";
        this.vmethod_4().Size = new Size(0x39, 20);
        this.vmethod_4().TabIndex = 1;
        this.vmethod_6().AutoSize = true;
        this.vmethod_6().BackColor = Color.Transparent;
        this.vmethod_6().FlatStyle = FlatStyle.Flat;
        this.vmethod_6().Location = new Point(0x22, 0x45);
        this.vmethod_6().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_6().Name = "lblPort";
        this.vmethod_6().Size = new Size(0x1d, 13);
        this.vmethod_6().TabIndex = 0x23;
        this.vmethod_6().Text = "Port:";
        this.vmethod_6().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_8().AutoSize = true;
        this.vmethod_8().BackColor = Color.Transparent;
        this.vmethod_8().FlatStyle = FlatStyle.Flat;
        this.vmethod_8().Location = new Point(0x1f, 0x2d);
        this.vmethod_8().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_8().Name = "lblLocalIP";
        this.vmethod_8().Size = new Size(0x20, 13);
        this.vmethod_8().TabIndex = 40;
        this.vmethod_8().Text = "Host:";
        this.vmethod_8().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_10().Location = new Point(0x42, 0x29);
        this.vmethod_10().Margin = new Padding(1);
        this.vmethod_10().MaxLength = 0xff;
        this.vmethod_10().Name = "txtHost";
        this.vmethod_10().Size = new Size(0x98, 20);
        this.vmethod_10().TabIndex = 0;
        this.vmethod_14().AutoSize = true;
        this.vmethod_14().BackColor = Color.Transparent;
        this.vmethod_14().Location = new Point(15, 0x97);
        this.vmethod_14().Margin = new Padding(1);
        this.vmethod_14().Name = "chkInstall";
        this.vmethod_14().RightToLeft = RightToLeft.Yes;
        this.vmethod_14().Size = new Size(0x35, 0x11);
        this.vmethod_14().TabIndex = 3;
        this.vmethod_14().Text = "Install";
        this.vmethod_14().UseVisualStyleBackColor = true;
        this.vmethod_16().Enabled = false;
        this.vmethod_16().Location = new Point(0x75, 0xac);
        this.vmethod_16().Margin = new Padding(1);
        this.vmethod_16().MaxLength = 0xff;
        this.vmethod_16().Name = "txtFilename";
        this.vmethod_16().Size = new Size(0x65, 20);
        this.vmethod_16().TabIndex = 4;
        this.vmethod_18().AutoSize = true;
        this.vmethod_18().BackColor = Color.Transparent;
        this.vmethod_18().Enabled = false;
        this.vmethod_18().FlatStyle = FlatStyle.Flat;
        this.vmethod_18().Location = new Point(0x3a, 0xae);
        this.vmethod_18().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_18().Name = "lblFilename";
        this.vmethod_18().Size = new Size(0x34, 13);
        this.vmethod_18().TabIndex = 0x2f;
        this.vmethod_18().Text = "Filename:";
        this.vmethod_20().Enabled = false;
        this.vmethod_20().Location = new Point(0x75, 0xc5);
        this.vmethod_20().Margin = new Padding(1);
        this.vmethod_20().MaxLength = 0xff;
        this.vmethod_20().Name = "txtInstallFolder";
        this.vmethod_20().Size = new Size(0x65, 20);
        this.vmethod_20().TabIndex = 5;
        this.vmethod_22().AutoSize = true;
        this.vmethod_22().BackColor = Color.Transparent;
        this.vmethod_22().Enabled = false;
        this.vmethod_22().FlatStyle = FlatStyle.Flat;
        this.vmethod_22().Location = new Point(0x17, 0xc5);
        this.vmethod_22().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_22().Name = "lblInstallFolder";
        this.vmethod_22().Size = new Size(0x59, 13);
        this.vmethod_22().TabIndex = 0x31;
        this.vmethod_22().Text = "Installation folder:";
        this.vmethod_24().AutoSize = true;
        this.vmethod_24().BackColor = Color.Transparent;
        this.vmethod_24().Enabled = false;
        this.vmethod_24().FlatStyle = FlatStyle.Flat;
        this.vmethod_24().Location = new Point(0xda, 0xae);
        this.vmethod_24().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_24().Name = "lblFilenameExt";
        this.vmethod_24().Size = new Size(0x1b, 13);
        this.vmethod_24().TabIndex = 0x33;
        this.vmethod_24().Text = ".exe";
        this.vmethod_26().AutoSize = true;
        this.vmethod_26().BackColor = Color.Transparent;
        this.vmethod_26().FlatStyle = FlatStyle.Flat;
        this.vmethod_26().Location = new Point(0x1c, 13);
        this.vmethod_26().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_26().Name = "lblType";
        this.vmethod_26().Size = new Size(0x22, 13);
        this.vmethod_26().TabIndex = 0x35;
        this.vmethod_26().Text = "Type:";
        this.vmethod_26().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_32().Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
        this.vmethod_32().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_32().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_32().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_32().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_32().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_32().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_32().Border.HoverVisible = true;
        this.vmethod_32().Border.Rounding = 6;
        this.vmethod_32().Border.Thickness = 1;
        this.vmethod_32().Border.Type = ShapeTypes.Rounded;
        this.vmethod_32().Border.Visible = true;
        this.vmethod_32().DialogResult = DialogResult.None;
        this.vmethod_32().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_32().Image = null;
        this.vmethod_32().Location = new Point(3, 0xde);
        this.vmethod_32().MouseState = MouseStates.Normal;
        this.vmethod_32().Name = "btnBuild";
        this.vmethod_32().Size = new Size(0x58, 0x1a);
        this.vmethod_32().TabIndex = 0x6b;
        this.vmethod_32().Text = "Build";
        this.vmethod_32().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_32().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_32().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_32().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_32().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_32().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_32().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_32().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_34().AutoSize = false;
        this.vmethod_34().BackColor = Color.FromArgb(0xeb, 0xed, 0xef);
        this.vmethod_34().ImageScalingSize = new Size(0x1c, 0x1c);
        ToolStripItem[] toolStripItems = new ToolStripItem[] { this.vmethod_36() };
        this.vmethod_34().Items.AddRange(toolStripItems);
        this.vmethod_34().Location = new Point(0, 0xfb);
        this.vmethod_34().Name = "ssMain";
        this.vmethod_34().Padding = new Padding(1, 0, 7, 0);
        this.vmethod_34().Size = new Size(0x281, 0x13);
        this.vmethod_34().SizingGrip = false;
        this.vmethod_34().Stretch = false;
        this.vmethod_34().TabIndex = 0x6c;
        this.vmethod_34().Text = "stStatus";
        this.vmethod_36().AutoSize = false;
        this.vmethod_36().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_36().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_36().Margin = new Padding(0, 3, -6, 0);
        this.vmethod_36().Name = "tsStatus";
        this.vmethod_36().Size = new Size(0x27f, 0x10);
        this.vmethod_36().Spring = true;
        this.vmethod_36().Text = "Status: N/A";
        this.vmethod_36().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_40().WorkerSupportsCancellation = true;
        this.vmethod_42().BackColor = Color.Transparent;
        this.vmethod_42().FlatStyle = FlatStyle.Flat;
        this.vmethod_42().Location = new Point(0x105, 13);
        this.vmethod_42().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_42().Name = "lblOutput";
        this.vmethod_42().Size = new Size(0x17a, 13);
        this.vmethod_42().TabIndex = 110;
        this.vmethod_42().Text = "Progress";
        this.vmethod_42().TextAlign = ContentAlignment.MiddleCenter;
        this.vmethod_44().Enabled = true;
        this.vmethod_44().Interval = 10;
        this.vmethod_46().AutoSize = true;
        this.vmethod_46().BackColor = Color.Transparent;
        this.vmethod_46().FlatStyle = FlatStyle.Flat;
        this.vmethod_46().Location = new Point(0x7d, 0x45);
        this.vmethod_46().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_46().Name = "lblNotNeeded";
        this.vmethod_46().Size = new Size(0x5d, 13);
        this.vmethod_46().TabIndex = 0x70;
        this.vmethod_46().Text = "(Forced for .onion)";
        this.vmethod_46().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_46().Visible = false;
        this.vmethod_50().AutoSize = true;
        this.vmethod_50().Checked = true;
        this.vmethod_50().Location = new Point(0x42, 11);
        this.vmethod_50().Margin = new Padding(2);
        this.vmethod_50().Name = "rbSecure";
        this.vmethod_50().Size = new Size(0x61, 0x11);
        this.vmethod_50().TabIndex = 0x75;
        this.vmethod_50().TabStop = true;
        this.vmethod_50().Text = "Standard (TLS)";
        this.vmethod_50().UseVisualStyleBackColor = true;
        this.vmethod_52().AutoSize = true;
        this.vmethod_52().Location = new Point(200, 11);
        this.vmethod_52().Margin = new Padding(2);
        this.vmethod_52().Name = "rbTor";
        this.vmethod_52().Size = new Size(0x29, 0x11);
        this.vmethod_52().TabIndex = 0x76;
        this.vmethod_52().Text = "Tor";
        this.vmethod_52().UseVisualStyleBackColor = true;
        this.vmethod_54().Location = new Point(0x67, 0x74);
        this.vmethod_54().Margin = new Padding(1);
        this.vmethod_54().MaxLength = 0x10;
        this.vmethod_54().Name = "txtTorProcessname";
        this.vmethod_54().Size = new Size(0x73, 20);
        this.vmethod_54().TabIndex = 120;
        this.vmethod_54().Text = "tor";
        this.vmethod_54().Visible = false;
        this.vmethod_56().AutoSize = true;
        this.vmethod_56().BackColor = Color.Transparent;
        this.vmethod_56().FlatStyle = FlatStyle.Flat;
        this.vmethod_56().Location = new Point(6, 0x77);
        this.vmethod_56().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_56().Name = "lblTorProcessname";
        this.vmethod_56().Size = new Size(0x5f, 13);
        this.vmethod_56().TabIndex = 0x79;
        this.vmethod_56().Text = "Tor process name:";
        this.vmethod_56().Visible = false;
        this.vmethod_58().AutoSize = true;
        this.vmethod_58().BackColor = Color.Transparent;
        this.vmethod_58().FlatStyle = FlatStyle.Flat;
        this.vmethod_58().Location = new Point(0xda, 0x77);
        this.vmethod_58().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_58().Name = "lblTorProcessnameExt";
        this.vmethod_58().Size = new Size(0x1b, 13);
        this.vmethod_58().TabIndex = 0x7a;
        this.vmethod_58().Text = ".exe";
        this.vmethod_58().Visible = false;
        this.vmethod_38().Alignment = ListViewAlignment.Left;
        this.vmethod_38().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
        this.vmethod_38().AutoArrange = false;
        this.vmethod_38().BackColor = Color.White;
        this.vmethod_38().Font = new Font("Microsoft Sans Serif", 8.142858f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_38().ForeColor = Color.Black;
        this.vmethod_38().FullRowSelect = true;
        this.vmethod_38().HeaderStyle = ColumnHeaderStyle.None;
        this.vmethod_38().HideSelection = false;
        this.vmethod_38().Location = new Point(0xf7, 0x1d);
        this.vmethod_38().Margin = new Padding(1);
        this.vmethod_38().Name = "lvOutput";
        this.vmethod_38().Size = new Size(0x188, 0xdb);
        this.vmethod_38().TabIndex = 0x6d;
        this.vmethod_38().UseCompatibleStateImageBehavior = false;
        this.vmethod_38().View = View.Details;
        this.vmethod_60().Image = Class131.smethod_52();
        this.vmethod_60().Location = new Point(0xdd, 0x5d);
        this.vmethod_60().Margin = new Padding(2);
        this.vmethod_60().Name = "pbUnlock";
        this.vmethod_60().Size = new Size(15, 15);
        this.vmethod_60().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_60().TabIndex = 0x7b;
        this.vmethod_60().TabStop = false;
        this.vmethod_48().Image = Class131.smethod_24();
        this.vmethod_48().Location = new Point(0xdd, 0x45);
        this.vmethod_48().Margin = new Padding(2);
        this.vmethod_48().Name = "pbPortHelp";
        this.vmethod_48().Size = new Size(15, 15);
        this.vmethod_48().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_48().TabIndex = 0x71;
        this.vmethod_48().TabStop = false;
        this.vmethod_48().Visible = false;
        this.vmethod_30().Image = Class131.smethod_4();
        this.vmethod_30().Location = new Point(0x43, 0x97);
        this.vmethod_30().Margin = new Padding(2);
        this.vmethod_30().Name = "pbWarning";
        this.vmethod_30().Size = new Size(15, 15);
        this.vmethod_30().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_30().TabIndex = 0x6a;
        this.vmethod_30().TabStop = false;
        this.vmethod_28().Image = Class131.smethod_24();
        this.vmethod_28().Location = new Point(0xdd, 200);
        this.vmethod_28().Margin = new Padding(2);
        this.vmethod_28().Name = "pbInstallationFolder";
        this.vmethod_28().Size = new Size(15, 15);
        this.vmethod_28().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_28().TabIndex = 0x37;
        this.vmethod_28().TabStop = false;
        this.vmethod_12().Image = Class131.smethod_24();
        this.vmethod_12().Location = new Point(0xdd, 0x2b);
        this.vmethod_12().Margin = new Padding(2);
        this.vmethod_12().Name = "pbHost";
        this.vmethod_12().Size = new Size(15, 15);
        this.vmethod_12().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_12().TabIndex = 0x29;
        this.vmethod_12().TabStop = false;
        this.vmethod_62().Image = Class131.smethod_29();
        this.vmethod_62().Location = new Point(0xdd, 0x5d);
        this.vmethod_62().Margin = new Padding(2);
        this.vmethod_62().Name = "pbLock";
        this.vmethod_62().Size = new Size(15, 15);
        this.vmethod_62().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_62().TabIndex = 0x7d;
        this.vmethod_62().TabStop = false;
        base.AutoScaleDimensions = new SizeF(6f, 13f);
        base.AutoScaleMode = AutoScaleMode.Font;
        this.BackColor = SystemColors.AppWorkspace;
        base.ClientSize = new Size(0x281, 270);
        base.Controls.Add(this.vmethod_60());
        base.Controls.Add(this.vmethod_58());
        base.Controls.Add(this.vmethod_54());
        base.Controls.Add(this.vmethod_56());
        base.Controls.Add(this.vmethod_52());
        base.Controls.Add(this.vmethod_50());
        base.Controls.Add(this.vmethod_48());
        base.Controls.Add(this.vmethod_46());
        base.Controls.Add(this.vmethod_42());
        base.Controls.Add(this.vmethod_38());
        base.Controls.Add(this.vmethod_34());
        base.Controls.Add(this.vmethod_32());
        base.Controls.Add(this.vmethod_30());
        base.Controls.Add(this.vmethod_28());
        base.Controls.Add(this.vmethod_26());
        base.Controls.Add(this.vmethod_24());
        base.Controls.Add(this.vmethod_20());
        base.Controls.Add(this.vmethod_22());
        base.Controls.Add(this.vmethod_16());
        base.Controls.Add(this.vmethod_18());
        base.Controls.Add(this.vmethod_14());
        base.Controls.Add(this.vmethod_12());
        base.Controls.Add(this.vmethod_8());
        base.Controls.Add(this.vmethod_10());
        base.Controls.Add(this.vmethod_0());
        base.Controls.Add(this.vmethod_2());
        base.Controls.Add(this.vmethod_4());
        base.Controls.Add(this.vmethod_6());
        base.Controls.Add(this.vmethod_62());
        this.DoubleBuffered = true;
        base.FormBorderStyle = FormBorderStyle.FixedToolWindow;
        base.IsMdiContainer = true;
        base.Margin = new Padding(2);
        base.MaximizeBox = false;
        base.MinimizeBox = false;
        base.Name = "fBuilder";
        base.Opacity = 0.0;
        base.ShowIcon = false;
        base.StartPosition = FormStartPosition.CenterParent;
        this.Text = "Builder - Client";
        this.vmethod_34().ResumeLayout(false);
        this.vmethod_34().PerformLayout();
        ((ISupportInitialize) this.vmethod_60()).EndInit();
        ((ISupportInitialize) this.vmethod_48()).EndInit();
        ((ISupportInitialize) this.vmethod_30()).EndInit();
        ((ISupportInitialize) this.vmethod_28()).EndInit();
        ((ISupportInitialize) this.vmethod_12()).EndInit();
        ((ISupportInitialize) this.vmethod_62()).EndInit();
        base.ResumeLayout(false);
        base.PerformLayout();
    }

    public void method_0()
    {
        this.vmethod_50().Checked = Class135.smethod_0().BuilderTLS;
        this.vmethod_52().Checked = !Class135.smethod_0().BuilderTLS;
        this.vmethod_10().Text = Class135.smethod_0().BuilderHost;
        this.vmethod_4().Text = Class135.smethod_0().BuilderPort;
        this.vmethod_0().Text = Class135.smethod_0().BuilderPass;
        this.vmethod_54().Text = Class135.smethod_0().BuilderTorPrcname;
        this.vmethod_16().Text = Class135.smethod_0().BuilderFilename;
        this.vmethod_20().Text = Class135.smethod_0().BuilderInstallFolder;
        base.Opacity = 90.0;
    }

    private void method_1(object sender, EventArgs e)
    {
        if ((!Versioned.IsNumeric(this.vmethod_4().Text) | (Conversion.Val(this.vmethod_4().Text) < 1.0)) | (Conversion.Val(this.vmethod_4().Text) > 65535.0))
        {
            this.vmethod_4().BackColor = Color.Red;
        }
        else
        {
            this.vmethod_4().BackColor = Color.White;
        }
    }

    public void method_10(byte[] byte_0)
    {
        object[] objArray = new object[] { this, byte_0 };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O70*?8c7", objArray);
    }

    private void method_11(object sender, EventArgs e)
    {
        object[] objArray = new object[] { this, sender, e };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O5!*?6pX", objArray);
    }

    public unsafe bool method_12()
    {
        object[] objArray = new object[] { this };
        return *(((bool*) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O:p*?5J/", objArray)));
    }

    public void method_13()
    {
        object[] objArray = new object[] { this };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O61*?5t=", objArray);
    }

    private void method_14(object sender, DoWorkEventArgs e)
    {
        object[] objArray = new object[] { this, sender, e };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O=O*?52'", objArray);
    }

    private void method_15(object sender, EventArgs e)
    {
        object[] objArray = new object[] { this, sender, e };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O5]*?8<*", objArray);
    }

    private void method_16(object sender, EventArgs e)
    {
        Interaction.MsgBox("You have selected to use a .onion address as host.\r\nYou should NOT forward any port for this to work.\r\n\r\nWARNING: Forwarding the Tor port when using a .onion address is dangerous and should be kept closed from public access (WAN). Leaving the port accessible from WAN may expose you to correlation attacks, which may reveal your IP.\r\n\r\nHowever, the Tor port in settings should still be started when using a .onion address. This port is used only for local communication between Tor and " + Application.ProductName + ".", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_17(object sender, EventArgs e)
    {
        this.vmethod_0().PasswordChar = '\0';
        this.vmethod_62().Visible = true;
        this.vmethod_60().Visible = false;
    }

    private void method_18(object sender, EventArgs e)
    {
        this.vmethod_0().PasswordChar = '*';
        this.vmethod_60().Visible = true;
        this.vmethod_62().Visible = false;
    }

    private void method_19(object sender, EventArgs e)
    {
    }

    private void method_2(object sender, EventArgs e)
    {
        Interaction.MsgBox("Enter your IP, DNS or Tor service (.onion) to which the client will connect.\r\n\r\nIf you wish to create a Tor client and use a .onion, then navigate to Settings and click on \"Tor hidden service\" to generate your own .onion address and use it with your .exe for enhanced anonymity and security.\r\n\r\nGood news is that the Tor hidden service method (client connects to .onion) requires no port forwarding.\r\n\r\nNOTE: The Tor hidden service will use port 80 (when using .onion). This port should not be forwarded from your end.\r\nInstead, port 80 is used within the Tor network.", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_20(object sender, EventArgs e)
    {
    }

    private void method_3(object sender, EventArgs e)
    {
        TextBox box;
        object text = (box = this.vmethod_0()).Text;
        ref object expression = ref text;
        box.Text = Conversions.ToString(text);
        if (Conversions.ToBoolean(Operators.NotObject((Strings.Len(expression) > 0) & (Strings.Len(expression) <= 0x10))))
        {
            this.vmethod_0().BackColor = Color.Red;
        }
        else
        {
            this.vmethod_0().BackColor = Color.White;
        }
    }

    private void method_4(object sender, EventArgs e)
    {
        this.vmethod_18().Enabled = this.vmethod_14().Checked;
        this.vmethod_16().Enabled = this.vmethod_14().Checked;
        this.vmethod_24().Enabled = this.vmethod_14().Checked;
        this.vmethod_22().Enabled = this.vmethod_14().Checked;
        this.vmethod_20().Enabled = this.vmethod_14().Checked;
    }

    private void method_5(object sender, EventArgs e)
    {
        Interaction.MsgBox(@"The client will be installed in %LOCALAPPDATA%\{FODLER_NAME} where {FODLER_NAME} represents the installation folder.", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_6(object sender, EventArgs e)
    {
        Interaction.MsgBox("Do not select this option if you intend on using a Crypter.\r\nUse the startup and installation from the Crypter instead.", MsgBoxStyle.Exclamation, Application.ProductName);
    }

    public void method_7(string string_0, Color color_0)
    {
        // Unresolved stack state at '00000000'
    }

    public void method_8()
    {
        object[] objArray = new object[] { this };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O9#*?=8a", objArray);
    }

    public void method_9(string string_0)
    {
        object[] objArray = new object[] { this, string_0 };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O6>*?9PM", objArray);
    }

    internal virtual TextBox vmethod_0()
    {
        return this.textBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_1(TextBox textBox_6)
    {
        EventHandler handler = new EventHandler(this.method_3);
        TextBox box = this.textBox_0;
        if (box != null)
        {
            box.TextChanged -= handler;
        }
        this.textBox_0 = textBox_6;
        box = this.textBox_0;
        if (box != null)
        {
            box.TextChanged += handler;
        }
    }

    internal virtual TextBox vmethod_10()
    {
        return this.textBox_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_11(TextBox textBox_6)
    {
        EventHandler handler = new EventHandler(this.method_19);
        TextBox box = this.textBox_2;
        if (box != null)
        {
            box.TextChanged -= handler;
        }
        this.textBox_2 = textBox_6;
        box = this.textBox_2;
        if (box != null)
        {
            box.TextChanged += handler;
        }
    }

    internal virtual PictureBox vmethod_12()
    {
        return this.pictureBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_13(PictureBox pictureBox_6)
    {
        EventHandler handler = new EventHandler(this.method_2);
        PictureBox box = this.pictureBox_0;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_0 = pictureBox_6;
        box = this.pictureBox_0;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual CheckBox vmethod_14()
    {
        return this.checkBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_15(CheckBox checkBox_1)
    {
        EventHandler handler = new EventHandler(this.method_4);
        CheckBox box = this.checkBox_0;
        if (box != null)
        {
            box.CheckedChanged -= handler;
        }
        this.checkBox_0 = checkBox_1;
        box = this.checkBox_0;
        if (box != null)
        {
            box.CheckedChanged += handler;
        }
    }

    internal virtual TextBox vmethod_16()
    {
        return this.textBox_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_17(TextBox textBox_6)
    {
        this.textBox_3 = textBox_6;
    }

    internal virtual Label vmethod_18()
    {
        return this.label_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_19(Label label_11)
    {
        this.label_3 = label_11;
    }

    internal virtual Label vmethod_2()
    {
        return this.label_0;
    }

    internal virtual TextBox vmethod_20()
    {
        return this.textBox_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_21(TextBox textBox_6)
    {
        EventHandler handler = new EventHandler(this.method_20);
        TextBox box = this.textBox_4;
        if (box != null)
        {
            box.TextChanged -= handler;
        }
        this.textBox_4 = textBox_6;
        box = this.textBox_4;
        if (box != null)
        {
            box.TextChanged += handler;
        }
    }

    internal virtual Label vmethod_22()
    {
        return this.label_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_23(Label label_11)
    {
        this.label_4 = label_11;
    }

    internal virtual Label vmethod_24()
    {
        return this.label_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_25(Label label_11)
    {
        this.label_5 = label_11;
    }

    internal virtual Label vmethod_26()
    {
        return this.label_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_27(Label label_11)
    {
        this.label_6 = label_11;
    }

    internal virtual PictureBox vmethod_28()
    {
        return this.pictureBox_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_29(PictureBox pictureBox_6)
    {
        EventHandler handler = new EventHandler(this.method_5);
        PictureBox box = this.pictureBox_1;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_1 = pictureBox_6;
        box = this.pictureBox_1;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_3(Label label_11)
    {
        this.label_0 = label_11;
    }

    internal virtual PictureBox vmethod_30()
    {
        return this.pictureBox_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_31(PictureBox pictureBox_6)
    {
        EventHandler handler = new EventHandler(this.method_6);
        PictureBox box = this.pictureBox_2;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_2 = pictureBox_6;
        box = this.pictureBox_2;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual VisualButton vmethod_32()
    {
        return this.visualButton_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_33(VisualButton visualButton_1)
    {
        EventHandler handler = new EventHandler(this.method_11);
        VisualButton button = this.visualButton_0;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_0 = visualButton_1;
        button = this.visualButton_0;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual StatusStrip vmethod_34()
    {
        return this.statusStrip_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_35(StatusStrip statusStrip_1)
    {
        this.statusStrip_0 = statusStrip_1;
    }

    internal virtual ToolStripStatusLabel vmethod_36()
    {
        return this.toolStripStatusLabel_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_37(ToolStripStatusLabel toolStripStatusLabel_1)
    {
        this.toolStripStatusLabel_0 = toolStripStatusLabel_1;
    }

    internal virtual GClass7 vmethod_38()
    {
        return this.gclass7_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_39(GClass7 gclass7_1)
    {
        this.gclass7_0 = gclass7_1;
    }

    internal virtual TextBox vmethod_4()
    {
        return this.textBox_1;
    }

    internal virtual BackgroundWorker vmethod_40()
    {
        return this.backgroundWorker_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_41(BackgroundWorker backgroundWorker_1)
    {
        DoWorkEventHandler handler = new DoWorkEventHandler(this.method_14);
        BackgroundWorker worker = this.backgroundWorker_0;
        if (worker != null)
        {
            worker.DoWork -= handler;
        }
        this.backgroundWorker_0 = backgroundWorker_1;
        worker = this.backgroundWorker_0;
        if (worker != null)
        {
            worker.DoWork += handler;
        }
    }

    internal virtual Label vmethod_42()
    {
        return this.label_7;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_43(Label label_11)
    {
        this.label_7 = label_11;
    }

    internal virtual Timer vmethod_44()
    {
        return this.timer_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_45(Timer timer_1)
    {
        EventHandler handler = new EventHandler(this.method_15);
        Timer timer = this.timer_0;
        if (timer != null)
        {
            timer.Tick -= handler;
        }
        this.timer_0 = timer_1;
        timer = this.timer_0;
        if (timer != null)
        {
            timer.Tick += handler;
        }
    }

    internal virtual Label vmethod_46()
    {
        return this.label_8;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_47(Label label_11)
    {
        this.label_8 = label_11;
    }

    internal virtual PictureBox vmethod_48()
    {
        return this.pictureBox_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_49(PictureBox pictureBox_6)
    {
        EventHandler handler = new EventHandler(this.method_16);
        PictureBox box = this.pictureBox_3;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_3 = pictureBox_6;
        box = this.pictureBox_3;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_5(TextBox textBox_6)
    {
        EventHandler handler = new EventHandler(this.method_1);
        TextBox box = this.textBox_1;
        if (box != null)
        {
            box.TextChanged -= handler;
        }
        this.textBox_1 = textBox_6;
        box = this.textBox_1;
        if (box != null)
        {
            box.TextChanged += handler;
        }
    }

    internal virtual RadioButton vmethod_50()
    {
        return this.radioButton_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_51(RadioButton radioButton_2)
    {
        this.radioButton_0 = radioButton_2;
    }

    internal virtual RadioButton vmethod_52()
    {
        return this.radioButton_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_53(RadioButton radioButton_2)
    {
        this.radioButton_1 = radioButton_2;
    }

    internal virtual TextBox vmethod_54()
    {
        return this.textBox_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_55(TextBox textBox_6)
    {
        this.textBox_5 = textBox_6;
    }

    internal virtual Label vmethod_56()
    {
        return this.label_9;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_57(Label label_11)
    {
        this.label_9 = label_11;
    }

    internal virtual Label vmethod_58()
    {
        return this.label_10;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_59(Label label_11)
    {
        this.label_10 = label_11;
    }

    internal virtual Label vmethod_6()
    {
        return this.label_1;
    }

    internal virtual PictureBox vmethod_60()
    {
        return this.pictureBox_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_61(PictureBox pictureBox_6)
    {
        EventHandler handler = new EventHandler(this.method_17);
        PictureBox box = this.pictureBox_4;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_4 = pictureBox_6;
        box = this.pictureBox_4;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual PictureBox vmethod_62()
    {
        return this.pictureBox_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_63(PictureBox pictureBox_6)
    {
        EventHandler handler = new EventHandler(this.method_18);
        PictureBox box = this.pictureBox_5;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_5 = pictureBox_6;
        box = this.pictureBox_5;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_7(Label label_11)
    {
        this.label_1 = label_11;
    }

    internal virtual Label vmethod_8()
    {
        return this.label_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_9(Label label_11)
    {
        this.label_2 = label_11;
    }

    private delegate void Delegate111(byte[] byte_0);

    private delegate void Delegate112();

    private delegate void Delegate113(string string_0);

    private delegate void Delegate114();

    private delegate void Delegate115(string string_0, Color color_0);
}

