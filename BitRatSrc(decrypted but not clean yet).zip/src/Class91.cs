﻿using System;

internal abstract class Class91 : IDisposable
{
    protected Class91()
    {
    }

    public virtual void Dispose()
    {
    }

    public abstract bool vmethod_0();
    public abstract int vmethod_1();
    public abstract int vmethod_2(byte[] byte_0, int int_0, int int_1, byte[] byte_1, int int_2);
    public abstract byte[] vmethod_3(byte[] byte_0, int int_0, int int_1);
}

