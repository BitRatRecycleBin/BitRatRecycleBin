﻿using System;

internal enum Enum2
{
}

