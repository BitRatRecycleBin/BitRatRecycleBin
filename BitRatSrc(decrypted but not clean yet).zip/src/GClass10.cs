﻿using System;
using System.Net.Sockets;
using System.Text;

public sealed class GClass10
{
    public Socket socket_0;
    public int int_0;
    public byte[] byte_0;
    public StringBuilder stringBuilder_0;

    public GClass10();
}

