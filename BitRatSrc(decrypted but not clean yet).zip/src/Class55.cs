﻿using System;

internal static class Class55
{
    public static unsafe int smethod_0(string string_0)
    {
        object[] objArray = new object[] { string_0 };
        return *(((int*) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O=m*?6\">", objArray)));
    }

    public static int smethod_1(int int_0)
    {
        // Unresolved stack state at '00000000'
    }

    public static int smethod_2(int? nullable_0)
    {
        // Unresolved stack state at '00000000'
    }
}

