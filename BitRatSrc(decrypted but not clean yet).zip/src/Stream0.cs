﻿using System;
using System.IO;

internal sealed class Stream0 : Stream
{
    private readonly int int_0;
    private Stream stream_0;

    public Stream0(Stream stream_1, int int_1)
    {
        this.method_1(stream_1);
        this.int_0 = int_1;
    }

    public override void Flush()
    {
        this.method_0().Flush();
    }

    public Stream method_0()
    {
        return this.stream_0;
    }

    private void method_1(Stream stream_1)
    {
        this.stream_0 = stream_1;
    }

    private byte method_2(byte byte_0, long long_0)
    {
        byte num = (byte) (((ulong) this.int_0) | long_0);
        return (byte) (byte_0 ^ num);
    }

    public override int Read(byte[] buffer, int offset, int count)
    {
        long position = this.Position;
        byte[] buffer2 = new byte[count];
        int num2 = this.method_0().Read(buffer2, 0, count);
        for (int i = 0; i < num2; i++)
        {
            buffer[i + offset] = this.method_2(buffer2[i], position + i);
        }
        return num2;
    }

    public override long Seek(long offset, SeekOrigin origin)
    {
        return this.method_0().Seek(offset, origin);
    }

    public override void SetLength(long value)
    {
        this.method_0().SetLength(value);
    }

    public override void Write(byte[] buffer, int offset, int count)
    {
        byte[] dst = new byte[count];
        Buffer.BlockCopy(buffer, offset, dst, 0, count);
        long position = this.Position;
        for (int i = 0; i < count; i++)
        {
            dst[i] = this.method_2(dst[i], position + i);
        }
        this.method_0().Write(dst, 0, count);
    }

    public override bool CanRead
    {
        get
        {
            return this.method_0().CanRead;
        }
    }

    public override bool CanSeek
    {
        get
        {
            return this.method_0().CanSeek;
        }
    }

    public override bool CanWrite
    {
        get
        {
            return this.method_0().CanWrite;
        }
    }

    public override long Length
    {
        get
        {
            return this.method_0().Length;
        }
    }

    public override long Position
    {
        get
        {
            return this.method_0().Position;
        }
        set
        {
            this.method_0().Position = value;
        }
    }
}

