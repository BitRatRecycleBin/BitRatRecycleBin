﻿using System;

internal sealed class Class61
{
    private Class61()
    {
    }

    internal static void smethod_0(uint uint_0, byte[] byte_0, int int_0)
    {
        byte_0[int_0] = (byte) uint_0;
        byte_0[++int_0] = (byte) (uint_0 >> 8);
        byte_0[++int_0] = (byte) (uint_0 >> 0x10);
        byte_0[++int_0] = (byte) (uint_0 >> 0x18);
    }

    internal static uint smethod_1(byte[] byte_0, int int_0)
    {
        byte num1 = byte_0[int_0];
        return (uint) (((num1 | (byte_0[++int_0] << 8)) | (byte_0[++int_0] << 0x10)) | (byte_0[++int_0] << 0x18));
    }
}

