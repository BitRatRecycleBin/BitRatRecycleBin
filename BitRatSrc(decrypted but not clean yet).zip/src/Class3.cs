﻿using System;

internal sealed class Class3
{
    private byte byte_0;
    private int int_0;
    private Class32 class32_0;

    public byte method_0()
    {
        return this.byte_0;
    }

    public void method_1(byte byte_1)
    {
        this.byte_0 = byte_1;
    }

    public int method_2()
    {
        return this.int_0;
    }

    public void method_3(int int_1)
    {
        this.int_0 = int_1;
    }

    public Class32 method_4()
    {
        return this.class32_0;
    }

    public void method_5(Class32 class32_1)
    {
        this.class32_0 = class32_1;
    }
}

