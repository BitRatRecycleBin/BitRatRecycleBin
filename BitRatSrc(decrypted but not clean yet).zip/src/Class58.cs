﻿using System;
using System.Reflection;

internal static class Class58
{
    public static readonly Type type_0 = typeof(object);
    public static readonly Type type_1 = typeof(Nullable<>);
    public static readonly Type type_2 = typeof(Enum);
    public static readonly Type type_3 = typeof(ValueType);
    public static readonly Assembly assembly_0 = typeof(Class58).Assembly;

    public static bool smethod_0(Type type_4)
    {
        return (type_4.IsGenericType && ReferenceEquals(type_4.GetGenericTypeDefinition(), type_1));
    }
}

