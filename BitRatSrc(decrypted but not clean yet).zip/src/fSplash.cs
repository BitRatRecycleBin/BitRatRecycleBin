﻿using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using VisualPlus.Toolkit.Controls.Interactivity;

[DesignerGenerated]
public sealed class fSplash : Form
{
    private IContainer icontainer_0;
    private Timer timer_0;
    private BackgroundWorker backgroundWorker_0;
    private VisualLabel visualLabel_0;
    private VisualLabel visualLabel_1;
    private PictureBox pictureBox_0;
    private Timer timer_1;
    private PictureBox pictureBox_1;
    private VisualLabel visualLabel_2;
    private BackgroundWorker backgroundWorker_1;
    private BackgroundWorker backgroundWorker_2;
    private VisualLabel visualLabel_3;
    private VisualLabel visualLabel_4;
    private Rectangle rectangle_0;
    private static Random random_0;
    private static fSplash.Class150[] class150_0;
    private static decimal decimal_0;
    private static MouseEventArgs mouseEventArgs_0;
    private int int_0;
    public Point point_0;
    private long long_0;
    private long long_1;
    private Collection collection_0;
    private Collection collection_1;

    static fSplash();
    public fSplash();
    [DebuggerNonUserCode]
    protected override void Dispose(bool disposing);
    private void fSplash_Load(object sender, EventArgs e);
    private void fSplash_MouseDown(object sender, MouseEventArgs e);
    private void fSplash_MouseLeave(object sender, EventArgs e);
    private void fSplash_MouseMove(object sender, MouseEventArgs e);
    private void fSplash_MouseUp(object sender, MouseEventArgs e);
    private void fSplash_Paint(object sender, PaintEventArgs e);
    private void fSplash_Resize(object sender, EventArgs e);
    [DllImport("Kernel32.dll")]
    public static extern IntPtr GetCurrentThread();
    [DebuggerStepThrough]
    private void InitializeComponent();
    [DllImport("kernel32.dll")]
    private static extern bool IsDebuggerPresent();
    private void method_0();
    private void method_1();
    private void method_10(object sender, EventArgs e);
    private void method_11(object sender, EventArgs e);
    private void method_12(object sender, MouseEventArgs e);
    private void method_13(object sender, MouseEventArgs e);
    private void method_14(object sender, MouseEventArgs e);
    private void method_15(object sender, EventArgs e);
    private void method_16(object sender, MouseEventArgs e);
    private void method_17(object sender, MouseEventArgs e);
    private void method_18(object sender, MouseEventArgs e);
    private void method_19(object sender, MouseEventArgs e);
    private void method_2();
    private void method_20(object sender, MouseEventArgs e);
    private void method_21(object sender, DoWorkEventArgs e);
    private void method_22(object sender, DoWorkEventArgs e);
    private void method_23(VisualLabel visualLabel_5, bool bool_0);
    private void method_24(object sender, EventArgs e);
    private void method_25(object sender, EventArgs e);
    private void method_26(VisualLabel visualLabel_5, int int_1, Color color_0);
    private void method_27(object sender, MouseEventArgs e);
    private void method_28(object sender, MouseEventArgs e);
    private void method_29(object sender, MouseEventArgs e);
    private void method_3(object sender, EventArgs e);
    private void method_30(object sender, MouseEventArgs e);
    private int method_4(int int_1, int int_2);
    public void method_5(int int_1);
    private void method_6(object sender, DoWorkEventArgs e);
    public void method_7(ref string string_0);
    public void method_8(Color color_0);
    public void method_9(ref string string_0, Color color_0);
    [DllImport("Ntdll.dll")]
    public static extern uint NtSetInformationThread(IntPtr intptr_0, int int_1, IntPtr intptr_1, uint uint_0);
    public static uint smethod_0();
    public static float smethod_1(Point point_1, Point point_2);
    private static decimal smethod_2(decimal decimal_1, decimal decimal_2, int int_1);
    private static decimal smethod_3(decimal decimal_1, decimal decimal_2, int int_1);
    internal virtual Timer vmethod_0();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_1(Timer timer_2);
    internal virtual Timer vmethod_10();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_11(Timer timer_2);
    internal virtual PictureBox vmethod_12();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_13(PictureBox pictureBox_2);
    internal virtual VisualLabel vmethod_14();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_15(VisualLabel visualLabel_5);
    internal virtual BackgroundWorker vmethod_16();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_17(BackgroundWorker backgroundWorker_3);
    internal virtual BackgroundWorker vmethod_18();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_19(BackgroundWorker backgroundWorker_3);
    internal virtual BackgroundWorker vmethod_2();
    internal virtual VisualLabel vmethod_20();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_21(VisualLabel visualLabel_5);
    internal virtual VisualLabel vmethod_22();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_23(VisualLabel visualLabel_5);
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_3(BackgroundWorker backgroundWorker_3);
    internal virtual VisualLabel vmethod_4();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_5(VisualLabel visualLabel_5);
    internal virtual VisualLabel vmethod_6();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_7(VisualLabel visualLabel_5);
    internal virtual PictureBox vmethod_8();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_9(PictureBox pictureBox_2);

    internal sealed class Class150
    {
        public decimal decimal_0;
        public decimal decimal_1;
        public decimal decimal_2;
        public decimal decimal_3;
        public decimal decimal_4;
        private Rectangle rectangle_0;

        public Class150(Rectangle rectangle_1);
        private void method_0();
        public void method_1(Graphics graphics_0);
        public void method_2();
    }

    private delegate void Delegate185(ref string string_0);

    private delegate void Delegate186(ref string string_0, Color color_0);

    private delegate void Delegate187(Color color_0);

    private delegate void Delegate188(VisualLabel visualLabel_0, int int_0, Color color_0);

    private delegate void Delegate189(int int_0);

    private delegate void Delegate190(VisualLabel visualLabel_0, bool bool_0);
}

