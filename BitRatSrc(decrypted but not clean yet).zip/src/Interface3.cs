﻿using System;

internal interface Interface3
{
    void imethod_0();
}

