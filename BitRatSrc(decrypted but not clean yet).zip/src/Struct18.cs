﻿using System;
using System.Runtime.InteropServices;
using System.Threading;

[StructLayout(LayoutKind.Sequential)]
internal struct Struct18
{
    private int? nullable_0;
    public Struct18(string string_0)
    {
        this.nullable_0 = new int?(Class22.smethod_0(string_0));
    }

    public bool method_0()
    {
        return Class22.smethod_1(this.nullable_0);
    }

    public void method_1(bool bool_0)
    {
        this.nullable_0 = new int?(Class22.smethod_4(bool_0));
    }

    public void method_2()
    {
        this.nullable_0 = new int?(Class22.smethod_4(false));
    }

    public int method_3()
    {
        return Class22.smethod_1(this.nullable_0).GetHashCode();
    }

    public bool method_4(bool bool_0)
    {
        return Class22.smethod_1(this.nullable_0).Equals(bool_0);
    }

    public bool method_5(object object_0)
    {
        return Class22.smethod_1(this.nullable_0).Equals(object_0);
    }

    public int method_6(bool bool_0)
    {
        return Class22.smethod_1(this.nullable_0).CompareTo(bool_0);
    }

    public int method_7(object object_0)
    {
        return Class22.smethod_1(this.nullable_0).CompareTo(object_0);
    }

    public TypeCode method_8()
    {
        return TypeCode.Boolean;
    }

    public string method_9()
    {
        return Class22.smethod_1(this.nullable_0).ToString();
    }

    public string method_10(IFormatProvider iformatProvider_0)
    {
        return Class22.smethod_1(this.nullable_0).ToString(iformatProvider_0);
    }

    public bool method_11()
    {
        Thread.MemoryBarrier();
        return Class22.smethod_1(this.nullable_0);
    }

    public void method_12(bool bool_0)
    {
        Thread.MemoryBarrier();
        this.nullable_0 = new int?(Class22.smethod_4(bool_0));
    }
}

