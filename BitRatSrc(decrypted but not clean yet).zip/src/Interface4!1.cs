﻿internal interface Interface4<T> : Interface3, Interface5
{
    T imethod_3();
}

