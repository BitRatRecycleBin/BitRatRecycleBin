﻿using System;
using System.Runtime.InteropServices;

internal sealed class Class132
{
    internal static readonly Struct22 struct22_0; // data size: 5 bytes

    [StructLayout(LayoutKind.Explicit, Size=5, Pack=1)]
    private struct Struct22
    {
    }
}

