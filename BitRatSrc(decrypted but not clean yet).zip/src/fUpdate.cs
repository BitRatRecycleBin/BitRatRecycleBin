﻿using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using VisualPlus.Enumerators;
using VisualPlus.Toolkit.Controls.Interactivity;

[DesignerGenerated]
public sealed class fUpdate : Form
{
    private IContainer icontainer_0;
    private BackgroundWorker backgroundWorker_0;
    private Label label_0;
    private PictureBox pictureBox_0;
    private Label label_1;
    private Label label_2;
    private Label label_3;
    private Label label_4;
    private RichTextBox richTextBox_0;
    private VisualButton visualButton_0;
    private Label label_5;
    private Label label_6;
    private PictureBox pictureBox_1;
    private PictureBox pictureBox_2;
    private StatusStrip statusStrip_0;
    private ToolStripStatusLabel toolStripStatusLabel_0;
    private BackgroundWorker backgroundWorker_1;
    private PictureBox pictureBox_3;
    private Label label_7;
    private Label label_8;
    private Label label_9;
    private string string_0;
    private int int_0;
    private Struct18 struct18_0;
    private Struct18 struct18_1;
    private Struct16 struct16_0;
    private Struct18 struct18_2;
    private Struct18 struct18_3;

    public fUpdate()
    {
        base.Load += new EventHandler(this.fUpdate_Load);
        base.Closing += new CancelEventHandler(this.fUpdate_Closing);
        this.InitializeComponent();
    }

    [CompilerGenerated]
    private void _Lambda$__R102-1()
    {
        this.method_7();
    }

    [CompilerGenerated]
    private void _Lambda$__R103-2()
    {
        this.method_7();
    }

    [DebuggerNonUserCode]
    protected override void Dispose(bool disposing)
    {
        if (disposing && (this.icontainer_0 != null))
        {
            this.icontainer_0.Dispose();
        }
    }

    private void fUpdate_Closing(object sender, CancelEventArgs e)
    {
        object[] objArray = new object[] { this, sender, e };
        Class149.smethod_0().method_139(Class149.smethod_1(), @")&O;o*?=\m", objArray);
    }

    private void fUpdate_Load(object sender, EventArgs e)
    {
        base.Visible = false;
        this.vmethod_14().ReadOnly = true;
        this.vmethod_14().BackColor = Color.White;
        this.method_11("Ready to update");
    }

    [DebuggerStepThrough]
    private void InitializeComponent()
    {
        this.icontainer_0 = new Container();
        this.vmethod_1(new BackgroundWorker());
        this.vmethod_3(new Label());
        this.vmethod_7(new Label());
        this.vmethod_9(new Label());
        this.vmethod_11(new Label());
        this.vmethod_13(new Label());
        this.vmethod_15(new RichTextBox());
        this.vmethod_17(new VisualButton());
        this.vmethod_19(new Label());
        this.vmethod_21(new Label());
        this.vmethod_27(new StatusStrip());
        this.vmethod_29(new ToolStripStatusLabel());
        this.vmethod_31(new BackgroundWorker());
        this.vmethod_25(new PictureBox());
        this.vmethod_23(new PictureBox());
        this.vmethod_5(new PictureBox());
        this.vmethod_33(new PictureBox());
        this.vmethod_35(new Label());
        this.vmethod_37(new Label());
        this.vmethod_39(new Label());
        this.vmethod_26().SuspendLayout();
        ((ISupportInitialize) this.vmethod_24()).BeginInit();
        ((ISupportInitialize) this.vmethod_22()).BeginInit();
        ((ISupportInitialize) this.vmethod_4()).BeginInit();
        ((ISupportInitialize) this.vmethod_32()).BeginInit();
        base.SuspendLayout();
        this.vmethod_2().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
        this.vmethod_2().BackColor = Color.Transparent;
        this.vmethod_2().Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
        this.vmethod_2().Location = new Point(3, 9);
        this.vmethod_2().Name = "lblTitle";
        this.vmethod_2().Size = new Size(0x1a0, 0x17);
        this.vmethod_2().TabIndex = 0;
        this.vmethod_2().Text = "BitRAT - New update available";
        this.vmethod_2().TextAlign = ContentAlignment.TopCenter;
        this.vmethod_6().AutoSize = true;
        this.vmethod_6().Location = new Point(12, 80);
        this.vmethod_6().Name = "lblCurrVersion";
        this.vmethod_6().Size = new Size(0x68, 13);
        this.vmethod_6().TabIndex = 0x15;
        this.vmethod_6().Text = "Current version: N/A";
        this.vmethod_8().AutoSize = true;
        this.vmethod_8().Location = new Point(0x17, 0x3a);
        this.vmethod_8().Name = "lblNewVersion";
        this.vmethod_8().Size = new Size(0x45, 13);
        this.vmethod_8().TabIndex = 0x16;
        this.vmethod_8().Text = "New version:";
        this.vmethod_10().AutoSize = true;
        this.vmethod_10().Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
        this.vmethod_10().ForeColor = Color.LimeGreen;
        this.vmethod_10().Location = new Point(0x5b, 0x3a);
        this.vmethod_10().Name = "lblVersion";
        this.vmethod_10().Size = new Size(30, 13);
        this.vmethod_10().TabIndex = 0x17;
        this.vmethod_10().Text = "N/A";
        this.vmethod_12().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
        this.vmethod_12().Location = new Point(3, 120);
        this.vmethod_12().Name = "lblRelTitle";
        this.vmethod_12().Size = new Size(0x1a0, 13);
        this.vmethod_12().TabIndex = 0x18;
        this.vmethod_12().Text = "What's new";
        this.vmethod_12().TextAlign = ContentAlignment.TopCenter;
        this.vmethod_14().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
        this.vmethod_14().BorderStyle = BorderStyle.FixedSingle;
        this.vmethod_14().Location = new Point(2, 0x88);
        this.vmethod_14().Name = "rtNews";
        this.vmethod_14().ScrollBars = RichTextBoxScrollBars.Vertical;
        this.vmethod_14().Size = new Size(420, 0x149);
        this.vmethod_14().TabIndex = 0x19;
        this.vmethod_14().Text = string.Empty;
        this.vmethod_16().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_16().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_16().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_16().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_16().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_16().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_16().Border.HoverVisible = true;
        this.vmethod_16().Border.Rounding = 6;
        this.vmethod_16().Border.Thickness = 1;
        this.vmethod_16().Border.Type = ShapeTypes.Rounded;
        this.vmethod_16().Border.Visible = true;
        this.vmethod_16().DialogResult = DialogResult.None;
        this.vmethod_16().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_16().Image = null;
        this.vmethod_16().Location = new Point(2, 0x1d7);
        this.vmethod_16().MouseState = MouseStates.Normal;
        this.vmethod_16().Name = "btnDownload";
        this.vmethod_16().Size = new Size(0x51, 0x13);
        this.vmethod_16().TabIndex = 0x2d;
        this.vmethod_16().Text = "Download";
        this.vmethod_16().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_16().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_16().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_16().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_16().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_16().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_16().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_16().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_18().AutoSize = true;
        this.vmethod_18().Location = new Point(0x58, 0x1da);
        this.vmethod_18().Name = "lblVisit";
        this.vmethod_18().Size = new Size(0x2d, 13);
        this.vmethod_18().TabIndex = 0x2e;
        this.vmethod_18().Text = "Or visit: ";
        this.vmethod_20().AutoSize = true;
        this.vmethod_20().ForeColor = Color.RoyalBlue;
        this.vmethod_20().Location = new Point(0x81, 0x1da);
        this.vmethod_20().Name = "lblURL";
        this.vmethod_20().Size = new Size(0x1b, 13);
        this.vmethod_20().TabIndex = 0x2f;
        this.vmethod_20().Text = "N/A";
        this.vmethod_26().AutoSize = false;
        this.vmethod_26().BackColor = Color.FromArgb(0xeb, 0xed, 0xef);
        this.vmethod_26().ImageScalingSize = new Size(0x1c, 0x1c);
        ToolStripItem[] toolStripItems = new ToolStripItem[] { this.vmethod_28() };
        this.vmethod_26().Items.AddRange(toolStripItems);
        this.vmethod_26().Location = new Point(0, 0x1ee);
        this.vmethod_26().Name = "ssMain";
        this.vmethod_26().Padding = new Padding(1, 0, 7, 0);
        this.vmethod_26().Size = new Size(0x1a7, 0x13);
        this.vmethod_26().SizingGrip = false;
        this.vmethod_26().Stretch = false;
        this.vmethod_26().TabIndex = 0x6d;
        this.vmethod_26().Text = "stStatus";
        this.vmethod_28().AutoSize = false;
        this.vmethod_28().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_28().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_28().Margin = new Padding(0, 3, -6, 0);
        this.vmethod_28().Name = "tsStatus";
        this.vmethod_28().Size = new Size(0x1a5, 0x10);
        this.vmethod_28().Spring = true;
        this.vmethod_28().Text = "Status: N/A";
        this.vmethod_28().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_30().WorkerSupportsCancellation = true;
        this.vmethod_24().Location = new Point(180, 0x1da);
        this.vmethod_24().Margin = new Padding(2);
        this.vmethod_24().Name = "pbInfo";
        this.vmethod_24().Size = new Size(15, 15);
        this.vmethod_24().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_24().TabIndex = 0x31;
        this.vmethod_24().TabStop = false;
        this.vmethod_22().Location = new Point(0xa1, 0x1da);
        this.vmethod_22().Margin = new Padding(2);
        this.vmethod_22().Name = "pbCopy";
        this.vmethod_22().Size = new Size(15, 15);
        this.vmethod_22().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_22().TabIndex = 0x30;
        this.vmethod_22().TabStop = false;
        this.vmethod_4().Anchor = AnchorStyles.Right | AnchorStyles.Top;
        this.vmethod_4().Location = new Point(0x18b, 5);
        this.vmethod_4().Margin = new Padding(2);
        this.vmethod_4().Name = "pIcon";
        this.vmethod_4().Size = new Size(0x18, 0x18);
        this.vmethod_4().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_4().TabIndex = 20;
        this.vmethod_4().TabStop = false;
        this.vmethod_32().Location = new Point(0x7c, 0x39);
        this.vmethod_32().Margin = new Padding(2);
        this.vmethod_32().Name = "pbWarning";
        this.vmethod_32().Size = new Size(15, 15);
        this.vmethod_32().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_32().TabIndex = 110;
        this.vmethod_32().TabStop = false;
        this.vmethod_32().Visible = false;
        this.vmethod_34().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
        this.vmethod_34().BackColor = Color.Transparent;
        this.vmethod_34().ForeColor = Color.RoyalBlue;
        this.vmethod_34().Location = new Point(0x67, 30);
        this.vmethod_34().Name = "lblMandatory";
        this.vmethod_34().Size = new Size(0xd5, 13);
        this.vmethod_34().TabIndex = 0x6f;
        this.vmethod_34().Text = "This update is mandatory";
        this.vmethod_34().TextAlign = ContentAlignment.TopCenter;
        this.vmethod_34().Visible = false;
        this.vmethod_36().Anchor = AnchorStyles.Right | AnchorStyles.Top;
        this.vmethod_36().AutoSize = true;
        this.vmethod_36().Location = new Point(0x10f, 80);
        this.vmethod_36().Name = "lblRARtitle";
        this.vmethod_36().Size = new Size(0x52, 13);
        this.vmethod_36().TabIndex = 0x70;
        this.vmethod_36().Text = "RAR-Password:";
        this.vmethod_36().TextAlign = ContentAlignment.TopRight;
        this.vmethod_38().Anchor = AnchorStyles.Right | AnchorStyles.Top;
        this.vmethod_38().AutoSize = true;
        this.vmethod_38().Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
        this.vmethod_38().ForeColor = Color.Black;
        this.vmethod_38().Location = new Point(0x160, 80);
        this.vmethod_38().Name = "lblRARPassword";
        this.vmethod_38().Size = new Size(0x3a, 13);
        this.vmethod_38().TabIndex = 0x71;
        this.vmethod_38().Text = "unknown";
        this.vmethod_38().TextAlign = ContentAlignment.TopRight;
        base.AutoScaleDimensions = new SizeF(6f, 13f);
        base.AutoScaleMode = AutoScaleMode.Font;
        this.BackColor = SystemColors.AppWorkspace;
        base.ClientSize = new Size(0x1a7, 0x201);
        base.Controls.Add(this.vmethod_38());
        base.Controls.Add(this.vmethod_36());
        base.Controls.Add(this.vmethod_34());
        base.Controls.Add(this.vmethod_32());
        base.Controls.Add(this.vmethod_26());
        base.Controls.Add(this.vmethod_24());
        base.Controls.Add(this.vmethod_22());
        base.Controls.Add(this.vmethod_20());
        base.Controls.Add(this.vmethod_18());
        base.Controls.Add(this.vmethod_16());
        base.Controls.Add(this.vmethod_14());
        base.Controls.Add(this.vmethod_12());
        base.Controls.Add(this.vmethod_10());
        base.Controls.Add(this.vmethod_8());
        base.Controls.Add(this.vmethod_6());
        base.Controls.Add(this.vmethod_4());
        base.Controls.Add(this.vmethod_2());
        this.DoubleBuffered = true;
        base.FormBorderStyle = FormBorderStyle.FixedToolWindow;
        base.Name = "fUpdate";
        base.Opacity = 0.0;
        base.ShowInTaskbar = false;
        base.StartPosition = FormStartPosition.CenterParent;
        this.Text = "BitRAT - Update notice";
        base.TopMost = true;
        this.vmethod_26().ResumeLayout(false);
        this.vmethod_26().PerformLayout();
        ((ISupportInitialize) this.vmethod_24()).EndInit();
        ((ISupportInitialize) this.vmethod_22()).EndInit();
        ((ISupportInitialize) this.vmethod_4()).EndInit();
        ((ISupportInitialize) this.vmethod_32()).EndInit();
        base.ResumeLayout(false);
        base.PerformLayout();
    }

    private void method_0()
    {
        object[] objArray = new object[] { this };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O;+*?<iU", objArray);
    }

    public void method_1(string string_1, bool bool_0, string string_2)
    {
        // Unresolved stack state at '00000000'
    }

    public void method_10()
    {
        if (this.vmethod_16().InvokeRequired)
        {
            this.vmethod_16().Invoke(new Delegate50(this.method_10), new object[0]);
        }
        else
        {
            this.vmethod_16().Enabled = true;
        }
    }

    public void method_11(string string_1)
    {
        if (!this.vmethod_26().InvokeRequired)
        {
            this.vmethod_28().Text = "Status: " + string_1;
        }
        else
        {
            object[] args = new object[] { string_1 };
            this.vmethod_26().Invoke(new Delegate51(this.method_11), args);
        }
    }

    private void method_12(object sender, EventArgs e)
    {
        this.method_11("Starting update. Please wait...");
        new Thread(new ThreadStart(this.method_8)).Start();
        this.vmethod_16().Enabled = false;
    }

    private void method_13(object sender, EventArgs e)
    {
        Interaction.MsgBox("This update is mandatory due to change in protocol, patched security flaws or other reasons.\r\n\r\nThe changelog may contain more information about why this update is forced.", MsgBoxStyle.Exclamation, Application.ProductName);
    }

    private void method_14(object sender, DoWorkEventArgs e)
    {
        object[] objArray = new object[] { this, sender, e };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O8c*?5D-", objArray);
    }

    public void method_2(int int_1)
    {
        // Unresolved stack state at '00000008'
    }

    private void method_3(object sender, DoWorkEventArgs e)
    {
        Thread.Sleep(0x3e8);
        this.int_0 = 0;
        while (this.int_0 < 100)
        {
            ref int numRef;
            *(numRef = ref this.int_0) = numRef + 1;
            this.method_2(this.int_0);
            Thread.Sleep(1);
        }
    }

    private void method_4(object sender, EventArgs e)
    {
        Clipboard.Clear();
        Clipboard.SetText(this.vmethod_20().Text);
        Interaction.MsgBox("URL copied to clipboard!\r\nPlease, visit it from TorBrowser!", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_5(object sender, EventArgs e)
    {
        if (MessageBox.Show("The URL cannot be visited from a regular web browser without configuring a proxy.\r\n\r\nTherefore, it is recommended to use TorBrowser.\r\nIt's very simple!\r\n\r\nNavigate to https://www.torproject.org/download/?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
        {
            Process.Start("https://www.torproject.org/download/");
        }
    }

    private void method_6(object sender, EventArgs e)
    {
        Clipboard.Clear();
        Clipboard.SetText(this.vmethod_20().Text);
        Interaction.MsgBox("URL copied to clipboard!\r\nPlease, visit it from TorBrowser!", MsgBoxStyle.Information, Application.ProductName);
    }

    public unsafe bool method_7()
    {
        object[] objArray = new object[] { this };
        return *(((bool*) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O97*?6pX", objArray)));
    }

    public void method_8()
    {
        object[] objArray = new object[] { this };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O<0*?<EI", objArray);
    }

    public void method_9(byte[] byte_0)
    {
        if (base.InvokeRequired)
        {
            object[] args = new object[] { byte_0 };
            base.Invoke(new Delegate53(this.method_9), args);
        }
        else if (base.Visible)
        {
            base.TopMost = false;
            SaveFileDialog dialog = new SaveFileDialog();
            dialog.Filter = "RAR Archive |*.rar";
            if (dialog.ShowDialog() != DialogResult.OK)
            {
                this.method_11("Update was aborted by user!");
            }
            else
            {
                Class136.Class142 class2 = new Class136.Class142();
                class2.string_0 = dialog.FileName;
                class2.byte_0 = byte_0;
                class2.bool_0 = false;
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                this.method_11("Update saved! You may now close this window.");
                this.struct18_3.method_1(true);
            }
            base.TopMost = true;
        }
    }

    internal virtual BackgroundWorker vmethod_0()
    {
        return this.backgroundWorker_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_1(BackgroundWorker backgroundWorker_2)
    {
        DoWorkEventHandler handler = new DoWorkEventHandler(this.method_3);
        BackgroundWorker worker = this.backgroundWorker_0;
        if (worker != null)
        {
            worker.DoWork -= handler;
        }
        this.backgroundWorker_0 = backgroundWorker_2;
        worker = this.backgroundWorker_0;
        if (worker != null)
        {
            worker.DoWork += handler;
        }
    }

    internal virtual Label vmethod_10()
    {
        return this.label_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_11(Label label_10)
    {
        this.label_3 = label_10;
    }

    internal virtual Label vmethod_12()
    {
        return this.label_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_13(Label label_10)
    {
        this.label_4 = label_10;
    }

    internal virtual RichTextBox vmethod_14()
    {
        return this.richTextBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_15(RichTextBox richTextBox_1)
    {
        this.richTextBox_0 = richTextBox_1;
    }

    internal virtual VisualButton vmethod_16()
    {
        return this.visualButton_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_17(VisualButton visualButton_1)
    {
        EventHandler handler = new EventHandler(this.method_12);
        VisualButton button = this.visualButton_0;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_0 = visualButton_1;
        button = this.visualButton_0;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual Label vmethod_18()
    {
        return this.label_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_19(Label label_10)
    {
        this.label_5 = label_10;
    }

    internal virtual Label vmethod_2()
    {
        return this.label_0;
    }

    internal virtual Label vmethod_20()
    {
        return this.label_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_21(Label label_10)
    {
        EventHandler handler = new EventHandler(this.method_6);
        Label label = this.label_6;
        if (label != null)
        {
            label.Click -= handler;
        }
        this.label_6 = label_10;
        label = this.label_6;
        if (label != null)
        {
            label.Click += handler;
        }
    }

    internal virtual PictureBox vmethod_22()
    {
        return this.pictureBox_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_23(PictureBox pictureBox_4)
    {
        EventHandler handler = new EventHandler(this.method_4);
        PictureBox box = this.pictureBox_1;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_1 = pictureBox_4;
        box = this.pictureBox_1;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual PictureBox vmethod_24()
    {
        return this.pictureBox_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_25(PictureBox pictureBox_4)
    {
        EventHandler handler = new EventHandler(this.method_5);
        PictureBox box = this.pictureBox_2;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_2 = pictureBox_4;
        box = this.pictureBox_2;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual StatusStrip vmethod_26()
    {
        return this.statusStrip_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_27(StatusStrip statusStrip_1)
    {
        this.statusStrip_0 = statusStrip_1;
    }

    internal virtual ToolStripStatusLabel vmethod_28()
    {
        return this.toolStripStatusLabel_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_29(ToolStripStatusLabel toolStripStatusLabel_1)
    {
        this.toolStripStatusLabel_0 = toolStripStatusLabel_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_3(Label label_10)
    {
        this.label_0 = label_10;
    }

    internal virtual BackgroundWorker vmethod_30()
    {
        return this.backgroundWorker_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_31(BackgroundWorker backgroundWorker_2)
    {
        DoWorkEventHandler handler = new DoWorkEventHandler(this.method_14);
        BackgroundWorker worker = this.backgroundWorker_1;
        if (worker != null)
        {
            worker.DoWork -= handler;
        }
        this.backgroundWorker_1 = backgroundWorker_2;
        worker = this.backgroundWorker_1;
        if (worker != null)
        {
            worker.DoWork += handler;
        }
    }

    internal virtual PictureBox vmethod_32()
    {
        return this.pictureBox_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_33(PictureBox pictureBox_4)
    {
        EventHandler handler = new EventHandler(this.method_13);
        PictureBox box = this.pictureBox_3;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_3 = pictureBox_4;
        box = this.pictureBox_3;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual Label vmethod_34()
    {
        return this.label_7;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_35(Label label_10)
    {
        this.label_7 = label_10;
    }

    internal virtual Label vmethod_36()
    {
        return this.label_8;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_37(Label label_10)
    {
        this.label_8 = label_10;
    }

    internal virtual Label vmethod_38()
    {
        return this.label_9;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_39(Label label_10)
    {
        this.label_9 = label_10;
    }

    internal virtual PictureBox vmethod_4()
    {
        return this.pictureBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_5(PictureBox pictureBox_4)
    {
        this.pictureBox_0 = pictureBox_4;
    }

    internal virtual Label vmethod_6()
    {
        return this.label_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_7(Label label_10)
    {
        this.label_1 = label_10;
    }

    internal virtual Label vmethod_8()
    {
        return this.label_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_9(Label label_10)
    {
        this.label_2 = label_10;
    }

    private delegate void Delegate50();

    private delegate void Delegate51(string string_0);

    private delegate void Delegate52();

    private delegate void Delegate53(byte[] byte_0);

    private delegate void Delegate54(int int_0);
}

