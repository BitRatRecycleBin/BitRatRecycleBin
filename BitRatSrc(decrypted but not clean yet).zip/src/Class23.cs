﻿using System;

internal static class Class23
{
    private static readonly bool bool_0 = (Type.GetType("Mono.Runtime") != null);

    public static bool smethod_0()
    {
        return bool_0;
    }
}

