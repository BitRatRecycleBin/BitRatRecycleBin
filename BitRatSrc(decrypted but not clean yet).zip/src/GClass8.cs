﻿using System;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Threading;

public sealed class GClass8
{
    private readonly bool bool_0;
    public int int_0;
    private GClass8.GDelegate8 gdelegate8_0;
    private bool bool_1;
    private Socket socket_0;
    public ManualResetEvent manualResetEvent_0;

    public GClass8(int int_1, bool bool_2);
    public void method_0(GClass8.GDelegate8 gdelegate8_1);
    public void method_1(GClass8.GDelegate8 gdelegate8_1);
    public void method_2();
    public void method_3();
    private void method_4(IAsyncResult iasyncResult_0);
    private string method_5();

    public delegate void GDelegate8(GClass1 gclass1_0);
}

