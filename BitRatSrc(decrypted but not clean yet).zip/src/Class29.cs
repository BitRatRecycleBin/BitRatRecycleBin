﻿using System;
using System.IO;
using System.Text;

internal sealed class Class29 : IDisposable
{
    private Class48 class48_0;
    private byte[] byte_0;
    private Decoder decoder_0;
    private byte[] byte_1;
    private char[] char_0;
    private char[] char_1;
    private int int_0;
    private bool bool_0;
    private bool bool_1;
    private byte[] byte_2;
    private MemoryStream memoryStream_0;
    private BinaryReader binaryReader_0;

    public Class29(Class48 class48_1) : this(class48_1, new UTF8Encoding())
    {
    }

    private Class29(Class48 class48_1, Encoding encoding_0)
    {
        if (class48_1 == null)
        {
            throw new ArgumentNullException();
        }
        if (encoding_0 == null)
        {
            throw new ArgumentNullException();
        }
        if (!class48_1.vmethod_0())
        {
            throw new ArgumentException();
        }
        this.class48_0 = class48_1;
        this.decoder_0 = encoding_0.GetDecoder();
        this.int_0 = encoding_0.GetMaxCharCount(0x80);
        int maxByteCount = encoding_0.GetMaxByteCount(1);
        if (maxByteCount < 0x10)
        {
            maxByteCount = 0x10;
        }
        this.byte_0 = new byte[maxByteCount];
        this.char_1 = null;
        this.byte_1 = null;
        this.bool_0 = encoding_0 is UnicodeEncoding;
        this.bool_1 = this.class48_0 is Class50;
    }

    public Class48 method_0()
    {
        return this.class48_0;
    }

    public void method_1()
    {
        this.method_2(true);
    }

    public int method_10(char[] char_2, int int_1, int int_2)
    {
        if (char_2 == null)
        {
            throw new ArgumentNullException("#=z5jI7l7s=", "ArgumentNull_Buffer");
        }
        if (int_1 < 0)
        {
            throw new ArgumentOutOfRangeException();
        }
        if (int_2 < 0)
        {
            throw new ArgumentOutOfRangeException();
        }
        if ((char_2.Length - int_1) < int_2)
        {
            throw new ArgumentException();
        }
        this.method_15();
        return this.method_11(char_2, int_1, int_2);
    }

    private int method_11(char[] char_2, int int_1, int int_2)
    {
        int num = 0;
        int num2 = 0;
        int num3 = int_2;
        if (this.byte_1 == null)
        {
            this.byte_1 = new byte[0x80];
        }
        while (num3 > 0)
        {
            num2 = num3;
            if (this.bool_0)
            {
                num2 = num2 << 1;
            }
            if (num2 > 0x80)
            {
                num2 = 0x80;
            }
            if (!this.bool_1)
            {
                num2 = this.class48_0.vmethod_11(this.byte_1, 0, num2);
                if (num2 == 0)
                {
                    return (int_2 - num3);
                }
                num = this.decoder_0.GetChars(this.byte_1, 0, num2, char_2, int_1);
            }
            else
            {
                Class50 class2 = (Class50) this.class48_0;
                int byteIndex = class2.method_3();
                num2 = class2.method_4(num2);
                if (num2 == 0)
                {
                    return (int_2 - num3);
                }
                num = this.decoder_0.GetChars(class2.method_1(), byteIndex, num2, char_2, int_1);
            }
            num3 -= num;
            int_1 += num;
        }
        return int_2;
    }

    private int method_12()
    {
        int num = 0;
        int byteCount = 0;
        if (this.class48_0.vmethod_2())
        {
            this.class48_0.vmethod_4();
        }
        if (this.byte_1 == null)
        {
            this.byte_1 = new byte[0x80];
        }
        if (this.char_0 == null)
        {
            this.char_0 = new char[1];
        }
        while (num == 0)
        {
            byteCount = this.bool_0 ? 2 : 1;
            int num4 = this.class48_0.vmethod_12();
            this.byte_1[0] = (byte) num4;
            if (num4 == -1)
            {
                byteCount = 0;
            }
            if (byteCount == 2)
            {
                num4 = this.class48_0.vmethod_12();
                this.byte_1[1] = (byte) num4;
                if (num4 == -1)
                {
                    byteCount = 1;
                }
            }
            if (byteCount == 0)
            {
                return -1;
            }
            num = this.decoder_0.GetChars(this.byte_1, 0, byteCount, this.char_0, 0);
        }
        return ((num != 0) ? this.char_0[0] : -1);
    }

    public char[] method_13(int int_1)
    {
        this.method_15();
        if (int_1 < 0)
        {
            throw new ArgumentOutOfRangeException();
        }
        char[] chArray = new char[int_1];
        int num = this.method_11(chArray, 0, int_1);
        if (num != int_1)
        {
            char[] dst = new char[num];
            Buffer.BlockCopy(chArray, 0, dst, 0, 2 * num);
            chArray = dst;
        }
        return chArray;
    }

    public int method_14(byte[] byte_3, int int_1, int int_2)
    {
        if (byte_3 == null)
        {
            throw new ArgumentNullException();
        }
        if (int_1 < 0)
        {
            throw new ArgumentOutOfRangeException();
        }
        if (int_2 < 0)
        {
            throw new ArgumentOutOfRangeException();
        }
        if ((byte_3.Length - int_1) < int_2)
        {
            throw new ArgumentException();
        }
        this.method_15();
        return this.class48_0.vmethod_11(byte_3, int_1, int_2);
    }

    private void method_15()
    {
        if (this.class48_0 == null)
        {
            throw new Exception();
        }
    }

    public byte[] method_16(int int_1)
    {
        if (int_1 < 0)
        {
            throw new ArgumentOutOfRangeException();
        }
        this.method_15();
        byte[] buffer = new byte[int_1];
        int num = 0;
        while (true)
        {
            int num2 = this.class48_0.vmethod_11(buffer, num, int_1);
            if (num2 != 0)
            {
                num += num2;
                int_1 -= num2;
                if (int_1 > 0)
                {
                    continue;
                }
            }
            if (num != buffer.Length)
            {
                byte[] dst = new byte[num];
                Buffer.BlockCopy(buffer, 0, dst, 0, num);
                buffer = dst;
            }
            return buffer;
        }
    }

    private void method_17(int int_1)
    {
        this.method_15();
        int num = 0;
        int num2 = 0;
        if (int_1 == 1)
        {
            num2 = this.class48_0.vmethod_12();
            if (num2 == -1)
            {
                throw new Exception();
            }
            this.byte_0[0] = (byte) num2;
        }
        else
        {
            while (true)
            {
                num2 = this.class48_0.vmethod_11(this.byte_0, num, int_1 - num);
                if (num2 == 0)
                {
                    throw new Exception();
                }
                num += num2;
                if (num >= int_1)
                {
                    return;
                }
            }
        }
    }

    internal int method_18()
    {
        int num = 0;
        int num2 = 0;
        while (num2 != 0x23)
        {
            byte num3 = this.method_6();
            num |= (num3 & 0x7f) << (num2 & 0x1f);
            num2 += 7;
            if ((num3 & 0x80) == 0)
            {
                return num;
            }
        }
        throw new FormatException();
    }

    public int method_19()
    {
        if (this.bool_1)
        {
            return ((Class50) this.class48_0).method_9();
        }
        this.method_17(4);
        return ((((this.byte_0[2] << 0x10) | (this.byte_0[1] << 0x18)) | this.byte_0[3]) | (this.byte_0[0] << 8));
    }

    private void method_2(bool bool_2)
    {
        if (bool_2)
        {
            Class48 class2 = this.class48_0;
            this.class48_0 = null;
            if (class2 != null)
            {
                class2.vmethod_6();
            }
        }
        this.class48_0 = null;
        this.byte_0 = null;
        this.decoder_0 = null;
        this.byte_1 = null;
        this.char_0 = null;
        this.char_1 = null;
    }

    public uint method_20()
    {
        this.method_17(4);
        return (uint) ((((this.byte_0[0] << 0x18) | (this.byte_0[2] << 8)) | (this.byte_0[1] << 0x10)) | this.byte_0[3]);
    }

    public long method_21()
    {
        this.method_17(8);
        byte[] buffer = this.byte_0;
        return (((long) ((ulong) (((buffer[3] | (buffer[6] << 8)) | (buffer[7] << 0x18)) | (buffer[2] << 0x10)))) | (((((buffer[1] << 0x10) | (buffer[5] << 8)) | buffer[0]) | (buffer[4] << 0x18)) << 0x20));
    }

    public ulong method_22()
    {
        this.method_17(8);
        byte[] buffer = this.byte_0;
        return (((ulong) (((buffer[0] | (buffer[2] << 0x10)) | (buffer[1] << 0x18)) | (buffer[6] << 8))) | (((((buffer[7] << 0x10) | (buffer[5] << 8)) | (buffer[3] << 0x18)) | buffer[4]) << 0x20));
    }

    public short method_23()
    {
        this.method_17(2);
        byte[] buffer = this.byte_0;
        return (short) ((buffer[0] << 8) | buffer[1]);
    }

    public ushort method_24()
    {
        this.method_17(2);
        byte[] buffer = this.byte_0;
        return (ushort) ((buffer[0] << 8) | buffer[1]);
    }

    private byte[] method_25()
    {
        byte[] buffer = this.byte_2;
        if (buffer == null)
        {
            this.byte_2 = buffer = new byte[0x10];
        }
        return buffer;
    }

    public float method_26()
    {
        this.method_17(4);
        byte[] buffer = this.byte_0;
        byte[] buffer2 = this.method_25();
        buffer2[0] = buffer[3];
        buffer2[1] = buffer[0];
        buffer2[3] = buffer[1];
        buffer2[2] = buffer[2];
        return this.method_29(buffer2).ReadSingle();
    }

    public double method_27()
    {
        this.method_17(8);
        byte[] buffer = this.byte_0;
        byte[] buffer2 = this.method_25();
        buffer2[2] = buffer[2];
        buffer2[6] = buffer[3];
        buffer2[4] = buffer[0];
        buffer2[7] = buffer[6];
        buffer2[3] = buffer[1];
        buffer2[1] = buffer[4];
        buffer2[0] = buffer[5];
        buffer2[5] = buffer[7];
        return this.method_29(buffer2).ReadDouble();
    }

    public decimal method_28()
    {
        this.method_17(0x10);
        byte[] buffer = this.byte_0;
        byte[] buffer1 = this.method_25();
        buffer1[3] = buffer[0];
        buffer1[11] = buffer[1];
        buffer1[10] = buffer[4];
        buffer1[0] = buffer[3];
        buffer1[9] = buffer[5];
        buffer1[8] = buffer[7];
        buffer1[1] = buffer[15];
        buffer1[12] = buffer[10];
        buffer1[14] = buffer[6];
        buffer1[15] = buffer[9];
        buffer1[7] = buffer[11];
        buffer1[5] = buffer[8];
        buffer1[4] = buffer[2];
        buffer1[13] = buffer[12];
        buffer1[6] = buffer[13];
        buffer1[2] = buffer[14];
        return smethod_1(buffer1);
    }

    private BinaryReader method_29(byte[] byte_3)
    {
        MemoryStream input = this.memoryStream_0;
        BinaryReader reader = this.binaryReader_0;
        if (input != null)
        {
            reader.BaseStream.Position = 0L;
        }
        else
        {
            this.memoryStream_0 = input = new MemoryStream(8);
            this.binaryReader_0 = reader = new BinaryReader(input);
        }
        input.Write(byte_3, 0, byte_3.Length);
        input.Position = 0L;
        return reader;
    }

    public int method_3()
    {
        this.method_15();
        if (!this.class48_0.vmethod_2())
        {
            return -1;
        }
        long num = this.class48_0.vmethod_4();
        this.class48_0.vmethod_5(num);
        return this.method_4();
    }

    public int method_4()
    {
        this.method_15();
        return this.method_12();
    }

    public bool method_5()
    {
        this.method_17(1);
        return (this.byte_0[0] != 0);
    }

    public byte method_6()
    {
        this.method_15();
        int num1 = this.class48_0.vmethod_12();
        if (num1 == -1)
        {
            throw new Exception();
        }
        return (byte) num1;
    }

    public sbyte method_7()
    {
        this.method_17(1);
        return (sbyte) this.byte_0[0];
    }

    public char method_8()
    {
        int num1 = this.method_4();
        if (num1 == -1)
        {
            throw new Exception();
        }
        return (char) num1;
    }

    public string method_9()
    {
        int num2 = 0;
        this.method_15();
        int capacity = this.method_18();
        if (capacity < 0)
        {
            throw new IOException();
        }
        if (capacity == 0)
        {
            return string.Empty;
        }
        if (this.byte_1 == null)
        {
            this.byte_1 = new byte[0x80];
        }
        if (this.char_1 == null)
        {
            this.char_1 = new char[this.int_0];
        }
        StringBuilder builder = null;
        while (true)
        {
            int num5 = ((capacity - num2) > 0x80) ? 0x80 : (capacity - num2);
            int byteCount = this.class48_0.vmethod_11(this.byte_1, 0, num5);
            if (byteCount == 0)
            {
                throw new Exception();
            }
            int length = this.decoder_0.GetChars(this.byte_1, 0, byteCount, this.char_1, 0);
            if ((num2 == 0) && (byteCount == capacity))
            {
                return new string(this.char_1, 0, length);
            }
            if (builder == null)
            {
                builder = new StringBuilder(capacity);
            }
            builder.Append(this.char_1, 0, length);
            num2 += byteCount;
            if (num2 >= capacity)
            {
                return builder.ToString();
            }
        }
    }

    private static decimal smethod_0(int int_1, int int_2, int int_3, int int_4)
    {
        return new decimal(int_1, int_2, int_3, (int_4 & -2147483648) != 0, (byte) (int_4 >> 0x10));
    }

    internal static decimal smethod_1(byte[] byte_3)
    {
        return smethod_0(((byte_3[0] | (byte_3[1] << 8)) | (byte_3[2] << 0x10)) | (byte_3[3] << 0x18), ((byte_3[4] | (byte_3[5] << 8)) | (byte_3[6] << 0x10)) | (byte_3[7] << 0x18), ((byte_3[8] | (byte_3[9] << 8)) | (byte_3[10] << 0x10)) | (byte_3[11] << 0x18), ((byte_3[12] | (byte_3[13] << 8)) | (byte_3[14] << 0x10)) | (byte_3[15] << 0x18));
    }

    void IDisposable.Dispose()
    {
        this.method_2(true);
    }
}

