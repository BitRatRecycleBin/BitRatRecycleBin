﻿using Microsoft.VisualBasic.CompilerServices;
using SkinSoft.VisualStyler;
using SkinSoft.VisualStyler.Licensing;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

[DesignerGenerated]
public sealed class fStartup : Form
{
    private IContainer icontainer_0;
    private SkinSoft.VisualStyler.VisualStyler visualStyler_0;

    public fStartup()
    {
        base.Load += new EventHandler(this.fStartup_Load);
        this.InitializeComponent();
    }

    [DebuggerNonUserCode]
    protected override void Dispose(bool disposing)
    {
        if (disposing && (this.icontainer_0 != null))
        {
            this.icontainer_0.Dispose();
        }
    }

    [MethodImpl(MethodImplOptions.NoOptimization)]
    private void fStartup_Load(object sender, EventArgs e)
    {
        object[] objArray = new object[] { this, sender, e };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O=\"*?;\"!", objArray);
    }

    [DebuggerStepThrough]
    private void InitializeComponent()
    {
        this.icontainer_0 = new Container();
        ComponentResourceManager manager = new ComponentResourceManager(typeof(fStartup));
        this.vmethod_1(new SkinSoft.VisualStyler.VisualStyler(this.icontainer_0));
        this.vmethod_0().BeginInit();
        base.SuspendLayout();
        this.vmethod_0().set_HookVisualStyles(true);
        this.vmethod_0().set_HostForm(this);
        this.vmethod_0().set_License((VisualStylerLicense) manager.GetObject("vStyle.License"));
        this.vmethod_0().set_ShadowStyle(0);
        base.AutoScaleDimensions = new SizeF(6f, 13f);
        base.AutoScaleMode = AutoScaleMode.Font;
        base.ClientSize = new Size(0x13, 0x12);
        base.ControlBox = false;
        this.DoubleBuffered = true;
        base.FormBorderStyle = FormBorderStyle.None;
        base.MaximizeBox = false;
        base.MinimizeBox = false;
        base.Name = "fStartup";
        base.ShowIcon = false;
        base.ShowInTaskbar = false;
        base.SizeGripStyle = SizeGripStyle.Hide;
        this.Text = "fStartup";
        base.WindowState = FormWindowState.Minimized;
        this.vmethod_0().EndInit();
        base.ResumeLayout(false);
    }

    public virtual SkinSoft.VisualStyler.VisualStyler vmethod_0()
    {
        return this.visualStyler_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    public virtual void vmethod_1(SkinSoft.VisualStyler.VisualStyler visualStyler_1)
    {
        this.visualStyler_0 = visualStyler_1;
    }
}

