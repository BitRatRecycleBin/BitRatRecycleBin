﻿using System;

internal sealed class Class115 : Class94
{
    private sbyte sbyte_0;

    public sbyte method_2()
    {
        return this.sbyte_0;
    }

    public void method_3(sbyte sbyte_1)
    {
        this.sbyte_0 = sbyte_1;
    }

    public override object vmethod_0()
    {
        return this.method_2();
    }

    public override void vmethod_1(object object_0)
    {
        if (object_0 is byte)
        {
            this.method_3((sbyte) ((byte) object_0));
        }
        else if (object_0 is short)
        {
            this.method_3((sbyte) ((short) object_0));
        }
        else if (object_0 is int)
        {
            this.method_3((sbyte) ((int) object_0));
        }
        else if (object_0 is long)
        {
            this.method_3((sbyte) ((long) object_0));
        }
        else if (object_0 is ushort)
        {
            this.method_3((sbyte) ((ushort) object_0));
        }
        else if (object_0 is uint)
        {
            this.method_3((sbyte) ((uint) object_0));
        }
        else if (object_0 is ulong)
        {
            this.method_3((sbyte) ((ulong) object_0));
        }
        else if (object_0 is float)
        {
            this.method_3((sbyte) ((float) object_0));
        }
        else if (object_0 is double)
        {
            this.method_3((sbyte) ((double) object_0));
        }
        else
        {
            this.method_3(Convert.ToSByte(object_0));
        }
    }

    public override int vmethod_2()
    {
        return 9;
    }

    public override Class94 vmethod_3(Class94 class94_0)
    {
        base.method_1(class94_0.method_0());
        switch (class94_0.vmethod_2())
        {
            case 0:
                this.method_3((sbyte) ((Class119) class94_0).method_2());
                break;

            case 2:
                this.method_3(Convert.ToSByte(((Class103) class94_0).method_2()));
                break;

            case 4:
                this.method_3(Convert.ToSByte(((Class102) class94_0).method_2()));
                break;

            case 7:
                this.method_3((sbyte) ((Class118) class94_0).method_2());
                break;

            case 9:
                this.method_3(((Class115) class94_0).method_2());
                break;

            case 10:
                this.method_3((sbyte) ((Class114) class94_0).method_2());
                break;

            case 11:
                this.method_3((sbyte) ((Class99) class94_0).method_2());
                break;

            case 14:
                this.method_3((sbyte) ((int) ((Class105) class94_0).method_2()));
                break;

            case 15:
                this.method_3((sbyte) ((Class101) class94_0).method_2());
                break;

            case 0x11:
                this.method_3((sbyte) ((Class117) class94_0).method_2());
                break;

            case 0x13:
                this.method_3((sbyte) ((Class120) class94_0).method_2());
                break;

            case 0x15:
                this.method_3((sbyte) ((Class104) class94_0).method_2());
                break;

            case 0x16:
                this.method_3((sbyte) ((Class121) class94_0).method_2());
                break;

            case 0x18:
                this.method_3(Convert.ToSByte(((Class98) class94_0).method_2()));
                break;

            default:
                throw new ArgumentOutOfRangeException();
        }
        return this;
    }

    public override Class94 vmethod_4()
    {
        Class115 class1 = new Class115();
        class1.method_3(this.sbyte_0);
        class1.method_1(base.method_0());
        return class1;
    }
}

