﻿using System;

internal enum Enum0
{
}

