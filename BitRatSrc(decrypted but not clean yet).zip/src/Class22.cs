﻿using System;

internal static class Class22
{
    private static int int_0;

    static Class22()
    {
        smethod_2();
    }

    public static unsafe int smethod_0(string string_0)
    {
        object[] objArray = new object[] { string_0 };
        return *(((int*) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O8!*?;4'", objArray)));
    }

    public static bool smethod_1(int? nullable_0)
    {
        return smethod_5(nullable_0, false);
    }

    private static void smethod_2()
    {
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O8N*?;R1", null);
    }

    private static unsafe int smethod_3()
    {
        return *(((int*) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O82*?<ZP", null)));
    }

    public static int smethod_4(bool bool_0)
    {
        // Unresolved stack state at '00000000'
    }

    private static bool smethod_5(int? nullable_0, bool bool_0)
    {
        // Unresolved stack state at '00000000'
    }
}

