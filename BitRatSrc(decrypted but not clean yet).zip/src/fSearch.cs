﻿using BrightIdeasSoftware;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.Collections.Concurrent;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using VisualPlus.Toolkit.Controls.Interactivity;

[DesignerGenerated]
public sealed class fSearch : Form
{
    private IContainer icontainer_0;
    private Timer timer_0;
    private StatusStrip statusStrip_0;
    private Panel panel_0;
    private FastObjectListView fastObjectListView_0;
    private OLVColumn olvcolumn_0;
    private OLVColumn olvcolumn_1;
    private OLVColumn olvcolumn_2;
    private ToolStripStatusLabel toolStripStatusLabel_0;
    private ToolStripStatusLabel toolStripStatusLabel_1;
    private OLVColumn olvcolumn_3;
    private OLVColumn olvcolumn_4;
    private OLVColumn olvcolumn_5;
    private TextBox textBox_0;
    private Label label_0;
    private Label label_1;
    private TextBox textBox_1;
    private OLVColumn olvcolumn_6;
    private Label label_2;
    private ContextMenuStrip contextMenuStrip_0;
    private ToolStripMenuItem toolStripMenuItem_0;
    private ToolStripMenuItem toolStripMenuItem_1;
    private ToolStripMenuItem toolStripMenuItem_2;
    private ToolStripMenuItem toolStripMenuItem_3;
    private ToolStripSeparator toolStripSeparator_0;
    private ToolStripMenuItem toolStripMenuItem_4;
    private ToolStripSeparator toolStripSeparator_1;
    private ToolStripMenuItem toolStripMenuItem_5;
    private ToolStripMenuItem toolStripMenuItem_6;
    private ToolStripMenuItem toolStripMenuItem_7;
    private ToolStripMenuItem toolStripMenuItem_8;
    private ToolStripMenuItem toolStripMenuItem_9;
    private ToolStripMenuItem toolStripMenuItem_10;
    private ToolStripMenuItem toolStripMenuItem_11;
    private ToolStripMenuItem toolStripMenuItem_12;
    private ToolStripMenuItem toolStripMenuItem_13;
    private ToolStripMenuItem toolStripMenuItem_14;
    private ToolStripMenuItem toolStripMenuItem_15;
    private ToolStripMenuItem toolStripMenuItem_16;
    private ToolStripSeparator toolStripSeparator_2;
    private ToolStripMenuItem toolStripMenuItem_17;
    private ToolStripSeparator toolStripSeparator_3;
    private ToolStripMenuItem toolStripMenuItem_18;
    private ToolStripMenuItem toolStripMenuItem_19;
    private ToolStripSeparator toolStripSeparator_4;
    private ToolStripMenuItem toolStripMenuItem_20;
    private ToolStripMenuItem toolStripMenuItem_21;
    private ToolStripSeparator toolStripSeparator_5;
    private ToolStripMenuItem toolStripMenuItem_22;
    private ToolStripMenuItem toolStripMenuItem_23;
    private ToolStripSeparator toolStripSeparator_6;
    private ToolStripMenuItem toolStripMenuItem_24;
    private ToolStripStatusLabel toolStripStatusLabel_2;
    private BackgroundWorker backgroundWorker_0;
    private BackgroundWorker backgroundWorker_1;
    private ToolStripStatusLabel toolStripStatusLabel_3;
    private ToolStripMenuItem toolStripMenuItem_25;
    private VisualButton visualButton_0;
    private VisualButton visualButton_1;
    public string string_0;
    public string string_1;
    public string string_2;
    public string string_3;
    public string string_4;
    public string string_5;
    public string string_6;
    public string string_7;
    private int int_0;
    public ConcurrentStack<cFileSearch> concurrentStack_0;

    public fSearch();
    [DebuggerNonUserCode]
    protected override void Dispose(bool disposing);
    private void fSearch_Closing(object sender, CancelEventArgs e);
    private void fSearch_Load(object sender, EventArgs e);
    [DebuggerStepThrough]
    private void InitializeComponent();
    public void method_0(string string_8);
    public void method_1(string string_8);
    private void method_10(object sender, EventArgs e);
    private void method_11(object sender, EventArgs e);
    private void method_12(object sender, EventArgs e);
    private void method_13(object sender, EventArgs e);
    private void method_14(object sender, EventArgs e);
    private void method_15(object sender, EventArgs e);
    private void method_16(object sender, EventArgs e);
    private void method_17(object sender, EventArgs e);
    private void method_18(object sender, EventArgs e);
    private void method_19(object sender, EventArgs e);
    public void method_2(string string_8);
    private void method_20(object sender, EventArgs e);
    private void method_21(object sender, EventArgs e);
    private void method_22(object sender, EventArgs e);
    private void method_23(object sender, EventArgs e);
    private void method_24(object sender, EventArgs e);
    private void method_25(object sender, EventArgs e);
    public void method_26(int int_1);
    private void method_27(object sender, DoWorkEventArgs e);
    private void method_28(object sender, DoWorkEventArgs e);
    private void method_29(object sender, EventArgs e);
    public void method_3(string string_8, string string_9, string string_10, string string_11, string string_12, string string_13, string string_14, string string_15);
    private void method_30(object sender, EventArgs e);
    private void method_31(object sender, EventArgs e);
    private void method_32(object sender, FormatRowEventArgs e);
    private void method_33(object sender, EventArgs e);
    private void method_34(object sender, EventArgs e);
    private void method_35(object sender, EventArgs e);
    private void method_36(object sender, MouseEventArgs e);
    public void method_4();
    public void method_5(bool bool_0, string string_8);
    public void method_6();
    public void method_7(string string_8, string string_9, string string_10, string string_11, string string_12, string string_13);
    public void method_8(string string_8);
    public void method_9();
    internal virtual Timer vmethod_0();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_1(Timer timer_1);
    internal virtual OLVColumn vmethod_10();
    internal virtual ToolStripMenuItem vmethod_100();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_101(ToolStripMenuItem toolStripMenuItem_26);
    internal virtual ToolStripStatusLabel vmethod_102();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_103(ToolStripStatusLabel toolStripStatusLabel_4);
    internal virtual BackgroundWorker vmethod_104();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_105(BackgroundWorker backgroundWorker_2);
    internal virtual BackgroundWorker vmethod_106();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_107(BackgroundWorker backgroundWorker_2);
    internal virtual ToolStripStatusLabel vmethod_108();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_109(ToolStripStatusLabel toolStripStatusLabel_4);
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_11(OLVColumn olvcolumn_7);
    internal virtual ToolStripMenuItem vmethod_110();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_111(ToolStripMenuItem toolStripMenuItem_26);
    internal virtual VisualButton vmethod_112();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_113(VisualButton visualButton_2);
    internal virtual VisualButton vmethod_114();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_115(VisualButton visualButton_2);
    internal virtual OLVColumn vmethod_12();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_13(OLVColumn olvcolumn_7);
    internal virtual ToolStripStatusLabel vmethod_14();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_15(ToolStripStatusLabel toolStripStatusLabel_4);
    internal virtual ToolStripStatusLabel vmethod_16();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_17(ToolStripStatusLabel toolStripStatusLabel_4);
    internal virtual OLVColumn vmethod_18();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_19(OLVColumn olvcolumn_7);
    internal virtual StatusStrip vmethod_2();
    internal virtual OLVColumn vmethod_20();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_21(OLVColumn olvcolumn_7);
    internal virtual OLVColumn vmethod_22();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_23(OLVColumn olvcolumn_7);
    internal virtual TextBox vmethod_24();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_25(TextBox textBox_2);
    internal virtual Label vmethod_26();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_27(Label label_3);
    internal virtual Label vmethod_28();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_29(Label label_3);
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_3(StatusStrip statusStrip_1);
    internal virtual TextBox vmethod_30();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_31(TextBox textBox_2);
    internal virtual OLVColumn vmethod_32();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_33(OLVColumn olvcolumn_7);
    internal virtual Label vmethod_34();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_35(Label label_3);
    internal virtual ContextMenuStrip vmethod_36();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_37(ContextMenuStrip contextMenuStrip_1);
    internal virtual ToolStripMenuItem vmethod_38();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_39(ToolStripMenuItem toolStripMenuItem_26);
    internal virtual Panel vmethod_4();
    internal virtual ToolStripMenuItem vmethod_40();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_41(ToolStripMenuItem toolStripMenuItem_26);
    internal virtual ToolStripMenuItem vmethod_42();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_43(ToolStripMenuItem toolStripMenuItem_26);
    internal virtual ToolStripMenuItem vmethod_44();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_45(ToolStripMenuItem toolStripMenuItem_26);
    internal virtual ToolStripSeparator vmethod_46();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_47(ToolStripSeparator toolStripSeparator_7);
    internal virtual ToolStripMenuItem vmethod_48();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_49(ToolStripMenuItem toolStripMenuItem_26);
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_5(Panel panel_1);
    internal virtual ToolStripSeparator vmethod_50();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_51(ToolStripSeparator toolStripSeparator_7);
    internal virtual ToolStripMenuItem vmethod_52();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_53(ToolStripMenuItem toolStripMenuItem_26);
    internal virtual ToolStripMenuItem vmethod_54();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_55(ToolStripMenuItem toolStripMenuItem_26);
    internal virtual ToolStripMenuItem vmethod_56();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_57(ToolStripMenuItem toolStripMenuItem_26);
    internal virtual ToolStripMenuItem vmethod_58();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_59(ToolStripMenuItem toolStripMenuItem_26);
    internal virtual FastObjectListView vmethod_6();
    internal virtual ToolStripMenuItem vmethod_60();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_61(ToolStripMenuItem toolStripMenuItem_26);
    internal virtual ToolStripMenuItem vmethod_62();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_63(ToolStripMenuItem toolStripMenuItem_26);
    internal virtual ToolStripMenuItem vmethod_64();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_65(ToolStripMenuItem toolStripMenuItem_26);
    internal virtual ToolStripMenuItem vmethod_66();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_67(ToolStripMenuItem toolStripMenuItem_26);
    internal virtual ToolStripMenuItem vmethod_68();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_69(ToolStripMenuItem toolStripMenuItem_26);
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_7(FastObjectListView fastObjectListView_1);
    internal virtual ToolStripMenuItem vmethod_70();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_71(ToolStripMenuItem toolStripMenuItem_26);
    internal virtual ToolStripMenuItem vmethod_72();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_73(ToolStripMenuItem toolStripMenuItem_26);
    internal virtual ToolStripMenuItem vmethod_74();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_75(ToolStripMenuItem toolStripMenuItem_26);
    internal virtual ToolStripSeparator vmethod_76();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_77(ToolStripSeparator toolStripSeparator_7);
    internal virtual ToolStripMenuItem vmethod_78();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_79(ToolStripMenuItem toolStripMenuItem_26);
    internal virtual OLVColumn vmethod_8();
    internal virtual ToolStripSeparator vmethod_80();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_81(ToolStripSeparator toolStripSeparator_7);
    internal virtual ToolStripMenuItem vmethod_82();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_83(ToolStripMenuItem toolStripMenuItem_26);
    internal virtual ToolStripMenuItem vmethod_84();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_85(ToolStripMenuItem toolStripMenuItem_26);
    internal virtual ToolStripSeparator vmethod_86();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_87(ToolStripSeparator toolStripSeparator_7);
    internal virtual ToolStripMenuItem vmethod_88();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_89(ToolStripMenuItem toolStripMenuItem_26);
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_9(OLVColumn olvcolumn_7);
    internal virtual ToolStripMenuItem vmethod_90();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_91(ToolStripMenuItem toolStripMenuItem_26);
    internal virtual ToolStripSeparator vmethod_92();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_93(ToolStripSeparator toolStripSeparator_7);
    internal virtual ToolStripMenuItem vmethod_94();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_95(ToolStripMenuItem toolStripMenuItem_26);
    internal virtual ToolStripMenuItem vmethod_96();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_97(ToolStripMenuItem toolStripMenuItem_26);
    internal virtual ToolStripSeparator vmethod_98();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_99(ToolStripSeparator toolStripSeparator_7);

    private delegate void Delegate191(string string_0);

    private delegate void Delegate192(bool bool_0, string string_0);

    private delegate void Delegate193();

    private delegate void Delegate194(string string_0);

    private delegate void Delegate195(string string_0);

    private delegate void Delegate196(string string_0);

    private delegate void Delegate197();

    private delegate void Delegate198(string string_0, string string_1, string string_2, string string_3, string string_4, string string_5, string string_6, string string_7);

    private delegate void Delegate199(int int_0);

    private delegate void Delegate200();
}

