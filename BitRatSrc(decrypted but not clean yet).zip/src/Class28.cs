﻿using System;

internal static class Class28
{
    public static unsafe void smethod_0(byte[] byte_0, int int_0, int int_1)
    {
        for (int i = 0; i < 4; i++)
        {
            byte* numPtr1 = &(byte_0[int_0++]);
            numPtr1[0] = (byte) (numPtr1[0] ^ ((byte) (int_1 >> ((i * 8) & 0x1f))));
        }
    }

    public static unsafe void smethod_1(byte[] byte_0, int int_0, int int_1)
    {
        for (int i = 0; i < 4; i++)
        {
            if (int_0 >= byte_0.Length)
            {
                return;
            }
            byte* numPtr1 = &(byte_0[int_0++]);
            numPtr1[0] = (byte) (numPtr1[0] ^ ((byte) (int_1 >> ((i * 8) & 0x1f))));
        }
    }

    public static unsafe void smethod_2(byte[] byte_0, int int_0, long long_0)
    {
        for (int i = 0; i < 8; i++)
        {
            byte* numPtr1 = &(byte_0[int_0++]);
            numPtr1[0] = (byte) (numPtr1[0] ^ ((byte) (long_0 >> ((i * 8) & 0x3f))));
        }
    }
}

