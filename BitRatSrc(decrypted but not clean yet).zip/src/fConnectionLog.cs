﻿using BrightIdeasSoftware;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.Collections.Concurrent;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

[DesignerGenerated]
public sealed class fConnectionLog : Form
{
    private IContainer icontainer_0;
    private FastObjectListView fastObjectListView_0;
    private OLVColumn olvcolumn_0;
    private OLVColumn olvcolumn_1;
    private OLVColumn olvcolumn_2;
    private StatusStrip statusStrip_0;
    private ToolStripStatusLabel toolStripStatusLabel_0;
    private BackgroundWorker backgroundWorker_0;
    private Timer timer_0;
    private OLVColumn olvcolumn_3;
    private ContextMenuStrip contextMenuStrip_0;
    private ToolStripMenuItem toolStripMenuItem_0;
    private ToolStripMenuItem toolStripMenuItem_1;
    private ToolStripSeparator toolStripSeparator_0;
    private ToolStripMenuItem toolStripMenuItem_2;
    private ToolStripSeparator toolStripSeparator_1;
    private ToolStripMenuItem toolStripMenuItem_3;
    private ToolStripSeparator toolStripSeparator_2;
    private ToolStripMenuItem toolStripMenuItem_4;
    private ToolStripMenuItem toolStripMenuItem_5;
    private ToolStripSeparator toolStripSeparator_3;
    private ToolStripMenuItem toolStripMenuItem_6;
    private ToolStripMenuItem toolStripMenuItem_7;
    private ToolStripMenuItem toolStripMenuItem_8;
    private ToolStripSeparator toolStripSeparator_4;
    public ConcurrentQueue<cLogCon> concurrentQueue_0;
    public ConcurrentQueue<cLogCon> concurrentQueue_1;
    public ConcurrentQueue<cLogCon> concurrentQueue_2;

    public fConnectionLog();
    [DebuggerNonUserCode]
    protected override void Dispose(bool disposing);
    private void fConnectionLog_Closing(object sender, CancelEventArgs e);
    private void fConnectionLog_Load(object sender, EventArgs e);
    [DebuggerStepThrough]
    private void InitializeComponent();
    public void method_0();
    public void method_1(string string_0, string string_1, int int_0);
    private void method_10(object sender, EventArgs e);
    private void method_11(object sender, EventArgs e);
    private void method_12(object sender, EventArgs e);
    private void method_13(object sender, MouseEventArgs e);
    private void method_14(object sender, EventArgs e);
    public void method_2();
    public void method_3();
    public void method_4();
    private void method_5(object sender, DoWorkEventArgs e);
    private void method_6(object sender, EventArgs e);
    private void method_7(object sender, FormatRowEventArgs e);
    private void method_8(object sender, EventArgs e);
    private void method_9(object sender, EventArgs e);
    internal virtual FastObjectListView vmethod_0();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_1(FastObjectListView fastObjectListView_1);
    internal virtual ToolStripStatusLabel vmethod_10();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_11(ToolStripStatusLabel toolStripStatusLabel_1);
    internal virtual BackgroundWorker vmethod_12();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_13(BackgroundWorker backgroundWorker_1);
    internal virtual Timer vmethod_14();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_15(Timer timer_1);
    internal virtual OLVColumn vmethod_16();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_17(OLVColumn olvcolumn_4);
    internal virtual ContextMenuStrip vmethod_18();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_19(ContextMenuStrip contextMenuStrip_1);
    internal virtual OLVColumn vmethod_2();
    internal virtual ToolStripMenuItem vmethod_20();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_21(ToolStripMenuItem toolStripMenuItem_9);
    internal virtual ToolStripMenuItem vmethod_22();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_23(ToolStripMenuItem toolStripMenuItem_9);
    internal virtual ToolStripSeparator vmethod_24();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_25(ToolStripSeparator toolStripSeparator_5);
    internal virtual ToolStripMenuItem vmethod_26();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_27(ToolStripMenuItem toolStripMenuItem_9);
    internal virtual ToolStripSeparator vmethod_28();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_29(ToolStripSeparator toolStripSeparator_5);
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_3(OLVColumn olvcolumn_4);
    internal virtual ToolStripMenuItem vmethod_30();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_31(ToolStripMenuItem toolStripMenuItem_9);
    internal virtual ToolStripSeparator vmethod_32();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_33(ToolStripSeparator toolStripSeparator_5);
    internal virtual ToolStripMenuItem vmethod_34();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_35(ToolStripMenuItem toolStripMenuItem_9);
    internal virtual ToolStripMenuItem vmethod_36();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_37(ToolStripMenuItem toolStripMenuItem_9);
    internal virtual ToolStripSeparator vmethod_38();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_39(ToolStripSeparator toolStripSeparator_5);
    internal virtual OLVColumn vmethod_4();
    internal virtual ToolStripMenuItem vmethod_40();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_41(ToolStripMenuItem toolStripMenuItem_9);
    internal virtual ToolStripMenuItem vmethod_42();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_43(ToolStripMenuItem toolStripMenuItem_9);
    internal virtual ToolStripMenuItem vmethod_44();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_45(ToolStripMenuItem toolStripMenuItem_9);
    internal virtual ToolStripSeparator vmethod_46();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_47(ToolStripSeparator toolStripSeparator_5);
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_5(OLVColumn olvcolumn_4);
    internal virtual OLVColumn vmethod_6();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_7(OLVColumn olvcolumn_4);
    internal virtual StatusStrip vmethod_8();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_9(StatusStrip statusStrip_1);

    private delegate void Delegate157();

    private delegate void Delegate158();

    private delegate void Delegate159();

    private delegate void Delegate160(string string_0, string string_1, int int_0);
}

