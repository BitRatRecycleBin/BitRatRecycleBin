﻿using System;

internal sealed class Class12
{
    private int int_0;

    public int method_0()
    {
        return this.int_0;
    }

    public void method_1(int int_1)
    {
        this.int_0 = int_1;
    }
}

