﻿using System;

internal sealed class Class100 : Class94
{
    private UIntPtr uintptr_0;

    public UIntPtr method_2()
    {
        return this.uintptr_0;
    }

    public void method_3(UIntPtr uintptr_1)
    {
        this.uintptr_0 = uintptr_1;
    }

    public override object vmethod_0()
    {
        return this.method_2();
    }

    public override void vmethod_1(object object_0)
    {
        this.method_3((UIntPtr) object_0);
    }

    public override int vmethod_2()
    {
        return 8;
    }

    public override Class94 vmethod_3(Class94 class94_0)
    {
        base.method_1(class94_0.method_0());
        int num = class94_0.vmethod_2();
        if (num == 0)
        {
            this.method_3((UIntPtr) ((Class119) class94_0).method_2());
        }
        else
        {
            switch (num)
            {
                case 4:
                    this.method_3((UIntPtr) ((Class102) class94_0).method_2());
                    break;

                case 5:
                case 6:
                case 9:
                    goto TR_0000;

                case 7:
                    this.method_3((UIntPtr) ((Class118) class94_0).method_2());
                    break;

                case 8:
                    this.method_3(((Class100) class94_0).method_2());
                    break;

                case 10:
                    this.method_3((UIntPtr) ((ulong) ((Class114) class94_0).method_2()));
                    break;

                case 11:
                    this.method_3((UIntPtr) ((Class99) class94_0).method_2());
                    break;

                default:
                    switch (num)
                    {
                        case 0x11:
                            this.method_3((UIntPtr) ((ulong) ((Class117) class94_0).method_2()));
                            break;

                        case 0x13:
                            this.method_3((UIntPtr) ((Class120) class94_0).method_2());
                            break;

                        case 0x15:
                            this.method_3((UIntPtr) ((Class104) class94_0).method_2());
                            break;

                        case 0x16:
                            this.method_3((UIntPtr) ((Class121) class94_0).method_2());
                            break;

                        case 0x18:
                            this.method_3(new UIntPtr(Convert.ToUInt64(((Class98) class94_0).method_2())));
                            break;

                        default:
                            goto TR_0000;
                    }
                    break;
            }
        }
        return this;
    TR_0000:
        throw new ArgumentOutOfRangeException();
    }

    public override Class94 vmethod_4()
    {
        Class100 class1 = new Class100();
        class1.method_3(this.uintptr_0);
        class1.method_1(base.method_0());
        return class1;
    }
}

