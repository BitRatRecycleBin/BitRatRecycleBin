﻿using System;
using System.Runtime.InteropServices;

internal sealed class Class47
{
    internal static readonly Struct11 struct11_0; // data size: 256 bytes
    internal static readonly Struct9 struct9_0; // data size: 1024 bytes
    internal static readonly Struct10 struct10_0; // data size: 20 bytes
    internal static readonly Struct11 struct11_1; // data size: 256 bytes
    internal static readonly Struct9 struct9_1; // data size: 1024 bytes
    internal static readonly Struct8 struct8_0; // data size: 30 bytes

    [StructLayout(LayoutKind.Explicit, Size=20, Pack=1)]
    private struct Struct10
    {
    }

    [StructLayout(LayoutKind.Explicit, Size=0x100, Pack=1)]
    private struct Struct11
    {
    }

    [StructLayout(LayoutKind.Explicit, Size=30, Pack=1)]
    private struct Struct8
    {
    }

    [StructLayout(LayoutKind.Explicit, Size=0x400, Pack=1)]
    private struct Struct9
    {
    }
}

