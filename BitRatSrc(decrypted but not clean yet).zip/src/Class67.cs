﻿using System;

internal static class Class67
{
    public static Type smethod_0(Type type_0)
    {
        return ((type_0.IsByRef || (type_0.IsArray || type_0.IsPointer)) ? smethod_0(type_0.GetElementType()) : type_0);
    }

    public static Type smethod_1(Type type_0)
    {
        if (type_0.HasElementType && !type_0.IsArray)
        {
            type_0 = type_0.GetElementType();
        }
        return type_0;
    }

    public static Class20<Struct17> smethod_2(Type type_0)
    {
        Class20<Struct17> class2 = new Class20<Struct17>();
        Type elementType = type_0;
        while (true)
        {
            Struct17 struct2;
            if (elementType.IsArray)
            {
                struct2 = new Struct17();
                struct2.int_0 = 0;
                struct2.int_1 = elementType.GetArrayRank();
                class2.method_7(struct2);
            }
            else if (elementType.IsByRef)
            {
                struct2 = new Struct17();
                struct2.int_0 = 2;
                class2.method_7(struct2);
            }
            else
            {
                if (!elementType.IsPointer)
                {
                    return class2;
                }
                struct2 = new Struct17();
                struct2.int_0 = 1;
                class2.method_7(struct2);
            }
            elementType = elementType.GetElementType();
        }
    }

    public static Class20<Struct17> smethod_3(string string_0)
    {
        string str = string_0;
        Class20<Struct17> class2 = new Class20<Struct17>();
        while (true)
        {
            Struct17 struct2;
            if (str.EndsWith("&", StringComparison.Ordinal))
            {
                struct2 = new Struct17();
                struct2.int_0 = 2;
                class2.method_7(struct2);
                str = str.Substring(0, str.Length - 1);
                continue;
            }
            if (str.EndsWith("*", StringComparison.Ordinal))
            {
                struct2 = new Struct17();
                struct2.int_0 = 1;
                class2.method_7(struct2);
                str = str.Substring(0, str.Length - 1);
                continue;
            }
            if (str.EndsWith("[]", StringComparison.Ordinal))
            {
                struct2 = new Struct17();
                struct2.int_0 = 0;
                struct2.int_1 = 1;
                class2.method_7(struct2);
                str = str.Substring(0, str.Length - 2);
                continue;
            }
            if (!str.EndsWith(",]", StringComparison.Ordinal))
            {
                return class2;
            }
            int num2 = 1;
            int length = -1;
            int num = str.Length - 2;
            while (true)
            {
                if (num < 0)
                {
                    if (length < 0)
                    {
                        throw new InvalidOperationException("VM-3014");
                    }
                    str = str.Substring(0, length);
                    struct2 = new Struct17();
                    struct2.int_0 = 0;
                    struct2.int_1 = num2;
                    class2.method_7(struct2);
                    break;
                }
                char ch = str[num];
                if (ch == ',')
                {
                    num2++;
                }
                else
                {
                    if (ch != '[')
                    {
                        throw new InvalidOperationException("VM-3012");
                    }
                    length = num;
                    num = -1;
                }
                num--;
            }
        }
    }

    public static Type smethod_4(Type type_0, Class20<Struct17> class20_0)
    {
        Type type = type_0;
        while (class20_0.Count > 0)
        {
            Struct17 struct2 = class20_0.method_6();
            int num = struct2.int_0;
            switch (num)
            {
                case 0:
                {
                    type = (struct2.int_1 != 1) ? type.MakeArrayType(struct2.int_1) : type.MakeArrayType();
                    continue;
                }
                case 1:
                {
                    type = type.MakePointerType();
                    continue;
                }
                case 2:
                {
                    type = type.MakeByRefType();
                    continue;
                }
            }
        }
        return type;
    }
}

