﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Threading;

internal sealed class Class16
{
    public readonly Class31 class31_0 = new Class31(0x23ad5610, 9);
    public readonly Class31 class31_1 = new Class31(0x15de4b2b, 10);
    public readonly Class31 class31_2 = new Class31(0x48820a13, 10);
    public readonly Class31 class31_3 = new Class31(0x1fcf2a9b, 4);
    public readonly Class31 class31_4 = new Class31(-1430168795, 12);
    public readonly Class31 class31_5 = new Class31(0x4c5f210e, 2);
    public readonly Class31 class31_6 = new Class31(-1698180648, 10);
    public readonly Class31 class31_7 = new Class31(0x1100a8d, 10);
    public readonly Class31 class31_8 = new Class31(-289882345, 10);
    public readonly Class31 class31_9 = new Class31(-838977618, 2);
    public readonly Class31 class31_10 = new Class31(-552871191, 10);
    public readonly Class31 class31_11 = new Class31(0xaadf678, 10);
    public readonly Class31 class31_12 = new Class31(-1583444599, 10);
    public readonly Class31 class31_13 = new Class31(0x4f2c63b5, 10);
    public readonly Class31 class31_14 = new Class31(-639857997, 9);
    public readonly Class31 class31_15 = new Class31(-2062375476, 4);
    public readonly Class31 class31_16 = new Class31(0x2b1eb347, 10);
    public readonly Class31 class31_17 = new Class31(0x21cdc908, 10);
    public readonly Class31 class31_18 = new Class31(0x63f318d, 10);
    public readonly Class31 class31_19 = new Class31(0x504e5638, 10);
    public readonly Class31 class31_20 = new Class31(0x238b5dc4, 10);
    public readonly Class31 class31_21 = new Class31(0xf7804d8, 10);
    public readonly Class31 class31_22 = new Class31(0x7b293428, 10);
    public readonly Class31 class31_23 = new Class31(0x5e88cb2f, 10);
    public readonly Class31 class31_24 = new Class31(-745642527, 10);
    public readonly Class31 class31_25 = new Class31(0x33d0fe10, 10);
    public readonly Class31 class31_26 = new Class31(-1638815350, 2);
    public readonly Class31 class31_27 = new Class31(-154790295, 10);
    public readonly Class31 class31_28 = new Class31(0x65d1ec6e, 2);
    public readonly Class31 class31_29 = new Class31(-328288691, 10);
    public readonly Class31 class31_30 = new Class31(-1371866470, 10);
    public readonly Class31 class31_31 = new Class31(-1421617972, 2);
    public readonly Class31 class31_32 = new Class31(-1859728989, 10);
    public readonly Class31 class31_33 = new Class31(-1499727640, 8);
    public readonly Class31 class31_34 = new Class31(0x4b6c4b7c, 10);
    public readonly Class31 class31_35 = new Class31(0x4c8a5bc9, 2);
    public readonly Class31 class31_36 = new Class31(0x1b42590d, 10);
    public readonly Class31 class31_37 = new Class31(0x276f1215, 10);
    public readonly Class31 class31_38 = new Class31(0x4d76063a, 1);
    public readonly Class31 class31_39 = new Class31(-240847514, 9);
    public readonly Class31 class31_40 = new Class31(-1203364073, 10);
    public readonly Class31 class31_41 = new Class31(0x7d7151d7, 2);
    public readonly Class31 class31_42 = new Class31(-484977883, 10);
    public readonly Class31 class31_43 = new Class31(0x37f0b5, 10);
    public readonly Class31 class31_44 = new Class31(-957812176, 10);
    public readonly Class31 class31_45 = new Class31(-1657963104, 10);
    public readonly Class31 class31_46 = new Class31(-583397345, 10);
    public readonly Class31 class31_47 = new Class31(-1410971792, 9);
    public readonly Class31 class31_48 = new Class31(0x262fdab9, 10);
    public readonly Class31 class31_49 = new Class31(-1648478077, 10);
    public readonly Class31 class31_50 = new Class31(0x576338f9, 10);
    private Class31[] class31_51;
    public readonly Class31 class31_52 = new Class31(-1376452137, 9);
    public readonly Class31 class31_53 = new Class31(0x30bdf7c7, 10);
    public readonly Class31 class31_54 = new Class31(0x996d7c2, 10);
    public readonly Class31 class31_55 = new Class31(0x4c003edb, 10);
    public readonly Class31 class31_56 = new Class31(0x28929c85, 2);
    public readonly Class31 class31_57 = new Class31(-539605913, 2);
    public readonly Class31 class31_58 = new Class31(0x20c7833c, 9);
    public readonly Class31 class31_59 = new Class31(-1781207118, 10);
    public readonly Class31 class31_60 = new Class31(-1027123539, 12);
    public readonly Class31 class31_61 = new Class31(-1432653780, 10);
    public readonly Class31 class31_62 = new Class31(0x577770fa, 10);
    public readonly Class31 class31_63 = new Class31(0x1cbc5d96, 10);
    public readonly Class31 class31_64 = new Class31(-2094542096, 11);
    public readonly Class31 class31_65 = new Class31(0x6edc58a6, 10);
    public readonly Class31 class31_66 = new Class31(-711203786, 10);
    public readonly Class31 class31_67 = new Class31(-1847212807, 10);
    public readonly Class31 class31_68 = new Class31(0x1ab84f95, 9);
    public readonly Class31 class31_69 = new Class31(-1067599509, 10);
    public readonly Class31 class31_70 = new Class31(0x7234bd26, 2);
    public readonly Class31 class31_71 = new Class31(0x35e924ad, 10);
    public readonly Class31 class31_72 = new Class31(-203280442, 10);
    public readonly Class31 class31_73 = new Class31(0x1fb45d9b, 2);
    public readonly Class31 class31_74 = new Class31(0x7fb3e8b7, 8);
    public readonly Class31 class31_75 = new Class31(-214417301, 10);
    public readonly Class31 class31_76 = new Class31(-1737052225, 10);
    public readonly Class31 class31_77 = new Class31(-1021389762, 10);
    public readonly Class31 class31_78 = new Class31(-1216233993, 10);
    public readonly Class31 class31_79 = new Class31(0x3f45f3ca, 10);
    public readonly Class31 class31_80 = new Class31(0x3dc1e222, 10);
    public readonly Class31 class31_81 = new Class31(0x1759b305, 10);
    public readonly Class31 class31_82 = new Class31(0x3551de7c, 9);
    public readonly Class31 class31_83 = new Class31(-1355282220, 10);
    public readonly Class31 class31_84 = new Class31(0x5cff79eb, 10);
    public readonly Class31 class31_85 = new Class31(-1314341727, 2);
    public readonly Class31 class31_86 = new Class31(-1302985347, 10);
    public readonly Class31 class31_87 = new Class31(0x722e1231, 8);
    public readonly Class31 class31_88 = new Class31(-357261539, 10);
    public readonly Class31 class31_89 = new Class31(0x48a91c09, 2);
    public readonly Class31 class31_90 = new Class31(0x15a42f00, 10);
    public readonly Class31 class31_91 = new Class31(0x48795db9, 10);
    public readonly Class31 class31_92 = new Class31(0x67135f2f, 10);
    public readonly Class31 class31_93 = new Class31(-381068917, 10);
    public readonly Class31 class31_94 = new Class31(0x52efaf28, 10);
    private bool bool_0;
    public readonly Class31 class31_95 = new Class31(0x133a29f3, 10);
    public readonly Class31 class31_96 = new Class31(0x40b2aea6, 10);
    public readonly Class31 class31_97 = new Class31(0x45d65c9a, 9);
    public readonly Class31 class31_98 = new Class31(0x31ed263b, 2);
    public readonly Class31 class31_99 = new Class31(-134358794, 10);
    public readonly Class31 class31_100 = new Class31(0x7d131a9a, 10);
    public readonly Class31 class31_101 = new Class31(0x724daf8d, 2);
    public readonly Class31 class31_102 = new Class31(-1326824001, 10);
    public readonly Class31 class31_103 = new Class31(0x34d0a2eb, 10);
    public readonly Class31 class31_104 = new Class31(-866072610, 10);
    public readonly Class31 class31_105 = new Class31(0x7a7d219b, 2);
    public readonly Class31 class31_106 = new Class31(0x7e83c536, 10);
    public readonly Class31 class31_107 = new Class31(-1058882580, 10);
    public readonly Class31 class31_108 = new Class31(0x4ed9dfed, 10);
    public readonly Class31 class31_109 = new Class31(0x2c6a2311, 10);
    public readonly Class31 class31_110 = new Class31(-1392103904, 2);
    public readonly Class31 class31_111 = new Class31(-1684870423, 10);
    public readonly Class31 class31_112 = new Class31(0x1963375a, 10);
    public readonly Class31 class31_113 = new Class31(-1742352633, 10);
    public readonly Class31 class31_114 = new Class31(-1740866013, 8);
    public readonly Class31 class31_115 = new Class31(0x352aee23, 2);
    public readonly Class31 class31_116 = new Class31(0xe86de71, 8);
    public readonly Class31 class31_117 = new Class31(0x4cd495da, 10);
    public readonly Class31 class31_118 = new Class31(-1239717344, 10);
    public readonly Class31 class31_119 = new Class31(0x20ad5809, 10);
    public readonly Class31 class31_120 = new Class31(0x782628c8, 10);
    public readonly Class31 class31_121 = new Class31(-1767732940, 9);
    public readonly Class31 class31_122 = new Class31(-1226593428, 10);
    public readonly Class31 class31_123 = new Class31(-1897509078, 9);
    public readonly Class31 class31_124 = new Class31(0x29227374, 2);
    public readonly Class31 class31_125 = new Class31(-114988973, 9);
    public readonly Class31 class31_126 = new Class31(-1815993426, 4);
    public readonly Class31 class31_127 = new Class31(-1061766621, 10);
    public readonly Class31 class31_128 = new Class31(-1000513042, 10);
    public readonly Class31 class31_129 = new Class31(0x27cfeb61, 10);
    public readonly Class31 class31_130 = new Class31(0x5502150b, 10);
    public readonly Class31 class31_131 = new Class31(-738447984, 10);
    public readonly Class31 class31_132 = new Class31(0x27fbcd60, 10);
    public readonly Class31 class31_133 = new Class31(-1811821847, 10);
    public readonly Class31 class31_134 = new Class31(-1245697240, 10);
    public readonly Class31 class31_135 = new Class31(0x584ebaf5, 10);
    public readonly Class31 class31_136 = new Class31(0x2f74acf8, 2);
    public readonly Class31 class31_137 = new Class31(-1967122305, 2);
    public readonly Class31 class31_138 = new Class31(0x1fb92e51, 10);
    public readonly Class31 class31_139 = new Class31(-984480955, 2);
    public readonly Class31 class31_140 = new Class31(0x435bbaa4, 10);
    public readonly Class31 class31_141 = new Class31(0x764a2ae7, 10);
    public readonly Class31 class31_142 = new Class31(0x8585fb2, 10);
    public readonly Class31 class31_143 = new Class31(-1185981238, 2);
    public readonly Class31 class31_144 = new Class31(-2102092545, 2);
    public readonly Class31 class31_145 = new Class31(-1936741949, 10);
    public readonly Class31 class31_146 = new Class31(-254935461, 10);
    public readonly Class31 class31_147 = new Class31(-617032759, 10);
    public readonly Class31 class31_148 = new Class31(-1478090996, 10);
    public readonly Class31 class31_149 = new Class31(-448174682, 10);
    public readonly Class31 class31_150 = new Class31(0x2abc50d7, 10);
    public readonly Class31 class31_151 = new Class31(0x13f5b2a1, 11);
    public readonly Class31 class31_152 = new Class31(0x26aec50d, 10);
    public readonly Class31 class31_153 = new Class31(-1016861655, 10);
    public readonly Class31 class31_154 = new Class31(-1294446564, 10);
    public readonly Class31 class31_155 = new Class31(0x7bd74814, 4);
    public readonly Class31 class31_156 = new Class31(0x2385a196, 10);
    public readonly Class31 class31_157 = new Class31(-439264573, 10);
    public readonly Class31 class31_158 = new Class31(-266252196, 10);
    public readonly Class31 class31_159 = new Class31(0x76300a8e, 8);
    public readonly Class31 class31_160 = new Class31(-1719858177, 2);
    public readonly Class31 class31_161 = new Class31(-206734566, 10);
    public readonly Class31 class31_162 = new Class31(-1084480005, 10);
    public readonly Class31 class31_163 = new Class31(0x7a73ac44, 10);
    public readonly Class31 class31_164 = new Class31(0x9be026a, 10);
    public readonly Class31 class31_165 = new Class31(0x23f8a5d6, 10);
    public readonly Class31 class31_166 = new Class31(0x7cda8aef, 10);
    public readonly Class31 class31_167 = new Class31(0x7ea1e90d, 7);
    public readonly Class31 class31_168 = new Class31(0x41f4f8eb, 2);
    public readonly Class31 class31_169 = new Class31(-377357638, 10);
    public readonly Class31 class31_170 = new Class31(-1600894623, 4);
    public readonly Class31 class31_171 = new Class31(-1454472157, 10);
    public readonly Class31 class31_172 = new Class31(0x4a25ed2b, 6);
    public readonly Class31 class31_173 = new Class31(0x77d77e76, 10);
    public readonly Class31 class31_174 = new Class31(-1793565308, 10);
    public readonly Class31 class31_175 = new Class31(0x2b1df0e1, 10);
    public readonly Class31 class31_176 = new Class31(0x7fdced87, 10);
    public readonly Class31 class31_177 = new Class31(-1432866349, 10);
    public readonly Class31 class31_178 = new Class31(-2029481984, 10);
    public readonly Class31 class31_179 = new Class31(0xa43d05d, 9);
    public readonly Class31 class31_180 = new Class31(-1853466064, 2);
    public readonly Class31 class31_181 = new Class31(-1112785331, 2);
    public readonly Class31 class31_182 = new Class31(-1529369506, 10);
    public readonly Class31 class31_183 = new Class31(-2144584300, 10);
    public readonly Class31 class31_184 = new Class31(0x5be75d73, 10);
    public readonly Class31 class31_185 = new Class31(-1206090133, 10);
    public readonly Class31 class31_186 = new Class31(-1443668454, 10);
    public readonly Class31 class31_187 = new Class31(0x8ac804, 10);
    public readonly Class31 class31_188 = new Class31(-54462014, 10);
    public readonly Class31 class31_189 = new Class31(0x16788dc3, 10);
    public readonly Class31 class31_190 = new Class31(-282098288, 2);
    public readonly Class31 class31_191 = new Class31(-1550453778, 2);
    public readonly Class31 class31_192 = new Class31(0x41d31b0b, 10);
    public readonly Class31 class31_193 = new Class31(-1882059562, 10);
    public readonly Class31 class31_194 = new Class31(-756584685, 10);
    public readonly Class31 class31_195 = new Class31(0x5b75dfa, 10);
    public readonly Class31 class31_196 = new Class31(-2514798, 10);
    public readonly Class31 class31_197 = new Class31(0x56ba3d6f, 10);
    public readonly Class31 class31_198 = new Class31(-182697603, 4);
    public readonly Class31 class31_199 = new Class31(0x44dc3d79, 10);
    public readonly Class31 class31_200 = new Class31(-791500484, 10);
    public readonly Class31 class31_201 = new Class31(-1368505744, 9);
    public readonly Class31 class31_202 = new Class31(-1342394088, 10);
    public readonly Class31 class31_203 = new Class31(0x5384d6cc, 5);
    public readonly Class31 class31_204 = new Class31(0x30d652e3, 10);
    public readonly Class31 class31_205 = new Class31(-1972236479, 10);
    public readonly Class31 class31_206 = new Class31(0x3ca59605, 10);
    public readonly Class31 class31_207 = new Class31(0x2c77eaeb, 10);
    public readonly Class31 class31_208 = new Class31(-1621098574, 2);
    public readonly Class31 class31_209 = new Class31(0x100d92ee, 10);
    public readonly Class31 class31_210 = new Class31(-1800455349, 10);
    public readonly Class31 class31_211 = new Class31(-2018197899, 10);
    public readonly Class31 class31_212 = new Class31(0x3e06ec38, 10);
    public readonly Class31 class31_213 = new Class31(-1398465799, 2);

    public IEnumerable<Class31> method_0()
    {
        Class18 class1 = new Class18(-2);
        class1.class16_0 = this;
        return class1;
    }

    public bool method_1()
    {
        return this.bool_0;
    }

    public void method_2(bool bool_1)
    {
        this.bool_0 = bool_1;
    }

    public Class31[] method_3()
    {
        if (this.class31_51 == null)
        {
            Monitor.Enter(this);
            if (this.class31_51 == null)
            {
                List<Class31> list = new List<Class31>(0x100);
                IEnumerator<Class31> enumerator = this.method_0().GetEnumerator();
                while (true)
                {
                    if (!enumerator.MoveNext())
                    {
                        list.Sort(Class17.comparison_0 ?? (Class17.comparison_0 = new Comparison<Class31>(Class17.class17_0.method_0)));
                        this.class31_51 = list.ToArray();
                        break;
                    }
                    Class31 current = enumerator.Current;
                    list.Add(current);
                }
            }
        }
        return this.class31_51;
    }

    [Serializable]
    private sealed class Class17
    {
        public static readonly Class16.Class17 class17_0 = new Class16.Class17();
        public static Comparison<Class31> comparison_0;

        internal int method_0(Class31 class31_0, Class31 class31_1)
        {
            return class31_0.method_0().CompareTo(class31_1.method_0());
        }
    }

    private sealed class Class18 : IEnumerable<Class31>, IEnumerator<Class31>, IEnumerable, IDisposable, IEnumerator
    {
        private int int_0;
        private Class31 class31_0;
        private int int_1;
        public Class16 class16_0;
        private FieldInfo[] fieldInfo_0;
        private int int_2;

        [DebuggerHidden]
        public Class18(int int_3)
        {
            this.int_0 = int_3;
            this.int_1 = Thread.CurrentThread.ManagedThreadId;
        }

        private bool MoveNext()
        {
            int num = this.int_0;
            Class16 class2 = this.class16_0;
            if (num == 0)
            {
                this.int_0 = -1;
                FieldInfo[] fields = typeof(Class16).GetFields(BindingFlags.Public | BindingFlags.Instance | BindingFlags.DeclaredOnly);
                this.fieldInfo_0 = fields;
                this.int_2 = 0;
            }
            else
            {
                if (num != 1)
                {
                    return false;
                }
                this.int_0 = -1;
                this.int_2++;
            }
            if (this.int_2 >= this.fieldInfo_0.Length)
            {
                this.fieldInfo_0 = null;
                return false;
            }
            Class31 class3 = (Class31) this.fieldInfo_0[this.int_2].GetValue(class2);
            this.class31_0 = class3;
            this.int_0 = 1;
            return true;
        }

        [DebuggerHidden]
        IEnumerator<Class31> IEnumerable<Class31>.GetEnumerator()
        {
            Class16.Class18 class2;
            if ((this.int_0 == -2) && (this.int_1 == Thread.CurrentThread.ManagedThreadId))
            {
                this.int_0 = 0;
                class2 = this;
            }
            else
            {
                class2 = new Class16.Class18(0);
                class2.class16_0 = this.class16_0;
            }
            return class2;
        }

        [DebuggerHidden]
        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.System.Collections.Generic.IEnumerable<Class31>.GetEnumerator();
        }

        [DebuggerHidden]
        void IEnumerator.Reset()
        {
            throw new NotSupportedException();
        }

        [DebuggerHidden]
        void IDisposable.Dispose()
        {
        }

        Class31 IEnumerator<Class31>.Current
        {
            [DebuggerHidden]
            get
            {
                return this.class31_0;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return this.class31_0;
            }
        }
    }
}

