﻿using System;

internal interface Interface6
{
    void imethod_0();
    string imethod_1();
    int imethod_2(byte[] byte_0, int int_0);
    int imethod_3(byte[] byte_0);
}

