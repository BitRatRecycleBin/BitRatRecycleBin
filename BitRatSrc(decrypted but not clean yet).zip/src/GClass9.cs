﻿using System;
using System.Collections;
using System.Windows.Forms;

public sealed class GClass9 : IComparer
{
    private SortOrder sortOrder_0;
    private IFormatProvider iformatProvider_0;

    public GClass9();
    public int Compare(object object_0, object object_1);
    public SortOrder method_0();
    public void method_1(SortOrder sortOrder_1);
}

