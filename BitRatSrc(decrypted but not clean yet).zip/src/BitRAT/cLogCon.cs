﻿namespace BitRAT
{
    using System;

    public class cLogCon
    {
        public string[] idxValues;
        public bool bIsAttempt;
        public bool bIsEstablished;
        public bool bIsDC;

        public cLogCon();

        public string HOST { get; set; }

        public string TYPE { get; set; }

        public string ACTION { get; set; }

        public string TIME { get; set; }
    }
}

