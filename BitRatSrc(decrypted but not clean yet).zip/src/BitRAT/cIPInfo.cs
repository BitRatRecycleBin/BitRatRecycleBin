﻿namespace BitRAT
{
    using System;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;
    using System.Windows.Forms;

    public sealed class cIPInfo
    {
        public bool bool_0;

        public cIPInfo();
        public void method_0(Form form_0);
        [MethodImpl(MethodImplOptions.NoOptimization)]
        public void method_1();
        public void method_2();
        public cIPInfo.STRUCT_GEO method_3(string string_0);
        public long method_4(string string_0);

        private delegate void Delegate205();

        [Serializable, StructLayout(LayoutKind.Sequential)]
        public struct STRUCT_GEO
        {
            public string CountryCode;
            public long IPStart;
            public long IPEnd;
        }
    }
}

