﻿namespace BitRAT
{
    using System;

    public class cFWIP
    {
        public string[] idxValues;
        public string Key;
        private string m_tag;

        public cFWIP();

        public string IP { get; set; }

        public string ATTEMPTS { get; set; }

        public string Tag { get; set; }
    }
}

