﻿namespace BitRAT.My
{
    using System;
    using System.CodeDom.Compiler;
    using System.Collections;
    using System.ComponentModel;
    using System.Configuration;
    using System.Diagnostics;
    using System.Runtime.CompilerServices;

    [GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "16.7.0.0"), CompilerGenerated, EditorBrowsable(EditorBrowsableState.Advanced)]
    internal sealed class MySettings : ApplicationSettingsBase
    {
        private static MySettings defaultInstance;
        private static bool addedHandler;
        private static object addedHandlerLockObject;

        static MySettings();
        [EditorBrowsable(EditorBrowsableState.Advanced), DebuggerNonUserCode]
        private static void AutoSaveSettings(object sender, EventArgs e);

        public static MySettings Default { get; }

        [DebuggerNonUserCode, UserScopedSetting, DefaultSettingValue("1234")]
        public int PortMain { get; set; }

        [UserScopedSetting, DefaultSettingValue(""), DebuggerNonUserCode]
        public string HostMainIP { get; set; }

        [UserScopedSetting, DebuggerNonUserCode, DefaultSettingValue("False")]
        public bool AutostartMain { get; set; }

        [UserScopedSetting, DebuggerNonUserCode, DefaultSettingValue("True")]
        public bool ShowGroups { get; set; }

        [DefaultSettingValue("1"), UserScopedSetting, DebuggerNonUserCode]
        public int GroupIndex { get; set; }

        [DefaultSettingValue("True"), DebuggerNonUserCode, UserScopedSetting]
        public bool GroupSubtitles { get; set; }

        [UserScopedSetting, DefaultSettingValue("True"), DebuggerNonUserCode]
        public bool LayoutAutoRefresh { get; set; }

        [DefaultSettingValue("URL to plugin: http://site.com/xmr.plg"), DebuggerNonUserCode, UserScopedSetting]
        public string PluginsURLXMR { get; set; }

        [UserScopedSetting, DefaultSettingValue("URL to plugin: http://site.com/pws.plg"), DebuggerNonUserCode]
        public string PluginsURLPws { get; set; }

        [UserScopedSetting, DebuggerNonUserCode, DefaultSettingValue("8192")]
        public int TransfersRecvBytes { get; set; }

        [DefaultSettingValue("8192"), DebuggerNonUserCode, UserScopedSetting]
        public int TransfersSendBytes { get; set; }

        [DebuggerNonUserCode, DefaultSettingValue("True"), UserScopedSetting]
        public bool PreviewEnabled { get; set; }

        [UserScopedSetting, DebuggerNonUserCode, DefaultSettingValue("True")]
        public bool PreviewSourceScreen { get; set; }

        [DefaultSettingValue("False"), DebuggerNonUserCode, UserScopedSetting]
        public bool PreviewSourceWebcam { get; set; }

        [DefaultSettingValue("1"), UserScopedSetting, DebuggerNonUserCode]
        public int PreviewUpdateInterval { get; set; }

        [DefaultSettingValue("30"), DebuggerNonUserCode, UserScopedSetting]
        public int PreviewQuality { get; set; }

        [DefaultSettingValue("380"), UserScopedSetting, DebuggerNonUserCode]
        public int PreviewDefaultX { get; set; }

        [UserScopedSetting, DebuggerNonUserCode, DefaultSettingValue("237")]
        public int PreviewDefaultY { get; set; }

        [DebuggerNonUserCode, UserScopedSetting, DefaultSettingValue("760")]
        public int PreviewDoubleClickX { get; set; }

        [DefaultSettingValue("475"), DebuggerNonUserCode, UserScopedSetting]
        public int PreviewDoubleClickY { get; set; }

        [DebuggerNonUserCode, DefaultSettingValue("100"), UserScopedSetting]
        public int PreviewDefaultSize { get; set; }

        [DebuggerNonUserCode, UserScopedSetting, DefaultSettingValue("100")]
        public int PreviewDoubleClickSize { get; set; }

        [UserScopedSetting, DebuggerNonUserCode, DefaultSettingValue("True")]
        public bool PreviewDisplayFrameData { get; set; }

        [DefaultSettingValue("True"), UserScopedSetting, DebuggerNonUserCode]
        public bool PreviewTransparentFrames { get; set; }

        [DefaultSettingValue("True"), DebuggerNonUserCode, UserScopedSetting]
        public bool PluginsUpload { get; set; }

        [DefaultSettingValue(""), UserScopedSetting, DebuggerNonUserCode]
        public string NetworkBandwidth { get; set; }

        [DefaultSettingValue(""), DebuggerNonUserCode, UserScopedSetting]
        public string Password { get; set; }

        [UserScopedSetting, DebuggerNonUserCode, DefaultSettingValue("URL to plugin: http://site.com/loader.plg")]
        public string PluginsURLLoader { get; set; }

        [DefaultSettingValue("URL to plugin: http://site.com/xmr64.plg"), UserScopedSetting, DebuggerNonUserCode]
        public string PluginsURLXMR64 { get; set; }

        [UserScopedSetting, DefaultSettingValue("1235"), DebuggerNonUserCode]
        public int PortTor { get; set; }

        [DefaultSettingValue(""), DebuggerNonUserCode, UserScopedSetting]
        public string HostTorIP { get; set; }

        [DebuggerNonUserCode, DefaultSettingValue("False"), UserScopedSetting]
        public bool AutostartTor { get; set; }

        [DebuggerNonUserCode, UserScopedSetting, DefaultSettingValue("5")]
        public int TransfersConcurrentMax { get; set; }

        [DebuggerNonUserCode, DefaultSettingValue(""), UserScopedSetting]
        public string TorConfigUsername { get; set; }

        [DebuggerNonUserCode, UserScopedSetting, DefaultSettingValue("False")]
        public bool TorConfigAutostart { get; set; }

        [DefaultSettingValue("True"), DebuggerNonUserCode, UserScopedSetting]
        public bool ShowGroupsTransfers { get; set; }

        [UserScopedSetting, DebuggerNonUserCode, DefaultSettingValue("True")]
        public bool GroupSubtitlesTransfers { get; set; }

        [UserScopedSetting, DebuggerNonUserCode, DefaultSettingValue("True")]
        public bool GroupSortingTransfersDir { get; set; }

        [UserScopedSetting, DebuggerNonUserCode, DefaultSettingValue("False")]
        public bool GroupSortingTransfersUser { get; set; }

        [UserScopedSetting, DebuggerNonUserCode, DefaultSettingValue("0")]
        public int MaxBandwidthRateIn { get; set; }

        [DebuggerNonUserCode, DefaultSettingValue("0"), UserScopedSetting]
        public int MaxBandwidthRateOut { get; set; }

        [DebuggerNonUserCode, UserScopedSetting, DefaultSettingValue("True")]
        public bool TransferReplaceExisting { get; set; }

        [DefaultSettingValue("True"), UserScopedSetting, DebuggerNonUserCode]
        public bool TransferReplaceFilesModified { get; set; }

        [DebuggerNonUserCode, DefaultSettingValue("True"), UserScopedSetting]
        public bool TransferReplaceFilesAll { get; set; }

        [DebuggerNonUserCode, DefaultSettingValue("True"), UserScopedSetting]
        public bool ConNotifications { get; set; }

        [UserScopedSetting, DebuggerNonUserCode, DefaultSettingValue("False")]
        public bool Gridlines { get; set; }

        [DebuggerNonUserCode, DefaultSettingValue("True"), UserScopedSetting]
        public bool ConKlgColors { get; set; }

        [DebuggerNonUserCode, UserScopedSetting, DefaultSettingValue("True")]
        public bool TorDisableCaching { get; set; }

        [UserScopedSetting, DefaultSettingValue("True"), DebuggerNonUserCode]
        public bool TorAvoidDiskWrites { get; set; }

        [DebuggerNonUserCode, UserScopedSetting, DefaultSettingValue("True")]
        public bool TorRejectSingleHop { get; set; }

        [UserScopedSetting, DefaultSettingValue("True"), DebuggerNonUserCode]
        public bool TorNoExec { get; set; }

        [DefaultSettingValue("False"), DebuggerNonUserCode, UserScopedSetting]
        public bool TorUseConstrainedSockets { get; set; }

        [DebuggerNonUserCode, DefaultSettingValue("8192"), UserScopedSetting]
        public string TorConstrainedSocketSize { get; set; }

        [DefaultSettingValue("True"), DebuggerNonUserCode, UserScopedSetting]
        public bool ConLogColors { get; set; }

        [DefaultSettingValue("1"), UserScopedSetting, DebuggerNonUserCode]
        public int LayoutTheme { get; set; }

        [DebuggerNonUserCode, DefaultSettingValue(""), UserScopedSetting]
        public string BuilderHost { get; set; }

        [DefaultSettingValue(""), DebuggerNonUserCode, UserScopedSetting]
        public string BuilderPort { get; set; }

        [DebuggerNonUserCode, DefaultSettingValue(""), UserScopedSetting]
        public string BuilderPass { get; set; }

        [DefaultSettingValue(""), UserScopedSetting, DebuggerNonUserCode]
        public string BuilderTorPrcname { get; set; }

        [DefaultSettingValue(""), UserScopedSetting, DebuggerNonUserCode]
        public string BuilderFilename { get; set; }

        [DebuggerNonUserCode, UserScopedSetting, DefaultSettingValue("")]
        public string BuilderInstallFolder { get; set; }

        [UserScopedSetting, DefaultSettingValue("True"), DebuggerNonUserCode]
        public bool BuilderTLS { get; set; }

        [DebuggerNonUserCode, UserScopedSetting]
        public ArrayList OnJoinCommands { get; set; }

        [DefaultSettingValue("True"), DebuggerNonUserCode, UserScopedSetting]
        public bool SettingsTray { get; set; }

        [UserScopedSetting, DebuggerNonUserCode, DefaultSettingValue("False")]
        public bool PluginsSavePws { get; set; }

        [DebuggerNonUserCode, UserScopedSetting, DefaultSettingValue("False")]
        public bool UIThumbnails { get; set; }
    }
}

