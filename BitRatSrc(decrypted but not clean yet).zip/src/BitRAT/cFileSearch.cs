﻿namespace BitRAT
{
    using System;

    public class cFileSearch
    {
        public string NAME;
        public string PATH;
        public string TYPE;
        public string SIZE;
        public string ATTR;
        public string LMOD;
        public string STATUS;
        public string TAG;

        public cFileSearch(string sName, string sPath, string sType, string sSize, string sAttr, string sLmod, string sStatus);
    }
}

