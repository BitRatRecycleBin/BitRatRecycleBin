﻿namespace BitRAT
{
    using System;

    public class cDOScli
    {
        public string[] idxValues;
        public string Key;
        private string m_tag;
        public long speed_bytes;
        public long sent_bytes;
        public bool bJustConnected;
        public bool pending_dc;
        public bool pending_dc_timeout;

        public cDOScli();

        public string USER { get; set; }

        public string TARGET_HOST { get; set; }

        public string TARGET_PORT { get; set; }

        public string PROTOCOL { get; set; }

        public string METHOD { get; set; }

        public string THREADS { get; set; }

        public string BYTES_SENT { get; set; }

        public string SPEED { get; set; }

        public string PPS { get; set; }

        public string INTENSITY { get; set; }

        public string PACKET_SIZE { get; set; }

        public string DURATION { get; set; }

        public string STATUS { get; set; }

        public string Tag { get; set; }
    }
}

