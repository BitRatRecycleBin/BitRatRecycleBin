﻿using System;

internal sealed class Class68
{
    private int int_0;
    private bool bool_0;

    public int method_0()
    {
        return this.int_0;
    }

    public void method_1(int int_1)
    {
        this.int_0 = int_1;
    }

    public bool method_2()
    {
        return this.bool_0;
    }

    public void method_3(bool bool_1)
    {
        this.bool_0 = bool_1;
    }
}

