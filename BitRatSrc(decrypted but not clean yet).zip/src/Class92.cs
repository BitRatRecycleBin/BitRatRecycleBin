﻿using System;
using System.Security.Cryptography;

internal sealed class Class92 : Class91
{
    private ICryptoTransform icryptoTransform_0;

    public Class92(ICryptoTransform icryptoTransform_1)
    {
        this.icryptoTransform_0 = icryptoTransform_1;
    }

    public override void Dispose()
    {
        this.icryptoTransform_0.Dispose();
    }

    public override bool vmethod_0()
    {
        return this.icryptoTransform_0.CanReuseTransform;
    }

    public override int vmethod_1()
    {
        return this.icryptoTransform_0.InputBlockSize;
    }

    public override int vmethod_2(byte[] byte_0, int int_0, int int_1, byte[] byte_1, int int_2)
    {
        return this.icryptoTransform_0.TransformBlock(byte_0, int_0, int_1, byte_1, int_2);
    }

    public override byte[] vmethod_3(byte[] byte_0, int int_0, int int_1)
    {
        return this.icryptoTransform_0.TransformFinalBlock(byte_0, int_0, int_1);
    }
}

