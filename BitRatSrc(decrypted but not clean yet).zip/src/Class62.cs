﻿using System;

internal sealed class Class62
{
    public Class0 class0_0;
}

