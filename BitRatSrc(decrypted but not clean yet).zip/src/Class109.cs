﻿using System;

internal abstract class Class109 : Class106
{
    private Type type_1;

    protected Class109()
    {
    }

    public Type method_2()
    {
        return this.type_1;
    }

    public void method_3(Type type_2)
    {
        this.type_1 = type_2;
    }

    public abstract object vmethod_5();
    public abstract void vmethod_6(object object_0);
    public abstract bool vmethod_7(Class109 class109_0);
}

