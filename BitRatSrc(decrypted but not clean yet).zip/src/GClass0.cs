﻿using System;

public sealed class GClass0
{
}

