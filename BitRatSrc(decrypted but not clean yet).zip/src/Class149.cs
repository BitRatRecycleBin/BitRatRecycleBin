﻿using System;
using System.IO;
using System.Runtime.CompilerServices;

internal static class Class149
{
    private static Class16 class16_0;
    [ThreadStatic]
    private static Stream stream_0;

    [MethodImpl(MethodImplOptions.Synchronized)]
    public static Class4 smethod_0();
    public static Stream smethod_1();
}

