﻿using System;

internal sealed class Class15 : Class14
{
    private readonly Interface6 interface6_0;

    public Class15(Interface0 interface0_1) : this(interface0_1, new Class89())
    {
    }

    public Class15(Interface0 interface0_1, Interface6 interface6_1)
    {
        base.interface0_0 = interface0_1;
        this.interface6_0 = interface6_1;
        base.byte_1 = new byte[interface0_1.imethod_2()];
        base.int_0 = 0;
    }

    public override void imethod_1(bool bool_1, Interface2 interface2_0)
    {
        base.bool_0 = bool_1;
        this.imethod_15();
        this.interface6_0.imethod_0();
        base.interface0_0.imethod_1(bool_1, interface2_0);
    }

    public override int imethod_12(byte[] byte_2, int int_1)
    {
        int num = base.interface0_0.imethod_2();
        int length = 0;
        if (!base.bool_0)
        {
            if (base.int_0 != num)
            {
                this.imethod_15();
                throw new Exception1("last block incomplete in decryption");
            }
            length = base.interface0_0.imethod_4(base.byte_1, 0, base.byte_1, 0);
            base.int_0 = 0;
            length -= this.interface6_0.imethod_3(base.byte_1);
            Array.Copy(base.byte_1, 0, byte_2, int_1, length);
        }
        else
        {
            if (base.int_0 == num)
            {
                if ((int_1 + (2 * num)) > byte_2.Length)
                {
                    this.imethod_15();
                    throw new Exception1("output buffer too short");
                }
                length = base.interface0_0.imethod_4(base.byte_1, 0, byte_2, int_1);
                base.int_0 = 0;
            }
            this.interface6_0.imethod_2(base.byte_1, base.int_0);
            length += base.interface0_0.imethod_4(base.byte_1, 0, byte_2, int_1 + length);
            this.imethod_15();
        }
        return length;
    }

    public override int imethod_3(int int_1)
    {
        int num = int_1 + base.int_0;
        int num2 = num % base.byte_1.Length;
        return ((num2 != 0) ? ((num - num2) + base.byte_1.Length) : (!base.bool_0 ? num : (num + base.byte_1.Length)));
    }

    public override int imethod_4(int int_1)
    {
        int num = int_1 + base.int_0;
        int num2 = num % base.byte_1.Length;
        return ((num2 != 0) ? (num - num2) : (num - base.byte_1.Length));
    }

    public override int imethod_8(byte[] byte_2, int int_1, int int_2, byte[] byte_3, int int_3)
    {
        if (int_2 < 0)
        {
            throw new ArgumentException("Can't have a negative input length!");
        }
        int num = this.imethod_2();
        int num2 = this.imethod_4(int_2);
        if ((num2 > 0) && ((int_3 + num2) > byte_3.Length))
        {
            throw new Exception1("output buffer too short");
        }
        int num3 = 0;
        int length = base.byte_1.Length - base.int_0;
        if (int_2 > length)
        {
            Array.Copy(byte_2, int_1, base.byte_1, base.int_0, length);
            num3 += base.interface0_0.imethod_4(base.byte_1, 0, byte_3, int_3);
            base.int_0 = 0;
            int_2 -= length;
            int_1 += length;
            while (int_2 > base.byte_1.Length)
            {
                num3 += base.interface0_0.imethod_4(byte_2, int_1, byte_3, int_3 + num3);
                int_2 -= num;
                int_1 += num;
            }
        }
        Array.Copy(byte_2, int_1, base.byte_1, base.int_0, int_2);
        base.int_0 += int_2;
        return num3;
    }
}

