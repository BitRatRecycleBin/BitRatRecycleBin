﻿using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using VisualPlus.Enumerators;
using VisualPlus.Toolkit.Controls.Interactivity;

[DesignerGenerated]
public sealed class fRegAdd : Form
{
    private IContainer icontainer_0;
    private TextBox textBox_0;
    private Label label_0;
    private Label label_1;
    private ComboBox comboBox_0;
    private Label label_2;
    private TextBox textBox_1;
    private VisualButton visualButton_0;
    private StatusStrip statusStrip_0;
    private ToolStripStatusLabel toolStripStatusLabel_0;
    private Timer timer_0;
    public string string_0;
    public string string_1;

    public fRegAdd()
    {
        base.Load += new EventHandler(this.fRegAdd_Load);
        base.Closing += new CancelEventHandler(this.fRegAdd_Closing);
        this.InitializeComponent();
    }

    [DebuggerNonUserCode]
    protected override void Dispose(bool disposing)
    {
        if (disposing && (this.icontainer_0 != null))
        {
            this.icontainer_0.Dispose();
        }
    }

    private void fRegAdd_Closing(object sender, CancelEventArgs e)
    {
        base.Visible = false;
        e.Cancel = true;
    }

    private void fRegAdd_Load(object sender, EventArgs e)
    {
        this.vmethod_6().Items.Add("REG_NONE");
        this.vmethod_6().Items.Add("REG_SZ");
        this.vmethod_6().Items.Add("REG_EXPAND_SZ");
        this.vmethod_6().Items.Add("REG_BINARY");
        this.vmethod_6().Items.Add("REG_DWORD");
        this.vmethod_6().Items.Add("REG_DWORD_BIG_ENDIAN");
        this.vmethod_6().Items.Add("REG_LINK");
        this.vmethod_6().Items.Add("REG_MULTI_SZ");
        this.vmethod_6().Items.Add("REG_RESOURCE_LIST");
        this.vmethod_6().Items.Add("REG_FULL_RESOURCE_DESCRIPTOR");
        this.vmethod_6().Items.Add("REG_RESOURCE_REQUIREMENTS_LIST");
        this.vmethod_6().Items.Add("REG_QWORD");
        this.vmethod_6().SelectedItem = this.vmethod_6().Items[1];
    }

    [DebuggerStepThrough]
    private void InitializeComponent()
    {
        this.icontainer_0 = new Container();
        this.vmethod_1(new TextBox());
        this.vmethod_3(new Label());
        this.vmethod_5(new Label());
        this.vmethod_7(new ComboBox());
        this.vmethod_9(new Label());
        this.vmethod_11(new TextBox());
        this.vmethod_13(new VisualButton());
        this.vmethod_15(new StatusStrip());
        this.vmethod_17(new ToolStripStatusLabel());
        this.vmethod_19(new Timer(this.icontainer_0));
        this.vmethod_14().SuspendLayout();
        base.SuspendLayout();
        this.vmethod_0().Location = new Point(0x4e, 6);
        this.vmethod_0().Margin = new Padding(1);
        this.vmethod_0().MaxLength = 0xff;
        this.vmethod_0().Name = "txtValueName";
        this.vmethod_0().Size = new Size(0xdf, 20);
        this.vmethod_0().TabIndex = 0x13;
        this.vmethod_2().AutoSize = true;
        this.vmethod_2().BackColor = Color.Transparent;
        this.vmethod_2().FlatStyle = FlatStyle.Flat;
        this.vmethod_2().Location = new Point(10, 9);
        this.vmethod_2().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_2().Name = "lblValueName";
        this.vmethod_2().Size = new Size(0x42, 13);
        this.vmethod_2().TabIndex = 0x12;
        this.vmethod_2().Text = "Value name:";
        this.vmethod_2().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_4().AutoSize = true;
        this.vmethod_4().BackColor = Color.Transparent;
        this.vmethod_4().FlatStyle = FlatStyle.Flat;
        this.vmethod_4().Location = new Point(0x12f, 9);
        this.vmethod_4().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_4().Name = "lblValueType";
        this.vmethod_4().Size = new Size(60, 13);
        this.vmethod_4().TabIndex = 20;
        this.vmethod_4().Text = "Value type:";
        this.vmethod_4().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_6().BackColor = Color.White;
        this.vmethod_6().DropDownStyle = ComboBoxStyle.DropDownList;
        this.vmethod_6().ForeColor = Color.Black;
        this.vmethod_6().FormattingEnabled = true;
        this.vmethod_6().ImeMode = ImeMode.NoControl;
        this.vmethod_6().Location = new Point(0x16e, 6);
        this.vmethod_6().Margin = new Padding(2);
        this.vmethod_6().Name = "cbValueType";
        this.vmethod_6().Size = new Size(0xad, 0x15);
        this.vmethod_6().TabIndex = 0x2e;
        this.vmethod_6().TabStop = false;
        this.vmethod_8().AutoSize = true;
        this.vmethod_8().BackColor = Color.Transparent;
        this.vmethod_8().FlatStyle = FlatStyle.Flat;
        this.vmethod_8().Location = new Point(15, 0x29);
        this.vmethod_8().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_8().Name = "lblValueData";
        this.vmethod_8().Size = new Size(0x3d, 13);
        this.vmethod_8().TabIndex = 0x2f;
        this.vmethod_8().Text = "Value data:";
        this.vmethod_8().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_10().Location = new Point(0x4e, 0x29);
        this.vmethod_10().MaxLength = 0x3fff;
        this.vmethod_10().Multiline = true;
        this.vmethod_10().Name = "txtValueData";
        this.vmethod_10().Size = new Size(0x1cd, 0x5b);
        this.vmethod_10().TabIndex = 0x30;
        this.vmethod_12().Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
        this.vmethod_12().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_12().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_12().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_12().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_12().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_12().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_12().Border.HoverVisible = true;
        this.vmethod_12().Border.Rounding = 6;
        this.vmethod_12().Border.Thickness = 1;
        this.vmethod_12().Border.Type = ShapeTypes.Rounded;
        this.vmethod_12().Border.Visible = true;
        this.vmethod_12().DialogResult = DialogResult.None;
        this.vmethod_12().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_12().Image = null;
        this.vmethod_12().Location = new Point(0x1d7, 0x8a);
        this.vmethod_12().MouseState = MouseStates.Normal;
        this.vmethod_12().Name = "btnAdd";
        this.vmethod_12().Size = new Size(0x44, 0x13);
        this.vmethod_12().TabIndex = 0x31;
        this.vmethod_12().Text = "Add";
        this.vmethod_12().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_12().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_12().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_12().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_12().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_12().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_12().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_12().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_14().AutoSize = false;
        this.vmethod_14().BackColor = Color.FromArgb(0xeb, 0xed, 0xef);
        this.vmethod_14().ImageScalingSize = new Size(0x1c, 0x1c);
        ToolStripItem[] toolStripItems = new ToolStripItem[] { this.vmethod_16() };
        this.vmethod_14().Items.AddRange(toolStripItems);
        this.vmethod_14().Location = new Point(0, 0xa1);
        this.vmethod_14().Name = "ssStatus";
        this.vmethod_14().Padding = new Padding(1, 0, 7, 0);
        this.vmethod_14().Size = new Size(0x21d, 0x13);
        this.vmethod_14().SizingGrip = false;
        this.vmethod_14().Stretch = false;
        this.vmethod_14().TabIndex = 50;
        this.vmethod_14().Text = "stStatus";
        this.vmethod_16().AutoSize = false;
        this.vmethod_16().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_16().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_16().Margin = new Padding(0, 3, -6, 0);
        this.vmethod_16().Name = "tsPath";
        this.vmethod_16().Size = new Size(0x21b, 0x10);
        this.vmethod_16().Spring = true;
        this.vmethod_16().Text = "Path: N/A";
        this.vmethod_16().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_18().Enabled = true;
        base.AutoScaleDimensions = new SizeF(6f, 13f);
        base.AutoScaleMode = AutoScaleMode.Font;
        this.BackColor = SystemColors.AppWorkspace;
        base.ClientSize = new Size(0x21d, 180);
        base.Controls.Add(this.vmethod_14());
        base.Controls.Add(this.vmethod_12());
        base.Controls.Add(this.vmethod_10());
        base.Controls.Add(this.vmethod_8());
        base.Controls.Add(this.vmethod_6());
        base.Controls.Add(this.vmethod_4());
        base.Controls.Add(this.vmethod_0());
        base.Controls.Add(this.vmethod_2());
        this.DoubleBuffered = true;
        base.FormBorderStyle = FormBorderStyle.FixedToolWindow;
        base.MaximizeBox = false;
        base.MinimizeBox = false;
        base.Name = "fRegAdd";
        base.Opacity = 0.0;
        base.ShowIcon = false;
        base.StartPosition = FormStartPosition.CenterParent;
        this.Text = "Registry - Add value";
        base.TopMost = true;
        this.vmethod_14().ResumeLayout(false);
        this.vmethod_14().PerformLayout();
        base.ResumeLayout(false);
        base.PerformLayout();
    }

    private void method_0(object sender, EventArgs e)
    {
        string str = "REG_SZ";
        string left = this.vmethod_6().SelectedItem.ToString();
        if (Operators.CompareString(left, "REG_NONE", true) == 0)
        {
            str = "0";
        }
        else if (Operators.CompareString(left, "REG_SZ", true) == 0)
        {
            str = "1";
        }
        else if (Operators.CompareString(left, "REG_EXPAND_SZ", true) == 0)
        {
            str = "2";
        }
        else if (Operators.CompareString(left, "REG_BINARY", true) == 0)
        {
            str = "3";
        }
        else if (Operators.CompareString(left, "REG_DWORD", true) == 0)
        {
            str = "4";
        }
        else if (Operators.CompareString(left, "REG_DWORD_BIG_ENDIAN", true) == 0)
        {
            str = "5";
        }
        else if (Operators.CompareString(left, "REG_LINK", true) == 0)
        {
            str = "6";
        }
        else if (Operators.CompareString(left, "REG_MULTI_SZ", true) == 0)
        {
            str = "7";
        }
        else if (Operators.CompareString(left, "REG_RESOURCE_LIST", true) == 0)
        {
            str = "8";
        }
        else if (Operators.CompareString(left, "REG_FULL_RESOURCE_DESCRIPTOR", true) == 0)
        {
            str = "9";
        }
        else if (Operators.CompareString(left, "REG_RESOURCE_REQUIREMENTS_LIST", true) == 0)
        {
            str = "10";
        }
        else if (Operators.CompareString(left, "REG_QWORD", true) == 0)
        {
            str = "11";
        }
        if (this.vmethod_0().TextLength == 0)
        {
            Interaction.MsgBox("Invalid value name!", MsgBoxStyle.Exclamation, Application.ProductName);
        }
        else if (this.vmethod_10().TextLength == 0)
        {
            Interaction.MsgBox("Invalid value data!", MsgBoxStyle.Exclamation, Application.ProductName);
        }
        else
        {
            this.vmethod_12().Enabled = false;
            string[] textArray1 = new string[] { "reg_val_edit|", this.string_1, "|", Convert.ToBase64String(Encoding.UTF8.GetBytes(this.vmethod_0().Text)), "|", str, "|", Convert.ToBase64String(Encoding.UTF8.GetBytes(this.vmethod_10().Text)) };
            Class136.Class138 class2 = new Class136.Class138();
            class2.string_0 = this.string_0;
            class2.string_1 = string.Concat(textArray1);
            class2.long_0 = 0L;
            try
            {
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
            }
            catch (Exception exception1)
            {
                Exception ex = exception1;
                ProjectData.SetProjectError(ex);
                Exception local2 = ex;
                ProjectData.ClearProjectError();
            }
        }
    }

    private void method_1(object sender, EventArgs e)
    {
        if (Strings.InStr(this.string_1, "-2147483648", CompareMethod.Text) != 0)
        {
            this.vmethod_16().Text = "Path: " + Strings.Replace(this.string_1, "-2147483648", "HKEY_CLASSES_ROOT", 1, -1, CompareMethod.Text);
        }
        if (Strings.InStr(this.string_1, "-2147483647", CompareMethod.Text) != 0)
        {
            this.vmethod_16().Text = "Path: " + Strings.Replace(this.string_1, "-2147483647", "HKEY_CURRENT_USER", 1, -1, CompareMethod.Text);
        }
        if (Strings.InStr(this.string_1, "-2147483646", CompareMethod.Text) != 0)
        {
            this.vmethod_16().Text = "Path: " + Strings.Replace(this.string_1, "-2147483646", "HKEY_LOCAL_MACHINE", 1, -1, CompareMethod.Text);
        }
        if (Strings.InStr(this.string_1, "-2147483645", CompareMethod.Text) != 0)
        {
            this.vmethod_16().Text = "Path: " + Strings.Replace(this.string_1, "-2147483645", "HKEY_USERS", 1, -1, CompareMethod.Text);
        }
        if (Strings.InStr(this.string_1, "-2147483643", CompareMethod.Text) != 0)
        {
            this.vmethod_16().Text = "Path: " + Strings.Replace(this.string_1, "-2147483643", "HKEY_CURRENT_CONFIG", 1, -1, CompareMethod.Text);
        }
    }

    internal virtual TextBox vmethod_0()
    {
        return this.textBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_1(TextBox textBox_2)
    {
        this.textBox_0 = textBox_2;
    }

    internal virtual TextBox vmethod_10()
    {
        return this.textBox_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_11(TextBox textBox_2)
    {
        this.textBox_1 = textBox_2;
    }

    internal virtual VisualButton vmethod_12()
    {
        return this.visualButton_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_13(VisualButton visualButton_1)
    {
        EventHandler handler = new EventHandler(this.method_0);
        VisualButton button = this.visualButton_0;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_0 = visualButton_1;
        button = this.visualButton_0;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual StatusStrip vmethod_14()
    {
        return this.statusStrip_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_15(StatusStrip statusStrip_1)
    {
        this.statusStrip_0 = statusStrip_1;
    }

    internal virtual ToolStripStatusLabel vmethod_16()
    {
        return this.toolStripStatusLabel_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_17(ToolStripStatusLabel toolStripStatusLabel_1)
    {
        this.toolStripStatusLabel_0 = toolStripStatusLabel_1;
    }

    internal virtual Timer vmethod_18()
    {
        return this.timer_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_19(Timer timer_1)
    {
        EventHandler handler = new EventHandler(this.method_1);
        Timer timer = this.timer_0;
        if (timer != null)
        {
            timer.Tick -= handler;
        }
        this.timer_0 = timer_1;
        timer = this.timer_0;
        if (timer != null)
        {
            timer.Tick += handler;
        }
    }

    internal virtual Label vmethod_2()
    {
        return this.label_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_3(Label label_3)
    {
        this.label_0 = label_3;
    }

    internal virtual Label vmethod_4()
    {
        return this.label_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_5(Label label_3)
    {
        this.label_1 = label_3;
    }

    internal virtual ComboBox vmethod_6()
    {
        return this.comboBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_7(ComboBox comboBox_1)
    {
        this.comboBox_0 = comboBox_1;
    }

    internal virtual Label vmethod_8()
    {
        return this.label_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_9(Label label_3)
    {
        this.label_2 = label_3;
    }
}

