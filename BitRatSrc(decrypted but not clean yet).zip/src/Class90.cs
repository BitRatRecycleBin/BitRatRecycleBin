﻿using System;

internal sealed class Class90 : Interface0
{
    private byte[] byte_0;
    private byte[] byte_1;
    private byte[] byte_2;
    private int int_0;
    private Interface0 interface0_0;
    private bool bool_0;

    public Class90(Interface0 interface0_1)
    {
        this.interface0_0 = interface0_1;
        this.int_0 = interface0_1.imethod_2();
        this.byte_0 = new byte[this.int_0];
        this.byte_1 = new byte[this.int_0];
        this.byte_2 = new byte[this.int_0];
    }

    public string imethod_0()
    {
        return (this.interface0_0.imethod_0() + "/CBC");
    }

    public void imethod_1(bool bool_1, Interface2 interface2_0)
    {
        this.bool_0 = bool_1;
        if (interface2_0 is Class38)
        {
            Class38 class1 = (Class38) interface2_0;
            byte[] sourceArray = class1.method_0();
            if (sourceArray.Length != this.int_0)
            {
                throw new ArgumentException("initialisation vector must be the same length as block size");
            }
            Array.Copy(sourceArray, 0, this.byte_0, 0, sourceArray.Length);
            interface2_0 = class1.method_1();
        }
        this.imethod_5();
        this.interface0_0.imethod_1(this.bool_0, interface2_0);
    }

    public int imethod_2()
    {
        return this.interface0_0.imethod_2();
    }

    public bool imethod_3()
    {
        return false;
    }

    public int imethod_4(byte[] byte_3, int int_1, byte[] byte_4, int int_2)
    {
        return (this.bool_0 ? this.method_1(byte_3, int_1, byte_4, int_2) : this.method_2(byte_3, int_1, byte_4, int_2));
    }

    public void imethod_5()
    {
        Array.Copy(this.byte_0, 0, this.byte_1, 0, this.byte_0.Length);
        Array.Clear(this.byte_2, 0, this.byte_2.Length);
        this.interface0_0.imethod_5();
    }

    public Interface0 method_0()
    {
        return this.interface0_0;
    }

    private unsafe int method_1(byte[] byte_3, int int_1, byte[] byte_4, int int_2)
    {
        if ((int_1 + this.int_0) > byte_3.Length)
        {
            throw new Exception1("input buffer too short");
        }
        for (int i = 0; i < this.int_0; i++)
        {
            byte* numPtr1 = &(this.byte_1[i]);
            numPtr1[0] = (byte) (numPtr1[0] ^ byte_3[int_1 + i]);
        }
        Array.Copy(byte_4, int_2, this.byte_1, 0, this.byte_1.Length);
        return this.interface0_0.imethod_4(this.byte_1, 0, byte_4, int_2);
    }

    private unsafe int method_2(byte[] byte_3, int int_1, byte[] byte_4, int int_2)
    {
        if ((int_1 + this.int_0) > byte_3.Length)
        {
            throw new Exception1("input buffer too short");
        }
        Array.Copy(byte_3, int_1, this.byte_2, 0, this.int_0);
        int num = this.interface0_0.imethod_4(byte_3, int_1, byte_4, int_2);
        for (int i = 0; i < this.int_0; i++)
        {
            byte* numPtr1 = &(byte_4[int_2 + i]);
            numPtr1[0] = (byte) (numPtr1[0] ^ this.byte_1[i]);
        }
        byte[] buffer = this.byte_1;
        this.byte_1 = this.byte_2;
        this.byte_2 = buffer;
        return num;
    }
}

