﻿using System;
using System.ComponentModel;
using System.Diagnostics;

internal static class Class57
{
    [STAThread, DebuggerHidden, EditorBrowsable(EditorBrowsableState.Advanced)]
    private static void Main(string[] args)
    {
        Form0.smethod_0(args);
    }
}

