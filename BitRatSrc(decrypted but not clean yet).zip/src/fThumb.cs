﻿using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Zeroit.Framework.Progress;

[DesignerGenerated]
public sealed class fThumb : Form
{
    private IContainer icontainer_0;
    private PictureBox pictureBox_0;
    private Timer timer_0;
    private Timer timer_1;
    private ZeroitWin8ProgressRing zeroitWin8ProgressRing_0;
    private Label label_0;
    private Timer timer_2;
    private Label label_1;
    public string string_0;
    public string string_1;
    public string string_2;
    public string string_3;
    public string string_4;
    public Point point_0;
    private long long_0;
    private long long_1;

    public fThumb()
    {
        base.Load += new EventHandler(this.fThumb_Load);
        this.InitializeComponent();
    }

    [DebuggerNonUserCode]
    protected override void Dispose(bool disposing)
    {
        if (disposing && (this.icontainer_0 != null))
        {
            this.icontainer_0.Dispose();
        }
    }

    private void fThumb_Load(object sender, EventArgs e)
    {
        base.Visible = false;
        base.Width = (int) Math.Round(Conversion.Val(Class130.fSettings_0.vmethod_92().Text));
        base.Height = (int) Math.Round(Conversion.Val(Class130.fSettings_0.vmethod_86().Text));
        this.vmethod_6().set_Animate(false);
        this.method_3();
    }

    [DebuggerStepThrough]
    private void InitializeComponent()
    {
        this.icontainer_0 = new Container();
        this.vmethod_3(new Timer(this.icontainer_0));
        this.vmethod_5(new Timer(this.icontainer_0));
        this.vmethod_7(new ZeroitWin8ProgressRing());
        this.vmethod_1(new PictureBox());
        this.vmethod_9(new Label());
        this.vmethod_11(new Timer(this.icontainer_0));
        this.vmethod_13(new Label());
        ((ISupportInitialize) this.vmethod_0()).BeginInit();
        base.SuspendLayout();
        this.vmethod_2().Interval = 1;
        this.vmethod_4().Interval = 1;
        this.vmethod_6().set_Animate(false);
        this.vmethod_6().BackColor = Color.Transparent;
        this.vmethod_6().set_ControlHeight(80);
        this.vmethod_6().Location = new Point(0x3a, 0x25);
        this.vmethod_6().Margin = new Padding(2);
        this.vmethod_6().Name = "ziLoader";
        this.vmethod_6().set_RefreshRate(100);
        this.vmethod_6().Size = new Size(80, 80);
        this.vmethod_6().TabIndex = 0x1f;
        this.vmethod_0().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
        this.vmethod_0().BorderStyle = BorderStyle.FixedSingle;
        this.vmethod_0().Location = new Point(0, 0);
        this.vmethod_0().Margin = new Padding(2);
        this.vmethod_0().Name = "pbThumb";
        this.vmethod_0().Size = new Size(0xc5, 0x8a);
        this.vmethod_0().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_0().TabIndex = 30;
        this.vmethod_0().TabStop = false;
        this.vmethod_8().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
        this.vmethod_8().BackColor = Color.Transparent;
        this.vmethod_8().ForeColor = Color.Black;
        this.vmethod_8().Location = new Point(0, 0);
        this.vmethod_8().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_8().Name = "lblCaption";
        this.vmethod_8().Size = new Size(0xc5, 14);
        this.vmethod_8().TabIndex = 0x20;
        this.vmethod_8().TextAlign = ContentAlignment.TopCenter;
        this.vmethod_10().Interval = 1;
        this.vmethod_12().BackColor = Color.Transparent;
        this.vmethod_12().Dock = DockStyle.Bottom;
        this.vmethod_12().ForeColor = Color.Black;
        this.vmethod_12().Location = new Point(0, 140);
        this.vmethod_12().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_12().Name = "lblData";
        this.vmethod_12().Size = new Size(0xc5, 14);
        this.vmethod_12().TabIndex = 0x21;
        this.vmethod_12().TextAlign = ContentAlignment.TopRight;
        base.AutoScaleDimensions = new SizeF(6f, 13f);
        base.AutoScaleMode = AutoScaleMode.Font;
        this.BackColor = Color.SkyBlue;
        base.ClientSize = new Size(0xc5, 0x9a);
        base.ControlBox = false;
        base.Controls.Add(this.vmethod_12());
        base.Controls.Add(this.vmethod_8());
        base.Controls.Add(this.vmethod_6());
        base.Controls.Add(this.vmethod_0());
        this.DoubleBuffered = true;
        base.FormBorderStyle = FormBorderStyle.None;
        base.MaximizeBox = false;
        base.MinimizeBox = false;
        base.Name = "fThumb";
        base.ShowIcon = false;
        base.ShowInTaskbar = false;
        base.SizeGripStyle = SizeGripStyle.Hide;
        ((ISupportInitialize) this.vmethod_0()).EndInit();
        base.ResumeLayout(false);
    }

    public void method_0(string string_5, string string_6, string string_7, string string_8, string string_9)
    {
        this.string_4 = string_5;
        this.string_1 = string_6;
        this.string_3 = string_7;
        this.string_2 = string_8;
        this.string_0 = string_9;
        string[] textArray1 = new string[] { string_6, "^", string_8, " - ", string_9 };
        this.vmethod_8().Text = string.Concat(textArray1);
        this.vmethod_12().Text = string_5;
    }

    public void method_1()
    {
        this.vmethod_0().Image = null;
        this.vmethod_0().BackColor = Color.Empty;
        this.vmethod_0().Invalidate();
        if (this.vmethod_6().InvokeRequired)
        {
            this.vmethod_6().Invoke(new Delegate71(this.method_1), new object[0]);
        }
        else
        {
            this.vmethod_6().set_Animate(true);
            this.vmethod_6().Visible = true;
        }
    }

    private void method_10(object sender, EventArgs e)
    {
    }

    private void method_11(object sender, EventArgs e)
    {
    }

    private void method_12(object sender, EventArgs e)
    {
        if (!Class135.smethod_0().PreviewTransparentFrames)
        {
            base.Opacity = 100.0;
            base.Visible = true;
            this.Refresh();
            this.vmethod_2().Tag = "0";
            this.vmethod_2().Enabled = false;
        }
        else
        {
            if (Conversion.Val(this.vmethod_2().Tag) == 80.0)
            {
                base.Opacity = 80.0;
                base.Visible = true;
                this.vmethod_2().Tag = "0";
            }
            this.vmethod_2().Tag = Conversion.Val(this.vmethod_2().Tag) + 10.0;
            base.Opacity = Conversion.Val(Operators.DivideObject(this.vmethod_2().Tag, (int) 100));
            this.Refresh();
            if (Conversion.Val(this.vmethod_2().Tag) == 80.0)
            {
                this.vmethod_2().Enabled = false;
            }
        }
    }

    private void method_13(object sender, MouseEventArgs e)
    {
        if (e.Button == MouseButtons.Left)
        {
            this.vmethod_10().Enabled = false;
        }
    }

    private void method_14(object sender, MouseEventArgs e)
    {
        this.method_7();
        MouseButtons button = e.Button;
        if (button == MouseButtons.Left)
        {
            this.vmethod_10().Enabled = true;
        }
        else if (button == MouseButtons.Right)
        {
            this.method_4();
        }
    }

    public void method_2()
    {
        if (this.vmethod_6().InvokeRequired)
        {
            this.vmethod_6().Invoke(new Delegate73(this.method_2), new object[0]);
        }
        else
        {
            this.vmethod_6().set_Animate(false);
            this.vmethod_6().Visible = false;
        }
    }

    public void method_3()
    {
        if (base.InvokeRequired)
        {
            base.Invoke(new Delegate72(this.method_3), new object[0]);
        }
        else
        {
            this.method_5();
            this.vmethod_2().Enabled = true;
        }
    }

    public void method_4()
    {
        if (base.InvokeRequired)
        {
            base.Invoke(new Delegate74(this.method_4), new object[0]);
        }
        else
        {
            this.vmethod_4().Enabled = true;
        }
    }

    private void method_5()
    {
        this.vmethod_6().Left = (int) Math.Round((double) ((((double) base.Width) / 2.0) - (((double) this.vmethod_6().Width) / 2.0)));
        this.vmethod_6().Top = (int) Math.Round((double) ((((double) base.Height) / 2.0) - (((double) this.vmethod_6().Height) / 2.0)));
        this.vmethod_6().set_Animate(true);
        Point position = Cursor.Position;
        base.Left = (int) Math.Round((double) (position.X - (((double) base.Width) / 2.0)));
        base.Top = (int) Math.Round((double) (position.Y - (((double) base.Height) / 2.0)));
    }

    private void method_6()
    {
        Point position = Cursor.Position;
        base.Left = position.X - ((int) this.long_0);
        base.Top = position.Y - ((int) this.long_1);
    }

    private void method_7()
    {
        this.point_0 = Cursor.Position;
        this.long_0 = this.point_0.X - base.Left;
        this.long_1 = this.point_0.Y - base.Top;
    }

    private void method_8(object sender, EventArgs e)
    {
        if (!Class135.smethod_0().PreviewTransparentFrames)
        {
            base.Opacity = 0.0;
            this.Refresh();
            this.vmethod_4().Tag = 0;
            base.Visible = false;
            this.vmethod_4().Enabled = false;
        }
        else
        {
            if (Conversion.Val(this.vmethod_4().Tag) == 0.0)
            {
                this.vmethod_4().Tag = "80";
                base.Opacity = 80.0;
                base.Visible = true;
            }
            this.vmethod_4().Tag = Conversion.Val(this.vmethod_4().Tag) - 10.0;
            base.Opacity = Conversion.Val(Operators.DivideObject(this.vmethod_4().Tag, (int) 100));
            this.Refresh();
            if (Conversion.Val(this.vmethod_4().Tag) == 0.0)
            {
                base.Visible = false;
                this.vmethod_4().Enabled = false;
            }
        }
    }

    private void method_9(object sender, EventArgs e)
    {
        this.method_6();
    }

    internal virtual PictureBox vmethod_0()
    {
        return this.pictureBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_1(PictureBox pictureBox_1)
    {
        EventHandler handler = new EventHandler(this.method_10);
        MouseEventHandler handler2 = new MouseEventHandler(this.method_13);
        MouseEventHandler handler3 = new MouseEventHandler(this.method_14);
        PictureBox box = this.pictureBox_0;
        if (box != null)
        {
            box.Click -= handler;
            box.MouseUp -= handler2;
            box.MouseDown -= handler3;
        }
        this.pictureBox_0 = pictureBox_1;
        box = this.pictureBox_0;
        if (box != null)
        {
            box.Click += handler;
            box.MouseUp += handler2;
            box.MouseDown += handler3;
        }
    }

    internal virtual Timer vmethod_10()
    {
        return this.timer_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_11(Timer timer_3)
    {
        EventHandler handler = new EventHandler(this.method_9);
        Timer timer = this.timer_2;
        if (timer != null)
        {
            timer.Tick -= handler;
        }
        this.timer_2 = timer_3;
        timer = this.timer_2;
        if (timer != null)
        {
            timer.Tick += handler;
        }
    }

    internal virtual Label vmethod_12()
    {
        return this.label_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_13(Label label_2)
    {
        this.label_1 = label_2;
    }

    internal virtual Timer vmethod_2()
    {
        return this.timer_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_3(Timer timer_3)
    {
        EventHandler handler = new EventHandler(this.method_12);
        Timer timer = this.timer_0;
        if (timer != null)
        {
            timer.Tick -= handler;
        }
        this.timer_0 = timer_3;
        timer = this.timer_0;
        if (timer != null)
        {
            timer.Tick += handler;
        }
    }

    internal virtual Timer vmethod_4()
    {
        return this.timer_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_5(Timer timer_3)
    {
        EventHandler handler = new EventHandler(this.method_8);
        Timer timer = this.timer_1;
        if (timer != null)
        {
            timer.Tick -= handler;
        }
        this.timer_1 = timer_3;
        timer = this.timer_1;
        if (timer != null)
        {
            timer.Tick += handler;
        }
    }

    internal virtual ZeroitWin8ProgressRing vmethod_6()
    {
        return this.zeroitWin8ProgressRing_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_7(ZeroitWin8ProgressRing zeroitWin8ProgressRing_1)
    {
        EventHandler handler = new EventHandler(this.method_11);
        ZeroitWin8ProgressRing ring = this.zeroitWin8ProgressRing_0;
        if (ring != null)
        {
            ring.Click -= handler;
        }
        this.zeroitWin8ProgressRing_0 = zeroitWin8ProgressRing_1;
        ring = this.zeroitWin8ProgressRing_0;
        if (ring != null)
        {
            ring.Click += handler;
        }
    }

    internal virtual Label vmethod_8()
    {
        return this.label_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_9(Label label_2)
    {
        this.label_0 = label_2;
    }

    private delegate void Delegate71();

    private delegate void Delegate72();

    private delegate void Delegate73();

    private delegate void Delegate74();
}

