﻿using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using Zeroit.Framework.Progress;

[DesignerGenerated]
public sealed class fPaymentDDoS : Form
{
    private IContainer icontainer_0;
    private PictureBox pictureBox_0;
    private Label label_0;
    private Label label_1;
    private Label label_2;
    private ZeroitProgressIndicator zeroitProgressIndicator_0;
    private BackgroundWorker backgroundWorker_0;
    private Label label_3;
    private PictureBox pictureBox_1;
    private PictureBox pictureBox_2;
    private BackgroundWorker backgroundWorker_1;
    private Label label_4;
    private Timer timer_0;
    private Label label_5;
    private Label label_6;
    private PictureBox pictureBox_3;
    private Label label_7;
    private Label label_8;
    private Label label_9;
    private Label label_10;
    private Label label_11;
    private Label label_12;
    private ToolStripStatusLabel toolStripStatusLabel_0;
    private BackgroundWorker backgroundWorker_2;
    private StatusStrip statusStrip_0;
    private PictureBox pictureBox_4;
    private PictureBox pictureBox_5;
    private Label label_13;
    private PictureBox pictureBox_6;
    private Struct18 struct18_0;
    private Struct18 struct18_1;
    private Struct16 struct16_0;
    private string string_0;
    private string string_1;
    private string string_2;
    private string string_3;
    private string string_4;
    private bool bool_0;
    private TimeSpan timeSpan_0;
    private Stopwatch stopwatch_0;
    private int int_0;

    public fPaymentDDoS()
    {
        base.Load += new EventHandler(this.fPaymentDDoS_Load);
        base.Closing += new CancelEventHandler(this.fPaymentDDoS_Closing);
        this.InitializeComponent();
    }

    [CompilerGenerated]
    private void _Lambda$__R140-1()
    {
        this.method_5();
    }

    [CompilerGenerated]
    private void _Lambda$__R141-2()
    {
        this.method_5();
    }

    [CompilerGenerated]
    private void _Lambda$__R143-3()
    {
        this.method_5();
    }

    [CompilerGenerated]
    private void _Lambda$__R152-4()
    {
        this.method_5();
    }

    [DebuggerNonUserCode]
    protected override void Dispose(bool disposing)
    {
        if (disposing && (this.icontainer_0 != null))
        {
            this.icontainer_0.Dispose();
        }
    }

    private void fPaymentDDoS_Closing(object sender, CancelEventArgs e)
    {
        base.Visible = false;
        e.Cancel = true;
    }

    private void fPaymentDDoS_Load(object sender, EventArgs e)
    {
        object[] objArray = new object[] { this, sender, e };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O9/*?8f8", objArray);
    }

    [DebuggerStepThrough]
    private void InitializeComponent()
    {
        this.icontainer_0 = new Container();
        ComponentResourceManager manager = new ComponentResourceManager(typeof(fPaymentDDoS));
        this.vmethod_3(new Label());
        this.vmethod_5(new Label());
        this.vmethod_7(new Label());
        this.vmethod_9(new ZeroitProgressIndicator());
        this.vmethod_11(new BackgroundWorker());
        this.vmethod_13(new Label());
        this.vmethod_19(new BackgroundWorker());
        this.vmethod_21(new Label());
        this.vmethod_23(new Timer(this.icontainer_0));
        this.vmethod_25(new Label());
        this.vmethod_27(new Label());
        this.vmethod_31(new Label());
        this.vmethod_33(new Label());
        this.vmethod_35(new Label());
        this.vmethod_37(new Label());
        this.vmethod_39(new Label());
        this.vmethod_41(new Label());
        this.vmethod_43(new ToolStripStatusLabel());
        this.vmethod_45(new BackgroundWorker());
        this.vmethod_47(new StatusStrip());
        this.vmethod_53(new Label());
        this.vmethod_55(new PictureBox());
        this.vmethod_1(new PictureBox());
        this.vmethod_15(new PictureBox());
        this.vmethod_29(new PictureBox());
        this.vmethod_17(new PictureBox());
        this.vmethod_49(new PictureBox());
        this.vmethod_51(new PictureBox());
        this.vmethod_46().SuspendLayout();
        ((ISupportInitialize) this.vmethod_54()).BeginInit();
        ((ISupportInitialize) this.vmethod_0()).BeginInit();
        ((ISupportInitialize) this.vmethod_14()).BeginInit();
        ((ISupportInitialize) this.vmethod_28()).BeginInit();
        ((ISupportInitialize) this.vmethod_16()).BeginInit();
        ((ISupportInitialize) this.vmethod_48()).BeginInit();
        ((ISupportInitialize) this.vmethod_50()).BeginInit();
        base.SuspendLayout();
        this.vmethod_2().AutoSize = true;
        this.vmethod_2().BackColor = Color.Transparent;
        this.vmethod_2().ForeColor = Color.Red;
        this.vmethod_2().Location = new Point(0x6b, 0xf6);
        this.vmethod_2().Name = "lblUnderpaid";
        this.vmethod_2().Size = new Size(0x99, 13);
        this.vmethod_2().TabIndex = 0xa2;
        this.vmethod_2().Text = "(Underpaid! Missing: N/A BTC)";
        this.vmethod_2().Visible = false;
        this.vmethod_4().AutoSize = true;
        this.vmethod_4().BackColor = Color.Transparent;
        this.vmethod_4().Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_4().ForeColor = Color.Black;
        this.vmethod_4().Location = new Point(0x4b, 0xf6);
        this.vmethod_4().Name = "lblRecv";
        this.vmethod_4().Size = new Size(0x1b, 13);
        this.vmethod_4().TabIndex = 0xa1;
        this.vmethod_4().Text = "N/A";
        this.vmethod_4().Visible = false;
        this.vmethod_6().AutoSize = true;
        this.vmethod_6().BackColor = Color.Transparent;
        this.vmethod_6().Location = new Point(0x10, 0xf6);
        this.vmethod_6().Name = "lblRecvCaption";
        this.vmethod_6().Size = new Size(0x38, 13);
        this.vmethod_6().TabIndex = 160;
        this.vmethod_6().Text = "Received:";
        this.vmethod_6().Visible = false;
        this.vmethod_8().set_BackColor(SystemColors.AppWorkspace);
        this.vmethod_8().set_CircleWidth(20f);
        this.vmethod_8().set_GetAnimationColor(Color.DeepSkyBlue);
        this.vmethod_8().set_GetAnimationSpeed(100);
        this.vmethod_8().set_GetBaseColor(Color.SkyBlue);
        this.vmethod_8().Location = new Point(0xb5, 0x2c);
        this.vmethod_8().MinimumSize = new Size(80, 80);
        this.vmethod_8().Name = "pbSplash";
        this.vmethod_8().set_NumberOfCircles(45f);
        this.vmethod_8().set_Radian(180.0);
        this.vmethod_8().Size = new Size(100, 100);
        this.vmethod_8().set_Smoothing(SmoothingMode.HighQuality);
        this.vmethod_8().TabIndex = 140;
        this.vmethod_12().AutoSize = true;
        this.vmethod_12().BackColor = Color.Transparent;
        this.vmethod_12().Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Italic, GraphicsUnit.Point, 0);
        this.vmethod_12().Location = new Point(0x16f, 0x1dd);
        this.vmethod_12().Name = "lblAlreadyPaid";
        this.vmethod_12().Size = new Size(0x47, 13);
        this.vmethod_12().TabIndex = 0x9d;
        this.vmethod_12().Text = "Already paid?";
        this.vmethod_18().WorkerSupportsCancellation = true;
        this.vmethod_20().AutoSize = true;
        this.vmethod_20().BackColor = Color.Transparent;
        this.vmethod_20().ForeColor = Color.Green;
        this.vmethod_20().Location = new Point(0x6b, 0xf6);
        this.vmethod_20().Name = "lblPaid";
        this.vmethod_20().Size = new Size(0xa5, 13);
        this.vmethod_20().TabIndex = 0xa3;
        this.vmethod_20().Text = "(Paid! Waiting for confirmations...)";
        this.vmethod_20().Visible = false;
        this.vmethod_22().Interval = 0x3e8;
        this.vmethod_24().AutoSize = true;
        this.vmethod_24().BackColor = Color.Transparent;
        this.vmethod_24().Location = new Point(0x3a, 0x112);
        this.vmethod_24().Name = "lblInfo";
        this.vmethod_24().Size = new Size(0x133, 0x5b);
        this.vmethod_24().TabIndex = 0x9a;
        this.vmethod_24().Text = manager.GetString("lblInfo.Text");
        this.vmethod_26().BackColor = Color.Transparent;
        this.vmethod_26().Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
        this.vmethod_26().Location = new Point(60, 0xaf);
        this.vmethod_26().Name = "lblTimer";
        this.vmethod_26().Size = new Size(0x161, 14);
        this.vmethod_26().TabIndex = 0x99;
        this.vmethod_26().Text = "Time left: N/A";
        this.vmethod_26().TextAlign = ContentAlignment.TopCenter;
        this.vmethod_26().Visible = false;
        this.vmethod_30().AutoSize = true;
        this.vmethod_30().BackColor = Color.Transparent;
        this.vmethod_30().Location = new Point(0x6b, 0xca);
        this.vmethod_30().Name = "lblAmountUSD";
        this.vmethod_30().Size = new Size(0x31, 13);
        this.vmethod_30().TabIndex = 0x97;
        this.vmethod_30().Text = "~ 0 USD";
        this.vmethod_30().Visible = false;
        this.vmethod_32().AutoSize = true;
        this.vmethod_32().BackColor = Color.Transparent;
        this.vmethod_32().Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
        this.vmethod_32().ForeColor = Color.RoyalBlue;
        this.vmethod_32().Location = new Point(0x4b, 0xe0);
        this.vmethod_32().Name = "lblAddress";
        this.vmethod_32().Size = new Size(30, 13);
        this.vmethod_32().TabIndex = 150;
        this.vmethod_32().Text = "N/A";
        this.vmethod_32().Visible = false;
        this.vmethod_34().AutoSize = true;
        this.vmethod_34().BackColor = Color.Transparent;
        this.vmethod_34().Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
        this.vmethod_34().ForeColor = Color.RoyalBlue;
        this.vmethod_34().Location = new Point(0x4b, 0xca);
        this.vmethod_34().Name = "lblAmount";
        this.vmethod_34().Size = new Size(30, 13);
        this.vmethod_34().TabIndex = 0x95;
        this.vmethod_34().Text = "N/A";
        this.vmethod_34().Visible = false;
        this.vmethod_36().AutoSize = true;
        this.vmethod_36().BackColor = Color.Transparent;
        this.vmethod_36().Location = new Point(0x18, 0xe0);
        this.vmethod_36().Name = "lblAddrCaption";
        this.vmethod_36().Size = new Size(0x30, 13);
        this.vmethod_36().TabIndex = 0x94;
        this.vmethod_36().Text = "Address:";
        this.vmethod_36().Visible = false;
        this.vmethod_38().AutoSize = true;
        this.vmethod_38().BackColor = Color.Transparent;
        this.vmethod_38().Location = new Point(0x1a, 0xca);
        this.vmethod_38().Name = "lblAmountCaption";
        this.vmethod_38().Size = new Size(0x2e, 13);
        this.vmethod_38().TabIndex = 0x93;
        this.vmethod_38().Text = "Amount:";
        this.vmethod_38().Visible = false;
        this.vmethod_40().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
        this.vmethod_40().BackColor = Color.Transparent;
        this.vmethod_40().Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
        this.vmethod_40().Location = new Point(8, 12);
        this.vmethod_40().Name = "lblTitle";
        this.vmethod_40().Size = new Size(0x1bf, 0x17);
        this.vmethod_40().TabIndex = 0x92;
        this.vmethod_40().Text = "Buy DDoS access";
        this.vmethod_40().TextAlign = ContentAlignment.TopCenter;
        this.vmethod_42().AutoSize = false;
        this.vmethod_42().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_42().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_42().Margin = new Padding(0, 3, -6, 0);
        this.vmethod_42().Name = "tsStatus";
        this.vmethod_42().Size = new Size(0x1ce, 0x10);
        this.vmethod_42().Spring = true;
        this.vmethod_42().Text = "Status: N/A";
        this.vmethod_42().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_44().WorkerSupportsCancellation = true;
        this.vmethod_46().AutoSize = false;
        this.vmethod_46().BackColor = Color.FromArgb(0xeb, 0xed, 0xef);
        this.vmethod_46().ImageScalingSize = new Size(0x1c, 0x1c);
        ToolStripItem[] toolStripItems = new ToolStripItem[] { this.vmethod_42() };
        this.vmethod_46().Items.AddRange(toolStripItems);
        this.vmethod_46().Location = new Point(0, 0x1f5);
        this.vmethod_46().Name = "ssMain";
        this.vmethod_46().Padding = new Padding(1, 0, 7, 0);
        this.vmethod_46().Size = new Size(0x1d0, 0x13);
        this.vmethod_46().SizingGrip = false;
        this.vmethod_46().Stretch = false;
        this.vmethod_46().TabIndex = 0x8b;
        this.vmethod_46().Text = "stStatus";
        this.vmethod_52().AutoSize = true;
        this.vmethod_52().BackColor = Color.Transparent;
        this.vmethod_52().Location = new Point(0x3a, 0x17b);
        this.vmethod_52().Name = "lblWarning";
        this.vmethod_52().Size = new Size(0x141, 0x5b);
        this.vmethod_52().TabIndex = 0xa5;
        this.vmethod_52().Text = manager.GetString("lblWarning.Text");
        this.vmethod_54().Image = Class131.smethod_33();
        this.vmethod_54().Location = new Point(0xa1, 200);
        this.vmethod_54().Margin = new Padding(2);
        this.vmethod_54().Name = "pbCopyAmount";
        this.vmethod_54().Size = new Size(15, 15);
        this.vmethod_54().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_54().TabIndex = 0xa6;
        this.vmethod_54().TabStop = false;
        this.vmethod_54().Visible = false;
        this.vmethod_0().Image = Class131.smethod_33();
        this.vmethod_0().Location = new Point(0x115, 0xf6);
        this.vmethod_0().Margin = new Padding(2);
        this.vmethod_0().Name = "pbCopyRemainder";
        this.vmethod_0().Size = new Size(15, 15);
        this.vmethod_0().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_0().TabIndex = 0xa4;
        this.vmethod_0().TabStop = false;
        this.vmethod_0().Visible = false;
        this.vmethod_14().Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
        this.vmethod_14().Image = Class131.smethod_17();
        this.vmethod_14().Location = new Point(0x1bb, 0x1dd);
        this.vmethod_14().Margin = new Padding(2);
        this.vmethod_14().Name = "pbHelp";
        this.vmethod_14().Size = new Size(15, 15);
        this.vmethod_14().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_14().TabIndex = 0x9c;
        this.vmethod_14().TabStop = false;
        this.vmethod_28().Image = Class131.smethod_33();
        this.vmethod_28().Location = new Point(110, 0xde);
        this.vmethod_28().Margin = new Padding(2);
        this.vmethod_28().Name = "pbCopyAddr";
        this.vmethod_28().Size = new Size(15, 15);
        this.vmethod_28().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_28().TabIndex = 0x98;
        this.vmethod_28().TabStop = false;
        this.vmethod_28().Visible = false;
        this.vmethod_16().BackColor = Color.Transparent;
        this.vmethod_16().Image = Class131.smethod_3();
        this.vmethod_16().Location = new Point(0xb5, 0x2c);
        this.vmethod_16().Margin = new Padding(2);
        this.vmethod_16().Name = "pbComplete";
        this.vmethod_16().Size = new Size(100, 100);
        this.vmethod_16().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_16().TabIndex = 0x9b;
        this.vmethod_16().TabStop = false;
        this.vmethod_16().Visible = false;
        this.vmethod_48().BackColor = Color.Transparent;
        this.vmethod_48().Location = new Point(0xb5, 0x2c);
        this.vmethod_48().Margin = new Padding(2);
        this.vmethod_48().Name = "pbQR";
        this.vmethod_48().Size = new Size(100, 100);
        this.vmethod_48().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_48().TabIndex = 0x8a;
        this.vmethod_48().TabStop = false;
        this.vmethod_48().Visible = false;
        this.vmethod_50().BackColor = Color.Transparent;
        this.vmethod_50().Image = Class131.smethod_13();
        this.vmethod_50().Location = new Point(0xb5, 0x2c);
        this.vmethod_50().Margin = new Padding(2);
        this.vmethod_50().Name = "pbError";
        this.vmethod_50().Size = new Size(100, 100);
        this.vmethod_50().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_50().TabIndex = 0x9e;
        this.vmethod_50().TabStop = false;
        this.vmethod_50().Visible = false;
        base.AutoScaleDimensions = new SizeF(6f, 13f);
        base.AutoScaleMode = AutoScaleMode.Font;
        this.BackColor = SystemColors.AppWorkspace;
        base.ClientSize = new Size(0x1d0, 520);
        base.Controls.Add(this.vmethod_54());
        base.Controls.Add(this.vmethod_52());
        base.Controls.Add(this.vmethod_0());
        base.Controls.Add(this.vmethod_4());
        base.Controls.Add(this.vmethod_6());
        base.Controls.Add(this.vmethod_12());
        base.Controls.Add(this.vmethod_14());
        base.Controls.Add(this.vmethod_24());
        base.Controls.Add(this.vmethod_26());
        base.Controls.Add(this.vmethod_28());
        base.Controls.Add(this.vmethod_30());
        base.Controls.Add(this.vmethod_32());
        base.Controls.Add(this.vmethod_34());
        base.Controls.Add(this.vmethod_36());
        base.Controls.Add(this.vmethod_38());
        base.Controls.Add(this.vmethod_40());
        base.Controls.Add(this.vmethod_46());
        base.Controls.Add(this.vmethod_2());
        base.Controls.Add(this.vmethod_20());
        base.Controls.Add(this.vmethod_8());
        base.Controls.Add(this.vmethod_16());
        base.Controls.Add(this.vmethod_48());
        base.Controls.Add(this.vmethod_50());
        this.DoubleBuffered = true;
        base.FormBorderStyle = FormBorderStyle.FixedSingle;
        base.Icon = (Icon) manager.GetObject("$this.Icon");
        base.MaximizeBox = false;
        base.MinimizeBox = false;
        base.Name = "fPaymentDDoS";
        base.Opacity = 0.0;
        base.StartPosition = FormStartPosition.CenterParent;
        this.Text = "Buy DDoS";
        this.vmethod_46().ResumeLayout(false);
        this.vmethod_46().PerformLayout();
        ((ISupportInitialize) this.vmethod_54()).EndInit();
        ((ISupportInitialize) this.vmethod_0()).EndInit();
        ((ISupportInitialize) this.vmethod_14()).EndInit();
        ((ISupportInitialize) this.vmethod_28()).EndInit();
        ((ISupportInitialize) this.vmethod_16()).EndInit();
        ((ISupportInitialize) this.vmethod_48()).EndInit();
        ((ISupportInitialize) this.vmethod_50()).EndInit();
        base.ResumeLayout(false);
        base.PerformLayout();
    }

    public void method_0(int int_1)
    {
        // Unresolved stack state at '00000008'
    }

    public void method_1(string string_5)
    {
        object[] objArray = new object[] { this, string_5 };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O9Q*?:[m", objArray);
    }

    private void method_10(object sender, EventArgs e)
    {
        Clipboard.Clear();
        Clipboard.SetText(this.vmethod_34().Text);
        Interaction.MsgBox("Amount copied to clipboard!", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_11(object sender, EventArgs e)
    {
        Clipboard.Clear();
        Clipboard.SetText(this.vmethod_32().Text);
        Interaction.MsgBox("Address copied to clipboard!", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_12(object sender, EventArgs e)
    {
        Clipboard.Clear();
        Clipboard.SetText(Conversions.ToString(this.vmethod_2().Tag));
        Interaction.MsgBox("Remaining amount copied to clipboard!", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_13(object sender, DoWorkEventArgs e)
    {
        object[] objArray = new object[] { this, sender, e };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O8H*?<`R", objArray);
    }

    private void method_14(object sender, DoWorkEventArgs e)
    {
        Thread.Sleep(0x3e8);
        this.int_0 = 0;
        while (this.int_0 < 100)
        {
            ref int numRef;
            *(numRef = ref this.int_0) = numRef + 1;
            this.method_0(this.int_0);
            Thread.Sleep(1);
        }
    }

    private void method_15(object sender, EventArgs e)
    {
        string[] textArray1 = new string[] { "If you've already paid and still seeing this payment form, please close it and wait some minutes before starting ", Application.ProductName, " again.\r\n\r\nMost likely, your payment is still waiting for a confirmation and your purchased item will automatically become available once confirmed.\r\n\r\nNOTE: ", Application.ProductName, " uses private nodes in the blockchain to check for confimrations, not public services like blockchain.com.\r\nThis means a confirmation may sometimes take a little longer or sometimes even faster. Do not panic, but allow some more minutes." };
        Interaction.MsgBox(string.Concat(textArray1), MsgBoxStyle.Question, Application.ProductName);
    }

    private void method_16(object sender, EventArgs e)
    {
        Clipboard.Clear();
        Clipboard.SetText(this.vmethod_34().Text);
        Interaction.MsgBox("Amount copied to clipboard!", MsgBoxStyle.Information, Application.ProductName);
    }

    public void method_17()
    {
        object[] objArray = new object[] { this };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O9=*?98E", objArray);
    }

    public void method_18(string string_5, bool bool_1, string string_6, decimal decimal_0)
    {
        // Unresolved stack state at '00000000'
    }

    private void method_2(ref string string_5, ref string string_6, ref string string_7)
    {
        object[] objArray = new object[] { this, string_5, string_6, string_7 };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O9n*?:.^", objArray);
    }

    private void method_3()
    {
        object[] objArray = new object[] { this };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O8D*?6@H", objArray);
    }

    private void method_4(string string_5, string string_6)
    {
        object[] objArray = new object[] { this, string_5, string_6 };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O9'*?9YP", objArray);
    }

    public unsafe bool method_5()
    {
        object[] objArray = new object[] { this };
        return *(((bool*) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O84*?;@+", objArray)));
    }

    public void method_6()
    {
        object[] objArray = new object[] { this };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O9i*?83'", objArray);
    }

    private void method_7(object sender, DoWorkEventArgs e)
    {
        Thread.Sleep(0x3e8);
        this.int_0 = 0;
        while (this.int_0 < 100)
        {
            ref int numRef;
            *(numRef = ref this.int_0) = numRef + 1;
            this.method_0(this.int_0);
            Thread.Sleep(1);
        }
    }

    public void method_8()
    {
        object[] objArray = new object[] { this };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O8h*?7Kh", objArray);
    }

    private void method_9(object sender, EventArgs e)
    {
        Clipboard.Clear();
        Clipboard.SetText(this.vmethod_32().Text);
        Interaction.MsgBox("Address copied to clipboard!", MsgBoxStyle.Information, Application.ProductName);
    }

    internal virtual PictureBox vmethod_0()
    {
        return this.pictureBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_1(PictureBox pictureBox_7)
    {
        EventHandler handler = new EventHandler(this.method_12);
        PictureBox box = this.pictureBox_0;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_0 = pictureBox_7;
        box = this.pictureBox_0;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual BackgroundWorker vmethod_10()
    {
        return this.backgroundWorker_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_11(BackgroundWorker backgroundWorker_3)
    {
        DoWorkEventHandler handler = new DoWorkEventHandler(this.method_14);
        BackgroundWorker worker = this.backgroundWorker_0;
        if (worker != null)
        {
            worker.DoWork -= handler;
        }
        this.backgroundWorker_0 = backgroundWorker_3;
        worker = this.backgroundWorker_0;
        if (worker != null)
        {
            worker.DoWork += handler;
        }
    }

    internal virtual Label vmethod_12()
    {
        return this.label_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_13(Label label_14)
    {
        this.label_3 = label_14;
    }

    internal virtual PictureBox vmethod_14()
    {
        return this.pictureBox_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_15(PictureBox pictureBox_7)
    {
        EventHandler handler = new EventHandler(this.method_15);
        PictureBox box = this.pictureBox_1;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_1 = pictureBox_7;
        box = this.pictureBox_1;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual PictureBox vmethod_16()
    {
        return this.pictureBox_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_17(PictureBox pictureBox_7)
    {
        this.pictureBox_2 = pictureBox_7;
    }

    internal virtual BackgroundWorker vmethod_18()
    {
        return this.backgroundWorker_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_19(BackgroundWorker backgroundWorker_3)
    {
        DoWorkEventHandler handler = new DoWorkEventHandler(this.method_13);
        BackgroundWorker worker = this.backgroundWorker_1;
        if (worker != null)
        {
            worker.DoWork -= handler;
        }
        this.backgroundWorker_1 = backgroundWorker_3;
        worker = this.backgroundWorker_1;
        if (worker != null)
        {
            worker.DoWork += handler;
        }
    }

    internal virtual Label vmethod_2()
    {
        return this.label_0;
    }

    internal virtual Label vmethod_20()
    {
        return this.label_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_21(Label label_14)
    {
        this.label_4 = label_14;
    }

    internal virtual Timer vmethod_22()
    {
        return this.timer_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_23(Timer timer_1)
    {
        this.timer_0 = timer_1;
    }

    internal virtual Label vmethod_24()
    {
        return this.label_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_25(Label label_14)
    {
        this.label_5 = label_14;
    }

    internal virtual Label vmethod_26()
    {
        return this.label_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_27(Label label_14)
    {
        this.label_6 = label_14;
    }

    internal virtual PictureBox vmethod_28()
    {
        return this.pictureBox_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_29(PictureBox pictureBox_7)
    {
        EventHandler handler = new EventHandler(this.method_11);
        PictureBox box = this.pictureBox_3;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_3 = pictureBox_7;
        box = this.pictureBox_3;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_3(Label label_14)
    {
        this.label_0 = label_14;
    }

    internal virtual Label vmethod_30()
    {
        return this.label_7;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_31(Label label_14)
    {
        this.label_7 = label_14;
    }

    internal virtual Label vmethod_32()
    {
        return this.label_8;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_33(Label label_14)
    {
        EventHandler handler = new EventHandler(this.method_9);
        Label label = this.label_8;
        if (label != null)
        {
            label.Click -= handler;
        }
        this.label_8 = label_14;
        label = this.label_8;
        if (label != null)
        {
            label.Click += handler;
        }
    }

    internal virtual Label vmethod_34()
    {
        return this.label_9;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_35(Label label_14)
    {
        EventHandler handler = new EventHandler(this.method_10);
        Label label = this.label_9;
        if (label != null)
        {
            label.Click -= handler;
        }
        this.label_9 = label_14;
        label = this.label_9;
        if (label != null)
        {
            label.Click += handler;
        }
    }

    internal virtual Label vmethod_36()
    {
        return this.label_10;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_37(Label label_14)
    {
        this.label_10 = label_14;
    }

    internal virtual Label vmethod_38()
    {
        return this.label_11;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_39(Label label_14)
    {
        this.label_11 = label_14;
    }

    internal virtual Label vmethod_4()
    {
        return this.label_1;
    }

    internal virtual Label vmethod_40()
    {
        return this.label_12;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_41(Label label_14)
    {
        this.label_12 = label_14;
    }

    internal virtual ToolStripStatusLabel vmethod_42()
    {
        return this.toolStripStatusLabel_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_43(ToolStripStatusLabel toolStripStatusLabel_1)
    {
        this.toolStripStatusLabel_0 = toolStripStatusLabel_1;
    }

    internal virtual BackgroundWorker vmethod_44()
    {
        return this.backgroundWorker_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_45(BackgroundWorker backgroundWorker_3)
    {
        DoWorkEventHandler handler = new DoWorkEventHandler(this.method_7);
        BackgroundWorker worker = this.backgroundWorker_2;
        if (worker != null)
        {
            worker.DoWork -= handler;
        }
        this.backgroundWorker_2 = backgroundWorker_3;
        worker = this.backgroundWorker_2;
        if (worker != null)
        {
            worker.DoWork += handler;
        }
    }

    internal virtual StatusStrip vmethod_46()
    {
        return this.statusStrip_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_47(StatusStrip statusStrip_1)
    {
        this.statusStrip_0 = statusStrip_1;
    }

    internal virtual PictureBox vmethod_48()
    {
        return this.pictureBox_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_49(PictureBox pictureBox_7)
    {
        this.pictureBox_4 = pictureBox_7;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_5(Label label_14)
    {
        this.label_1 = label_14;
    }

    internal virtual PictureBox vmethod_50()
    {
        return this.pictureBox_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_51(PictureBox pictureBox_7)
    {
        this.pictureBox_5 = pictureBox_7;
    }

    internal virtual Label vmethod_52()
    {
        return this.label_13;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_53(Label label_14)
    {
        this.label_13 = label_14;
    }

    internal virtual PictureBox vmethod_54()
    {
        return this.pictureBox_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_55(PictureBox pictureBox_7)
    {
        EventHandler handler = new EventHandler(this.method_16);
        PictureBox box = this.pictureBox_6;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_6 = pictureBox_7;
        box = this.pictureBox_6;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual Label vmethod_6()
    {
        return this.label_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_7(Label label_14)
    {
        this.label_2 = label_14;
    }

    internal virtual ZeroitProgressIndicator vmethod_8()
    {
        return this.zeroitProgressIndicator_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_9(ZeroitProgressIndicator zeroitProgressIndicator_1)
    {
        this.zeroitProgressIndicator_0 = zeroitProgressIndicator_1;
    }

    private delegate void Delegate103(ref string string_0, ref string string_1, ref string string_2);

    private delegate void Delegate104(string string_0);

    private delegate void Delegate105();

    private delegate void Delegate106();

    private delegate void Delegate107(string string_0, bool bool_0, string string_1, decimal decimal_0);

    private delegate void Delegate108(string string_0, string string_1);

    private delegate void Delegate109(int int_0);
}

