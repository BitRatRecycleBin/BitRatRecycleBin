﻿using Microsoft.VisualBasic.CompilerServices;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using VisualPlus.Toolkit.Controls.Interactivity;
using Zeroit.Framework.Progress;

[DesignerGenerated]
public sealed class fPayment : Form
{
    private IContainer icontainer_0;
    private PictureBox pictureBox_0;
    private StatusStrip statusStrip_0;
    private ToolStripStatusLabel toolStripStatusLabel_0;
    private BackgroundWorker backgroundWorker_0;
    private ZeroitProgressIndicator zeroitProgressIndicator_0;
    private PictureBox pictureBox_1;
    private Label label_0;
    private PictureBox pictureBox_2;
    private Label label_1;
    private Label label_2;
    private Label label_3;
    private Label label_4;
    private Label label_5;
    private Label label_6;
    private Label label_7;
    private Label label_8;
    private PictureBox pictureBox_3;
    private Label label_9;
    private Timer timer_0;
    private Label label_10;
    private BackgroundWorker backgroundWorker_1;
    private PictureBox pictureBox_4;
    private PictureBox pictureBox_5;
    private Label label_11;
    private BackgroundWorker backgroundWorker_2;
    private Label label_12;
    private Label label_13;
    private Label label_14;
    private Label label_15;
    private PictureBox pictureBox_6;
    private PictureBox pictureBox_7;
    private PictureBox pictureBox_8;
    private VisualButton visualButton_0;
    private Label label_16;
    private PictureBox pictureBox_9;
    private Struct18 struct18_0;
    private Struct18 struct18_1;
    private Struct16 struct16_0;
    private string string_0;
    private string string_1;
    private string string_2;
    private string string_3;
    private string string_4;
    private bool bool_0;
    private TimeSpan timeSpan_0;
    private Stopwatch stopwatch_0;
    private int int_0;

    public fPayment();
    [CompilerGenerated]
    private void _Lambda$__R164-1();
    [CompilerGenerated]
    private void _Lambda$__R165-2();
    [CompilerGenerated]
    private void _Lambda$__R166-3();
    [CompilerGenerated]
    private void _Lambda$__R167-4();
    [DebuggerNonUserCode]
    protected override void Dispose(bool disposing);
    private void fPayment_Closing(object sender, CancelEventArgs e);
    private void fPayment_Load(object sender, EventArgs e);
    [DebuggerStepThrough]
    private void InitializeComponent();
    private void method_0(ref string string_5, ref string string_6, ref string string_7);
    private void method_1();
    private void method_10(object sender, EventArgs e);
    private void method_11(object sender, EventArgs e);
    private void method_12(object sender, DoWorkEventArgs e);
    private void method_13(object sender, EventArgs e);
    private void method_14(object sender, DoWorkEventArgs e);
    private void method_15(object sender, EventArgs e);
    private void method_16(object sender, EventArgs e);
    public void method_17(int int_1);
    private void method_18(object sender, DoWorkEventArgs e);
    public void method_19(string string_5);
    private void method_2(string string_5, string string_6);
    private void method_20(object sender, EventArgs e);
    private void method_21(object sender, EventArgs e);
    private void method_22(object sender, EventArgs e);
    private void method_23(object sender, EventArgs e);
    private void method_24(object sender, EventArgs e);
    public void method_25(string string_5, bool bool_1, string string_6, decimal decimal_0);
    private void method_26(object sender, EventArgs e);
    public bool method_3();
    public void method_4();
    public void method_5();
    public void method_6();
    private void method_7(object sender, EventArgs e);
    private void method_8(object sender, EventArgs e);
    private void method_9(object sender, EventArgs e);
    internal virtual PictureBox vmethod_0();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_1(PictureBox pictureBox_10);
    internal virtual PictureBox vmethod_10();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_11(PictureBox pictureBox_10);
    internal virtual Label vmethod_12();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_13(Label label_17);
    internal virtual PictureBox vmethod_14();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_15(PictureBox pictureBox_10);
    internal virtual Label vmethod_16();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_17(Label label_17);
    internal virtual Label vmethod_18();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_19(Label label_17);
    internal virtual StatusStrip vmethod_2();
    internal virtual Label vmethod_20();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_21(Label label_17);
    internal virtual Label vmethod_22();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_23(Label label_17);
    internal virtual Label vmethod_24();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_25(Label label_17);
    internal virtual Label vmethod_26();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_27(Label label_17);
    internal virtual Label vmethod_28();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_29(Label label_17);
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_3(StatusStrip statusStrip_1);
    internal virtual Label vmethod_30();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_31(Label label_17);
    internal virtual PictureBox vmethod_32();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_33(PictureBox pictureBox_10);
    internal virtual Label vmethod_34();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_35(Label label_17);
    internal virtual Timer vmethod_36();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_37(Timer timer_1);
    internal virtual Label vmethod_38();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_39(Label label_17);
    internal virtual ToolStripStatusLabel vmethod_4();
    internal virtual BackgroundWorker vmethod_40();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_41(BackgroundWorker backgroundWorker_3);
    internal virtual PictureBox vmethod_42();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_43(PictureBox pictureBox_10);
    internal virtual PictureBox vmethod_44();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_45(PictureBox pictureBox_10);
    internal virtual Label vmethod_46();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_47(Label label_17);
    internal virtual BackgroundWorker vmethod_48();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_49(BackgroundWorker backgroundWorker_3);
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_5(ToolStripStatusLabel toolStripStatusLabel_1);
    internal virtual Label vmethod_50();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_51(Label label_17);
    internal virtual Label vmethod_52();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_53(Label label_17);
    internal virtual Label vmethod_54();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_55(Label label_17);
    internal virtual Label vmethod_56();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_57(Label label_17);
    internal virtual PictureBox vmethod_58();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_59(PictureBox pictureBox_10);
    internal virtual BackgroundWorker vmethod_6();
    internal virtual PictureBox vmethod_60();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_61(PictureBox pictureBox_10);
    internal virtual PictureBox vmethod_62();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_63(PictureBox pictureBox_10);
    internal virtual VisualButton vmethod_64();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_65(VisualButton visualButton_1);
    internal virtual Label vmethod_66();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_67(Label label_17);
    internal virtual PictureBox vmethod_68();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_69(PictureBox pictureBox_10);
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_7(BackgroundWorker backgroundWorker_3);
    internal virtual ZeroitProgressIndicator vmethod_8();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_9(ZeroitProgressIndicator zeroitProgressIndicator_1);

    private delegate void Delegate150(ref string string_0, ref string string_1, ref string string_2);

    private delegate void Delegate151(string string_0);

    private delegate void Delegate152();

    private delegate void Delegate153();

    private delegate void Delegate154(string string_0, bool bool_0, string string_1, decimal decimal_0);

    private delegate void Delegate155(string string_0, string string_1);

    private delegate void Delegate156(int int_0);
}

