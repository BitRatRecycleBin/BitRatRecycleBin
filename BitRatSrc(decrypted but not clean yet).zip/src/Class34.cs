﻿using System;

internal sealed class Class34 : Class32
{
    private byte byte_0;
    private Class3 class3_0;
    private string string_0;
    private Class3[] class3_1;
    private Class3[] class3_2;
    private Class3 class3_3;

    public byte method_0()
    {
        return this.byte_0;
    }

    public void method_1(byte byte_1)
    {
        this.byte_0 = byte_1;
    }

    public Class3[] method_10()
    {
        return this.class3_2;
    }

    public void method_11(Class3[] class3_4)
    {
        this.class3_2 = class3_4;
    }

    public Class3 method_12()
    {
        return this.class3_3;
    }

    public void method_13(Class3 class3_4)
    {
        this.class3_3 = class3_4;
    }

    public bool method_2()
    {
        return ((this.method_0() & 2) != 0);
    }

    public bool method_3()
    {
        return ((this.method_0() & 1) != 0);
    }

    public Class3 method_4()
    {
        return this.class3_0;
    }

    public void method_5(Class3 class3_4)
    {
        this.class3_0 = class3_4;
    }

    public string method_6()
    {
        return this.string_0;
    }

    public void method_7(string string_1)
    {
        this.string_0 = string_1;
    }

    public Class3[] method_8()
    {
        return this.class3_1;
    }

    public void method_9(Class3[] class3_4)
    {
        this.class3_1 = class3_4;
    }

    public override byte vmethod_0()
    {
        return 4;
    }
}

