﻿internal interface Interface9<T> : Interface8
{
    Interface4<T> imethod_1();
}

