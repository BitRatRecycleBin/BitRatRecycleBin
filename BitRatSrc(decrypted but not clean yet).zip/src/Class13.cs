﻿using System;

internal abstract class Class13 : Interface1
{
    protected static readonly byte[] byte_0 = new byte[0];

    protected Class13()
    {
    }

    public abstract string imethod_0();
    public abstract void imethod_1(bool bool_0, Interface2 interface2_0);
    public virtual byte[] imethod_10(byte[] byte_1)
    {
        return this.imethod_11(byte_1, 0, byte_1.Length);
    }

    public abstract byte[] imethod_11(byte[] byte_1, int int_0, int int_1);
    public virtual int imethod_12(byte[] byte_1, int int_0)
    {
        byte[] buffer = this.imethod_9();
        if ((int_0 + buffer.Length) > byte_1.Length)
        {
            throw new Exception1("output buffer too short");
        }
        buffer.CopyTo(byte_1, int_0);
        return buffer.Length;
    }

    public virtual int imethod_13(byte[] byte_1, byte[] byte_2, int int_0)
    {
        return this.imethod_14(byte_1, 0, byte_1.Length, byte_2, int_0);
    }

    public virtual int imethod_14(byte[] byte_1, int int_0, int int_1, byte[] byte_2, int int_2)
    {
        int num = this.imethod_8(byte_1, int_0, int_1, byte_2, int_2);
        return (num + this.imethod_12(byte_2, int_2 + num));
    }

    public abstract void imethod_15();
    public abstract int imethod_2();
    public abstract int imethod_3(int int_0);
    public abstract int imethod_4(int int_0);
    public virtual byte[] imethod_5(byte[] byte_1)
    {
        return this.imethod_6(byte_1, 0, byte_1.Length);
    }

    public abstract byte[] imethod_6(byte[] byte_1, int int_0, int int_1);
    public virtual int imethod_7(byte[] byte_1, byte[] byte_2, int int_0)
    {
        return this.imethod_8(byte_1, 0, byte_1.Length, byte_2, int_0);
    }

    public virtual int imethod_8(byte[] byte_1, int int_0, int int_1, byte[] byte_2, int int_2)
    {
        byte[] buffer = this.imethod_6(byte_1, int_0, int_1);
        if (buffer == null)
        {
            return 0;
        }
        if ((int_2 + buffer.Length) > byte_2.Length)
        {
            throw new Exception1("output buffer too short");
        }
        buffer.CopyTo(byte_2, int_2);
        return buffer.Length;
    }

    public abstract byte[] imethod_9();
}

