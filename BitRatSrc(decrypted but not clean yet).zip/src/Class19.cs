﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

internal sealed class Class19 : IDisposable, Interface7
{
    private List<byte> list_0 = new List<byte>();

    public void Dispose()
    {
        this.imethod_3();
        this.list_0 = null;
    }

    public int imethod_0()
    {
        return this.list_0.Count;
    }

    public void imethod_1(int int_0, out byte byte_0)
    {
        byte_0 = this.method_0(this.list_0[int_0], int_0);
    }

    public void imethod_2(int int_0, ref byte byte_0)
    {
        for (int i = this.list_0.Count; i <= int_0; i++)
        {
            if (i == int_0)
            {
                this.list_0.Add(this.method_1(byte_0, i));
                return;
            }
            this.list_0.Add(this.method_1(0, i));
        }
        this.list_0[int_0] = this.method_1(byte_0, int_0);
    }

    public void imethod_3()
    {
        this.list_0.Clear();
    }

    public Interface7 imethod_4()
    {
        return new Class19();
    }

    private byte method_0(byte byte_0, int int_0)
    {
        throw new NotImplementedException();
    }

    private byte method_1(byte byte_0, int int_0)
    {
        throw new NotImplementedException();
    }
}

