﻿using System;

internal static class Class54
{
    public static unsafe long smethod_0(string string_0)
    {
        object[] objArray = new object[] { string_0 };
        return *(((long*) Class149.smethod_0().method_256(Class149.smethod_1(), @")&O=/*?7'\", objArray)));
    }

    public static long smethod_1(long long_0)
    {
        // Unresolved stack state at '00000000'
    }

    public static long smethod_2(long? nullable_0)
    {
        // Unresolved stack state at '00000000'
    }
}

