﻿using System;
using System.Threading;

internal sealed class Class2
{
    public readonly string string_0;
    public readonly Class0 class0_0;
    public readonly Class46 class46_0;

    public Class2(string string_1, Class0 class0_1, Class46 class46_1)
    {
        this.string_0 = string_1;
        this.class0_0 = class0_1;
        this.class46_0 = class46_1;
    }

    protected override void Finalize()
    {
        bool lockTaken = false;
        Monitor.Enter(this.class46_0.object_0, ref lockTaken);
        if (!this.class46_0.bool_1)
        {
            this.class46_0.byte_0 = Class63.smethod_1(this.string_0);
            this.class46_0.bool_1 = true;
            Class63.smethod_3(this.string_0);
        }
    }
}

