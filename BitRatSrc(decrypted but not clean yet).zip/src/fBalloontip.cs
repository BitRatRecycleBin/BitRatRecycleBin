﻿using BitRAT;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;

[DesignerGenerated]
public sealed class fBalloontip : Form
{
    private IContainer icontainer_0;
    private PictureBox pictureBox_0;
    private Label label_0;
    private PictureBox pictureBox_1;
    private Label label_1;
    private Label label_2;
    private Label label_3;
    private PictureBox pictureBox_2;
    private BackgroundWorker backgroundWorker_0;
    private BackgroundWorker backgroundWorker_1;
    private BackgroundWorker backgroundWorker_2;
    private BackgroundWorker backgroundWorker_3;
    private Label label_4;
    private string string_0;
    private string string_1;
    private string string_2;
    private string string_3;
    private string string_4;
    private Image image_0;
    private int int_0;
    private int int_1;
    private CClient cclient_0;

    public fBalloontip()
    {
        base.Load += new EventHandler(this.fBalloontip_Load);
        this.InitializeComponent();
    }

    [DebuggerNonUserCode]
    protected override void Dispose(bool disposing)
    {
        if (disposing && (this.icontainer_0 != null))
        {
            this.icontainer_0.Dispose();
        }
    }

    private void fBalloontip_Load(object sender, EventArgs e)
    {
        base.Visible = false;
    }

    [DebuggerStepThrough]
    private void InitializeComponent()
    {
        this.vmethod_1(new PictureBox());
        this.vmethod_3(new Label());
        this.vmethod_5(new PictureBox());
        this.vmethod_7(new Label());
        this.vmethod_9(new Label());
        this.vmethod_11(new Label());
        this.vmethod_13(new PictureBox());
        this.vmethod_15(new BackgroundWorker());
        this.vmethod_17(new BackgroundWorker());
        this.vmethod_19(new BackgroundWorker());
        this.vmethod_21(new BackgroundWorker());
        this.vmethod_23(new Label());
        ((ISupportInitialize) this.vmethod_0()).BeginInit();
        ((ISupportInitialize) this.vmethod_4()).BeginInit();
        ((ISupportInitialize) this.vmethod_12()).BeginInit();
        base.SuspendLayout();
        this.vmethod_0().BorderStyle = BorderStyle.FixedSingle;
        this.vmethod_0().Location = new Point(2, 0);
        this.vmethod_0().Margin = new Padding(2);
        this.vmethod_0().Name = "pbMain";
        this.vmethod_0().Size = new Size(0x181, 0x5e);
        this.vmethod_0().TabIndex = 0x12;
        this.vmethod_0().TabStop = false;
        this.vmethod_2().Anchor = AnchorStyles.Right | AnchorStyles.Left;
        this.vmethod_2().BackColor = Color.Transparent;
        this.vmethod_2().FlatStyle = FlatStyle.Flat;
        this.vmethod_2().Location = new Point(0x21, 4);
        this.vmethod_2().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_2().Name = "lblTitle";
        this.vmethod_2().Size = new Size(0x14e, 14);
        this.vmethod_2().TabIndex = 20;
        this.vmethod_2().Text = "New connection";
        this.vmethod_2().TextAlign = ContentAlignment.MiddleCenter;
        this.vmethod_4().Anchor = AnchorStyles.Right | AnchorStyles.Top;
        this.vmethod_4().Image = Class131.smethod_30();
        this.vmethod_4().Location = new Point(9, 5);
        this.vmethod_4().Margin = new Padding(2);
        this.vmethod_4().Name = "pIcon";
        this.vmethod_4().Size = new Size(13, 13);
        this.vmethod_4().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_4().TabIndex = 0x13;
        this.vmethod_4().TabStop = false;
        this.vmethod_6().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_6().BackColor = Color.Transparent;
        this.vmethod_6().Cursor = Cursors.Hand;
        this.vmethod_6().FlatStyle = FlatStyle.Flat;
        this.vmethod_6().Font = new Font("Microsoft Sans Serif", 8.142858f, FontStyle.Underline, GraphicsUnit.Point, 0);
        this.vmethod_6().ForeColor = Color.DarkSlateBlue;
        this.vmethod_6().Location = new Point(0x15a, 0x4c);
        this.vmethod_6().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_6().Name = "lblOpen";
        this.vmethod_6().Size = new Size(0x24, 14);
        this.vmethod_6().TabIndex = 0x15;
        this.vmethod_6().Text = "Open";
        this.vmethod_6().TextAlign = ContentAlignment.MiddleRight;
        this.vmethod_8().BackColor = Color.Transparent;
        this.vmethod_8().FlatStyle = FlatStyle.Flat;
        this.vmethod_8().Location = new Point(6, 0x34);
        this.vmethod_8().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_8().Name = "lblUser";
        this.vmethod_8().Size = new Size(0x16d, 14);
        this.vmethod_8().TabIndex = 0x16;
        this.vmethod_8().Text = "User: N/A";
        this.vmethod_8().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_10().BackColor = Color.Transparent;
        this.vmethod_10().FlatStyle = FlatStyle.Flat;
        this.vmethod_10().Location = new Point(6, 0x4c);
        this.vmethod_10().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_10().Name = "lblActiveWindow";
        this.vmethod_10().Size = new Size(330, 14);
        this.vmethod_10().TabIndex = 0x17;
        this.vmethod_10().Text = "Window: N/A";
        this.vmethod_10().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_12().Anchor = AnchorStyles.Right | AnchorStyles.Top;
        this.vmethod_12().Location = new Point(370, 5);
        this.vmethod_12().Margin = new Padding(2);
        this.vmethod_12().Name = "pbType";
        this.vmethod_12().Size = new Size(13, 13);
        this.vmethod_12().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_12().TabIndex = 0x18;
        this.vmethod_12().TabStop = false;
        this.vmethod_22().BackColor = Color.Transparent;
        this.vmethod_22().FlatStyle = FlatStyle.Flat;
        this.vmethod_22().Location = new Point(6, 0x1c);
        this.vmethod_22().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_22().Name = "lblIP";
        this.vmethod_22().Size = new Size(0x16d, 14);
        this.vmethod_22().TabIndex = 0x19;
        this.vmethod_22().Text = "IP: N/A";
        this.vmethod_22().TextAlign = ContentAlignment.MiddleLeft;
        base.AutoScaleDimensions = new SizeF(6f, 13f);
        base.AutoScaleMode = AutoScaleMode.Font;
        this.BackColor = Color.LightSkyBlue;
        base.ClientSize = new Size(0x185, 0x5f);
        base.Controls.Add(this.vmethod_22());
        base.Controls.Add(this.vmethod_12());
        base.Controls.Add(this.vmethod_10());
        base.Controls.Add(this.vmethod_8());
        base.Controls.Add(this.vmethod_6());
        base.Controls.Add(this.vmethod_2());
        base.Controls.Add(this.vmethod_4());
        base.Controls.Add(this.vmethod_0());
        this.DoubleBuffered = true;
        base.FormBorderStyle = FormBorderStyle.None;
        base.Margin = new Padding(2);
        base.Name = "fBalloontip";
        base.Opacity = 0.0;
        base.ShowIcon = false;
        base.ShowInTaskbar = false;
        ((ISupportInitialize) this.vmethod_0()).EndInit();
        ((ISupportInitialize) this.vmethod_4()).EndInit();
        ((ISupportInitialize) this.vmethod_12()).EndInit();
        base.ResumeLayout(false);
    }

    private void method_0()
    {
        base.Visible = true;
        base.Activate();
        base.Top = (Screen.PrimaryScreen.Bounds.Height - this.int_1) - 1;
        base.Left = Screen.PrimaryScreen.Bounds.Width - base.Width;
        this.vmethod_0().Top = 0;
        this.vmethod_0().Left = 0;
        this.vmethod_0().Width = base.Width;
        this.vmethod_0().Height = base.Height;
        this.vmethod_12().Image = this.image_0;
        this.vmethod_2().Text = this.string_1;
        this.vmethod_22().Text = "Host: " + this.string_2;
        this.vmethod_8().Text = "User: " + this.string_3;
        this.vmethod_10().Text = "Window: " + this.string_4;
        this.vmethod_14().RunWorkerAsync();
    }

    public void method_1(string string_5, string string_6, string string_7, string string_8, string string_9, Image image_1)
    {
        this.string_0 = string_5;
        this.string_1 = string_6;
        this.string_2 = string_7;
        this.string_3 = string_8;
        this.string_4 = string_9;
        this.image_0 = image_1;
        this.int_1 = Class145.smethod_0().Screen.Bounds.Height - Class145.smethod_0().Screen.WorkingArea.Height;
        this.method_0();
    }

    private void method_10(object sender, DoWorkEventArgs e)
    {
        Thread.Sleep(0xbb8);
        this.vmethod_16().RunWorkerAsync();
        this.int_0 = 0;
        while (this.int_0 < 100)
        {
            ref int numRef;
            *(numRef = ref this.int_0) = numRef + 1;
            this.method_8(this.int_0);
            Thread.Sleep(1);
        }
        this.vmethod_18().RunWorkerAsync();
    }

    private void method_11(object sender, DoWorkEventArgs e)
    {
        int height = base.Height;
        for (int i = 1; i <= height; i++)
        {
            this.method_9(1);
            Thread.Sleep(1);
        }
    }

    public void method_12()
    {
        if (base.InvokeRequired)
        {
            base.Invoke(new Delegate85(this.method_12), new object[0]);
        }
        else
        {
            base.Close();
        }
    }

    private void method_13(object sender, EventArgs e)
    {
        CClient client;
        Form fDB;
        Form form2;
        bool flag;
        Rectangle rectangle;
        CClient client1;
        base.Visible = false;
        if (client.fDB == null)
        {
            client.fDB = new fDashboard();
            client.fDB.method_1(ref client.sock_async, ref client.sIP, ref client.sPort, ref client.sLANIP, ref client.sUser, ref client.sSettingPassword);
            client.fDB.Show();
            flag = false;
            form2 = Class130.fMain_0;
            fDB = client.fDB;
            CClient client2 = client = Class130.concurrentDictionary_3[this.string_0];
            rectangle = (form2 == null) ? Screen.FromPoint(fDB.Location).WorkingArea : form2.RectangleToScreen(form2.ClientRectangle);
            fDB.Location = new Point(rectangle.Left + ((rectangle.Width - fDB.Width) / 2), rectangle.Top + ((rectangle.Height - fDB.Height) / 2));
            if (flag)
            {
                fDB.Visible = true;
            }
            client1 = client2;
        }
        else if (!client.fDB.Visible)
        {
            client.fDB.method_147();
            flag = false;
            form2 = Class130.fMain_0;
            fDB = client.fDB;
            CClient client3 = client = Class130.concurrentDictionary_3[this.string_0];
            rectangle = (form2 == null) ? Screen.FromPoint(fDB.Location).WorkingArea : form2.RectangleToScreen(form2.ClientRectangle);
            fDB.Location = new Point(rectangle.Left + ((rectangle.Width - fDB.Width) / 2), rectangle.Top + ((rectangle.Height - fDB.Height) / 2));
            if (flag)
            {
                fDB.Visible = true;
            }
            client1 = client3;
        }
        client1.fDB.Activate();
    }

    private void method_14(object sender, DoWorkEventArgs e)
    {
        Thread.Sleep(0x1388);
        int num = this.int_1 + base.Height;
        for (int i = 1; i <= num; i++)
        {
            this.method_9(-1);
            Thread.Sleep(1);
        }
        this.method_12();
    }

    private void method_15(object sender, DoWorkEventArgs e)
    {
        int num = this.int_1 + base.Height;
        for (int i = 1; i <= num; i++)
        {
            this.method_9(-1);
            Thread.Sleep(1);
        }
        this.method_12();
    }

    private void method_2(object sender, EventArgs e)
    {
        this.vmethod_20().RunWorkerAsync();
    }

    private void method_3(object sender, EventArgs e)
    {
        this.vmethod_20().RunWorkerAsync();
    }

    private void method_4(object sender, EventArgs e)
    {
        this.vmethod_20().RunWorkerAsync();
    }

    private void method_5(object sender, EventArgs e)
    {
        this.vmethod_20().RunWorkerAsync();
    }

    private void method_6(object sender, EventArgs e)
    {
        this.vmethod_20().RunWorkerAsync();
    }

    private void method_7(object sender, EventArgs e)
    {
        this.vmethod_20().RunWorkerAsync();
    }

    public void method_8(int int_2)
    {
        // Unresolved stack state at '00000008'
    }

    public void method_9(int int_2)
    {
        // Unresolved stack state at '00000008'
    }

    internal virtual PictureBox vmethod_0()
    {
        return this.pictureBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_1(PictureBox pictureBox_3)
    {
        EventHandler handler = new EventHandler(this.method_2);
        PictureBox box = this.pictureBox_0;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_0 = pictureBox_3;
        box = this.pictureBox_0;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual Label vmethod_10()
    {
        return this.label_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_11(Label label_5)
    {
        EventHandler handler = new EventHandler(this.method_6);
        Label label = this.label_3;
        if (label != null)
        {
            label.Click -= handler;
        }
        this.label_3 = label_5;
        label = this.label_3;
        if (label != null)
        {
            label.Click += handler;
        }
    }

    internal virtual PictureBox vmethod_12()
    {
        return this.pictureBox_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_13(PictureBox pictureBox_3)
    {
        EventHandler handler = new EventHandler(this.method_7);
        PictureBox box = this.pictureBox_2;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_2 = pictureBox_3;
        box = this.pictureBox_2;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual BackgroundWorker vmethod_14()
    {
        return this.backgroundWorker_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_15(BackgroundWorker backgroundWorker_4)
    {
        DoWorkEventHandler handler = new DoWorkEventHandler(this.method_10);
        BackgroundWorker worker = this.backgroundWorker_0;
        if (worker != null)
        {
            worker.DoWork -= handler;
        }
        this.backgroundWorker_0 = backgroundWorker_4;
        worker = this.backgroundWorker_0;
        if (worker != null)
        {
            worker.DoWork += handler;
        }
    }

    internal virtual BackgroundWorker vmethod_16()
    {
        return this.backgroundWorker_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_17(BackgroundWorker backgroundWorker_4)
    {
        DoWorkEventHandler handler = new DoWorkEventHandler(this.method_11);
        BackgroundWorker worker = this.backgroundWorker_1;
        if (worker != null)
        {
            worker.DoWork -= handler;
        }
        this.backgroundWorker_1 = backgroundWorker_4;
        worker = this.backgroundWorker_1;
        if (worker != null)
        {
            worker.DoWork += handler;
        }
    }

    internal virtual BackgroundWorker vmethod_18()
    {
        return this.backgroundWorker_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_19(BackgroundWorker backgroundWorker_4)
    {
        DoWorkEventHandler handler = new DoWorkEventHandler(this.method_14);
        BackgroundWorker worker = this.backgroundWorker_2;
        if (worker != null)
        {
            worker.DoWork -= handler;
        }
        this.backgroundWorker_2 = backgroundWorker_4;
        worker = this.backgroundWorker_2;
        if (worker != null)
        {
            worker.DoWork += handler;
        }
    }

    internal virtual Label vmethod_2()
    {
        return this.label_0;
    }

    internal virtual BackgroundWorker vmethod_20()
    {
        return this.backgroundWorker_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_21(BackgroundWorker backgroundWorker_4)
    {
        DoWorkEventHandler handler = new DoWorkEventHandler(this.method_15);
        BackgroundWorker worker = this.backgroundWorker_3;
        if (worker != null)
        {
            worker.DoWork -= handler;
        }
        this.backgroundWorker_3 = backgroundWorker_4;
        worker = this.backgroundWorker_3;
        if (worker != null)
        {
            worker.DoWork += handler;
        }
    }

    internal virtual Label vmethod_22()
    {
        return this.label_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_23(Label label_5)
    {
        this.label_4 = label_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_3(Label label_5)
    {
        EventHandler handler = new EventHandler(this.method_4);
        Label label = this.label_0;
        if (label != null)
        {
            label.Click -= handler;
        }
        this.label_0 = label_5;
        label = this.label_0;
        if (label != null)
        {
            label.Click += handler;
        }
    }

    internal virtual PictureBox vmethod_4()
    {
        return this.pictureBox_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_5(PictureBox pictureBox_3)
    {
        EventHandler handler = new EventHandler(this.method_3);
        PictureBox box = this.pictureBox_1;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_1 = pictureBox_3;
        box = this.pictureBox_1;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual Label vmethod_6()
    {
        return this.label_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_7(Label label_5)
    {
        EventHandler handler = new EventHandler(this.method_13);
        Label label = this.label_1;
        if (label != null)
        {
            label.Click -= handler;
        }
        this.label_1 = label_5;
        label = this.label_1;
        if (label != null)
        {
            label.Click += handler;
        }
    }

    internal virtual Label vmethod_8()
    {
        return this.label_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_9(Label label_5)
    {
        EventHandler handler = new EventHandler(this.method_5);
        Label label = this.label_2;
        if (label != null)
        {
            label.Click -= handler;
        }
        this.label_2 = label_5;
        label = this.label_2;
        if (label != null)
        {
            label.Click += handler;
        }
    }

    private delegate void Delegate85();

    private delegate void Delegate86(int int_0);

    private delegate void Delegate87(int int_0);
}

