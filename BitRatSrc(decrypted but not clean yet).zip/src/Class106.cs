﻿using System;

internal abstract class Class106 : Class94
{
    protected Class106()
    {
    }

    public override object vmethod_0()
    {
        throw new InvalidOperationException();
    }

    public override void vmethod_1(object object_0)
    {
        throw new InvalidOperationException();
    }
}

