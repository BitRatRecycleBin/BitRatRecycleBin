﻿using System;

internal sealed class Class24<T>
{
    public static readonly int int_0;

    static Class24()
    {
        Class24<T>.int_0 = Buffer.ByteLength(new T[1]);
    }
}

