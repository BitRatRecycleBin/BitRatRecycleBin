﻿using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

[DesignerGenerated]
public sealed class fAbout : Form
{
    private IContainer icontainer_0;
    private PictureBox pictureBox_0;
    private PictureBox pictureBox_1;
    private PictureBox pictureBox_2;
    private Label label_0;
    private Label label_1;
    private Label label_2;
    private Label label_3;
    private Label label_4;
    private Label label_5;
    private PictureBox pictureBox_3;
    private Label label_6;
    private Label label_7;
    private Label label_8;

    public fAbout()
    {
        base.Load += new EventHandler(this.fAbout_Load);
        base.Closing += new CancelEventHandler(this.fAbout_Closing);
        this.InitializeComponent();
    }

    [DebuggerNonUserCode]
    protected override void Dispose(bool disposing)
    {
        if (disposing && (this.icontainer_0 != null))
        {
            this.icontainer_0.Dispose();
        }
    }

    private void fAbout_Closing(object sender, CancelEventArgs e)
    {
        base.Visible = false;
        e.Cancel = true;
    }

    private void fAbout_Load(object sender, EventArgs e)
    {
        this.method_0();
        this.vmethod_6().Text = Class130.struct3_6.method_1();
        this.vmethod_4().Left = (this.vmethod_6().Left + this.vmethod_6().Width) + 2;
        this.vmethod_2().Left = (this.vmethod_4().Left + this.vmethod_4().Width) + 3;
        this.vmethod_18().Left = (this.vmethod_14().Left + this.vmethod_14().Width) + 2;
    }

    [DebuggerStepThrough]
    private void InitializeComponent()
    {
        ComponentResourceManager manager = new ComponentResourceManager(typeof(fAbout));
        this.vmethod_7(new Label());
        this.vmethod_9(new Label());
        this.vmethod_3(new PictureBox());
        this.vmethod_5(new PictureBox());
        this.vmethod_1(new PictureBox());
        this.vmethod_11(new Label());
        this.vmethod_13(new Label());
        this.vmethod_15(new Label());
        this.vmethod_17(new Label());
        this.vmethod_19(new PictureBox());
        this.vmethod_21(new Label());
        this.vmethod_23(new Label());
        this.vmethod_25(new Label());
        ((ISupportInitialize) this.vmethod_2()).BeginInit();
        ((ISupportInitialize) this.vmethod_4()).BeginInit();
        ((ISupportInitialize) this.vmethod_0()).BeginInit();
        ((ISupportInitialize) this.vmethod_18()).BeginInit();
        base.SuspendLayout();
        this.vmethod_6().AutoSize = true;
        this.vmethod_6().BackColor = Color.Transparent;
        this.vmethod_6().ForeColor = Color.RoyalBlue;
        this.vmethod_6().Location = new Point(0x22, 0x9e);
        this.vmethod_6().Name = "lblURL";
        this.vmethod_6().Size = new Size(0x1b, 13);
        this.vmethod_6().TabIndex = 0x33;
        this.vmethod_6().Text = "N/A";
        this.vmethod_8().AutoSize = true;
        this.vmethod_8().BackColor = Color.Transparent;
        this.vmethod_8().Location = new Point(8, 0x9e);
        this.vmethod_8().Name = "lblVisit";
        this.vmethod_8().Size = new Size(0x20, 13);
        this.vmethod_8().TabIndex = 50;
        this.vmethod_8().Text = "Visit: ";
        this.vmethod_2().Image = Class131.smethod_50();
        this.vmethod_2().Location = new Point(0x55, 0x9e);
        this.vmethod_2().Margin = new Padding(2);
        this.vmethod_2().Name = "pbInfo";
        this.vmethod_2().Size = new Size(15, 15);
        this.vmethod_2().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_2().TabIndex = 0x35;
        this.vmethod_2().TabStop = false;
        this.vmethod_4().Image = Class131.smethod_33();
        this.vmethod_4().Location = new Point(0x42, 0x9e);
        this.vmethod_4().Margin = new Padding(2);
        this.vmethod_4().Name = "pbCopy";
        this.vmethod_4().Size = new Size(15, 15);
        this.vmethod_4().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_4().TabIndex = 0x34;
        this.vmethod_4().TabStop = false;
        this.vmethod_0().BackColor = Color.Transparent;
        this.vmethod_0().Image = Class131.smethod_30();
        this.vmethod_0().Location = new Point(11, 11);
        this.vmethod_0().Margin = new Padding(2);
        this.vmethod_0().Name = "pbMainPort";
        this.vmethod_0().Size = new Size(50, 50);
        this.vmethod_0().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_0().TabIndex = 0x29;
        this.vmethod_0().TabStop = false;
        this.vmethod_10().AutoSize = true;
        this.vmethod_10().BackColor = Color.Transparent;
        this.vmethod_10().Location = new Point(0x8d, 0x3e);
        this.vmethod_10().Name = "lblCurrVersionPre";
        this.vmethod_10().Size = new Size(0x2d, 13);
        this.vmethod_10().TabIndex = 0x36;
        this.vmethod_10().Text = "Version:";
        this.vmethod_12().AutoSize = true;
        this.vmethod_12().BackColor = Color.Transparent;
        this.vmethod_12().Location = new Point(0x79, 0x56);
        this.vmethod_12().Name = "lblHWIDPre";
        this.vmethod_12().Size = new Size(0x41, 13);
        this.vmethod_12().TabIndex = 0x37;
        this.vmethod_12().Text = "Your HWID:";
        this.vmethod_14().AutoSize = true;
        this.vmethod_14().BackColor = Color.Transparent;
        this.vmethod_14().Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
        this.vmethod_14().ForeColor = Color.RoyalBlue;
        this.vmethod_14().Location = new Point(0xb9, 0x56);
        this.vmethod_14().Name = "lblHWID";
        this.vmethod_14().Size = new Size(30, 13);
        this.vmethod_14().TabIndex = 0x38;
        this.vmethod_14().Text = "N/A";
        this.vmethod_16().AutoSize = true;
        this.vmethod_16().BackColor = Color.Transparent;
        this.vmethod_16().Location = new Point(0xb9, 0x3e);
        this.vmethod_16().Name = "lblVersion";
        this.vmethod_16().Size = new Size(0x1b, 13);
        this.vmethod_16().TabIndex = 0x39;
        this.vmethod_16().Text = "N/A";
        this.vmethod_18().Image = Class131.smethod_33();
        this.vmethod_18().Location = new Point(220, 0x55);
        this.vmethod_18().Margin = new Padding(2);
        this.vmethod_18().Name = "pbCopyHWID";
        this.vmethod_18().Size = new Size(15, 15);
        this.vmethod_18().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_18().TabIndex = 0x3a;
        this.vmethod_18().TabStop = false;
        this.vmethod_20().AutoSize = true;
        this.vmethod_20().BackColor = Color.Transparent;
        this.vmethod_20().Location = new Point(0x6c, 110);
        this.vmethod_20().Name = "Label1";
        this.vmethod_20().Size = new Size(0x4e, 13);
        this.vmethod_20().TabIndex = 0x3b;
        this.vmethod_20().Text = "License status:";
        this.vmethod_22().AutoSize = true;
        this.vmethod_22().BackColor = Color.Transparent;
        this.vmethod_22().ForeColor = Color.Green;
        this.vmethod_22().Location = new Point(0xb9, 110);
        this.vmethod_22().Name = "lblLicenseStatus";
        this.vmethod_22().Size = new Size(0x1b, 13);
        this.vmethod_22().TabIndex = 60;
        this.vmethod_22().Text = "N/A";
        this.vmethod_24().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
        this.vmethod_24().BackColor = Color.Transparent;
        this.vmethod_24().Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
        this.vmethod_24().Location = new Point(11, 11);
        this.vmethod_24().Name = "lblTitle";
        this.vmethod_24().Size = new Size(360, 0x17);
        this.vmethod_24().TabIndex = 0x3d;
        this.vmethod_24().Text = "About";
        this.vmethod_24().TextAlign = ContentAlignment.TopCenter;
        base.AutoScaleDimensions = new SizeF(6f, 13f);
        base.AutoScaleMode = AutoScaleMode.Font;
        this.BackColor = SystemColors.AppWorkspace;
        base.ClientSize = new Size(0x17f, 0xb3);
        base.Controls.Add(this.vmethod_22());
        base.Controls.Add(this.vmethod_20());
        base.Controls.Add(this.vmethod_18());
        base.Controls.Add(this.vmethod_16());
        base.Controls.Add(this.vmethod_14());
        base.Controls.Add(this.vmethod_12());
        base.Controls.Add(this.vmethod_10());
        base.Controls.Add(this.vmethod_2());
        base.Controls.Add(this.vmethod_4());
        base.Controls.Add(this.vmethod_6());
        base.Controls.Add(this.vmethod_8());
        base.Controls.Add(this.vmethod_0());
        base.Controls.Add(this.vmethod_24());
        this.DoubleBuffered = true;
        base.FormBorderStyle = FormBorderStyle.FixedToolWindow;
        base.Icon = (Icon) manager.GetObject("$this.Icon");
        base.MaximizeBox = false;
        base.MinimizeBox = false;
        base.Name = "fAbout";
        base.Opacity = 0.0;
        base.ShowIcon = false;
        base.ShowInTaskbar = false;
        base.StartPosition = FormStartPosition.CenterParent;
        this.Text = "About";
        base.TopMost = true;
        ((ISupportInitialize) this.vmethod_2()).EndInit();
        ((ISupportInitialize) this.vmethod_4()).EndInit();
        ((ISupportInitialize) this.vmethod_0()).EndInit();
        ((ISupportInitialize) this.vmethod_18()).EndInit();
        base.ResumeLayout(false);
        base.PerformLayout();
    }

    private void method_0()
    {
        object[] objArray = new object[] { this };
        Class149.smethod_0().method_139(Class149.smethod_1(), @")&O:]*?=\m", objArray);
    }

    private void method_1(object sender, EventArgs e)
    {
        Clipboard.Clear();
        Clipboard.SetText(this.vmethod_6().Text);
        Interaction.MsgBox("URL copied to clipboard!", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_2(object sender, EventArgs e)
    {
        if (MessageBox.Show("The URL cannot be visited from a regular web browser without configuring a proxy.\r\n\r\nTherefore, it is recommended to use TorBrowser.\r\nIt's very simple!\r\n\r\nNavigate to https://www.torproject.org/download/?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
        {
            Process.Start("https://www.torproject.org/download/");
        }
    }

    private void method_3(object sender, EventArgs e)
    {
        Clipboard.Clear();
        Clipboard.SetText(this.vmethod_6().Text);
        Interaction.MsgBox("URL copied to clipboard!\r\nPlease, visit it from TorBrowser!", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_4(object sender, EventArgs e)
    {
        Clipboard.Clear();
        Clipboard.SetText(this.vmethod_14().Text);
        Interaction.MsgBox("HWID copied to clipboard!", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_5(object sender, EventArgs e)
    {
        Clipboard.Clear();
        Clipboard.SetText(this.vmethod_14().Text);
        Interaction.MsgBox("HWID copied to clipboard!", MsgBoxStyle.Information, Application.ProductName);
    }

    internal virtual PictureBox vmethod_0()
    {
        return this.pictureBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_1(PictureBox pictureBox_4)
    {
        this.pictureBox_0 = pictureBox_4;
    }

    internal virtual Label vmethod_10()
    {
        return this.label_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_11(Label label_9)
    {
        this.label_2 = label_9;
    }

    internal virtual Label vmethod_12()
    {
        return this.label_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_13(Label label_9)
    {
        this.label_3 = label_9;
    }

    internal virtual Label vmethod_14()
    {
        return this.label_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_15(Label label_9)
    {
        EventHandler handler = new EventHandler(this.method_4);
        Label label = this.label_4;
        if (label != null)
        {
            label.Click -= handler;
        }
        this.label_4 = label_9;
        label = this.label_4;
        if (label != null)
        {
            label.Click += handler;
        }
    }

    internal virtual Label vmethod_16()
    {
        return this.label_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_17(Label label_9)
    {
        this.label_5 = label_9;
    }

    internal virtual PictureBox vmethod_18()
    {
        return this.pictureBox_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_19(PictureBox pictureBox_4)
    {
        EventHandler handler = new EventHandler(this.method_5);
        PictureBox box = this.pictureBox_3;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_3 = pictureBox_4;
        box = this.pictureBox_3;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual PictureBox vmethod_2()
    {
        return this.pictureBox_1;
    }

    internal virtual Label vmethod_20()
    {
        return this.label_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_21(Label label_9)
    {
        this.label_6 = label_9;
    }

    internal virtual Label vmethod_22()
    {
        return this.label_7;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_23(Label label_9)
    {
        this.label_7 = label_9;
    }

    internal virtual Label vmethod_24()
    {
        return this.label_8;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_25(Label label_9)
    {
        this.label_8 = label_9;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_3(PictureBox pictureBox_4)
    {
        EventHandler handler = new EventHandler(this.method_2);
        PictureBox box = this.pictureBox_1;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_1 = pictureBox_4;
        box = this.pictureBox_1;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual PictureBox vmethod_4()
    {
        return this.pictureBox_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_5(PictureBox pictureBox_4)
    {
        EventHandler handler = new EventHandler(this.method_1);
        PictureBox box = this.pictureBox_2;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_2 = pictureBox_4;
        box = this.pictureBox_2;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual Label vmethod_6()
    {
        return this.label_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_7(Label label_9)
    {
        EventHandler handler = new EventHandler(this.method_3);
        Label label = this.label_0;
        if (label != null)
        {
            label.Click -= handler;
        }
        this.label_0 = label_9;
        label = this.label_0;
        if (label != null)
        {
            label.Click += handler;
        }
    }

    internal virtual Label vmethod_8()
    {
        return this.label_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_9(Label label_9)
    {
        this.label_1 = label_9;
    }
}

