﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading;

[StructLayout(LayoutKind.Sequential)]
internal struct Struct3
{
    private static readonly ConditionalWeakTable<string, Class2> conditionalWeakTable_0;
    private static readonly object object_0;
    private Class62 class62_0;
    public Struct3(string string_0)
    {
        Class62 class1 = new Class62();
        class1.class0_0 = Class63.smethod_0(string_0);
        this.class62_0 = class1;
    }

    static Struct3()
    {
        conditionalWeakTable_0 = new ConditionalWeakTable<string, Class2>();
        object_0 = new object();
    }

    private bool method_0(out string string_0)
    {
        Class0 class1;
        object target;
        string_0 = null;
        if (this.class62_0 != null)
        {
            class1 = this.class62_0.class0_0;
        }
        else
        {
            Class62 local1 = this.class62_0;
            class1 = null;
        }
        Class0 class2 = class1;
        if (class2 == null)
        {
            return true;
        }
        if (class2.weakReference_0 != null)
        {
            target = class2.weakReference_0.Target;
        }
        else
        {
            WeakReference local2 = class2.weakReference_0;
            target = null;
        }
        string_0 = target as string;
        return (string_0 != null);
    }

    public string method_1()
    {
        string str;
        if (!this.method_0(out str))
        {
            bool lockTaken = false;
            Monitor.Enter(object_0, ref lockTaken);
            if (this.method_0(out str))
            {
                return str;
            }
            Class46 class2 = this.class62_0.class0_0.class46_0;
            bool flag2 = false;
            Monitor.Enter(class2.object_0, ref flag2);
            byte[] buffer = class2.byte_0;
            bool flag3 = class2.bool_0;
            if (class2.bool_1)
            {
                if (buffer == null)
                {
                    throw new Exception("Unable to decrypt string data: encrypted value is null");
                }
            }
            else
            {
                object target;
                if (this.class62_0.class0_0.weakReference_1 != null)
                {
                    target = this.class62_0.class0_0.weakReference_1.Target;
                }
                else
                {
                    WeakReference local1 = this.class62_0.class0_0.weakReference_1;
                    target = null;
                }
                string text1 = target as string;
                if (text1 == null)
                {
                    throw new Exception("Unable to obtain original string data");
                }
                string local2 = text1;
                str = string.Copy(local2);
                Class63.smethod_3(local2);
            }
            class2.bool_1 = true;
            if (str == null)
            {
                str = Class63.smethod_2(buffer, flag3);
            }
            this.method_2(str);
        }
        return str;
    }

    private void method_2(string string_0)
    {
        Class2 class2;
        if (!conditionalWeakTable_0.TryGetValue(string_0, out class2))
        {
            Class0 class1 = new Class0();
            class1.class46_0 = new Class46();
            class1.weakReference_0 = new WeakReference(string_0);
            class1.weakReference_1 = new WeakReference(string_0, true);
            Class0 class3 = class1;
            class2 = new Class2(string_0, class3, class3.class46_0);
            conditionalWeakTable_0.Add(string_0, class2);
        }
        this.class62_0.class0_0 = class2.class0_0;
    }

    public void method_3(string string_0)
    {
        bool lockTaken = false;
        Monitor.Enter(object_0, ref lockTaken);
        if (string_0 == null)
        {
            this.class62_0 = null;
        }
        else
        {
            this.class62_0 = new Class62();
            this.method_2(string_0);
        }
    }

    public void method_4()
    {
        this.method_3(null);
    }
}

