﻿using System;

internal sealed class Class120 : Class94
{
    private ulong ulong_0;

    public ulong method_2()
    {
        return this.ulong_0;
    }

    public void method_3(ulong ulong_1)
    {
        this.ulong_0 = ulong_1;
    }

    public override object vmethod_0()
    {
        return this.method_2();
    }

    public override void vmethod_1(object object_0)
    {
        if (object_0 is short)
        {
            this.method_3((ulong) ((short) object_0));
        }
        else if (object_0 is int)
        {
            this.method_3((ulong) ((int) object_0));
        }
        else if (object_0 is long)
        {
            this.method_3((ulong) ((long) object_0));
        }
        else if (object_0 is float)
        {
            this.method_3((ulong) ((float) object_0));
        }
        else if (object_0 is double)
        {
            this.method_3((ulong) ((double) object_0));
        }
        else
        {
            this.method_3(Convert.ToUInt64(object_0));
        }
    }

    public override int vmethod_2()
    {
        return 0x13;
    }

    public override Class94 vmethod_3(Class94 class94_0)
    {
        base.method_1(class94_0.method_0());
        switch (class94_0.vmethod_2())
        {
            case 0:
                this.method_3((ulong) ((Class119) class94_0).method_2());
                break;

            case 2:
                this.method_3((ulong) Convert.ToByte(((Class103) class94_0).method_2()));
                break;

            case 4:
                this.method_3(Convert.ToUInt64(((Class102) class94_0).method_2()));
                break;

            case 7:
                this.method_3((ulong) ((Class118) class94_0).method_2());
                break;

            case 8:
                this.method_3((ulong) ((Class100) class94_0).method_2());
                break;

            case 9:
                this.method_3((ulong) ((Class115) class94_0).method_2());
                break;

            case 10:
                this.method_3((ulong) ((Class114) class94_0).method_2());
                break;

            case 11:
                this.method_3((ulong) ((Class99) class94_0).method_2());
                break;

            case 14:
                this.method_3((ulong) ((long) ((Class105) class94_0).method_2()));
                break;

            case 15:
                this.method_3((ulong) ((Class101) class94_0).method_2());
                break;

            case 0x11:
                this.method_3((ulong) ((Class117) class94_0).method_2());
                break;

            case 0x13:
                this.method_3(((Class120) class94_0).method_2());
                break;

            case 0x15:
                this.method_3((ulong) ((Class104) class94_0).method_2());
                break;

            case 0x16:
                this.method_3((ulong) ((Class121) class94_0).method_2());
                break;

            case 0x18:
                this.method_3(Convert.ToUInt64(((Class98) class94_0).method_2()));
                break;

            default:
                throw new ArgumentOutOfRangeException();
        }
        return this;
    }

    public override Class94 vmethod_4()
    {
        Class120 class1 = new Class120();
        class1.method_3(this.ulong_0);
        class1.method_1(base.method_0());
        return class1;
    }
}

