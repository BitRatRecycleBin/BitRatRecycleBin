﻿using System;

internal sealed class Class112 : Class106
{
    private Class94 class94_0;

    public Class94 method_2()
    {
        return this.class94_0;
    }

    public void method_3(Class94 class94_1)
    {
        this.class94_0 = class94_1;
    }

    public override int vmethod_2()
    {
        return 12;
    }

    public override Class94 vmethod_3(Class94 class94_1)
    {
        base.method_1(class94_1.method_0());
        if (class94_1.vmethod_2() != 12)
        {
            throw new ArgumentOutOfRangeException();
        }
        this.method_3(((Class112) class94_1).method_2());
        return this;
    }

    public override Class94 vmethod_4()
    {
        Class112 class1 = new Class112();
        class1.method_3(this.method_2());
        class1.method_1(base.method_0());
        return class1;
    }
}

