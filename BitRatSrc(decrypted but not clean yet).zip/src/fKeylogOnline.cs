﻿using Microsoft.VisualBasic.CompilerServices;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

[DesignerGenerated]
public sealed class fKeylogOnline : Form
{
    private IContainer icontainer_0;
    private RichTextBox richTextBox_0;

    public fKeylogOnline()
    {
        base.Closing += new CancelEventHandler(this.fKeylogOnline_Closing);
        this.InitializeComponent();
    }

    [DebuggerNonUserCode]
    protected override void Dispose(bool disposing)
    {
        if (disposing && (this.icontainer_0 != null))
        {
            this.icontainer_0.Dispose();
        }
    }

    private void fKeylogOnline_Closing(object sender, CancelEventArgs e)
    {
        base.Visible = false;
        e.Cancel = true;
    }

    [DebuggerStepThrough]
    private void InitializeComponent()
    {
        this.vmethod_1(new RichTextBox());
        base.SuspendLayout();
        this.vmethod_0().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
        this.vmethod_0().BackColor = Color.White;
        this.vmethod_0().Location = new Point(1, 2);
        this.vmethod_0().Margin = new Padding(2);
        this.vmethod_0().Name = "rtKeylogOnline";
        this.vmethod_0().ReadOnly = true;
        this.vmethod_0().ScrollBars = RichTextBoxScrollBars.Vertical;
        this.vmethod_0().Size = new Size(0x2ac, 0x145);
        this.vmethod_0().TabIndex = 2;
        this.vmethod_0().Text = string.Empty;
        base.AutoScaleDimensions = new SizeF(6f, 13f);
        base.AutoScaleMode = AutoScaleMode.Font;
        this.BackColor = SystemColors.AppWorkspace;
        base.ClientSize = new Size(0x2ad, 0x148);
        base.Controls.Add(this.vmethod_0());
        base.Name = "fKeylogOnline";
        base.Opacity = 0.0;
        base.ShowIcon = false;
        this.Text = "Online keylog";
        base.ResumeLayout(false);
    }

    internal virtual RichTextBox vmethod_0()
    {
        return this.richTextBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_1(RichTextBox richTextBox_1)
    {
        this.richTextBox_0 = richTextBox_1;
    }
}

