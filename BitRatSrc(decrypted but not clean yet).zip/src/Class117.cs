﻿using System;

internal sealed class Class117 : Class94
{
    private double double_0;

    public double method_2()
    {
        return this.double_0;
    }

    public void method_3(double double_1)
    {
        this.double_0 = double_1;
    }

    public override object vmethod_0()
    {
        return this.method_2();
    }

    public override void vmethod_1(object object_0)
    {
        this.method_3(Convert.ToDouble(object_0));
    }

    public override int vmethod_2()
    {
        return 0x11;
    }

    public override Class94 vmethod_3(Class94 class94_0)
    {
        base.method_1(class94_0.method_0());
        int num = class94_0.vmethod_2();
        if (num == 0)
        {
            this.method_3((double) ((Class119) class94_0).method_2());
        }
        else
        {
            switch (num)
            {
                case 4:
                    this.method_3((double) ((Class102) class94_0).method_2());
                    break;

                case 7:
                    this.method_3((double) ((Class118) class94_0).method_2());
                    break;

                case 9:
                    this.method_3((double) ((Class115) class94_0).method_2());
                    break;

                case 10:
                    this.method_3((double) ((Class114) class94_0).method_2());
                    break;

                case 11:
                    this.method_3((double) ((Class99) class94_0).method_2());
                    break;

                case 15:
                    this.method_3((double) ((Class101) class94_0).method_2());
                    break;

                case 0x11:
                    this.method_3(((Class117) class94_0).method_2());
                    break;

                case 0x13:
                    this.method_3((double) ((Class120) class94_0).method_2());
                    break;

                case 0x15:
                    this.method_3((double) ((Class104) class94_0).method_2());
                    break;

                case 0x16:
                    this.method_3((double) ((Class121) class94_0).method_2());
                    break;

                default:
                    throw new ArgumentOutOfRangeException();
            }
        }
        return this;
    }

    public override Class94 vmethod_4()
    {
        Class117 class1 = new Class117();
        class1.method_3(this.double_0);
        class1.method_1(base.method_0());
        return class1;
    }
}

