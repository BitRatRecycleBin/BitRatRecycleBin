﻿using System;

internal sealed class Class116 : Class94
{
    private Array array_0;

    public Array method_2()
    {
        return this.array_0;
    }

    public void method_3(Array array_1)
    {
        this.array_0 = array_1;
    }

    public override object vmethod_0()
    {
        return this.method_2();
    }

    public override void vmethod_1(object object_0)
    {
        this.method_3((Array) object_0);
    }

    public override int vmethod_2()
    {
        return 1;
    }

    public override Class94 vmethod_3(Class94 class94_0)
    {
        base.method_1(class94_0.method_0());
        int num = class94_0.vmethod_2();
        if (num == 1)
        {
            this.method_3(((Class116) class94_0).method_2());
        }
        else
        {
            if (num != 4)
            {
                throw new ArgumentOutOfRangeException();
            }
            this.method_3((Array) ((Class102) class94_0).method_2());
        }
        return this;
    }

    public override Class94 vmethod_4()
    {
        Class116 class1 = new Class116();
        class1.method_3(this.array_0);
        class1.method_1(base.method_0());
        return class1;
    }
}

