﻿using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.IO.Compression;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using VisualPlus.Enumerators;
using VisualPlus.Toolkit.Controls.Interactivity;

[DesignerGenerated]
public sealed class fTorConfig : Form
{
    private IContainer icontainer_0;
    private CheckBox checkBox_0;
    private Timer timer_0;
    private StatusStrip statusStrip_0;
    private ToolStripStatusLabel toolStripStatusLabel_0;
    private PictureBox pictureBox_0;
    private TextBox textBox_0;
    private Label label_0;
    private Label label_1;
    private PictureBox pictureBox_1;
    private TextBox textBox_1;
    private BackgroundWorker backgroundWorker_0;
    private VisualButton visualButton_0;
    private VisualButton visualButton_1;
    private PictureBox pictureBox_2;
    private PictureBox pictureBox_3;
    private VisualButton visualButton_2;
    private Timer timer_1;
    private PictureBox pictureBox_4;
    private fMain fMain_0;
    private bool bool_0;
    private bool bool_1;

    public fTorConfig()
    {
        base.Load += new EventHandler(this.fTorConfig_Load);
        base.Closing += new CancelEventHandler(this.fTorConfig_Closing);
        this.InitializeComponent();
    }

    [DebuggerNonUserCode]
    protected override void Dispose(bool disposing)
    {
        if (disposing && (this.icontainer_0 != null))
        {
            this.icontainer_0.Dispose();
        }
    }

    private void fTorConfig_Closing(object sender, CancelEventArgs e)
    {
        base.Visible = false;
        e.Cancel = true;
    }

    private void fTorConfig_Load(object sender, EventArgs e)
    {
        this.method_4();
        this.method_1();
    }

    [DebuggerStepThrough]
    private void InitializeComponent()
    {
        this.icontainer_0 = new Container();
        this.vmethod_1(new CheckBox());
        this.vmethod_3(new Timer(this.icontainer_0));
        this.vmethod_5(new StatusStrip());
        this.vmethod_7(new ToolStripStatusLabel());
        this.vmethod_11(new TextBox());
        this.vmethod_13(new Label());
        this.vmethod_15(new Label());
        this.vmethod_19(new TextBox());
        this.vmethod_21(new BackgroundWorker());
        this.vmethod_23(new VisualButton());
        this.vmethod_25(new VisualButton());
        this.vmethod_27(new PictureBox());
        this.vmethod_17(new PictureBox());
        this.vmethod_9(new PictureBox());
        this.vmethod_29(new PictureBox());
        this.vmethod_31(new VisualButton());
        this.vmethod_33(new Timer(this.icontainer_0));
        this.vmethod_35(new PictureBox());
        this.vmethod_4().SuspendLayout();
        ((ISupportInitialize) this.vmethod_26()).BeginInit();
        ((ISupportInitialize) this.vmethod_16()).BeginInit();
        ((ISupportInitialize) this.vmethod_8()).BeginInit();
        ((ISupportInitialize) this.vmethod_28()).BeginInit();
        ((ISupportInitialize) this.vmethod_34()).BeginInit();
        base.SuspendLayout();
        this.vmethod_0().AutoSize = true;
        this.vmethod_0().BackColor = Color.Transparent;
        this.vmethod_0().Location = new Point(0x4a, 90);
        this.vmethod_0().Margin = new Padding(1);
        this.vmethod_0().Name = "chkTorConfigAutostart";
        this.vmethod_0().RightToLeft = RightToLeft.Yes;
        this.vmethod_0().Size = new Size(0x44, 0x11);
        this.vmethod_0().TabIndex = 0x22;
        this.vmethod_0().Text = "Autostart";
        this.vmethod_0().UseVisualStyleBackColor = false;
        this.vmethod_2().Enabled = true;
        this.vmethod_2().Interval = 0x3e8;
        this.vmethod_4().AutoSize = false;
        this.vmethod_4().BackColor = SystemColors.Control;
        this.vmethod_4().ImageScalingSize = new Size(0x1c, 0x1c);
        ToolStripItem[] toolStripItems = new ToolStripItem[] { this.vmethod_6() };
        this.vmethod_4().Items.AddRange(toolStripItems);
        this.vmethod_4().Location = new Point(0, 0x71);
        this.vmethod_4().Name = "ssStatus";
        this.vmethod_4().Padding = new Padding(1, 0, 7, 0);
        this.vmethod_4().Size = new Size(0x1de, 0x15);
        this.vmethod_4().SizingGrip = false;
        this.vmethod_4().Stretch = false;
        this.vmethod_4().TabIndex = 0x24;
        this.vmethod_4().Text = "stStatus";
        this.vmethod_6().AutoSize = false;
        this.vmethod_6().BackColor = SystemColors.Control;
        this.vmethod_6().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_6().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_6().Margin = new Padding(0, 4, 0, 2);
        this.vmethod_6().Name = "tsStatus";
        this.vmethod_6().Size = new Size(470, 15);
        this.vmethod_6().Spring = true;
        this.vmethod_6().Text = "Status: N/A";
        this.vmethod_6().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_10().Location = new Point(0x63, 11);
        this.vmethod_10().Margin = new Padding(1);
        this.vmethod_10().MaxLength = 20;
        this.vmethod_10().Name = "txtUsername";
        this.vmethod_10().Size = new Size(0x79, 20);
        this.vmethod_10().TabIndex = 0x29;
        this.vmethod_12().AutoSize = true;
        this.vmethod_12().BackColor = Color.Transparent;
        this.vmethod_12().FlatStyle = FlatStyle.Flat;
        this.vmethod_12().Location = new Point(2, 14);
        this.vmethod_12().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_12().Name = "lblNickname";
        this.vmethod_12().Size = new Size(0x5f, 13);
        this.vmethod_12().TabIndex = 40;
        this.vmethod_12().Text = "Service nickname:";
        this.vmethod_12().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_14().AutoSize = true;
        this.vmethod_14().BackColor = Color.Transparent;
        this.vmethod_14().FlatStyle = FlatStyle.Flat;
        this.vmethod_14().Location = new Point(0x10, 0x2d);
        this.vmethod_14().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_14().Name = "lblHostname";
        this.vmethod_14().Size = new Size(0x51, 13);
        this.vmethod_14().TabIndex = 0x2b;
        this.vmethod_14().Text = "Your hostname:";
        this.vmethod_14().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_18().Enabled = false;
        this.vmethod_18().Location = new Point(0x63, 0x2a);
        this.vmethod_18().Margin = new Padding(1);
        this.vmethod_18().MaxLength = 0x80;
        this.vmethod_18().Multiline = true;
        this.vmethod_18().Name = "txtHostname";
        this.vmethod_18().ReadOnly = true;
        this.vmethod_18().Size = new Size(0x120, 0x20);
        this.vmethod_18().TabIndex = 0x2c;
        this.vmethod_18().Text = "N/A";
        this.vmethod_20().WorkerSupportsCancellation = true;
        this.vmethod_22().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_22().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_22().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_22().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_22().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_22().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_22().Border.HoverVisible = true;
        this.vmethod_22().Border.Rounding = 6;
        this.vmethod_22().Border.Thickness = 1;
        this.vmethod_22().Border.Type = ShapeTypes.Rounded;
        this.vmethod_22().Border.Visible = true;
        this.vmethod_22().DialogResult = DialogResult.None;
        this.vmethod_22().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_22().Image = null;
        this.vmethod_22().Location = new Point(5, 0x58);
        this.vmethod_22().MouseState = MouseStates.Normal;
        this.vmethod_22().Name = "btnStartStop";
        this.vmethod_22().Size = new Size(0x41, 0x13);
        this.vmethod_22().TabIndex = 0x31;
        this.vmethod_22().Text = "Start";
        this.vmethod_22().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_22().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_22().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_22().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_22().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_22().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_22().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_22().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_24().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
        this.vmethod_24().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_24().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_24().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_24().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_24().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_24().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_24().Border.HoverVisible = true;
        this.vmethod_24().Border.Rounding = 6;
        this.vmethod_24().Border.Thickness = 1;
        this.vmethod_24().Border.Type = ShapeTypes.Rounded;
        this.vmethod_24().Border.Visible = true;
        this.vmethod_24().DialogResult = DialogResult.None;
        this.vmethod_24().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_24().Image = null;
        this.vmethod_24().Location = new Point(0x19b, 0x58);
        this.vmethod_24().MouseState = MouseStates.Normal;
        this.vmethod_24().Name = "btnSaveSettings";
        this.vmethod_24().Size = new Size(0x3e, 0x13);
        this.vmethod_24().TabIndex = 0x35;
        this.vmethod_24().Text = "Save";
        this.vmethod_24().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_24().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_24().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_24().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_24().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_24().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_24().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_24().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_26().Image = Class131.smethod_51();
        this.vmethod_26().Location = new Point(0x1ca, 4);
        this.vmethod_26().Margin = new Padding(2);
        this.vmethod_26().Name = "PictureBox1";
        this.vmethod_26().Size = new Size(15, 15);
        this.vmethod_26().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_26().TabIndex = 0x37;
        this.vmethod_26().TabStop = false;
        this.vmethod_16().Image = Class131.smethod_24();
        this.vmethod_16().Location = new Point(0x19b, 0x33);
        this.vmethod_16().Margin = new Padding(2);
        this.vmethod_16().Name = "pbHostname";
        this.vmethod_16().Size = new Size(15, 15);
        this.vmethod_16().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_16().TabIndex = 0x2d;
        this.vmethod_16().TabStop = false;
        this.vmethod_8().Image = Class131.smethod_24();
        this.vmethod_8().Location = new Point(0xdf, 12);
        this.vmethod_8().Margin = new Padding(2);
        this.vmethod_8().Name = "pbInfoNickname";
        this.vmethod_8().Size = new Size(15, 15);
        this.vmethod_8().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_8().TabIndex = 0x2a;
        this.vmethod_8().TabStop = false;
        this.vmethod_28().Enabled = false;
        this.vmethod_28().Image = Class131.smethod_33();
        this.vmethod_28().Location = new Point(390, 0x33);
        this.vmethod_28().Margin = new Padding(2);
        this.vmethod_28().Name = "pbCopyHWID";
        this.vmethod_28().Size = new Size(15, 15);
        this.vmethod_28().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_28().TabIndex = 0x75;
        this.vmethod_28().TabStop = false;
        this.vmethod_30().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
        this.vmethod_30().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_30().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_30().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_30().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_30().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_30().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_30().Border.HoverVisible = true;
        this.vmethod_30().Border.Rounding = 6;
        this.vmethod_30().Border.Thickness = 1;
        this.vmethod_30().Border.Type = ShapeTypes.Rounded;
        this.vmethod_30().Border.Visible = true;
        this.vmethod_30().DialogResult = DialogResult.None;
        this.vmethod_30().Enabled = false;
        this.vmethod_30().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_30().Image = null;
        this.vmethod_30().Location = new Point(0x131, 0x58);
        this.vmethod_30().MouseState = MouseStates.Normal;
        this.vmethod_30().Name = "btnBackup";
        this.vmethod_30().Size = new Size(0x3e, 0x13);
        this.vmethod_30().TabIndex = 0x76;
        this.vmethod_30().Text = "Backup";
        this.vmethod_30().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_30().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_30().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_30().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_30().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_30().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_30().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_30().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_32().Enabled = true;
        this.vmethod_32().Interval = 500;
        this.vmethod_34().Enabled = false;
        this.vmethod_34().Image = Class131.smethod_24();
        this.vmethod_34().Location = new Point(0x174, 90);
        this.vmethod_34().Margin = new Padding(2);
        this.vmethod_34().Name = "pbBackupInfo";
        this.vmethod_34().Size = new Size(15, 15);
        this.vmethod_34().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_34().TabIndex = 0x77;
        this.vmethod_34().TabStop = false;
        base.AutoScaleDimensions = new SizeF(6f, 13f);
        base.AutoScaleMode = AutoScaleMode.Font;
        this.BackColor = SystemColors.AppWorkspace;
        base.ClientSize = new Size(0x1de, 0x86);
        base.Controls.Add(this.vmethod_34());
        base.Controls.Add(this.vmethod_30());
        base.Controls.Add(this.vmethod_28());
        base.Controls.Add(this.vmethod_26());
        base.Controls.Add(this.vmethod_24());
        base.Controls.Add(this.vmethod_22());
        base.Controls.Add(this.vmethod_16());
        base.Controls.Add(this.vmethod_18());
        base.Controls.Add(this.vmethod_14());
        base.Controls.Add(this.vmethod_8());
        base.Controls.Add(this.vmethod_10());
        base.Controls.Add(this.vmethod_12());
        base.Controls.Add(this.vmethod_4());
        base.Controls.Add(this.vmethod_0());
        this.DoubleBuffered = true;
        base.FormBorderStyle = FormBorderStyle.FixedToolWindow;
        base.IsMdiContainer = true;
        base.MaximizeBox = false;
        base.MinimizeBox = false;
        base.Name = "fTorConfig";
        base.ShowIcon = false;
        base.ShowInTaskbar = false;
        base.StartPosition = FormStartPosition.CenterParent;
        this.Text = "Tor - Hidden service configuration";
        base.TopMost = true;
        this.vmethod_4().ResumeLayout(false);
        this.vmethod_4().PerformLayout();
        ((ISupportInitialize) this.vmethod_26()).EndInit();
        ((ISupportInitialize) this.vmethod_16()).EndInit();
        ((ISupportInitialize) this.vmethod_8()).EndInit();
        ((ISupportInitialize) this.vmethod_28()).EndInit();
        ((ISupportInitialize) this.vmethod_34()).EndInit();
        base.ResumeLayout(false);
        base.PerformLayout();
    }

    public void method_0(Form form_0)
    {
        this.fMain_0 = (fMain) form_0;
    }

    public void method_1()
    {
        this.vmethod_10().Text = Class135.smethod_0().TorConfigUsername;
        this.vmethod_0().Checked = Class135.smethod_0().TorConfigAutostart;
        this.vmethod_18().ReadOnly = true;
        if (File.Exists(Application.StartupPath + @"\data\tor\html\hostname"))
        {
            this.vmethod_18().Text = Strings.Replace(Class136.smethod_14(ref Application.StartupPath + @"\data\tor\html\hostname"), "\r\n", string.Empty, 1, -1, CompareMethod.Text);
            this.vmethod_18().Enabled = true;
            this.vmethod_28().Enabled = true;
        }
        if (!Class130.struct18_5.method_0())
        {
            Class130.struct18_5.method_1(true);
            if (this.vmethod_0().Checked)
            {
                Class136.smethod_12();
            }
        }
    }

    private void method_10(object sender, DoWorkEventArgs e)
    {
        while (!Class130.process_0.HasExited)
        {
            Thread.Sleep(10);
        }
        Class130.struct18_3.method_1(false);
        if (this.bool_1)
        {
            this.method_2("Tor hidden service was stopped!", false);
        }
        else
        {
            this.method_2("Tor hidden service failed to launch. Tor already running?", true);
        }
        this.method_3("Start");
    }

    private void method_11(object sender, EventArgs e)
    {
        if (!Class130.struct18_3.method_0())
        {
            if ((this.vmethod_10().TextLength > 0) && (this.vmethod_10().TextLength < 3))
            {
                Interaction.MsgBox("Invalid username! Username must be between 3 to 20 characters in lenght.", MsgBoxStyle.Critical, Application.ProductName);
            }
            else
            {
                Class135.smethod_0().TorConfigUsername = this.vmethod_10().Text;
                Class135.smethod_0().TorConfigAutostart = this.vmethod_0().Checked;
                Class135.smethod_0().Save();
                Class136.smethod_12();
            }
        }
        else if (MessageBox.Show("Are you sure you want to stop the Tor hidden service?\r\nWarning: Connected clients via Tor will be immediately disconnected.", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
        {
            this.method_2("Stopping Tor hidden service. Please wait...", false);
            this.bool_1 = true;
            this.vmethod_10().Enabled = true;
            if ((Class130.process_0 != null) && !Class130.process_0.HasExited)
            {
                Class130.process_0.Kill();
            }
        }
    }

    private void method_12(object sender, EventArgs e)
    {
    }

    private void method_13(object sender, EventArgs e)
    {
        if ((this.vmethod_10().TextLength > 0) && (this.vmethod_10().TextLength < 3))
        {
            Interaction.MsgBox("Invalid username! Username must be between 3 to 20 characters in lenght.", MsgBoxStyle.Critical, Application.ProductName);
        }
        else
        {
            Class135.smethod_0().TorConfigUsername = this.vmethod_10().Text;
            Class135.smethod_0().TorConfigAutostart = this.vmethod_0().Checked;
            Class135.smethod_0().Save();
            Interaction.MsgBox("Settings successfully saved!", MsgBoxStyle.Information, Application.ProductName);
        }
    }

    private void method_14(object sender, EventArgs e)
    {
        Clipboard.Clear();
        Clipboard.SetText(this.vmethod_18().Text);
        Interaction.MsgBox("Hostname copied to clipboard!", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_15(object sender, EventArgs e)
    {
        SaveFileDialog dialog = new SaveFileDialog();
        dialog.Filter = "ZIP Archive |*.zip";
        if (dialog.ShowDialog() != DialogResult.OK)
        {
            Interaction.MsgBox("Backup was aborted by user!", MsgBoxStyle.Critical, Application.ProductName);
        }
        else
        {
            ZipFile.CreateFromDirectory(Application.StartupPath + @"\data\tor\html", dialog.FileName, CompressionLevel.Optimal, false);
            Interaction.MsgBox("Backup successfully saved to: " + dialog.FileName, MsgBoxStyle.Information, Application.ProductName);
        }
    }

    private void method_16(object sender, EventArgs e)
    {
        this.vmethod_30().Enabled = Directory.Exists(Application.StartupPath + @"\data\tor\html");
        this.vmethod_34().Enabled = Directory.Exists(Application.StartupPath + @"\data\tor\html");
    }

    private void method_17(object sender, EventArgs e)
    {
        string[] textArray1 = new string[] { "You are strongly advised to backup your hidden service address (.onion addres) which is stored in: ", Application.StartupPath, @"\data\tor\html in case you lose access to ", Application.ProductName, ", unexpected corruption, wish to move it to another system or simply after a new major update.\r\n\r\nBy default, an update should not interfere with your existing hidden service address, but losing your .onion address will result in loss of all clients connecting to it.\r\n\r\nYou can either manually copy the data\\tor\\html folder or simply click Backup to create a ZIP-Archive of it.\r\n\r\nTo restore a hidden service address, delete the contents inside the data\\tor\\html folder, place the backed up files in it and restart ", Application.ProductName };
        Interaction.MsgBox(string.Concat(textArray1), MsgBoxStyle.Information, Application.ProductName);
    }

    public void method_2(string string_0, bool bool_2)
    {
        // Unresolved stack state at '0000000D'
    }

    public void method_3(string string_0)
    {
        if (!this.vmethod_22().InvokeRequired)
        {
            this.vmethod_22().Text = string_0;
            this.vmethod_22().Refresh();
        }
        else
        {
            object[] args = new object[] { string_0 };
            this.vmethod_22().Invoke(new Delegate102(this.method_3), args);
        }
    }

    public void method_4()
    {
        base.Left = (int) Math.Round((double) ((Class130.fMain_0.Left + (((double) Class130.fMain_0.Width) / 2.0)) - (((double) base.Width) / 2.0)));
        base.Top = (int) Math.Round((double) ((Class130.fMain_0.Top + (((double) Class130.fMain_0.Height) / 2.0)) - (((double) base.Height) / 2.0)));
    }

    private void method_5(object sender, EventArgs e)
    {
        if (!Directory.Exists(Application.StartupPath + @"\data\tor\"))
        {
            this.bool_0 = false;
            this.method_2("Tor directory missing!", true);
        }
        else if (!File.Exists(Application.StartupPath + @"\data\tor\tor.exe"))
        {
            this.bool_0 = false;
            this.method_2("Tor executable (tor.exe) missing!", true);
        }
    }

    private void method_6(object sender, EventArgs e)
    {
        Interaction.MsgBox("A handle for your Hidden tor service, so user don't have to refer to it by key. The nickname is optional!", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_7(object sender, EventArgs e)
    {
        if (this.vmethod_10().TextLength <= 0)
        {
            if (this.vmethod_10().TextLength == 0)
            {
                this.vmethod_10().BackColor = Color.White;
            }
        }
        else if (this.vmethod_10().TextLength < 3)
        {
            this.vmethod_10().BackColor = Color.Red;
        }
        else
        {
            this.vmethod_10().BackColor = Color.White;
        }
    }

    private void method_8(object sender, KeyPressEventArgs e)
    {
        if (!((((e.KeyChar > '0') & (e.KeyChar < '[')) | ((e.KeyChar > '`') & (e.KeyChar < '{'))) | (e.KeyChar == '\b')))
        {
            e.KeyChar = '\0';
        }
    }

    private void method_9(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.vmethod_18().Text, "N/A", true) == 0)
        {
            Interaction.MsgBox("The hostname is your private DNS and is to be used when building your .exe\r\n\r\nYour hostname will be generated and displayed once you start the Tor hidden service.", MsgBoxStyle.Information, Application.ProductName);
        }
        else
        {
            Interaction.MsgBox("The hostname is your private DNS and is to be used when building your .exe", MsgBoxStyle.Information, Application.ProductName);
        }
    }

    internal virtual CheckBox vmethod_0()
    {
        return this.checkBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_1(CheckBox checkBox_1)
    {
        this.checkBox_0 = checkBox_1;
    }

    internal virtual TextBox vmethod_10()
    {
        return this.textBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_11(TextBox textBox_2)
    {
        EventHandler handler = new EventHandler(this.method_7);
        KeyPressEventHandler handler2 = new KeyPressEventHandler(this.method_8);
        TextBox box = this.textBox_0;
        if (box != null)
        {
            box.TextChanged -= handler;
            box.KeyPress -= handler2;
        }
        this.textBox_0 = textBox_2;
        box = this.textBox_0;
        if (box != null)
        {
            box.TextChanged += handler;
            box.KeyPress += handler2;
        }
    }

    internal virtual Label vmethod_12()
    {
        return this.label_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_13(Label label_2)
    {
        this.label_0 = label_2;
    }

    internal virtual Label vmethod_14()
    {
        return this.label_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_15(Label label_2)
    {
        this.label_1 = label_2;
    }

    internal virtual PictureBox vmethod_16()
    {
        return this.pictureBox_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_17(PictureBox pictureBox_5)
    {
        EventHandler handler = new EventHandler(this.method_9);
        PictureBox box = this.pictureBox_1;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_1 = pictureBox_5;
        box = this.pictureBox_1;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual TextBox vmethod_18()
    {
        return this.textBox_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_19(TextBox textBox_2)
    {
        this.textBox_1 = textBox_2;
    }

    internal virtual Timer vmethod_2()
    {
        return this.timer_0;
    }

    internal virtual BackgroundWorker vmethod_20()
    {
        return this.backgroundWorker_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_21(BackgroundWorker backgroundWorker_1)
    {
        DoWorkEventHandler handler = new DoWorkEventHandler(this.method_10);
        BackgroundWorker worker = this.backgroundWorker_0;
        if (worker != null)
        {
            worker.DoWork -= handler;
        }
        this.backgroundWorker_0 = backgroundWorker_1;
        worker = this.backgroundWorker_0;
        if (worker != null)
        {
            worker.DoWork += handler;
        }
    }

    internal virtual VisualButton vmethod_22()
    {
        return this.visualButton_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_23(VisualButton visualButton_3)
    {
        EventHandler handler = new EventHandler(this.method_11);
        VisualButton button = this.visualButton_0;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_0 = visualButton_3;
        button = this.visualButton_0;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual VisualButton vmethod_24()
    {
        return this.visualButton_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_25(VisualButton visualButton_3)
    {
        EventHandler handler = new EventHandler(this.method_13);
        VisualButton button = this.visualButton_1;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_1 = visualButton_3;
        button = this.visualButton_1;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual PictureBox vmethod_26()
    {
        return this.pictureBox_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_27(PictureBox pictureBox_5)
    {
        this.pictureBox_2 = pictureBox_5;
    }

    internal virtual PictureBox vmethod_28()
    {
        return this.pictureBox_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_29(PictureBox pictureBox_5)
    {
        EventHandler handler = new EventHandler(this.method_14);
        PictureBox box = this.pictureBox_3;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_3 = pictureBox_5;
        box = this.pictureBox_3;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_3(Timer timer_2)
    {
        EventHandler handler = new EventHandler(this.method_5);
        Timer timer = this.timer_0;
        if (timer != null)
        {
            timer.Tick -= handler;
        }
        this.timer_0 = timer_2;
        timer = this.timer_0;
        if (timer != null)
        {
            timer.Tick += handler;
        }
    }

    internal virtual VisualButton vmethod_30()
    {
        return this.visualButton_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_31(VisualButton visualButton_3)
    {
        EventHandler handler = new EventHandler(this.method_15);
        VisualButton button = this.visualButton_2;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_2 = visualButton_3;
        button = this.visualButton_2;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual Timer vmethod_32()
    {
        return this.timer_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_33(Timer timer_2)
    {
        EventHandler handler = new EventHandler(this.method_16);
        Timer timer = this.timer_1;
        if (timer != null)
        {
            timer.Tick -= handler;
        }
        this.timer_1 = timer_2;
        timer = this.timer_1;
        if (timer != null)
        {
            timer.Tick += handler;
        }
    }

    internal virtual PictureBox vmethod_34()
    {
        return this.pictureBox_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_35(PictureBox pictureBox_5)
    {
        EventHandler handler = new EventHandler(this.method_17);
        PictureBox box = this.pictureBox_4;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_4 = pictureBox_5;
        box = this.pictureBox_4;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual StatusStrip vmethod_4()
    {
        return this.statusStrip_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_5(StatusStrip statusStrip_1)
    {
        this.statusStrip_0 = statusStrip_1;
    }

    internal virtual ToolStripStatusLabel vmethod_6()
    {
        return this.toolStripStatusLabel_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_7(ToolStripStatusLabel toolStripStatusLabel_1)
    {
        this.toolStripStatusLabel_0 = toolStripStatusLabel_1;
    }

    internal virtual PictureBox vmethod_8()
    {
        return this.pictureBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_9(PictureBox pictureBox_5)
    {
        EventHandler handler = new EventHandler(this.method_6);
        PictureBox box = this.pictureBox_0;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_0 = pictureBox_5;
        box = this.pictureBox_0;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    private delegate void Delegate101(string string_0, bool bool_0);

    private delegate void Delegate102(string string_0);
}

