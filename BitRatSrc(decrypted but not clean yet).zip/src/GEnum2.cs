﻿using System;

public enum GEnum2
{
}

