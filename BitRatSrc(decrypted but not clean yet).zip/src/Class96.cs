﻿using System;
using System.Reflection;

internal sealed class Class96 : Class94
{
    private object object_0;

    public Class96(object object_1)
    {
        if ((object_1 != null) && !(object_1 is ValueType))
        {
            throw new ArgumentException();
        }
        this.object_0 = object_1;
    }

    public object method_2()
    {
        return this.object_0;
    }

    public void method_3(object object_1)
    {
        if ((object_1 != null) && !(object_1 is ValueType))
        {
            throw new ArgumentException();
        }
        this.object_0 = object_1;
    }

    public override object vmethod_0()
    {
        return this.method_2();
    }

    public override void vmethod_1(object object_1)
    {
        this.method_3(object_1);
    }

    public override int vmethod_2()
    {
        return 20;
    }

    public override Class94 vmethod_3(Class94 class94_0)
    {
        base.method_1(class94_0.method_0());
        int num2 = class94_0.vmethod_2();
        if (num2 == 4)
        {
            this.method_3(((Class102) class94_0).method_2());
        }
        else if (num2 != 20)
        {
            this.method_3(class94_0.vmethod_0());
        }
        else if (this.method_2() == null)
        {
            this.method_3(((Class96) class94_0).method_2());
        }
        else
        {
            object obj2 = ((Class96) class94_0).method_2();
            Type type = this.method_2().GetType();
            if ((obj2 == null) || (type.IsPrimitive || (type.IsEnum || !type.IsAssignableFrom(obj2.GetType()))))
            {
                this.method_3(obj2);
            }
            else
            {
                foreach (FieldInfo info in type.GetFields(BindingFlags.SetField | BindingFlags.GetField | BindingFlags.FlattenHierarchy | BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance))
                {
                    info.SetValue(this.method_2(), info.GetValue(obj2));
                }
            }
        }
        return this;
    }

    public override Class94 vmethod_4()
    {
        Class96 class1 = new Class96(this.object_0);
        class1.method_1(base.method_0());
        return class1;
    }
}

