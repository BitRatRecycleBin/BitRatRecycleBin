﻿using System;

internal sealed class Class98 : Class94
{
    private Enum enum_0;

    public Class98(Enum enum_1)
    {
        this.enum_0 = enum_1 ?? Enum1.Value;
    }

    public Enum method_2()
    {
        return this.enum_0;
    }

    public void method_3(Enum enum_1)
    {
        if (enum_1 == 0)
        {
            throw new ArgumentException();
        }
        this.enum_0 = enum_1;
    }

    public override object vmethod_0()
    {
        return this.method_2();
    }

    public override void vmethod_1(object object_0)
    {
        this.method_3((Enum) Enum.Parse(this.method_2().GetType(), object_0.ToString()));
    }

    public override int vmethod_2()
    {
        return 0x18;
    }

    public override Class94 vmethod_3(Class94 class94_0)
    {
        base.method_1(class94_0.method_0());
        int num = class94_0.vmethod_2();
        if (num > 4)
        {
            switch (num)
            {
                case 7:
                    this.method_3((Enum) Enum.ToObject(this.enum_0.GetType(), ((Class118) class94_0).method_2()));
                    break;

                case 8:
                case 10:
                    goto TR_0000;

                case 9:
                    this.method_3((Enum) Enum.ToObject(this.enum_0.GetType(), ((Class115) class94_0).method_2()));
                    break;

                case 11:
                    this.method_3((Enum) Enum.ToObject(this.enum_0.GetType(), ((Class99) class94_0).method_2()));
                    break;

                default:
                    if (num == 15)
                    {
                        this.method_3((Enum) Enum.ToObject(this.enum_0.GetType(), ((Class101) class94_0).method_2()));
                    }
                    else
                    {
                        switch (num)
                        {
                            case 0x13:
                                this.method_3((Enum) Enum.ToObject(this.enum_0.GetType(), ((Class120) class94_0).method_2()));
                                break;

                            case 0x15:
                                this.method_3((Enum) Enum.ToObject(this.enum_0.GetType(), ((Class104) class94_0).method_2()));
                                break;

                            case 0x16:
                                this.method_3((Enum) Enum.ToObject(this.enum_0.GetType(), ((Class121) class94_0).method_2()));
                                break;

                            case 0x18:
                            {
                                Type objB = this.enum_0.GetType();
                                Enum enum2 = ((Class98) class94_0).method_2();
                                if (ReferenceEquals(enum2.GetType(), objB))
                                {
                                    this.method_3(enum2);
                                }
                                else
                                {
                                    this.method_3((Enum) Enum.ToObject(objB, enum2));
                                }
                                break;
                            }
                            default:
                                goto TR_0000;
                        }
                    }
                    break;
            }
            goto TR_0001;
        }
        else
        {
            if (num == 0)
            {
                this.method_3((Enum) Enum.ToObject(this.enum_0.GetType(), ((Class119) class94_0).method_2()));
            }
            else if (num == 4)
            {
                this.method_3((Enum) Enum.ToObject(this.enum_0.GetType(), ((Class102) class94_0).method_2()));
            }
            else
            {
                goto TR_0000;
            }
            goto TR_0001;
        }
    TR_0000:
        throw new ArgumentOutOfRangeException();
    TR_0001:
        return this;
    }

    public override Class94 vmethod_4()
    {
        Class98 class1 = new Class98(this.enum_0);
        class1.method_1(base.method_0());
        return class1;
    }

    private enum Enum1
    {
        Value
    }
}

