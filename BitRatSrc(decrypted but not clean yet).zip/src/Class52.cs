﻿using System;

internal static class Class52
{
    public static int smethod_0(int int_0)
    {
        return (int_0 & -16777216);
    }
}

