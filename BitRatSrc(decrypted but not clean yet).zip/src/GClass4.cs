﻿using System;
using System.Collections;
using System.Windows.Forms;

public sealed class GClass4 : IComparer
{
    private int int_0 = 0;
    private SortOrder sortOrder_0 = SortOrder.None;
    private CaseInsensitiveComparer caseInsensitiveComparer_0 = new CaseInsensitiveComparer();

    public int Compare(object object_0, object object_1)
    {
        int num3;
        int num4;
        DateTime time;
        DateTime time2;
        string text = ((ListViewItem) object_0).SubItems[this.int_0].Text;
        string s = ((ListViewItem) object_1).SubItems[this.int_0].Text;
        int num2 = (!int.TryParse(text, out num3) || !int.TryParse(s, out num4)) ? ((!DateTime.TryParse(text, out time) || !DateTime.TryParse(s, out time2)) ? this.caseInsensitiveComparer_0.Compare(text, s) : this.caseInsensitiveComparer_0.Compare(time, time2)) : this.caseInsensitiveComparer_0.Compare(num3, num4);
        return ((this.sortOrder_0 != SortOrder.Ascending) ? ((this.sortOrder_0 != SortOrder.Descending) ? 0 : (0 - num2)) : num2);
    }

    public int method_0()
    {
        return this.int_0;
    }

    public void method_1(int int_1)
    {
        this.int_0 = int_1;
    }

    public SortOrder method_2()
    {
        return this.sortOrder_0;
    }

    public void method_3(SortOrder sortOrder_1)
    {
        this.sortOrder_0 = sortOrder_1;
    }
}

