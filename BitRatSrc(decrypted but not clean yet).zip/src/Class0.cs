﻿using System;

internal sealed class Class0
{
    public WeakReference weakReference_0;
    public WeakReference weakReference_1;
    public Class46 class46_0;
}

