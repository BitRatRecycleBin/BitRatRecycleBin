﻿using System;

internal class Exception0 : Exception
{
    public Exception0()
    {
    }

    public Exception0(string string_0) : base(string_0)
    {
    }

    public Exception0(string string_0, Exception exception_0) : base(string_0, exception_0)
    {
    }
}

