﻿using System;

internal sealed class Class46
{
    public readonly object object_0 = new object();
    public byte[] byte_0;
    public bool bool_0;
    public bool bool_1;
}

