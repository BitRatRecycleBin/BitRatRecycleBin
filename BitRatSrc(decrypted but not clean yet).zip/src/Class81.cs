﻿using System;
using System.Runtime.InteropServices;
using System.Security;

internal sealed class Class81 : IDisposable, Interface7
{
    private SecureString secureString_0 = new SecureString();

    public void Dispose()
    {
        this.secureString_0.Dispose();
        this.secureString_0 = null;
    }

    public int imethod_0()
    {
        return this.secureString_0.Length;
    }

    public void imethod_1(int int_0, out byte byte_0)
    {
        if ((int_0 < 0) || (int_0 >= this.imethod_0()))
        {
            throw new ArgumentOutOfRangeException();
        }
        char ch = '\0';
        ch = (char) ((ushort) Marshal.ReadInt16(Marshal.SecureStringToGlobalAllocUnicode(this.secureString_0), int_0 * 2));
        byte_0 = smethod_1(ch, int_0);
    }

    public void imethod_2(int int_0, ref byte byte_0)
    {
        for (int i = this.secureString_0.Length; i <= int_0; i++)
        {
            if (i == int_0)
            {
                this.secureString_0.AppendChar(smethod_0(byte_0, i));
                return;
            }
            this.secureString_0.AppendChar(smethod_0(0, i));
        }
        this.secureString_0.SetAt(int_0, smethod_0(byte_0, int_0));
    }

    public void imethod_3()
    {
        this.secureString_0.Clear();
    }

    public Interface7 imethod_4()
    {
        return new Class81();
    }

    private static char smethod_0(byte byte_0, int int_0)
    {
        return (char) (byte_0 + 1);
    }

    private static byte smethod_1(char char_0, int int_0)
    {
        return (byte) (char_0 - '\x0001');
    }
}

