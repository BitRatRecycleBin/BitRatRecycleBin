﻿using System;

internal static class Class69<T>
{
    public static readonly T[] gparam_0;

    static Class69()
    {
        Class69<T>.gparam_0 = new T[0];
    }
}

