﻿using System;

internal static class Class82
{
    public static readonly object object_0 = new object();
}

