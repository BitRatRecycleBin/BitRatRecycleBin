﻿using System;
using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Sequential)]
internal struct Struct15
{
    public int int_0;
    public int int_1;
    public int int_2;
    public int int_3;
}

