﻿using System;

internal static class Class30
{
    private static bool smethod_0<T>(Type type_0)
    {
        Type objB = typeof(T);
        return (ReferenceEquals(type_0, objB) || type_0.IsSubclassOf(objB));
    }

    public static Class94 smethod_1(object object_0, Type type_0)
    {
        Class94 class2 = object_0 as Class94;
        if (class2 == null)
        {
            if (type_0 == null)
            {
                if (object_0 == null)
                {
                    return new Class102();
                }
                type_0 = object_0.GetType();
            }
            type_0 = Class67.smethod_1(type_0);
            if (ReferenceEquals(type_0, Class58.type_0))
            {
                class2 = new Class102();
                if ((object_0 != null) && !ReferenceEquals(object_0.GetType(), Class58.type_0))
                {
                    class2.method_1(object_0.GetType());
                }
            }
            else if (smethod_0<Array>(type_0))
            {
                class2 = new Class116();
            }
            else if (smethod_0<string>(type_0))
            {
                class2 = new Class113();
            }
            else if (smethod_0<IntPtr>(type_0))
            {
                class2 = new Class105();
            }
            else if (smethod_0<UIntPtr>(type_0))
            {
                class2 = new Class100();
            }
            else if (smethod_0<ulong>(type_0))
            {
                class2 = new Class120();
            }
            else if (smethod_0<uint>(type_0))
            {
                class2 = new Class104();
            }
            else if (smethod_0<ushort>(type_0))
            {
                class2 = new Class119();
            }
            else if (smethod_0<long>(type_0))
            {
                class2 = new Class99();
            }
            else if (smethod_0<int>(type_0))
            {
                class2 = new Class118();
            }
            else if (smethod_0<short>(type_0))
            {
                class2 = new Class101();
            }
            else if (smethod_0<byte>(type_0))
            {
                class2 = new Class121();
            }
            else if (smethod_0<sbyte>(type_0))
            {
                class2 = new Class115();
            }
            else if (smethod_0<double>(type_0))
            {
                class2 = new Class117();
            }
            else if (smethod_0<float>(type_0))
            {
                class2 = new Class114();
            }
            else if (smethod_0<bool>(type_0))
            {
                class2 = new Class103();
            }
            else if (smethod_0<char>(type_0))
            {
                class2 = new Class95();
            }
            else if (Class58.smethod_0(type_0))
            {
                Class102 class1 = new Class102();
                class1.method_1(type_0);
                class2 = class1;
            }
            else
            {
                if (smethod_0<Enum>(type_0))
                {
                    return new Class98((object_0 != null) ? ((!ReferenceEquals(type_0, Class58.type_2) || !(object_0 is Enum)) ? ((Enum) Enum.ToObject(type_0, object_0)) : ((Enum) object_0)) : (!ReferenceEquals(type_0, Class58.type_2) ? ((Enum) Activator.CreateInstance(type_0)) : ((Enum) 0)));
                }
                if (smethod_0<ValueType>(type_0))
                {
                    if (object_0 == null)
                    {
                        object obj2 = !ReferenceEquals(type_0, Class58.type_3) ? Activator.CreateInstance(type_0) : null;
                        class2 = new Class96(obj2);
                    }
                    else
                    {
                        if (!ReferenceEquals(object_0.GetType(), type_0))
                        {
                            object_0 = Convert.ChangeType(object_0, type_0);
                        }
                        class2 = new Class96(object_0);
                    }
                    return class2;
                }
                class2 = new Class102();
            }
            if (object_0 != null)
            {
                class2.vmethod_1(object_0);
            }
        }
        return class2;
    }
}

