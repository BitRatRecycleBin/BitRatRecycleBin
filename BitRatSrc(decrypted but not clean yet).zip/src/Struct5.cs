﻿using System;
using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Explicit)]
internal struct Struct5
{
    public static bool bool_0;
    [FieldOffset(0)]
    private ulong ulong_0;
    [FieldOffset(0)]
    private double double_0;

    static Struct5()
    {
        Struct5 struct2 = new Struct5();
        struct2.double_0 = 2.5842823409468781E+43;
        bool_0 = struct2.ulong_0 == 0x48f28a93b792e44cL;
    }
}

