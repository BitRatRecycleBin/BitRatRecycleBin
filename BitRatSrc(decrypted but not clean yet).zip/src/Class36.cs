﻿using System;

internal sealed class Class36 : Class32
{
    private Class3 class3_0;
    private string string_0;
    private bool bool_0;

    public Class3 method_0()
    {
        return this.class3_0;
    }

    public void method_1(Class3 class3_1)
    {
        this.class3_0 = class3_1;
    }

    public string method_2()
    {
        return this.string_0;
    }

    public void method_3(string string_1)
    {
        this.string_0 = string_1;
    }

    public bool method_4()
    {
        return this.bool_0;
    }

    public void method_5(bool bool_1)
    {
        this.bool_0 = bool_1;
    }

    public override byte vmethod_0()
    {
        return 0;
    }
}

