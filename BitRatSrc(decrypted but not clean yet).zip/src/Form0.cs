﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

[GeneratedCode("MyTemplate", "11.0.0.0"), EditorBrowsable(EditorBrowsableState.Never)]
internal sealed class Form0 : WindowsFormsApplicationBase
{
    [DebuggerStepThrough]
    public Form0() : base(AuthenticationMode.Windows)
    {
        base.IsSingleInstance = false;
        base.EnableVisualStyles = true;
        base.SaveMySettingsOnExit = true;
        base.ShutdownStyle = ShutdownMode.AfterMainFormCloses;
    }

    [DebuggerStepThrough]
    protected override void OnCreateMainForm()
    {
        base.MainForm = Class145.smethod_3().method_28();
    }

    [MethodImpl(MethodImplOptions.NoOptimization), EditorBrowsable(EditorBrowsableState.Advanced), STAThread, DebuggerHidden]
    internal static void smethod_0(string[] string_0)
    {
        Application.SetCompatibleTextRenderingDefault(WindowsFormsApplicationBase.UseCompatibleTextRendering);
        Class145.smethod_1().Run(string_0);
    }
}

