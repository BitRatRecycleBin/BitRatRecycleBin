﻿using System;

internal static class Class10
{
    public static void smethod_0(Array array_0, RuntimeFieldHandle runtimeFieldHandle_0)
    {
        // Unresolved stack state at '00000013'
    }
}

