﻿using System;

internal sealed class Class1
{
    private readonly byte[] byte_0;
    private static byte[] byte_1 = new byte[] { 
        0xa3, 0xd7, 9, 0x83, 0xf8, 0x48, 0xf6, 0xf4, 0xb3, 0x21, 0x15, 120, 0x99, 0xb1, 0xaf, 0xf9,
        0xe7, 0x2d, 0x4d, 0x8a, 0xce, 0x4c, 0xca, 0x2e, 0x52, 0x95, 0xd9, 30, 0x4e, 0x38, 0x44, 40,
        10, 0xdf, 2, 160, 0x17, 0xf1, 0x60, 0x68, 0x12, 0xb7, 0x7a, 0xc3, 0xe9, 250, 0x3d, 0x53,
        150, 0x84, 0x6b, 0xba, 0xf2, 0x63, 0x9a, 0x19, 0x7c, 0xae, 0xe5, 0xf5, 0xf7, 0x16, 0x6a, 0xa2,
        0x39, 0xb6, 0x7b, 15, 0xc1, 0x93, 0x81, 0x1b, 0xee, 180, 0x1a, 0xea, 0xd0, 0x91, 0x2f, 0xb8,
        0x55, 0xb9, 0xda, 0x85, 0x3f, 0x41, 0xbf, 0xe0, 90, 0x58, 0x80, 0x5f, 0x66, 11, 0xd8, 0x90,
        0x35, 0xd5, 0xc0, 0xa7, 0x33, 6, 0x65, 0x69, 0x45, 0, 0x94, 0x56, 0x6d, 0x98, 0x9b, 0x76,
        0x97, 0xfc, 0xb2, 0xc2, 0xb0, 0xfe, 0xdb, 0x20, 0xe1, 0xeb, 0xd6, 0xe4, 0xdd, 0x47, 0x4a, 0x1d,
        0x42, 0xed, 0x9e, 110, 0x49, 60, 0xcd, 0x43, 0x27, 210, 7, 0xd4, 0xde, 0xc7, 0x67, 0x18,
        0x89, 0xcb, 0x30, 0x1f, 0x8d, 0xc6, 0x8f, 170, 200, 0x74, 220, 0xc9, 0x5d, 0x5c, 0x31, 0xa4,
        0x70, 0x88, 0x61, 0x2c, 0x9f, 13, 0x2b, 0x87, 80, 130, 0x54, 100, 0x26, 0x7d, 3, 0x40,
        0x34, 0x4b, 0x1c, 0x73, 0xd1, 0xc4, 0xfd, 0x3b, 0xcc, 0xfb, 0x7f, 0xab, 230, 0x3e, 0x5b, 0xa5,
        0xad, 4, 0x23, 0x9c, 20, 0x51, 0x22, 240, 0x29, 0x79, 0x71, 0x7e, 0xff, 140, 14, 0xe2,
        12, 0xef, 0xbc, 0x72, 0x75, 0x6f, 0x37, 0xa1, 0xec, 0xd3, 0x8e, 0x62, 0x8b, 0x86, 0x10, 0xe8,
        8, 0x77, 0x11, 190, 0x92, 0x4f, 0x24, 0xc5, 50, 0x36, 0x9d, 0xcf, 0xf3, 0xa6, 0xbb, 0xac,
        0x5e, 0x6c, 0xa9, 0x13, 0x57, 0x25, 0xb5, 0xe3, 0xbd, 0xa8, 0x3a, 1, 5, 0x59, 0x2a, 70
    };

    public Class1(byte[] byte_2)
    {
        if (byte_2 == null)
        {
            throw new ArgumentNullException("#=z5jI7l7s=");
        }
        if (byte_2.Length != 10)
        {
            throw new ArgumentException("key");
        }
        this.byte_0 = byte_2;
    }

    public byte[] method_0(byte[] byte_2)
    {
        return this.method_6(byte_2, true);
    }

    public byte[] method_1(byte[] byte_2)
    {
        return this.method_6(byte_2, false);
    }

    public uint method_2(uint uint_0)
    {
        return smethod_1(this.method_0(smethod_0(uint_0)));
    }

    public uint method_3(uint uint_0)
    {
        return smethod_1(this.method_1(smethod_0(uint_0)));
    }

    public int method_4(int int_0)
    {
        return smethod_3(this.method_0(smethod_2(int_0)));
    }

    public int method_5(int int_0)
    {
        return smethod_3(this.method_1(smethod_2(int_0)));
    }

    private byte[] method_6(byte[] byte_2, bool bool_0)
    {
        if (byte_2 == null)
        {
            throw new ArgumentNullException("#=z5jI7l7s=");
        }
        int length = byte_2.Length;
        if ((length % 4) != 0)
        {
            throw new ArgumentOutOfRangeException("#=z5jI7l7s=", "Invalid block size.");
        }
        byte[] buffer = this.byte_0;
        byte[] buffer2 = new byte[length];
        for (int i = 0; i < length; i += 4)
        {
            smethod_5(buffer, byte_2, i, buffer2, i, bool_0);
        }
        return buffer2;
    }

    private static byte[] smethod_0(uint uint_0)
    {
        return new byte[] { ((byte) (uint_0 >> 0x18)), ((byte) (uint_0 >> 0x10)), ((byte) (uint_0 >> 8)), ((byte) uint_0) };
    }

    private static uint smethod_1(byte[] byte_2)
    {
        return (uint) ((((byte_2[0] << 0x18) | (byte_2[1] << 0x10)) | (byte_2[2] << 8)) | byte_2[3]);
    }

    private static byte[] smethod_2(int int_0)
    {
        return new byte[] { ((byte) (int_0 >> 0x18)), ((byte) (int_0 >> 0x10)), ((byte) (int_0 >> 8)), ((byte) int_0) };
    }

    private static int smethod_3(byte[] byte_2)
    {
        return ((((byte_2[0] << 0x18) | (byte_2[1] << 0x10)) | (byte_2[2] << 8)) | byte_2[3]);
    }

    private static ushort smethod_4(byte[] byte_2, int int_0, ushort ushort_0)
    {
        byte num5 = (byte) ((ushort_0 >> 8) & 0xff);
        byte num = (byte) (ushort_0 & 0xff);
        byte num2 = (byte) (byte_1[num ^ byte_2[(4 * int_0) % 10]] ^ num5);
        byte num3 = (byte) (byte_1[num2 ^ byte_2[((4 * int_0) + 1) % 10]] ^ num);
        byte num4 = (byte) (byte_1[num3 ^ byte_2[((4 * int_0) + 2) % 10]] ^ num2);
        byte num6 = (byte) (byte_1[num4 ^ byte_2[((4 * int_0) + 3) % 10]] ^ num3);
        return (ushort) ((num4 << 8) + num6);
    }

    private static void smethod_5(byte[] byte_2, byte[] byte_3, int int_0, byte[] byte_4, int int_1, bool bool_0)
    {
        int num;
        int num2;
        if (bool_0)
        {
            num = 1;
            num2 = 0;
        }
        else
        {
            num = -1;
            num2 = 0x17;
        }
        ushort num3 = (ushort) ((byte_3[int_0] << 8) + byte_3[int_0 + 1]);
        ushort num4 = (ushort) ((byte_3[int_0 + 2] << 8) + byte_3[int_0 + 3]);
        for (int i = 0; i < 12; i++)
        {
            num4 = (ushort) (num4 ^ ((ushort) (smethod_4(byte_2, num2, num3) ^ num2)));
            num2 += num;
            num3 = (ushort) (num3 ^ ((ushort) (smethod_4(byte_2, num2, num4) ^ num2)));
            num2 += num;
        }
        byte_4[int_1] = (byte) (num4 >> 8);
        byte_4[int_1 + 1] = (byte) (num4 & 0xff);
        byte_4[int_1 + 2] = (byte) (num3 >> 8);
        byte_4[int_1 + 3] = (byte) (num3 & 0xff);
    }
}

