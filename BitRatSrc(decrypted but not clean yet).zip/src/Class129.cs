﻿using Microsoft.VisualBasic.Devices;
using System.CodeDom.Compiler;
using System.ComponentModel;

[GeneratedCode("MyTemplate", "11.0.0.0"), EditorBrowsable(EditorBrowsableState.Never)]
internal sealed class Class129 : Computer
{
}

