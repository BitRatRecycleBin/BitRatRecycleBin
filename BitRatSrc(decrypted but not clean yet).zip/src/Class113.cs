﻿using System;

internal sealed class Class113 : Class94
{
    private string string_0;

    public string method_2()
    {
        return this.string_0;
    }

    public void method_3(string string_1)
    {
        this.string_0 = string_1;
    }

    public override object vmethod_0()
    {
        return this.method_2();
    }

    public override void vmethod_1(object object_0)
    {
        this.method_3((string) object_0);
    }

    public override int vmethod_2()
    {
        return 5;
    }

    public override Class94 vmethod_3(Class94 class94_0)
    {
        base.method_1(class94_0.method_0());
        int num = class94_0.vmethod_2();
        if (num == 4)
        {
            this.method_3((string) ((Class102) class94_0).method_2());
        }
        else
        {
            if (num != 5)
            {
                throw new ArgumentOutOfRangeException();
            }
            this.method_3(((Class113) class94_0).method_2());
        }
        return this;
    }

    public override Class94 vmethod_4()
    {
        Class113 class1 = new Class113();
        class1.method_3(this.string_0);
        class1.method_1(base.method_0());
        return class1;
    }
}

