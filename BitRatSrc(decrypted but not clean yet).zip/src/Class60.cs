﻿using System;
using System.Diagnostics;

internal sealed class Class60
{
    [Conditional("DEBUG")]
    public static void smethod_0(string string_0)
    {
    }
}

