﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

internal static class Class39
{
    [DllImport("kernel32.dll", SetLastError=true)]
    private static extern IntPtr LoadLibrary(string string_0);
    [DllImport("kernel32.dll")]
    private static extern bool MoveFileEx(string string_0, string string_1, int int_0);
    private static bool smethod_0()
    {
        return smethod_1();
    }

    private static bool smethod_1()
    {
        StackFrame frame = new StackTrace().GetFrame(3);
        MethodBase base2 = (frame == null) ? null : frame.GetMethod();
        Type objA = (base2 == null) ? null : base2.DeclaringType;
        return (!ReferenceEquals(objA, typeof(RuntimeMethodHandle)) ? ((objA != null) ? ReferenceEquals(objA.Assembly, typeof(Class39).Assembly) : false) : false);
    }

    private static Assembly smethod_10(ResolveEventArgs resolveEventArgs_0)
    {
        Assembly requestingAssembly = resolveEventArgs_0.RequestingAssembly;
        if (requestingAssembly == null)
        {
            return null;
        }
        if ((new AssemblyName(resolveEventArgs_0.Name).Flags & AssemblyNameFlags.Retargetable) == AssemblyNameFlags.None)
        {
            return null;
        }
        if (ReferenceEquals(requestingAssembly, typeof(Class39).Assembly))
        {
            return null;
        }
        bool flag = false;
        Dictionary<string, Assembly> dictionary = Class41.dictionary_0;
        Monitor.Enter(dictionary);
        Dictionary<string, Assembly>.Enumerator enumerator = dictionary.GetEnumerator();
        while (true)
        {
            if (enumerator.MoveNext())
            {
                KeyValuePair<string, Assembly> current = enumerator.Current;
                if (current.Value != requestingAssembly)
                {
                    continue;
                }
                flag = true;
            }
            return (flag ? Assembly.Load(resolveEventArgs_0.Name) : null);
        }
    }

    private static void smethod_11()
    {
        smethod_12();
    }

    private static void smethod_12()
    {
        IEnumerator<Class43.Class45> enumerator = Class43.smethod_0(null).GetEnumerator();
        while (enumerator.MoveNext())
        {
            Class43.Class45 current = enumerator.Current;
            if (current.method_0().StartsWith("#N,S,", StringComparison.Ordinal) && Class40.smethod_1(current))
            {
                string str = Class43.smethod_2(current, true, null);
                if (LoadLibrary(str) == IntPtr.Zero)
                {
                    File.Delete(str);
                }
            }
        }
    }

    internal static void smethod_2()
    {
        smethod_11();
        AppDomain.CurrentDomain.AssemblyResolve += new ResolveEventHandler(Class39.smethod_4);
    }

    internal static Assembly smethod_3(string string_0)
    {
        return smethod_5(string_0);
    }

    private static Assembly smethod_4(object object_0, ResolveEventArgs resolveEventArgs_0)
    {
        Assembly assembly = smethod_5(resolveEventArgs_0.Name);
        if (assembly == null)
        {
            assembly = smethod_10(resolveEventArgs_0);
        }
        return assembly;
    }

    private static Assembly smethod_5(string string_0)
    {
        Assembly assembly;
        Struct6 struct2 = new Struct6(string_0.ToUpperInvariant());
        Class43.Class45 current = null;
        bool flag2 = false;
        if (!struct2.bool_2 || (struct2.string_2 != null))
        {
            IEnumerator<Class43.Class45> enumerator = Class43.smethod_0(null).GetEnumerator();
            while (enumerator.MoveNext())
            {
                Class43.Class45 current = enumerator.Current;
                if (current.method_0().StartsWith("#A,A,", StringComparison.Ordinal))
                {
                    Struct6 struct3 = new Struct6(current.method_0().Substring(5));
                    if ((struct3.string_0 == struct2.string_0) && ((struct3.string_1 == struct2.string_1) && (!struct2.bool_2 || (struct3.string_2 == struct2.string_2))))
                    {
                        if (!struct2.bool_0 || !(struct3.version_0 != struct2.version_0))
                        {
                            current = current;
                            break;
                        }
                        flag2 = true;
                    }
                }
            }
        }
        if ((current == null) && !flag2)
        {
            string s = struct2.method_0(false);
            IEnumerator<Class43.Class45> enumerator = Class43.smethod_0(Convert.ToBase64String(Encoding.UTF8.GetBytes(s))).GetEnumerator();
            if (enumerator.MoveNext())
            {
                current = enumerator.Current;
            }
        }
        if (current == null)
        {
            return null;
        }
        Dictionary<string, Assembly> dictionary = Class41.dictionary_0;
        Monitor.Enter(dictionary);
        if (!dictionary.TryGetValue(current.string_2, out assembly))
        {
            bool flag;
            byte[] rawAssembly = Class43.smethod_1(current);
            if (rawAssembly == null)
            {
                return null;
            }
            if (!(flag = current.bool_2))
            {
                assembly = Assembly.Load(rawAssembly);
            }
            if (flag)
            {
                assembly = Assembly.LoadFrom(Class43.smethod_2(current, true, rawAssembly));
            }
            dictionary.Add(current.string_2, assembly);
        }
        return assembly;
    }

    private static int smethod_6(byte[] byte_0, int int_0)
    {
        return (((byte_0[int_0] | (byte_0[int_0 + 1] << 0x18)) | (byte_0[int_0 + 2] << 8)) | (byte_0[int_0 + 3] << 0x10));
    }

    private static int smethod_7(byte[] byte_0, int int_0)
    {
        return ((((byte_0[int_0] << 0x10) | (byte_0[int_0 + 1] << 8)) | (byte_0[int_0 + 2] << 0x18)) | byte_0[int_0 + 3]);
    }

    private static byte[] smethod_8(byte[] byte_0)
    {
        if (smethod_6(byte_0, 0) != -1686991929)
        {
            throw new Exception();
        }
        int count = smethod_7(byte_0, 4);
        Stream stream = new MemoryStream(byte_0, false);
        stream.Position = 8L;
        stream = new DeflateStream(stream, CompressionMode.Decompress);
        byte_0 = new byte[count];
        if (stream.Read(byte_0, 0, count) != count)
        {
            throw new Exception();
        }
        return byte_0;
    }

    private static unsafe byte[] smethod_9(byte[] byte_0)
    {
        byte[] buffer2 = Convert.FromBase64String("uVV3SRG3zklj18W1oZX5IdUM8FaKGBm3cLRysvQaf527HiVV2RzSyCKmC0qLbojTZ2uPjhjXjFEhAh14neTGVwJTQjrfLxCrVXLb");
        Class70.smethod_1(buffer2);
        Class42 class2 = new Class42(buffer2);
        int length = byte_0.Length;
        byte num = 0;
        byte num3 = 0x79;
        byte[] buffer = new byte[] { 0x94, 0x44, 0xd0, 0x34, 0xf1, 0x5d, 0xc3, 220 };
        for (int i = 0; i != length; i++)
        {
            if (num == 0)
            {
                num3 = class2.method_1();
            }
            num = (byte) (num + 1);
            if (num == 0x20)
            {
                num = 0;
            }
            byte* numPtr1 = &(byte_0[i]);
            numPtr1[0] = (byte) (numPtr1[0] ^ ((byte) ((num3 ^ buffer[(i >> 2) & 3]) ^ buffer[num & 3])));
        }
        return byte_0;
    }

    private static class Class40
    {
        private static int smethod_0()
        {
            int size = IntPtr.Size;
            return ((size == 4) ? 1 : ((size == 8) ? 2 : 0xff));
        }

        public static bool smethod_1(Class39.Class43.Class45 class45_0)
        {
            return ((class45_0.int_0 != 0) ? ((smethod_0() & class45_0.int_0) != 0) : true);
        }
    }

    private static class Class41
    {
        internal static readonly Dictionary<string, Assembly> dictionary_0 = new Dictionary<string, Assembly>(StringComparer.Ordinal);
    }

    private sealed class Class42
    {
        private byte[] byte_0 = new byte[0x100];
        private int int_0;
        private int int_1;

        public Class42(byte[] byte_1)
        {
            int length = byte_1.Length;
            this.int_0 = 0;
            while (this.int_0 < 0x100)
            {
                this.byte_0[this.int_0] = (byte) this.int_0;
                this.int_0++;
            }
            this.int_1 = 0;
            this.int_0 = 0;
            while (this.int_0 < 0x100)
            {
                this.int_1 = ((this.int_1 + byte_1[this.int_0 % length]) + this.byte_0[this.int_0]) & 0xff;
                this.method_0(this.int_0, this.int_1);
                this.int_0++;
            }
        }

        private void method_0(int int_2, int int_3)
        {
            byte num = this.byte_0[int_2];
            this.byte_0[int_2] = this.byte_0[int_3];
            this.byte_0[int_3] = num;
        }

        public byte method_1()
        {
            this.int_0 = (this.int_0 + 1) & 0xff;
            this.int_1 = (this.int_1 + this.byte_0[this.int_0]) & 0xff;
            this.method_0(this.int_0, this.int_1);
            return this.byte_0[(byte) (this.byte_0[this.int_0] + this.byte_0[this.int_1])];
        }
    }

    private static class Class43
    {
        internal static IEnumerable<Class45> smethod_0(string string_0)
        {
            Class44 class1 = new Class44(-2);
            class1.string_1 = string_0;
            return class1;
        }

        internal static byte[] smethod_1(Class45 class45_0)
        {
            Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream(class45_0.string_2);
            if (manifestResourceStream == null)
            {
                return null;
            }
            int length = (int) manifestResourceStream.Length;
            byte[] buffer = new byte[length];
            manifestResourceStream.Read(buffer, 0, length);
            manifestResourceStream.Dispose();
            if (class45_0.bool_0)
            {
                buffer = Class39.smethod_9(buffer);
            }
            if (class45_0.bool_1)
            {
                buffer = Class39.smethod_8(buffer);
            }
            return buffer;
        }

        internal static string smethod_2(Class45 class45_0, bool bool_0, byte[] byte_0)
        {
            string path = Path.Combine(Path.GetTempPath(), class45_0.string_2);
            Directory.CreateDirectory(path);
            string str2 = Path.Combine(path, class45_0.method_1());
            if (!File.Exists(str2))
            {
                if (byte_0 == null)
                {
                    byte_0 = smethod_1(class45_0);
                }
                File.WriteAllBytes(str2, byte_0);
                if (bool_0)
                {
                    Class39.MoveFileEx(str2, null, 4);
                    Class39.MoveFileEx(path, null, 4);
                }
            }
            return str2;
        }

        internal static void smethod_3(string string_0, bool bool_0)
        {
            bool flag = false;
            File.Delete(string_0);
            flag = true;
            string directoryName = Path.GetDirectoryName(string_0);
            bool flag2 = false;
            Directory.Delete(directoryName);
            flag = true;
            if (bool_0)
            {
                if (!flag)
                {
                    Class39.MoveFileEx(string_0, null, 4);
                }
                if (!flag2)
                {
                    Class39.MoveFileEx(directoryName, null, 4);
                }
            }
        }

        private sealed class Class44 : IEnumerable<Class39.Class43.Class45>, IEnumerator<Class39.Class43.Class45>, IEnumerable, IDisposable, IEnumerator
        {
            private int int_0;
            private Class39.Class43.Class45 class45_0;
            private int int_1;
            private string string_0;
            public string string_1;
            private string[] string_2;
            private int int_2;

            [DebuggerHidden]
            public Class44(int int_3)
            {
                this.int_0 = int_3;
                this.int_1 = Thread.CurrentThread.ManagedThreadId;
            }

            [DebuggerHidden]
            IEnumerator<Class39.Class43.Class45> IEnumerable<Class39.Class43.Class45>.GetEnumerator()
            {
                Class39.Class43.Class44 class2;
                if ((this.int_0 != -2) || (this.int_1 != Thread.CurrentThread.ManagedThreadId))
                {
                    class2 = new Class39.Class43.Class44(0);
                }
                else
                {
                    this.int_0 = 0;
                    class2 = this;
                }
                class2.string_0 = this.string_1;
                return class2;
            }

            [DebuggerHidden]
            IEnumerator IEnumerable.GetEnumerator()
            {
                return this.System.Collections.Generic.IEnumerable<Class39.Class43.Class45>.GetEnumerator();
            }

            bool IEnumerator.MoveNext()
            {
                int num2 = this.int_0;
                if (num2 == 0)
                {
                    this.int_0 = -1;
                    string str5 = "WlhfMkQ5MzA5QzQ5NEVFNDdBRjg2NDJFQkQxRDVFQjVGQTYsIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49TlVMTA==,ab|c57e60c3147843f39af3ff714140bd0a,enhfMmQ5MzA5YzQ5NGVlNDdhZjg2NDJlYmQxZDVlYjVmYTYuZGxs,,Q0lSQ0xFX1BST0dSRVNTQkFSLCBDVUxUVVJFPU5FVVRSQUwsIFBVQkxJQ0tFWVRPS0VOPU5VTEw=,ab|4fe90a0540cd4887b332bf69fc976ec5,Y2lyY2xlX3Byb2dyZXNzYmFyLmRsbA==,,I04sUywxLGxpYm1wM2xhbWUuMzI=,ab|8d1aa588907342699c8c3309b3bc14e4,bGlibXAzbGFtZS4zMi5kbGw=,1,I04sUywyLGxpYm1wM2xhbWUuNjQ=,ab|1f0d3a86aa8447b1a0cfb6e296cc3a27,bGlibXAzbGFtZS42NC5kbGw=,2,TUlDUk9TT0ZULlRIUkVBRElORy5UQVNLUywgQ1VMVFVSRT1ORVVUUkFMLCBQVUJMSUNLRVlUT0tFTj1CMDNGNUY3RjExRDUwQTNB,ab|6264aee43400493ba5a83d12052207c6,TWljcm9zb2Z0LlRocmVhZGluZy5UYXNrcy5kbGw=,,I0EsQSxNSUNST1NPRlQuVEhSRUFESU5HLlRBU0tTLCBWRVJTSU9OPTEuMC4xMi4wLCBDVUxUVVJFPU5FVVRSQUwsIFBVQkxJQ0tFWVRPS0VOPUIwM0Y1RjdGMTFENTBBM0E=,ab|6264aee43400493ba5a83d12052207c6,TWljcm9zb2Z0LlRocmVhZGluZy5UYXNrcy5kbGw=,,TUlDUk9TT0ZULlRIUkVBRElORy5UQVNLUy5FWFRFTlNJT05TLkRFU0tUT1AsIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49QjAzRjVGN0YxMUQ1MEEzQQ==,ab|42feaac15b0a4239a5d10a8a07159229,TWljcm9zb2Z0LlRocmVhZGluZy5UYXNrcy5FeHRlbnNpb25zLkRlc2t0b3AuZGxs,,I0EsQSxNSUNST1NPRlQuVEhSRUFESU5HLlRBU0tTLkVYVEVOU0lPTlMuREVTS1RPUCwgVkVSU0lPTj0xLjAuMTY4LjAsIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49QjAzRjVGN0YxMUQ1MEEzQQ==,ab|42feaac15b0a4239a5d10a8a07159229,TWljcm9zb2Z0LlRocmVhZGluZy5UYXNrcy5FeHRlbnNpb25zLkRlc2t0b3AuZGxs,,TUlDUk9TT0ZULlRIUkVBRElORy5UQVNLUy5FWFRFTlNJT05TLCBDVUxUVVJFPU5FVVRSQUwsIFBVQkxJQ0tFWVRPS0VOPUIwM0Y1RjdGMTFENTBBM0E=,ab|71d08c0140074379823066654901e1e7,TWljcm9zb2Z0LlRocmVhZGluZy5UYXNrcy5FeHRlbnNpb25zLmRsbA==,,I0EsQSxNSUNST1NPRlQuVEhSRUFESU5HLlRBU0tTLkVYVEVOU0lPTlMsIFZFUlNJT049MS4wLjEyLjAsIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49QjAzRjVGN0YxMUQ1MEEzQQ==,ab|71d08c0140074379823066654901e1e7,TWljcm9zb2Z0LlRocmVhZGluZy5UYXNrcy5FeHRlbnNpb25zLmRsbA==,,TUVUUk9GUkFNRVdPUksuREVTSUdOLCBDVUxUVVJFPU5FVVRSQUwsIFBVQkxJQ0tFWVRPS0VOPTVGOTFBODQ3NTlCRjU4NEE=,ab|f304bc27d16945e69aaab7369f4268a2,TWV0cm9GcmFtZXdvcmsuRGVzaWduLmRsbA==,,I0EsQSxNRVRST0ZSQU1FV09SSy5ERVNJR04sIFZFUlNJT049MS40LjAuMCwgQ1VMVFVSRT1ORVVUUkFMLCBQVUJMSUNLRVlUT0tFTj01RjkxQTg0NzU5QkY1ODRB,ab|f304bc27d16945e69aaab7369f4268a2,TWV0cm9GcmFtZXdvcmsuRGVzaWduLmRsbA==,,TUVUUk9GUkFNRVdPUkssIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49NUY5MUE4NDc1OUJGNTg0QQ==,ab|4387107a2694444190a0c5f5bb03847d,TWV0cm9GcmFtZXdvcmsuZGxs,,I0EsQSxNRVRST0ZSQU1FV09SSywgVkVSU0lPTj0xLjQuMC4wLCBDVUxUVVJFPU5FVVRSQUwsIFBVQkxJQ0tFWVRPS0VOPTVGOTFBODQ3NTlCRjU4NEE=,ab|4387107a2694444190a0c5f5bb03847d,TWV0cm9GcmFtZXdvcmsuZGxs,,TUVUUk9GUkFNRVdPUksuRk9OVFMsIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49NUY5MUE4NDc1OUJGNTg0QQ==,ab|2631f76cfbaa4db2ba493ef6fe2636f0,TWV0cm9GcmFtZXdvcmsuRm9udHMuZGxs,,I0EsQSxNRVRST0ZSQU1FV09SSy5GT05UUywgVkVSU0lPTj0xLjQuMC4wLCBDVUxUVVJFPU5FVVRSQUwsIFBVQkxJQ0tFWVRPS0VOPTVGOTFBODQ3NTlCRjU4NEE=,ab|2631f76cfbaa4db2ba493ef6fe2636f0,TWV0cm9GcmFtZXdvcmsuRm9udHMuZGxs,,TkFVRElPLCBDVUxUVVJFPU5FVVRSQUwsIFBVQkxJQ0tFWVRPS0VOPU5VTEw=,ab|f41c36dc09d14bd6bb959faacedef4c6,TkF1ZGlvLmRsbA==,,TkFVRElPLkxBTUUsIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49TlVMTA==,ab|e78009d2551c440f846b5e8c7755b88a,TkF1ZGlvLkxhbWUuZGxs,,TkVXVE9OU09GVC5KU09OLCBDVUxUVVJFPU5FVVRSQUwsIFBVQkxJQ0tFWVRPS0VOPTMwQUQ0RkU2QjJBNkFFRUQ=,ab|e203f266de75474da28adf801155f74b,TmV3dG9uc29mdC5Kc29uLmRsbA==,,I0EsQSxORVdUT05TT0ZULkpTT04sIFZFUlNJT049MTIuMC4wLjAsIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49MzBBRDRGRTZCMkE2QUVFRA==,ab|e203f266de75474da28adf801155f74b,TmV3dG9uc29mdC5Kc29uLmRsbA==,,TklUTy5BU1lOQ0VYLkNPT1JESU5BVElPTiwgQ1VMVFVSRT1ORVVUUkFMLCBQVUJMSUNLRVlUT0tFTj1OVUxM,ab|3a57e4dcd6654ca1b36ee125a84dd3fb,Tml0by5Bc3luY0V4LkNvb3JkaW5hdGlvbi5kbGw=,,TklUTy5BU1lOQ0VYLklOVEVST1AuV0FJVEhBTkRMRVMsIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49TlVMTA==,ab|7555edd2c31642ef843b7b3ef9e6b9ec,Tml0by5Bc3luY0V4LkludGVyb3AuV2FpdEhhbmRsZXMuZGxs,,TklUTy5BU1lOQ0VYLlRBU0tTLCBDVUxUVVJFPU5FVVRSQUwsIFBVQkxJQ0tFWVRPS0VOPU5VTEw=,ab|17dc047006e84c0183b68979edc51a60,Tml0by5Bc3luY0V4LlRhc2tzLmRsbA==,,TklUTy5BU1lOQ0VYLk9PUCwgQ1VMVFVSRT1ORVVUUkFMLCBQVUJMSUNLRVlUT0tFTj1OVUxM,ab|d4773934400f4f229d0722988dc2ed5b,Tml0by5Bc3luY0V4Lk9vcC5kbGw=,,TklUTy5DQU5DRUxMQVRJT04sIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49TlVMTA==,ab|1e6b7b67b43d4db08f35a6ad42609e06,Tml0by5DYW5jZWxsYXRpb24uZGxs,,TklUTy5DT0xMRUNUSU9OUy5ERVFVRSwgQ1VMVFVSRT1ORVVUUkFMLCBQVUJMSUNLRVlUT0tFTj1OVUxM,ab|d8e955afd7c349a1824b215312453c09,Tml0by5Db2xsZWN0aW9ucy5EZXF1ZS5kbGw=,,TklUTy5ESVNQT1NBQkxFUywgQ1VMVFVSRT1ORVVUUkFMLCBQVUJMSUNLRVlUT0tFTj1OVUxM,ab|875c35266c50425ebb1fe0f40218e1bf,Tml0by5EaXNwb3NhYmxlcy5kbGw=,,TklUTy5BU1lOQ0VYLkNPTlRFWFQsIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49TlVMTA==,ab|7799fa9cff134036a1c0a04005e2fdc1,Tml0by5Bc3luY0V4LkNvbnRleHQuZGxs,,T0JKRUNUTElTVFZJRVcsIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49QjFDNUJGNTgxNDgxQkNENA==,ab|2e51a42fc565402d99fc8e534ed5c95b,T2JqZWN0TGlzdFZpZXcuZGxs,,I0EsQSxPQkpFQ1RMSVNUVklFVywgVkVSU0lPTj0yLjkuMS4yNTQxMCwgQ1VMVFVSRT1ORVVUUkFMLCBQVUJMSUNLRVlUT0tFTj1CMUM1QkY1ODE0ODFCQ0Q0,ab|2e51a42fc565402d99fc8e534ed5c95b,T2JqZWN0TGlzdFZpZXcuZGxs,,UVJDT0RFUiwgQ1VMVFVSRT1ORVVUUkFMLCBQVUJMSUNLRVlUT0tFTj1OVUxM,ab|c1533f5cda9940c3b28c92ad6d3ba906,UVJDb2Rlci5kbGw=,,U1lTVEVNLkJVRkZFUlMsIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49Q0M3QjEzRkZDRDJEREQ1MQ==,ab|116bb25c7c634e3cbecdedd0b9e1fe01,U3lzdGVtLkJ1ZmZlcnMuZGxs,,I0EsQSxTWVNURU0uQlVGRkVSUywgVkVSU0lPTj00LjAuMy4wLCBDVUxUVVJFPU5FVVRSQUwsIFBVQkxJQ0tFWVRPS0VOPUNDN0IxM0ZGQ0QyRERENTE=,ab|116bb25c7c634e3cbecdedd0b9e1fe01,U3lzdGVtLkJ1ZmZlcnMuZGxs,,U1lTVEVNLkRBVEEuSEFTSEZVTkNUSU9OLkNPUkUsIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49ODBDOTI4OEUzOTRDMTMyMg==,ab|6845599238cf4d439dac9f185e98cde6,U3lzdGVtLkRhdGEuSGFzaEZ1bmN0aW9uLkNvcmUuZGxs,,I0EsQSxTWVNURU0uREFUQS5IQVNIRlVOQ1RJT04uQ09SRSwgVkVSU0lPTj0yLjAuMC4wLCBDVUxUVVJFPU5FVVRSQUwsIFBVQkxJQ0tFWVRPS0VOPTgwQzkyODhFMzk0QzEzMjI=,ab|6845599238cf4d439dac9f185e98cde6,U3lzdGVtLkRhdGEuSGFzaEZ1bmN0aW9uLkNvcmUuZGxs,,U1lTVEVNLkRBVEEuSEFTSEZVTkNUSU9OLklOVEVSRkFDRVMsIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49ODBDOTI4OEUzOTRDMTMyMg==,ab|64381fcd12954710931ba2b7ad6ea742,U3lzdGVtLkRhdGEuSGFzaEZ1bmN0aW9uLkludGVyZmFjZXMuZGxs,,I0EsQSxTWVNURU0uREFUQS5IQVNIRlVOQ1RJT04uSU5URVJGQUNFUywgVkVSU0lPTj0yLjAuMC4wLCBDVUxUVVJFPU5FVVRSQUwsIFBVQkxJQ0tFWVRPS0VOPTgwQzkyODhFMzk0QzEzMjI=,ab|64381fcd12954710931ba2b7ad6ea742,U3lzdGVtLkRhdGEuSGFzaEZ1bmN0aW9uLkludGVyZmFjZXMuZGxs,,U1lTVEVNLk5VTUVSSUNTLlZFQ1RPUlMsIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49QjAzRjVGN0YxMUQ1MEEzQQ==,ab|26f4684d6ccb4790907c74654660550c,U3lzdGVtLk51bWVyaWNzLlZlY3RvcnMuZGxs,,I0EsQSxTWVNURU0uTlVNRVJJQ1MuVkVDVE9SUywgVkVSU0lPTj00LjEuNC4wLCBDVUxUVVJFPU5FVVRSQUwsIFBVQkxJQ0tFWVRPS0VOPUIwM0Y1RjdGMTFENTBBM0E=,ab|26f4684d6ccb4790907c74654660550c,U3lzdGVtLk51bWVyaWNzLlZlY3RvcnMuZGxs,,V0lORk9STUFOSU1BVElPTiwgQ1VMVFVSRT1ORVVUUkFMLCBQVUJMSUNLRVlUT0tFTj0zMTBGRDA3QjI1REY3OUIz,ab|520640872efc477285f9eb2f15c8399e,V2luRm9ybUFuaW1hdGlvbi5kbGw=,,I0EsQSxXSU5GT1JNQU5JTUFUSU9OLCBWRVJTSU9OPTEuNi4wLjQsIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49MzEwRkQwN0IyNURGNzlCMw==,ab|520640872efc477285f9eb2f15c8399e,V2luRm9ybUFuaW1hdGlvbi5kbGw=,,VklTVUFMUExVUywgQ1VMVFVSRT1ORVVUUkFMLCBQVUJMSUNLRVlUT0tFTj1OVUxM,ab|208c756db94949d491356be98c76cc9e,VmlzdWFsUGx1cy5kbGw=,,U0tJTlNPRlQuVklTVUFMU1RZTEVSLCBDVUxUVVJFPU5FVVRSQUwsIFBVQkxJQ0tFWVRPS0VOPTBGREE5RjQyM0UxRDk4MzA=,ab|16426fb571464b7fac3ab4297e185291,U2tpblNvZnQuVmlzdWFsU3R5bGVyLmRsbA==,,I0EsQSxTS0lOU09GVC5WSVNVQUxTVFlMRVIsIFZFUlNJT049Mi40LjAuMCwgQ1VMVFVSRT1ORVVUUkFMLCBQVUJMSUNLRVlUT0tFTj0wRkRBOUY0MjNFMUQ5ODMw,ab|16426fb571464b7fac3ab4297e185291,U2tpblNvZnQuVmlzdWFsU3R5bGVyLmRsbA==,,WkVST0lULkZSQU1FV09SSy5QUk9HUkVTUywgQ1VMVFVSRT1ORVVUUkFMLCBQVUJMSUNLRVlUT0tFTj1BMENFRTFCRkExMjBCOTUz,ab|af7ed5c0d14244eaa91a2a0bcb3608e5,WmVyb2l0LkZyYW1ld29yay5Qcm9ncmVzcy5kbGw=,,I0EsQSxaRVJPSVQuRlJBTUVXT1JLLlBST0dSRVNTLCBWRVJTSU9OPTEuMC4wLjAsIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49QTBDRUUxQkZBMTIwQjk1Mw==,ab|af7ed5c0d14244eaa91a2a0bcb3608e5,WmVyb2l0LkZyYW1ld29yay5Qcm9ncmVzcy5kbGw=,,TUlIQVpVUEFOLkhUVFBUT1NPQ0tTNVBST1hZLCBDVUxUVVJFPU5FVVRSQUwsIFBVQkxJQ0tFWVRPS0VOPU5VTEw=,ab|2365d29c303040b1b48f06b3e9bb23c4,TWloYVp1cGFuLkh0dHBUb1NvY2tzNVByb3h5LmRsbA==,,Qk9VTkNZQ0FTVExFLkNSWVBUTywgQ1VMVFVSRT1ORVVUUkFMLCBQVUJMSUNLRVlUT0tFTj0wRTk5Mzc1RTU0NzY5OTQy,ab|c8f7ec7b41814ab7aceba45ae5a07509,Qm91bmN5Q2FzdGxlLkNyeXB0by5kbGw=,,I0EsQSxCT1VOQ1lDQVNUTEUuQ1JZUFRPLCBWRVJTSU9OPTEuOC42LjAsIENVTFRVUkU9TkVVVFJBTCwgUFVCTElDS0VZVE9LRU49MEU5OTM3NUU1NDc2OTk0Mg==,ab|c8f7ec7b41814ab7aceba45ae5a07509,Qm91bmN5Q2FzdGxlLkNyeXB0by5kbGw=,";
                    char[] separator = new char[] { ',' };
                    this.string_2 = str5.Split(separator);
                    if ((this.string_0 == null) && !Class39.smethod_0())
                    {
                        return false;
                    }
                    this.int_2 = 0;
                }
                else
                {
                    if (num2 != 1)
                    {
                        return false;
                    }
                    this.int_0 = -1;
                    goto TR_000D;
                }
            TR_000B:
                if (this.int_2 >= this.string_2.Length)
                {
                    return false;
                }
                string str3 = this.string_2[this.int_2];
                if ((this.string_0 == null) || str3.Equals(this.string_0, StringComparison.Ordinal))
                {
                    Class39.Class43.Class45 class2 = new Class39.Class43.Class45();
                    class2.string_0 = str3;
                    string str = this.string_2[this.int_2 + 1];
                    int index = str.IndexOf('|');
                    if (index >= 0)
                    {
                        string str2 = str.Substring(0, index);
                        str = str.Substring(index + 1);
                        class2.bool_0 = str2.IndexOf('a') != -1;
                        class2.bool_1 = str2.IndexOf('b') != -1;
                        class2.bool_2 = str2.IndexOf('c') != -1;
                    }
                    class2.string_2 = str;
                    class2.string_3 = this.string_2[this.int_2 + 2];
                    string s = this.string_2[this.int_2 + 3];
                    if (s.Length != 0)
                    {
                        class2.int_0 = int.Parse(s, NumberStyles.AllowHexSpecifier, NumberFormatInfo.InvariantInfo);
                    }
                    this.class45_0 = class2;
                    this.int_0 = 1;
                    return true;
                }
            TR_000D:
                while (true)
                {
                    this.int_2 += 4;
                    break;
                }
                goto TR_000B;
            }

            [DebuggerHidden]
            void IEnumerator.Reset()
            {
                throw new NotSupportedException();
            }

            [DebuggerHidden]
            void IDisposable.Dispose()
            {
            }

            Class39.Class43.Class45 IEnumerator<Class39.Class43.Class45>.Current
            {
                [DebuggerHidden]
                get
                {
                    return this.class45_0;
                }
            }

            object IEnumerator.Current
            {
                [DebuggerHidden]
                get
                {
                    return this.class45_0;
                }
            }
        }

        internal sealed class Class45
        {
            public string string_0;
            private string string_1;
            public string string_2;
            public bool bool_0;
            public bool bool_1;
            public bool bool_2;
            public bool bool_3;
            public bool bool_4;
            public string string_3;
            private string string_4;
            public int int_0;

            public string method_0()
            {
                if (this.string_1 == null)
                {
                    byte[] bytes = Convert.FromBase64String(this.string_0);
                    this.string_1 = Encoding.UTF8.GetString(bytes, 0, bytes.Length);
                }
                return this.string_1;
            }

            public string method_1()
            {
                if (this.string_4 == null)
                {
                    byte[] bytes = Convert.FromBase64String(this.string_3);
                    this.string_4 = Encoding.UTF8.GetString(bytes, 0, bytes.Length);
                }
                return this.string_4;
            }
        }
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct Struct6
    {
        public Version version_0;
        public bool bool_0;
        public string string_0;
        public string string_1;
        public bool bool_1;
        public string string_2;
        public bool bool_2;
        public Struct6(string string_3)
        {
            this = new Class39.Struct6();
            this.version_0 = new Version();
            this.string_0 = string.Empty;
            char[] separator = new char[] { ',' };
            foreach (string str in string_3.Split(separator))
            {
                string str2 = str.Trim();
                if (str2.StartsWith("Version=", StringComparison.OrdinalIgnoreCase))
                {
                    this.version_0 = new Version(str2.Substring("Version=".Length));
                    this.bool_0 = true;
                }
                else if (str2.StartsWith("Culture=", StringComparison.OrdinalIgnoreCase))
                {
                    this.string_1 = str2.Substring("Culture=".Length);
                    if (this.string_1.Equals("neutral", StringComparison.OrdinalIgnoreCase))
                    {
                        this.string_1 = null;
                    }
                    this.bool_1 = true;
                }
                else if (!str2.StartsWith("PublicKeyToken=", StringComparison.OrdinalIgnoreCase))
                {
                    this.string_0 = str2;
                }
                else
                {
                    this.string_2 = str2.Substring("PublicKeyToken=".Length);
                    if (this.string_2.Equals("null", StringComparison.OrdinalIgnoreCase))
                    {
                        this.string_2 = null;
                    }
                    this.bool_2 = true;
                }
            }
        }

        public string method_0(bool bool_3)
        {
            StringBuilder builder = new StringBuilder();
            builder.Append(this.string_0);
            if (bool_3)
            {
                builder.Append(", VERSION=").Append(this.version_0);
            }
            builder.Append(", CULTURE=").Append(this.string_1 ?? "NEUTRAL").Append(", PUBLICKEYTOKEN=").Append(this.string_2 ?? "NULL");
            return builder.ToString();
        }
    }
}

