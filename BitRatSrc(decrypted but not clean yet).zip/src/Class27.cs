﻿using System;

internal static class Class27
{
    public static byte[] smethod_0(Array array_0, Struct15 struct15_0, Func<byte[]> func_0)
    {
        if (array_0 == null)
        {
            return null;
        }
        if (array_0.Length == 0)
        {
            return new byte[0];
        }
        int num5 = Buffer.ByteLength(array_0);
        byte[] buffer = new byte[num5];
        byte[] dst = null;
        byte[] buffer5 = array_0 as byte[];
        byte[] buffer3 = (buffer5 == null) ? new byte[Math.Min(num5, 0x10)] : buffer5;
        int srcOffset = 0;
        byte[] array = null;
        int num6 = num5 / 0x10;
        if (num6 > 0)
        {
            array = func_0();
            for (int i = 0; i < num6; i++)
            {
                int num3 = 0;
                if (buffer5 != null)
                {
                    num3 = srcOffset;
                }
                else
                {
                    Buffer.BlockCopy(array_0, srcOffset, dst, 0, 0x10);
                }
                int num = srcOffset;
                buffer[num++] = buffer3[num3 + array[0]];
                buffer[num++] = buffer3[num3 + array[1]];
                buffer[num++] = buffer3[num3 + array[2]];
                buffer[num++] = buffer3[num3 + array[3]];
                buffer[num++] = buffer3[num3 + array[4]];
                buffer[num++] = buffer3[num3 + array[5]];
                buffer[num++] = buffer3[num3 + array[6]];
                buffer[num++] = buffer3[num3 + array[7]];
                buffer[num++] = buffer3[num3 + array[8]];
                buffer[num++] = buffer3[num3 + array[9]];
                buffer[num++] = buffer3[num3 + array[10]];
                buffer[num++] = buffer3[num3 + array[11]];
                buffer[num++] = buffer3[num3 + array[12]];
                buffer[num++] = buffer3[num3 + array[13]];
                buffer[num++] = buffer3[num3 + array[14]];
                buffer[num++] = buffer3[num3 + array[15]];
                Class28.smethod_0(buffer, srcOffset, struct15_0.int_0);
                Class28.smethod_0(buffer, srcOffset + 4, struct15_0.int_1);
                Class28.smethod_0(buffer, srcOffset + 8, struct15_0.int_2);
                Class28.smethod_0(buffer, srcOffset + 12, struct15_0.int_3);
                srcOffset += 0x10;
            }
        }
        if (srcOffset < num5)
        {
            num6 = (num5 - srcOffset) / 4;
            if (num6 > 0)
            {
                if (array == null)
                {
                    array = func_0();
                }
                for (int i = 0; i < num6; i++)
                {
                    int num7 = 0;
                    if (buffer5 != null)
                    {
                        num7 = srcOffset;
                    }
                    else
                    {
                        Buffer.BlockCopy(array_0, srcOffset, dst, 0, 4);
                    }
                    int num4 = srcOffset;
                    buffer[num4++] = buffer3[num7 + array[0x10]];
                    buffer[num4++] = buffer3[num7 + array[0x11]];
                    buffer[num4++] = buffer3[num7 + array[0x12]];
                    buffer[num4++] = buffer3[num7 + array[0x13]];
                    Class28.smethod_0(buffer, srcOffset, struct15_0.int_0);
                    srcOffset += 4;
                }
            }
        }
        int count = num5 - srcOffset;
        if (count > 0)
        {
            Buffer.BlockCopy(array_0, srcOffset, buffer, srcOffset, count);
            Class28.smethod_1(buffer, srcOffset, struct15_0.int_0);
        }
        if (array != null)
        {
            Array.Clear(array, 0, array.Length);
        }
        if (dst != null)
        {
            Array.Clear(dst, 0, dst.Length);
        }
        return buffer;
    }

    public static T[] smethod_1<T>(byte[] byte_0, int int_0, Struct15 struct15_0, Func<byte[]> func_0, bool bool_0)
    {
        if (byte_0 == null)
        {
            return null;
        }
        if ((byte_0.Length - int_0) <= 0)
        {
            return new T[0];
        }
        int num5 = byte_0.Length - int_0;
        int num11 = Class24<T>.int_0;
        T[] dst = new T[num5 / num11];
        int dstOffset = 0;
        byte[] destinationArray = new byte[Math.Min(num5, 0x10)];
        byte[] src = null;
        byte[] buffer2 = !(dst is byte[]) ? new byte[destinationArray.Length] : (dst as byte[]);
        byte[] array = null;
        int num6 = (num5 - dstOffset) / 0x10;
        if (num6 > 0)
        {
            array = func_0();
            for (int i = 0; i < num6; i++)
            {
                Array.Copy(byte_0, dstOffset + int_0, destinationArray, 0, 0x10);
                Class28.smethod_0(destinationArray, 0, struct15_0.int_0);
                Class28.smethod_0(destinationArray, 4, struct15_0.int_1);
                Class28.smethod_0(destinationArray, 8, struct15_0.int_2);
                Class28.smethod_0(destinationArray, 12, struct15_0.int_3);
                int num = 0;
                int num2 = 0;
                if (buffer2 == dst)
                {
                    num2 = dstOffset;
                }
                buffer2[num2 + array[0]] = destinationArray[num++];
                buffer2[num2 + array[1]] = destinationArray[num++];
                buffer2[num2 + array[2]] = destinationArray[num++];
                buffer2[num2 + array[3]] = destinationArray[num++];
                buffer2[num2 + array[4]] = destinationArray[num++];
                buffer2[num2 + array[5]] = destinationArray[num++];
                buffer2[num2 + array[6]] = destinationArray[num++];
                buffer2[num2 + array[7]] = destinationArray[num++];
                buffer2[num2 + array[8]] = destinationArray[num++];
                buffer2[num2 + array[9]] = destinationArray[num++];
                buffer2[num2 + array[10]] = destinationArray[num++];
                buffer2[num2 + array[11]] = destinationArray[num++];
                buffer2[num2 + array[12]] = destinationArray[num++];
                buffer2[num2 + array[13]] = destinationArray[num++];
                buffer2[num2 + array[14]] = destinationArray[num++];
                buffer2[num2 + array[15]] = destinationArray[num++];
                if (buffer2 != dst)
                {
                    Buffer.BlockCopy(buffer2, 0, dst, dstOffset, 0x10);
                }
                dstOffset += 0x10;
            }
        }
        num6 = (num5 - dstOffset) / 4;
        if (num6 > 0)
        {
            if (array == null)
            {
                array = func_0();
            }
            for (int i = 0; i < num6; i++)
            {
                Array.Copy(byte_0, dstOffset + int_0, destinationArray, 0, 4);
                Class28.smethod_0(destinationArray, 0, struct15_0.int_0);
                int num4 = 0;
                int num7 = 0;
                if (buffer2 == dst)
                {
                    num7 = dstOffset;
                }
                buffer2[num7 + array[0x10]] = destinationArray[num4++];
                buffer2[num7 + array[0x11]] = destinationArray[num4++];
                buffer2[num7 + array[0x12]] = destinationArray[num4++];
                buffer2[num7 + array[0x13]] = destinationArray[num4++];
                if (buffer2 != dst)
                {
                    Buffer.BlockCopy(src, 0, dst, dstOffset, 4);
                }
                dstOffset += 4;
            }
        }
        int length = num5 - dstOffset;
        if (length > 0)
        {
            Array.Copy(byte_0, dstOffset + int_0, destinationArray, 0, length);
            Class28.smethod_1(destinationArray, 0, struct15_0.int_0);
            Buffer.BlockCopy(destinationArray, 0, dst, dstOffset, length);
        }
        if (array != null)
        {
            Array.Clear(array, 0, array.Length);
        }
        Array.Clear(destinationArray, 0, destinationArray.Length);
        if (src != null)
        {
            Array.Clear(src, 0, src.Length);
        }
        if (bool_0 && (!BitConverter.IsLittleEndian && ((dst.Length != 0) && (num11 != 1))))
        {
            smethod_2<T>(dst);
        }
        return dst;
    }

    private static void smethod_2<T>(T[] gparam_0)
    {
        int count = Class24<T>.int_0;
        if (count != 1)
        {
            byte[] dst = new byte[count];
            byte[] src = new byte[count];
            for (int i = 0; i < gparam_0.Length; i++)
            {
                Buffer.BlockCopy(gparam_0, i * count, dst, 0, count);
                if ((typeof(T) == typeof(float)) && !Struct14.bool_0)
                {
                    gparam_0[i] = (T) Class64.smethod_6(dst, 0);
                }
                else if ((typeof(T) == typeof(double)) && !Struct5.bool_0)
                {
                    gparam_0[i] = (T) Class64.smethod_7(dst, 0);
                }
                else
                {
                    int index = 0;
                    while (true)
                    {
                        if (index >= count)
                        {
                            Buffer.BlockCopy(src, 0, gparam_0, i * count, count);
                            break;
                        }
                        src[(count - index) - 1] = dst[index];
                        index++;
                    }
                }
            }
            Array.Clear(dst, 0, dst.Length);
            Array.Clear(src, 0, src.Length);
        }
    }
}

