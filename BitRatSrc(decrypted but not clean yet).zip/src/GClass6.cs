﻿using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;

public sealed class GClass6
{
    private byte[] byte_0 = new byte[0x30];
    public DateTime dateTime_0;
    private string string_0;

    public GClass6(string string_1)
    {
        this.string_0 = string_1;
    }

    public GEnum1 method_0()
    {
        GEnum1 enum2;
        switch (((byte) (this.byte_0[0] >> 6)))
        {
            case 0:
                enum2 = (GEnum1) 0;
                break;

            case 1:
                enum2 = (GEnum1) 1;
                break;

            case 2:
                enum2 = (GEnum1) 2;
                break;

            case 3:
                enum2 = (GEnum1) 3;
                break;

            default:
                enum2 = (GEnum1) 3;
                break;
        }
        return enum2;
    }

    public byte method_1()
    {
        return (byte) ((this.byte_0[0] & 0x38) >> 3);
    }

    public DateTime method_10()
    {
        return this.method_16(this.method_17(0x18));
    }

    public DateTime method_11()
    {
        return this.method_16(this.method_17(0x20)).Add(TimeZone.CurrentTimeZone.GetUtcOffset(DateTime.Now));
    }

    public DateTime method_12()
    {
        return this.method_16(this.method_17(40)).Add(TimeZone.CurrentTimeZone.GetUtcOffset(DateTime.Now));
    }

    public void method_13(DateTime dateTime_1)
    {
        this.method_18(40, dateTime_1);
    }

    public long method_14()
    {
        return (long) Math.Round(this.dateTime_0.Subtract(this.method_10()).Subtract(this.method_11().Subtract(this.method_12())).TotalMilliseconds);
    }

    public long method_15()
    {
        return (long) Math.Round((double) (this.method_11().Subtract(this.method_10()).Add(this.method_12().Subtract(this.dateTime_0)).TotalMilliseconds / 2.0));
    }

    private DateTime method_16(decimal decimal_0)
    {
        DateTime time = new DateTime(0x76c, 1, 1);
        return time.Add(TimeSpan.FromMilliseconds(Convert.ToDouble(decimal_0)));
    }

    private decimal method_17(byte byte_1)
    {
        decimal num = 0M;
        decimal num2 = 0M;
        int num3 = 0;
        while (true)
        {
            num = Conversion.Int(decimal.Add(decimal.Multiply(256M, num), new decimal(this.byte_0[byte_1 + num3])));
            num3++;
            if (num3 > 3)
            {
                num3 = 4;
                while (true)
                {
                    num2 = Conversion.Int(decimal.Add(decimal.Multiply(256M, num2), new decimal(this.byte_0[byte_1 + num3])));
                    num3++;
                    if (num3 > 7)
                    {
                        return Conversion.Int(decimal.Add(decimal.Multiply(num, 1000M), decimal.Divide(decimal.Multiply(num2, 1000M), 4294967296M)));
                    }
                }
            }
        }
    }

    private void method_18(byte byte_1, DateTime dateTime_1)
    {
        decimal num;
        decimal number = 0M;
        DateTime time = new DateTime(0x76c, 1, 1, 0, 0, 0);
        decimal decimal1 = new decimal(Conversion.Int(dateTime_1.Subtract(time).TotalMilliseconds));
        number = Conversion.Int(decimal.Divide(decimal.Multiply(decimal.Remainder(decimal1, 1000M), 4294967296M), 1000M));
        decimal num2 = Conversion.Int(decimal.Divide(decimal1, 1000M));
        for (num = 3M; decimal.Compare(num, 0M) >= 0; num = decimal.Add(num, -1M))
        {
            this.byte_0[Convert.ToInt32(decimal.Add(new decimal(byte_1), num))] = Convert.ToByte(Conversion.Int(decimal.Remainder(num2, 256M)));
            num2 = Conversion.Int(decimal.Divide(num2, 256M));
        }
        num2 = Conversion.Int(number);
        decimal num5 = 4M;
        for (num = 7M; decimal.Compare(num, num5) >= 0; num = decimal.Add(num, -1M))
        {
            this.byte_0[Convert.ToInt32(decimal.Add(new decimal(byte_1), num))] = Convert.ToByte(Conversion.Int(decimal.Remainder(num2, 256M)));
            num2 = Conversion.Int(decimal.Divide(num2, 256M));
        }
    }

    private void method_19()
    {
        this.byte_0[0] = 0x1b;
        int index = 1;
        while (true)
        {
            this.byte_0[index] = 0;
            index++;
            if (index > 0x2f)
            {
                this.method_13(DateTime.Now);
                return;
            }
        }
    }

    public object method_2()
    {
        object unknown;
        switch (((byte) (this.byte_0[0] & 7)))
        {
            case 0:
            case 6:
            case 7:
                unknown = GEnum0.Unknown;
                break;

            case 1:
                unknown = GEnum0.SymmetricActive;
                break;

            case 2:
                unknown = GEnum0.SymmetricPassive;
                break;

            case 3:
                unknown = GEnum0.Client;
                break;

            case 4:
                unknown = GEnum0.Server;
                break;

            case 5:
                unknown = GEnum0.Broadcast;
                break;

            default:
                break;
        }
        return unknown;
    }

    public bool method_20(bool bool_0)
    {
        IPEndPoint endPoint = new IPEndPoint(Dns.Resolve(this.string_0).AddressList[0], 0x7b);
        UdpClient client = new UdpClient();
        client.Connect(endPoint);
        client.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReceiveTimeout, 0xbb8);
        this.method_19();
        client.Send(this.byte_0, this.byte_0.Length);
        this.byte_0 = client.Receive(ref endPoint);
        if (!this.method_21())
        {
            throw new Exception("Invalid response from " + this.string_0);
        }
        this.dateTime_0 = DateTime.Now;
        if (bool_0)
        {
            this.method_22();
        }
        return true;
    }

    public bool method_21()
    {
        return !Conversions.ToBoolean(Operators.OrObject(this.byte_0.Length < 0x2f, Operators.CompareObjectNotEqual(this.method_2(), GEnum0.Server, true)));
    }

    private void method_22()
    {
        Struct29 struct2;
        DateTime time = DateTime.Now.AddMilliseconds((double) this.method_15());
        struct2.short_0 = (short) time.Year;
        struct2.short_1 = (short) time.Month;
        struct2.short_2 = (short) time.DayOfWeek;
        struct2.short_3 = (short) time.Day;
        struct2.short_4 = (short) time.Hour;
        struct2.short_5 = (short) time.Minute;
        struct2.short_6 = (short) time.Second;
        struct2.short_7 = (short) time.Millisecond;
        SetLocalTime(ref struct2);
    }

    public GEnum2 method_3()
    {
        byte num = this.byte_0[1];
        return ((num != 0) ? ((num != 1) ? ((num > 15) ? ((GEnum2) 3) : ((GEnum2) 2)) : ((GEnum2) 1)) : ((GEnum2) 0));
    }

    public int method_4()
    {
        return (int) Math.Round(Math.Pow(2.0, (double) this.byte_0[2]));
    }

    public double method_5()
    {
        return Math.Pow(2.0, (double) this.byte_0[3]);
    }

    public double method_6()
    {
        return (1000.0 * (((double) ((0x100 * ((0x100 * ((0x100 * this.byte_0[4]) + this.byte_0[5])) + this.byte_0[6])) + this.byte_0[7])) / 65536.0));
    }

    public double method_7()
    {
        return (1000.0 * (((double) ((0x100 * ((0x100 * ((0x100 * this.byte_0[8]) + this.byte_0[9])) + this.byte_0[10])) + this.byte_0[11])) / 65536.0));
    }

    public string method_8()
    {
        string str = string.Empty;
        GEnum2 enum2 = this.method_3();
        if (enum2 == ((GEnum2) 1))
        {
            if (this.byte_0[12] != 0)
            {
                str = str + Conversions.ToString(Strings.Chr(this.byte_0[12]));
            }
            if (this.byte_0[13] != 0)
            {
                str = str + Conversions.ToString(Strings.Chr(this.byte_0[13]));
            }
            if (this.byte_0[14] != 0)
            {
                str = str + Conversions.ToString(Strings.Chr(this.byte_0[14]));
            }
            if (this.byte_0[15] != 0)
            {
                str = str + Conversions.ToString(Strings.Chr(this.byte_0[15]));
            }
        }
        else if (enum2 == ((GEnum2) 2))
        {
            byte num = this.method_1();
            if (num != 3)
            {
                if (num != 4)
                {
                    str = "N/A";
                }
                else
                {
                    DateTime time = this.method_16(this.method_17(12));
                    str = time.Add(TimeZone.CurrentTimeZone.GetUtcOffset(DateTime.Now)).ToString();
                }
            }
            else
            {
                string[] textArray1 = new string[] { this.byte_0[12].ToString(), ".", this.byte_0[13].ToString(), ".", this.byte_0[14].ToString(), ".", this.byte_0[15].ToString() };
                string address = string.Concat(textArray1);
                str = Dns.GetHostByAddress(address).HostName + " (" + address + ")";
            }
        }
        return str;
    }

    public DateTime method_9()
    {
        return this.method_16(this.method_17(0x10)).Add(TimeZone.CurrentTimeZone.GetUtcOffset(DateTime.Now));
    }

    [DllImport("KERNEL32.DLL", CallingConvention=CallingConvention.StdCall, CharSet=CharSet.Unicode, SetLastError=true)]
    private static extern int SetLocalTime(ref Struct29 struct29_0);
    [Obsolete]
    public override string ToString()
    {
        StringBuilder builder = new StringBuilder("Leap Indicator: ");
        switch (this.method_0())
        {
            case ((GEnum1) 0):
                builder.Append("No warning");
                break;

            case ((GEnum1) 1):
                builder.Append("Last minute has 61 seconds");
                break;

            case ((GEnum1) 2):
                builder.Append("Last minute has 59 seconds");
                break;

            case ((GEnum1) 3):
                builder.Append("Alarm Condition (clock not synchronized)");
                break;

            default:
                break;
        }
        builder.Append("\r\nVersion number: " + this.method_1().ToString());
        builder.Append("\r\nMode: ");
        object left = this.method_2();
        if (Operators.ConditionalCompareObjectEqual(left, GEnum0.Unknown, true))
        {
            builder.Append("Unknown");
        }
        else if (Operators.ConditionalCompareObjectEqual(left, GEnum0.SymmetricActive, true))
        {
            builder.Append("Symmetric Active");
        }
        else if (Operators.ConditionalCompareObjectEqual(left, GEnum0.SymmetricPassive, true))
        {
            builder.Append("Symmetric Pasive");
        }
        else if (Operators.ConditionalCompareObjectEqual(left, GEnum0.Client, true))
        {
            builder.Append("Client");
        }
        else if (Operators.ConditionalCompareObjectEqual(left, GEnum0.Server, true))
        {
            builder.Append("Server");
        }
        else if (Operators.ConditionalCompareObjectEqual(left, GEnum0.Broadcast, true))
        {
            builder.Append("Broadcast");
        }
        builder.Append("\r\nStratum: ");
        switch (this.method_3())
        {
            case ((GEnum2) 1):
                builder.Append("Primary Reference");
                break;

            case ((GEnum2) 2):
                builder.Append("Secondary Reference");
                break;

            case ((GEnum2) 3):
                builder.Append("Unspecified");
                break;

            default:
                break;
        }
        builder.Append("\r\nLocal time: " + this.method_12().ToString());
        builder.Append("\r\nPrecision: " + this.method_5().ToString() + " ms");
        builder.Append("\r\nPoll Interval: " + this.method_4().ToString() + " s");
        builder.Append("\r\nReference ID: " + this.method_8().ToString());
        builder.Append("\r\nRoot Delay: " + this.method_6().ToString() + " ms");
        builder.Append("\r\nRoot Dispersion: " + this.method_7().ToString() + " ms");
        builder.Append("\r\nRound Trip Delay: " + this.method_14().ToString() + " ms");
        builder.Append("\r\nLocal Clock Offset: " + this.method_15().ToString() + " ms");
        builder.Append("\r\n");
        return builder.ToString();
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct Struct29
    {
        public short short_0;
        public short short_1;
        public short short_2;
        public short short_3;
        public short short_4;
        public short short_5;
        public short short_6;
        public short short_7;
    }
}

