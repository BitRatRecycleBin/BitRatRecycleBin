﻿using System;

internal interface Interface1
{
    string imethod_0();
    void imethod_1(bool bool_0, Interface2 interface2_0);
    byte[] imethod_10(byte[] byte_0);
    byte[] imethod_11(byte[] byte_0, int int_0, int int_1);
    int imethod_12(byte[] byte_0, int int_0);
    int imethod_13(byte[] byte_0, byte[] byte_1, int int_0);
    int imethod_14(byte[] byte_0, int int_0, int int_1, byte[] byte_1, int int_2);
    void imethod_15();
    int imethod_2();
    int imethod_3(int int_0);
    int imethod_4(int int_0);
    byte[] imethod_5(byte[] byte_0);
    byte[] imethod_6(byte[] byte_0, int int_0, int int_1);
    int imethod_7(byte[] byte_0, byte[] byte_1, int int_0);
    int imethod_8(byte[] byte_0, int int_0, int int_1, byte[] byte_1, int int_2);
    byte[] imethod_9();
}

