﻿using System;
using System.Reflection;
using System.Security;

internal static class Class84
{
    private static readonly bool bool_0 = smethod_0();

    private static bool smethod_0()
    {
        bool flag;
        if (Environment.Version.Major < 4)
        {
            flag = false;
        }
        else
        {
            Assembly objB = typeof(SecurityCriticalAttribute).Assembly;
            bool flag2 = false;
            object[] customAttributes = typeof(Class4).Assembly.GetCustomAttributes(false);
            int index = 0;
            while (true)
            {
                if (index >= customAttributes.Length)
                {
                    flag = flag2;
                    break;
                }
                object obj2 = customAttributes[index];
                if (obj2 is AllowPartiallyTrustedCallersAttribute)
                {
                    flag2 = true;
                }
                else
                {
                    Type type = obj2.GetType();
                    if (ReferenceEquals(type.Assembly, objB) && ("System.Security.SecurityRulesAttribute".Equals(type.FullName, StringComparison.Ordinal) && (((byte) type.GetProperty("RuleSet").GetValue(obj2, null)) != 2)))
                    {
                        flag = false;
                        break;
                    }
                }
                index++;
            }
        }
        return flag;
    }

    public static bool smethod_1()
    {
        return bool_0;
    }
}

