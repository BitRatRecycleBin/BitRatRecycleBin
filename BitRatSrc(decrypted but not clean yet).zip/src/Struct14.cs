﻿using System;
using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Explicit)]
internal struct Struct14
{
    public static bool bool_0;
    [FieldOffset(0)]
    private uint uint_0;
    [FieldOffset(0)]
    private float float_0;

    static Struct14()
    {
        Struct14 struct2 = new Struct14();
        struct2.float_0 = 8.167903E+07f;
        bool_0 = struct2.uint_0 == 0x4c9bca57;
    }
}

