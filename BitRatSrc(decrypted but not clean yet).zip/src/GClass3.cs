﻿using System;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

public sealed class GClass3 : Label
{
    private int int_0;
    private Control control_0;
    private Color color_0;

    public GClass3()
    {
        base.HandleCreated += new EventHandler(this.GClass3_HandleCreated);
        this.int_0 = 0;
        this.color_0 = Color.Blue;
        base.SetStyle(ControlStyles.Opaque, true);
        base.SetStyle(ControlStyles.OptimizedDoubleBuffer, false);
        base.SetStyle(ControlStyles.ResizeRedraw, true);
        this.Font = new Font("Microsoft Sans Serif", 28.2f);
    }

    private void GClass3_HandleCreated(object sender, EventArgs e)
    {
        this.vmethod_1(base.Parent);
    }

    public int method_0()
    {
        return this.int_0;
    }

    public void method_1(int int_1)
    {
        if ((int_1 >= 0) & (int_1 <= 0xff))
        {
            this.int_0 = int_1;
        }
        base.Invalidate();
    }

    protected override void OnPaint(PaintEventArgs paintEventArgs_0)
    {
        Bitmap image = new Bitmap(base.Width, base.Height);
        Graphics graphics = Graphics.FromImage(image);
        Color baseColor = this.color_0;
        if ((this.color_0 == Color.Transparent) && (this.vmethod_0() != null))
        {
            baseColor = this.vmethod_0().BackColor;
        }
        PaintEventArgs e = new PaintEventArgs(graphics, paintEventArgs_0.ClipRectangle);
        base.OnPaint(e);
        int num3 = base.Height - 1;
        int y = 0;
        while (y <= num3)
        {
            int num4 = base.Width - 1;
            int x = 0;
            while (true)
            {
                if (x > num4)
                {
                    y++;
                    break;
                }
                Color pixel = image.GetPixel(x, y);
                if (pixel.A != 0)
                {
                    image.SetPixel(x, y, Color.FromArgb(this.int_0, pixel));
                }
                else
                {
                    image.SetPixel(x, y, Color.FromArgb(0xff, baseColor));
                }
                x++;
            }
        }
        paintEventArgs_0.Graphics.DrawImage(image, 0, 0);
    }

    private Control vmethod_0()
    {
        return this.control_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    private void vmethod_1(Control control_1)
    {
        this.control_0 = control_1;
    }

    protected override System.Windows.Forms.CreateParams CreateParams
    {
        get
        {
            System.Windows.Forms.CreateParams createParams = base.CreateParams;
            createParams.ExStyle |= 0x20;
            return createParams;
        }
    }

    public override Color BackColor
    {
        get
        {
            return this.color_0;
        }
        set
        {
            this.color_0 = value;
            base.Invalidate();
        }
    }
}

