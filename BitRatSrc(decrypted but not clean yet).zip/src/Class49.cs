﻿using System;
using System.IO;

internal sealed class Class49 : Class48
{
    private readonly int int_0;
    private readonly Stream stream_0;

    public Class49(Stream stream_1, int int_1)
    {
        this.stream_0 = stream_1;
        this.int_0 = int_1;
    }

    public Stream method_0()
    {
        return this.stream_0;
    }

    private byte method_1(byte byte_0, long long_0)
    {
        byte num = (byte) ((this.int_0 ^ -559030707) ^ ((uint) long_0));
        return (byte) (byte_0 ^ num);
    }

    public override bool vmethod_0()
    {
        return this.method_0().CanRead;
    }

    public override bool vmethod_1()
    {
        return this.method_0().CanWrite;
    }

    public override void vmethod_10(long long_0)
    {
        this.method_0().SetLength(long_0);
    }

    public override int vmethod_11(byte[] byte_0, int int_1, int int_2)
    {
        long num = this.vmethod_4();
        byte[] buffer = new byte[int_2];
        int num2 = this.method_0().Read(buffer, 0, int_2);
        for (int i = 0; i < num2; i++)
        {
            byte_0[i + int_1] = this.method_1(buffer[i], num + i);
        }
        return num2;
    }

    public override void vmethod_13(byte[] byte_0, int int_1, int int_2)
    {
        long num = this.vmethod_4();
        byte[] buffer = new byte[int_2];
        for (int i = 0; i < int_2; i++)
        {
            buffer[i] = this.method_1(byte_0[i + int_1], num + i);
        }
        this.method_0().Write(buffer, 0, int_2);
    }

    public override bool vmethod_2()
    {
        return this.method_0().CanSeek;
    }

    public override long vmethod_3()
    {
        return this.method_0().Length;
    }

    public override long vmethod_4()
    {
        return this.method_0().Position;
    }

    public override void vmethod_5(long long_0)
    {
        this.method_0().Position = long_0;
    }

    public override void vmethod_8()
    {
        this.method_0().Flush();
    }

    public override long vmethod_9(long long_0, int int_1)
    {
        SeekOrigin begin;
        switch (int_1)
        {
            case 0:
                begin = SeekOrigin.Begin;
                break;

            case 1:
                begin = SeekOrigin.Current;
                break;

            case 2:
                begin = SeekOrigin.End;
                break;

            default:
                throw new ArgumentException();
        }
        return this.method_0().Seek(long_0, begin);
    }
}

