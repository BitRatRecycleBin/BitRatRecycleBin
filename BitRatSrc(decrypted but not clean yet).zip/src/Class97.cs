﻿using System;
using System.Reflection;

internal sealed class Class97 : Class94
{
    private MethodBase methodBase_0;

    public MethodBase method_2()
    {
        return this.methodBase_0;
    }

    public void method_3(MethodBase methodBase_1)
    {
        this.methodBase_0 = methodBase_1;
    }

    public IntPtr method_4()
    {
        return this.method_2().MethodHandle.GetFunctionPointer();
    }

    public override object vmethod_0()
    {
        return this.method_2();
    }

    public override void vmethod_1(object object_0)
    {
        this.method_3((MethodBase) object_0);
    }

    public override int vmethod_2()
    {
        return 0x17;
    }

    public override Class94 vmethod_3(Class94 class94_0)
    {
        base.method_1(class94_0.method_0());
        if (class94_0.vmethod_2() != 0x17)
        {
            throw new ArgumentOutOfRangeException();
        }
        this.method_3(((Class97) class94_0).method_2());
        return this;
    }

    public override Class94 vmethod_4()
    {
        Class97 class1 = new Class97();
        class1.method_3(this.methodBase_0);
        class1.method_1(base.method_0());
        return class1;
    }
}

