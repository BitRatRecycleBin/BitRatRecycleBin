﻿using System;
using System.Reflection;

internal sealed class Class107 : Class106
{
    private object object_0;
    private FieldInfo fieldInfo_0;
    private Class106 class106_0;

    private Class107()
    {
    }

    public Class107(FieldInfo fieldInfo_1, object object_1)
    {
        this.method_5(fieldInfo_1);
        this.method_3(object_1);
    }

    public Class107(FieldInfo fieldInfo_1, object object_1, Class106 class106_1) : this(fieldInfo_1, object_1)
    {
        this.method_7(class106_1);
    }

    public object method_2()
    {
        return this.object_0;
    }

    private void method_3(object object_1)
    {
        this.object_0 = object_1;
    }

    public FieldInfo method_4()
    {
        return this.fieldInfo_0;
    }

    private void method_5(FieldInfo fieldInfo_1)
    {
        this.fieldInfo_0 = fieldInfo_1;
    }

    public Class106 method_6()
    {
        return this.class106_0;
    }

    private void method_7(Class106 class106_1)
    {
        this.class106_0 = class106_1;
    }

    public override int vmethod_2()
    {
        return 0x12;
    }

    public override Class94 vmethod_3(Class94 class94_0)
    {
        base.method_1(class94_0.method_0());
        if (class94_0.vmethod_2() != 0x12)
        {
            throw new ArgumentOutOfRangeException();
        }
        Class107 class2 = (Class107) class94_0;
        this.method_3(class2.method_2());
        this.method_5(class2.method_4());
        return this;
    }

    public override Class94 vmethod_4()
    {
        Class107 class1 = new Class107();
        class1.method_3(this.method_2());
        class1.method_5(this.method_4());
        class1.method_7(this.method_6());
        class1.method_1(base.method_0());
        return class1;
    }
}

