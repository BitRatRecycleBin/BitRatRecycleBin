﻿using System;

public enum GEnum0
{
    SymmetricActive,
    SymmetricPassive,
    Client,
    Server,
    Broadcast,
    Unknown
}

