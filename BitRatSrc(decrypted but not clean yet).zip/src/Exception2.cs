﻿using System;

internal sealed class Exception2 : Exception0
{
    public Exception2()
    {
    }

    public Exception2(string string_0) : base(string_0)
    {
    }

    public Exception2(string string_0, Exception exception_0) : base(string_0, exception_0)
    {
    }
}

