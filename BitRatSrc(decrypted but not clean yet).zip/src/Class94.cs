﻿using System;

internal abstract class Class94
{
    private Type type_0;

    protected Class94()
    {
    }

    public Type method_0()
    {
        return this.type_0;
    }

    public void method_1(Type type_1)
    {
        this.type_0 = type_1;
    }

    public abstract object vmethod_0();
    public abstract void vmethod_1(object object_0);
    public abstract int vmethod_2();
    public abstract Class94 vmethod_3(Class94 class94_0);
    public abstract Class94 vmethod_4();
}

