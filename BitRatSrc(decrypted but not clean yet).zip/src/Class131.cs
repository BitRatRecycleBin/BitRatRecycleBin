﻿using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.CodeDom.Compiler;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;

[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0"), StandardModule, HideModuleName, DebuggerNonUserCode]
internal sealed class Class131
{
    private static ResourceManager resourceManager_0;
    private static CultureInfo cultureInfo_0;

    internal static ResourceManager smethod_0()
    {
        if (ReferenceEquals(resourceManager_0, null))
        {
            resourceManager_0 = new ResourceManager("BitRAT.Resources", typeof(Class131).Assembly);
        }
        return resourceManager_0;
    }

    internal static CultureInfo smethod_1()
    {
        return cultureInfo_0;
    }

    internal static Bitmap smethod_10()
    {
        return (Bitmap) smethod_0().GetObject("cog", cultureInfo_0);
    }

    internal static Bitmap smethod_11()
    {
        return (Bitmap) smethod_0().GetObject("connections", cultureInfo_0);
    }

    internal static byte[] smethod_12()
    {
        return (byte[]) smethod_0().GetObject("dl", cultureInfo_0);
    }

    internal static Bitmap smethod_13()
    {
        return (Bitmap) smethod_0().GetObject("err", cultureInfo_0);
    }

    internal static Bitmap smethod_14()
    {
        return (Bitmap) smethod_0().GetObject("ex", cultureInfo_0);
    }

    internal static Bitmap smethod_15()
    {
        return (Bitmap) smethod_0().GetObject("eye", cultureInfo_0);
    }

    internal static Bitmap smethod_16()
    {
        return (Bitmap) smethod_0().GetObject("ff", cultureInfo_0);
    }

    internal static Bitmap smethod_17()
    {
        return (Bitmap) smethod_0().GetObject("help", cultureInfo_0);
    }

    internal static Bitmap smethod_18()
    {
        return (Bitmap) smethod_0().GetObject("hvnc", cultureInfo_0);
    }

    internal static Bitmap smethod_19()
    {
        return (Bitmap) smethod_0().GetObject("icon-home-gr", cultureInfo_0);
    }

    internal static void smethod_2(CultureInfo cultureInfo_1)
    {
        cultureInfo_0 = cultureInfo_1;
    }

    internal static Bitmap smethod_20()
    {
        return (Bitmap) smethod_0().GetObject("icon-home-gr1", cultureInfo_0);
    }

    internal static Bitmap smethod_21()
    {
        return (Bitmap) smethod_0().GetObject("iconfinder_go-next_118773(2)", cultureInfo_0);
    }

    internal static Bitmap smethod_22()
    {
        return (Bitmap) smethod_0().GetObject("iconfinder_go-previous_118774(2)", cultureInfo_0);
    }

    internal static Bitmap smethod_23()
    {
        return (Bitmap) smethod_0().GetObject("ie", cultureInfo_0);
    }

    internal static Bitmap smethod_24()
    {
        return (Bitmap) smethod_0().GetObject("information", cultureInfo_0);
    }

    internal static Bitmap smethod_25()
    {
        return (Bitmap) smethod_0().GetObject("key", cultureInfo_0);
    }

    internal static Bitmap smethod_26()
    {
        return (Bitmap) smethod_0().GetObject("keyboard", cultureInfo_0);
    }

    internal static Bitmap smethod_27()
    {
        return (Bitmap) smethod_0().GetObject("left-arrow", cultureInfo_0);
    }

    internal static Bitmap smethod_28()
    {
        return (Bitmap) smethod_0().GetObject("loading", cultureInfo_0);
    }

    internal static Bitmap smethod_29()
    {
        return (Bitmap) smethod_0().GetObject("lock", cultureInfo_0);
    }

    internal static Bitmap smethod_3()
    {
        return (Bitmap) smethod_0().GetObject("417px-Checkmark_green.svg", cultureInfo_0);
    }

    internal static Bitmap smethod_30()
    {
        return (Bitmap) smethod_0().GetObject("logo", cultureInfo_0);
    }

    internal static Bitmap smethod_31()
    {
        return (Bitmap) smethod_0().GetObject("monitor", cultureInfo_0);
    }

    internal static Bitmap smethod_32()
    {
        return (Bitmap) smethod_0().GetObject("page_white_copy", cultureInfo_0);
    }

    internal static Bitmap smethod_33()
    {
        return (Bitmap) smethod_0().GetObject("page_white_copy1", cultureInfo_0);
    }

    internal static Bitmap smethod_34()
    {
        return (Bitmap) smethod_0().GetObject("png-transparent-error-icon-attention-angle-triangle-logo", cultureInfo_0);
    }

    internal static Bitmap smethod_35()
    {
        return (Bitmap) smethod_0().GetObject("poweroff", cultureInfo_0);
    }

    internal static Bitmap smethod_36()
    {
        return (Bitmap) smethod_0().GetObject("poweroff1", cultureInfo_0);
    }

    internal static Bitmap smethod_37()
    {
        return (Bitmap) smethod_0().GetObject("previous", cultureInfo_0);
    }

    internal static Bitmap smethod_38()
    {
        return (Bitmap) smethod_0().GetObject("processes", cultureInfo_0);
    }

    internal static Bitmap smethod_39()
    {
        return (Bitmap) smethod_0().GetObject("refresh", cultureInfo_0);
    }

    internal static Bitmap smethod_4()
    {
        return (Bitmap) smethod_0().GetObject("error", cultureInfo_0);
    }

    internal static Bitmap smethod_40()
    {
        return (Bitmap) smethod_0().GetObject("refresh1", cultureInfo_0);
    }

    internal static Bitmap smethod_41()
    {
        return (Bitmap) smethod_0().GetObject("regedit", cultureInfo_0);
    }

    internal static Bitmap smethod_42()
    {
        return (Bitmap) smethod_0().GetObject("registry", cultureInfo_0);
    }

    internal static Bitmap smethod_43()
    {
        return (Bitmap) smethod_0().GetObject("right-arrow", cultureInfo_0);
    }

    internal static Bitmap smethod_44()
    {
        return (Bitmap) smethod_0().GetObject("rsz_1refresh", cultureInfo_0);
    }

    internal static Bitmap smethod_45()
    {
        return (Bitmap) smethod_0().GetObject("rsz_refresh-png-image-24498", cultureInfo_0);
    }

    internal static Bitmap smethod_46()
    {
        return (Bitmap) smethod_0().GetObject("run", cultureInfo_0);
    }

    internal static Bitmap smethod_47()
    {
        return (Bitmap) smethod_0().GetObject("shell", cultureInfo_0);
    }

    internal static Bitmap smethod_48()
    {
        return (Bitmap) smethod_0().GetObject("sound", cultureInfo_0);
    }

    internal static Bitmap smethod_49()
    {
        return (Bitmap) smethod_0().GetObject("ssl", cultureInfo_0);
    }

    internal static Bitmap smethod_5()
    {
        return (Bitmap) smethod_0().GetObject("active-search-24", cultureInfo_0);
    }

    internal static Bitmap smethod_50()
    {
        return (Bitmap) smethod_0().GetObject("tb", cultureInfo_0);
    }

    internal static Bitmap smethod_51()
    {
        return (Bitmap) smethod_0().GetObject("tor", cultureInfo_0);
    }

    internal static Bitmap smethod_52()
    {
        return (Bitmap) smethod_0().GetObject("unlock", cultureInfo_0);
    }

    internal static Bitmap smethod_53()
    {
        return (Bitmap) smethod_0().GetObject("update", cultureInfo_0);
    }

    internal static Bitmap smethod_54()
    {
        return (Bitmap) smethod_0().GetObject("webcam", cultureInfo_0);
    }

    internal static Bitmap smethod_55()
    {
        return (Bitmap) smethod_0().GetObject("windows", cultureInfo_0);
    }

    internal static Bitmap smethod_6()
    {
        return (Bitmap) smethod_0().GetObject("application", cultureInfo_0);
    }

    internal static byte[] smethod_7()
    {
        return (byte[]) smethod_0().GetObject("bnd", cultureInfo_0);
    }

    internal static Bitmap smethod_8()
    {
        return (Bitmap) smethod_0().GetObject("browser", cultureInfo_0);
    }

    internal static Bitmap smethod_9()
    {
        return (Bitmap) smethod_0().GetObject("ch", cultureInfo_0);
    }
}

