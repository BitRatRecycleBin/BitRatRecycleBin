﻿using System;

internal sealed class Class108 : Class106
{
    private int int_0;

    public int method_2()
    {
        return this.int_0;
    }

    public void method_3(int int_1)
    {
        this.int_0 = int_1;
    }

    public override int vmethod_2()
    {
        return 13;
    }

    public override Class94 vmethod_3(Class94 class94_0)
    {
        base.method_1(class94_0.method_0());
        if (class94_0.vmethod_2() != 13)
        {
            throw new ArgumentOutOfRangeException();
        }
        this.method_3(((Class108) class94_0).method_2());
        return this;
    }

    public override Class94 vmethod_4()
    {
        Class108 class1 = new Class108();
        class1.method_3(this.int_0);
        class1.method_1(base.method_0());
        return class1;
    }
}

