﻿using System;
using System.Runtime.InteropServices;
using System.Threading;

[StructLayout(LayoutKind.Sequential)]
internal struct Struct7
{
    private long? nullable_0;
    public Struct7(string string_0)
    {
        this.nullable_0 = new long?(Class54.smethod_0(string_0));
    }

    public long method_0()
    {
        return Class54.smethod_2(this.nullable_0);
    }

    public void method_1(long long_0)
    {
        this.nullable_0 = new long?(Class54.smethod_1(long_0));
    }

    public void method_2()
    {
        this.nullable_0 = new long?(Class54.smethod_1(0L));
    }

    public int method_3()
    {
        return Class54.smethod_2(this.nullable_0).GetHashCode();
    }

    public bool method_4(long long_0)
    {
        return Class54.smethod_2(this.nullable_0).Equals(long_0);
    }

    public bool method_5(object object_0)
    {
        return Class54.smethod_2(this.nullable_0).Equals(object_0);
    }

    public int method_6(long long_0)
    {
        return Class54.smethod_2(this.nullable_0).CompareTo(long_0);
    }

    public int method_7(object object_0)
    {
        return Class54.smethod_2(this.nullable_0).CompareTo(object_0);
    }

    public TypeCode method_8()
    {
        return TypeCode.Int64;
    }

    public string method_9()
    {
        return Class54.smethod_2(this.nullable_0).ToString();
    }

    public string method_10(string string_0)
    {
        return Class54.smethod_2(this.nullable_0).ToString(string_0);
    }

    public string method_11(IFormatProvider iformatProvider_0)
    {
        return Class54.smethod_2(this.nullable_0).ToString(iformatProvider_0);
    }

    public string method_12(string string_0, IFormatProvider iformatProvider_0)
    {
        return Class54.smethod_2(this.nullable_0).ToString(string_0, iformatProvider_0);
    }

    public long method_13()
    {
        Thread.MemoryBarrier();
        return Class54.smethod_2(this.nullable_0);
    }

    public void method_14(long long_0)
    {
        Thread.MemoryBarrier();
        this.nullable_0 = new long?(Class54.smethod_1(long_0));
    }

    public long method_15()
    {
        bool lockTaken = false;
        Monitor.Enter(Class82.object_0, ref lockTaken);
        long num = Class54.smethod_2(this.nullable_0) + 1L;
        this.nullable_0 = new long?(Class54.smethod_1(num));
        return num;
    }

    public long method_16()
    {
        bool lockTaken = false;
        Monitor.Enter(Class82.object_0, ref lockTaken);
        long num = Class54.smethod_2(this.nullable_0) - 1L;
        this.nullable_0 = new long?(Class54.smethod_1(num));
        return num;
    }

    public long method_17(long long_0)
    {
        bool lockTaken = false;
        Monitor.Enter(Class82.object_0, ref lockTaken);
        long num = Class54.smethod_2(this.nullable_0) + long_0;
        this.nullable_0 = new long?(Class54.smethod_1(num));
        return num;
    }

    public long method_18(long long_0)
    {
        bool lockTaken = false;
        Monitor.Enter(Class82.object_0, ref lockTaken);
        this.nullable_0 = new long?(Class54.smethod_1(long_0));
        return Class54.smethod_2(this.nullable_0);
    }

    public long method_19(long long_0, long long_1)
    {
        bool lockTaken = false;
        Monitor.Enter(Class82.object_0, ref lockTaken);
        long num1 = Class54.smethod_2(this.nullable_0);
        if (num1 == long_1)
        {
            this.nullable_0 = new long?(Class54.smethod_1(long_0));
        }
        return num1;
    }
}

