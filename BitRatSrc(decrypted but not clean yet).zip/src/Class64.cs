﻿using System;
using System.IO;

internal static class Class64
{
    public static void smethod_0(int int_0, byte[] byte_0, int int_1)
    {
        byte_0[int_1] = (byte) int_0;
        byte_0[int_1 + 1] = (byte) (int_0 >> 8);
        byte_0[int_1 + 2] = (byte) (int_0 >> 0x10);
        byte_0[int_1 + 3] = (byte) (int_0 >> 0x18);
    }

    public static void smethod_1(long long_0, byte[] byte_0, int int_0)
    {
        byte_0[int_0] = (byte) long_0;
        byte_0[int_0 + 1] = (byte) (long_0 >> 8);
        byte_0[int_0 + 2] = (byte) (long_0 >> 0x10);
        byte_0[int_0 + 3] = (byte) (long_0 >> 0x18);
        byte_0[int_0 + 4] = (byte) (long_0 >> 0x20);
        byte_0[int_0 + 5] = (byte) (long_0 >> 40);
        byte_0[int_0 + 6] = (byte) (long_0 >> 0x30);
        byte_0[int_0 + 7] = (byte) (long_0 >> 0x38);
    }

    public static byte[] smethod_2(int int_0)
    {
        if (BitConverter.IsLittleEndian)
        {
            return BitConverter.GetBytes(int_0);
        }
        byte[] buffer = new byte[4];
        smethod_0(int_0, buffer, 0);
        return buffer;
    }

    public static byte[] smethod_3(long long_0)
    {
        if (BitConverter.IsLittleEndian)
        {
            return BitConverter.GetBytes(long_0);
        }
        byte[] buffer = new byte[8];
        smethod_1(long_0, buffer, 0);
        return buffer;
    }

    public static int smethod_4(byte[] byte_0, int int_0)
    {
        return (!BitConverter.IsLittleEndian ? (((byte_0[int_0] | (byte_0[int_0 + 1] << 8)) | (byte_0[int_0 + 2] << 0x10)) | (byte_0[int_0 + 3] << 0x18)) : BitConverter.ToInt32(byte_0, int_0));
    }

    public static long smethod_5(byte[] byte_0, int int_0)
    {
        return (!BitConverter.IsLittleEndian ? ((long) (((((((byte_0[int_0] | (byte_0[int_0 + 1] << 8)) | (byte_0[int_0 + 2] << 0x10)) | (byte_0[int_0 + 3] << 0x18)) | (byte_0[int_0 + 4] << 0x20)) | (byte_0[int_0 + 5] << 40)) | (byte_0[int_0 + 6] << 0x30)) | (byte_0[int_0 + 7] << 0x38))) : BitConverter.ToInt64(byte_0, int_0));
    }

    public static float smethod_6(byte[] byte_0, int int_0)
    {
        if (BitConverter.IsLittleEndian && Struct14.bool_0)
        {
            return BitConverter.ToSingle(byte_0, int_0);
        }
        BinaryReader reader1 = new BinaryReader(new MemoryStream(byte_0, int_0, 4, false));
        float num = reader1.ReadSingle();
        reader1.Close();
        return num;
    }

    public static double smethod_7(byte[] byte_0, int int_0)
    {
        if (BitConverter.IsLittleEndian && Struct5.bool_0)
        {
            return BitConverter.ToDouble(byte_0, int_0);
        }
        BinaryReader reader1 = new BinaryReader(new MemoryStream(byte_0, int_0, 8, false));
        double num = reader1.ReadDouble();
        reader1.Close();
        return num;
    }
}

