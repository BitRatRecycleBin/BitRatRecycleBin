﻿using System;

internal sealed class Class99 : Class94
{
    private long long_0;

    public long method_2()
    {
        return this.long_0;
    }

    public void method_3(long long_1)
    {
        this.long_0 = long_1;
    }

    public override object vmethod_0()
    {
        return this.method_2();
    }

    public override void vmethod_1(object object_0)
    {
        if (object_0 is ulong)
        {
            this.method_3((long) ((ulong) object_0));
        }
        else if (object_0 is float)
        {
            this.method_3((long) ((float) object_0));
        }
        else if (object_0 is double)
        {
            this.method_3((long) ((double) object_0));
        }
        else
        {
            this.method_3(Convert.ToInt64(object_0));
        }
    }

    public override int vmethod_2()
    {
        return 11;
    }

    public override Class94 vmethod_3(Class94 class94_0)
    {
        base.method_1(class94_0.method_0());
        switch (class94_0.vmethod_2())
        {
            case 0:
                this.method_3((long) ((Class119) class94_0).method_2());
                break;

            case 2:
                this.method_3((long) Convert.ToByte(((Class103) class94_0).method_2()));
                break;

            case 4:
                this.method_3(Convert.ToInt64(((Class102) class94_0).method_2()));
                break;

            case 7:
                this.method_3((long) ((Class118) class94_0).method_2());
                break;

            case 8:
                this.method_3((long) ((ulong) ((Class100) class94_0).method_2()));
                break;

            case 9:
                this.method_3((long) ((Class115) class94_0).method_2());
                break;

            case 10:
                this.method_3((long) ((Class114) class94_0).method_2());
                break;

            case 11:
                this.method_3(((Class99) class94_0).method_2());
                break;

            case 14:
                this.method_3((long) ((Class105) class94_0).method_2());
                break;

            case 15:
                this.method_3((long) ((Class101) class94_0).method_2());
                break;

            case 0x11:
                this.method_3((long) ((Class117) class94_0).method_2());
                break;

            case 0x13:
                this.method_3((long) ((Class120) class94_0).method_2());
                break;

            case 0x15:
                this.method_3((long) ((Class104) class94_0).method_2());
                break;

            case 0x16:
                this.method_3((long) ((Class121) class94_0).method_2());
                break;

            case 0x18:
                this.method_3(Convert.ToInt64(((Class98) class94_0).method_2()));
                break;

            default:
                throw new ArgumentOutOfRangeException();
        }
        return this;
    }

    public override Class94 vmethod_4()
    {
        Class99 class1 = new Class99();
        class1.method_3(this.long_0);
        class1.method_1(base.method_0());
        return class1;
    }
}

