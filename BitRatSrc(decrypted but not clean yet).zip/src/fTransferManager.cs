﻿using BrightIdeasSoftware;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.Collections.Concurrent;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

[DesignerGenerated]
public sealed class fTransferManager : Form
{
    private IContainer icontainer_0;
    private ContextMenuStrip contextMenuStrip_0;
    private ToolStripMenuItem toolStripMenuItem_0;
    private ToolStripSeparator toolStripSeparator_0;
    private ToolStripMenuItem toolStripMenuItem_1;
    private ToolStripMenuItem toolStripMenuItem_2;
    private ToolStripSeparator toolStripSeparator_1;
    private ToolStripMenuItem toolStripMenuItem_3;
    private ToolStripMenuItem toolStripMenuItem_4;
    private ToolStripMenuItem toolStripMenuItem_5;
    private ToolStripSeparator toolStripSeparator_2;
    private FastObjectListView fastObjectListView_0;
    private OLVColumn olvcolumn_0;
    private OLVColumn olvcolumn_1;
    private OLVColumn olvcolumn_2;
    private OLVColumn olvcolumn_3;
    private OLVColumn olvcolumn_4;
    private OLVColumn olvcolumn_5;
    private OLVColumn olvcolumn_6;
    private OLVColumn olvcolumn_7;
    private StatusStrip statusStrip_0;
    private ToolStripStatusLabel toolStripStatusLabel_0;
    private ToolStripStatusLabel toolStripStatusLabel_1;
    private Timer timer_0;
    private OLVColumn olvcolumn_8;
    private ToolStripStatusLabel toolStripStatusLabel_2;
    private ToolStripStatusLabel toolStripStatusLabel_3;
    private ToolStripStatusLabel toolStripStatusLabel_4;
    private ToolStripStatusLabel toolStripStatusLabel_5;
    private BackgroundWorker backgroundWorker_0;
    private ToolStripMenuItem toolStripMenuItem_6;
    private ToolStripMenuItem toolStripMenuItem_7;
    private ToolStripSeparator toolStripSeparator_3;
    private ToolStripMenuItem toolStripMenuItem_8;
    private ToolStripSeparator toolStripSeparator_4;
    private ToolStripStatusLabel toolStripStatusLabel_6;
    private OLVColumn olvcolumn_9;
    private ToolStripMenuItem toolStripMenuItem_9;
    private ToolStripMenuItem toolStripMenuItem_10;
    private ToolStripMenuItem toolStripMenuItem_11;
    private ToolStripMenuItem toolStripMenuItem_12;
    private ToolStripMenuItem toolStripMenuItem_13;
    private ToolStripMenuItem toolStripMenuItem_14;
    private ToolStripMenuItem toolStripMenuItem_15;
    private ToolStripMenuItem toolStripMenuItem_16;
    private ToolStripSeparator toolStripSeparator_5;
    private ToolStripMenuItem toolStripMenuItem_17;
    private ToolStripSeparator toolStripSeparator_6;
    private BarRenderer barRenderer_0;
    public Collection collection_0;
    public ConcurrentStack<cTransfer> concurrentStack_0;
    public ConcurrentStack<cTransfer> concurrentStack_1;
    public ConcurrentStack<cTransfer> concurrentStack_2;
    private bool bool_0;

    public fTransferManager();
    [DebuggerNonUserCode]
    protected override void Dispose(bool disposing);
    private void fTransferManager_FormClosing(object sender, FormClosingEventArgs e);
    private void fTransferManager_Load(object sender, EventArgs e);
    [DebuggerStepThrough]
    private void InitializeComponent();
    public void method_0();
    public void method_1(ref ListView listView_0, string string_0, int int_0);
    public void method_10();
    public void method_11();
    public void method_12(string string_0, string string_1, string string_2, string string_3, string string_4, string string_5);
    public void method_13();
    public void method_14(string string_0);
    public void method_15(string string_0, int int_0);
    public void method_16(string string_0, int int_0, string string_1);
    public void method_17(string string_0);
    private void method_18(object sender, EventArgs e);
    private void method_19();
    public void method_2(string string_0, string string_1, string string_2, string string_3, string string_4);
    private void method_20(object sender, EventArgs e);
    private void method_21(object sender, EventArgs e);
    private void method_22(object sender, EventArgs e);
    private void method_23(object sender, EventArgs e);
    private void method_24(object sender, MouseEventArgs e);
    private void method_25(object sender, EventArgs e);
    public void method_26();
    private void method_27(object sender, FormatRowEventArgs e);
    private void method_28(object sender, EventArgs e);
    private void method_29(object sender, EventArgs e);
    public void method_3();
    private void method_30(object sender, EventArgs e);
    private void method_31(object sender, DoWorkEventArgs e);
    private void method_32(object sender, CreateGroupsEventArgs e);
    private void method_33(object sender, EventArgs e);
    private void method_34(object sender, EventArgs e);
    private void method_35(object sender, EventArgs e);
    private void method_36(object sender, EventArgs e);
    private void method_37(object sender, EventArgs e);
    private void method_38(object sender, DoWorkEventArgs e);
    private void method_39(object sender, EventArgs e);
    public void method_4();
    private void method_40(object sender, GroupExpandingCollapsingEventArgs e);
    private void method_41(object sender, CreateGroupsEventArgs e);
    private void method_42(object sender, ColumnWidthChangingEventArgs e);
    public void method_5(string string_0, string string_1, string string_2, string string_3, long long_0, string string_4, string string_5, string string_6);
    public void method_6();
    public void method_7();
    public void method_8();
    public void method_9();
    internal virtual ContextMenuStrip vmethod_0();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_1(ContextMenuStrip contextMenuStrip_1);
    internal virtual ToolStripSeparator vmethod_10();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_11(ToolStripSeparator toolStripSeparator_7);
    internal virtual ToolStripMenuItem vmethod_12();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_13(ToolStripMenuItem toolStripMenuItem_18);
    internal virtual ToolStripMenuItem vmethod_14();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_15(ToolStripMenuItem toolStripMenuItem_18);
    internal virtual ToolStripMenuItem vmethod_16();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_17(ToolStripMenuItem toolStripMenuItem_18);
    internal virtual ToolStripSeparator vmethod_18();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_19(ToolStripSeparator toolStripSeparator_7);
    internal virtual ToolStripMenuItem vmethod_2();
    internal virtual FastObjectListView vmethod_20();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_21(FastObjectListView fastObjectListView_1);
    internal virtual OLVColumn vmethod_22();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_23(OLVColumn olvcolumn_10);
    internal virtual OLVColumn vmethod_24();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_25(OLVColumn olvcolumn_10);
    internal virtual OLVColumn vmethod_26();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_27(OLVColumn olvcolumn_10);
    internal virtual OLVColumn vmethod_28();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_29(OLVColumn olvcolumn_10);
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_3(ToolStripMenuItem toolStripMenuItem_18);
    internal virtual OLVColumn vmethod_30();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_31(OLVColumn olvcolumn_10);
    internal virtual OLVColumn vmethod_32();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_33(OLVColumn olvcolumn_10);
    internal virtual OLVColumn vmethod_34();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_35(OLVColumn olvcolumn_10);
    internal virtual OLVColumn vmethod_36();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_37(OLVColumn olvcolumn_10);
    internal virtual StatusStrip vmethod_38();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_39(StatusStrip statusStrip_1);
    internal virtual ToolStripSeparator vmethod_4();
    internal virtual ToolStripStatusLabel vmethod_40();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_41(ToolStripStatusLabel toolStripStatusLabel_7);
    internal virtual ToolStripStatusLabel vmethod_42();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_43(ToolStripStatusLabel toolStripStatusLabel_7);
    internal virtual Timer vmethod_44();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_45(Timer timer_1);
    internal virtual OLVColumn vmethod_46();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_47(OLVColumn olvcolumn_10);
    internal virtual ToolStripStatusLabel vmethod_48();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_49(ToolStripStatusLabel toolStripStatusLabel_7);
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_5(ToolStripSeparator toolStripSeparator_7);
    internal virtual ToolStripStatusLabel vmethod_50();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_51(ToolStripStatusLabel toolStripStatusLabel_7);
    internal virtual ToolStripStatusLabel vmethod_52();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_53(ToolStripStatusLabel toolStripStatusLabel_7);
    internal virtual ToolStripStatusLabel vmethod_54();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_55(ToolStripStatusLabel toolStripStatusLabel_7);
    internal virtual BackgroundWorker vmethod_56();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_57(BackgroundWorker backgroundWorker_1);
    internal virtual ToolStripMenuItem vmethod_58();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_59(ToolStripMenuItem toolStripMenuItem_18);
    internal virtual ToolStripMenuItem vmethod_6();
    internal virtual ToolStripMenuItem vmethod_60();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_61(ToolStripMenuItem toolStripMenuItem_18);
    internal virtual ToolStripSeparator vmethod_62();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_63(ToolStripSeparator toolStripSeparator_7);
    internal virtual ToolStripMenuItem vmethod_64();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_65(ToolStripMenuItem toolStripMenuItem_18);
    internal virtual ToolStripSeparator vmethod_66();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_67(ToolStripSeparator toolStripSeparator_7);
    internal virtual ToolStripStatusLabel vmethod_68();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_69(ToolStripStatusLabel toolStripStatusLabel_7);
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_7(ToolStripMenuItem toolStripMenuItem_18);
    internal virtual OLVColumn vmethod_70();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_71(OLVColumn olvcolumn_10);
    internal virtual ToolStripMenuItem vmethod_72();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_73(ToolStripMenuItem toolStripMenuItem_18);
    internal virtual ToolStripMenuItem vmethod_74();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_75(ToolStripMenuItem toolStripMenuItem_18);
    internal virtual ToolStripMenuItem vmethod_76();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_77(ToolStripMenuItem toolStripMenuItem_18);
    internal virtual ToolStripMenuItem vmethod_78();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_79(ToolStripMenuItem toolStripMenuItem_18);
    internal virtual ToolStripMenuItem vmethod_8();
    internal virtual ToolStripMenuItem vmethod_80();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_81(ToolStripMenuItem toolStripMenuItem_18);
    internal virtual ToolStripMenuItem vmethod_82();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_83(ToolStripMenuItem toolStripMenuItem_18);
    internal virtual ToolStripMenuItem vmethod_84();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_85(ToolStripMenuItem toolStripMenuItem_18);
    internal virtual ToolStripMenuItem vmethod_86();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_87(ToolStripMenuItem toolStripMenuItem_18);
    internal virtual ToolStripSeparator vmethod_88();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_89(ToolStripSeparator toolStripSeparator_7);
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_9(ToolStripMenuItem toolStripMenuItem_18);
    internal virtual ToolStripMenuItem vmethod_90();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_91(ToolStripMenuItem toolStripMenuItem_18);
    internal virtual ToolStripSeparator vmethod_92();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_93(ToolStripSeparator toolStripSeparator_7);
    internal virtual BarRenderer vmethod_94();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_95(BarRenderer barRenderer_1);

    private delegate void Delegate167();

    private delegate void Delegate168();

    private delegate void Delegate169();

    private delegate void Delegate170(string string_0, string string_1, string string_2, string string_3, string string_4, string string_5);

    private delegate void Delegate171(string string_0);

    private delegate void Delegate172();

    private delegate void Delegate173(ref ListView listView_0, string string_0, int int_0);

    private delegate void Delegate174(string string_0, string string_1, string string_2, string string_3, string string_4);

    private delegate void Delegate175();

    private delegate void Delegate176(string string_0, int int_0, string string_1);

    private delegate void Delegate177();

    private delegate void Delegate178();

    private delegate void Delegate179(string string_0, int int_0);

    private delegate void Delegate180();

    private delegate void Delegate181();

    private delegate void Delegate182(string string_0, string string_1, string string_2, string string_3, long long_0, string string_4, string string_5, string string_6);
}

