﻿using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.Collections;
using System.Windows.Forms;

internal sealed class Class143 : IComparer
{
    private int int_0;
    private SortOrder sortOrder_0;

    public Class143(int int_1, SortOrder sortOrder_1)
    {
        this.int_0 = int_1;
        this.sortOrder_0 = sortOrder_1;
    }

    public int Compare(object object_0, object object_1)
    {
        ListViewItem item = (ListViewItem) object_0;
        ListViewItem item2 = (ListViewItem) object_1;
        string expression = (item.SubItems.Count > this.int_0) ? item.SubItems[this.int_0].Text : string.Empty;
        string str2 = (item2.SubItems.Count > this.int_0) ? item2.SubItems[this.int_0].Text : string.Empty;
        return ((this.sortOrder_0 != SortOrder.Ascending) ? (!(Versioned.IsNumeric(expression) & Versioned.IsNumeric(str2)) ? (!(Information.IsDate(expression) & Information.IsDate(str2)) ? string.Compare(str2, expression) : DateTime.Parse(str2).CompareTo(DateTime.Parse(expression))) : Conversion.Val(str2).CompareTo(Conversion.Val(expression))) : (!(Versioned.IsNumeric(expression) & Versioned.IsNumeric(str2)) ? (!(Information.IsDate(expression) & Information.IsDate(str2)) ? string.Compare(expression, str2) : DateTime.Parse(expression).CompareTo(DateTime.Parse(str2))) : Conversion.Val(expression).CompareTo(Conversion.Val(str2))));
    }
}

