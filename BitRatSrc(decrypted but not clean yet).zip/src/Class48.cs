﻿using System;

internal abstract class Class48 : IDisposable
{
    protected Class48()
    {
    }

    public void Dispose()
    {
        this.vmethod_6();
    }

    public abstract bool vmethod_0();
    public abstract bool vmethod_1();
    public abstract void vmethod_10(long long_0);
    public abstract int vmethod_11(byte[] byte_0, int int_0, int int_1);
    public virtual int vmethod_12()
    {
        byte[] buffer = new byte[1];
        return ((this.vmethod_11(buffer, 0, 1) != 0) ? buffer[0] : -1);
    }

    public abstract void vmethod_13(byte[] byte_0, int int_0, int int_1);
    public virtual void vmethod_14(byte byte_0)
    {
        byte[] buffer = new byte[] { byte_0 };
        this.vmethod_13(buffer, 0, 1);
    }

    public abstract bool vmethod_2();
    public abstract long vmethod_3();
    public abstract long vmethod_4();
    public abstract void vmethod_5(long long_0);
    public virtual void vmethod_6()
    {
        this.vmethod_7(true);
        GC.SuppressFinalize(this);
    }

    protected virtual void vmethod_7(bool bool_0)
    {
    }

    public abstract void vmethod_8();
    public abstract long vmethod_9(long long_0, int int_0);
}

