﻿using System;

internal static class Class56
{
}

