﻿internal interface Interface8
{
    Interface5 imethod_0();
}

