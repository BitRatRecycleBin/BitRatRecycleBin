﻿using System;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;

public sealed class GClass2 : ApplicationContext
{
    private ContextMenuStrip contextMenuStrip_0;
    private ToolStripMenuItem toolStripMenuItem_0;
    private ToolStripSeparator toolStripSeparator_0;
    private ToolStripSeparator toolStripSeparator_1;
    private ToolStripMenuItem toolStripMenuItem_1;
    private ToolStripMenuItem toolStripMenuItem_2;
    private NotifyIcon notifyIcon_0;
    private fMain fMain_0;

    public GClass2(fMain fMain_1)
    {
        base.ThreadExit += new EventHandler(this.GClass2_ThreadExit);
        this.fMain_0 = fMain_1;
        this.vmethod_3(new ToolStripMenuItem("Restore"));
        this.vmethod_5(new ToolStripSeparator());
        this.vmethod_11(new ToolStripMenuItem("Settings"));
        this.vmethod_7(new ToolStripSeparator());
        this.vmethod_9(new ToolStripMenuItem("Exit"));
        this.vmethod_1(new ContextMenuStrip());
        ToolStripItem[] toolStripItems = new ToolStripItem[] { this.vmethod_2(), this.vmethod_4(), this.vmethod_10(), this.vmethod_6(), this.vmethod_8() };
        this.vmethod_0().Items.AddRange(toolStripItems);
        this.vmethod_0().Enabled = false;
        this.vmethod_13(new NotifyIcon());
        this.vmethod_12().Icon = this.fMain_0.Icon;
        this.vmethod_12().ContextMenuStrip = this.vmethod_0();
        this.vmethod_12().Text = "BitRAT v" + Class130.struct3_8.method_1();
        this.vmethod_12().Visible = true;
        new Thread(new ThreadStart(this._Lambda$__29-0)).Start();
    }

    [CompilerGenerated]
    private void _Lambda$__29-0()
    {
        this.method_0();
    }

    private void GClass2_ThreadExit(object sender, EventArgs e)
    {
        this.vmethod_12().Visible = false;
    }

    private void method_0()
    {
        while (!this.fMain_0.struct18_0.method_0())
        {
            Thread.Sleep(0x3e8);
        }
        this.method_1();
    }

    public void method_1()
    {
        if (this.vmethod_0().InvokeRequired)
        {
            this.vmethod_0().Invoke(new Delegate55(this.method_1), new object[0]);
        }
        else
        {
            this.vmethod_0().Enabled = true;
        }
    }

    private void method_2(object sender, EventArgs e)
    {
        this.fMain_0.Visible = true;
        this.fMain_0.WindowState = FormWindowState.Normal;
    }

    private void method_3(object sender, EventArgs e)
    {
        if (MessageBox.Show("Are you sure want to exit?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
        {
            this.vmethod_12().Visible = false;
            Class130.fMain_0.method_50();
        }
    }

    private void method_4(object sender, EventArgs e)
    {
        Class130.fSettings_0.Visible = true;
        Class130.fSettings_0.method_0(Class145.smethod_3().method_14());
        Class130.fSettings_0.Left = (int) Math.Round((double) ((Class145.smethod_3().method_14().Left + (((double) Class145.smethod_3().method_14().Width) / 2.0)) - (((double) Class130.fSettings_0.Width) / 2.0)));
        Class130.fSettings_0.Top = (int) Math.Round((double) ((Class145.smethod_3().method_14().Top + (((double) Class145.smethod_3().method_14().Height) / 2.0)) - (((double) Class130.fSettings_0.Height) / 2.0)));
    }

    private void method_5(object sender, EventArgs e)
    {
        this.fMain_0.Visible = true;
        this.fMain_0.WindowState = FormWindowState.Normal;
        this.fMain_0.Activate();
    }

    public void method_6()
    {
        this.vmethod_12().Visible = false;
    }

    private ContextMenuStrip vmethod_0()
    {
        return this.contextMenuStrip_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    private void vmethod_1(ContextMenuStrip contextMenuStrip_1)
    {
        this.contextMenuStrip_0 = contextMenuStrip_1;
    }

    private ToolStripMenuItem vmethod_10()
    {
        return this.toolStripMenuItem_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    private void vmethod_11(ToolStripMenuItem toolStripMenuItem_3)
    {
        EventHandler handler = new EventHandler(this.method_4);
        ToolStripMenuItem item = this.toolStripMenuItem_2;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_2 = toolStripMenuItem_3;
        item = this.toolStripMenuItem_2;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    private NotifyIcon vmethod_12()
    {
        return this.notifyIcon_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    private void vmethod_13(NotifyIcon notifyIcon_1)
    {
        EventHandler handler = new EventHandler(this.method_5);
        NotifyIcon icon = this.notifyIcon_0;
        if (icon != null)
        {
            icon.DoubleClick -= handler;
        }
        this.notifyIcon_0 = notifyIcon_1;
        icon = this.notifyIcon_0;
        if (icon != null)
        {
            icon.DoubleClick += handler;
        }
    }

    private ToolStripMenuItem vmethod_2()
    {
        return this.toolStripMenuItem_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    private void vmethod_3(ToolStripMenuItem toolStripMenuItem_3)
    {
        EventHandler handler = new EventHandler(this.method_2);
        EventHandler handler2 = new EventHandler(this.method_5);
        ToolStripMenuItem item = this.toolStripMenuItem_0;
        if (item != null)
        {
            item.Click -= handler;
            item.Click -= handler2;
        }
        this.toolStripMenuItem_0 = toolStripMenuItem_3;
        item = this.toolStripMenuItem_0;
        if (item != null)
        {
            item.Click += handler;
            item.Click += handler2;
        }
    }

    private ToolStripSeparator vmethod_4()
    {
        return this.toolStripSeparator_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    private void vmethod_5(ToolStripSeparator toolStripSeparator_2)
    {
        this.toolStripSeparator_0 = toolStripSeparator_2;
    }

    private ToolStripSeparator vmethod_6()
    {
        return this.toolStripSeparator_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    private void vmethod_7(ToolStripSeparator toolStripSeparator_2)
    {
        this.toolStripSeparator_1 = toolStripSeparator_2;
    }

    private ToolStripMenuItem vmethod_8()
    {
        return this.toolStripMenuItem_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    private void vmethod_9(ToolStripMenuItem toolStripMenuItem_3)
    {
        EventHandler handler = new EventHandler(this.method_3);
        ToolStripMenuItem item = this.toolStripMenuItem_1;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_1 = toolStripMenuItem_3;
        item = this.toolStripMenuItem_1;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    private delegate void Delegate55();
}

