﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Threading;

internal sealed class Class20<T> : IEnumerable<T>, IEnumerable, ICollection
{
    private T[] gparam_0;
    private int int_0;
    private int int_1;
    private object object_0;

    public Class20()
    {
        this.gparam_0 = Class69<T>.gparam_0;
        this.int_0 = 0;
        this.int_1 = 0;
    }

    public Class20(IEnumerable<T> ienumerable_0)
    {
        if (ienumerable_0 == null)
        {
            throw new ArgumentNullException();
        }
        ICollection<T> is2 = ienumerable_0 as ICollection<T>;
        if (is2 != null)
        {
            int count = is2.Count;
            this.gparam_0 = new T[count];
            is2.CopyTo(this.gparam_0, 0);
            this.int_0 = count;
        }
        else
        {
            this.int_0 = 0;
            this.gparam_0 = new T[4];
            IEnumerator<T> enumerator = ienumerable_0.GetEnumerator();
            while (enumerator.MoveNext())
            {
                this.method_7(enumerator.Current);
            }
        }
    }

    public Class20(int int_2)
    {
        if (int_2 < 0)
        {
            throw new ArgumentOutOfRangeException();
        }
        this.gparam_0 = new T[int_2];
        this.int_0 = 0;
        this.int_1 = 0;
    }

    public void method_0()
    {
        Array.Clear(this.gparam_0, 0, this.int_0);
        this.int_0 = 0;
        this.int_1++;
    }

    public bool method_1(T gparam_1)
    {
        int index = this.int_0;
        EqualityComparer<T> comparer = EqualityComparer<T>.Default;
        while (index-- > 0)
        {
            if (gparam_1 == null)
            {
                if (this.gparam_0[index] == null)
                {
                    return true;
                }
                continue;
            }
            if ((this.gparam_0[index] != null) && comparer.Equals(this.gparam_0[index], gparam_1))
            {
                return true;
            }
        }
        return false;
    }

    public void method_2(T[] gparam_1, int int_2)
    {
        if (gparam_1 == null)
        {
            throw new ArgumentNullException("#=z5jI7l7s=");
        }
        if ((int_2 < 0) || (int_2 > gparam_1.Length))
        {
            throw new ArgumentOutOfRangeException("#=zBBshIlI=", "arrayIndex < 0 || arrayIndex > array.Length");
        }
        if ((gparam_1.Length - int_2) < this.int_0)
        {
            throw new ArgumentException("Invalid Off Len");
        }
        Array.Copy(this.gparam_0, 0, gparam_1, int_2, this.int_0);
        Array.Reverse(gparam_1, int_2, this.int_0);
    }

    public Struct4<T> method_3()
    {
        return new Struct4<T>((Class20<T>) this);
    }

    public void method_4()
    {
        int num = (int) (this.gparam_0.Length * 0.9);
        if (this.int_0 < num)
        {
            T[] destinationArray = new T[this.int_0];
            Array.Copy(this.gparam_0, 0, destinationArray, 0, this.int_0);
            this.gparam_0 = destinationArray;
            this.int_1++;
        }
    }

    public T method_5()
    {
        if (this.int_0 == 0)
        {
            throw new InvalidOperationException();
        }
        return this.gparam_0[this.int_0 - 1];
    }

    public T method_6()
    {
        if (this.int_0 == 0)
        {
            throw new InvalidOperationException();
        }
        this.int_1++;
        int index = this.int_0 - 1;
        this.int_0 = index;
        this.gparam_0[this.int_0] = default(T);
        return this.gparam_0[index];
    }

    public void method_7(T gparam_1)
    {
        if (this.int_0 == this.gparam_0.Length)
        {
            T[] destinationArray = new T[(this.gparam_0.Length == 0) ? 4 : (2 * this.gparam_0.Length)];
            Array.Copy(this.gparam_0, 0, destinationArray, 0, this.int_0);
            this.gparam_0 = destinationArray;
        }
        int index = this.int_0;
        this.int_0 = index + 1;
        this.gparam_0[index] = gparam_1;
        this.int_1++;
    }

    public T[] method_8()
    {
        T[] localArray = new T[this.int_0];
        for (int i = 0; i < this.int_0; i++)
        {
            localArray[i] = this.gparam_0[(this.int_0 - i) - 1];
        }
        return localArray;
    }

    IEnumerator<T> IEnumerable<T>.GetEnumerator()
    {
        return new Struct4<T>((Class20<T>) this);
    }

    void ICollection.CopyTo(Array array, int index)
    {
        if (array == null)
        {
            throw new ArgumentNullException();
        }
        if (array.Rank != 1)
        {
            throw new ArgumentException();
        }
        if (array.GetLowerBound(0) != 0)
        {
            throw new ArgumentException();
        }
        if ((index < 0) || (index > array.Length))
        {
            throw new ArgumentOutOfRangeException();
        }
        if ((array.Length - index) < this.int_0)
        {
            throw new ArgumentException();
        }
        Array.Copy(this.gparam_0, 0, array, index, this.int_0);
        Array.Reverse(array, index, this.int_0);
    }

    IEnumerator IEnumerable.GetEnumerator()
    {
        return new Struct4<T>((Class20<T>) this);
    }

    public int Count
    {
        get
        {
            return this.int_0;
        }
    }

    bool ICollection.IsSynchronized
    {
        get
        {
            return false;
        }
    }

    object ICollection.SyncRoot
    {
        get
        {
            if (this.object_0 == null)
            {
                Interlocked.CompareExchange(ref this.object_0, new object(), null);
            }
            return this.object_0;
        }
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct Struct4 : IEnumerator<T>, IDisposable, IEnumerator
    {
        private Class20<T> class20_0;
        private int int_0;
        private int int_1;
        private T gparam_0;
        internal Struct4(Class20<T> class20_1)
        {
            this.class20_0 = class20_1;
            this.int_1 = this.class20_0.int_1;
            this.int_0 = -2;
            this.gparam_0 = default(T);
        }

        public void Dispose()
        {
            this.int_0 = -1;
        }

        public bool MoveNext()
        {
            if (this.int_1 != this.class20_0.int_1)
            {
                throw new InvalidOperationException("EnumFailedVersion");
            }
            if (this.int_0 == -2)
            {
                this.int_0 = this.class20_0.int_0 - 1;
                bool flag1 = this.int_0 >= 0;
                if (flag1)
                {
                    this.gparam_0 = this.class20_0.gparam_0[this.int_0];
                }
                return flag1;
            }
            if (this.int_0 == -1)
            {
                return false;
            }
            int num = this.int_0 - 1;
            this.int_0 = num;
            bool flag2 = num >= 0;
            if (flag2)
            {
                this.gparam_0 = this.class20_0.gparam_0[this.int_0];
                return flag2;
            }
            this.gparam_0 = default(T);
            return flag2;
        }

        public T Current
        {
            get
            {
                if (this.int_0 == -2)
                {
                    throw new InvalidOperationException();
                }
                if (this.int_0 == -1)
                {
                    throw new InvalidOperationException();
                }
                return this.gparam_0;
            }
        }
        object IEnumerator.Current
        {
            get
            {
                if (this.int_0 == -2)
                {
                    throw new InvalidOperationException();
                }
                if (this.int_0 == -1)
                {
                    throw new InvalidOperationException();
                }
                return this.gparam_0;
            }
        }
        void IEnumerator.Reset()
        {
            if (this.int_1 != this.class20_0.int_1)
            {
                throw new InvalidOperationException();
            }
            this.int_0 = -2;
            this.gparam_0 = default(T);
        }
    }
}

