﻿using Microsoft.VisualBasic.CompilerServices;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using VisualPlus.Toolkit.Controls.Interactivity;

[DesignerGenerated]
public sealed class fCertificate : Form
{
    private IContainer icontainer_0;
    private Label label_0;
    private Label label_1;
    private ComboBox comboBox_0;
    private Label label_2;
    private ComboBox comboBox_1;
    private Label label_3;
    private Label label_4;
    private TextBox textBox_0;
    private Timer timer_0;
    private Label label_5;
    private PictureBox pictureBox_0;
    private VisualButton visualButton_0;
    private Timer timer_1;
    private bool bool_0;
    private string string_0;
    private string string_1;
    private int int_0;

    public fCertificate();
    [CompilerGenerated]
    private void _Lambda$__64-0();
    [DebuggerNonUserCode]
    protected override void Dispose(bool disposing);
    private void fCertificate_Closing(object sender, CancelEventArgs e);
    private void fCertificate_Load(object sender, EventArgs e);
    [DebuggerStepThrough]
    private void InitializeComponent();
    public void method_0();
    private void method_1(object sender, EventArgs e);
    private void method_2(object sender, EventArgs e);
    private void method_3();
    public void method_4();
    public void method_5();
    private void method_6(object sender, EventArgs e);
    private void method_7(object sender, EventArgs e);
    internal virtual Label vmethod_0();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_1(Label label_6);
    internal virtual Label vmethod_10();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_11(Label label_6);
    internal virtual Label vmethod_12();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_13(Label label_6);
    internal virtual TextBox vmethod_14();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_15(TextBox textBox_1);
    internal virtual Timer vmethod_16();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_17(Timer timer_2);
    internal virtual Label vmethod_18();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_19(Label label_6);
    internal virtual Label vmethod_2();
    internal virtual PictureBox vmethod_20();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_21(PictureBox pictureBox_1);
    internal virtual VisualButton vmethod_22();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_23(VisualButton visualButton_1);
    internal virtual Timer vmethod_24();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_25(Timer timer_2);
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_3(Label label_6);
    internal virtual ComboBox vmethod_4();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_5(ComboBox comboBox_2);
    internal virtual Label vmethod_6();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_7(Label label_6);
    internal virtual ComboBox vmethod_8();
    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_9(ComboBox comboBox_2);

    private delegate void Delegate183();

    private delegate void Delegate184();
}

