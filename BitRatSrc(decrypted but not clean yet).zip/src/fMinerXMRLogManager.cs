﻿using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;

[DesignerGenerated]
public sealed class fMinerXMRLogManager : Form
{
    private IContainer icontainer_0;
    private GClass7 gclass7_0;
    private StatusStrip statusStrip_0;
    private ToolStripStatusLabel toolStripStatusLabel_0;
    private ToolStripStatusLabel toolStripStatusLabel_1;
    private RichTextBox richTextBox_0;
    private Timer timer_0;
    private ToolStripStatusLabel toolStripStatusLabel_2;
    private ContextMenuStrip contextMenuStrip_0;
    private ToolStripMenuItem toolStripMenuItem_0;
    private ToolStripMenuItem toolStripMenuItem_1;
    private ToolStripSeparator toolStripSeparator_0;
    private ToolStripMenuItem toolStripMenuItem_2;
    private ToolStripSeparator toolStripSeparator_1;
    private ToolStripMenuItem toolStripMenuItem_3;
    private ToolStripMenuItem toolStripMenuItem_4;
    private ToolStripSeparator toolStripSeparator_2;
    private ToolStripMenuItem toolStripMenuItem_5;
    public Collection collection_0;

    public fMinerXMRLogManager()
    {
        base.Load += new EventHandler(this.fMinerXMRLogManager_Load);
        base.Closing += new CancelEventHandler(this.fMinerXMRLogManager_Closing);
        this.collection_0 = new Collection();
        this.InitializeComponent();
    }

    [DebuggerNonUserCode]
    protected override void Dispose(bool disposing)
    {
        if (disposing && (this.icontainer_0 != null))
        {
            this.icontainer_0.Dispose();
        }
    }

    private void fMinerXMRLogManager_Closing(object sender, CancelEventArgs e)
    {
        base.Visible = false;
        e.Cancel = true;
    }

    private void fMinerXMRLogManager_Load(object sender, EventArgs e)
    {
        this.vmethod_0().Columns.Add("Miner");
        this.vmethod_0().Columns[0].Width = (this.vmethod_0().Width - 6) - SystemInformation.VerticalScrollBarWidth;
        this.vmethod_0().GridLines = Class135.smethod_0().Gridlines;
    }

    [DebuggerStepThrough]
    private void InitializeComponent()
    {
        this.icontainer_0 = new Container();
        this.vmethod_1(new GClass7());
        this.vmethod_15(new ContextMenuStrip(this.icontainer_0));
        this.vmethod_17(new ToolStripMenuItem());
        this.vmethod_19(new ToolStripMenuItem());
        this.vmethod_21(new ToolStripSeparator());
        this.vmethod_23(new ToolStripMenuItem());
        this.vmethod_25(new ToolStripSeparator());
        this.vmethod_27(new ToolStripMenuItem());
        this.vmethod_29(new ToolStripMenuItem());
        this.vmethod_31(new ToolStripSeparator());
        this.vmethod_33(new ToolStripMenuItem());
        this.vmethod_3(new StatusStrip());
        this.vmethod_5(new ToolStripStatusLabel());
        this.vmethod_13(new ToolStripStatusLabel());
        this.vmethod_7(new ToolStripStatusLabel());
        this.vmethod_9(new RichTextBox());
        this.vmethod_11(new Timer(this.icontainer_0));
        this.vmethod_14().SuspendLayout();
        this.vmethod_2().SuspendLayout();
        base.SuspendLayout();
        this.vmethod_0().Alignment = ListViewAlignment.Left;
        this.vmethod_0().Anchor = AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
        this.vmethod_0().AutoArrange = false;
        this.vmethod_0().BackColor = Color.White;
        this.vmethod_0().ContextMenuStrip = this.vmethod_14();
        this.vmethod_0().Font = new Font("Microsoft Sans Serif", 8.142858f, FontStyle.Regular, GraphicsUnit.Point, 0);
        this.vmethod_0().ForeColor = Color.Black;
        this.vmethod_0().FullRowSelect = true;
        this.vmethod_0().HeaderStyle = ColumnHeaderStyle.Nonclickable;
        this.vmethod_0().HideSelection = false;
        this.vmethod_0().Location = new Point(0, 0);
        this.vmethod_0().Margin = new Padding(1);
        this.vmethod_0().Name = "lvMiners";
        this.vmethod_0().Size = new Size(0xcd, 0x1c8);
        this.vmethod_0().TabIndex = 0x23;
        this.vmethod_0().TabStop = false;
        this.vmethod_0().UseCompatibleStateImageBehavior = false;
        this.vmethod_0().View = View.Details;
        this.vmethod_14().ImageScalingSize = new Size(0x18, 0x18);
        ToolStripItem[] toolStripItems = new ToolStripItem[] { this.vmethod_16(), this.vmethod_24(), this.vmethod_26() };
        this.vmethod_14().Items.AddRange(toolStripItems);
        this.vmethod_14().Name = "ContextMenuStrip1";
        this.vmethod_14().Size = new Size(0x66, 0x36);
        ToolStripItem[] itemArray2 = new ToolStripItem[] { this.vmethod_18(), this.vmethod_20(), this.vmethod_22() };
        this.vmethod_16().DropDownItems.AddRange(itemArray2);
        this.vmethod_16().Name = "LogStripMenuItem1";
        this.vmethod_16().Size = new Size(0x65, 0x16);
        this.vmethod_16().Text = "Log";
        this.vmethod_18().Name = "ViewToolStripMenuItem";
        this.vmethod_18().Size = new Size(0xa2, 0x16);
        this.vmethod_18().Text = "View";
        this.vmethod_20().Name = "ToolStripMenuItem3";
        this.vmethod_20().Size = new Size(0x9f, 6);
        this.vmethod_22().Name = "UpdateAndViewToolStripMenuItem";
        this.vmethod_22().Size = new Size(0xa2, 0x16);
        this.vmethod_22().Text = "Update and view";
        this.vmethod_24().Name = "ToolStripMenuItem1";
        this.vmethod_24().Size = new Size(0x62, 6);
        ToolStripItem[] itemArray3 = new ToolStripItem[] { this.vmethod_28(), this.vmethod_30(), this.vmethod_32() };
        this.vmethod_26().DropDownItems.AddRange(itemArray3);
        this.vmethod_26().Name = "ClearToolStripMenuItem";
        this.vmethod_26().Size = new Size(0x65, 0x16);
        this.vmethod_26().Text = "Clear";
        this.vmethod_28().Name = "AllToolStripMenuItem";
        this.vmethod_28().Size = new Size(0x76, 0x16);
        this.vmethod_28().Text = "All";
        this.vmethod_30().Name = "ToolStripMenuItem2";
        this.vmethod_30().Size = new Size(0x73, 6);
        this.vmethod_32().Name = "SelectedToolStripMenuItem";
        this.vmethod_32().Size = new Size(0x76, 0x16);
        this.vmethod_32().Text = "Selected";
        this.vmethod_2().AutoSize = false;
        this.vmethod_2().BackColor = Color.FromArgb(0xeb, 0xed, 0xef);
        this.vmethod_2().ImageScalingSize = new Size(0x1c, 0x1c);
        ToolStripItem[] itemArray4 = new ToolStripItem[] { this.vmethod_4(), this.vmethod_12(), this.vmethod_6() };
        this.vmethod_2().Items.AddRange(itemArray4);
        this.vmethod_2().Location = new Point(0, 0x1c9);
        this.vmethod_2().Name = "ssKeylogOffline";
        this.vmethod_2().Padding = new Padding(1, 0, 7, 0);
        this.vmethod_2().Size = new Size(0x387, 0x13);
        this.vmethod_2().SizingGrip = false;
        this.vmethod_2().Stretch = false;
        this.vmethod_2().TabIndex = 0x22;
        this.vmethod_2().Text = "stStatus";
        this.vmethod_4().AutoSize = false;
        this.vmethod_4().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_4().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_4().Margin = new Padding(0, 3, 0, 0);
        this.vmethod_4().Name = "tsLogs";
        this.vmethod_4().Size = new Size(0x131, 0x10);
        this.vmethod_4().Text = "Logs: N/A";
        this.vmethod_4().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_12().AutoSize = false;
        this.vmethod_12().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_12().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_12().Margin = new Padding(0, 3, 0, 0);
        this.vmethod_12().Name = "tsLogUser";
        this.vmethod_12().Size = new Size(0x18c, 0x10);
        this.vmethod_12().Spring = true;
        this.vmethod_12().Text = "Current log: N/A";
        this.vmethod_12().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_6().AutoSize = false;
        this.vmethod_6().BorderSides = ToolStripStatusLabelBorderSides.All;
        this.vmethod_6().BorderStyle = Border3DStyle.SunkenOuter;
        this.vmethod_6().Font = new Font("Segoe UI", 9f);
        this.vmethod_6().Margin = new Padding(0, 3, -6, 0);
        this.vmethod_6().Name = "tsLogSize";
        this.vmethod_6().Size = new Size(200, 0x10);
        this.vmethod_6().Text = "Log size: N/A";
        this.vmethod_6().TextAlign = ContentAlignment.TopLeft;
        this.vmethod_8().Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Top;
        this.vmethod_8().Location = new Point(0xcf, 0);
        this.vmethod_8().Margin = new Padding(2);
        this.vmethod_8().Name = "rtLogs";
        this.vmethod_8().ScrollBars = RichTextBoxScrollBars.Vertical;
        this.vmethod_8().Size = new Size(0x2b7, 0x1c8);
        this.vmethod_8().TabIndex = 0x20;
        this.vmethod_8().Text = string.Empty;
        this.vmethod_10().Enabled = true;
        this.vmethod_10().Interval = 0x3e8;
        base.AutoScaleDimensions = new SizeF(6f, 13f);
        base.AutoScaleMode = AutoScaleMode.Font;
        base.ClientSize = new Size(0x387, 0x1dc);
        base.Controls.Add(this.vmethod_0());
        base.Controls.Add(this.vmethod_2());
        base.Controls.Add(this.vmethod_8());
        this.DoubleBuffered = true;
        base.Margin = new Padding(2);
        base.Name = "fMinerXMRLogManager";
        base.Opacity = 0.0;
        base.ShowIcon = false;
        base.ShowInTaskbar = false;
        base.StartPosition = FormStartPosition.CenterParent;
        this.Text = "XMR Mining - Log manager";
        this.vmethod_14().ResumeLayout(false);
        this.vmethod_2().ResumeLayout(false);
        this.vmethod_2().PerformLayout();
        base.ResumeLayout(false);
    }

    public void method_0(string string_0, string string_1, string string_2)
    {
        if (this.vmethod_0().InvokeRequired)
        {
            object[] args = new object[] { string_0, string_1, string_2 };
            this.vmethod_0().Invoke(new Delegate64(this.method_0), args);
        }
        else
        {
            int num3;
            string_2 = Encoding.UTF8.GetString(Convert.FromBase64String(string_2));
            if (Class136.smethod_31(ref this.collection_0, ref string_0))
            {
                this.vmethod_0().Items[string_0].Remove();
                this.collection_0.Remove(string_0);
            }
            this.collection_0.Add(string_2, string_0, null, null);
            this.vmethod_8().ReadOnly = true;
            this.vmethod_8().Text = Conversions.ToString(this.collection_0[string_0]);
            this.vmethod_12().Text = "Current log: " + string_1;
            ref bool flagRef = ref false;
            double number = Strings.Len(this.collection_0[string_0]);
            string str3 = "Log size: ";
            ToolStripStatusLabel label = this.vmethod_6();
            ProjectData.ClearProjectError();
            string expression = string.Empty;
            if (number >= 1099511627776)
            {
                expression = Strings.Format((((number / 1024.0) / 1024.0) / 1024.0) / 1024.0, "#0.00") + " TiB";
            }
            else if (number >= 1073741824.0)
            {
                expression = Strings.Format(((number / 1024.0) / 1024.0) / 1024.0, "#0.00") + " GiB";
            }
            else if (number >= 1048576.0)
            {
                expression = Strings.Format((number / 1024.0) / 1024.0, "#0.00") + " MiB";
            }
            else if (number >= 1024.0)
            {
                expression = Strings.Format(number / 1024.0, "#0.00") + " KiB";
            }
            else if (number < 1024.0)
            {
                expression = Conversions.ToString(Conversion.Fix(number)) + " B";
            }
            if (flagRef)
            {
                expression = Strings.Split(expression, " ", -1, CompareMethod.Text)[0];
            }
            string str = (expression.Length <= 0) ? " 0 B" : expression;
            if (num3 != 0)
            {
                ProjectData.ClearProjectError();
            }
            label.Text = str3 + str;
            this.vmethod_0().Items.Add(string_0, string_1, 0);
            this.vmethod_0().Items[string_0].Tag = string_0;
        }
    }

    public void method_1(string string_0)
    {
        if (this.vmethod_0().InvokeRequired)
        {
            object[] args = new object[] { string_0 };
            this.vmethod_0().Invoke(new Delegate63(this.method_1), args);
        }
        else
        {
            this.collection_0.Remove(string_0);
            if (Operators.ConditionalCompareObjectEqual(this.vmethod_0().SelectedItems[0].Tag, string_0, true))
            {
                this.vmethod_8().Clear();
            }
            this.vmethod_0().Items[string_0].Remove();
        }
    }

    private void method_10(object sender, EventArgs e)
    {
        Class136.Class138 class2 = new Class136.Class138();
        class2.string_0 = Conversions.ToString(this.vmethod_0().SelectedItems[0].Tag);
        class2.string_1 = "xmr_mine_log|1";
        class2.long_0 = 0L;
        if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
        {
            new Thread(new ThreadStart(class2._Lambda$__0)).Start();
        }
    }

    private void method_11(object sender, EventArgs e)
    {
        for (int i = this.vmethod_0().Items.Count - 1; i >= 0; i += -1)
        {
            if (this.vmethod_0().Items[i].Selected)
            {
                if ((this.vmethod_0().SelectedItems.Count > 0) && (this.vmethod_0().SelectedItems[0].Index == i))
                {
                    this.vmethod_8().Clear();
                    this.vmethod_12().Text = "N/A";
                    this.vmethod_6().Text = "N/A";
                }
                this.method_1(Conversions.ToString(this.vmethod_0().Items[i].Tag));
                Application.DoEvents();
            }
        }
    }

    private void method_12(object sender, EventArgs e)
    {
        this.vmethod_0().Items.Clear();
        this.collection_0.Clear();
        this.vmethod_8().Clear();
        this.vmethod_12().Text = "N/A";
        this.vmethod_6().Text = "N/A";
    }

    private void method_13(object sender, EventArgs e)
    {
        if (this.vmethod_0().SelectedItems.Count > 0)
        {
            int num3;
            this.vmethod_8().ReadOnly = true;
            this.vmethod_8().Text = Conversions.ToString(this.collection_0[this.vmethod_0().SelectedItems[0].Tag]);
            this.vmethod_12().Text = "Current log: " + this.vmethod_0().SelectedItems[0].Text;
            ref bool flagRef = ref false;
            double number = Strings.Len(this.collection_0[this.vmethod_0().SelectedItems[0].Tag]);
            string str3 = "Log size: ";
            ToolStripStatusLabel label = this.vmethod_6();
            ProjectData.ClearProjectError();
            string expression = string.Empty;
            if (number >= 1099511627776)
            {
                expression = Strings.Format((((number / 1024.0) / 1024.0) / 1024.0) / 1024.0, "#0.00") + " TiB";
            }
            else if (number >= 1073741824.0)
            {
                expression = Strings.Format(((number / 1024.0) / 1024.0) / 1024.0, "#0.00") + " GiB";
            }
            else if (number >= 1048576.0)
            {
                expression = Strings.Format((number / 1024.0) / 1024.0, "#0.00") + " MiB";
            }
            else if (number >= 1024.0)
            {
                expression = Strings.Format(number / 1024.0, "#0.00") + " KiB";
            }
            else if (number < 1024.0)
            {
                expression = Conversions.ToString(Conversion.Fix(number)) + " B";
            }
            if (flagRef)
            {
                expression = Strings.Split(expression, " ", -1, CompareMethod.Text)[0];
            }
            string str = (expression.Length <= 0) ? " 0 B" : expression;
            if (num3 != 0)
            {
                ProjectData.ClearProjectError();
            }
            label.Text = str3 + str;
        }
    }

    private void method_14(object sender, KeyEventArgs e)
    {
        if (e.KeyData == (Keys.Control | Keys.A))
        {
            IEnumerator enumerator = this.vmethod_0().Items.GetEnumerator();
            while (enumerator.MoveNext())
            {
                ((ListViewItem) enumerator.Current).Selected = true;
            }
        }
    }

    private void method_2(object sender, EventArgs e)
    {
        int num3;
        this.vmethod_8().ReadOnly = true;
        this.vmethod_8().Text = Conversions.ToString(this.collection_0[this.vmethod_0().SelectedItems[0].Tag]);
        this.vmethod_12().Text = "Current log: " + this.vmethod_0().SelectedItems[0].Text;
        ref bool flagRef = ref false;
        double number = Strings.Len(this.collection_0[this.vmethod_0().SelectedItems[0].Tag]);
        string str3 = "Log size: ";
        ToolStripStatusLabel label = this.vmethod_6();
        ProjectData.ClearProjectError();
        string expression = string.Empty;
        if (number >= 1099511627776)
        {
            expression = Strings.Format((((number / 1024.0) / 1024.0) / 1024.0) / 1024.0, "#0.00") + " TiB";
        }
        else if (number >= 1073741824.0)
        {
            expression = Strings.Format(((number / 1024.0) / 1024.0) / 1024.0, "#0.00") + " GiB";
        }
        else if (number >= 1048576.0)
        {
            expression = Strings.Format((number / 1024.0) / 1024.0, "#0.00") + " MiB";
        }
        else if (number >= 1024.0)
        {
            expression = Strings.Format(number / 1024.0, "#0.00") + " KiB";
        }
        else if (number < 1024.0)
        {
            expression = Conversions.ToString(Conversion.Fix(number)) + " B";
        }
        if (flagRef)
        {
            expression = Strings.Split(expression, " ", -1, CompareMethod.Text)[0];
        }
        string str = (expression.Length <= 0) ? " 0 B" : expression;
        if (num3 != 0)
        {
            ProjectData.ClearProjectError();
        }
        label.Text = str3 + str;
    }

    private void method_3(object sender, EventArgs e)
    {
        this.vmethod_4().Text = "Logs: " + Conversions.ToString(this.vmethod_0().Items.Count);
    }

    private void method_4(object sender, EventArgs e)
    {
        this.vmethod_0().Items.Clear();
        this.collection_0.Clear();
        this.vmethod_8().Clear();
        this.vmethod_12().Text = "N/A";
        this.vmethod_6().Text = "N/A";
    }

    private void method_5(object sender, EventArgs e)
    {
        for (int i = this.vmethod_0().Items.Count - 1; i >= 0; i += -1)
        {
            if (this.vmethod_0().Items[i].Selected)
            {
                if ((this.vmethod_0().SelectedItems.Count > 0) && (this.vmethod_0().SelectedItems[0].Index == i))
                {
                    this.vmethod_8().Clear();
                    this.vmethod_12().Text = "N/A";
                    this.vmethod_6().Text = "N/A";
                }
                this.method_1(Conversions.ToString(this.vmethod_0().Items[i].Tag));
                Application.DoEvents();
            }
        }
    }

    private void method_6(object sender, MouseEventArgs e)
    {
        this.vmethod_16().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_0().SelectedItems.Count == 1, true, false));
        this.vmethod_32().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_0().SelectedItems.Count > 0, true, false));
        this.vmethod_28().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_0().Items.Count > 0, true, false));
        this.vmethod_26().Enabled = Conversions.ToBoolean(Interaction.IIf(this.vmethod_0().Items.Count > 0, true, false));
    }

    private void method_7(object sender, EventArgs e)
    {
        int num3;
        this.vmethod_8().ReadOnly = true;
        this.vmethod_8().Text = Conversions.ToString(this.collection_0[this.vmethod_0().SelectedItems[0].Tag]);
        this.vmethod_12().Text = "Current log: " + this.vmethod_0().SelectedItems[0].Text;
        ref bool flagRef = ref false;
        double number = Strings.Len(this.collection_0[this.vmethod_0().SelectedItems[0].Tag]);
        string str3 = "Log size: ";
        ToolStripStatusLabel label = this.vmethod_6();
        ProjectData.ClearProjectError();
        string expression = string.Empty;
        if (number >= 1099511627776)
        {
            expression = Strings.Format((((number / 1024.0) / 1024.0) / 1024.0) / 1024.0, "#0.00") + " TiB";
        }
        else if (number >= 1073741824.0)
        {
            expression = Strings.Format(((number / 1024.0) / 1024.0) / 1024.0, "#0.00") + " GiB";
        }
        else if (number >= 1048576.0)
        {
            expression = Strings.Format((number / 1024.0) / 1024.0, "#0.00") + " MiB";
        }
        else if (number >= 1024.0)
        {
            expression = Strings.Format(number / 1024.0, "#0.00") + " KiB";
        }
        else if (number < 1024.0)
        {
            expression = Conversions.ToString(Conversion.Fix(number)) + " B";
        }
        if (flagRef)
        {
            expression = Strings.Split(expression, " ", -1, CompareMethod.Text)[0];
        }
        string str = (expression.Length <= 0) ? " 0 B" : expression;
        if (num3 != 0)
        {
            ProjectData.ClearProjectError();
        }
        label.Text = str3 + str;
    }

    private void method_8(object sender, EventArgs e)
    {
        Class136.Class138 class2 = new Class136.Class138();
        class2.string_0 = Conversions.ToString(this.vmethod_0().SelectedItems[0].Tag);
        class2.string_1 = "xmr_mine_log|1";
        class2.long_0 = 0L;
        if (Class130.concurrentDictionary_3.ContainsKey(class2.string_0))
        {
            new Thread(new ThreadStart(class2._Lambda$__0)).Start();
        }
    }

    private void method_9(object sender, EventArgs e)
    {
        int num3;
        this.vmethod_8().ReadOnly = true;
        this.vmethod_8().Text = Conversions.ToString(this.collection_0[this.vmethod_0().SelectedItems[0].Tag]);
        this.vmethod_12().Text = "Current log: " + this.vmethod_0().SelectedItems[0].Text;
        ref bool flagRef = ref false;
        double number = Strings.Len(this.collection_0[this.vmethod_0().SelectedItems[0].Tag]);
        string str3 = "Log size: ";
        ToolStripStatusLabel label = this.vmethod_6();
        ProjectData.ClearProjectError();
        string expression = string.Empty;
        if (number >= 1099511627776)
        {
            expression = Strings.Format((((number / 1024.0) / 1024.0) / 1024.0) / 1024.0, "#0.00") + " TiB";
        }
        else if (number >= 1073741824.0)
        {
            expression = Strings.Format(((number / 1024.0) / 1024.0) / 1024.0, "#0.00") + " GiB";
        }
        else if (number >= 1048576.0)
        {
            expression = Strings.Format((number / 1024.0) / 1024.0, "#0.00") + " MiB";
        }
        else if (number >= 1024.0)
        {
            expression = Strings.Format(number / 1024.0, "#0.00") + " KiB";
        }
        else if (number < 1024.0)
        {
            expression = Conversions.ToString(Conversion.Fix(number)) + " B";
        }
        if (flagRef)
        {
            expression = Strings.Split(expression, " ", -1, CompareMethod.Text)[0];
        }
        string str = (expression.Length <= 0) ? " 0 B" : expression;
        if (num3 != 0)
        {
            ProjectData.ClearProjectError();
        }
        label.Text = str3 + str;
    }

    internal virtual GClass7 vmethod_0()
    {
        return this.gclass7_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_1(GClass7 gclass7_1)
    {
        EventHandler handler = new EventHandler(this.method_2);
        MouseEventHandler handler2 = new MouseEventHandler(this.method_6);
        EventHandler handler3 = new EventHandler(this.method_13);
        KeyEventHandler handler4 = new KeyEventHandler(this.method_14);
        GClass7 class2 = this.gclass7_0;
        if (class2 != null)
        {
            class2.DoubleClick -= handler;
            class2.MouseUp -= handler2;
            class2.SelectedIndexChanged -= handler3;
            class2.KeyDown -= handler4;
        }
        this.gclass7_0 = gclass7_1;
        class2 = this.gclass7_0;
        if (class2 != null)
        {
            class2.DoubleClick += handler;
            class2.MouseUp += handler2;
            class2.SelectedIndexChanged += handler3;
            class2.KeyDown += handler4;
        }
    }

    internal virtual Timer vmethod_10()
    {
        return this.timer_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_11(Timer timer_1)
    {
        EventHandler handler = new EventHandler(this.method_3);
        Timer timer = this.timer_0;
        if (timer != null)
        {
            timer.Tick -= handler;
        }
        this.timer_0 = timer_1;
        timer = this.timer_0;
        if (timer != null)
        {
            timer.Tick += handler;
        }
    }

    internal virtual ToolStripStatusLabel vmethod_12()
    {
        return this.toolStripStatusLabel_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_13(ToolStripStatusLabel toolStripStatusLabel_3)
    {
        this.toolStripStatusLabel_2 = toolStripStatusLabel_3;
    }

    internal virtual ContextMenuStrip vmethod_14()
    {
        return this.contextMenuStrip_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_15(ContextMenuStrip contextMenuStrip_1)
    {
        this.contextMenuStrip_0 = contextMenuStrip_1;
    }

    internal virtual ToolStripMenuItem vmethod_16()
    {
        return this.toolStripMenuItem_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_17(ToolStripMenuItem toolStripMenuItem_6)
    {
        this.toolStripMenuItem_0 = toolStripMenuItem_6;
    }

    internal virtual ToolStripMenuItem vmethod_18()
    {
        return this.toolStripMenuItem_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_19(ToolStripMenuItem toolStripMenuItem_6)
    {
        EventHandler handler = new EventHandler(this.method_9);
        ToolStripMenuItem item = this.toolStripMenuItem_1;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_1 = toolStripMenuItem_6;
        item = this.toolStripMenuItem_1;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual StatusStrip vmethod_2()
    {
        return this.statusStrip_0;
    }

    internal virtual ToolStripSeparator vmethod_20()
    {
        return this.toolStripSeparator_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_21(ToolStripSeparator toolStripSeparator_3)
    {
        this.toolStripSeparator_0 = toolStripSeparator_3;
    }

    internal virtual ToolStripMenuItem vmethod_22()
    {
        return this.toolStripMenuItem_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_23(ToolStripMenuItem toolStripMenuItem_6)
    {
        EventHandler handler = new EventHandler(this.method_10);
        ToolStripMenuItem item = this.toolStripMenuItem_2;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_2 = toolStripMenuItem_6;
        item = this.toolStripMenuItem_2;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripSeparator vmethod_24()
    {
        return this.toolStripSeparator_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_25(ToolStripSeparator toolStripSeparator_3)
    {
        this.toolStripSeparator_1 = toolStripSeparator_3;
    }

    internal virtual ToolStripMenuItem vmethod_26()
    {
        return this.toolStripMenuItem_3;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_27(ToolStripMenuItem toolStripMenuItem_6)
    {
        this.toolStripMenuItem_3 = toolStripMenuItem_6;
    }

    internal virtual ToolStripMenuItem vmethod_28()
    {
        return this.toolStripMenuItem_4;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_29(ToolStripMenuItem toolStripMenuItem_6)
    {
        EventHandler handler = new EventHandler(this.method_12);
        ToolStripMenuItem item = this.toolStripMenuItem_4;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_4 = toolStripMenuItem_6;
        item = this.toolStripMenuItem_4;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_3(StatusStrip statusStrip_1)
    {
        this.statusStrip_0 = statusStrip_1;
    }

    internal virtual ToolStripSeparator vmethod_30()
    {
        return this.toolStripSeparator_2;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_31(ToolStripSeparator toolStripSeparator_3)
    {
        this.toolStripSeparator_2 = toolStripSeparator_3;
    }

    internal virtual ToolStripMenuItem vmethod_32()
    {
        return this.toolStripMenuItem_5;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_33(ToolStripMenuItem toolStripMenuItem_6)
    {
        EventHandler handler = new EventHandler(this.method_11);
        ToolStripMenuItem item = this.toolStripMenuItem_5;
        if (item != null)
        {
            item.Click -= handler;
        }
        this.toolStripMenuItem_5 = toolStripMenuItem_6;
        item = this.toolStripMenuItem_5;
        if (item != null)
        {
            item.Click += handler;
        }
    }

    internal virtual ToolStripStatusLabel vmethod_4()
    {
        return this.toolStripStatusLabel_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_5(ToolStripStatusLabel toolStripStatusLabel_3)
    {
        this.toolStripStatusLabel_0 = toolStripStatusLabel_3;
    }

    internal virtual ToolStripStatusLabel vmethod_6()
    {
        return this.toolStripStatusLabel_1;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_7(ToolStripStatusLabel toolStripStatusLabel_3)
    {
        this.toolStripStatusLabel_1 = toolStripStatusLabel_3;
    }

    internal virtual RichTextBox vmethod_8()
    {
        return this.richTextBox_0;
    }

    [MethodImpl(MethodImplOptions.Synchronized)]
    internal virtual void vmethod_9(RichTextBox richTextBox_1)
    {
        this.richTextBox_0 = richTextBox_1;
    }

    private delegate void Delegate63(string string_0);

    private delegate void Delegate64(string string_0, string string_1, string string_2);
}

